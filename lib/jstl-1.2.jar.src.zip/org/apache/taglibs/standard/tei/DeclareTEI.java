/*    */ package org.apache.taglibs.standard.tei;
/*    */ 
/*    */ import javax.servlet.jsp.tagext.TagData;
/*    */ import javax.servlet.jsp.tagext.TagExtraInfo;
/*    */ import javax.servlet.jsp.tagext.VariableInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DeclareTEI
/*    */   extends TagExtraInfo
/*    */ {
/*    */   public VariableInfo[] getVariableInfo(TagData data) {
/* 46 */     VariableInfo id = new VariableInfo(data.getAttributeString("id"), (data.getAttributeString("type") == null) ? "java.lang.Object" : data.getAttributeString("type"), true, 2);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 52 */     return new VariableInfo[] { id };
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tei\DeclareTEI.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */