/*    */ package org.apache.taglibs.standard.tei;
/*    */ 
/*    */ import javax.servlet.jsp.tagext.TagData;
/*    */ import javax.servlet.jsp.tagext.TagExtraInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XmlParseTEI
/*    */   extends TagExtraInfo
/*    */ {
/*    */   private static final String VAR = "var";
/*    */   private static final String VAR_DOM = "varDom";
/*    */   private static final String SCOPE = "scope";
/*    */   private static final String SCOPE_DOM = "scopeDom";
/*    */   
/*    */   public boolean isValid(TagData us) {
/* 46 */     if (Util.isSpecified(us, "var") && Util.isSpecified(us, "varDom")) {
/* 47 */       return false;
/*    */     }
/*    */     
/* 50 */     if (!Util.isSpecified(us, "var") && !Util.isSpecified(us, "varDom")) {
/* 51 */       return false;
/*    */     }
/*    */     
/* 54 */     if (Util.isSpecified(us, "scope") && !Util.isSpecified(us, "var"))
/* 55 */       return false; 
/* 56 */     if (Util.isSpecified(us, "scopeDom") && !Util.isSpecified(us, "varDom")) {
/* 57 */       return false;
/*    */     }
/* 59 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tei\XmlParseTEI.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */