/*    */ package org.apache.taglibs.standard.tei;
/*    */ 
/*    */ import javax.servlet.jsp.tagext.TagData;
/*    */ import javax.servlet.jsp.tagext.TagExtraInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ImportTEI
/*    */   extends TagExtraInfo
/*    */ {
/*    */   private static final String VAR = "var";
/*    */   private static final String VAR_READER = "varReader";
/*    */   
/*    */   public boolean isValid(TagData us) {
/* 44 */     if (Util.isSpecified(us, "var") && Util.isSpecified(us, "varReader")) {
/* 45 */       return false;
/*    */     }
/* 47 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tei\ImportTEI.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */