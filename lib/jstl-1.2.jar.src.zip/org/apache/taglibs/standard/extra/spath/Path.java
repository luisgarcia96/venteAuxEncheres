package org.apache.taglibs.standard.extra.spath;

import java.util.List;

public abstract class Path {
  public abstract List getSteps();
}


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\extra\spath\Path.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */