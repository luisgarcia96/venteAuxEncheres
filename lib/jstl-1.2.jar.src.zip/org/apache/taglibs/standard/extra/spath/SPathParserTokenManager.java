/*     */ package org.apache.taglibs.standard.extra.spath;
/*     */ 
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SPathParserTokenManager
/*     */   implements SPathParserConstants
/*     */ {
/*     */   private final int jjStopStringLiteralDfa_0(int pos, long active0) {
/*  29 */     switch (pos) {
/*     */     
/*     */     } 
/*  32 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   private final int jjStartNfa_0(int pos, long active0) {
/*  37 */     return jjMoveNfa_0(jjStopStringLiteralDfa_0(pos, active0), pos + 1);
/*     */   }
/*     */   
/*     */   private final int jjStopAtPos(int pos, int kind) {
/*  41 */     this.jjmatchedKind = kind;
/*  42 */     this.jjmatchedPos = pos;
/*  43 */     return pos + 1;
/*     */   }
/*     */   
/*     */   private final int jjStartNfaWithStates_0(int pos, int kind, int state) {
/*  47 */     this.jjmatchedKind = kind;
/*  48 */     this.jjmatchedPos = pos; 
/*  49 */     try { this.curChar = this.input_stream.readChar(); }
/*  50 */     catch (IOException e) { return pos + 1; }
/*  51 */      return jjMoveNfa_0(state, pos + 1);
/*     */   }
/*     */   
/*     */   private final int jjMoveStringLiteralDfa0_0() {
/*  55 */     switch (this.curChar) {
/*     */       
/*     */       case '*':
/*  58 */         return jjStopAtPos(0, 14);
/*     */       case '/':
/*  60 */         return jjStopAtPos(0, 13);
/*     */       case ':':
/*  62 */         return jjStopAtPos(0, 15);
/*     */       case '=':
/*  64 */         return jjStopAtPos(0, 19);
/*     */       case '@':
/*  66 */         return jjStopAtPos(0, 18);
/*     */       case '[':
/*  68 */         return jjStopAtPos(0, 16);
/*     */       case ']':
/*  70 */         return jjStopAtPos(0, 17);
/*     */     } 
/*  72 */     return jjMoveNfa_0(0, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   private final void jjCheckNAdd(int state) {
/*  77 */     if (this.jjrounds[state] != this.jjround) {
/*     */       
/*  79 */       this.jjstateSet[this.jjnewStateCnt++] = state;
/*  80 */       this.jjrounds[state] = this.jjround;
/*     */     } 
/*     */   }
/*     */   
/*     */   private final void jjAddStates(int start, int end) {
/*     */     do {
/*  86 */       this.jjstateSet[this.jjnewStateCnt++] = jjnextStates[start];
/*  87 */     } while (start++ != end);
/*     */   }
/*     */   
/*     */   private final void jjCheckNAddTwoStates(int state1, int state2) {
/*  91 */     jjCheckNAdd(state1);
/*  92 */     jjCheckNAdd(state2);
/*     */   }
/*     */   
/*     */   private final void jjCheckNAddStates(int start, int end) {
/*     */     do {
/*  97 */       jjCheckNAdd(jjnextStates[start]);
/*  98 */     } while (start++ != end);
/*     */   }
/*     */   
/*     */   private final void jjCheckNAddStates(int start) {
/* 102 */     jjCheckNAdd(jjnextStates[start]);
/* 103 */     jjCheckNAdd(jjnextStates[start + 1]);
/*     */   }
/* 105 */   static final long[] jjbitVec0 = new long[] { -2L, -1L, -1L, -1L };
/*     */ 
/*     */   
/* 108 */   static final long[] jjbitVec2 = new long[] { 0L, 0L, -1L, -1L };
/*     */ 
/*     */   
/* 111 */   static final long[] jjbitVec3 = new long[] { 0L, -16384L, -17590038560769L, 8388607L };
/*     */ 
/*     */   
/* 114 */   static final long[] jjbitVec4 = new long[] { 0L, 0L, 0L, -36028797027352577L };
/*     */ 
/*     */   
/* 117 */   static final long[] jjbitVec5 = new long[] { 9219994337134247935L, 9223372036854775294L, -1L, -274156627316187121L };
/*     */ 
/*     */   
/* 120 */   static final long[] jjbitVec6 = new long[] { 16777215L, -65536L, -576458553280167937L, 3L };
/*     */ 
/*     */   
/* 123 */   static final long[] jjbitVec7 = new long[] { 0L, 0L, -17179879616L, 4503588160110591L };
/*     */ 
/*     */   
/* 126 */   static final long[] jjbitVec8 = new long[] { -8194L, -536936449L, -65533L, 234134404065073567L };
/*     */ 
/*     */   
/* 129 */   static final long[] jjbitVec9 = new long[] { -562949953421312L, -8547991553L, 127L, 1979120929931264L };
/*     */ 
/*     */   
/* 132 */   static final long[] jjbitVec10 = new long[] { 576460743713488896L, -562949953419266L, 9007199254740991999L, 412319973375L };
/*     */ 
/*     */   
/* 135 */   static final long[] jjbitVec11 = new long[] { 2594073385365405664L, 17163091968L, 271902628478820320L, 844440767823872L };
/*     */ 
/*     */   
/* 138 */   static final long[] jjbitVec12 = new long[] { 247132830528276448L, 7881300924956672L, 2589004636761075680L, 4294967296L };
/*     */ 
/*     */   
/* 141 */   static final long[] jjbitVec13 = new long[] { 2579997437506199520L, 15837691904L, 270153412153034720L, 0L };
/*     */ 
/*     */   
/* 144 */   static final long[] jjbitVec14 = new long[] { 283724577500946400L, 12884901888L, 283724577500946400L, 13958643712L };
/*     */ 
/*     */   
/* 147 */   static final long[] jjbitVec15 = new long[] { 288228177128316896L, 12884901888L, 0L, 0L };
/*     */ 
/*     */   
/* 150 */   static final long[] jjbitVec16 = new long[] { 3799912185593854L, 63L, 2309621682768192918L, 31L };
/*     */ 
/*     */   
/* 153 */   static final long[] jjbitVec17 = new long[] { 0L, 4398046510847L, 0L, 0L };
/*     */ 
/*     */   
/* 156 */   static final long[] jjbitVec18 = new long[] { 0L, 0L, -4294967296L, 36028797018898495L };
/*     */ 
/*     */   
/* 159 */   static final long[] jjbitVec19 = new long[] { 5764607523034749677L, 12493387738468353L, -756383734487318528L, 144405459145588743L };
/*     */ 
/*     */   
/* 162 */   static final long[] jjbitVec20 = new long[] { -1L, -1L, -4026531841L, 288230376151711743L };
/*     */ 
/*     */   
/* 165 */   static final long[] jjbitVec21 = new long[] { -3233808385L, 4611686017001275199L, 6908521828386340863L, 2295745090394464220L };
/*     */ 
/*     */   
/* 168 */   static final long[] jjbitVec22 = new long[] { 83837761617920L, 0L, 7L, 0L };
/*     */ 
/*     */   
/* 171 */   static final long[] jjbitVec23 = new long[] { 4389456576640L, -2L, -8587837441L, 576460752303423487L };
/*     */ 
/*     */   
/* 174 */   static final long[] jjbitVec24 = new long[] { 35184372088800L, 0L, 0L, 0L };
/*     */ 
/*     */   
/* 177 */   static final long[] jjbitVec25 = new long[] { -1L, -1L, 274877906943L, 0L };
/*     */ 
/*     */   
/* 180 */   static final long[] jjbitVec26 = new long[] { -1L, -1L, 68719476735L, 0L };
/*     */ 
/*     */   
/* 183 */   static final long[] jjbitVec27 = new long[] { 0L, 0L, 36028797018963968L, -36028797027352577L };
/*     */ 
/*     */   
/* 186 */   static final long[] jjbitVec28 = new long[] { 16777215L, -65536L, -576458553280167937L, 196611L };
/*     */ 
/*     */   
/* 189 */   static final long[] jjbitVec29 = new long[] { -1L, 12884901951L, -17179879488L, 4503588160110591L };
/*     */ 
/*     */   
/* 192 */   static final long[] jjbitVec30 = new long[] { -8194L, -536936449L, -65413L, 234134404065073567L };
/*     */ 
/*     */   
/* 195 */   static final long[] jjbitVec31 = new long[] { -562949953421312L, -8547991553L, -4899916411759099777L, 1979120929931286L };
/*     */ 
/*     */   
/* 198 */   static final long[] jjbitVec32 = new long[] { 576460743713488896L, -277081224642561L, 9007199254740991999L, 288017070894841855L };
/*     */ 
/*     */   
/* 201 */   static final long[] jjbitVec33 = new long[] { -864691128455135250L, 281268803485695L, -3186861885341720594L, 1125692414638495L };
/*     */ 
/*     */   
/* 204 */   static final long[] jjbitVec34 = new long[] { -3211631683292264476L, 9006925953907079L, -869759877059465234L, 281204393786303L };
/*     */ 
/*     */   
/* 207 */   static final long[] jjbitVec35 = new long[] { -878767076314341394L, 281215949093263L, -4341532606274353172L, 280925229301191L };
/*     */ 
/*     */   
/* 210 */   static final long[] jjbitVec36 = new long[] { -4327961440926441490L, 281212990012895L, -4327961440926441492L, 281214063754719L };
/*     */ 
/*     */   
/* 213 */   static final long[] jjbitVec37 = new long[] { -4323457841299070996L, 281212992110031L, 0L, 0L };
/*     */ 
/*     */   
/* 216 */   static final long[] jjbitVec38 = new long[] { 576320014815068158L, 67076095L, 4323293666156225942L, 67059551L };
/*     */ 
/*     */   
/* 219 */   static final long[] jjbitVec39 = new long[] { -4422530440275951616L, -558551906910465L, 215680200883507167L, 0L };
/*     */ 
/*     */   
/* 222 */   static final long[] jjbitVec40 = new long[] { 0L, 0L, 0L, 9126739968L };
/*     */ 
/*     */   
/* 225 */   static final long[] jjbitVec41 = new long[] { 17732914942836896L, -2L, -6876561409L, 8646911284551352319L };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int jjMoveNfa_0(int startState, int curPos) {
/* 231 */     int startsAt = 0;
/* 232 */     this.jjnewStateCnt = 19;
/* 233 */     int i = 1;
/* 234 */     this.jjstateSet[0] = startState;
/* 235 */     int kind = Integer.MAX_VALUE;
/*     */     
/*     */     while (true) {
/* 238 */       if (++this.jjround == Integer.MAX_VALUE)
/* 239 */         ReInitRounds(); 
/* 240 */       if (this.curChar < '@') {
/*     */         
/* 242 */         long l = 1L << this.curChar;
/*     */         
/*     */         do {
/* 245 */           switch (this.jjstateSet[--i]) {
/*     */             
/*     */             case 0:
/* 248 */               if (this.curChar == '\'') {
/* 249 */                 jjCheckNAddStates(0, 2); break;
/* 250 */               }  if (this.curChar == '"')
/* 251 */                 jjCheckNAddStates(3, 5); 
/*     */               break;
/*     */             case 1:
/* 254 */               if ((0xFFFFFFFBFFFFFFFFL & l) != 0L)
/* 255 */                 jjCheckNAddStates(3, 5); 
/*     */               break;
/*     */             case 3:
/* 258 */               if (this.curChar == '"')
/* 259 */                 jjCheckNAddStates(3, 5); 
/*     */               break;
/*     */             case 4:
/* 262 */               if (this.curChar == '"' && kind > 1)
/* 263 */                 kind = 1; 
/*     */               break;
/*     */             case 5:
/*     */             case 8:
/* 267 */               if (this.curChar == '\'')
/* 268 */                 jjCheckNAddStates(0, 2); 
/*     */               break;
/*     */             case 6:
/* 271 */               if ((0xFFFFFF7FFFFFFFFFL & l) != 0L)
/* 272 */                 jjCheckNAddStates(0, 2); 
/*     */               break;
/*     */             case 9:
/* 275 */               if (this.curChar == '\'' && kind > 1)
/* 276 */                 kind = 1; 
/*     */               break;
/*     */             case 11:
/* 279 */               if ((0x3FF600000000000L & l) != 0L)
/* 280 */                 jjAddStates(6, 7); 
/*     */               break;
/*     */             case 12:
/* 283 */               if (this.curChar == ':')
/* 284 */                 this.jjstateSet[this.jjnewStateCnt++] = 13; 
/*     */               break;
/*     */             case 14:
/* 287 */               if ((0x3FF600000000000L & l) == 0L)
/*     */                 break; 
/* 289 */               if (kind > 2)
/* 290 */                 kind = 2; 
/* 291 */               this.jjstateSet[this.jjnewStateCnt++] = 14;
/*     */               break;
/*     */             case 15:
/* 294 */               if ((0x3FF600000000000L & l) == 0L)
/*     */                 break; 
/* 296 */               if (kind > 3)
/* 297 */                 kind = 3; 
/* 298 */               this.jjstateSet[this.jjnewStateCnt++] = 15;
/*     */               break;
/*     */             case 16:
/* 301 */               if ((0x3FF600000000000L & l) != 0L)
/* 302 */                 jjAddStates(8, 9); 
/*     */               break;
/*     */             case 17:
/* 305 */               if (this.curChar == ':')
/* 306 */                 this.jjstateSet[this.jjnewStateCnt++] = 18; 
/*     */               break;
/*     */             case 18:
/* 309 */               if (this.curChar == '*' && kind > 4) {
/* 310 */                 kind = 4;
/*     */               }
/*     */               break;
/*     */           } 
/* 314 */         } while (i != startsAt);
/*     */       }
/* 316 */       else if (this.curChar < '') {
/*     */         
/* 318 */         long l = 1L << (this.curChar & 0x3F);
/*     */         
/*     */         do {
/* 321 */           switch (this.jjstateSet[--i]) {
/*     */             
/*     */             case 0:
/* 324 */               if ((0x7FFFFFE87FFFFFEL & l) == 0L)
/*     */                 break; 
/* 326 */               if (kind > 2)
/* 327 */                 kind = 2; 
/* 328 */               jjCheckNAddStates(10, 15);
/*     */               break;
/*     */             case 1:
/* 331 */               if ((0xFFFFFFFFEFFFFFFFL & l) != 0L)
/* 332 */                 jjCheckNAddStates(3, 5); 
/*     */               break;
/*     */             case 2:
/* 335 */               if (this.curChar == '\\')
/* 336 */                 this.jjstateSet[this.jjnewStateCnt++] = 3; 
/*     */               break;
/*     */             case 3:
/* 339 */               if (this.curChar == '\\')
/* 340 */                 jjCheckNAddStates(3, 5); 
/*     */               break;
/*     */             case 6:
/* 343 */               if ((0xFFFFFFFFEFFFFFFFL & l) != 0L)
/* 344 */                 jjCheckNAddStates(0, 2); 
/*     */               break;
/*     */             case 7:
/* 347 */               if (this.curChar == '\\')
/* 348 */                 this.jjstateSet[this.jjnewStateCnt++] = 8; 
/*     */               break;
/*     */             case 8:
/* 351 */               if (this.curChar == '\\')
/* 352 */                 jjCheckNAddStates(0, 2); 
/*     */               break;
/*     */             case 11:
/* 355 */               if ((0x7FFFFFE87FFFFFEL & l) != 0L)
/* 356 */                 jjCheckNAddTwoStates(11, 12); 
/*     */               break;
/*     */             case 13:
/*     */             case 14:
/* 360 */               if ((0x7FFFFFE87FFFFFEL & l) == 0L)
/*     */                 break; 
/* 362 */               if (kind > 2)
/* 363 */                 kind = 2; 
/* 364 */               jjCheckNAdd(14);
/*     */               break;
/*     */             case 15:
/* 367 */               if ((0x7FFFFFE87FFFFFEL & l) == 0L)
/*     */                 break; 
/* 369 */               if (kind > 3)
/* 370 */                 kind = 3; 
/* 371 */               jjCheckNAdd(15);
/*     */               break;
/*     */             case 16:
/* 374 */               if ((0x7FFFFFE87FFFFFEL & l) != 0L) {
/* 375 */                 jjCheckNAddTwoStates(16, 17);
/*     */               }
/*     */               break;
/*     */           } 
/* 379 */         } while (i != startsAt);
/*     */       }
/*     */       else {
/*     */         
/* 383 */         int hiByte = this.curChar >> 8;
/* 384 */         int i1 = hiByte >> 6;
/* 385 */         long l1 = 1L << (hiByte & 0x3F);
/* 386 */         int i2 = (this.curChar & 0xFF) >> 6;
/* 387 */         long l2 = 1L << (this.curChar & 0x3F);
/*     */         
/*     */         do {
/* 390 */           switch (this.jjstateSet[--i]) {
/*     */             
/*     */             case 0:
/* 393 */               if (!jjCanMove_1(hiByte, i1, i2, l1, l2))
/*     */                 break; 
/* 395 */               if (kind > 2)
/* 396 */                 kind = 2; 
/* 397 */               jjCheckNAddStates(10, 15);
/*     */               break;
/*     */             case 1:
/* 400 */               if (jjCanMove_0(hiByte, i1, i2, l1, l2))
/* 401 */                 jjAddStates(3, 5); 
/*     */               break;
/*     */             case 6:
/* 404 */               if (jjCanMove_0(hiByte, i1, i2, l1, l2))
/* 405 */                 jjAddStates(0, 2); 
/*     */               break;
/*     */             case 11:
/* 408 */               if (jjCanMove_2(hiByte, i1, i2, l1, l2))
/* 409 */                 jjCheckNAddTwoStates(11, 12); 
/*     */               break;
/*     */             case 13:
/* 412 */               if (!jjCanMove_1(hiByte, i1, i2, l1, l2))
/*     */                 break; 
/* 414 */               if (kind > 2)
/* 415 */                 kind = 2; 
/* 416 */               jjCheckNAdd(14);
/*     */               break;
/*     */             case 14:
/* 419 */               if (!jjCanMove_2(hiByte, i1, i2, l1, l2))
/*     */                 break; 
/* 421 */               if (kind > 2)
/* 422 */                 kind = 2; 
/* 423 */               jjCheckNAdd(14);
/*     */               break;
/*     */             case 15:
/* 426 */               if (!jjCanMove_2(hiByte, i1, i2, l1, l2))
/*     */                 break; 
/* 428 */               if (kind > 3)
/* 429 */                 kind = 3; 
/* 430 */               jjCheckNAdd(15);
/*     */               break;
/*     */             case 16:
/* 433 */               if (jjCanMove_2(hiByte, i1, i2, l1, l2)) {
/* 434 */                 jjCheckNAddTwoStates(16, 17);
/*     */               }
/*     */               break;
/*     */           } 
/* 438 */         } while (i != startsAt);
/*     */       } 
/* 440 */       if (kind != Integer.MAX_VALUE) {
/*     */         
/* 442 */         this.jjmatchedKind = kind;
/* 443 */         this.jjmatchedPos = curPos;
/* 444 */         kind = Integer.MAX_VALUE;
/*     */       } 
/* 446 */       curPos++;
/* 447 */       if ((i = this.jjnewStateCnt) == (startsAt = 19 - (this.jjnewStateCnt = startsAt)))
/* 448 */         return curPos;  
/* 449 */       try { this.curChar = this.input_stream.readChar(); }
/* 450 */       catch (IOException e) { return curPos; }
/*     */     
/*     */     } 
/* 453 */   } static final int[] jjnextStates = new int[] { 6, 7, 9, 1, 2, 4, 11, 12, 16, 17, 11, 12, 14, 15, 16, 17 };
/*     */ 
/*     */ 
/*     */   
/*     */   private static final boolean jjCanMove_0(int hiByte, int i1, int i2, long l1, long l2) {
/* 458 */     switch (hiByte) {
/*     */       
/*     */       case 0:
/* 461 */         return ((jjbitVec2[i2] & l2) != 0L);
/*     */     } 
/* 463 */     if ((jjbitVec0[i1] & l1) != 0L)
/* 464 */       return true; 
/* 465 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private static final boolean jjCanMove_1(int hiByte, int i1, int i2, long l1, long l2) {
/* 470 */     switch (hiByte) {
/*     */       
/*     */       case 0:
/* 473 */         return ((jjbitVec4[i2] & l2) != 0L);
/*     */       case 1:
/* 475 */         return ((jjbitVec5[i2] & l2) != 0L);
/*     */       case 2:
/* 477 */         return ((jjbitVec6[i2] & l2) != 0L);
/*     */       case 3:
/* 479 */         return ((jjbitVec7[i2] & l2) != 0L);
/*     */       case 4:
/* 481 */         return ((jjbitVec8[i2] & l2) != 0L);
/*     */       case 5:
/* 483 */         return ((jjbitVec9[i2] & l2) != 0L);
/*     */       case 6:
/* 485 */         return ((jjbitVec10[i2] & l2) != 0L);
/*     */       case 9:
/* 487 */         return ((jjbitVec11[i2] & l2) != 0L);
/*     */       case 10:
/* 489 */         return ((jjbitVec12[i2] & l2) != 0L);
/*     */       case 11:
/* 491 */         return ((jjbitVec13[i2] & l2) != 0L);
/*     */       case 12:
/* 493 */         return ((jjbitVec14[i2] & l2) != 0L);
/*     */       case 13:
/* 495 */         return ((jjbitVec15[i2] & l2) != 0L);
/*     */       case 14:
/* 497 */         return ((jjbitVec16[i2] & l2) != 0L);
/*     */       case 15:
/* 499 */         return ((jjbitVec17[i2] & l2) != 0L);
/*     */       case 16:
/* 501 */         return ((jjbitVec18[i2] & l2) != 0L);
/*     */       case 17:
/* 503 */         return ((jjbitVec19[i2] & l2) != 0L);
/*     */       case 30:
/* 505 */         return ((jjbitVec20[i2] & l2) != 0L);
/*     */       case 31:
/* 507 */         return ((jjbitVec21[i2] & l2) != 0L);
/*     */       case 33:
/* 509 */         return ((jjbitVec22[i2] & l2) != 0L);
/*     */       case 48:
/* 511 */         return ((jjbitVec23[i2] & l2) != 0L);
/*     */       case 49:
/* 513 */         return ((jjbitVec24[i2] & l2) != 0L);
/*     */       case 159:
/* 515 */         return ((jjbitVec25[i2] & l2) != 0L);
/*     */       case 215:
/* 517 */         return ((jjbitVec26[i2] & l2) != 0L);
/*     */     } 
/* 519 */     if ((jjbitVec3[i1] & l1) != 0L)
/* 520 */       return true; 
/* 521 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private static final boolean jjCanMove_2(int hiByte, int i1, int i2, long l1, long l2) {
/* 526 */     switch (hiByte) {
/*     */       
/*     */       case 0:
/* 529 */         return ((jjbitVec27[i2] & l2) != 0L);
/*     */       case 1:
/* 531 */         return ((jjbitVec5[i2] & l2) != 0L);
/*     */       case 2:
/* 533 */         return ((jjbitVec28[i2] & l2) != 0L);
/*     */       case 3:
/* 535 */         return ((jjbitVec29[i2] & l2) != 0L);
/*     */       case 4:
/* 537 */         return ((jjbitVec30[i2] & l2) != 0L);
/*     */       case 5:
/* 539 */         return ((jjbitVec31[i2] & l2) != 0L);
/*     */       case 6:
/* 541 */         return ((jjbitVec32[i2] & l2) != 0L);
/*     */       case 9:
/* 543 */         return ((jjbitVec33[i2] & l2) != 0L);
/*     */       case 10:
/* 545 */         return ((jjbitVec34[i2] & l2) != 0L);
/*     */       case 11:
/* 547 */         return ((jjbitVec35[i2] & l2) != 0L);
/*     */       case 12:
/* 549 */         return ((jjbitVec36[i2] & l2) != 0L);
/*     */       case 13:
/* 551 */         return ((jjbitVec37[i2] & l2) != 0L);
/*     */       case 14:
/* 553 */         return ((jjbitVec38[i2] & l2) != 0L);
/*     */       case 15:
/* 555 */         return ((jjbitVec39[i2] & l2) != 0L);
/*     */       case 16:
/* 557 */         return ((jjbitVec18[i2] & l2) != 0L);
/*     */       case 17:
/* 559 */         return ((jjbitVec19[i2] & l2) != 0L);
/*     */       case 30:
/* 561 */         return ((jjbitVec20[i2] & l2) != 0L);
/*     */       case 31:
/* 563 */         return ((jjbitVec21[i2] & l2) != 0L);
/*     */       case 32:
/* 565 */         return ((jjbitVec40[i2] & l2) != 0L);
/*     */       case 33:
/* 567 */         return ((jjbitVec22[i2] & l2) != 0L);
/*     */       case 48:
/* 569 */         return ((jjbitVec41[i2] & l2) != 0L);
/*     */       case 49:
/* 571 */         return ((jjbitVec24[i2] & l2) != 0L);
/*     */       case 159:
/* 573 */         return ((jjbitVec25[i2] & l2) != 0L);
/*     */       case 215:
/* 575 */         return ((jjbitVec26[i2] & l2) != 0L);
/*     */     } 
/* 577 */     if ((jjbitVec3[i1] & l1) != 0L)
/* 578 */       return true; 
/* 579 */     return false;
/*     */   }
/*     */   
/* 582 */   public static final String[] jjstrLiteralImages = new String[] { "", null, null, null, null, null, null, null, null, null, null, null, null, "/", "*", ":", "[", "]", "@", "=" };
/*     */ 
/*     */   
/* 585 */   public static final String[] lexStateNames = new String[] { "DEFAULT" };
/*     */   
/*     */   private ASCII_UCodeESC_CharStream input_stream;
/*     */   
/* 589 */   private final int[] jjrounds = new int[19];
/* 590 */   private final int[] jjstateSet = new int[38];
/*     */   protected char curChar;
/*     */   int curLexState;
/*     */   int defaultLexState;
/*     */   int jjnewStateCnt;
/*     */   int jjround;
/*     */   int jjmatchedPos;
/*     */   int jjmatchedKind;
/*     */   
/*     */   public SPathParserTokenManager(ASCII_UCodeESC_CharStream stream, int lexState) {
/* 600 */     this(stream);
/* 601 */     SwitchTo(lexState);
/*     */   }
/*     */   
/*     */   public void ReInit(ASCII_UCodeESC_CharStream stream) {
/* 605 */     this.jjmatchedPos = this.jjnewStateCnt = 0;
/* 606 */     this.curLexState = this.defaultLexState;
/* 607 */     this.input_stream = stream;
/* 608 */     ReInitRounds();
/*     */   }
/*     */ 
/*     */   
/*     */   private final void ReInitRounds() {
/* 613 */     this.jjround = -2147483647;
/* 614 */     for (int i = 19; i-- > 0;)
/* 615 */       this.jjrounds[i] = Integer.MIN_VALUE; 
/*     */   }
/*     */   
/*     */   public void ReInit(ASCII_UCodeESC_CharStream stream, int lexState) {
/* 619 */     ReInit(stream);
/* 620 */     SwitchTo(lexState);
/*     */   }
/*     */   
/*     */   public void SwitchTo(int lexState) {
/* 624 */     if (lexState >= 1 || lexState < 0) {
/* 625 */       throw new TokenMgrError("Error: Ignoring invalid lexical state : " + lexState + ". State unchanged.", 2);
/*     */     }
/* 627 */     this.curLexState = lexState;
/*     */   }
/*     */ 
/*     */   
/*     */   private final Token jjFillToken() {
/* 632 */     Token t = Token.newToken(this.jjmatchedKind);
/* 633 */     t.kind = this.jjmatchedKind;
/* 634 */     String im = jjstrLiteralImages[this.jjmatchedKind];
/* 635 */     t.image = (im == null) ? this.input_stream.GetImage() : im;
/* 636 */     t.beginLine = this.input_stream.getBeginLine();
/* 637 */     t.beginColumn = this.input_stream.getBeginColumn();
/* 638 */     t.endLine = this.input_stream.getEndLine();
/* 639 */     t.endColumn = this.input_stream.getEndColumn();
/* 640 */     return t;
/*     */   }
/*     */   public SPathParserTokenManager(ASCII_UCodeESC_CharStream stream) {
/* 643 */     this.curLexState = 0;
/* 644 */     this.defaultLexState = 0;
/*     */     this.input_stream = stream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Token getNextToken() {
/* 653 */     Token specialToken = null;
/*     */     
/* 655 */     int curPos = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 662 */       this.curChar = this.input_stream.BeginToken();
/*     */     }
/* 664 */     catch (IOException e) {
/*     */       
/* 666 */       this.jjmatchedKind = 0;
/* 667 */       Token matchedToken = jjFillToken();
/* 668 */       return matchedToken;
/*     */     } 
/*     */     
/* 671 */     this.jjmatchedKind = Integer.MAX_VALUE;
/* 672 */     this.jjmatchedPos = 0;
/* 673 */     curPos = jjMoveStringLiteralDfa0_0();
/* 674 */     if (this.jjmatchedKind != Integer.MAX_VALUE) {
/*     */       
/* 676 */       if (this.jjmatchedPos + 1 < curPos)
/* 677 */         this.input_stream.backup(curPos - this.jjmatchedPos - 1); 
/* 678 */       Token matchedToken = jjFillToken();
/* 679 */       return matchedToken;
/*     */     } 
/* 681 */     int error_line = this.input_stream.getEndLine();
/* 682 */     int error_column = this.input_stream.getEndColumn();
/* 683 */     String error_after = null;
/* 684 */     boolean EOFSeen = false; try {
/* 685 */       this.input_stream.readChar(); this.input_stream.backup(1);
/* 686 */     } catch (IOException e1) {
/* 687 */       EOFSeen = true;
/* 688 */       error_after = (curPos <= 1) ? "" : this.input_stream.GetImage();
/* 689 */       if (this.curChar == '\n' || this.curChar == '\r') {
/* 690 */         error_line++;
/* 691 */         error_column = 0;
/*     */       } else {
/*     */         
/* 694 */         error_column++;
/*     */       } 
/* 696 */     }  if (!EOFSeen) {
/* 697 */       this.input_stream.backup(1);
/* 698 */       error_after = (curPos <= 1) ? "" : this.input_stream.GetImage();
/*     */     } 
/* 700 */     throw new TokenMgrError(EOFSeen, this.curLexState, error_line, error_column, error_after, this.curChar, 0);
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\extra\spath\SPathParserTokenManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */