/*     */ package org.apache.taglibs.standard.extra.spath;
/*     */ 
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Step
/*     */ {
/*     */   private boolean depthUnlimited;
/*     */   private String name;
/*     */   private List predicates;
/*     */   private String uri;
/*     */   private String localPart;
/*     */   
/*     */   public Step(boolean depthUnlimited, String name, List predicates) {
/*  53 */     if (name == null)
/*  54 */       throw new IllegalArgumentException("non-null name required"); 
/*  55 */     this.depthUnlimited = depthUnlimited;
/*  56 */     this.name = name;
/*  57 */     this.predicates = predicates;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isMatchingName(String uri, String localPart) {
/*  67 */     if (localPart == null)
/*  68 */       throw new IllegalArgumentException("need non-null localPart"); 
/*  69 */     if (uri != null && uri.equals("")) {
/*  70 */       uri = null;
/*     */     }
/*     */     
/*  73 */     if (this.localPart == null && this.uri == null) {
/*  74 */       parseStepName();
/*     */     }
/*     */     
/*  77 */     if (this.uri == null && this.localPart.equals("*")) {
/*  78 */       return true;
/*     */     }
/*     */     
/*  81 */     if (uri == null && this.uri == null && localPart.equals(this.localPart))
/*     */     {
/*  83 */       return true;
/*     */     }
/*  85 */     if (uri != null && this.uri != null && uri.equals(this.uri)) {
/*     */       
/*  87 */       if (localPart.equals(this.localPart)) {
/*  88 */         return true;
/*     */       }
/*     */       
/*  91 */       if (this.localPart.equals("*")) {
/*  92 */         return true;
/*     */       }
/*     */     } 
/*     */     
/*  96 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDepthUnlimited() {
/* 101 */     return this.depthUnlimited;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/* 106 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   public List getPredicates() {
/* 111 */     return this.predicates;
/*     */   }
/*     */ 
/*     */   
/*     */   private void parseStepName() {
/*     */     String prefix;
/* 117 */     int colonIndex = this.name.indexOf(":");
/*     */     
/* 119 */     if (colonIndex == -1) {
/*     */       
/* 121 */       prefix = null;
/* 122 */       this.localPart = this.name;
/*     */     } else {
/* 124 */       prefix = this.name.substring(0, colonIndex);
/* 125 */       this.localPart = this.name.substring(colonIndex + 1);
/*     */     } 
/*     */     
/* 128 */     this.uri = mapPrefix(prefix);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private String mapPrefix(String prefix) {
/* 134 */     if (prefix == null) {
/* 135 */       return null;
/*     */     }
/* 137 */     throw new IllegalArgumentException("unknown prefix '" + prefix + "'");
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\extra\spath\Step.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */