/*    */ package org.apache.taglibs.standard.extra.spath;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface SPathParserConstants
/*    */ {
/*    */   public static final int EOF = 0;
/*    */   public static final int LITERAL = 1;
/*    */   public static final int QNAME = 2;
/*    */   public static final int NCNAME = 3;
/*    */   public static final int NSWILDCARD = 4;
/*    */   public static final int NCNAMECHAR = 5;
/*    */   public static final int LETTER = 6;
/*    */   public static final int DIGIT = 7;
/*    */   public static final int COMBINING_CHAR = 8;
/*    */   public static final int EXTENDER = 9;
/*    */   public static final int UNDERSCORE = 10;
/*    */   public static final int DOT = 11;
/*    */   public static final int DASH = 12;
/*    */   public static final int SLASH = 13;
/*    */   public static final int STAR = 14;
/*    */   public static final int COLON = 15;
/*    */   public static final int START_BRACKET = 16;
/*    */   public static final int END_BRACKET = 17;
/*    */   public static final int AT = 18;
/*    */   public static final int EQUALS = 19;
/*    */   public static final int DEFAULT = 0;
/* 50 */   public static final String[] tokenImage = new String[] { "<EOF>", "<LITERAL>", "<QNAME>", "<NCNAME>", "<NSWILDCARD>", "<NCNAMECHAR>", "<LETTER>", "<DIGIT>", "<COMBINING_CHAR>", "<EXTENDER>", "\"_\"", "\".\"", "\"-\"", "\"/\"", "\"*\"", "\":\"", "\"[\"", "\"]\"", "\"@\"", "\"=\"" };
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\extra\spath\SPathParserConstants.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */