/*    */ package org.apache.taglibs.standard.extra.spath;
/*    */ 
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AttributePredicate
/*    */   extends Predicate
/*    */ {
/*    */   private String attribute;
/*    */   private String target;
/*    */   
/*    */   public AttributePredicate(String attribute, String target) {
/* 43 */     if (attribute == null)
/* 44 */       throw new IllegalArgumentException("non-null attribute needed"); 
/* 45 */     if (attribute.indexOf(":") != -1) {
/* 46 */       throw new IllegalArgumentException("namespace-qualified attribute names are not currently supported");
/*    */     }
/*    */     
/* 49 */     this.attribute = attribute;
/*    */     
/* 51 */     if (target == null) {
/* 52 */       throw new IllegalArgumentException("non-null target needed");
/*    */     }
/* 54 */     this.target = target.substring(1, target.length() - 1);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isMatchingAttribute(Attributes a) {
/* 62 */     String attValue = a.getValue("", this.attribute);
/* 63 */     return (attValue != null && attValue.equals(this.target));
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\extra\spath\AttributePredicate.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */