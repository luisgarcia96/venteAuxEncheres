/*     */ package org.apache.taglibs.standard.tlv;
/*     */ 
/*     */ import java.util.Set;
/*     */ import java.util.Stack;
/*     */ import javax.servlet.jsp.tagext.PageData;
/*     */ import javax.servlet.jsp.tagext.ValidationMessage;
/*     */ import org.apache.taglibs.standard.resources.Resources;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JstlXmlTLV
/*     */   extends JstlBaseTLV
/*     */ {
/*  83 */   private final String CHOOSE = "choose";
/*  84 */   private final String WHEN = "when";
/*  85 */   private final String OTHERWISE = "otherwise";
/*  86 */   private final String PARSE = "parse";
/*  87 */   private final String PARAM = "param";
/*  88 */   private final String TRANSFORM = "transform";
/*  89 */   private final String JSP_TEXT = "jsp:text";
/*     */ 
/*     */   
/*  92 */   private final String VALUE = "value";
/*  93 */   private final String SOURCE = "xml";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValidationMessage[] validate(String prefix, String uri, PageData page) {
/* 100 */     return validate(4, prefix, uri, page);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DefaultHandler getHandler() {
/* 108 */     return new Handler();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class Handler
/*     */     extends DefaultHandler
/*     */   {
/* 119 */     private int depth = 0;
/* 120 */     private Stack chooseDepths = new Stack();
/* 121 */     private Stack chooseHasOtherwise = new Stack();
/* 122 */     private Stack chooseHasWhen = new Stack();
/* 123 */     private String lastElementName = null;
/*     */     private boolean bodyNecessary = false;
/*     */     private boolean bodyIllegal = false;
/* 126 */     private Stack transformWithSource = new Stack();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void startElement(String ns, String ln, String qn, Attributes a) {
/* 133 */       if (ln == null) {
/* 134 */         ln = JstlXmlTLV.this.getLocalPart(qn);
/*     */       }
/*     */ 
/*     */       
/* 138 */       if (qn.equals("jsp:text")) {
/*     */         return;
/*     */       }
/*     */       
/* 142 */       if (this.bodyIllegal) {
/* 143 */         JstlXmlTLV.this.fail(Resources.getMessage("TLV_ILLEGAL_BODY", this.lastElementName));
/*     */       }
/*     */       
/*     */       Set expAtts;
/* 147 */       if (qn.startsWith(JstlXmlTLV.this.prefix + ":") && (expAtts = (Set)JstlXmlTLV.this.config.get(ln)) != null)
/*     */       {
/* 149 */         for (int i = 0; i < a.getLength(); i++) {
/* 150 */           String attName = a.getLocalName(i);
/* 151 */           if (expAtts.contains(attName)) {
/* 152 */             String vMsg = JstlXmlTLV.this.validateExpression(ln, attName, a.getValue(i));
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 157 */             if (vMsg != null) {
/* 158 */               JstlXmlTLV.this.fail(vMsg);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       }
/*     */       
/* 164 */       if (qn.startsWith(JstlXmlTLV.this.prefix + ":") && !JstlXmlTLV.this.hasNoInvalidScope(a)) {
/* 165 */         JstlXmlTLV.this.fail(Resources.getMessage("TLV_INVALID_ATTRIBUTE", "scope", qn, a.getValue("scope")));
/*     */       }
/* 167 */       if (qn.startsWith(JstlXmlTLV.this.prefix + ":") && JstlXmlTLV.this.hasEmptyVar(a))
/* 168 */         JstlXmlTLV.this.fail(Resources.getMessage("TLV_EMPTY_VAR", qn)); 
/* 169 */       if (qn.startsWith(JstlXmlTLV.this.prefix + ":") && JstlXmlTLV.this.hasDanglingScope(a)) {
/* 170 */         JstlXmlTLV.this.fail(Resources.getMessage("TLV_DANGLING_SCOPE", qn));
/*     */       }
/*     */       
/* 173 */       if (chooseChild()) {
/*     */         
/* 175 */         if (JstlXmlTLV.this.isXmlTag(ns, ln, "when")) {
/* 176 */           this.chooseHasWhen.pop();
/* 177 */           this.chooseHasWhen.push(Boolean.TRUE);
/*     */         } 
/*     */ 
/*     */         
/* 181 */         if (!JstlXmlTLV.this.isXmlTag(ns, ln, "when") && !JstlXmlTLV.this.isXmlTag(ns, ln, "otherwise")) {
/* 182 */           JstlXmlTLV.this.fail(Resources.getMessage("TLV_ILLEGAL_CHILD_TAG", JstlXmlTLV.this.prefix, "choose", qn));
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 187 */         if (((Boolean)this.chooseHasOtherwise.peek()).booleanValue()) {
/* 188 */           JstlXmlTLV.this.fail(Resources.getMessage("TLV_ILLEGAL_ORDER", qn, JstlXmlTLV.this.prefix, "otherwise", "choose"));
/*     */         }
/*     */         
/* 191 */         if (JstlXmlTLV.this.isXmlTag(ns, ln, "otherwise")) {
/* 192 */           this.chooseHasOtherwise.pop();
/* 193 */           this.chooseHasOtherwise.push(Boolean.TRUE);
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 199 */       if (!this.transformWithSource.empty() && topDepth(this.transformWithSource) == this.depth - 1)
/*     */       {
/*     */         
/* 202 */         if (!JstlXmlTLV.this.isXmlTag(ns, ln, "param")) {
/* 203 */           JstlXmlTLV.this.fail(Resources.getMessage("TLV_ILLEGAL_BODY", JstlXmlTLV.this.prefix + ":" + "transform"));
/*     */         }
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 213 */       if (JstlXmlTLV.this.isXmlTag(ns, ln, "choose")) {
/* 214 */         this.chooseDepths.push(new Integer(this.depth));
/* 215 */         this.chooseHasWhen.push(Boolean.FALSE);
/* 216 */         this.chooseHasOtherwise.push(Boolean.FALSE);
/*     */       } 
/*     */ 
/*     */       
/* 220 */       this.bodyIllegal = false;
/* 221 */       this.bodyNecessary = false;
/* 222 */       if (JstlXmlTLV.this.isXmlTag(ns, ln, "parse")) {
/* 223 */         if (JstlXmlTLV.this.hasAttribute(a, "xml"))
/* 224 */           this.bodyIllegal = true; 
/* 225 */       } else if (JstlXmlTLV.this.isXmlTag(ns, ln, "param")) {
/* 226 */         if (JstlXmlTLV.this.hasAttribute(a, "value"))
/* 227 */         { this.bodyIllegal = true; }
/*     */         else
/* 229 */         { this.bodyNecessary = true; } 
/* 230 */       } else if (JstlXmlTLV.this.isXmlTag(ns, ln, "transform") && 
/* 231 */         JstlXmlTLV.this.hasAttribute(a, "xml")) {
/* 232 */         this.transformWithSource.push(new Integer(this.depth));
/*     */       } 
/*     */ 
/*     */       
/* 236 */       this.lastElementName = qn;
/* 237 */       JstlXmlTLV.this.lastElementId = a.getValue("http://java.sun.com/JSP/Page", "id");
/*     */ 
/*     */       
/* 240 */       this.depth++;
/*     */     }
/*     */ 
/*     */     
/*     */     public void characters(char[] ch, int start, int length) {
/* 245 */       this.bodyNecessary = false;
/*     */ 
/*     */       
/* 248 */       String s = (new String(ch, start, length)).trim();
/* 249 */       if (s.equals("")) {
/*     */         return;
/*     */       }
/*     */       
/* 253 */       if (this.bodyIllegal) {
/* 254 */         JstlXmlTLV.this.fail(Resources.getMessage("TLV_ILLEGAL_BODY", this.lastElementName));
/*     */       }
/*     */       
/* 257 */       if (chooseChild()) {
/* 258 */         String msg = Resources.getMessage("TLV_ILLEGAL_TEXT_BODY", JstlXmlTLV.this.prefix, "choose", (s.length() < 7) ? s : s.substring(0, 7));
/*     */ 
/*     */ 
/*     */         
/* 262 */         JstlXmlTLV.this.fail(msg);
/*     */       } 
/*     */ 
/*     */       
/* 266 */       if (!this.transformWithSource.empty() && topDepth(this.transformWithSource) == this.depth - 1)
/*     */       {
/* 268 */         JstlXmlTLV.this.fail(Resources.getMessage("TLV_ILLEGAL_BODY", JstlXmlTLV.this.prefix + ":" + "transform"));
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void endElement(String ns, String ln, String qn) {
/* 276 */       if (qn.equals("jsp:text")) {
/*     */         return;
/*     */       }
/*     */       
/* 280 */       if (this.bodyNecessary) {
/* 281 */         JstlXmlTLV.this.fail(Resources.getMessage("TLV_MISSING_BODY", this.lastElementName));
/*     */       }
/* 283 */       this.bodyIllegal = false;
/*     */ 
/*     */       
/* 286 */       if (JstlXmlTLV.this.isXmlTag(ns, ln, "choose")) {
/* 287 */         Boolean b = this.chooseHasWhen.pop();
/* 288 */         if (!b.booleanValue()) {
/* 289 */           JstlXmlTLV.this.fail(Resources.getMessage("TLV_PARENT_WITHOUT_SUBTAG", "choose", "when"));
/*     */         }
/* 291 */         this.chooseDepths.pop();
/* 292 */         this.chooseHasOtherwise.pop();
/*     */       } 
/*     */ 
/*     */       
/* 296 */       if (!this.transformWithSource.empty() && topDepth(this.transformWithSource) == this.depth - 1)
/*     */       {
/* 298 */         this.transformWithSource.pop();
/*     */       }
/*     */       
/* 301 */       this.depth--;
/*     */     }
/*     */ 
/*     */     
/*     */     private boolean chooseChild() {
/* 306 */       return (!this.chooseDepths.empty() && this.depth - 1 == ((Integer)this.chooseDepths.peek()).intValue());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private int topDepth(Stack<Integer> s) {
/* 312 */       return ((Integer)s.peek()).intValue();
/*     */     }
/*     */     
/*     */     private Handler() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tlv\JstlXmlTLV.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */