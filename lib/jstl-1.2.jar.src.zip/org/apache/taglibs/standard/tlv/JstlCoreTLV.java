/*     */ package org.apache.taglibs.standard.tlv;
/*     */ 
/*     */ import java.util.Set;
/*     */ import java.util.Stack;
/*     */ import javax.servlet.jsp.tagext.PageData;
/*     */ import javax.servlet.jsp.tagext.ValidationMessage;
/*     */ import org.apache.taglibs.standard.resources.Resources;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JstlCoreTLV
/*     */   extends JstlBaseTLV
/*     */ {
/*  79 */   private final String CHOOSE = "choose";
/*  80 */   private final String WHEN = "when";
/*  81 */   private final String OTHERWISE = "otherwise";
/*  82 */   private final String EXPR = "out";
/*  83 */   private final String SET = "set";
/*  84 */   private final String IMPORT = "import";
/*  85 */   private final String URL = "url";
/*  86 */   private final String REDIRECT = "redirect";
/*  87 */   private final String PARAM = "param";
/*     */   
/*  89 */   private final String TEXT = "text";
/*     */ 
/*     */   
/*  92 */   private final String VALUE = "value";
/*  93 */   private final String DEFAULT = "default";
/*  94 */   private final String VAR_READER = "varReader";
/*     */ 
/*     */   
/*  97 */   private final String IMPORT_WITH_READER = "import varReader=''";
/*  98 */   private final String IMPORT_WITHOUT_READER = "import var=''";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValidationMessage[] validate(String prefix, String uri, PageData page) {
/* 105 */     return validate(1, prefix, uri, page);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DefaultHandler getHandler() {
/* 113 */     return new Handler();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class Handler
/*     */     extends DefaultHandler
/*     */   {
/* 124 */     private int depth = 0;
/* 125 */     private Stack chooseDepths = new Stack();
/* 126 */     private Stack chooseHasOtherwise = new Stack();
/* 127 */     private Stack chooseHasWhen = new Stack();
/* 128 */     private Stack urlTags = new Stack();
/* 129 */     private String lastElementName = null;
/*     */ 
/*     */     
/*     */     private boolean bodyNecessary = false;
/*     */     
/*     */     private boolean bodyIllegal = false;
/*     */ 
/*     */     
/*     */     public void startElement(String ns, String ln, String qn, Attributes a) {
/* 138 */       if (ln == null) {
/* 139 */         ln = JstlCoreTLV.this.getLocalPart(qn);
/*     */       }
/*     */ 
/*     */       
/* 143 */       if (JstlCoreTLV.this.isJspTag(ns, ln, "text")) {
/*     */         return;
/*     */       }
/*     */       
/* 147 */       if (this.bodyIllegal) {
/* 148 */         JstlCoreTLV.this.fail(Resources.getMessage("TLV_ILLEGAL_BODY", this.lastElementName));
/*     */       }
/*     */       
/*     */       Set expAtts;
/* 152 */       if (qn.startsWith(JstlCoreTLV.this.prefix + ":") && (expAtts = (Set)JstlCoreTLV.this.config.get(ln)) != null)
/*     */       {
/* 154 */         for (int i = 0; i < a.getLength(); i++) {
/* 155 */           String attName = a.getLocalName(i);
/* 156 */           if (expAtts.contains(attName)) {
/* 157 */             String vMsg = JstlCoreTLV.this.validateExpression(ln, attName, a.getValue(i));
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 162 */             if (vMsg != null) {
/* 163 */               JstlCoreTLV.this.fail(vMsg);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       }
/*     */       
/* 169 */       if (qn.startsWith(JstlCoreTLV.this.prefix + ":") && !JstlCoreTLV.this.hasNoInvalidScope(a)) {
/* 170 */         JstlCoreTLV.this.fail(Resources.getMessage("TLV_INVALID_ATTRIBUTE", "scope", qn, a.getValue("scope")));
/*     */       }
/* 172 */       if (qn.startsWith(JstlCoreTLV.this.prefix + ":") && JstlCoreTLV.this.hasEmptyVar(a))
/* 173 */         JstlCoreTLV.this.fail(Resources.getMessage("TLV_EMPTY_VAR", qn)); 
/* 174 */       if (qn.startsWith(JstlCoreTLV.this.prefix + ":") && JstlCoreTLV.this.hasDanglingScope(a)) {
/* 175 */         JstlCoreTLV.this.fail(Resources.getMessage("TLV_DANGLING_SCOPE", qn));
/*     */       }
/*     */       
/* 178 */       if (chooseChild()) {
/*     */         
/* 180 */         if (JstlCoreTLV.this.isCoreTag(ns, ln, "when")) {
/* 181 */           this.chooseHasWhen.pop();
/* 182 */           this.chooseHasWhen.push(Boolean.TRUE);
/*     */         } 
/*     */ 
/*     */         
/* 186 */         if (!JstlCoreTLV.this.isCoreTag(ns, ln, "when") && !JstlCoreTLV.this.isCoreTag(ns, ln, "otherwise")) {
/* 187 */           JstlCoreTLV.this.fail(Resources.getMessage("TLV_ILLEGAL_CHILD_TAG", JstlCoreTLV.this.prefix, "choose", qn));
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 192 */         if (((Boolean)this.chooseHasOtherwise.peek()).booleanValue()) {
/* 193 */           JstlCoreTLV.this.fail(Resources.getMessage("TLV_ILLEGAL_ORDER", qn, JstlCoreTLV.this.prefix, "otherwise", "choose"));
/*     */         }
/*     */         
/* 196 */         if (JstlCoreTLV.this.isCoreTag(ns, ln, "otherwise")) {
/* 197 */           this.chooseHasOtherwise.pop();
/* 198 */           this.chooseHasOtherwise.push(Boolean.TRUE);
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 204 */       if (JstlCoreTLV.this.isCoreTag(ns, ln, "param")) {
/*     */         
/* 206 */         if (this.urlTags.empty() || this.urlTags.peek().equals("param")) {
/* 207 */           JstlCoreTLV.this.fail(Resources.getMessage("TLV_ILLEGAL_ORPHAN", "param"));
/*     */         }
/*     */         
/* 210 */         if (!this.urlTags.empty() && this.urlTags.peek().equals("import varReader=''"))
/*     */         {
/* 212 */           JstlCoreTLV.this.fail(Resources.getMessage("TLV_ILLEGAL_PARAM", JstlCoreTLV.this.prefix, "param", "import", "varReader"));
/*     */         
/*     */         }
/*     */       }
/* 216 */       else if (!this.urlTags.empty() && this.urlTags.peek().equals("import var=''")) {
/*     */         
/* 218 */         JstlCoreTLV.this.fail(Resources.getMessage("TLV_ILLEGAL_CHILD_TAG", JstlCoreTLV.this.prefix, "import", qn));
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 225 */       if (JstlCoreTLV.this.isCoreTag(ns, ln, "choose")) {
/* 226 */         this.chooseDepths.push(new Integer(this.depth));
/* 227 */         this.chooseHasWhen.push(Boolean.FALSE);
/* 228 */         this.chooseHasOtherwise.push(Boolean.FALSE);
/*     */       } 
/*     */ 
/*     */       
/* 232 */       if (JstlCoreTLV.this.isCoreTag(ns, ln, "import")) {
/* 233 */         if (JstlCoreTLV.this.hasAttribute(a, "varReader"))
/* 234 */         { this.urlTags.push("import varReader=''"); }
/*     */         else
/* 236 */         { this.urlTags.push("import var=''"); } 
/* 237 */       } else if (JstlCoreTLV.this.isCoreTag(ns, ln, "param")) {
/* 238 */         this.urlTags.push("param");
/* 239 */       } else if (JstlCoreTLV.this.isCoreTag(ns, ln, "redirect")) {
/* 240 */         this.urlTags.push("redirect");
/* 241 */       } else if (JstlCoreTLV.this.isCoreTag(ns, ln, "url")) {
/* 242 */         this.urlTags.push("url");
/*     */       } 
/*     */       
/* 245 */       this.bodyIllegal = false;
/* 246 */       this.bodyNecessary = false;
/* 247 */       if (JstlCoreTLV.this.isCoreTag(ns, ln, "out")) {
/* 248 */         if (JstlCoreTLV.this.hasAttribute(a, "default"))
/* 249 */           this.bodyIllegal = true; 
/* 250 */       } else if (JstlCoreTLV.this.isCoreTag(ns, ln, "set") && 
/* 251 */         JstlCoreTLV.this.hasAttribute(a, "value")) {
/* 252 */         this.bodyIllegal = true;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 258 */       this.lastElementName = qn;
/* 259 */       JstlCoreTLV.this.lastElementId = a.getValue("http://java.sun.com/JSP/Page", "id");
/*     */ 
/*     */       
/* 262 */       this.depth++;
/*     */     }
/*     */ 
/*     */     
/*     */     public void characters(char[] ch, int start, int length) {
/* 267 */       this.bodyNecessary = false;
/*     */ 
/*     */       
/* 270 */       String s = (new String(ch, start, length)).trim();
/* 271 */       if (s.equals("")) {
/*     */         return;
/*     */       }
/*     */       
/* 275 */       if (this.bodyIllegal)
/* 276 */         JstlCoreTLV.this.fail(Resources.getMessage("TLV_ILLEGAL_BODY", this.lastElementName)); 
/* 277 */       if (!this.urlTags.empty() && this.urlTags.peek().equals("import var=''"))
/*     */       {
/*     */ 
/*     */         
/* 281 */         JstlCoreTLV.this.fail(Resources.getMessage("TLV_ILLEGAL_BODY", JstlCoreTLV.this.prefix + ":" + "import"));
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 286 */       if (chooseChild()) {
/* 287 */         String msg = Resources.getMessage("TLV_ILLEGAL_TEXT_BODY", JstlCoreTLV.this.prefix, "choose", (s.length() < 7) ? s : s.substring(0, 7));
/*     */ 
/*     */ 
/*     */         
/* 291 */         JstlCoreTLV.this.fail(msg);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void endElement(String ns, String ln, String qn) {
/* 298 */       if (JstlCoreTLV.this.isJspTag(ns, ln, "text")) {
/*     */         return;
/*     */       }
/*     */       
/* 302 */       if (this.bodyNecessary) {
/* 303 */         JstlCoreTLV.this.fail(Resources.getMessage("TLV_MISSING_BODY", this.lastElementName));
/*     */       }
/* 305 */       this.bodyIllegal = false;
/*     */ 
/*     */       
/* 308 */       if (JstlCoreTLV.this.isCoreTag(ns, ln, "choose")) {
/* 309 */         Boolean b = this.chooseHasWhen.pop();
/* 310 */         if (!b.booleanValue()) {
/* 311 */           JstlCoreTLV.this.fail(Resources.getMessage("TLV_PARENT_WITHOUT_SUBTAG", "choose", "when"));
/*     */         }
/* 313 */         this.chooseDepths.pop();
/* 314 */         this.chooseHasOtherwise.pop();
/*     */       } 
/*     */ 
/*     */       
/* 318 */       if (JstlCoreTLV.this.isCoreTag(ns, ln, "import") || JstlCoreTLV.this.isCoreTag(ns, ln, "param") || JstlCoreTLV.this.isCoreTag(ns, ln, "redirect") || JstlCoreTLV.this.isCoreTag(ns, ln, "url"))
/*     */       {
/*     */ 
/*     */         
/* 322 */         this.urlTags.pop();
/*     */       }
/*     */       
/* 325 */       this.depth--;
/*     */     }
/*     */ 
/*     */     
/*     */     private boolean chooseChild() {
/* 330 */       return (!this.chooseDepths.empty() && this.depth - 1 == ((Integer)this.chooseDepths.peek()).intValue());
/*     */     }
/*     */     
/*     */     private Handler() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tlv\JstlCoreTLV.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */