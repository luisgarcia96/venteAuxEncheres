package org.apache.taglibs.standard.lang.jstl;

public abstract class UnaryOperator {
  public abstract String getOperatorSymbol();
  
  public abstract Object apply(Object paramObject1, Object paramObject2, Logger paramLogger) throws ELException;
}


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\jstl\UnaryOperator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */