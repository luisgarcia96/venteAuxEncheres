package org.apache.taglibs.standard.lang.jstl;

import java.util.Map;

public abstract class Expression {
  public abstract String getExpressionString();
  
  public abstract Object evaluate(Object paramObject, VariableResolver paramVariableResolver, Map paramMap, String paramString, Logger paramLogger) throws ELException;
}


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\jstl\Expression.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */