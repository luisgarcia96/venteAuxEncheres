/*     */ package org.apache.taglibs.standard.lang.jstl;
/*     */ 
/*     */ import java.beans.BeanInfo;
/*     */ import java.beans.EventSetDescriptor;
/*     */ import java.beans.IndexedPropertyDescriptor;
/*     */ import java.beans.IntrospectionException;
/*     */ import java.beans.Introspector;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.security.AccessControlException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BeanInfoManager
/*     */ {
/*     */   Class mBeanClass;
/*     */   BeanInfo mBeanInfo;
/*     */   Map mPropertyByName;
/*     */   Map mIndexedPropertyByName;
/*     */   Map mEventSetByName;
/*     */   boolean mInitialized;
/*     */   
/*     */   public Class getBeanClass() {
/*  61 */     return this.mBeanClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  83 */   static Map mBeanInfoManagerByClass = new HashMap<Object, Object>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   BeanInfoManager(Class pBeanClass) {
/*  92 */     this.mBeanClass = pBeanClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BeanInfoManager getBeanInfoManager(Class pClass) {
/* 102 */     BeanInfoManager ret = (BeanInfoManager)mBeanInfoManagerByClass.get(pClass);
/*     */     
/* 104 */     if (ret == null) {
/* 105 */       ret = createBeanInfoManager(pClass);
/*     */     }
/* 107 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static synchronized BeanInfoManager createBeanInfoManager(Class<?> pClass) {
/* 126 */     BeanInfoManager ret = (BeanInfoManager)mBeanInfoManagerByClass.get(pClass);
/*     */     
/* 128 */     if (ret == null) {
/* 129 */       ret = new BeanInfoManager(pClass);
/* 130 */       mBeanInfoManagerByClass.put(pClass, ret);
/*     */     } 
/* 132 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BeanInfoProperty getBeanInfoProperty(Class pClass, String pPropertyName, Logger pLogger) throws ELException {
/* 147 */     return getBeanInfoManager(pClass).getProperty(pPropertyName, pLogger);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BeanInfoIndexedProperty getBeanInfoIndexedProperty(Class pClass, String pIndexedPropertyName, Logger pLogger) throws ELException {
/* 162 */     return getBeanInfoManager(pClass).getIndexedProperty(pIndexedPropertyName, pLogger);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void checkInitialized(Logger pLogger) throws ELException {
/* 175 */     if (!this.mInitialized) {
/* 176 */       synchronized (this) {
/* 177 */         if (!this.mInitialized) {
/* 178 */           initialize(pLogger);
/* 179 */           this.mInitialized = true;
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void initialize(Logger pLogger) throws ELException {
/*     */     try {
/* 194 */       this.mBeanInfo = Introspector.getBeanInfo(this.mBeanClass);
/*     */       
/* 196 */       this.mPropertyByName = new HashMap<Object, Object>();
/* 197 */       this.mIndexedPropertyByName = new HashMap<Object, Object>();
/* 198 */       PropertyDescriptor[] pds = this.mBeanInfo.getPropertyDescriptors();
/* 199 */       for (int i = 0; pds != null && i < pds.length; i++) {
/*     */         
/* 201 */         PropertyDescriptor pd = pds[i];
/* 202 */         if (pd instanceof IndexedPropertyDescriptor) {
/* 203 */           IndexedPropertyDescriptor ipd = (IndexedPropertyDescriptor)pd;
/* 204 */           Method method1 = getPublicMethod(ipd.getIndexedReadMethod());
/* 205 */           Method method2 = getPublicMethod(ipd.getIndexedWriteMethod());
/* 206 */           BeanInfoIndexedProperty beanInfoIndexedProperty = new BeanInfoIndexedProperty(method1, method2, ipd);
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 211 */           this.mIndexedPropertyByName.put(ipd.getName(), beanInfoIndexedProperty);
/*     */         } 
/*     */         
/* 214 */         Method readMethod = getPublicMethod(pd.getReadMethod());
/* 215 */         Method writeMethod = getPublicMethod(pd.getWriteMethod());
/* 216 */         BeanInfoProperty property = new BeanInfoProperty(readMethod, writeMethod, pd);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 221 */         this.mPropertyByName.put(pd.getName(), property);
/*     */       } 
/*     */       
/* 224 */       this.mEventSetByName = new HashMap<Object, Object>();
/* 225 */       EventSetDescriptor[] esds = this.mBeanInfo.getEventSetDescriptors();
/* 226 */       for (int j = 0; esds != null && j < esds.length; j++) {
/* 227 */         EventSetDescriptor esd = esds[j];
/* 228 */         this.mEventSetByName.put(esd.getName(), esd);
/*     */       }
/*     */     
/* 231 */     } catch (IntrospectionException exc) {
/* 232 */       if (pLogger.isLoggingWarning()) {
/* 233 */         pLogger.logWarning(Constants.EXCEPTION_GETTING_BEANINFO, exc, this.mBeanClass.getName());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   BeanInfo getBeanInfo(Logger pLogger) throws ELException {
/* 249 */     checkInitialized(pLogger);
/* 250 */     return this.mBeanInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanInfoProperty getProperty(String pPropertyName, Logger pLogger) throws ELException {
/* 263 */     checkInitialized(pLogger);
/* 264 */     return (BeanInfoProperty)this.mPropertyByName.get(pPropertyName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanInfoIndexedProperty getIndexedProperty(String pIndexedPropertyName, Logger pLogger) throws ELException {
/* 278 */     checkInitialized(pLogger);
/* 279 */     return (BeanInfoIndexedProperty)this.mIndexedPropertyByName.get(pIndexedPropertyName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EventSetDescriptor getEventSet(String pEventSetName, Logger pLogger) throws ELException {
/* 293 */     checkInitialized(pLogger);
/* 294 */     return (EventSetDescriptor)this.mEventSetByName.get(pEventSetName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Method getPublicMethod(Method pMethod) {
/* 311 */     if (pMethod == null) {
/* 312 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 316 */     Class<?> cl = pMethod.getDeclaringClass();
/* 317 */     if (Modifier.isPublic(cl.getModifiers())) {
/* 318 */       return pMethod;
/*     */     }
/*     */ 
/*     */     
/* 322 */     Method ret = getPublicMethod(cl, pMethod);
/* 323 */     if (ret != null) {
/* 324 */       return ret;
/*     */     }
/*     */     
/* 327 */     return pMethod;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Method getPublicMethod(Class pClass, Method pMethod) {
/* 343 */     if (Modifier.isPublic(pClass.getModifiers())) {
/*     */       try {
/*     */         Method method;
/*     */         try {
/* 347 */           method = pClass.getDeclaredMethod(pMethod.getName(), pMethod.getParameterTypes());
/*     */         }
/* 349 */         catch (AccessControlException ex) {
/*     */ 
/*     */ 
/*     */           
/* 353 */           method = pClass.getMethod(pMethod.getName(), pMethod.getParameterTypes());
/*     */         } 
/*     */         
/* 356 */         if (Modifier.isPublic(method.getModifiers())) {
/* 357 */           return method;
/*     */         }
/*     */       }
/* 360 */       catch (NoSuchMethodException exc) {}
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 365 */     Class[] interfaces = pClass.getInterfaces();
/* 366 */     if (interfaces != null) {
/* 367 */       for (int i = 0; i < interfaces.length; i++) {
/* 368 */         Method m = getPublicMethod(interfaces[i], pMethod);
/* 369 */         if (m != null) {
/* 370 */           return m;
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 378 */     Class superclass = pClass.getSuperclass();
/* 379 */     if (superclass != null) {
/* 380 */       Method m = getPublicMethod(superclass, pMethod);
/* 381 */       if (m != null) {
/* 382 */         return m;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 387 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\jstl\BeanInfoManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */