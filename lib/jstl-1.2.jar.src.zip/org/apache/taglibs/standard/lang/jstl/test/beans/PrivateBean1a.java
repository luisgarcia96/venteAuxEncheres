package org.apache.taglibs.standard.lang.jstl.test.beans;

class PrivateBean1a extends PublicBean1 {}


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\jstl\test\beans\PrivateBean1a.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */