/*     */ package org.apache.taglibs.standard.lang.jstl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PrimitiveObjects
/*     */ {
/*  44 */   static int BYTE_LOWER_BOUND = 0;
/*  45 */   static int BYTE_UPPER_BOUND = 255;
/*  46 */   static int CHARACTER_LOWER_BOUND = 0;
/*  47 */   static int CHARACTER_UPPER_BOUND = 255;
/*  48 */   static int SHORT_LOWER_BOUND = -1000;
/*  49 */   static int SHORT_UPPER_BOUND = 1000;
/*  50 */   static int INTEGER_LOWER_BOUND = -1000;
/*  51 */   static int INTEGER_UPPER_BOUND = 1000;
/*  52 */   static int LONG_LOWER_BOUND = -1000;
/*  53 */   static int LONG_UPPER_BOUND = 1000;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  59 */   static Byte[] mBytes = createBytes();
/*  60 */   static Character[] mCharacters = createCharacters();
/*  61 */   static Short[] mShorts = createShorts();
/*  62 */   static Integer[] mIntegers = createIntegers();
/*  63 */   static Long[] mLongs = createLongs();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Boolean getBoolean(boolean pValue) {
/*  70 */     return pValue ? Boolean.TRUE : Boolean.FALSE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Byte getByte(byte pValue) {
/*  79 */     if (pValue >= BYTE_LOWER_BOUND && pValue <= BYTE_UPPER_BOUND)
/*     */     {
/*  81 */       return mBytes[pValue - BYTE_LOWER_BOUND];
/*     */     }
/*     */     
/*  84 */     return new Byte(pValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Character getCharacter(char pValue) {
/*  91 */     if (pValue >= CHARACTER_LOWER_BOUND && pValue <= CHARACTER_UPPER_BOUND)
/*     */     {
/*  93 */       return mCharacters[pValue - CHARACTER_LOWER_BOUND];
/*     */     }
/*     */     
/*  96 */     return new Character(pValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Short getShort(short pValue) {
/* 103 */     if (pValue >= SHORT_LOWER_BOUND && pValue <= SHORT_UPPER_BOUND)
/*     */     {
/* 105 */       return mShorts[pValue - SHORT_LOWER_BOUND];
/*     */     }
/*     */     
/* 108 */     return new Short(pValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Integer getInteger(int pValue) {
/* 115 */     if (pValue >= INTEGER_LOWER_BOUND && pValue <= INTEGER_UPPER_BOUND)
/*     */     {
/* 117 */       return mIntegers[pValue - INTEGER_LOWER_BOUND];
/*     */     }
/*     */     
/* 120 */     return new Integer(pValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Long getLong(long pValue) {
/* 127 */     if (pValue >= LONG_LOWER_BOUND && pValue <= LONG_UPPER_BOUND)
/*     */     {
/* 129 */       return mLongs[(int)pValue - LONG_LOWER_BOUND];
/*     */     }
/*     */     
/* 132 */     return new Long(pValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Float getFloat(float pValue) {
/* 139 */     return new Float(pValue);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Double getDouble(double pValue) {
/* 145 */     return new Double(pValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Class getPrimitiveObjectClass(Class<boolean> pClass) {
/* 158 */     if (pClass == boolean.class) {
/* 159 */       return Boolean.class;
/*     */     }
/* 161 */     if (pClass == byte.class) {
/* 162 */       return Byte.class;
/*     */     }
/* 164 */     if (pClass == short.class) {
/* 165 */       return Short.class;
/*     */     }
/* 167 */     if (pClass == char.class) {
/* 168 */       return Character.class;
/*     */     }
/* 170 */     if (pClass == int.class) {
/* 171 */       return Integer.class;
/*     */     }
/* 173 */     if (pClass == long.class) {
/* 174 */       return Long.class;
/*     */     }
/* 176 */     if (pClass == float.class) {
/* 177 */       return Float.class;
/*     */     }
/* 179 */     if (pClass == double.class) {
/* 180 */       return Double.class;
/*     */     }
/*     */     
/* 183 */     return pClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Byte[] createBytes() {
/* 192 */     int len = BYTE_UPPER_BOUND - BYTE_LOWER_BOUND + 1;
/* 193 */     Byte[] ret = new Byte[len];
/* 194 */     byte val = (byte)BYTE_LOWER_BOUND;
/* 195 */     for (int i = 0; i < len; i++, val = (byte)(val + 1)) {
/* 196 */       ret[i] = new Byte(val);
/*     */     }
/* 198 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static Character[] createCharacters() {
/* 204 */     int len = CHARACTER_UPPER_BOUND - CHARACTER_LOWER_BOUND + 1;
/* 205 */     Character[] ret = new Character[len];
/* 206 */     char val = (char)CHARACTER_LOWER_BOUND;
/* 207 */     for (int i = 0; i < len; i++, val = (char)(val + 1)) {
/* 208 */       ret[i] = new Character(val);
/*     */     }
/* 210 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static Short[] createShorts() {
/* 216 */     int len = SHORT_UPPER_BOUND - SHORT_LOWER_BOUND + 1;
/* 217 */     Short[] ret = new Short[len];
/* 218 */     short val = (short)SHORT_LOWER_BOUND;
/* 219 */     for (int i = 0; i < len; i++, val = (short)(val + 1)) {
/* 220 */       ret[i] = new Short(val);
/*     */     }
/* 222 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static Integer[] createIntegers() {
/* 228 */     int len = INTEGER_UPPER_BOUND - INTEGER_LOWER_BOUND + 1;
/* 229 */     Integer[] ret = new Integer[len];
/* 230 */     int val = INTEGER_LOWER_BOUND;
/* 231 */     for (int i = 0; i < len; i++, val++) {
/* 232 */       ret[i] = new Integer(val);
/*     */     }
/* 234 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static Long[] createLongs() {
/* 240 */     int len = LONG_UPPER_BOUND - LONG_LOWER_BOUND + 1;
/* 241 */     Long[] ret = new Long[len];
/* 242 */     long val = LONG_LOWER_BOUND;
/* 243 */     for (int i = 0; i < len; i++, val++) {
/* 244 */       ret[i] = new Long(val);
/*     */     }
/* 246 */     return ret;
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\jstl\PrimitiveObjects.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */