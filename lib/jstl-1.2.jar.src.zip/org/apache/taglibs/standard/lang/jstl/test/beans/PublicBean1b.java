package org.apache.taglibs.standard.lang.jstl.test.beans;

public class PublicBean1b extends PrivateBean1a {}


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\jstl\test\beans\PublicBean1b.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */