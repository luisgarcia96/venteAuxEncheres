/*     */ package org.apache.taglibs.standard.lang.jstl;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnaryOperatorExpression
/*     */   extends Expression
/*     */ {
/*     */   UnaryOperator mOperator;
/*     */   List mOperators;
/*     */   Expression mExpression;
/*     */   
/*     */   public UnaryOperator getOperator() {
/*  51 */     return this.mOperator;
/*     */   } public void setOperator(UnaryOperator pOperator) {
/*  53 */     this.mOperator = pOperator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List getOperators() {
/*  60 */     return this.mOperators;
/*     */   } public void setOperators(List pOperators) {
/*  62 */     this.mOperators = pOperators;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression getExpression() {
/*  69 */     return this.mExpression;
/*     */   } public void setExpression(Expression pExpression) {
/*  71 */     this.mExpression = pExpression;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UnaryOperatorExpression(UnaryOperator pOperator, List pOperators, Expression pExpression) {
/*  82 */     this.mOperator = pOperator;
/*  83 */     this.mOperators = pOperators;
/*  84 */     this.mExpression = pExpression;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getExpressionString() {
/*  96 */     StringBuffer buf = new StringBuffer();
/*  97 */     buf.append("(");
/*  98 */     if (this.mOperator != null) {
/*  99 */       buf.append(this.mOperator.getOperatorSymbol());
/* 100 */       buf.append(" ");
/*     */     } else {
/*     */       
/* 103 */       for (int i = 0; i < this.mOperators.size(); i++) {
/* 104 */         UnaryOperator operator = this.mOperators.get(i);
/* 105 */         buf.append(operator.getOperatorSymbol());
/* 106 */         buf.append(" ");
/*     */       } 
/*     */     } 
/* 109 */     buf.append(this.mExpression.getExpressionString());
/* 110 */     buf.append(")");
/* 111 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object evaluate(Object pContext, VariableResolver pResolver, Map functions, String defaultPrefix, Logger pLogger) throws ELException {
/* 126 */     Object value = this.mExpression.evaluate(pContext, pResolver, functions, defaultPrefix, pLogger);
/*     */     
/* 128 */     if (this.mOperator != null) {
/* 129 */       value = this.mOperator.apply(value, pContext, pLogger);
/*     */     } else {
/*     */       
/* 132 */       for (int i = this.mOperators.size() - 1; i >= 0; i--) {
/* 133 */         UnaryOperator operator = this.mOperators.get(i);
/* 134 */         value = operator.apply(value, pContext, pLogger);
/*     */       } 
/*     */     } 
/* 137 */     return value;
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\jstl\UnaryOperatorExpression.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */