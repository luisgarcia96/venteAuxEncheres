/*     */ package org.apache.taglibs.standard.lang.jstl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DivideOperator
/*     */   extends BinaryOperator
/*     */ {
/*  43 */   public static final DivideOperator SINGLETON = new DivideOperator();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getOperatorSymbol() {
/*  64 */     return "/";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object apply(Object pLeft, Object pRight, Object pContext, Logger pLogger) throws ELException {
/*  78 */     if (pLeft == null && pRight == null) {
/*     */       
/*  80 */       if (pLogger.isLoggingWarning()) {
/*  81 */         pLogger.logWarning(Constants.ARITH_OP_NULL, getOperatorSymbol());
/*     */       }
/*     */ 
/*     */       
/*  85 */       return PrimitiveObjects.getInteger(0);
/*     */     } 
/*     */     
/*  88 */     double left = Coercions.coerceToPrimitiveNumber(pLeft, Double.class, pLogger).doubleValue();
/*     */ 
/*     */     
/*  91 */     double right = Coercions.coerceToPrimitiveNumber(pRight, Double.class, pLogger).doubleValue();
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  96 */       return PrimitiveObjects.getDouble(left / right);
/*     */     }
/*  98 */     catch (Exception exc) {
/*  99 */       if (pLogger.isLoggingError()) {
/* 100 */         pLogger.logError(Constants.ARITH_ERROR, getOperatorSymbol(), "" + left, "" + right);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 106 */       return PrimitiveObjects.getInteger(0);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\jstl\DivideOperator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */