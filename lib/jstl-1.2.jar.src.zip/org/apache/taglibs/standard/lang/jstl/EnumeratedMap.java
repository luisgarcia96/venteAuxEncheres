/*     */ package org.apache.taglibs.standard.lang.jstl;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class EnumeratedMap
/*     */   implements Map
/*     */ {
/*     */   Map mMap;
/*     */   
/*     */   public void clear() {
/*  61 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsKey(Object pKey) {
/*  67 */     return (getValue(pKey) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsValue(Object pValue) {
/*  73 */     return getAsMap().containsValue(pValue);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Set entrySet() {
/*  79 */     return getAsMap().entrySet();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object get(Object pKey) {
/*  85 */     return getValue(pKey);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/*  91 */     return !enumerateKeys().hasMoreElements();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Set keySet() {
/*  97 */     return getAsMap().keySet();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object put(Object pKey, Object pValue) {
/* 103 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void putAll(Map pMap) {
/* 109 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object remove(Object pKey) {
/* 115 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 121 */     return getAsMap().size();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection values() {
/* 127 */     return getAsMap().values();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Enumeration enumerateKeys();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean isMutable();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Object getValue(Object paramObject);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map getAsMap() {
/* 162 */     if (this.mMap != null) {
/* 163 */       return this.mMap;
/*     */     }
/*     */     
/* 166 */     Map m = convertToMap();
/* 167 */     if (!isMutable()) {
/* 168 */       this.mMap = m;
/*     */     }
/* 170 */     return m;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Map convertToMap() {
/* 181 */     Map<Object, Object> ret = new HashMap<Object, Object>();
/* 182 */     for (Enumeration e = enumerateKeys(); e.hasMoreElements(); ) {
/* 183 */       Object key = e.nextElement();
/* 184 */       Object value = getValue(key);
/* 185 */       ret.put(key, value);
/*     */     } 
/* 187 */     return ret;
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\jstl\EnumeratedMap.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */