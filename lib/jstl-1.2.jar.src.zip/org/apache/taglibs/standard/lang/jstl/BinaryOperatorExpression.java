/*     */ package org.apache.taglibs.standard.lang.jstl;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BinaryOperatorExpression
/*     */   extends Expression
/*     */ {
/*     */   Expression mExpression;
/*     */   List mOperators;
/*     */   List mExpressions;
/*     */   
/*     */   public Expression getExpression() {
/*  50 */     return this.mExpression;
/*     */   } public void setExpression(Expression pExpression) {
/*  52 */     this.mExpression = pExpression;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List getOperators() {
/*  59 */     return this.mOperators;
/*     */   } public void setOperators(List pOperators) {
/*  61 */     this.mOperators = pOperators;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List getExpressions() {
/*  68 */     return this.mExpressions;
/*     */   } public void setExpressions(List pExpressions) {
/*  70 */     this.mExpressions = pExpressions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BinaryOperatorExpression(Expression pExpression, List pOperators, List pExpressions) {
/*  81 */     this.mExpression = pExpression;
/*  82 */     this.mOperators = pOperators;
/*  83 */     this.mExpressions = pExpressions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getExpressionString() {
/*  95 */     StringBuffer buf = new StringBuffer();
/*  96 */     buf.append("(");
/*  97 */     buf.append(this.mExpression.getExpressionString());
/*  98 */     for (int i = 0; i < this.mOperators.size(); i++) {
/*  99 */       BinaryOperator operator = this.mOperators.get(i);
/* 100 */       Expression expression = this.mExpressions.get(i);
/* 101 */       buf.append(" ");
/* 102 */       buf.append(operator.getOperatorSymbol());
/* 103 */       buf.append(" ");
/* 104 */       buf.append(expression.getExpressionString());
/*     */     } 
/* 106 */     buf.append(")");
/*     */     
/* 108 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object evaluate(Object pContext, VariableResolver pResolver, Map functions, String defaultPrefix, Logger pLogger) throws ELException {
/* 123 */     Object value = this.mExpression.evaluate(pContext, pResolver, functions, defaultPrefix, pLogger);
/*     */     
/* 125 */     for (int i = 0; i < this.mOperators.size(); i++) {
/* 126 */       BinaryOperator operator = this.mOperators.get(i);
/*     */ 
/*     */ 
/*     */       
/* 130 */       if (operator.shouldCoerceToBoolean()) {
/* 131 */         value = Coercions.coerceToBoolean(value, pLogger);
/*     */       }
/*     */       
/* 134 */       if (operator.shouldEvaluate(value)) {
/* 135 */         Expression expression = this.mExpressions.get(i);
/* 136 */         Object nextValue = expression.evaluate(pContext, pResolver, functions, defaultPrefix, pLogger);
/*     */ 
/*     */ 
/*     */         
/* 140 */         value = operator.apply(value, nextValue, pContext, pLogger);
/*     */       } 
/*     */     } 
/* 143 */     return value;
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\lang\jstl\BinaryOperatorExpression.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */