/*     */ package org.apache.taglibs.standard.tag.common.core;
/*     */ 
/*     */ import java.beans.IntrospectionException;
/*     */ import java.beans.Introspector;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Map;
/*     */ import javax.el.ELException;
/*     */ import javax.el.ExpressionFactory;
/*     */ import javax.el.ValueExpression;
/*     */ import javax.el.VariableMapper;
/*     */ import javax.servlet.jsp.JspApplicationContext;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.JspFactory;
/*     */ import javax.servlet.jsp.JspTagException;
/*     */ import javax.servlet.jsp.tagext.BodyTagSupport;
/*     */ import org.apache.taglibs.standard.resources.Resources;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SetSupport
/*     */   extends BodyTagSupport
/*     */ {
/*     */   protected Object value;
/*     */   protected boolean valueSpecified;
/*     */   protected Object target;
/*     */   protected String property;
/*     */   private String var;
/*     */   private int scope;
/*     */   private boolean scopeSpecified;
/*     */   
/*     */   public SetSupport() {
/*  77 */     init();
/*     */   }
/*     */ 
/*     */   
/*     */   private void init() {
/*  82 */     this.value = this.var = null;
/*  83 */     this.scopeSpecified = this.valueSpecified = false;
/*  84 */     this.scope = 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public void release() {
/*  89 */     super.release();
/*  90 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doEndTag() throws JspException {
/*     */     Object result;
/* 102 */     if (this.value != null) {
/*     */       
/* 104 */       result = this.value;
/* 105 */     } else if (this.valueSpecified) {
/*     */       
/* 107 */       result = null;
/*     */     
/*     */     }
/* 110 */     else if (this.bodyContent == null || this.bodyContent.getString() == null) {
/* 111 */       result = "";
/*     */     } else {
/* 113 */       result = this.bodyContent.getString().trim();
/*     */     } 
/*     */ 
/*     */     
/* 117 */     if (this.var != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 125 */       if (result != null) {
/* 126 */         if (result instanceof ValueExpression) {
/* 127 */           if (this.scope != 1) {
/* 128 */             throw new JspException(Resources.getMessage("SET_BAD_SCOPE_DEFERRED"));
/*     */           }
/*     */           
/* 131 */           VariableMapper vm = this.pageContext.getELContext().getVariableMapper();
/*     */           
/* 133 */           if (vm != null) {
/* 134 */             vm.setVariable(this.var, (ValueExpression)result);
/*     */           }
/*     */         }
/*     */         else {
/*     */           
/* 139 */           if (this.scope == 1) {
/* 140 */             VariableMapper vm = this.pageContext.getELContext().getVariableMapper();
/*     */             
/* 142 */             if (vm != null) {
/* 143 */               vm.setVariable(this.var, null);
/*     */             }
/*     */           } 
/* 146 */           this.pageContext.setAttribute(this.var, result, this.scope);
/*     */         } 
/*     */       } else {
/* 149 */         if (this.scopeSpecified) {
/* 150 */           this.pageContext.removeAttribute(this.var, this.scope);
/*     */         } else {
/* 152 */           this.pageContext.removeAttribute(this.var);
/*     */         } 
/* 154 */         if (this.scope == 1) {
/* 155 */           VariableMapper vm = this.pageContext.getELContext().getVariableMapper();
/*     */           
/* 157 */           if (vm != null) {
/* 158 */             vm.setVariable(this.var, null);
/*     */           }
/*     */         }
/*     */       
/*     */       } 
/* 163 */     } else if (this.target != null) {
/*     */ 
/*     */       
/* 166 */       if (this.target instanceof Map) {
/*     */         
/* 168 */         if (result == null) {
/* 169 */           ((Map)this.target).remove(this.property);
/*     */         } else {
/* 171 */           ((Map<String, Object>)this.target).put(this.property, result);
/*     */         } 
/*     */       } else {
/*     */         try {
/* 175 */           PropertyDescriptor[] pd = Introspector.getBeanInfo(this.target.getClass()).getPropertyDescriptors();
/*     */ 
/*     */           
/* 178 */           boolean succeeded = false;
/* 179 */           for (int i = 0; i < pd.length; i++) {
/* 180 */             if (pd[i].getName().equals(this.property)) {
/* 181 */               Method m = pd[i].getWriteMethod();
/* 182 */               if (m == null) {
/* 183 */                 throw new JspException(Resources.getMessage("SET_NO_SETTER_METHOD", this.property));
/*     */               }
/*     */ 
/*     */               
/* 187 */               if (result != null) {
/*     */                 try {
/* 189 */                   m.invoke(this.target, new Object[] { convertToExpectedType(result, m.getParameterTypes()[0]) });
/*     */                 
/*     */                 }
/* 192 */                 catch (ELException ex) {
/* 193 */                   throw new JspTagException(ex);
/*     */                 } 
/*     */               } else {
/* 196 */                 m.invoke(this.target, new Object[] { null });
/*     */               } 
/* 198 */               succeeded = true;
/*     */             } 
/*     */           } 
/* 201 */           if (!succeeded) {
/* 202 */             throw new JspTagException(Resources.getMessage("SET_INVALID_PROPERTY", this.property));
/*     */           
/*     */           }
/*     */         }
/* 206 */         catch (IllegalAccessException ex) {
/* 207 */           throw new JspException(ex);
/* 208 */         } catch (IntrospectionException ex) {
/* 209 */           throw new JspException(ex);
/* 210 */         } catch (InvocationTargetException ex) {
/* 211 */           throw new JspException(ex);
/*     */         } 
/*     */       } 
/*     */     } else {
/*     */       
/* 216 */       throw new JspTagException();
/*     */     } 
/*     */     
/* 219 */     return 6;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object convertToExpectedType(Object value, Class expectedType) {
/* 229 */     JspFactory jspFactory = JspFactory.getDefaultFactory();
/* 230 */     JspApplicationContext jspAppContext = jspFactory.getJspApplicationContext(this.pageContext.getServletContext());
/*     */     
/* 232 */     ExpressionFactory exprFactory = jspAppContext.getExpressionFactory();
/* 233 */     return exprFactory.coerceToType(value, expectedType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVar(String var) {
/* 241 */     this.var = var;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setScope(String scope) {
/* 246 */     this.scope = Util.getScope(scope);
/* 247 */     this.scopeSpecified = true;
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\common\core\SetSupport.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */