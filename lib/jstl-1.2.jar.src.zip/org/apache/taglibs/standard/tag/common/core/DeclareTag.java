package org.apache.taglibs.standard.tag.common.core;

import javax.servlet.jsp.tagext.TagSupport;

public class DeclareTag extends TagSupport {
  public void setType(String x) {}
}


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\common\core\DeclareTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */