/*     */ package org.apache.taglibs.standard.tag.common.fmt;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.ResourceBundle;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.JspTagException;
/*     */ import javax.servlet.jsp.jstl.fmt.LocalizationContext;
/*     */ import javax.servlet.jsp.tagext.BodyTagSupport;
/*     */ import javax.servlet.jsp.tagext.Tag;
/*     */ import org.apache.taglibs.standard.tag.common.core.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MessageSupport
/*     */   extends BodyTagSupport
/*     */ {
/*     */   public static final String UNDEFINED_KEY = "???";
/*     */   protected String keyAttrValue;
/*     */   protected boolean keySpecified;
/*     */   protected LocalizationContext bundleAttrValue;
/*     */   protected boolean bundleSpecified;
/*     */   private String var;
/*     */   private int scope;
/*     */   private List params;
/*     */   
/*     */   public MessageSupport() {
/*  82 */     this.params = new ArrayList();
/*  83 */     init();
/*     */   }
/*     */   
/*     */   private void init() {
/*  87 */     this.var = null;
/*  88 */     this.scope = 1;
/*  89 */     this.keyAttrValue = null;
/*  90 */     this.keySpecified = false;
/*  91 */     this.bundleAttrValue = null;
/*  92 */     this.bundleSpecified = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVar(String var) {
/* 100 */     this.var = var;
/*     */   }
/*     */   
/*     */   public void setScope(String scope) {
/* 104 */     this.scope = Util.getScope(scope);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addParam(Object arg) {
/* 117 */     this.params.add(arg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doStartTag() throws JspException {
/* 125 */     this.params.clear();
/* 126 */     return 2;
/*     */   }
/*     */ 
/*     */   
/*     */   public int doEndTag() throws JspException {
/* 131 */     String key = null;
/* 132 */     LocalizationContext locCtxt = null;
/*     */ 
/*     */     
/* 135 */     if (this.keySpecified) {
/*     */       
/* 137 */       key = this.keyAttrValue;
/*     */     
/*     */     }
/* 140 */     else if (this.bodyContent != null && this.bodyContent.getString() != null) {
/* 141 */       key = this.bodyContent.getString().trim();
/*     */     } 
/*     */     
/* 144 */     if (key == null || key.equals("")) {
/*     */       try {
/* 146 */         this.pageContext.getOut().print("??????");
/* 147 */       } catch (IOException ioe) {
/* 148 */         throw new JspTagException(ioe.toString(), ioe);
/*     */       } 
/* 150 */       return 6;
/*     */     } 
/*     */     
/* 153 */     String prefix = null;
/* 154 */     if (!this.bundleSpecified) {
/* 155 */       Tag t = findAncestorWithClass((Tag)this, BundleSupport.class);
/* 156 */       if (t != null) {
/*     */         
/* 158 */         BundleSupport parent = (BundleSupport)t;
/* 159 */         locCtxt = parent.getLocalizationContext();
/* 160 */         prefix = parent.getPrefix();
/*     */       } else {
/* 162 */         locCtxt = BundleSupport.getLocalizationContext(this.pageContext);
/*     */       } 
/*     */     } else {
/*     */       
/* 166 */       locCtxt = this.bundleAttrValue;
/* 167 */       if (locCtxt.getLocale() != null) {
/* 168 */         SetLocaleSupport.setResponseLocale(this.pageContext, locCtxt.getLocale());
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 173 */     String message = "???" + key + "???";
/* 174 */     if (locCtxt != null) {
/* 175 */       ResourceBundle bundle = locCtxt.getResourceBundle();
/* 176 */       if (bundle != null) {
/*     */         
/*     */         try {
/* 179 */           if (prefix != null)
/* 180 */             key = prefix + key; 
/* 181 */           message = bundle.getString(key);
/*     */           
/* 183 */           if (!this.params.isEmpty()) {
/* 184 */             Object[] messageArgs = this.params.toArray();
/* 185 */             MessageFormat formatter = new MessageFormat("");
/* 186 */             if (locCtxt.getLocale() != null) {
/* 187 */               formatter.setLocale(locCtxt.getLocale());
/*     */             
/*     */             }
/*     */             else {
/*     */ 
/*     */               
/* 193 */               Locale locale = SetLocaleSupport.getFormattingLocale(this.pageContext);
/*     */               
/* 195 */               if (locale != null) {
/* 196 */                 formatter.setLocale(locale);
/*     */               }
/*     */             } 
/* 199 */             formatter.applyPattern(message);
/* 200 */             message = formatter.format(messageArgs);
/*     */           } 
/* 202 */         } catch (MissingResourceException mre) {
/* 203 */           message = "???" + key + "???";
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 208 */     if (this.var != null) {
/* 209 */       this.pageContext.setAttribute(this.var, message, this.scope);
/*     */     } else {
/*     */       try {
/* 212 */         this.pageContext.getOut().print(message);
/* 213 */       } catch (IOException ioe) {
/* 214 */         throw new JspTagException(ioe.toString(), ioe);
/*     */       } 
/*     */     } 
/*     */     
/* 218 */     return 6;
/*     */   }
/*     */ 
/*     */   
/*     */   public void release() {
/* 223 */     init();
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\common\fmt\MessageSupport.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */