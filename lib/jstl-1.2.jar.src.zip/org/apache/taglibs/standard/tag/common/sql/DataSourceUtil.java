/*     */ package org.apache.taglibs.standard.tag.common.sql;
/*     */ 
/*     */ import javax.naming.Context;
/*     */ import javax.naming.InitialContext;
/*     */ import javax.naming.NamingException;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.JspTagException;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import javax.servlet.jsp.jstl.core.Config;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.taglibs.standard.resources.Resources;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataSourceUtil
/*     */ {
/*     */   private static final String ESCAPE = "\\";
/*     */   private static final String TOKEN = ",";
/*     */   
/*     */   static DataSource getDataSource(Object rawDataSource, PageContext pc) throws JspException {
/*  62 */     DataSource dataSource = null;
/*     */     
/*  64 */     if (rawDataSource == null) {
/*  65 */       rawDataSource = Config.find(pc, "javax.servlet.jsp.jstl.sql.dataSource");
/*     */     }
/*     */     
/*  68 */     if (rawDataSource == null) {
/*  69 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  77 */     if (rawDataSource instanceof String) {
/*     */       try {
/*  79 */         Context ctx = new InitialContext();
/*     */         
/*  81 */         Context envCtx = (Context)ctx.lookup("java:comp/env");
/*  82 */         dataSource = (DataSource)envCtx.lookup((String)rawDataSource);
/*  83 */       } catch (NamingException ex) {
/*  84 */         dataSource = getDataSource((String)rawDataSource);
/*     */       } 
/*  86 */     } else if (rawDataSource instanceof DataSource) {
/*  87 */       dataSource = (DataSource)rawDataSource;
/*     */     } else {
/*  89 */       throw new JspException(Resources.getMessage("SQL_DATASOURCE_INVALID_TYPE"));
/*     */     } 
/*     */ 
/*     */     
/*  93 */     return dataSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static DataSource getDataSource(String params) throws JspException {
/* 102 */     DataSourceWrapper dataSource = new DataSourceWrapper();
/*     */     
/* 104 */     String[] paramString = new String[4];
/* 105 */     int escCount = 0;
/* 106 */     int aryCount = 0;
/* 107 */     int begin = 0;
/*     */     
/* 109 */     for (int index = 0; index < params.length(); index++) {
/* 110 */       char nextChar = params.charAt(index);
/* 111 */       if (",".indexOf(nextChar) != -1 && 
/* 112 */         escCount == 0) {
/* 113 */         paramString[aryCount] = params.substring(begin, index).trim();
/* 114 */         begin = index + 1;
/* 115 */         if (++aryCount > 4) {
/* 116 */           throw new JspTagException(Resources.getMessage("JDBC_PARAM_COUNT"));
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 121 */       if ("\\".indexOf(nextChar) != -1) {
/* 122 */         escCount++;
/*     */       } else {
/*     */         
/* 125 */         escCount = 0;
/*     */       } 
/*     */     } 
/* 128 */     paramString[aryCount] = params.substring(begin).trim();
/*     */ 
/*     */     
/* 131 */     dataSource.setJdbcURL(paramString[0]);
/*     */ 
/*     */     
/* 134 */     if (paramString[1] != null) {
/*     */       try {
/* 136 */         dataSource.setDriverClassName(paramString[1]);
/* 137 */       } catch (Exception ex) {
/* 138 */         throw new JspTagException(Resources.getMessage("DRIVER_INVALID_CLASS", ex.toString()), ex);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 145 */     dataSource.setUserName(paramString[2]);
/* 146 */     dataSource.setPassword(paramString[3]);
/*     */     
/* 148 */     return dataSource;
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\common\sql\DataSourceUtil.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */