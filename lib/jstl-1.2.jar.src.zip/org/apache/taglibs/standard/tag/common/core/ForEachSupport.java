/*     */ package org.apache.taglibs.standard.tag.common.core;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.el.ValueExpression;
/*     */ import javax.servlet.jsp.JspTagException;
/*     */ import javax.servlet.jsp.jstl.core.LoopTagSupport;
/*     */ import org.apache.taglibs.standard.resources.Resources;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ForEachSupport
/*     */   extends LoopTagSupport
/*     */ {
/*     */   protected ForEachIterator items;
/*     */   protected Object rawItems;
/*     */   
/*     */   protected class SimpleForEachIterator
/*     */     implements ForEachIterator
/*     */   {
/*     */     private Iterator i;
/*     */     
/*     */     public SimpleForEachIterator(Iterator i) {
/* 113 */       this.i = i;
/*     */     }
/*     */     public boolean hasNext() {
/* 116 */       return this.i.hasNext();
/*     */     }
/*     */     public Object next() {
/* 119 */       return this.i.next();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean hasNext() throws JspTagException {
/* 137 */     return this.items.hasNext();
/*     */   }
/*     */   
/*     */   protected Object next() throws JspTagException {
/* 141 */     return this.items.next();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void prepare() throws JspTagException {
/* 146 */     if (this.rawItems != null) {
/*     */ 
/*     */       
/* 149 */       if (this.rawItems instanceof ValueExpression) {
/* 150 */         this.deferredExpression = (ValueExpression)this.rawItems;
/* 151 */         this.rawItems = this.deferredExpression.getValue(this.pageContext.getELContext());
/*     */       } 
/*     */ 
/*     */       
/* 155 */       this.items = supportedTypeForEachIterator(this.rawItems);
/*     */     } else {
/*     */       
/* 158 */       this.items = beginEndForEachIterator();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void release() {
/* 175 */     super.release();
/* 176 */     this.items = null;
/* 177 */     this.rawItems = null;
/* 178 */     this.deferredExpression = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ForEachIterator supportedTypeForEachIterator(Object o) throws JspTagException {
/*     */     ForEachIterator items;
/* 205 */     if (o instanceof Object[]) {
/* 206 */       items = toForEachIterator((Object[])o);
/* 207 */     } else if (o instanceof boolean[]) {
/* 208 */       items = toForEachIterator((boolean[])o);
/* 209 */     } else if (o instanceof byte[]) {
/* 210 */       items = toForEachIterator((byte[])o);
/* 211 */     } else if (o instanceof char[]) {
/* 212 */       items = toForEachIterator((char[])o);
/* 213 */     } else if (o instanceof short[]) {
/* 214 */       items = toForEachIterator((short[])o);
/* 215 */     } else if (o instanceof int[]) {
/* 216 */       items = toForEachIterator((int[])o);
/* 217 */     } else if (o instanceof long[]) {
/* 218 */       items = toForEachIterator((long[])o);
/* 219 */     } else if (o instanceof float[]) {
/* 220 */       items = toForEachIterator((float[])o);
/* 221 */     } else if (o instanceof double[]) {
/* 222 */       items = toForEachIterator((double[])o);
/* 223 */     } else if (o instanceof Collection) {
/* 224 */       items = toForEachIterator((Collection)o);
/* 225 */     } else if (o instanceof Iterator) {
/* 226 */       items = toForEachIterator((Iterator)o);
/* 227 */     } else if (o instanceof Enumeration) {
/* 228 */       items = toForEachIterator((Enumeration)o);
/* 229 */     } else if (o instanceof Map) {
/* 230 */       items = toForEachIterator((Map)o);
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 235 */     else if (o instanceof String) {
/* 236 */       items = toForEachIterator((String)o);
/*     */     } else {
/* 238 */       items = toForEachIterator(o);
/*     */     } 
/* 240 */     return items;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ForEachIterator beginEndForEachIterator() {
/* 261 */     Integer[] ia = new Integer[this.end + 1];
/* 262 */     for (int i = 0; i <= this.end; i++)
/* 263 */       ia[i] = new Integer(i); 
/* 264 */     return new SimpleForEachIterator(Arrays.<Integer>asList(ia).iterator());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ForEachIterator toForEachIterator(Object o) throws JspTagException {
/* 274 */     throw new JspTagException(Resources.getMessage("FOREACH_BAD_ITEMS"));
/*     */   }
/*     */ 
/*     */   
/*     */   protected ForEachIterator toForEachIterator(Object[] a) {
/* 279 */     return new SimpleForEachIterator(Arrays.<Object>asList(a).iterator());
/*     */   }
/*     */ 
/*     */   
/*     */   protected ForEachIterator toForEachIterator(boolean[] a) {
/* 284 */     Boolean[] wrapped = new Boolean[a.length];
/* 285 */     for (int i = 0; i < a.length; i++)
/* 286 */       wrapped[i] = new Boolean(a[i]); 
/* 287 */     return new SimpleForEachIterator(Arrays.<Boolean>asList(wrapped).iterator());
/*     */   }
/*     */ 
/*     */   
/*     */   protected ForEachIterator toForEachIterator(byte[] a) {
/* 292 */     Byte[] wrapped = new Byte[a.length];
/* 293 */     for (int i = 0; i < a.length; i++)
/* 294 */       wrapped[i] = new Byte(a[i]); 
/* 295 */     return new SimpleForEachIterator(Arrays.<Byte>asList(wrapped).iterator());
/*     */   }
/*     */ 
/*     */   
/*     */   protected ForEachIterator toForEachIterator(char[] a) {
/* 300 */     Character[] wrapped = new Character[a.length];
/* 301 */     for (int i = 0; i < a.length; i++)
/* 302 */       wrapped[i] = new Character(a[i]); 
/* 303 */     return new SimpleForEachIterator(Arrays.<Character>asList(wrapped).iterator());
/*     */   }
/*     */ 
/*     */   
/*     */   protected ForEachIterator toForEachIterator(short[] a) {
/* 308 */     Short[] wrapped = new Short[a.length];
/* 309 */     for (int i = 0; i < a.length; i++)
/* 310 */       wrapped[i] = new Short(a[i]); 
/* 311 */     return new SimpleForEachIterator(Arrays.<Short>asList(wrapped).iterator());
/*     */   }
/*     */ 
/*     */   
/*     */   protected ForEachIterator toForEachIterator(int[] a) {
/* 316 */     Integer[] wrapped = new Integer[a.length];
/* 317 */     for (int i = 0; i < a.length; i++)
/* 318 */       wrapped[i] = new Integer(a[i]); 
/* 319 */     return new SimpleForEachIterator(Arrays.<Integer>asList(wrapped).iterator());
/*     */   }
/*     */ 
/*     */   
/*     */   protected ForEachIterator toForEachIterator(long[] a) {
/* 324 */     Long[] wrapped = new Long[a.length];
/* 325 */     for (int i = 0; i < a.length; i++)
/* 326 */       wrapped[i] = new Long(a[i]); 
/* 327 */     return new SimpleForEachIterator(Arrays.<Long>asList(wrapped).iterator());
/*     */   }
/*     */ 
/*     */   
/*     */   protected ForEachIterator toForEachIterator(float[] a) {
/* 332 */     Float[] wrapped = new Float[a.length];
/* 333 */     for (int i = 0; i < a.length; i++)
/* 334 */       wrapped[i] = new Float(a[i]); 
/* 335 */     return new SimpleForEachIterator(Arrays.<Float>asList(wrapped).iterator());
/*     */   }
/*     */ 
/*     */   
/*     */   protected ForEachIterator toForEachIterator(double[] a) {
/* 340 */     Double[] wrapped = new Double[a.length];
/* 341 */     for (int i = 0; i < a.length; i++)
/* 342 */       wrapped[i] = new Double(a[i]); 
/* 343 */     return new SimpleForEachIterator(Arrays.<Double>asList(wrapped).iterator());
/*     */   }
/*     */ 
/*     */   
/*     */   protected ForEachIterator toForEachIterator(Collection c) {
/* 348 */     return new SimpleForEachIterator(c.iterator());
/*     */   }
/*     */ 
/*     */   
/*     */   protected ForEachIterator toForEachIterator(Iterator i) {
/* 353 */     return new SimpleForEachIterator(i);
/*     */   }
/*     */   
/*     */   protected ForEachIterator toForEachIterator(Enumeration e) {
/*     */     class EnumerationAdapter
/*     */       implements ForEachIterator
/*     */     {
/*     */       private Enumeration e;
/*     */       
/*     */       public EnumerationAdapter(Enumeration e) {
/* 363 */         this.e = e;
/*     */       }
/*     */       public boolean hasNext() {
/* 366 */         return this.e.hasMoreElements();
/*     */       }
/*     */       public Object next() {
/* 369 */         return this.e.nextElement();
/*     */       }
/*     */     };
/*     */     
/* 373 */     return new EnumerationAdapter(e);
/*     */   }
/*     */ 
/*     */   
/*     */   protected ForEachIterator toForEachIterator(Map m) {
/* 378 */     return new SimpleForEachIterator(m.entrySet().iterator());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ForEachIterator toForEachIterator(String s) {
/* 415 */     StringTokenizer st = new StringTokenizer(s, ",");
/* 416 */     return toForEachIterator(st);
/*     */   }
/*     */   
/*     */   protected static interface ForEachIterator {
/*     */     boolean hasNext() throws JspTagException;
/*     */     
/*     */     Object next() throws JspTagException;
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\common\core\ForEachSupport.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */