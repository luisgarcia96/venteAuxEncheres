/*     */ package org.apache.taglibs.standard.tag.common.fmt;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.JspTagException;
/*     */ import javax.servlet.jsp.tagext.TagSupport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class RequestEncodingSupport
/*     */   extends TagSupport
/*     */ {
/*     */   static final String REQUEST_CHAR_SET = "javax.servlet.jsp.jstl.fmt.request.charset";
/*     */   private static final String DEFAULT_ENCODING = "ISO-8859-1";
/*     */   protected String value;
/*     */   protected String charEncoding;
/*     */   
/*     */   public RequestEncodingSupport() {
/*  75 */     init();
/*     */   }
/*     */   
/*     */   private void init() {
/*  79 */     this.value = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doEndTag() throws JspException {
/*  87 */     this.charEncoding = this.value;
/*  88 */     if (this.charEncoding == null && this.pageContext.getRequest().getCharacterEncoding() == null) {
/*     */ 
/*     */       
/*  91 */       this.charEncoding = (String)this.pageContext.getAttribute("javax.servlet.jsp.jstl.fmt.request.charset", 3);
/*     */ 
/*     */       
/*  94 */       if (this.charEncoding == null)
/*     */       {
/*  96 */         this.charEncoding = "ISO-8859-1";
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 104 */     if (this.charEncoding != null) {
/*     */       try {
/* 106 */         this.pageContext.getRequest().setCharacterEncoding(this.charEncoding);
/* 107 */       } catch (UnsupportedEncodingException uee) {
/* 108 */         throw new JspTagException(uee.toString(), uee);
/*     */       } 
/*     */     }
/*     */     
/* 112 */     return 6;
/*     */   }
/*     */ 
/*     */   
/*     */   public void release() {
/* 117 */     init();
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\common\fmt\RequestEncodingSupport.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */