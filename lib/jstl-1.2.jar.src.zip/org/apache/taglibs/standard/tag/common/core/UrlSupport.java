/*     */ package org.apache.taglibs.standard.tag.common.core;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.JspTagException;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import javax.servlet.jsp.tagext.BodyTagSupport;
/*     */ import org.apache.taglibs.standard.resources.Resources;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class UrlSupport
/*     */   extends BodyTagSupport
/*     */   implements ParamParent
/*     */ {
/*     */   protected String value;
/*     */   protected String context;
/*     */   private String var;
/*     */   private int scope;
/*     */   private ParamSupport.ParamManager params;
/*     */   
/*     */   public UrlSupport() {
/*  65 */     init();
/*     */   }
/*     */   
/*     */   private void init() {
/*  69 */     this.value = this.var = null;
/*  70 */     this.params = null;
/*  71 */     this.context = null;
/*  72 */     this.scope = 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVar(String var) {
/*  80 */     this.var = var;
/*     */   }
/*     */   
/*     */   public void setScope(String scope) {
/*  84 */     this.scope = Util.getScope(scope);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addParameter(String name, String value) {
/*  93 */     this.params.addParameter(name, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doStartTag() throws JspException {
/* 102 */     this.params = new ParamSupport.ParamManager();
/* 103 */     return 2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doEndTag() throws JspException {
/* 112 */     String baseUrl = resolveUrl(this.value, this.context, this.pageContext);
/* 113 */     String result = this.params.aggregateParams(baseUrl);
/*     */ 
/*     */     
/* 116 */     if (!ImportSupport.isAbsoluteUrl(result)) {
/* 117 */       HttpServletResponse response = (HttpServletResponse)this.pageContext.getResponse();
/*     */       
/* 119 */       result = response.encodeURL(result);
/*     */     } 
/*     */ 
/*     */     
/* 123 */     if (this.var != null) {
/* 124 */       this.pageContext.setAttribute(this.var, result, this.scope);
/*     */     } else {
/*     */       try {
/* 127 */         this.pageContext.getOut().print(result);
/* 128 */       } catch (IOException ex) {
/* 129 */         throw new JspTagException(ex.toString(), ex);
/*     */       } 
/*     */     } 
/*     */     
/* 133 */     return 6;
/*     */   }
/*     */ 
/*     */   
/*     */   public void release() {
/* 138 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String resolveUrl(String url, String context, PageContext pageContext) throws JspException {
/* 148 */     if (ImportSupport.isAbsoluteUrl(url)) {
/* 149 */       return url;
/*     */     }
/*     */     
/* 152 */     HttpServletRequest request = (HttpServletRequest)pageContext.getRequest();
/*     */     
/* 154 */     if (context == null) {
/* 155 */       if (url.startsWith("/")) {
/* 156 */         return request.getContextPath() + url;
/*     */       }
/* 158 */       return url;
/*     */     } 
/* 160 */     if (!context.startsWith("/") || !url.startsWith("/")) {
/* 161 */       throw new JspTagException(Resources.getMessage("IMPORT_BAD_RELATIVE"));
/*     */     }
/*     */     
/* 164 */     if (context.equals("/"))
/*     */     {
/*     */ 
/*     */       
/* 168 */       return url;
/*     */     }
/* 170 */     return context + url;
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\common\core\UrlSupport.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */