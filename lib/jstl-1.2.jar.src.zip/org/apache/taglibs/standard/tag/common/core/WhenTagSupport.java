/*    */ package org.apache.taglibs.standard.tag.common.core;
/*    */ 
/*    */ import javax.servlet.jsp.JspException;
/*    */ import javax.servlet.jsp.JspTagException;
/*    */ import javax.servlet.jsp.jstl.core.ConditionalTagSupport;
/*    */ import javax.servlet.jsp.tagext.Tag;
/*    */ import org.apache.taglibs.standard.resources.Resources;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class WhenTagSupport
/*    */   extends ConditionalTagSupport
/*    */ {
/*    */   public int doStartTag() throws JspException {
/*    */     Tag parent;
/* 65 */     if (!(parent = getParent() instanceof ChooseTag)) {
/* 66 */       throw new JspTagException(Resources.getMessage("WHEN_OUTSIDE_CHOOSE"));
/*    */     }
/*    */ 
/*    */     
/* 70 */     if (!((ChooseTag)parent).gainPermission()) {
/* 71 */       return 0;
/*    */     }
/*    */     
/* 74 */     if (condition()) {
/* 75 */       ((ChooseTag)parent).subtagSucceeded();
/* 76 */       return 1;
/*    */     } 
/* 78 */     return 0;
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\common\core\WhenTagSupport.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */