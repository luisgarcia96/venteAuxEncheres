/*     */ package org.apache.taglibs.standard.tag.common.fmt;
/*     */ 
/*     */ import java.util.TimeZone;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.jstl.core.Config;
/*     */ import javax.servlet.jsp.tagext.TagSupport;
/*     */ import org.apache.taglibs.standard.tag.common.core.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SetTimeZoneSupport
/*     */   extends TagSupport
/*     */ {
/*     */   protected Object value;
/*     */   private int scope;
/*     */   private String var;
/*     */   
/*     */   public SetTimeZoneSupport() {
/*  65 */     init();
/*     */   }
/*     */ 
/*     */   
/*     */   private void init() {
/*  70 */     this.value = this.var = null;
/*  71 */     this.scope = 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setScope(String scope) {
/*  79 */     this.scope = Util.getScope(scope);
/*     */   }
/*     */   
/*     */   public void setVar(String var) {
/*  83 */     this.var = var;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doEndTag() throws JspException {
/*  91 */     TimeZone timeZone = null;
/*     */     
/*  93 */     if (this.value == null) {
/*  94 */       timeZone = TimeZone.getTimeZone("GMT");
/*  95 */     } else if (this.value instanceof String) {
/*  96 */       if (((String)this.value).trim().equals("")) {
/*  97 */         timeZone = TimeZone.getTimeZone("GMT");
/*     */       } else {
/*  99 */         timeZone = TimeZone.getTimeZone((String)this.value);
/*     */       } 
/*     */     } else {
/* 102 */       timeZone = (TimeZone)this.value;
/*     */     } 
/*     */     
/* 105 */     if (this.var != null) {
/* 106 */       this.pageContext.setAttribute(this.var, timeZone, this.scope);
/*     */     } else {
/* 108 */       Config.set(this.pageContext, "javax.servlet.jsp.jstl.fmt.timeZone", timeZone, this.scope);
/*     */     } 
/*     */     
/* 111 */     return 6;
/*     */   }
/*     */ 
/*     */   
/*     */   public void release() {
/* 116 */     init();
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\common\fmt\SetTimeZoneSupport.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */