/*     */ package org.apache.taglibs.standard.tag.common.xml;
/*     */ 
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.JspTagException;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import javax.servlet.jsp.tagext.BodyTagSupport;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.transform.TransformerConfigurationException;
/*     */ import javax.xml.transform.TransformerFactory;
/*     */ import javax.xml.transform.dom.DOMResult;
/*     */ import javax.xml.transform.sax.SAXTransformerFactory;
/*     */ import javax.xml.transform.sax.TransformerHandler;
/*     */ import org.apache.taglibs.standard.resources.Resources;
/*     */ import org.apache.taglibs.standard.tag.common.core.ImportSupport;
/*     */ import org.apache.taglibs.standard.tag.common.core.Util;
/*     */ import org.w3c.dom.Document;
/*     */ import org.xml.sax.EntityResolver;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.XMLFilter;
/*     */ import org.xml.sax.XMLReader;
/*     */ import org.xml.sax.helpers.XMLReaderFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ParseSupport
/*     */   extends BodyTagSupport
/*     */ {
/*     */   protected Object xml;
/*     */   protected String systemId;
/*     */   protected XMLFilter filter;
/*     */   private String var;
/*     */   private String varDom;
/*     */   private int scope;
/*     */   private int scopeDom;
/*     */   private DocumentBuilderFactory dbf;
/*     */   private DocumentBuilder db;
/*     */   private TransformerFactory tf;
/*     */   private TransformerHandler th;
/*     */   
/*     */   public ParseSupport() {
/*  93 */     init();
/*     */   }
/*     */   
/*     */   private void init() {
/*  97 */     this.var = this.varDom = null;
/*  98 */     this.xml = null;
/*  99 */     this.systemId = null;
/* 100 */     this.filter = null;
/* 101 */     this.dbf = null;
/* 102 */     this.db = null;
/* 103 */     this.tf = null;
/* 104 */     this.th = null;
/* 105 */     this.scope = 1;
/* 106 */     this.scopeDom = 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doEndTag() throws JspException {
/*     */     try {
/*     */       Document d;
/* 118 */       if (this.dbf == null) {
/* 119 */         this.dbf = DocumentBuilderFactory.newInstance();
/* 120 */         this.dbf.setNamespaceAware(true);
/* 121 */         this.dbf.setValidating(false);
/*     */       } 
/* 123 */       this.db = this.dbf.newDocumentBuilder();
/*     */ 
/*     */       
/* 126 */       if (this.filter != null) {
/* 127 */         if (this.tf == null)
/* 128 */           this.tf = TransformerFactory.newInstance(); 
/* 129 */         if (!this.tf.getFeature("http://javax.xml.transform.sax.SAXTransformerFactory/feature")) {
/* 130 */           throw new JspTagException(Resources.getMessage("PARSE_NO_SAXTRANSFORMER"));
/*     */         }
/* 132 */         SAXTransformerFactory stf = (SAXTransformerFactory)this.tf;
/* 133 */         this.th = stf.newTransformerHandler();
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 138 */       Object xmlText = this.xml;
/* 139 */       if (xmlText == null)
/*     */       {
/* 141 */         if (this.bodyContent != null && this.bodyContent.getString() != null) {
/* 142 */           xmlText = this.bodyContent.getString().trim();
/*     */         } else {
/* 144 */           xmlText = "";
/*     */         }  } 
/* 146 */       if (xmlText instanceof String) {
/* 147 */         d = parseStringWithFilter((String)xmlText, this.filter);
/* 148 */       } else if (xmlText instanceof Reader) {
/* 149 */         d = parseReaderWithFilter((Reader)xmlText, this.filter);
/*     */       } else {
/* 151 */         throw new JspTagException(Resources.getMessage("PARSE_INVALID_SOURCE"));
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 156 */       if (this.var != null)
/* 157 */         this.pageContext.setAttribute(this.var, d, this.scope); 
/* 158 */       if (this.varDom != null) {
/* 159 */         this.pageContext.setAttribute(this.varDom, d, this.scopeDom);
/*     */       }
/* 161 */       return 6;
/* 162 */     } catch (SAXException ex) {
/* 163 */       Document d; throw new JspException(d);
/* 164 */     } catch (IOException ex) {
/* 165 */       throw new JspException(ex);
/* 166 */     } catch (ParserConfigurationException ex) {
/* 167 */       throw new JspException(ex);
/* 168 */     } catch (TransformerConfigurationException ex) {
/* 169 */       throw new JspException(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void release() {
/* 175 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Document parseInputSourceWithFilter(InputSource s, XMLFilter f) throws SAXException, IOException {
/* 185 */     if (f != null) {
/*     */       
/* 187 */       Document o = this.db.newDocument();
/*     */ 
/*     */       
/* 190 */       this.th.setResult(new DOMResult(o));
/* 191 */       XMLReader xr = XMLReaderFactory.createXMLReader();
/* 192 */       xr.setEntityResolver(new JstlEntityResolver(this.pageContext));
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 197 */       f.setParent(xr);
/* 198 */       f.setContentHandler(this.th);
/* 199 */       f.parse(s);
/* 200 */       return o;
/*     */     } 
/* 202 */     return parseInputSource(s);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Document parseReaderWithFilter(Reader r, XMLFilter f) throws SAXException, IOException {
/* 208 */     return parseInputSourceWithFilter(new InputSource(r), f);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Document parseStringWithFilter(String s, XMLFilter f) throws SAXException, IOException {
/* 214 */     StringReader r = new StringReader(s);
/* 215 */     return parseReaderWithFilter(r, f);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Document parseURLWithFilter(String url, XMLFilter f) throws SAXException, IOException {
/* 221 */     return parseInputSourceWithFilter(new InputSource(url), f);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Document parseInputSource(InputSource s) throws SAXException, IOException {
/* 227 */     this.db.setEntityResolver(new JstlEntityResolver(this.pageContext));
/*     */ 
/*     */     
/* 230 */     if (this.systemId == null) {
/* 231 */       s.setSystemId("jstl:");
/* 232 */     } else if (ImportSupport.isAbsoluteUrl(this.systemId)) {
/* 233 */       s.setSystemId(this.systemId);
/*     */     } else {
/* 235 */       s.setSystemId("jstl:" + this.systemId);
/* 236 */     }  return this.db.parse(s);
/*     */   }
/*     */ 
/*     */   
/*     */   private Document parseReader(Reader r) throws SAXException, IOException {
/* 241 */     return parseInputSource(new InputSource(r));
/*     */   }
/*     */ 
/*     */   
/*     */   private Document parseString(String s) throws SAXException, IOException {
/* 246 */     StringReader r = new StringReader(s);
/* 247 */     return parseReader(r);
/*     */   }
/*     */ 
/*     */   
/*     */   private Document parseURL(String url) throws SAXException, IOException {
/* 252 */     return parseInputSource(new InputSource(url));
/*     */   }
/*     */ 
/*     */   
/*     */   public static class JstlEntityResolver
/*     */     implements EntityResolver
/*     */   {
/*     */     private final PageContext ctx;
/*     */     
/*     */     public JstlEntityResolver(PageContext ctx) {
/* 262 */       this.ctx = ctx;
/*     */     }
/*     */ 
/*     */     
/*     */     public InputSource resolveEntity(String publicId, String systemId) throws FileNotFoundException {
/*     */       InputStream s;
/* 268 */       if (systemId == null) {
/* 269 */         return null;
/*     */       }
/*     */       
/* 272 */       if (systemId.startsWith("jstl:")) {
/* 273 */         systemId = systemId.substring(5);
/*     */       }
/*     */       
/* 276 */       if (ImportSupport.isAbsoluteUrl(systemId)) {
/* 277 */         return null;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 283 */       if (systemId.startsWith("/")) {
/* 284 */         s = this.ctx.getServletContext().getResourceAsStream(systemId);
/* 285 */         if (s == null) {
/* 286 */           throw new FileNotFoundException(Resources.getMessage("UNABLE_TO_RESOLVE_ENTITY", systemId));
/*     */         }
/*     */       } else {
/*     */         
/* 290 */         String pagePath = ((HttpServletRequest)this.ctx.getRequest()).getServletPath();
/*     */         
/* 292 */         String basePath = pagePath.substring(0, pagePath.lastIndexOf("/"));
/*     */         
/* 294 */         s = this.ctx.getServletContext().getResourceAsStream(basePath + "/" + systemId);
/*     */         
/* 296 */         if (s == null) {
/* 297 */           throw new FileNotFoundException(Resources.getMessage("UNABLE_TO_RESOLVE_ENTITY", systemId));
/*     */         }
/*     */       } 
/*     */       
/* 301 */       return new InputSource(s);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVar(String var) {
/* 309 */     this.var = var;
/*     */   }
/*     */   
/*     */   public void setVarDom(String varDom) {
/* 313 */     this.varDom = varDom;
/*     */   }
/*     */   
/*     */   public void setScope(String scope) {
/* 317 */     this.scope = Util.getScope(scope);
/*     */   }
/*     */   
/*     */   public void setScopeDom(String scopeDom) {
/* 321 */     this.scopeDom = Util.getScope(scopeDom);
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\common\xml\ParseSupport.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */