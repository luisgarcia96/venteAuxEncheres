/*     */ package org.apache.taglibs.standard.tag.common.fmt;
/*     */ 
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.JspTagException;
/*     */ import javax.servlet.jsp.tagext.BodyTagSupport;
/*     */ import javax.servlet.jsp.tagext.Tag;
/*     */ import org.apache.taglibs.standard.resources.Resources;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ParamSupport
/*     */   extends BodyTagSupport
/*     */ {
/*     */   protected Object value;
/*     */   protected boolean valueSpecified;
/*     */   
/*     */   public ParamSupport() {
/*  58 */     init();
/*     */   }
/*     */   
/*     */   private void init() {
/*  62 */     this.value = null;
/*  63 */     this.valueSpecified = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doEndTag() throws JspException {
/*  72 */     Tag t = findAncestorWithClass((Tag)this, MessageSupport.class);
/*  73 */     if (t == null) {
/*  74 */       throw new JspTagException(Resources.getMessage("PARAM_OUTSIDE_MESSAGE"));
/*     */     }
/*     */     
/*  77 */     MessageSupport parent = (MessageSupport)t;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  84 */     Object input = null;
/*     */     
/*  86 */     if (this.valueSpecified) {
/*     */       
/*  88 */       input = this.value;
/*     */     }
/*     */     else {
/*     */       
/*  92 */       input = this.bodyContent.getString().trim();
/*     */     } 
/*  94 */     parent.addParam(input);
/*     */     
/*  96 */     return 6;
/*     */   }
/*     */ 
/*     */   
/*     */   public void release() {
/* 101 */     init();
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\common\fmt\ParamSupport.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */