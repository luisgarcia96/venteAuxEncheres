/*     */ package org.apache.taglibs.standard.tag.common.fmt;
/*     */ 
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.jstl.core.Config;
/*     */ import javax.servlet.jsp.jstl.fmt.LocalizationContext;
/*     */ import javax.servlet.jsp.tagext.TagSupport;
/*     */ import org.apache.taglibs.standard.tag.common.core.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SetBundleSupport
/*     */   extends TagSupport
/*     */ {
/*     */   protected String basename;
/*     */   private int scope;
/*     */   private String var;
/*     */   
/*     */   public SetBundleSupport() {
/*  64 */     init();
/*     */   }
/*     */   
/*     */   private void init() {
/*  68 */     this.basename = null;
/*  69 */     this.scope = 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVar(String var) {
/*  77 */     this.var = var;
/*     */   }
/*     */   
/*     */   public void setScope(String scope) {
/*  81 */     this.scope = Util.getScope(scope);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doEndTag() throws JspException {
/*  89 */     LocalizationContext locCtxt = BundleSupport.getLocalizationContext(this.pageContext, this.basename);
/*     */ 
/*     */     
/*  92 */     if (this.var != null) {
/*  93 */       this.pageContext.setAttribute(this.var, locCtxt, this.scope);
/*     */     } else {
/*  95 */       Config.set(this.pageContext, "javax.servlet.jsp.jstl.fmt.localizationContext", locCtxt, this.scope);
/*     */     } 
/*     */ 
/*     */     
/*  99 */     return 6;
/*     */   }
/*     */ 
/*     */   
/*     */   public void release() {
/* 104 */     init();
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\common\fmt\SetBundleSupport.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */