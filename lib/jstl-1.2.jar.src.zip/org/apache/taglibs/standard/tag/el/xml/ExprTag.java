/*     */ package org.apache.taglibs.standard.tag.el.xml;
/*     */ 
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.tagext.Tag;
/*     */ import org.apache.taglibs.standard.tag.common.xml.ExprSupport;
/*     */ import org.apache.taglibs.standard.tag.el.core.ExpressionUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExprTag
/*     */   extends ExprSupport
/*     */ {
/*     */   private String escapeXml_;
/*     */   
/*     */   public ExprTag() {
/*  57 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doStartTag() throws JspException {
/*  68 */     evaluateExpressions();
/*     */ 
/*     */     
/*  71 */     return super.doStartTag();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void release() {
/*  77 */     super.release();
/*  78 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEscapeXml(String escapeXml_) {
/*  87 */     this.escapeXml_ = escapeXml_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void init() {
/*  97 */     this.escapeXml_ = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void evaluateExpressions() throws JspException {
/* 110 */     if (this.escapeXml_ != null) {
/* 111 */       Boolean b = (Boolean)ExpressionUtil.evalNotNull("out", "escapeXml", this.escapeXml_, Boolean.class, (Tag)this, this.pageContext);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 118 */       if (b == null) {
/* 119 */         this.escapeXml = false;
/*     */       } else {
/* 121 */         this.escapeXml = b.booleanValue();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\el\xml\ExprTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */