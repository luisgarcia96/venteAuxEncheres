/*     */ package org.apache.taglibs.standard.tag.el.core;
/*     */ 
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.tagext.Tag;
/*     */ import org.apache.taglibs.standard.tag.common.core.NullAttributeException;
/*     */ import org.apache.taglibs.standard.tag.common.core.OutSupport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OutTag
/*     */   extends OutSupport
/*     */ {
/*     */   private String value_;
/*     */   private String default_;
/*     */   private String escapeXml_;
/*     */   
/*     */   public OutTag() {
/*  55 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doStartTag() throws JspException {
/*  66 */     evaluateExpressions();
/*     */ 
/*     */     
/*  69 */     return super.doStartTag();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void release() {
/*  75 */     super.release();
/*  76 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(String value_) {
/*  84 */     this.value_ = value_;
/*     */   }
/*     */   
/*     */   public void setDefault(String default_) {
/*  88 */     this.default_ = default_;
/*     */   }
/*     */   
/*     */   public void setEscapeXml(String escapeXml_) {
/*  92 */     this.escapeXml_ = escapeXml_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void init() {
/* 102 */     this.value_ = this.default_ = this.escapeXml_ = null;
/*     */   }
/*     */ 
/*     */   
/*     */   private void evaluateExpressions() throws JspException {
/*     */     try {
/* 108 */       this.value = ExpressionUtil.evalNotNull("out", "value", this.value_, Object.class, (Tag)this, this.pageContext);
/*     */     }
/* 110 */     catch (NullAttributeException ex) {
/*     */       
/* 112 */       this.value = null;
/*     */     } 
/*     */     try {
/* 115 */       this.def = (String)ExpressionUtil.evalNotNull("out", "default", this.default_, String.class, (Tag)this, this.pageContext);
/*     */     }
/* 117 */     catch (NullAttributeException ex) {
/*     */       
/* 119 */       this.def = null;
/*     */     } 
/* 121 */     this.escapeXml = true;
/* 122 */     Boolean escape = (Boolean)ExpressionUtil.evalNotNull("out", "escapeXml", this.escapeXml_, Boolean.class, (Tag)this, this.pageContext);
/*     */     
/* 124 */     if (escape != null)
/* 125 */       this.escapeXml = escape.booleanValue(); 
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\el\core\OutTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */