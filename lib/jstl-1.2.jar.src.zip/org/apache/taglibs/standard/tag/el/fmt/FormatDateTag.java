/*     */ package org.apache.taglibs.standard.tag.el.fmt;
/*     */ 
/*     */ import java.util.Date;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.tagext.Tag;
/*     */ import org.apache.taglibs.standard.lang.support.ExpressionEvaluatorManager;
/*     */ import org.apache.taglibs.standard.tag.common.fmt.FormatDateSupport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormatDateTag
/*     */   extends FormatDateSupport
/*     */ {
/*     */   private String value_;
/*     */   private String type_;
/*     */   private String dateStyle_;
/*     */   private String timeStyle_;
/*     */   private String pattern_;
/*     */   private String timeZone_;
/*     */   
/*     */   public FormatDateTag() {
/*  65 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doStartTag() throws JspException {
/*  76 */     evaluateExpressions();
/*     */ 
/*     */     
/*  79 */     return super.doStartTag();
/*     */   }
/*     */ 
/*     */   
/*     */   public void release() {
/*  84 */     super.release();
/*  85 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(String value_) {
/*  94 */     this.value_ = value_;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setType(String type_) {
/*  99 */     this.type_ = type_;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDateStyle(String dateStyle_) {
/* 104 */     this.dateStyle_ = dateStyle_;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTimeStyle(String timeStyle_) {
/* 109 */     this.timeStyle_ = timeStyle_;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPattern(String pattern_) {
/* 114 */     this.pattern_ = pattern_;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTimeZone(String timeZone_) {
/* 119 */     this.timeZone_ = timeZone_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void init() {
/* 129 */     this.value_ = this.type_ = this.dateStyle_ = this.timeStyle_ = this.pattern_ = this.timeZone_ = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void evaluateExpressions() throws JspException {
/* 143 */     this.value = (Date)ExpressionEvaluatorManager.evaluate("value", this.value_, Date.class, (Tag)this, this.pageContext);
/*     */ 
/*     */ 
/*     */     
/* 147 */     if (this.type_ != null) {
/* 148 */       this.type = (String)ExpressionEvaluatorManager.evaluate("type", this.type_, String.class, (Tag)this, this.pageContext);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 153 */     if (this.dateStyle_ != null) {
/* 154 */       this.dateStyle = (String)ExpressionEvaluatorManager.evaluate("dateStyle", this.dateStyle_, String.class, (Tag)this, this.pageContext);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 159 */     if (this.timeStyle_ != null) {
/* 160 */       this.timeStyle = (String)ExpressionEvaluatorManager.evaluate("timeStyle", this.timeStyle_, String.class, (Tag)this, this.pageContext);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 165 */     if (this.pattern_ != null) {
/* 166 */       this.pattern = (String)ExpressionEvaluatorManager.evaluate("pattern", this.pattern_, String.class, (Tag)this, this.pageContext);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 171 */     if (this.timeZone_ != null)
/* 172 */       this.timeZone = ExpressionEvaluatorManager.evaluate("timeZone", this.timeZone_, Object.class, (Tag)this, this.pageContext); 
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\el\fmt\FormatDateTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */