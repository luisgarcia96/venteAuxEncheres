/*     */ package org.apache.taglibs.standard.tag.el.core;
/*     */ 
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.jstl.core.LoopTag;
/*     */ import javax.servlet.jsp.tagext.IterationTag;
/*     */ import javax.servlet.jsp.tagext.Tag;
/*     */ import org.apache.taglibs.standard.lang.support.ExpressionEvaluatorManager;
/*     */ import org.apache.taglibs.standard.tag.common.core.ForTokensSupport;
/*     */ import org.apache.taglibs.standard.tag.common.core.NullAttributeException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ForTokensTag
/*     */   extends ForTokensSupport
/*     */   implements LoopTag, IterationTag
/*     */ {
/*     */   private String begin_;
/*     */   private String end_;
/*     */   private String step_;
/*     */   private String items_;
/*     */   private String delims_;
/*     */   
/*     */   public ForTokensTag() {
/*  62 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doStartTag() throws JspException {
/*  73 */     evaluateExpressions();
/*     */ 
/*     */     
/*  76 */     return super.doStartTag();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void release() {
/*  82 */     super.release();
/*  83 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBegin(String begin_) {
/*  92 */     this.begin_ = begin_;
/*  93 */     this.beginSpecified = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setEnd(String end_) {
/*  98 */     this.end_ = end_;
/*  99 */     this.endSpecified = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setStep(String step_) {
/* 104 */     this.step_ = step_;
/* 105 */     this.stepSpecified = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setItems(String items_) {
/* 110 */     this.items_ = items_;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDelims(String delims_) {
/* 115 */     this.delims_ = delims_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void init() {
/* 125 */     this.begin_ = null;
/* 126 */     this.end_ = null;
/* 127 */     this.step_ = null;
/* 128 */     this.items_ = null;
/* 129 */     this.delims_ = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void evaluateExpressions() throws JspException {
/* 142 */     if (this.begin_ != null) {
/* 143 */       Object r = ExpressionEvaluatorManager.evaluate("begin", this.begin_, Integer.class, (Tag)this, this.pageContext);
/*     */       
/* 145 */       if (r == null)
/* 146 */         throw new NullAttributeException("forTokens", "begin"); 
/* 147 */       this.begin = ((Integer)r).intValue();
/* 148 */       validateBegin();
/*     */     } 
/*     */     
/* 151 */     if (this.end_ != null) {
/* 152 */       Object r = ExpressionEvaluatorManager.evaluate("end", this.end_, Integer.class, (Tag)this, this.pageContext);
/*     */       
/* 154 */       if (r == null)
/* 155 */         throw new NullAttributeException("forTokens", "end"); 
/* 156 */       this.end = ((Integer)r).intValue();
/* 157 */       validateEnd();
/*     */     } 
/*     */     
/* 160 */     if (this.step_ != null) {
/* 161 */       Object r = ExpressionEvaluatorManager.evaluate("step", this.step_, Integer.class, (Tag)this, this.pageContext);
/*     */       
/* 163 */       if (r == null)
/* 164 */         throw new NullAttributeException("forTokens", "step"); 
/* 165 */       this.step = ((Integer)r).intValue();
/* 166 */       validateStep();
/*     */     } 
/*     */     
/* 169 */     if (this.items_ != null) {
/* 170 */       this.items = ExpressionEvaluatorManager.evaluate("items", this.items_, String.class, (Tag)this, this.pageContext);
/*     */ 
/*     */       
/* 173 */       if (this.items == null) {
/* 174 */         this.items = "";
/*     */       }
/*     */     } 
/* 177 */     if (this.delims_ != null) {
/* 178 */       this.delims = (String)ExpressionEvaluatorManager.evaluate("delims", this.delims_, String.class, (Tag)this, this.pageContext);
/*     */ 
/*     */       
/* 181 */       if (this.delims == null)
/* 182 */         this.delims = ""; 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\el\core\ForTokensTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */