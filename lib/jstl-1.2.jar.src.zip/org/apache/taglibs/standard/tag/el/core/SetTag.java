/*     */ package org.apache.taglibs.standard.tag.el.core;
/*     */ 
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.tagext.Tag;
/*     */ import org.apache.taglibs.standard.tag.common.core.NullAttributeException;
/*     */ import org.apache.taglibs.standard.tag.common.core.SetSupport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SetTag
/*     */   extends SetSupport
/*     */ {
/*     */   private String value_;
/*     */   private String target_;
/*     */   private String property_;
/*     */   
/*     */   public SetTag() {
/*  55 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doStartTag() throws JspException {
/*  66 */     evaluateExpressions();
/*     */ 
/*     */     
/*  69 */     return super.doStartTag();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void release() {
/*  75 */     super.release();
/*  76 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(String value_) {
/*  84 */     this.value_ = value_;
/*  85 */     this.valueSpecified = true;
/*     */   }
/*     */   
/*     */   public void setTarget(String target_) {
/*  89 */     this.target_ = target_;
/*     */   }
/*     */   
/*     */   public void setProperty(String property_) {
/*  93 */     this.property_ = property_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void init() {
/* 103 */     this.value_ = this.target_ = this.property_ = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void evaluateExpressions() throws JspException {
/*     */     try {
/* 118 */       this.value = ExpressionUtil.evalNotNull("set", "value", this.value_, Object.class, (Tag)this, this.pageContext);
/*     */     }
/* 120 */     catch (NullAttributeException ex) {
/*     */       
/* 122 */       this.value = null;
/*     */     } 
/*     */ 
/*     */     
/* 126 */     this.target = ExpressionUtil.evalNotNull("set", "target", this.target_, Object.class, (Tag)this, this.pageContext);
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 131 */       this.property = (String)ExpressionUtil.evalNotNull("set", "property", this.property_, String.class, (Tag)this, this.pageContext);
/*     */     }
/* 133 */     catch (NullAttributeException ex) {
/*     */       
/* 135 */       this.property = null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\el\core\SetTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */