/*     */ package org.apache.taglibs.standard.tag.el.fmt;
/*     */ 
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.tagext.Tag;
/*     */ import org.apache.taglibs.standard.lang.support.ExpressionEvaluatorManager;
/*     */ import org.apache.taglibs.standard.tag.common.fmt.FormatNumberSupport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormatNumberTag
/*     */   extends FormatNumberSupport
/*     */ {
/*     */   private String value_;
/*     */   private String type_;
/*     */   private String pattern_;
/*     */   private String currencyCode_;
/*     */   private String currencySymbol_;
/*     */   private String groupingUsed_;
/*     */   private String maxIntegerDigits_;
/*     */   private String minIntegerDigits_;
/*     */   private String maxFractionDigits_;
/*     */   private String minFractionDigits_;
/*     */   
/*     */   public FormatNumberTag() {
/*  67 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doStartTag() throws JspException {
/*  78 */     evaluateExpressions();
/*     */ 
/*     */     
/*  81 */     return super.doStartTag();
/*     */   }
/*     */ 
/*     */   
/*     */   public void release() {
/*  86 */     super.release();
/*  87 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(String value_) {
/*  96 */     this.value_ = value_;
/*  97 */     this.valueSpecified = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setType(String type_) {
/* 102 */     this.type_ = type_;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPattern(String pattern_) {
/* 107 */     this.pattern_ = pattern_;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCurrencyCode(String currencyCode_) {
/* 112 */     this.currencyCode_ = currencyCode_;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCurrencySymbol(String currencySymbol_) {
/* 117 */     this.currencySymbol_ = currencySymbol_;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setGroupingUsed(String groupingUsed_) {
/* 122 */     this.groupingUsed_ = groupingUsed_;
/* 123 */     this.groupingUsedSpecified = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMaxIntegerDigits(String maxIntegerDigits_) {
/* 128 */     this.maxIntegerDigits_ = maxIntegerDigits_;
/* 129 */     this.maxIntegerDigitsSpecified = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMinIntegerDigits(String minIntegerDigits_) {
/* 134 */     this.minIntegerDigits_ = minIntegerDigits_;
/* 135 */     this.minIntegerDigitsSpecified = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMaxFractionDigits(String maxFractionDigits_) {
/* 140 */     this.maxFractionDigits_ = maxFractionDigits_;
/* 141 */     this.maxFractionDigitsSpecified = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMinFractionDigits(String minFractionDigits_) {
/* 146 */     this.minFractionDigits_ = minFractionDigits_;
/* 147 */     this.minFractionDigitsSpecified = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void init() {
/* 157 */     this.value_ = this.type_ = this.pattern_ = null;
/* 158 */     this.currencyCode_ = this.currencySymbol_ = null;
/* 159 */     this.groupingUsed_ = null;
/* 160 */     this.maxIntegerDigits_ = this.minIntegerDigits_ = null;
/* 161 */     this.maxFractionDigits_ = this.minFractionDigits_ = null;
/*     */   }
/*     */ 
/*     */   
/*     */   private void evaluateExpressions() throws JspException {
/* 166 */     Object obj = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 177 */     if (this.value_ != null) {
/* 178 */       this.value = ExpressionEvaluatorManager.evaluate("value", this.value_, Object.class, (Tag)this, this.pageContext);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 183 */     if (this.type_ != null) {
/* 184 */       this.type = (String)ExpressionEvaluatorManager.evaluate("type", this.type_, String.class, (Tag)this, this.pageContext);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 189 */     if (this.pattern_ != null) {
/* 190 */       this.pattern = (String)ExpressionEvaluatorManager.evaluate("pattern", this.pattern_, String.class, (Tag)this, this.pageContext);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 195 */     if (this.currencyCode_ != null) {
/* 196 */       this.currencyCode = (String)ExpressionEvaluatorManager.evaluate("currencyCode", this.currencyCode_, String.class, (Tag)this, this.pageContext);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 202 */     if (this.currencySymbol_ != null) {
/* 203 */       this.currencySymbol = (String)ExpressionEvaluatorManager.evaluate("currencySymbol", this.currencySymbol_, String.class, (Tag)this, this.pageContext);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 209 */     if (this.groupingUsed_ != null) {
/* 210 */       obj = ExpressionEvaluatorManager.evaluate("groupingUsed", this.groupingUsed_, Boolean.class, (Tag)this, this.pageContext);
/*     */ 
/*     */       
/* 213 */       if (obj != null) {
/* 214 */         this.isGroupingUsed = ((Boolean)obj).booleanValue();
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 219 */     if (this.maxIntegerDigits_ != null) {
/* 220 */       obj = ExpressionEvaluatorManager.evaluate("maxIntegerDigits", this.maxIntegerDigits_, Integer.class, (Tag)this, this.pageContext);
/*     */ 
/*     */       
/* 223 */       if (obj != null) {
/* 224 */         this.maxIntegerDigits = ((Integer)obj).intValue();
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 229 */     if (this.minIntegerDigits_ != null) {
/* 230 */       obj = ExpressionEvaluatorManager.evaluate("minIntegerDigits", this.minIntegerDigits_, Integer.class, (Tag)this, this.pageContext);
/*     */ 
/*     */       
/* 233 */       if (obj != null) {
/* 234 */         this.minIntegerDigits = ((Integer)obj).intValue();
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 239 */     if (this.maxFractionDigits_ != null) {
/* 240 */       obj = ExpressionEvaluatorManager.evaluate("maxFractionDigits", this.maxFractionDigits_, Integer.class, (Tag)this, this.pageContext);
/*     */ 
/*     */       
/* 243 */       if (obj != null) {
/* 244 */         this.maxFractionDigits = ((Integer)obj).intValue();
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 249 */     if (this.minFractionDigits_ != null) {
/* 250 */       obj = ExpressionEvaluatorManager.evaluate("minFractionDigits", this.minFractionDigits_, Integer.class, (Tag)this, this.pageContext);
/*     */ 
/*     */       
/* 253 */       if (obj != null)
/* 254 */         this.minFractionDigits = ((Integer)obj).intValue(); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\el\fmt\FormatNumberTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */