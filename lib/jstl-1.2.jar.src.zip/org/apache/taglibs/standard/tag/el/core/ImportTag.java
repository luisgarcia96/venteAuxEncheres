/*     */ package org.apache.taglibs.standard.tag.el.core;
/*     */ 
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.tagext.Tag;
/*     */ import org.apache.taglibs.standard.tag.common.core.ImportSupport;
/*     */ import org.apache.taglibs.standard.tag.common.core.NullAttributeException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImportTag
/*     */   extends ImportSupport
/*     */ {
/*     */   private String context_;
/*     */   private String charEncoding_;
/*     */   private String url_;
/*     */   
/*     */   public ImportTag() {
/*  60 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int doStartTag() throws JspException {
/*  71 */     evaluateExpressions();
/*     */ 
/*     */     
/*  74 */     return super.doStartTag();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void release() {
/*  80 */     super.release();
/*  81 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUrl(String url_) {
/*  90 */     this.url_ = url_;
/*     */   }
/*     */   
/*     */   public void setContext(String context_) {
/*  94 */     this.context_ = context_;
/*     */   }
/*     */   
/*     */   public void setCharEncoding(String charEncoding_) {
/*  98 */     this.charEncoding_ = charEncoding_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void init() {
/* 107 */     this.url_ = this.context_ = this.charEncoding_ = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void evaluateExpressions() throws JspException {
/* 120 */     this.url = (String)ExpressionUtil.evalNotNull("import", "url", this.url_, String.class, (Tag)this, this.pageContext);
/*     */     
/* 122 */     if (this.url == null || this.url.equals("")) {
/* 123 */       throw new NullAttributeException("import", "url");
/*     */     }
/* 125 */     this.context = (String)ExpressionUtil.evalNotNull("import", "context", this.context_, String.class, (Tag)this, this.pageContext);
/*     */     
/* 127 */     this.charEncoding = (String)ExpressionUtil.evalNotNull("import", "charEncoding", this.charEncoding_, String.class, (Tag)this, this.pageContext);
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\el\core\ImportTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */