/*    */ package org.apache.taglibs.standard.tag.el.core;
/*    */ 
/*    */ import javax.servlet.jsp.JspException;
/*    */ import javax.servlet.jsp.JspTagException;
/*    */ import javax.servlet.jsp.tagext.Tag;
/*    */ import org.apache.taglibs.standard.lang.support.ExpressionEvaluatorManager;
/*    */ import org.apache.taglibs.standard.tag.common.core.NullAttributeException;
/*    */ import org.apache.taglibs.standard.tag.common.core.WhenTagSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WhenTag
/*    */   extends WhenTagSupport
/*    */ {
/*    */   private String test;
/*    */   
/*    */   public WhenTag() {
/* 50 */     init();
/*    */   }
/*    */ 
/*    */   
/*    */   public void release() {
/* 55 */     super.release();
/* 56 */     init();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean condition() throws JspTagException {
/*    */     try {
/* 65 */       Object r = ExpressionEvaluatorManager.evaluate("test", this.test, Boolean.class, (Tag)this, this.pageContext);
/*    */       
/* 67 */       if (r == null) {
/* 68 */         throw new NullAttributeException("when", "test");
/*    */       }
/* 70 */       return ((Boolean)r).booleanValue();
/* 71 */     } catch (JspException ex) {
/* 72 */       throw new JspTagException(ex.toString(), ex);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setTest(String test) {
/* 88 */     this.test = test;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void init() {
/* 97 */     this.test = null;
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\el\core\WhenTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */