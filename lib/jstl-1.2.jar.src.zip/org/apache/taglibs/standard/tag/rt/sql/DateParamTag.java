/*    */ package org.apache.taglibs.standard.tag.rt.sql;
/*    */ 
/*    */ import java.util.Date;
/*    */ import org.apache.taglibs.standard.tag.common.sql.DateParamTagSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DateParamTag
/*    */   extends DateParamTagSupport
/*    */ {
/*    */   public void setValue(Date value) {
/* 39 */     this.value = value;
/*    */   }
/*    */   
/*    */   public void setType(String type) {
/* 43 */     this.type = type;
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\rt\sql\DateParamTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */