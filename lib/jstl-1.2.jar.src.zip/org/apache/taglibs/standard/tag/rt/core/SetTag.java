/*    */ package org.apache.taglibs.standard.tag.rt.core;
/*    */ 
/*    */ import org.apache.taglibs.standard.tag.common.core.SetSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SetTag
/*    */   extends SetSupport
/*    */ {
/*    */   public void setValue(Object value) {
/* 43 */     this.value = value;
/* 44 */     this.valueSpecified = true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setTarget(Object target) {
/* 49 */     this.target = target;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setProperty(String property) {
/* 54 */     this.property = property;
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\rt\core\SetTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */