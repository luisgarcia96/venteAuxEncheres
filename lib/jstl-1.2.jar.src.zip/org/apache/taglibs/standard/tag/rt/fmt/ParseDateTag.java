/*    */ package org.apache.taglibs.standard.tag.rt.fmt;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import javax.servlet.jsp.JspTagException;
/*    */ import org.apache.taglibs.standard.tag.common.fmt.ParseDateSupport;
/*    */ import org.apache.taglibs.standard.tag.common.fmt.SetLocaleSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParseDateTag
/*    */   extends ParseDateSupport
/*    */ {
/*    */   public void setValue(String value) throws JspTagException {
/* 49 */     this.value = value;
/* 50 */     this.valueSpecified = true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setType(String type) throws JspTagException {
/* 55 */     this.type = type;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setDateStyle(String dateStyle) throws JspTagException {
/* 60 */     this.dateStyle = dateStyle;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setTimeStyle(String timeStyle) throws JspTagException {
/* 65 */     this.timeStyle = timeStyle;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setPattern(String pattern) throws JspTagException {
/* 70 */     this.pattern = pattern;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setTimeZone(Object timeZone) throws JspTagException {
/* 75 */     this.timeZone = timeZone;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setParseLocale(Object loc) throws JspTagException {
/* 80 */     if (loc != null)
/* 81 */       if (loc instanceof Locale) {
/* 82 */         this.parseLocale = (Locale)loc;
/*    */       }
/* 84 */       else if (!"".equals(loc)) {
/* 85 */         this.parseLocale = SetLocaleSupport.parseLocale((String)loc);
/*    */       }  
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\rt\fmt\ParseDateTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */