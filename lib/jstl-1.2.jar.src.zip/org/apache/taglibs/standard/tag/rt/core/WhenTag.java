/*    */ package org.apache.taglibs.standard.tag.rt.core;
/*    */ 
/*    */ import org.apache.taglibs.standard.tag.common.core.WhenTagSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WhenTag
/*    */   extends WhenTagSupport
/*    */ {
/*    */   private boolean test;
/*    */   
/*    */   public WhenTag() {
/* 44 */     init();
/*    */   }
/*    */ 
/*    */   
/*    */   public void release() {
/* 49 */     super.release();
/* 50 */     init();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean condition() {
/* 58 */     return this.test;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setTest(boolean test) {
/* 73 */     this.test = test;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void init() {
/* 82 */     this.test = false;
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\rt\core\WhenTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */