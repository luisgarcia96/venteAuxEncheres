/*    */ package org.apache.taglibs.standard.tag.rt.sql;
/*    */ 
/*    */ import org.apache.taglibs.standard.tag.common.sql.SetDataSourceTagSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SetDataSourceTag
/*    */   extends SetDataSourceTagSupport
/*    */ {
/*    */   public void setDataSource(Object dataSource) {
/* 41 */     this.dataSource = dataSource;
/* 42 */     this.dataSourceSpecified = true;
/*    */   }
/*    */   
/*    */   public void setDriver(String driverClassName) {
/* 46 */     this.driverClassName = driverClassName;
/*    */   }
/*    */   
/*    */   public void setUrl(String jdbcURL) {
/* 50 */     this.jdbcURL = jdbcURL;
/*    */   }
/*    */   
/*    */   public void setUser(String userName) {
/* 54 */     this.userName = userName;
/*    */   }
/*    */   
/*    */   public void setPassword(String password) {
/* 58 */     this.password = password;
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\rt\sql\SetDataSourceTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */