/*    */ package org.apache.taglibs.standard.tag.rt.sql;
/*    */ 
/*    */ import org.apache.taglibs.standard.tag.common.sql.QueryTagSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class QueryTag
/*    */   extends QueryTagSupport
/*    */ {
/*    */   public void setDataSource(Object dataSource) {
/* 53 */     this.rawDataSource = dataSource;
/* 54 */     this.dataSourceSpecified = true;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setStartRow(int startRow) {
/* 62 */     this.startRow = startRow;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setMaxRows(int maxRows) {
/* 70 */     this.maxRows = maxRows;
/* 71 */     this.maxRowsSpecified = true;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setSql(String sql) {
/* 81 */     this.sql = sql;
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\rt\sql\QueryTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */