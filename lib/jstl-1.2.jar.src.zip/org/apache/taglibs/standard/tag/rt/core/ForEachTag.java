/*    */ package org.apache.taglibs.standard.tag.rt.core;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import javax.servlet.jsp.JspTagException;
/*    */ import javax.servlet.jsp.jstl.core.LoopTag;
/*    */ import javax.servlet.jsp.tagext.IterationTag;
/*    */ import org.apache.taglibs.standard.tag.common.core.ForEachSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ForEachTag
/*    */   extends ForEachSupport
/*    */   implements LoopTag, IterationTag
/*    */ {
/*    */   public void setBegin(int begin) throws JspTagException {
/* 53 */     this.beginSpecified = true;
/* 54 */     this.begin = begin;
/* 55 */     validateBegin();
/*    */   }
/*    */ 
/*    */   
/*    */   public void setEnd(int end) throws JspTagException {
/* 60 */     this.endSpecified = true;
/* 61 */     this.end = end;
/* 62 */     validateEnd();
/*    */   }
/*    */ 
/*    */   
/*    */   public void setStep(int step) throws JspTagException {
/* 67 */     this.stepSpecified = true;
/* 68 */     this.step = step;
/* 69 */     validateStep();
/*    */   }
/*    */ 
/*    */   
/*    */   public void setItems(Object o) throws JspTagException {
/* 74 */     if (o == null) {
/* 75 */       this.rawItems = new ArrayList();
/*    */     } else {
/* 77 */       this.rawItems = o;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\rt\core\ForEachTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */