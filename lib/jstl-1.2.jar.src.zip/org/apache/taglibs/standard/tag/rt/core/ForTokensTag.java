/*    */ package org.apache.taglibs.standard.tag.rt.core;
/*    */ 
/*    */ import javax.servlet.jsp.JspTagException;
/*    */ import javax.servlet.jsp.jstl.core.LoopTag;
/*    */ import javax.servlet.jsp.tagext.IterationTag;
/*    */ import org.apache.taglibs.standard.tag.common.core.ForTokensSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ForTokensTag
/*    */   extends ForTokensSupport
/*    */   implements LoopTag, IterationTag
/*    */ {
/*    */   public void setBegin(int begin) throws JspTagException {
/* 51 */     this.beginSpecified = true;
/* 52 */     this.begin = begin;
/* 53 */     validateBegin();
/*    */   }
/*    */ 
/*    */   
/*    */   public void setEnd(int end) throws JspTagException {
/* 58 */     this.endSpecified = true;
/* 59 */     this.end = end;
/* 60 */     validateEnd();
/*    */   }
/*    */ 
/*    */   
/*    */   public void setStep(int step) throws JspTagException {
/* 65 */     this.stepSpecified = true;
/* 66 */     this.step = step;
/* 67 */     validateStep();
/*    */   }
/*    */ 
/*    */   
/*    */   public void setItems(Object s) throws JspTagException {
/* 72 */     this.items = s;
/*    */     
/* 74 */     if (s == null) {
/* 75 */       this.items = "";
/*    */     }
/*    */   }
/*    */   
/*    */   public void setDelims(String s) throws JspTagException {
/* 80 */     this.delims = s;
/*    */     
/* 82 */     if (s == null)
/* 83 */       this.delims = ""; 
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\jstl-1.2.jar!\org\apache\taglibs\standard\tag\rt\core\ForTokensTag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */