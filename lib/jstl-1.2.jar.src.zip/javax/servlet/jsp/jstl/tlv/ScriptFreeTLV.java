/*     */ package javax.servlet.jsp.jstl.tlv;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Map;
/*     */ import javax.servlet.jsp.tagext.PageData;
/*     */ import javax.servlet.jsp.tagext.TagLibraryValidator;
/*     */ import javax.servlet.jsp.tagext.ValidationMessage;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.parsers.SAXParser;
/*     */ import javax.xml.parsers.SAXParserFactory;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ScriptFreeTLV
/*     */   extends TagLibraryValidator
/*     */ {
/*     */   private boolean allowDeclarations = false;
/*     */   private boolean allowScriptlets = false;
/*     */   private boolean allowExpressions = false;
/*     */   private boolean allowRTExpressions = false;
/*     */   private SAXParserFactory factory;
/*     */   
/*     */   public ScriptFreeTLV() {
/*  78 */     this.factory = SAXParserFactory.newInstance();
/*  79 */     this.factory.setValidating(false);
/*  80 */     this.factory.setNamespaceAware(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInitParameters(Map<String, Object> initParms) {
/*  89 */     super.setInitParameters(initParms);
/*  90 */     String declarationsParm = (String)initParms.get("allowDeclarations");
/*  91 */     String scriptletsParm = (String)initParms.get("allowScriptlets");
/*  92 */     String expressionsParm = (String)initParms.get("allowExpressions");
/*  93 */     String rtExpressionsParm = (String)initParms.get("allowRTExpressions");
/*     */     
/*  95 */     this.allowDeclarations = "true".equalsIgnoreCase(declarationsParm);
/*  96 */     this.allowScriptlets = "true".equalsIgnoreCase(scriptletsParm);
/*  97 */     this.allowExpressions = "true".equalsIgnoreCase(expressionsParm);
/*  98 */     this.allowRTExpressions = "true".equalsIgnoreCase(rtExpressionsParm);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValidationMessage[] validate(String prefix, String uri, PageData page) {
/* 114 */     InputStream in = null;
/*     */     
/* 116 */     MyContentHandler handler = new MyContentHandler(); try {
/*     */       SAXParser parser;
/* 118 */       synchronized (this.factory) {
/* 119 */         parser = this.factory.newSAXParser();
/*     */       } 
/* 121 */       in = page.getInputStream();
/* 122 */       parser.parse(in, handler);
/*     */     }
/* 124 */     catch (ParserConfigurationException e) {
/* 125 */       return vmFromString(e.toString());
/*     */     }
/* 127 */     catch (SAXException e) {
/* 128 */       return vmFromString(e.toString());
/*     */     }
/* 130 */     catch (IOException e) {
/* 131 */       return vmFromString(e.toString());
/*     */     } finally {
/*     */       
/* 134 */       if (in != null) try { in.close(); } catch (IOException e) {} 
/*     */     } 
/* 136 */     return handler.reportResults();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class MyContentHandler
/*     */     extends DefaultHandler
/*     */   {
/* 145 */     private int declarationCount = 0;
/* 146 */     private int scriptletCount = 0;
/* 147 */     private int expressionCount = 0;
/* 148 */     private int rtExpressionCount = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void startElement(String namespaceUri, String localName, String qualifiedName, Attributes atts) {
/* 164 */       if (!ScriptFreeTLV.this.allowDeclarations && qualifiedName.equals("jsp:declaration")) {
/*     */         
/* 166 */         this.declarationCount++;
/* 167 */       } else if (!ScriptFreeTLV.this.allowScriptlets && qualifiedName.equals("jsp:scriptlet")) {
/*     */         
/* 169 */         this.scriptletCount++;
/* 170 */       } else if (!ScriptFreeTLV.this.allowExpressions && qualifiedName.equals("jsp:expression")) {
/*     */         
/* 172 */         this.expressionCount++;
/* 173 */       }  if (!ScriptFreeTLV.this.allowRTExpressions) countRTExpressions(atts);
/*     */     
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void countRTExpressions(Attributes atts) {
/* 184 */       int stop = atts.getLength();
/* 185 */       for (int i = 0; i < stop; i++) {
/* 186 */         String attval = atts.getValue(i);
/* 187 */         if (attval.startsWith("%=") && attval.endsWith("%")) {
/* 188 */           this.rtExpressionCount++;
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ValidationMessage[] reportResults() {
/* 207 */       if (this.declarationCount + this.scriptletCount + this.expressionCount + this.rtExpressionCount > 0) {
/*     */         
/* 209 */         StringBuffer results = new StringBuffer("JSP page contains ");
/* 210 */         boolean first = true;
/* 211 */         if (this.declarationCount > 0) {
/* 212 */           results.append(Integer.toString(this.declarationCount));
/* 213 */           results.append(" declaration");
/* 214 */           if (this.declarationCount > 1) results.append('s'); 
/* 215 */           first = false;
/*     */         } 
/* 217 */         if (this.scriptletCount > 0) {
/* 218 */           if (!first) results.append(", "); 
/* 219 */           results.append(Integer.toString(this.scriptletCount));
/* 220 */           results.append(" scriptlet");
/* 221 */           if (this.scriptletCount > 1) results.append('s'); 
/* 222 */           first = false;
/*     */         } 
/* 224 */         if (this.expressionCount > 0) {
/* 225 */           if (!first) results.append(", "); 
/* 226 */           results.append(Integer.toString(this.expressionCount));
/* 227 */           results.append(" expression");
/* 228 */           if (this.expressionCount > 1) results.append('s'); 
/* 229 */           first = false;
/*     */         } 
/* 231 */         if (this.rtExpressionCount > 0) {
/* 232 */           if (!first) results.append(", "); 
/* 233 */           results.append(Integer.toString(this.rtExpressionCount));
/* 234 */           results.append(" request-time attribute value");
/* 235 */           if (this.rtExpressionCount > 1) results.append('s'); 
/* 236 */           first = false;
/*     */         } 
/* 238 */         results.append(".");
/* 239 */         return ScriptFreeTLV.vmFromString(results.toString());
/*     */       } 
/* 241 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     private MyContentHandler() {}
/*     */   }
/*     */   
/*     */   private static ValidationMessage[] vmFromString(String message) {
/* 249 */     return new ValidationMessage[] { new ValidationMessage(null, message) };
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\jstl-1.2.jar!\javax\servlet\jsp\jstl\tlv\ScriptFreeTLV.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */