/*     */ package microsoft.sql;
/*     */ 
/*     */ import java.io.InvalidObjectException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.Serializable;
/*     */ import java.math.BigDecimal;
/*     */ import java.sql.Timestamp;
/*     */ import java.time.LocalDateTime;
/*     */ import java.time.OffsetDateTime;
/*     */ import java.time.ZoneOffset;
/*     */ import java.util.Calendar;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DateTimeOffset
/*     */   implements Serializable, Comparable<DateTimeOffset>
/*     */ {
/*     */   private static final long serialVersionUID = 541973748553014280L;
/*     */   private final long utcMillis;
/*     */   private final int nanos;
/*     */   private final int minutesOffset;
/*     */   private static final int NANOS_MIN = 0;
/*     */   private static final int NANOS_MAX = 999999999;
/*     */   private static final int MINUTES_OFFSET_MIN = -840;
/*     */   private static final int MINUTES_OFFSET_MAX = 840;
/*     */   private static final int HUNDRED_NANOS_PER_SECOND = 10000000;
/*     */   
/*     */   private DateTimeOffset(Timestamp timestamp, int minutesOffset) {
/*  41 */     if (minutesOffset < -840 || minutesOffset > 840)
/*  42 */       throw new IllegalArgumentException(); 
/*  43 */     this.minutesOffset = minutesOffset;
/*     */ 
/*     */     
/*  46 */     int timestampNanos = timestamp.getNanos();
/*  47 */     if (timestampNanos < 0 || timestampNanos > 999999999) {
/*  48 */       throw new IllegalArgumentException();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  56 */     int hundredNanos = (timestampNanos + 50) / 100;
/*  57 */     this.nanos = 100 * hundredNanos % 10000000;
/*  58 */     this.utcMillis = timestamp.getTime() - (timestamp.getNanos() / 1000000) + (1000 * hundredNanos / 10000000);
/*     */ 
/*     */ 
/*     */     
/*  62 */     assert this.minutesOffset >= -840 && this.minutesOffset <= 840 : "minutesOffset: " + this.minutesOffset;
/*     */     
/*  64 */     assert this.nanos >= 0 && this.nanos <= 999999999 : "nanos: " + this.nanos;
/*  65 */     assert 0 == this.nanos % 100 : "nanos: " + this.nanos;
/*  66 */     assert 0L == this.utcMillis % 1000L : "utcMillis: " + this.utcMillis;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DateTimeOffset valueOf(Timestamp timestamp, int minutesOffset) {
/*  79 */     return new DateTimeOffset(timestamp, minutesOffset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DateTimeOffset valueOf(Timestamp timestamp, Calendar calendar) {
/*  96 */     calendar.setTimeInMillis(timestamp.getTime());
/*     */     
/*  98 */     return new DateTimeOffset(timestamp, (calendar
/*  99 */         .get(15) + calendar.get(16)) / 60000);
/*     */   }
/*     */   
/* 102 */   private String formattedValue = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 115 */     String result = this.formattedValue;
/* 116 */     if (null == result) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 124 */       String formattedOffset = (this.minutesOffset < 0) ? String.format(Locale.US, "-%1$02d:%2$02d", new Object[] { Integer.valueOf(-this.minutesOffset / 60), Integer.valueOf(-this.minutesOffset % 60) }) : String.format(Locale.US, "+%1$02d:%2$02d", new Object[] { Integer.valueOf(this.minutesOffset / 60), 
/* 125 */             Integer.valueOf(this.minutesOffset % 60) });
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 130 */       Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("GMT" + formattedOffset), Locale.US);
/*     */ 
/*     */       
/* 133 */       calendar.setTimeInMillis(this.utcMillis);
/*     */ 
/*     */ 
/*     */       
/* 137 */       assert this.nanos >= 0 && this.nanos <= 999999999;
/*     */ 
/*     */       
/* 140 */       this
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 146 */         .formattedValue = result = (0 == this.nanos) ? String.format(Locale.US, "%1$tF %1$tT %2$s", new Object[] { calendar, formattedOffset }) : String.format(Locale.US, "%1$tF %1$tT.%2$s %3$s", new Object[] { calendar, 
/*     */ 
/*     */ 
/*     */             
/* 150 */             BigDecimal.valueOf(this.nanos, 9)
/* 151 */             .stripTrailingZeros()
/* 152 */             .toPlainString()
/* 153 */             .substring(2), formattedOffset });
/*     */     } 
/*     */ 
/*     */     
/* 157 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 163 */     if (this == o) {
/* 164 */       return true;
/*     */     }
/*     */     
/* 167 */     if (!(o instanceof DateTimeOffset)) {
/* 168 */       return false;
/*     */     }
/* 170 */     DateTimeOffset other = (DateTimeOffset)o;
/* 171 */     return (this.utcMillis == other.utcMillis && this.nanos == other.nanos && this.minutesOffset == other.minutesOffset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 180 */     assert 0L == this.utcMillis % 1000L;
/* 181 */     long seconds = this.utcMillis / 1000L;
/*     */     
/* 183 */     int result = 571;
/* 184 */     result = 2011 * result + (int)seconds;
/* 185 */     result = 3217 * result + (int)(seconds / 60L * 60L * 24L * 365L);
/*     */ 
/*     */     
/* 188 */     result = 3919 * result + this.nanos / 100000;
/* 189 */     result = 4463 * result + this.nanos / 1000;
/* 190 */     result = 5227 * result + this.nanos;
/*     */ 
/*     */ 
/*     */     
/* 194 */     result = 6689 * result + this.minutesOffset;
/* 195 */     result = 7577 * result + this.minutesOffset / 60;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 200 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Timestamp getTimestamp() {
/* 212 */     Timestamp timestamp = new Timestamp(this.utcMillis);
/* 213 */     timestamp.setNanos(this.nanos);
/* 214 */     return timestamp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OffsetDateTime getOffsetDateTime() {
/* 223 */     ZoneOffset zoneOffset = ZoneOffset.ofTotalSeconds(60 * this.minutesOffset);
/* 224 */     LocalDateTime localDateTime = LocalDateTime.ofEpochSecond(this.utcMillis / 1000L, this.nanos, zoneOffset);
/*     */     
/* 226 */     return OffsetDateTime.of(localDateTime, zoneOffset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMinutesOffset() {
/* 235 */     return this.minutesOffset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(DateTimeOffset other) {
/* 254 */     assert this.nanos >= 0;
/* 255 */     assert other.nanos >= 0;
/*     */     
/* 257 */     return (this.utcMillis > other.utcMillis) ? 1 : ((this.utcMillis < other.utcMillis) ? -1 : (this.nanos - other.nanos));
/*     */   }
/*     */   
/*     */   private static class SerializationProxy
/*     */     implements Serializable {
/*     */     private final long utcMillis;
/*     */     private final int nanos;
/*     */     
/*     */     SerializationProxy(DateTimeOffset dateTimeOffset) {
/* 266 */       this.utcMillis = dateTimeOffset.utcMillis;
/* 267 */       this.nanos = dateTimeOffset.nanos;
/* 268 */       this.minutesOffset = dateTimeOffset.minutesOffset;
/*     */     }
/*     */     private final int minutesOffset;
/*     */     private static final long serialVersionUID = 664661379547314226L;
/*     */     
/*     */     private Object readResolve() {
/* 274 */       Timestamp timestamp = new Timestamp(this.utcMillis);
/* 275 */       timestamp.setNanos(this.nanos);
/* 276 */       return new DateTimeOffset(timestamp, this.minutesOffset);
/*     */     }
/*     */   }
/*     */   
/*     */   private Object writeReplace() {
/* 281 */     return new SerializationProxy(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream stream) throws InvalidObjectException {
/* 287 */     throw new InvalidObjectException("");
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\microsoft\sql\DateTimeOffset.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */