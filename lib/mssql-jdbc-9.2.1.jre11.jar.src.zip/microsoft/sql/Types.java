package microsoft.sql;

public final class Types {
  public static final int DATETIMEOFFSET = -155;
  
  public static final int STRUCTURED = -153;
  
  public static final int DATETIME = -151;
  
  public static final int SMALLDATETIME = -150;
  
  public static final int MONEY = -148;
  
  public static final int SMALLMONEY = -146;
  
  public static final int GUID = -145;
  
  public static final int SQL_VARIANT = -156;
  
  public static final int GEOMETRY = -157;
  
  public static final int GEOGRAPHY = -158;
}


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\microsoft\sql\Types.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */