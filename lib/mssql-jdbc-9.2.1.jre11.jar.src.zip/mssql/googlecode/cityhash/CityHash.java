/*     */ package mssql.googlecode.cityhash;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CityHash
/*     */ {
/*     */   private static final long k0 = -4348849565147123417L;
/*     */   private static final long k1 = -5435081209227447693L;
/*     */   private static final long k2 = -7286425919675154353L;
/*     */   private static final long k3 = -3942382747735136937L;
/*     */   private static final long kMul = -7070675565921424023L;
/*     */   
/*     */   private static long toLongLE(byte[] b, int i) {
/*  29 */     return (b[i + 7] << 56L) + ((b[i + 6] & 0xFF) << 48L) + ((b[i + 5] & 0xFF) << 40L) + ((b[i + 4] & 0xFF) << 32L) + ((b[i + 3] & 0xFF) << 24L) + ((b[i + 2] & 0xFF) << 16) + ((b[i + 1] & 0xFF) << 8) + ((b[i + 0] & 0xFF) << 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static int toIntLE(byte[] b, int i) {
/*  35 */     return ((b[i + 3] & 0xFF) << 24) + ((b[i + 2] & 0xFF) << 16) + ((b[i + 1] & 0xFF) << 8) + ((b[i + 0] & 0xFF) << 0);
/*     */   }
/*     */ 
/*     */   
/*     */   private static long fetch64(byte[] s, int pos) {
/*  40 */     return toLongLE(s, pos);
/*     */   }
/*     */ 
/*     */   
/*     */   private static int fetch32(byte[] s, int pos) {
/*  45 */     return toIntLE(s, pos);
/*     */   }
/*     */ 
/*     */   
/*     */   private static long rotate(long val, int shift) {
/*  50 */     return (shift == 0) ? val : (val >>> shift | val << 64 - shift);
/*     */   }
/*     */ 
/*     */   
/*     */   private static long rotateByAtLeast1(long val, int shift) {
/*  55 */     return val >>> shift | val << 64 - shift;
/*     */   }
/*     */   
/*     */   private static long shiftMix(long val) {
/*  59 */     return val ^ val >>> 47L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static long hash128to64(long u, long v) {
/*  66 */     long a = (u ^ v) * -7070675565921424023L;
/*  67 */     a ^= a >>> 47L;
/*  68 */     long b = (v ^ a) * -7070675565921424023L;
/*  69 */     b ^= b >>> 47L;
/*  70 */     b *= -7070675565921424023L;
/*  71 */     return b;
/*     */   }
/*     */ 
/*     */   
/*     */   private static long hashLen16(long u, long v) {
/*  76 */     return hash128to64(u, v);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static long hashLen0to16(byte[] s, int pos, int len) {
/*  82 */     if (len > 8) {
/*  83 */       long a = fetch64(s, pos + 0);
/*  84 */       long b = fetch64(s, pos + len - 8);
/*  85 */       return hashLen16(a, rotateByAtLeast1(b + len, len)) ^ b;
/*     */     } 
/*  87 */     if (len >= 4) {
/*  88 */       long a = 0xFFFFFFFFL & fetch32(s, pos + 0);
/*  89 */       return hashLen16((a << 3L) + len, 0xFFFFFFFFL & fetch32(s, pos + len - 4));
/*     */     } 
/*  91 */     if (len > 0) {
/*  92 */       int a = s[pos + 0] & 0xFF;
/*  93 */       int b = s[pos + (len >>> 1)] & 0xFF;
/*  94 */       int c = s[pos + len - 1] & 0xFF;
/*  95 */       int y = a + (b << 8);
/*  96 */       int z = len + (c << 2);
/*  97 */       return shiftMix(y * -7286425919675154353L ^ z * -3942382747735136937L) * -7286425919675154353L;
/*     */     } 
/*  99 */     return -7286425919675154353L;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static long hashLen17to32(byte[] s, int pos, int len) {
/* 105 */     long a = fetch64(s, pos + 0) * -5435081209227447693L;
/* 106 */     long b = fetch64(s, pos + 8);
/* 107 */     long c = fetch64(s, pos + len - 8) * -7286425919675154353L;
/* 108 */     long d = fetch64(s, pos + len - 16) * -4348849565147123417L;
/* 109 */     return hashLen16(rotate(a - b, 43) + rotate(c, 30) + d, a + rotate(b ^ 0xC949D7C7509E6557L, 20) - c + len);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static long[] weakHashLen32WithSeeds(long w, long x, long y, long z, long a, long b) {
/* 119 */     a += w;
/* 120 */     b = rotate(b + a + z, 21);
/* 121 */     long c = a;
/* 122 */     a += x;
/* 123 */     a += y;
/* 124 */     b += rotate(a, 44);
/* 125 */     return new long[] { a + z, b + c };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static long[] weakHashLen32WithSeeds(byte[] s, int pos, long a, long b) {
/* 132 */     return weakHashLen32WithSeeds(fetch64(s, pos + 0), fetch64(s, pos + 8), fetch64(s, pos + 16), fetch64(s, pos + 24), a, b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static long hashLen33to64(byte[] s, int pos, int len) {
/* 139 */     long z = fetch64(s, pos + 24);
/* 140 */     long a = fetch64(s, pos + 0) + (fetch64(s, pos + len - 16) + len) * -4348849565147123417L;
/* 141 */     long b = rotate(a + z, 52);
/* 142 */     long c = rotate(a, 37);
/*     */     
/* 144 */     a += fetch64(s, pos + 8);
/* 145 */     c += rotate(a, 7);
/* 146 */     a += fetch64(s, pos + 16);
/*     */     
/* 148 */     long vf = a + z;
/* 149 */     long vs = b + rotate(a, 31) + c;
/*     */     
/* 151 */     a = fetch64(s, pos + 16) + fetch64(s, pos + len - 32);
/* 152 */     z = fetch64(s, pos + len - 8);
/* 153 */     b = rotate(a + z, 52);
/* 154 */     c = rotate(a, 37);
/* 155 */     a += fetch64(s, pos + len - 24);
/* 156 */     c += rotate(a, 7);
/* 157 */     a += fetch64(s, pos + len - 16);
/*     */     
/* 159 */     long wf = a + z;
/* 160 */     long ws = b + rotate(a, 31) + c;
/* 161 */     long r = shiftMix((vf + ws) * -7286425919675154353L + (wf + vs) * -4348849565147123417L);
/*     */     
/* 163 */     return shiftMix(r * -4348849565147123417L + vs) * -7286425919675154353L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static long cityHash64(byte[] s, int pos, int len) {
/* 171 */     if (len <= 32) {
/* 172 */       if (len <= 16) {
/* 173 */         return hashLen0to16(s, pos, len);
/*     */       }
/*     */       
/* 176 */       return hashLen17to32(s, pos, len);
/*     */     } 
/*     */     
/* 179 */     if (len <= 64) {
/* 180 */       return hashLen33to64(s, pos, len);
/*     */     }
/*     */     
/* 183 */     long x = fetch64(s, pos + len - 40);
/* 184 */     long y = fetch64(s, pos + len - 16) + fetch64(s, pos + len - 56);
/* 185 */     long z = hashLen16(fetch64(s, pos + len - 48) + len, fetch64(s, pos + len - 24));
/*     */     
/* 187 */     long[] v = weakHashLen32WithSeeds(s, pos + len - 64, len, z);
/* 188 */     long[] w = weakHashLen32WithSeeds(s, pos + len - 32, y + -5435081209227447693L, x);
/* 189 */     x = x * -5435081209227447693L + fetch64(s, pos + 0);
/*     */     
/* 191 */     len = len - 1 & 0xFFFFFFC0;
/*     */     do {
/* 193 */       x = rotate(x + y + v[0] + fetch64(s, pos + 8), 37) * -5435081209227447693L;
/* 194 */       y = rotate(y + v[1] + fetch64(s, pos + 48), 42) * -5435081209227447693L;
/* 195 */       x ^= w[1];
/* 196 */       y += v[0] + fetch64(s, pos + 40);
/* 197 */       z = rotate(z + w[0], 33) * -5435081209227447693L;
/* 198 */       v = weakHashLen32WithSeeds(s, pos + 0, v[1] * -5435081209227447693L, x + w[0]);
/* 199 */       w = weakHashLen32WithSeeds(s, pos + 32, z + w[1], y + fetch64(s, pos + 16));
/*     */       
/* 201 */       long swap = z;
/* 202 */       z = x;
/* 203 */       x = swap;
/*     */       
/* 205 */       pos += 64;
/* 206 */       len -= 64;
/*     */     }
/* 208 */     while (len != 0);
/*     */     
/* 210 */     return hashLen16(hashLen16(v[0], w[0]) + shiftMix(y) * -5435081209227447693L + z, hashLen16(v[1], w[1]) + x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static long cityHash64WithSeed(byte[] s, int pos, int len, long seed) {
/* 218 */     return cityHash64WithSeeds(s, pos, len, -7286425919675154353L, seed);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static long cityHash64WithSeeds(byte[] s, int pos, int len, long seed0, long seed1) {
/* 226 */     return hashLen16(cityHash64(s, pos, len) - seed0, seed1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static long[] cityMurmur(byte[] s, int pos, int len, long seed0, long seed1) {
/* 235 */     long a = seed0;
/* 236 */     long b = seed1;
/* 237 */     long c = 0L;
/* 238 */     long d = 0L;
/*     */     
/* 240 */     int l = len - 16;
/* 241 */     if (l <= 0) {
/* 242 */       a = shiftMix(a * -5435081209227447693L) * -5435081209227447693L;
/* 243 */       c = b * -5435081209227447693L + hashLen0to16(s, pos, len);
/* 244 */       d = shiftMix(a + ((len >= 8) ? fetch64(s, pos + 0) : c));
/*     */     }
/*     */     else {
/*     */       
/* 248 */       c = hashLen16(fetch64(s, pos + len - 8) + -5435081209227447693L, a);
/* 249 */       d = hashLen16(b + len, c + fetch64(s, pos + len - 16));
/* 250 */       a += d;
/*     */       
/*     */       do {
/* 253 */         a ^= shiftMix(fetch64(s, pos + 0) * -5435081209227447693L) * -5435081209227447693L;
/* 254 */         a *= -5435081209227447693L;
/* 255 */         b ^= a;
/* 256 */         c ^= shiftMix(fetch64(s, pos + 8) * -5435081209227447693L) * -5435081209227447693L;
/* 257 */         c *= -5435081209227447693L;
/* 258 */         d ^= c;
/* 259 */         pos += 16;
/* 260 */         l -= 16;
/*     */       }
/* 262 */       while (l > 0);
/*     */     } 
/*     */     
/* 265 */     a = hashLen16(a, c);
/* 266 */     b = hashLen16(d, b);
/*     */     
/* 268 */     return new long[] { a ^ b, hashLen16(b, a) };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static long[] cityHash128WithSeed(byte[] s, int pos, int len, long seed0, long seed1) {
/* 278 */     if (len < 128) {
/* 279 */       return cityMurmur(s, pos, len, seed0, seed1);
/*     */     }
/*     */     
/* 282 */     long[] v = new long[2], w = new long[2];
/* 283 */     long x = seed0;
/* 284 */     long y = seed1;
/* 285 */     long z = -5435081209227447693L * len;
/*     */     
/* 287 */     v[0] = rotate(y ^ 0xB492B66FBE98F273L, 49) * -5435081209227447693L + fetch64(s, pos);
/* 288 */     v[1] = rotate(v[0], 42) * -5435081209227447693L + fetch64(s, pos + 8);
/* 289 */     w[0] = rotate(y + z, 35) * -5435081209227447693L + x;
/* 290 */     w[1] = rotate(x + fetch64(s, pos + 88), 53) * -5435081209227447693L;
/*     */     
/*     */     do {
/* 293 */       x = rotate(x + y + v[0] + fetch64(s, pos + 8), 37) * -5435081209227447693L;
/* 294 */       y = rotate(y + v[1] + fetch64(s, pos + 48), 42) * -5435081209227447693L;
/*     */       
/* 296 */       x ^= w[1];
/* 297 */       y += v[0] + fetch64(s, pos + 40);
/* 298 */       z = rotate(z + w[0], 33) * -5435081209227447693L;
/* 299 */       v = weakHashLen32WithSeeds(s, pos + 0, v[1] * -5435081209227447693L, x + w[0]);
/* 300 */       w = weakHashLen32WithSeeds(s, pos + 32, z + w[1], y + fetch64(s, pos + 16));
/*     */       
/* 302 */       long swap = z;
/* 303 */       z = x;
/* 304 */       x = swap;
/*     */       
/* 306 */       pos += 64;
/* 307 */       x = rotate(x + y + v[0] + fetch64(s, pos + 8), 37) * -5435081209227447693L;
/* 308 */       y = rotate(y + v[1] + fetch64(s, pos + 48), 42) * -5435081209227447693L;
/* 309 */       x ^= w[1];
/* 310 */       y += v[0] + fetch64(s, pos + 40);
/* 311 */       z = rotate(z + w[0], 33) * -5435081209227447693L;
/* 312 */       v = weakHashLen32WithSeeds(s, pos, v[1] * -5435081209227447693L, x + w[0]);
/* 313 */       w = weakHashLen32WithSeeds(s, pos + 32, z + w[1], y + fetch64(s, pos + 16));
/*     */       
/* 315 */       swap = z;
/* 316 */       z = x;
/* 317 */       x = swap;
/*     */       
/* 319 */       pos += 64;
/* 320 */       len -= 128;
/*     */     }
/* 322 */     while (len >= 128);
/*     */     
/* 324 */     x += rotate(v[0] + z, 49) * -4348849565147123417L;
/* 325 */     z += rotate(w[0], 37) * -4348849565147123417L;
/*     */     
/* 327 */     for (int tail_done = 0; tail_done < len; ) {
/* 328 */       tail_done += 32;
/* 329 */       y = rotate(x + y, 42) * -4348849565147123417L + v[1];
/* 330 */       w[0] = w[0] + fetch64(s, pos + len - tail_done + 16);
/* 331 */       x = x * -4348849565147123417L + w[0];
/* 332 */       z += w[1] + fetch64(s, pos + len - tail_done);
/* 333 */       w[1] = w[1] + v[0];
/* 334 */       v = weakHashLen32WithSeeds(s, pos + len - tail_done, v[0] + z, v[1]);
/*     */     } 
/*     */     
/* 337 */     x = hashLen16(x, v[0]);
/* 338 */     y = hashLen16(y + z, w[0]);
/*     */     
/* 340 */     return new long[] { hashLen16(x + v[1], w[1]) + y, hashLen16(x + w[1], y + v[1]) };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long[] cityHash128(byte[] s, int pos, int len) {
/* 348 */     if (len >= 16) {
/* 349 */       return cityHash128WithSeed(s, pos + 16, len - 16, fetch64(s, pos + 0) ^ 0xC949D7C7509E6557L, fetch64(s, pos + 8));
/*     */     }
/* 351 */     if (len >= 8) {
/* 352 */       return cityHash128WithSeed(new byte[0], 0, 0, fetch64(s, pos + 0) ^ len * -4348849565147123417L, fetch64(s, pos + len - 8) ^ 0xB492B66FBE98F273L);
/*     */     }
/*     */     
/* 355 */     return cityHash128WithSeed(s, pos, len, -4348849565147123417L, -5435081209227447693L);
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\mssql\googlecode\cityhash\CityHash.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */