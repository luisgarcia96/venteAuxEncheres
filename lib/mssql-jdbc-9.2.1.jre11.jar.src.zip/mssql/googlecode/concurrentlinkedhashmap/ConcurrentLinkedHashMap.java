/*      */ package mssql.googlecode.concurrentlinkedhashmap;
/*      */ 
/*      */ import java.io.InvalidObjectException;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.Serializable;
/*      */ import java.util.AbstractCollection;
/*      */ import java.util.AbstractMap;
/*      */ import java.util.AbstractQueue;
/*      */ import java.util.AbstractSet;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.Map;
/*      */ import java.util.Queue;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.ConcurrentLinkedQueue;
/*      */ import java.util.concurrent.ConcurrentMap;
/*      */ import java.util.concurrent.atomic.AtomicLong;
/*      */ import java.util.concurrent.atomic.AtomicReference;
/*      */ import java.util.concurrent.locks.Lock;
/*      */ import java.util.concurrent.locks.ReentrantLock;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class ConcurrentLinkedHashMap<K, V>
/*      */   extends AbstractMap<K, V>
/*      */   implements ConcurrentMap<K, V>, Serializable
/*      */ {
/*  142 */   static final int NCPU = Runtime.getRuntime().availableProcessors();
/*      */ 
/*      */   
/*      */   static final long MAXIMUM_CAPACITY = 9223372034707292160L;
/*      */ 
/*      */   
/*  148 */   static final int NUMBER_OF_READ_BUFFERS = ceilingNextPowerOfTwo(NCPU);
/*      */ 
/*      */   
/*  151 */   static final int READ_BUFFERS_MASK = NUMBER_OF_READ_BUFFERS - 1;
/*      */ 
/*      */   
/*      */   static final int READ_BUFFER_THRESHOLD = 32;
/*      */ 
/*      */   
/*      */   static final int READ_BUFFER_DRAIN_THRESHOLD = 64;
/*      */ 
/*      */   
/*      */   static final int READ_BUFFER_SIZE = 128;
/*      */ 
/*      */   
/*      */   static final int READ_BUFFER_INDEX_MASK = 127;
/*      */ 
/*      */   
/*      */   static final int WRITE_BUFFER_DRAIN_THRESHOLD = 16;
/*      */ 
/*      */   
/*  169 */   static final Queue<?> DISCARDING_QUEUE = new DiscardingQueue(); final ConcurrentMap<K, Node<K, V>> data; final int concurrencyLevel; final long[] readBufferReadCount; final LinkedDeque<Node<K, V>> evictionDeque; final AtomicLong weightedSize; final AtomicLong capacity; final Lock evictionLock; final Queue<Runnable> writeBuffer; final AtomicLong[] readBufferWriteCount; final AtomicLong[] readBufferDrainAtWriteCount; final AtomicReference<Node<K, V>>[][] readBuffers; final AtomicReference<DrainStatus> drainStatus; final EntryWeigher<? super K, ? super V> weigher; final Queue<Node<K, V>> pendingNotifications; final EvictionListener<K, V> listener; transient Set<K> keySet; transient Collection<V> values; transient Set<Map.Entry<K, V>> entrySet;
/*      */   static final long serialVersionUID = 1L;
/*      */   
/*      */   static int ceilingNextPowerOfTwo(int x) {
/*  173 */     return 1 << 32 - Integer.numberOfLeadingZeros(x - 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ConcurrentLinkedHashMap(Builder<K, V> builder) {
/*  210 */     this.concurrencyLevel = builder.concurrencyLevel;
/*  211 */     this.capacity = new AtomicLong(Math.min(builder.capacity, 9223372034707292160L));
/*  212 */     this.data = new ConcurrentHashMap<>(builder.initialCapacity, 0.75F, this.concurrencyLevel);
/*      */ 
/*      */     
/*  215 */     this.weigher = builder.weigher;
/*  216 */     this.evictionLock = new ReentrantLock();
/*  217 */     this.weightedSize = new AtomicLong();
/*  218 */     this.evictionDeque = new LinkedDeque<>();
/*  219 */     this.writeBuffer = new ConcurrentLinkedQueue<>();
/*  220 */     this.drainStatus = new AtomicReference<>(DrainStatus.IDLE);
/*      */     
/*  222 */     this.readBufferReadCount = new long[NUMBER_OF_READ_BUFFERS];
/*  223 */     this.readBufferWriteCount = new AtomicLong[NUMBER_OF_READ_BUFFERS];
/*  224 */     this.readBufferDrainAtWriteCount = new AtomicLong[NUMBER_OF_READ_BUFFERS];
/*  225 */     this.readBuffers = (AtomicReference<Node<K, V>>[][])new AtomicReference[NUMBER_OF_READ_BUFFERS][128];
/*  226 */     for (int i = 0; i < NUMBER_OF_READ_BUFFERS; i++) {
/*  227 */       this.readBufferWriteCount[i] = new AtomicLong();
/*  228 */       this.readBufferDrainAtWriteCount[i] = new AtomicLong();
/*  229 */       this.readBuffers[i] = (AtomicReference<Node<K, V>>[])new AtomicReference[128];
/*  230 */       for (int j = 0; j < 128; j++) {
/*  231 */         this.readBuffers[i][j] = new AtomicReference<>();
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  236 */     this.listener = builder.listener;
/*  237 */     this
/*      */       
/*  239 */       .pendingNotifications = (this.listener == DiscardingListener.INSTANCE) ? (Queue)DISCARDING_QUEUE : new ConcurrentLinkedQueue<>();
/*      */   }
/*      */ 
/*      */   
/*      */   static void checkNotNull(Object o) {
/*  244 */     if (o == null) {
/*  245 */       throw new NullPointerException();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static void checkArgument(boolean expression) {
/*  251 */     if (!expression) {
/*  252 */       throw new IllegalArgumentException();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static void checkState(boolean expression) {
/*  258 */     if (!expression) {
/*  259 */       throw new IllegalStateException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long capacity() {
/*  271 */     return this.capacity.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCapacity(long capacity) {
/*  282 */     checkArgument((capacity >= 0L));
/*  283 */     this.evictionLock.lock();
/*      */     try {
/*  285 */       this.capacity.lazySet(Math.min(capacity, 9223372034707292160L));
/*  286 */       drainBuffers();
/*  287 */       evict();
/*      */     } finally {
/*  289 */       this.evictionLock.unlock();
/*      */     } 
/*  291 */     notifyListener();
/*      */   }
/*      */ 
/*      */   
/*      */   boolean hasOverflowed() {
/*  296 */     return (this.weightedSize.get() > this.capacity.get());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void evict() {
/*  310 */     while (hasOverflowed()) {
/*  311 */       Node<K, V> node = this.evictionDeque.poll();
/*      */ 
/*      */ 
/*      */       
/*  315 */       if (node == null) {
/*      */         return;
/*      */       }
/*      */ 
/*      */       
/*  320 */       if (this.data.remove(node.key, node)) {
/*  321 */         this.pendingNotifications.add(node);
/*      */       }
/*      */       
/*  324 */       makeDead(node);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void afterRead(Node<K, V> node) {
/*  334 */     int bufferIndex = readBufferIndex();
/*  335 */     long writeCount = recordRead(bufferIndex, node);
/*  336 */     drainOnReadIfNeeded(bufferIndex, writeCount);
/*  337 */     notifyListener();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static int readBufferIndex() {
/*  345 */     return (int)Thread.currentThread().getId() & READ_BUFFERS_MASK;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   long recordRead(int bufferIndex, Node<K, V> node) {
/*  359 */     AtomicLong counter = this.readBufferWriteCount[bufferIndex];
/*  360 */     long writeCount = counter.get();
/*  361 */     counter.lazySet(writeCount + 1L);
/*      */     
/*  363 */     int index = (int)(writeCount & 0x7FL);
/*  364 */     this.readBuffers[bufferIndex][index].lazySet(node);
/*      */     
/*  366 */     return writeCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void drainOnReadIfNeeded(int bufferIndex, long writeCount) {
/*  377 */     long pending = writeCount - this.readBufferDrainAtWriteCount[bufferIndex].get();
/*  378 */     boolean delayable = (pending < 32L);
/*  379 */     DrainStatus status = this.drainStatus.get();
/*  380 */     if (status.shouldDrainBuffers(delayable)) {
/*  381 */       tryToDrainBuffers();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void afterWrite(Runnable task) {
/*  391 */     this.writeBuffer.add(task);
/*  392 */     this.drainStatus.lazySet(DrainStatus.REQUIRED);
/*  393 */     tryToDrainBuffers();
/*  394 */     notifyListener();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void tryToDrainBuffers() {
/*  402 */     if (this.evictionLock.tryLock()) {
/*      */       try {
/*  404 */         this.drainStatus.lazySet(DrainStatus.PROCESSING);
/*  405 */         drainBuffers();
/*      */       } finally {
/*  407 */         this.drainStatus.compareAndSet(DrainStatus.PROCESSING, DrainStatus.IDLE);
/*  408 */         this.evictionLock.unlock();
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   void drainBuffers() {
/*  415 */     drainReadBuffers();
/*  416 */     drainWriteBuffer();
/*      */   }
/*      */ 
/*      */   
/*      */   void drainReadBuffers() {
/*  421 */     int start = (int)Thread.currentThread().getId();
/*  422 */     int end = start + NUMBER_OF_READ_BUFFERS;
/*  423 */     for (int i = start; i < end; i++) {
/*  424 */       drainReadBuffer(i & READ_BUFFERS_MASK);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   void drainReadBuffer(int bufferIndex) {
/*  430 */     long writeCount = this.readBufferWriteCount[bufferIndex].get();
/*  431 */     for (int i = 0; i < 64; i++) {
/*  432 */       int index = (int)(this.readBufferReadCount[bufferIndex] & 0x7FL);
/*  433 */       AtomicReference<Node<K, V>> slot = this.readBuffers[bufferIndex][index];
/*  434 */       Node<K, V> node = slot.get();
/*  435 */       if (node == null) {
/*      */         break;
/*      */       }
/*      */       
/*  439 */       slot.lazySet(null);
/*  440 */       applyRead(node);
/*  441 */       this.readBufferReadCount[bufferIndex] = this.readBufferReadCount[bufferIndex] + 1L;
/*      */     } 
/*  443 */     this.readBufferDrainAtWriteCount[bufferIndex].lazySet(writeCount);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void applyRead(Node<K, V> node) {
/*  452 */     if (this.evictionDeque.contains(node)) {
/*  453 */       this.evictionDeque.moveToBack(node);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   void drainWriteBuffer() {
/*  459 */     for (int i = 0; i < 16; i++) {
/*  460 */       Runnable task = this.writeBuffer.poll();
/*  461 */       if (task == null) {
/*      */         break;
/*      */       }
/*  464 */       task.run();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean tryToRetire(Node<K, V> node, WeightedValue<V> expect) {
/*  477 */     if (expect.isAlive()) {
/*  478 */       WeightedValue<V> retired = new WeightedValue<>(expect.value, -expect.weight);
/*  479 */       return node.compareAndSet(expect, retired);
/*      */     } 
/*  481 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void makeRetired(Node<K, V> node) {
/*      */     WeightedValue<V> current;
/*      */     WeightedValue<V> retired;
/*      */     do {
/*  492 */       current = node.get();
/*  493 */       if (!current.isAlive()) {
/*      */         return;
/*      */       }
/*  496 */       retired = new WeightedValue<>(current.value, -current.weight);
/*  497 */     } while (!node.compareAndSet(current, retired));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void makeDead(Node<K, V> node) {
/*      */     while (true) {
/*  511 */       WeightedValue<V> current = node.get();
/*  512 */       WeightedValue<V> dead = new WeightedValue<>(current.value, 0);
/*  513 */       if (node.compareAndSet(current, dead)) {
/*  514 */         this.weightedSize.lazySet(this.weightedSize.get() - Math.abs(current.weight));
/*      */         return;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   void notifyListener() {
/*      */     Node<K, V> node;
/*  523 */     while ((node = this.pendingNotifications.poll()) != null)
/*  524 */       this.listener.onEviction(node.key, node.getValue()); 
/*      */   }
/*      */   
/*      */   final class AddTask
/*      */     implements Runnable
/*      */   {
/*      */     final ConcurrentLinkedHashMap.Node<K, V> node;
/*      */     final int weight;
/*      */     
/*      */     AddTask(ConcurrentLinkedHashMap.Node<K, V> node, int weight) {
/*  534 */       this.weight = weight;
/*  535 */       this.node = node;
/*      */     }
/*      */ 
/*      */     
/*      */     public void run() {
/*  540 */       ConcurrentLinkedHashMap.this.weightedSize.lazySet(ConcurrentLinkedHashMap.this.weightedSize.get() + this.weight);
/*      */ 
/*      */       
/*  543 */       if (this.node.get().isAlive()) {
/*  544 */         ConcurrentLinkedHashMap.this.evictionDeque.add(this.node);
/*  545 */         ConcurrentLinkedHashMap.this.evict();
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   final class RemovalTask
/*      */     implements Runnable {
/*      */     final ConcurrentLinkedHashMap.Node<K, V> node;
/*      */     
/*      */     RemovalTask(ConcurrentLinkedHashMap.Node<K, V> node) {
/*  555 */       this.node = node;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void run() {
/*  561 */       ConcurrentLinkedHashMap.this.evictionDeque.remove(this.node);
/*  562 */       ConcurrentLinkedHashMap.this.makeDead(this.node);
/*      */     }
/*      */   }
/*      */   
/*      */   final class UpdateTask
/*      */     implements Runnable {
/*      */     final int weightDifference;
/*      */     final ConcurrentLinkedHashMap.Node<K, V> node;
/*      */     
/*      */     public UpdateTask(ConcurrentLinkedHashMap.Node<K, V> node, int weightDifference) {
/*  572 */       this.weightDifference = weightDifference;
/*  573 */       this.node = node;
/*      */     }
/*      */ 
/*      */     
/*      */     public void run() {
/*  578 */       ConcurrentLinkedHashMap.this.weightedSize.lazySet(ConcurrentLinkedHashMap.this.weightedSize.get() + this.weightDifference);
/*  579 */       ConcurrentLinkedHashMap.this.applyRead(this.node);
/*  580 */       ConcurrentLinkedHashMap.this.evict();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEmpty() {
/*  588 */     return this.data.isEmpty();
/*      */   }
/*      */ 
/*      */   
/*      */   public int size() {
/*  593 */     return this.data.size();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long weightedSize() {
/*  602 */     return Math.max(0L, this.weightedSize.get());
/*      */   }
/*      */ 
/*      */   
/*      */   public void clear() {
/*  607 */     this.evictionLock.lock();
/*      */     
/*      */     try {
/*      */       Node<K, V> node;
/*  611 */       while ((node = this.evictionDeque.poll()) != null) {
/*  612 */         this.data.remove(node.key, node);
/*  613 */         makeDead(node);
/*      */       } 
/*      */ 
/*      */       
/*  617 */       for (AtomicReference<Node<K, V>>[] buffer : this.readBuffers) {
/*  618 */         for (AtomicReference<Node<K, V>> slot : buffer) {
/*  619 */           slot.lazySet(null);
/*      */         }
/*      */       } 
/*      */       
/*      */       Runnable task;
/*      */       
/*  625 */       while ((task = this.writeBuffer.poll()) != null) {
/*  626 */         task.run();
/*      */       }
/*      */     } finally {
/*  629 */       this.evictionLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean containsKey(Object key) {
/*  635 */     return this.data.containsKey(key);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean containsValue(Object value) {
/*  640 */     checkNotNull(value);
/*      */     
/*  642 */     for (Node<K, V> node : this.data.values()) {
/*  643 */       if (node.getValue().equals(value)) {
/*  644 */         return true;
/*      */       }
/*      */     } 
/*  647 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public V get(Object key) {
/*  652 */     Node<K, V> node = this.data.get(key);
/*  653 */     if (node == null) {
/*  654 */       return null;
/*      */     }
/*  656 */     afterRead(node);
/*  657 */     return node.getValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public V getQuietly(Object key) {
/*  672 */     Node<K, V> node = this.data.get(key);
/*  673 */     return (node == null) ? null : node.getValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public V put(K key, V value) {
/*  678 */     return put(key, value, false);
/*      */   }
/*      */ 
/*      */   
/*      */   public V putIfAbsent(K key, V value) {
/*  683 */     return put(key, value, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   V put(K key, V value, boolean onlyIfAbsent) {
/*  697 */     checkNotNull(key);
/*  698 */     checkNotNull(value);
/*      */     
/*  700 */     int weight = this.weigher.weightOf(key, value);
/*  701 */     WeightedValue<V> weightedValue = new WeightedValue<>(value, weight);
/*  702 */     Node<K, V> node = new Node<>(key, weightedValue);
/*      */     
/*      */     label21: while (true) {
/*  705 */       Node<K, V> prior = this.data.putIfAbsent(node.key, node);
/*  706 */       if (prior == null) {
/*  707 */         afterWrite(new AddTask(node, weight));
/*  708 */         return null;
/*  709 */       }  if (onlyIfAbsent) {
/*  710 */         afterRead(prior);
/*  711 */         return prior.getValue();
/*      */       } 
/*      */       while (true) {
/*  714 */         WeightedValue<V> oldWeightedValue = prior.get();
/*  715 */         if (!oldWeightedValue.isAlive()) {
/*      */           continue label21;
/*      */         }
/*      */         
/*  719 */         if (prior.compareAndSet(oldWeightedValue, weightedValue)) {
/*  720 */           int weightedDifference = weight - oldWeightedValue.weight;
/*  721 */           if (weightedDifference == 0) {
/*  722 */             afterRead(prior);
/*      */           } else {
/*  724 */             afterWrite(new UpdateTask(prior, weightedDifference));
/*      */           } 
/*  726 */           return oldWeightedValue.value;
/*      */         } 
/*      */       } 
/*      */       break;
/*      */     } 
/*      */   }
/*      */   
/*      */   public V remove(Object key) {
/*  734 */     Node<K, V> node = this.data.remove(key);
/*  735 */     if (node == null) {
/*  736 */       return null;
/*      */     }
/*      */     
/*  739 */     makeRetired(node);
/*  740 */     afterWrite(new RemovalTask(node));
/*  741 */     return node.getValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean remove(Object key, Object value) {
/*  746 */     Node<K, V> node = this.data.get(key);
/*  747 */     if (node == null || value == null) {
/*  748 */       return false;
/*      */     }
/*      */     
/*  751 */     WeightedValue<V> weightedValue = node.get();
/*      */     
/*  753 */     while (weightedValue.contains(value)) {
/*  754 */       if (tryToRetire(node, weightedValue)) {
/*  755 */         if (this.data.remove(key, node)) {
/*  756 */           afterWrite(new RemovalTask(node));
/*  757 */           return true;
/*      */         }  break;
/*      */       } 
/*  760 */       weightedValue = node.get();
/*  761 */       if (weightedValue.isAlive());
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  768 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public V replace(K key, V value) {
/*  774 */     checkNotNull(key);
/*  775 */     checkNotNull(value);
/*      */     
/*  777 */     int weight = this.weigher.weightOf(key, value);
/*  778 */     WeightedValue<V> weightedValue = new WeightedValue<>(value, weight);
/*      */     
/*  780 */     Node<K, V> node = this.data.get(key);
/*  781 */     if (node == null) {
/*  782 */       return null;
/*      */     }
/*      */     while (true) {
/*  785 */       WeightedValue<V> oldWeightedValue = node.get();
/*  786 */       if (!oldWeightedValue.isAlive()) {
/*  787 */         return null;
/*      */       }
/*  789 */       if (node.compareAndSet(oldWeightedValue, weightedValue)) {
/*  790 */         int weightedDifference = weight - oldWeightedValue.weight;
/*  791 */         if (weightedDifference == 0) {
/*  792 */           afterRead(node);
/*      */         } else {
/*  794 */           afterWrite(new UpdateTask(node, weightedDifference));
/*      */         } 
/*  796 */         return oldWeightedValue.value;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean replace(K key, V oldValue, V newValue) {
/*  803 */     checkNotNull(key);
/*  804 */     checkNotNull(oldValue);
/*  805 */     checkNotNull(newValue);
/*      */     
/*  807 */     int weight = this.weigher.weightOf(key, newValue);
/*  808 */     WeightedValue<V> newWeightedValue = new WeightedValue<>(newValue, weight);
/*      */     
/*  810 */     Node<K, V> node = this.data.get(key);
/*  811 */     if (node == null) {
/*  812 */       return false;
/*      */     }
/*      */     while (true) {
/*  815 */       WeightedValue<V> weightedValue = node.get();
/*  816 */       if (!weightedValue.isAlive() || !weightedValue.contains(oldValue)) {
/*  817 */         return false;
/*      */       }
/*  819 */       if (node.compareAndSet(weightedValue, newWeightedValue)) {
/*  820 */         int weightedDifference = weight - weightedValue.weight;
/*  821 */         if (weightedDifference == 0) {
/*  822 */           afterRead(node);
/*      */         } else {
/*  824 */           afterWrite(new UpdateTask(node, weightedDifference));
/*      */         } 
/*  826 */         return true;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public Set<K> keySet() {
/*  833 */     Set<K> ks = this.keySet;
/*  834 */     return (ks == null) ? (this.keySet = new KeySet()) : ks;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<K> ascendingKeySet() {
/*  851 */     return ascendingKeySetWithLimit(2147483647);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<K> ascendingKeySetWithLimit(int limit) {
/*  870 */     return orderedKeySet(true, limit);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<K> descendingKeySet() {
/*  887 */     return descendingKeySetWithLimit(2147483647);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<K> descendingKeySetWithLimit(int limit) {
/*  906 */     return orderedKeySet(false, limit);
/*      */   }
/*      */   
/*      */   Set<K> orderedKeySet(boolean ascending, int limit) {
/*  910 */     checkArgument((limit >= 0));
/*  911 */     this.evictionLock.lock();
/*      */     try {
/*  913 */       drainBuffers();
/*      */ 
/*      */ 
/*      */       
/*  917 */       int initialCapacity = (this.weigher == Weighers.entrySingleton()) ? Math.min(limit, (int)weightedSize()) : 16;
/*  918 */       Set<K> keys = new LinkedHashSet<>(initialCapacity);
/*      */ 
/*      */       
/*  921 */       Iterator<E> iterator = ascending ? (Iterator)this.evictionDeque.iterator() : (Iterator)this.evictionDeque.descendingIterator();
/*  922 */       while (iterator.hasNext() && limit > keys.size()) {
/*  923 */         keys.add(((Node)iterator.next()).key);
/*      */       }
/*  925 */       return Collections.unmodifiableSet(keys);
/*      */     } finally {
/*  927 */       this.evictionLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public Collection<V> values() {
/*  933 */     Collection<V> vs = this.values;
/*  934 */     return (vs == null) ? (this.values = new Values()) : vs;
/*      */   }
/*      */ 
/*      */   
/*      */   public Set<Map.Entry<K, V>> entrySet() {
/*  939 */     Set<Map.Entry<K, V>> es = this.entrySet;
/*  940 */     return (es == null) ? (this.entrySet = new EntrySet()) : es;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<K, V> ascendingMap() {
/*  958 */     return ascendingMapWithLimit(2147483647);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<K, V> ascendingMapWithLimit(int limit) {
/*  978 */     return orderedMap(true, limit);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<K, V> descendingMap() {
/*  996 */     return descendingMapWithLimit(2147483647);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<K, V> descendingMapWithLimit(int limit) {
/* 1016 */     return orderedMap(false, limit);
/*      */   }
/*      */   
/*      */   Map<K, V> orderedMap(boolean ascending, int limit) {
/* 1020 */     checkArgument((limit >= 0));
/* 1021 */     this.evictionLock.lock();
/*      */     try {
/* 1023 */       drainBuffers();
/*      */ 
/*      */ 
/*      */       
/* 1027 */       int initialCapacity = (this.weigher == Weighers.entrySingleton()) ? Math.min(limit, (int)weightedSize()) : 16;
/* 1028 */       Map<K, V> map = new LinkedHashMap<>(initialCapacity);
/*      */ 
/*      */       
/* 1031 */       Iterator<E> iterator = ascending ? (Iterator)this.evictionDeque.iterator() : (Iterator)this.evictionDeque.descendingIterator();
/* 1032 */       while (iterator.hasNext() && limit > map.size()) {
/* 1033 */         Node<K, V> node = (Node<K, V>)iterator.next();
/* 1034 */         map.put(node.key, node.getValue());
/*      */       } 
/* 1036 */       return Collections.unmodifiableMap(map);
/*      */     } finally {
/* 1038 */       this.evictionLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   enum DrainStatus
/*      */   {
/* 1046 */     IDLE {
/*      */       boolean shouldDrainBuffers(boolean delayable) {
/* 1048 */         return !delayable;
/*      */       }
/*      */     },
/*      */ 
/*      */     
/* 1053 */     REQUIRED {
/*      */       boolean shouldDrainBuffers(boolean delayable) {
/* 1055 */         return true;
/*      */       }
/*      */     },
/*      */ 
/*      */     
/* 1060 */     PROCESSING
/*      */     {
/* 1062 */       boolean shouldDrainBuffers(boolean delayable) { return false; } }; abstract boolean shouldDrainBuffers(boolean param1Boolean); } enum null { boolean shouldDrainBuffers(boolean delayable) { return !delayable; } } enum null { boolean shouldDrainBuffers(boolean delayable) { return true; } } enum null { boolean shouldDrainBuffers(boolean delayable) { return false; }
/*      */      }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final class WeightedValue<V>
/*      */   {
/*      */     final int weight;
/*      */ 
/*      */ 
/*      */     
/*      */     final V value;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     WeightedValue(V value, int weight) {
/* 1081 */       this.weight = weight;
/* 1082 */       this.value = value;
/*      */     }
/*      */     
/*      */     boolean contains(Object o) {
/* 1086 */       return (o == this.value || this.value.equals(o));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     boolean isAlive() {
/* 1093 */       return (this.weight > 0);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     boolean isRetired() {
/* 1101 */       return (this.weight < 0);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     boolean isDead() {
/* 1109 */       return (this.weight == 0);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static final class Node<K, V>
/*      */     extends AtomicReference<WeightedValue<V>>
/*      */     implements Linked<Node<K, V>>
/*      */   {
/*      */     final K key;
/*      */     
/*      */     Node<K, V> prev;
/*      */     
/*      */     Node<K, V> next;
/*      */ 
/*      */     
/*      */     Node(K key, ConcurrentLinkedHashMap.WeightedValue<V> weightedValue) {
/* 1126 */       super(weightedValue);
/* 1127 */       this.key = key;
/*      */     }
/*      */ 
/*      */     
/*      */     public Node<K, V> getPrevious() {
/* 1132 */       return this.prev;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setPrevious(Node<K, V> prev) {
/* 1137 */       this.prev = prev;
/*      */     }
/*      */ 
/*      */     
/*      */     public Node<K, V> getNext() {
/* 1142 */       return this.next;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setNext(Node<K, V> next) {
/* 1147 */       this.next = next;
/*      */     }
/*      */ 
/*      */     
/*      */     V getValue() {
/* 1152 */       return (get()).value;
/*      */     }
/*      */   }
/*      */   
/*      */   final class KeySet
/*      */     extends AbstractSet<K> {
/* 1158 */     final ConcurrentLinkedHashMap<K, V> map = ConcurrentLinkedHashMap.this;
/*      */ 
/*      */     
/*      */     public int size() {
/* 1162 */       return this.map.size();
/*      */     }
/*      */ 
/*      */     
/*      */     public void clear() {
/* 1167 */       this.map.clear();
/*      */     }
/*      */ 
/*      */     
/*      */     public Iterator<K> iterator() {
/* 1172 */       return new ConcurrentLinkedHashMap.KeyIterator();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean contains(Object obj) {
/* 1177 */       return ConcurrentLinkedHashMap.this.containsKey(obj);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean remove(Object obj) {
/* 1182 */       return (this.map.remove(obj) != null);
/*      */     }
/*      */ 
/*      */     
/*      */     public Object[] toArray() {
/* 1187 */       return this.map.data.keySet().toArray();
/*      */     }
/*      */ 
/*      */     
/*      */     public <T> T[] toArray(T[] array) {
/* 1192 */       return (T[])this.map.data.keySet().toArray((Object[])array);
/*      */     }
/*      */   }
/*      */   
/*      */   final class KeyIterator
/*      */     implements Iterator<K> {
/* 1198 */     final Iterator<K> iterator = ConcurrentLinkedHashMap.this.data.keySet().iterator();
/*      */     
/*      */     K current;
/*      */     
/*      */     public boolean hasNext() {
/* 1203 */       return this.iterator.hasNext();
/*      */     }
/*      */ 
/*      */     
/*      */     public K next() {
/* 1208 */       this.current = this.iterator.next();
/* 1209 */       return this.current;
/*      */     }
/*      */ 
/*      */     
/*      */     public void remove() {
/* 1214 */       ConcurrentLinkedHashMap.checkState((this.current != null));
/* 1215 */       ConcurrentLinkedHashMap.this.remove(this.current);
/* 1216 */       this.current = null;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   final class Values
/*      */     extends AbstractCollection<V>
/*      */   {
/*      */     public int size() {
/* 1225 */       return ConcurrentLinkedHashMap.this.size();
/*      */     }
/*      */ 
/*      */     
/*      */     public void clear() {
/* 1230 */       ConcurrentLinkedHashMap.this.clear();
/*      */     }
/*      */ 
/*      */     
/*      */     public Iterator<V> iterator() {
/* 1235 */       return new ConcurrentLinkedHashMap.ValueIterator();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean contains(Object o) {
/* 1240 */       return ConcurrentLinkedHashMap.this.containsValue(o);
/*      */     }
/*      */   }
/*      */   
/*      */   final class ValueIterator
/*      */     implements Iterator<V> {
/* 1246 */     final Iterator<ConcurrentLinkedHashMap.Node<K, V>> iterator = ConcurrentLinkedHashMap.this.data.values().iterator();
/*      */     
/*      */     ConcurrentLinkedHashMap.Node<K, V> current;
/*      */     
/*      */     public boolean hasNext() {
/* 1251 */       return this.iterator.hasNext();
/*      */     }
/*      */ 
/*      */     
/*      */     public V next() {
/* 1256 */       this.current = this.iterator.next();
/* 1257 */       return this.current.getValue();
/*      */     }
/*      */ 
/*      */     
/*      */     public void remove() {
/* 1262 */       ConcurrentLinkedHashMap.checkState((this.current != null));
/* 1263 */       ConcurrentLinkedHashMap.this.remove(this.current.key);
/* 1264 */       this.current = null;
/*      */     }
/*      */   }
/*      */   
/*      */   final class EntrySet
/*      */     extends AbstractSet<Map.Entry<K, V>> {
/* 1270 */     final ConcurrentLinkedHashMap<K, V> map = ConcurrentLinkedHashMap.this;
/*      */ 
/*      */     
/*      */     public int size() {
/* 1274 */       return this.map.size();
/*      */     }
/*      */ 
/*      */     
/*      */     public void clear() {
/* 1279 */       this.map.clear();
/*      */     }
/*      */ 
/*      */     
/*      */     public Iterator<Map.Entry<K, V>> iterator() {
/* 1284 */       return new ConcurrentLinkedHashMap.EntryIterator();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean contains(Object obj) {
/* 1289 */       if (!(obj instanceof Map.Entry)) {
/* 1290 */         return false;
/*      */       }
/* 1292 */       Map.Entry<?, ?> entry = (Map.Entry<?, ?>)obj;
/* 1293 */       ConcurrentLinkedHashMap.Node<K, V> node = this.map.data.get(entry.getKey());
/* 1294 */       return (node != null && node.getValue().equals(entry.getValue()));
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean add(Map.Entry<K, V> entry) {
/* 1299 */       return (this.map.putIfAbsent(entry.getKey(), entry.getValue()) == null);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean remove(Object obj) {
/* 1304 */       if (!(obj instanceof Map.Entry)) {
/* 1305 */         return false;
/*      */       }
/* 1307 */       Map.Entry<?, ?> entry = (Map.Entry<?, ?>)obj;
/* 1308 */       return this.map.remove(entry.getKey(), entry.getValue());
/*      */     }
/*      */   }
/*      */   
/*      */   final class EntryIterator
/*      */     implements Iterator<Map.Entry<K, V>> {
/* 1314 */     final Iterator<ConcurrentLinkedHashMap.Node<K, V>> iterator = ConcurrentLinkedHashMap.this.data.values().iterator();
/*      */     
/*      */     ConcurrentLinkedHashMap.Node<K, V> current;
/*      */     
/*      */     public boolean hasNext() {
/* 1319 */       return this.iterator.hasNext();
/*      */     }
/*      */ 
/*      */     
/*      */     public Map.Entry<K, V> next() {
/* 1324 */       this.current = this.iterator.next();
/* 1325 */       return new ConcurrentLinkedHashMap.WriteThroughEntry(this.current);
/*      */     }
/*      */ 
/*      */     
/*      */     public void remove() {
/* 1330 */       ConcurrentLinkedHashMap.checkState((this.current != null));
/* 1331 */       ConcurrentLinkedHashMap.this.remove(this.current.key);
/* 1332 */       this.current = null;
/*      */     }
/*      */   }
/*      */   
/*      */   final class WriteThroughEntry
/*      */     extends AbstractMap.SimpleEntry<K, V> {
/*      */     static final long serialVersionUID = 1L;
/*      */     
/*      */     WriteThroughEntry(ConcurrentLinkedHashMap.Node<K, V> node) {
/* 1341 */       super(node.key, node.getValue());
/*      */     }
/*      */ 
/*      */     
/*      */     public V setValue(V value) {
/* 1346 */       ConcurrentLinkedHashMap.this.put(getKey(), value);
/* 1347 */       return super.setValue(value);
/*      */     }
/*      */     
/*      */     Object writeReplace() {
/* 1351 */       return new AbstractMap.SimpleEntry<>(this);
/*      */     }
/*      */   }
/*      */   
/*      */   static final class BoundedEntryWeigher<K, V>
/*      */     implements EntryWeigher<K, V>, Serializable {
/*      */     static final long serialVersionUID = 1L;
/*      */     final EntryWeigher<? super K, ? super V> weigher;
/*      */     
/*      */     BoundedEntryWeigher(EntryWeigher<? super K, ? super V> weigher) {
/* 1361 */       ConcurrentLinkedHashMap.checkNotNull(weigher);
/* 1362 */       this.weigher = weigher;
/*      */     }
/*      */ 
/*      */     
/*      */     public int weightOf(K key, V value) {
/* 1367 */       int weight = this.weigher.weightOf(key, value);
/* 1368 */       ConcurrentLinkedHashMap.checkArgument((weight >= 1));
/* 1369 */       return weight;
/*      */     }
/*      */     
/*      */     Object writeReplace() {
/* 1373 */       return this.weigher;
/*      */     }
/*      */   }
/*      */   
/*      */   static final class DiscardingQueue extends AbstractQueue<Object> {
/*      */     public boolean add(Object e) {
/* 1379 */       return true;
/* 1380 */     } public boolean offer(Object e) { return true; }
/* 1381 */     public Object poll() { return null; }
/* 1382 */     public Object peek() { return null; }
/* 1383 */     public int size() { return 0; } public Iterator<Object> iterator() {
/* 1384 */       return Collections.<Object>emptyList().iterator();
/*      */     }
/*      */   }
/*      */   
/*      */   enum DiscardingListener implements EvictionListener<Object, Object> {
/* 1389 */     INSTANCE;
/*      */ 
/*      */ 
/*      */     
/*      */     public void onEviction(Object key, Object value) {}
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   Object writeReplace() {
/* 1399 */     return new SerializationProxy<>(this);
/*      */   }
/*      */   
/*      */   private void readObject(ObjectInputStream stream) throws InvalidObjectException {
/* 1403 */     throw new InvalidObjectException("Proxy required");
/*      */   }
/*      */ 
/*      */   
/*      */   static final class SerializationProxy<K, V>
/*      */     implements Serializable
/*      */   {
/*      */     final EntryWeigher<? super K, ? super V> weigher;
/*      */     
/*      */     final EvictionListener<K, V> listener;
/*      */     
/*      */     final int concurrencyLevel;
/*      */     
/*      */     final Map<K, V> data;
/*      */     final long capacity;
/*      */     static final long serialVersionUID = 1L;
/*      */     
/*      */     SerializationProxy(ConcurrentLinkedHashMap<K, V> map) {
/* 1421 */       this.concurrencyLevel = map.concurrencyLevel;
/* 1422 */       this.data = new HashMap<>(map);
/* 1423 */       this.capacity = map.capacity.get();
/* 1424 */       this.listener = map.listener;
/* 1425 */       this.weigher = map.weigher;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Object readResolve() {
/* 1434 */       ConcurrentLinkedHashMap<K, V> map = (new ConcurrentLinkedHashMap.Builder<>()).concurrencyLevel(this.concurrencyLevel).maximumWeightedCapacity(this.capacity).listener(this.listener).weigher(this.weigher).build();
/* 1435 */       map.putAll(this.data);
/* 1436 */       return map;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final class Builder<K, V>
/*      */   {
/* 1468 */     long capacity = -1L;
/* 1469 */     EntryWeigher<? super K, ? super V> weigher = Weighers.entrySingleton();
/* 1470 */     int initialCapacity = 16;
/* 1471 */     int concurrencyLevel = 16;
/* 1472 */     EvictionListener<K, V> listener = ConcurrentLinkedHashMap.DiscardingListener.INSTANCE;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     static final int DEFAULT_CONCURRENCY_LEVEL = 16;
/*      */ 
/*      */ 
/*      */     
/*      */     static final int DEFAULT_INITIAL_CAPACITY = 16;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Builder<K, V> initialCapacity(int initialCapacity) {
/* 1487 */       ConcurrentLinkedHashMap.checkArgument((initialCapacity >= 0));
/* 1488 */       this.initialCapacity = initialCapacity;
/* 1489 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Builder<K, V> maximumWeightedCapacity(long capacity) {
/* 1502 */       ConcurrentLinkedHashMap.checkArgument((capacity >= 0L));
/* 1503 */       this.capacity = capacity;
/* 1504 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Builder<K, V> concurrencyLevel(int concurrencyLevel) {
/* 1519 */       ConcurrentLinkedHashMap.checkArgument((concurrencyLevel > 0));
/* 1520 */       this.concurrencyLevel = concurrencyLevel;
/* 1521 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Builder<K, V> listener(EvictionListener<K, V> listener) {
/* 1533 */       ConcurrentLinkedHashMap.checkNotNull(listener);
/* 1534 */       this.listener = listener;
/* 1535 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Builder<K, V> weigher(Weigher<? super V> weigher) {
/* 1548 */       this
/*      */         
/* 1550 */         .weigher = (weigher == Weighers.singleton()) ? Weighers.<K, V>entrySingleton() : new ConcurrentLinkedHashMap.BoundedEntryWeigher<>(Weighers.asEntryWeigher(weigher));
/* 1551 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Builder<K, V> weigher(EntryWeigher<? super K, ? super V> weigher) {
/* 1564 */       this
/*      */         
/* 1566 */         .weigher = (weigher == Weighers.entrySingleton()) ? Weighers.<K, V>entrySingleton() : new ConcurrentLinkedHashMap.BoundedEntryWeigher<>(weigher);
/* 1567 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ConcurrentLinkedHashMap<K, V> build() {
/* 1578 */       ConcurrentLinkedHashMap.checkState((this.capacity >= 0L));
/* 1579 */       return new ConcurrentLinkedHashMap<>(this);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\mssql\googlecode\concurrentlinkedhashmap\ConcurrentLinkedHashMap.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */