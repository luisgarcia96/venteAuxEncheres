/*     */ package mssql.googlecode.concurrentlinkedhashmap;
/*     */ 
/*     */ import java.util.AbstractCollection;
/*     */ import java.util.Collection;
/*     */ import java.util.Deque;
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class LinkedDeque<E extends Linked<E>>
/*     */   extends AbstractCollection<E>
/*     */   implements Deque<E>
/*     */ {
/*     */   E first;
/*     */   E last;
/*     */   
/*     */   void linkFirst(E e) {
/*  76 */     E f = this.first;
/*  77 */     this.first = e;
/*     */     
/*  79 */     if (f == null) {
/*  80 */       this.last = e;
/*     */     } else {
/*  82 */       f.setPrevious(e);
/*  83 */       e.setNext(f);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void linkLast(E e) {
/*  94 */     E l = this.last;
/*  95 */     this.last = e;
/*     */     
/*  97 */     if (l == null) {
/*  98 */       this.first = e;
/*     */     } else {
/* 100 */       l.setNext(e);
/* 101 */       e.setPrevious(l);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   E unlinkFirst() {
/* 107 */     E f = this.first;
/* 108 */     E next = f.getNext();
/* 109 */     f.setNext(null);
/*     */     
/* 111 */     this.first = next;
/* 112 */     if (next == null) {
/* 113 */       this.last = null;
/*     */     } else {
/* 115 */       next.setPrevious(null);
/*     */     } 
/* 117 */     return f;
/*     */   }
/*     */ 
/*     */   
/*     */   E unlinkLast() {
/* 122 */     E l = this.last;
/* 123 */     E prev = l.getPrevious();
/* 124 */     l.setPrevious(null);
/* 125 */     this.last = prev;
/* 126 */     if (prev == null) {
/* 127 */       this.first = null;
/*     */     } else {
/* 129 */       prev.setNext(null);
/*     */     } 
/* 131 */     return l;
/*     */   }
/*     */ 
/*     */   
/*     */   void unlink(E e) {
/* 136 */     E prev = e.getPrevious();
/* 137 */     E next = e.getNext();
/*     */     
/* 139 */     if (prev == null) {
/* 140 */       this.first = next;
/*     */     } else {
/* 142 */       prev.setNext(next);
/* 143 */       e.setPrevious(null);
/*     */     } 
/*     */     
/* 146 */     if (next == null) {
/* 147 */       this.last = prev;
/*     */     } else {
/* 149 */       next.setPrevious(prev);
/* 150 */       e.setNext(null);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 156 */     return (this.first == null);
/*     */   }
/*     */   
/*     */   void checkNotEmpty() {
/* 160 */     if (isEmpty()) {
/* 161 */       throw new NoSuchElementException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 173 */     int size = 0;
/* 174 */     for (E e = this.first; e != null; e = e.getNext()) {
/* 175 */       size++;
/*     */     }
/* 177 */     return size;
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 182 */     for (E e = this.first; e != null; ) {
/* 183 */       E next = e.getNext();
/* 184 */       e.setPrevious(null);
/* 185 */       e.setNext(null);
/* 186 */       e = next;
/*     */     } 
/* 188 */     this.first = this.last = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(Object o) {
/* 193 */     return (o instanceof Linked && contains((Linked)o));
/*     */   }
/*     */ 
/*     */   
/*     */   boolean contains(Linked<?> e) {
/* 198 */     return (e.getPrevious() != null || e
/* 199 */       .getNext() != null || e == this.first);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void moveToFront(E e) {
/* 210 */     if (e != this.first) {
/* 211 */       unlink(e);
/* 212 */       linkFirst(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void moveToBack(E e) {
/* 223 */     if (e != this.last) {
/* 224 */       unlink(e);
/* 225 */       linkLast(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public E peek() {
/* 231 */     return peekFirst();
/*     */   }
/*     */ 
/*     */   
/*     */   public E peekFirst() {
/* 236 */     return this.first;
/*     */   }
/*     */ 
/*     */   
/*     */   public E peekLast() {
/* 241 */     return this.last;
/*     */   }
/*     */ 
/*     */   
/*     */   public E getFirst() {
/* 246 */     checkNotEmpty();
/* 247 */     return peekFirst();
/*     */   }
/*     */ 
/*     */   
/*     */   public E getLast() {
/* 252 */     checkNotEmpty();
/* 253 */     return peekLast();
/*     */   }
/*     */ 
/*     */   
/*     */   public E element() {
/* 258 */     return getFirst();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean offer(E e) {
/* 263 */     return offerLast(e);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean offerFirst(E e) {
/* 268 */     if (contains((Linked<?>)e)) {
/* 269 */       return false;
/*     */     }
/* 271 */     linkFirst(e);
/* 272 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean offerLast(E e) {
/* 277 */     if (contains((Linked<?>)e)) {
/* 278 */       return false;
/*     */     }
/* 280 */     linkLast(e);
/* 281 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean add(E e) {
/* 286 */     return offerLast(e);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addFirst(E e) {
/* 292 */     if (!offerFirst(e)) {
/* 293 */       throw new IllegalArgumentException();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void addLast(E e) {
/* 299 */     if (!offerLast(e)) {
/* 300 */       throw new IllegalArgumentException();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public E poll() {
/* 306 */     return pollFirst();
/*     */   }
/*     */ 
/*     */   
/*     */   public E pollFirst() {
/* 311 */     return isEmpty() ? null : unlinkFirst();
/*     */   }
/*     */ 
/*     */   
/*     */   public E pollLast() {
/* 316 */     return isEmpty() ? null : unlinkLast();
/*     */   }
/*     */ 
/*     */   
/*     */   public E remove() {
/* 321 */     return removeFirst();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean remove(Object o) {
/* 327 */     return (o instanceof Linked && remove((E)o));
/*     */   }
/*     */ 
/*     */   
/*     */   boolean remove(E e) {
/* 332 */     if (contains((Linked<?>)e)) {
/* 333 */       unlink(e);
/* 334 */       return true;
/*     */     } 
/* 336 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public E removeFirst() {
/* 341 */     checkNotEmpty();
/* 342 */     return pollFirst();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean removeFirstOccurrence(Object o) {
/* 347 */     return remove(o);
/*     */   }
/*     */ 
/*     */   
/*     */   public E removeLast() {
/* 352 */     checkNotEmpty();
/* 353 */     return pollLast();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean removeLastOccurrence(Object o) {
/* 358 */     return remove(o);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean removeAll(Collection<?> c) {
/* 363 */     boolean modified = false;
/* 364 */     for (Object o : c) {
/* 365 */       modified |= remove(o);
/*     */     }
/* 367 */     return modified;
/*     */   }
/*     */ 
/*     */   
/*     */   public void push(E e) {
/* 372 */     addFirst(e);
/*     */   }
/*     */ 
/*     */   
/*     */   public E pop() {
/* 377 */     return removeFirst();
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<E> iterator() {
/* 382 */     return new AbstractLinkedIterator((Linked)this.first) {
/*     */         E computeNext() {
/* 384 */           return this.cursor.getNext();
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<E> descendingIterator() {
/* 391 */     return new AbstractLinkedIterator((Linked)this.last) {
/*     */         E computeNext() {
/* 393 */           return this.cursor.getPrevious();
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   abstract class AbstractLinkedIterator
/*     */     implements Iterator<E>
/*     */   {
/*     */     E cursor;
/*     */ 
/*     */     
/*     */     AbstractLinkedIterator(E start) {
/* 407 */       this.cursor = start;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 412 */       return (this.cursor != null);
/*     */     }
/*     */ 
/*     */     
/*     */     public E next() {
/* 417 */       if (!hasNext()) {
/* 418 */         throw new NoSuchElementException();
/*     */       }
/* 420 */       E e = this.cursor;
/* 421 */       this.cursor = computeNext();
/* 422 */       return e;
/*     */     }
/*     */ 
/*     */     
/*     */     public void remove() {
/* 427 */       throw new UnsupportedOperationException();
/*     */     }
/*     */     
/*     */     abstract E computeNext();
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\mssql\googlecode\concurrentlinkedhashmap\LinkedDeque.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */