/*     */ package mssql.googlecode.concurrentlinkedhashmap;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Weighers
/*     */ {
/*     */   private Weighers() {
/*  36 */     throw new AssertionError();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <K, V> EntryWeigher<K, V> asEntryWeigher(Weigher<? super V> weigher) {
/*  50 */     return (weigher == singleton()) ? 
/*  51 */       entrySingleton() : 
/*  52 */       new EntryWeigherView<>(weigher);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <K, V> EntryWeigher<K, V> entrySingleton() {
/*  66 */     return SingletonEntryWeigher.INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <V> Weigher<V> singleton() {
/*  79 */     return SingletonWeigher.INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Weigher<byte[]> byteArray() {
/*  98 */     return ByteArrayWeigher.INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <E> Weigher<? super Iterable<E>> iterable() {
/* 118 */     return IterableWeigher.INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <E> Weigher<? super Collection<E>> collection() {
/* 137 */     return CollectionWeigher.INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <E> Weigher<? super List<E>> list() {
/* 156 */     return ListWeigher.INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <E> Weigher<? super Set<E>> set() {
/* 175 */     return SetWeigher.INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <A, B> Weigher<? super Map<A, B>> map() {
/* 195 */     return MapWeigher.INSTANCE;
/*     */   }
/*     */   
/*     */   static final class EntryWeigherView<K, V> implements EntryWeigher<K, V>, Serializable {
/*     */     static final long serialVersionUID = 1L;
/*     */     final Weigher<? super V> weigher;
/*     */     
/*     */     EntryWeigherView(Weigher<? super V> weigher) {
/* 203 */       ConcurrentLinkedHashMap.checkNotNull(weigher);
/* 204 */       this.weigher = weigher;
/*     */     }
/*     */ 
/*     */     
/*     */     public int weightOf(K key, V value) {
/* 209 */       return this.weigher.weightOf(value);
/*     */     }
/*     */   }
/*     */   
/*     */   enum SingletonEntryWeigher implements EntryWeigher<Object, Object> {
/* 214 */     INSTANCE;
/*     */ 
/*     */     
/*     */     public int weightOf(Object key, Object value) {
/* 218 */       return 1;
/*     */     }
/*     */   }
/*     */   
/*     */   enum SingletonWeigher implements Weigher<Object> {
/* 223 */     INSTANCE;
/*     */ 
/*     */     
/*     */     public int weightOf(Object value) {
/* 227 */       return 1;
/*     */     }
/*     */   }
/*     */   
/*     */   enum ByteArrayWeigher implements Weigher<byte[]> {
/* 232 */     INSTANCE;
/*     */ 
/*     */     
/*     */     public int weightOf(byte[] value) {
/* 236 */       return value.length;
/*     */     }
/*     */   }
/*     */   
/*     */   enum IterableWeigher implements Weigher<Iterable<?>> {
/* 241 */     INSTANCE;
/*     */ 
/*     */     
/*     */     public int weightOf(Iterable<?> values) {
/* 245 */       if (values instanceof Collection) {
/* 246 */         return ((Collection)values).size();
/*     */       }
/* 248 */       int size = 0;
/* 249 */       for (Object value : values) {
/* 250 */         size++;
/*     */       }
/* 252 */       return size;
/*     */     }
/*     */   }
/*     */   
/*     */   enum CollectionWeigher implements Weigher<Collection<?>> {
/* 257 */     INSTANCE;
/*     */ 
/*     */     
/*     */     public int weightOf(Collection<?> values) {
/* 261 */       return values.size();
/*     */     }
/*     */   }
/*     */   
/*     */   enum ListWeigher implements Weigher<List<?>> {
/* 266 */     INSTANCE;
/*     */ 
/*     */     
/*     */     public int weightOf(List<?> values) {
/* 270 */       return values.size();
/*     */     }
/*     */   }
/*     */   
/*     */   enum SetWeigher implements Weigher<Set<?>> {
/* 275 */     INSTANCE;
/*     */ 
/*     */     
/*     */     public int weightOf(Set<?> values) {
/* 279 */       return values.size();
/*     */     }
/*     */   }
/*     */   
/*     */   enum MapWeigher implements Weigher<Map<?, ?>> {
/* 284 */     INSTANCE;
/*     */ 
/*     */     
/*     */     public int weightOf(Map<?, ?> values) {
/* 288 */       return values.size();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\mssql\googlecode\concurrentlinkedhashmap\Weighers.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */