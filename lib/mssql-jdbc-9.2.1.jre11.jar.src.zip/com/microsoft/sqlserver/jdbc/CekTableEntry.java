/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CekTableEntry
/*     */ {
/*  48 */   private static final Logger aeLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.AE");
/*     */   
/*     */   List<EncryptionKeyInfo> columnEncryptionKeyValues;
/*     */   int ordinal;
/*     */   int databaseId;
/*     */   int cekId;
/*     */   int cekVersion;
/*     */   byte[] cekMdVersion;
/*     */   
/*     */   List<EncryptionKeyInfo> getColumnEncryptionKeyValues() {
/*  58 */     return this.columnEncryptionKeyValues;
/*     */   }
/*     */   
/*     */   int getOrdinal() {
/*  62 */     return this.ordinal;
/*     */   }
/*     */   
/*     */   int getDatabaseId() {
/*  66 */     return this.databaseId;
/*     */   }
/*     */   
/*     */   int getCekId() {
/*  70 */     return this.cekId;
/*     */   }
/*     */   
/*     */   int getCekVersion() {
/*  74 */     return this.cekVersion;
/*     */   }
/*     */   
/*     */   byte[] getCekMdVersion() {
/*  78 */     return this.cekMdVersion;
/*     */   }
/*     */   
/*     */   CekTableEntry(int ordinalVal) {
/*  82 */     this.ordinal = ordinalVal;
/*  83 */     this.databaseId = 0;
/*  84 */     this.cekId = 0;
/*  85 */     this.cekVersion = 0;
/*  86 */     this.cekMdVersion = null;
/*  87 */     this.columnEncryptionKeyValues = new ArrayList<>();
/*     */   }
/*     */   
/*     */   int getSize() {
/*  91 */     return this.columnEncryptionKeyValues.size();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void add(byte[] encryptedKey, int dbId, int keyId, int keyVersion, byte[] mdVersion, String keyPath, String keyStoreName, String algorithmName) {
/*  97 */     assert null != this.columnEncryptionKeyValues : "columnEncryptionKeyValues should already be initialized.";
/*     */     
/*  99 */     aeLogger.fine("Retrieving CEK values");
/*     */     
/* 101 */     EncryptionKeyInfo encryptionKey = new EncryptionKeyInfo(encryptedKey, dbId, keyId, keyVersion, mdVersion, keyPath, keyStoreName, algorithmName);
/*     */     
/* 103 */     this.columnEncryptionKeyValues.add(encryptionKey);
/*     */     
/* 105 */     if (0 == this.databaseId) {
/* 106 */       this.databaseId = dbId;
/* 107 */       this.cekId = keyId;
/* 108 */       this.cekVersion = keyVersion;
/* 109 */       this.cekMdVersion = mdVersion;
/*     */     } else {
/* 111 */       assert this.databaseId == dbId;
/* 112 */       assert this.cekId == keyId;
/* 113 */       assert this.cekVersion == keyVersion;
/* 114 */       assert null != this.cekMdVersion && null != mdVersion && this.cekMdVersion.length == mdVersion.length;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\CekTableEntry.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */