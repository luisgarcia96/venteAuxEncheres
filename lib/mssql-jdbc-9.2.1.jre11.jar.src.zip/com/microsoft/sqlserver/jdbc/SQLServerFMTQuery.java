/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.stream.Collectors;
/*     */ import org.antlr.v4.runtime.ANTLRErrorListener;
/*     */ import org.antlr.v4.runtime.CharStreams;
/*     */ import org.antlr.v4.runtime.Token;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SQLServerFMTQuery
/*     */ {
/*     */   private static final String FMT_ON = "SET FMTONLY ON;";
/*     */   private static final String SELECT = "SELECT ";
/*     */   private static final String FROM = " FROM ";
/*     */   private static final String FMT_OFF = ";SET FMTONLY OFF;";
/*  30 */   private String prefix = "";
/*  31 */   private ArrayList<? extends Token> tokenList = null;
/*  32 */   private List<String> userColumns = new ArrayList<>();
/*  33 */   private List<String> tableTarget = new ArrayList<>();
/*  34 */   private List<String> possibleAliases = new ArrayList<>();
/*  35 */   private List<List<String>> valuesList = new ArrayList<>();
/*     */   
/*     */   List<String> getColumns() {
/*  38 */     return this.userColumns;
/*     */   }
/*     */   
/*     */   List<String> getTableTarget() {
/*  42 */     return this.tableTarget;
/*     */   }
/*     */   
/*     */   List<List<String>> getValuesList() {
/*  46 */     return this.valuesList;
/*     */   }
/*     */   
/*     */   List<String> getAliases() {
/*  50 */     return this.possibleAliases;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String constructColumnTargets() {
/*  61 */     if (this.userColumns.contains("?")) {
/*  62 */       return this.userColumns.stream().filter(s -> !"?".equals(s)).map(s -> "".equals(s) ? "NULL" : s)
/*  63 */         .collect(Collectors.joining(","));
/*     */     }
/*  65 */     return this.userColumns.isEmpty() ? "*" : 
/*  66 */       this.userColumns.stream().map(s -> "".equals(s) ? "NULL" : s).collect(Collectors.joining(","));
/*     */   }
/*     */ 
/*     */   
/*     */   String constructTableTargets() {
/*  71 */     return this.tableTarget.stream().distinct().filter(s -> !this.possibleAliases.contains(s))
/*  72 */       .collect(Collectors.joining(","));
/*     */   }
/*     */   
/*     */   String getFMTQuery() {
/*  76 */     StringBuilder sb = new StringBuilder("SET FMTONLY ON;");
/*  77 */     if (!"".equals(this.prefix)) {
/*  78 */       sb.append(this.prefix);
/*     */     }
/*  80 */     sb.append("SELECT ");
/*  81 */     sb.append(constructColumnTargets());
/*  82 */     if (!this.tableTarget.isEmpty()) {
/*  83 */       sb.append(" FROM ");
/*  84 */       sb.append(constructTableTargets());
/*     */     } 
/*  86 */     sb.append(";SET FMTONLY OFF;");
/*  87 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SQLServerFMTQuery(String userSql) throws SQLServerException {
/*  95 */     if (null != userSql && 0 != userSql.length()) {
/*  96 */       InputStream stream = new ByteArrayInputStream(userSql.getBytes(StandardCharsets.UTF_8));
/*     */       
/*  98 */       SQLServerLexer lexer = null;
/*     */       try {
/* 100 */         lexer = new SQLServerLexer(CharStreams.fromStream(stream));
/* 101 */       } catch (IOException e) {
/* 102 */         SQLServerException.makeFromDriverError(null, userSql, e.getLocalizedMessage(), null, false);
/*     */       } 
/* 104 */       if (null != lexer) {
/* 105 */         lexer.removeErrorListeners();
/* 106 */         lexer.addErrorListener((ANTLRErrorListener)new SQLServerErrorListener());
/* 107 */         this.tokenList = (ArrayList<? extends Token>)lexer.getAllTokens();
/* 108 */         if (this.tokenList.size() <= 0) {
/* 109 */           SQLServerException.makeFromDriverError(null, this, 
/* 110 */               SQLServerResource.getResource("R_noTokensFoundInUserQuery"), null, false);
/*     */         }
/* 112 */         SQLServerTokenIterator iter = new SQLServerTokenIterator(this.tokenList);
/* 113 */         this.prefix = SQLServerParser.getCTE(iter);
/* 114 */         SQLServerParser.parseQuery(iter, this);
/*     */       } else {
/* 116 */         SQLServerException.makeFromDriverError(null, userSql, 
/* 117 */             SQLServerResource.getResource("R_noTokensFoundInUserQuery"), null, false);
/*     */       } 
/*     */     } else {
/* 120 */       SQLServerException.makeFromDriverError(null, this, 
/* 121 */           SQLServerResource.getResource("R_noTokensFoundInUserQuery"), null, false);
/*     */     } 
/*     */   }
/*     */   
/*     */   private SQLServerFMTQuery() {}
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerFMTQuery.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */