/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.sql.Blob;
/*     */ import java.sql.SQLException;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SQLServerBlob
/*     */   extends SQLServerLob
/*     */   implements Blob, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -3526170228097889085L;
/*     */   private static final String R_CANT_SET_NULL = "R_cantSetNull";
/*     */   private static final String R_INVALID_POSITION_INDEX = "R_invalidPositionIndex";
/*     */   private static final String R_INVALID_LENGTH = "R_invalidLength";
/*  34 */   private static final Logger _LOGGER = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerBlob");
/*     */ 
/*     */   
/*  37 */   private static final AtomicInteger BASE_ID = new AtomicInteger(0);
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] value;
/*     */ 
/*     */ 
/*     */   
/*     */   private transient SQLServerConnection con;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isClosed = false;
/*     */ 
/*     */   
/*  52 */   ArrayList<Closeable> activeStreams = new ArrayList<>(1);
/*     */   
/*     */   private final String traceID;
/*     */   
/*     */   public final String toString() {
/*  57 */     return this.traceID;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int nextInstanceID() {
/*  62 */     return BASE_ID.incrementAndGet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public SQLServerBlob(SQLServerConnection connection, byte[] data) {
/*  76 */     this.traceID = getClass().getSimpleName() + getClass().getSimpleName();
/*  77 */     this.con = connection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  84 */     if (null == data) {
/*  85 */       throw new NullPointerException(SQLServerException.getErrString("R_cantSetNull"));
/*     */     }
/*  87 */     this.value = data;
/*     */     
/*  89 */     if (_LOGGER.isLoggable(Level.FINE)) {
/*  90 */       String loggingInfo = (null != connection) ? connection.toString() : "null connection";
/*  91 */       _LOGGER.fine(toString() + " created by (" + toString() + ")");
/*     */     } 
/*     */   }
/*     */   
/*     */   SQLServerBlob(SQLServerConnection connection) {
/*  96 */     this.traceID = getClass().getSimpleName() + getClass().getSimpleName();
/*  97 */     this.con = connection;
/*  98 */     this.value = new byte[0];
/*  99 */     if (_LOGGER.isLoggable(Level.FINE))
/* 100 */       _LOGGER.fine(toString() + " created by (" + toString() + ")"); 
/*     */   }
/*     */   
/*     */   SQLServerBlob(BaseInputStream stream) {
/* 104 */     this.traceID = getClass().getSimpleName() + getClass().getSimpleName();
/* 105 */     this.activeStreams.add(stream);
/* 106 */     if (_LOGGER.isLoggable(Level.FINE)) {
/* 107 */       _LOGGER.fine(toString() + " created by (null connection)");
/*     */     }
/*     */   }
/*     */   
/*     */   public void free() throws SQLException {
/* 112 */     if (!this.isClosed) {
/*     */ 
/*     */       
/* 115 */       if (null != this.activeStreams) {
/* 116 */         for (Closeable stream : this.activeStreams) {
/*     */           try {
/* 118 */             stream.close();
/* 119 */           } catch (IOException ioException) {
/* 120 */             _LOGGER.fine(toString() + " ignored IOException closing stream " + toString() + ": " + stream);
/*     */           } 
/*     */         } 
/*     */         
/* 124 */         this.activeStreams = null;
/*     */       } 
/*     */ 
/*     */       
/* 128 */       this.value = null;
/* 129 */       this.isClosed = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkClosed() throws SQLServerException {
/* 137 */     if (this.isClosed) {
/* 138 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_isFreed"));
/* 139 */       SQLServerException.makeFromDriverError(this.con, null, form.format(new Object[] { "Blob" }, ), null, true);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStream getBinaryStream() throws SQLException {
/* 145 */     checkClosed();
/*     */     
/* 147 */     if (!this.delayLoadingLob && null == this.value && !this.activeStreams.isEmpty()) {
/* 148 */       getBytesFromStream();
/*     */     }
/*     */     
/* 151 */     if (null == this.value && !this.activeStreams.isEmpty()) {
/* 152 */       InputStream stream = (InputStream)this.activeStreams.get(0);
/*     */       try {
/* 154 */         stream.reset();
/* 155 */       } catch (IOException e) {
/* 156 */         throw new SQLServerException(e.getMessage(), null, 0, e);
/*     */       } 
/* 158 */       return (InputStream)this.activeStreams.get(0);
/*     */     } 
/* 160 */     if (this.value == null) {
/* 161 */       throw new SQLServerException("Unexpected Error: blob value is null while all streams are closed.", null);
/*     */     }
/*     */     
/* 164 */     return getBinaryStreamInternal(0, this.value.length);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public InputStream getBinaryStream(long pos, long length) throws SQLException {
/* 170 */     SQLServerException.throwFeatureNotSupportedException();
/* 171 */     return null;
/*     */   }
/*     */   
/*     */   private InputStream getBinaryStreamInternal(int pos, int length) {
/* 175 */     assert null != this.value;
/* 176 */     assert pos >= 0;
/* 177 */     assert 0 <= length && length <= this.value.length - pos;
/* 178 */     assert null != this.activeStreams;
/*     */     
/* 180 */     InputStream getterStream = new ByteArrayInputStream(this.value, pos, length);
/* 181 */     this.activeStreams.add(getterStream);
/* 182 */     return getterStream;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getBytes(long pos, int length) throws SQLException {
/* 187 */     checkClosed();
/*     */     
/* 189 */     getBytesFromStream();
/* 190 */     if (pos < 1L) {
/* 191 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidPositionIndex"));
/* 192 */       Object[] msgArgs = { Long.valueOf(pos) };
/* 193 */       SQLServerException.makeFromDriverError(this.con, null, form.format(msgArgs), null, true);
/*     */     } 
/*     */     
/* 196 */     if (length < 0) {
/* 197 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidLength"));
/* 198 */       Object[] msgArgs = { Integer.valueOf(length) };
/* 199 */       SQLServerException.makeFromDriverError(this.con, null, form.format(msgArgs), null, true);
/*     */     } 
/*     */ 
/*     */     
/* 203 */     pos--;
/*     */ 
/*     */     
/* 206 */     if (pos > this.value.length) {
/* 207 */       pos = this.value.length;
/*     */     }
/*     */     
/* 210 */     if (length > this.value.length - pos) {
/* 211 */       length = (int)(this.value.length - pos);
/*     */     }
/* 213 */     byte[] bTemp = new byte[length];
/* 214 */     System.arraycopy(this.value, (int)pos, bTemp, 0, length);
/* 215 */     return bTemp;
/*     */   }
/*     */ 
/*     */   
/*     */   public long length() throws SQLException {
/* 220 */     checkClosed();
/* 221 */     if (this.value == null && this.activeStreams.get(0) instanceof BaseInputStream) {
/* 222 */       return ((BaseInputStream)this.activeStreams.get(0)).payloadLength;
/*     */     }
/* 224 */     getBytesFromStream();
/* 225 */     return this.value.length;
/*     */   }
/*     */ 
/*     */   
/*     */   void fillFromStream() throws SQLException {
/* 230 */     if (!this.isClosed) {
/* 231 */       getBytesFromStream();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void getBytesFromStream() throws SQLServerException {
/* 241 */     if (null == this.value) {
/* 242 */       BaseInputStream stream = (BaseInputStream)this.activeStreams.get(0);
/*     */       try {
/* 244 */         stream.reset();
/* 245 */       } catch (IOException e) {
/* 246 */         throw new SQLServerException(e.getMessage(), null, 0, e);
/*     */       } 
/* 248 */       this.value = stream.getBytes();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public long position(Blob pattern, long start) throws SQLException {
/* 254 */     checkClosed();
/*     */     
/* 256 */     getBytesFromStream();
/* 257 */     if (start < 1L) {
/* 258 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidPositionIndex"));
/* 259 */       Object[] msgArgs = { Long.valueOf(start) };
/* 260 */       SQLServerException.makeFromDriverError(this.con, null, form.format(msgArgs), null, true);
/*     */     } 
/*     */     
/* 263 */     if (null == pattern) {
/* 264 */       return -1L;
/*     */     }
/* 266 */     return position(pattern.getBytes(1L, (int)pattern.length()), start);
/*     */   }
/*     */ 
/*     */   
/*     */   public long position(byte[] bPattern, long start) throws SQLException {
/* 271 */     checkClosed();
/* 272 */     getBytesFromStream();
/* 273 */     if (start < 1L) {
/* 274 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidPositionIndex"));
/* 275 */       Object[] msgArgs = { Long.valueOf(start) };
/* 276 */       SQLServerException.makeFromDriverError(this.con, null, form.format(msgArgs), null, true);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 282 */     if (null == bPattern) {
/* 283 */       return -1L;
/*     */     }
/*     */     
/* 286 */     start--;
/*     */ 
/*     */     
/* 289 */     for (int pos = (int)start; pos <= this.value.length - bPattern.length; pos++) {
/* 290 */       boolean match = true;
/* 291 */       for (int i = 0; i < bPattern.length; i++) {
/* 292 */         if (this.value[pos + i] != bPattern[i]) {
/* 293 */           match = false;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 298 */       if (match) {
/* 299 */         return pos + 1L;
/*     */       }
/*     */     } 
/*     */     
/* 303 */     return -1L;
/*     */   }
/*     */ 
/*     */   
/*     */   public void truncate(long len) throws SQLException {
/* 308 */     checkClosed();
/* 309 */     getBytesFromStream();
/*     */     
/* 311 */     if (len < 0L) {
/* 312 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidLength"));
/* 313 */       Object[] msgArgs = { Long.valueOf(len) };
/* 314 */       SQLServerException.makeFromDriverError(this.con, null, form.format(msgArgs), null, true);
/*     */     } 
/*     */     
/* 317 */     if (this.value.length > len) {
/* 318 */       byte[] bNew = new byte[(int)len];
/* 319 */       System.arraycopy(this.value, 0, bNew, 0, (int)len);
/* 320 */       this.value = bNew;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public OutputStream setBinaryStream(long pos) throws SQLException {
/* 326 */     checkClosed();
/*     */     
/* 328 */     if (pos < 1L) {
/* 329 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidPositionIndex"));
/* 330 */       SQLServerException.makeFromDriverError(this.con, null, form.format(new Object[] { Long.valueOf(pos) }, ), null, true);
/*     */     } 
/*     */     
/* 333 */     return new SQLServerBlobOutputStream(this, pos);
/*     */   }
/*     */ 
/*     */   
/*     */   public int setBytes(long pos, byte[] bytes) throws SQLException {
/* 338 */     checkClosed();
/*     */     
/* 340 */     getBytesFromStream();
/* 341 */     if (null == bytes) {
/* 342 */       SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_cantSetNull"), null, true);
/*     */     }
/*     */     
/* 345 */     return setBytes(pos, bytes, 0, bytes.length);
/*     */   }
/*     */ 
/*     */   
/*     */   public int setBytes(long pos, byte[] bytes, int offset, int len) throws SQLException {
/* 350 */     checkClosed();
/* 351 */     getBytesFromStream();
/*     */     
/* 353 */     if (null == bytes) {
/* 354 */       SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_cantSetNull"), null, true);
/*     */     }
/*     */ 
/*     */     
/* 358 */     if (offset < 0 || offset > bytes.length) {
/* 359 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidOffset"));
/* 360 */       Object[] msgArgs = { Integer.valueOf(offset) };
/* 361 */       SQLServerException.makeFromDriverError(this.con, null, form.format(msgArgs), null, true);
/*     */     } 
/*     */ 
/*     */     
/* 365 */     if (len < 0 || len > bytes.length - offset) {
/* 366 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidLength"));
/* 367 */       Object[] msgArgs = { Integer.valueOf(len) };
/* 368 */       SQLServerException.makeFromDriverError(this.con, null, form.format(msgArgs), null, true);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 374 */     if (pos <= 0L || pos > (this.value.length + 1)) {
/* 375 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidPositionIndex"));
/* 376 */       Object[] msgArgs = { Long.valueOf(pos) };
/* 377 */       SQLServerException.makeFromDriverError(this.con, null, form.format(msgArgs), null, true);
/*     */     } 
/*     */ 
/*     */     
/* 381 */     pos--;
/*     */ 
/*     */     
/* 384 */     if (len >= this.value.length - pos) {
/*     */ 
/*     */       
/* 387 */       DataTypes.getCheckedLength(this.con, JDBCType.BLOB, pos + len, false);
/*     */ 
/*     */       
/* 390 */       byte[] combinedValue = new byte[(int)pos + len];
/* 391 */       System.arraycopy(this.value, 0, combinedValue, 0, (int)pos);
/*     */ 
/*     */       
/* 394 */       System.arraycopy(bytes, offset, combinedValue, (int)pos, len);
/* 395 */       this.value = combinedValue;
/*     */     } else {
/*     */       
/* 398 */       System.arraycopy(bytes, offset, this.value, (int)pos, len);
/*     */     } 
/*     */     
/* 401 */     return len;
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerBlob.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */