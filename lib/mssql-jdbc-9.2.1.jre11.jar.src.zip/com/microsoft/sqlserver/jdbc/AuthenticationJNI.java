/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class AuthenticationJNI
/*     */   extends SSPIAuthentication
/*     */ {
/*     */   private static final int maximumpointersize = 128;
/*     */   private static boolean enabled = false;
/*  29 */   private static Logger authLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.AuthenticationJNI");
/*  30 */   private static int sspiBlobMaxlen = 0;
/*  31 */   private byte[] sniSec = new byte[128];
/*  32 */   private int[] sniSecLen = new int[] { 0 };
/*     */   
/*     */   private final String dnsName;
/*     */   private final int port;
/*     */   private SQLServerConnection con;
/*     */   private static final UnsatisfiedLinkError linkError;
/*     */   
/*     */   static int getMaxSSPIBlobSize() {
/*  40 */     return sspiBlobMaxlen;
/*     */   }
/*     */   
/*     */   static boolean isDllLoaded() {
/*  44 */     return enabled;
/*     */   }
/*     */   
/*     */   static {
/*  48 */     UnsatisfiedLinkError temp = null;
/*     */     
/*     */     try {
/*  51 */       System.loadLibrary(SQLServerDriver.AUTH_DLL_NAME);
/*  52 */       int[] pkg = new int[1];
/*  53 */       pkg[0] = 0;
/*  54 */       if (0 == SNISecInitPackage(pkg, authLogger)) {
/*  55 */         sspiBlobMaxlen = pkg[0];
/*     */       } else {
/*  57 */         throw new UnsatisfiedLinkError();
/*     */       } 
/*  59 */       enabled = true;
/*  60 */     } catch (UnsatisfiedLinkError e) {
/*  61 */       temp = e;
/*     */     }
/*     */     finally {
/*     */       
/*  65 */       linkError = temp;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   AuthenticationJNI(SQLServerConnection con, String address, int serverport) throws SQLServerException {
/*  71 */     if (!enabled) {
/*  72 */       con.terminate(0, 
/*  73 */           SQLServerException.getErrString("R_notConfiguredForIntegrated"), linkError);
/*     */     }
/*     */     
/*  76 */     this.con = con;
/*  77 */     this.dnsName = initDNSArray(address);
/*  78 */     this.port = serverport;
/*     */   }
/*     */ 
/*     */   
/*     */   static FedAuthDllInfo getAccessTokenForWindowsIntegrated(String stsURL, String servicePrincipalName, String clientConnectionId, String clientId, long expirationFileTime) throws DLLException {
/*  83 */     FedAuthDllInfo dllInfo = ADALGetAccessTokenForWindowsIntegrated(stsURL, servicePrincipalName, clientConnectionId, clientId, expirationFileTime, authLogger);
/*     */     
/*  85 */     return dllInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] generateClientContext(byte[] pin, boolean[] done) throws SQLServerException {
/*  92 */     int[] outsize = new int[1];
/*  93 */     outsize[0] = getMaxSSPIBlobSize();
/*  94 */     byte[] pOut = new byte[outsize[0]];
/*     */ 
/*     */     
/*  97 */     assert this.dnsName != null;
/*     */     
/*  99 */     int failure = SNISecGenClientContext(this.sniSec, this.sniSecLen, pin, pin.length, pOut, outsize, done, this.dnsName, this.port, null, null, authLogger);
/*     */ 
/*     */     
/* 102 */     if (failure != 0) {
/* 103 */       if (authLogger.isLoggable(Level.WARNING)) {
/* 104 */         authLogger.warning(toString() + " Authentication failed code : " + toString());
/*     */       }
/* 106 */       this.con.terminate(0, 
/* 107 */           SQLServerException.getErrString("R_integratedAuthenticationFailed"), linkError);
/*     */     } 
/*     */     
/* 110 */     byte[] output = new byte[outsize[0]];
/* 111 */     System.arraycopy(pOut, 0, output, 0, outsize[0]);
/* 112 */     return output;
/*     */   }
/*     */   
/*     */   void releaseClientContext() {
/* 116 */     int success = 0;
/* 117 */     if (this.sniSecLen[0] > 0) {
/* 118 */       success = SNISecReleaseClientContext(this.sniSec, this.sniSecLen[0], authLogger);
/* 119 */       this.sniSecLen[0] = 0;
/*     */     } 
/* 121 */     if (authLogger.isLoggable(Level.FINER)) {
/* 122 */       authLogger.finer(toString() + " Release client context status : " + toString());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static String initDNSArray(String address) {
/* 129 */     String[] dns = new String[1];
/* 130 */     if (GetDNSName(address, dns, authLogger) != 0)
/*     */     {
/* 132 */       dns[0] = address;
/*     */     }
/* 134 */     return dns[0];
/*     */   }
/*     */   
/*     */   private static native int SNISecGenClientContext(byte[] paramArrayOfbyte1, int[] paramArrayOfint1, byte[] paramArrayOfbyte2, int paramInt1, byte[] paramArrayOfbyte3, int[] paramArrayOfint2, boolean[] paramArrayOfboolean, String paramString1, int paramInt2, String paramString2, String paramString3, Logger paramLogger);
/*     */   
/*     */   private static native int SNISecReleaseClientContext(byte[] paramArrayOfbyte, int paramInt, Logger paramLogger);
/*     */   
/*     */   private static native int SNISecInitPackage(int[] paramArrayOfint, Logger paramLogger);
/*     */   
/*     */   private static native int SNISecTerminatePackage(Logger paramLogger);
/*     */   
/*     */   private static native int SNIGetSID(byte[] paramArrayOfbyte, Logger paramLogger);
/*     */   
/*     */   private static native boolean SNIIsEqualToCurrentSID(byte[] paramArrayOfbyte, Logger paramLogger);
/*     */   
/*     */   private static native int GetDNSName(String paramString, String[] paramArrayOfString, Logger paramLogger);
/*     */   
/*     */   private static synchronized native FedAuthDllInfo ADALGetAccessTokenForWindowsIntegrated(String paramString1, String paramString2, String paramString3, String paramString4, long paramLong, Logger paramLogger);
/*     */   
/*     */   static synchronized native byte[] DecryptColumnEncryptionKey(String paramString1, String paramString2, byte[] paramArrayOfbyte) throws DLLException;
/*     */   
/*     */   static synchronized native boolean VerifyColumnMasterKeyMetadata(String paramString, boolean paramBoolean, byte[] paramArrayOfbyte) throws DLLException;
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\AuthenticationJNI.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */