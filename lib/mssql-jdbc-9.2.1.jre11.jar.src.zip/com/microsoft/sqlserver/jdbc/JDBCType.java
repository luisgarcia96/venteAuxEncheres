/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.math.BigDecimal;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Date;
/*      */ import java.sql.NClob;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.text.MessageFormat;
/*      */ import java.time.LocalDateTime;
/*      */ import java.time.OffsetDateTime;
/*      */ import java.time.OffsetTime;
/*      */ import java.util.EnumMap;
/*      */ import java.util.EnumSet;
/*      */ import microsoft.sql.DateTimeOffset;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ enum JDBCType
/*      */ {
/*  624 */   UNKNOWN(Category.UNKNOWN, 999, Object.class.getName()),
/*  625 */   ARRAY(Category.UNKNOWN, 2003, Object.class.getName()),
/*  626 */   BIGINT(Category.NUMERIC, -5, Long.class.getName()),
/*  627 */   BINARY(Category.BINARY, -2, "[B"),
/*  628 */   BIT(Category.NUMERIC, -7, Boolean.class.getName()),
/*  629 */   BLOB(Category.BLOB, 2004, Blob.class.getName()),
/*  630 */   BOOLEAN(Category.NUMERIC, 16, Boolean.class.getName()),
/*  631 */   CHAR(Category.CHARACTER, 1, String.class.getName()),
/*  632 */   CLOB(Category.CLOB, 2005, Clob.class.getName()),
/*  633 */   DATALINK(Category.UNKNOWN, 70, Object.class.getName()),
/*  634 */   DATE(Category.DATE, 91, Date.class.getName()),
/*  635 */   DATETIMEOFFSET(Category.DATETIMEOFFSET, -155, DateTimeOffset.class
/*  636 */     .getName()),
/*  637 */   DECIMAL(Category.NUMERIC, 3, BigDecimal.class.getName()),
/*  638 */   DISTINCT(Category.UNKNOWN, 2001, Object.class.getName()),
/*  639 */   DOUBLE(Category.NUMERIC, 8, Double.class.getName()),
/*  640 */   FLOAT(Category.NUMERIC, 6, Double.class.getName()),
/*  641 */   INTEGER(Category.NUMERIC, 4, Integer.class.getName()),
/*  642 */   JAVA_OBJECT(Category.UNKNOWN, 2000, Object.class.getName()),
/*  643 */   LONGNVARCHAR(Category.LONG_NCHARACTER, -16, String.class.getName()),
/*  644 */   LONGVARBINARY(Category.LONG_BINARY, -4, "[B"),
/*  645 */   LONGVARCHAR(Category.LONG_CHARACTER, -1, String.class.getName()),
/*  646 */   NCHAR(Category.NCHARACTER, -15, String.class.getName()),
/*  647 */   NCLOB(Category.NCLOB, 2011, NClob.class.getName()),
/*  648 */   NULL(Category.UNKNOWN, 0, Object.class.getName()),
/*  649 */   NUMERIC(Category.NUMERIC, 2, BigDecimal.class.getName()),
/*  650 */   NVARCHAR(Category.NCHARACTER, -9, String.class.getName()),
/*  651 */   OTHER(Category.UNKNOWN, 1111, Object.class.getName()),
/*  652 */   REAL(Category.NUMERIC, 7, Float.class.getName()),
/*  653 */   REF(Category.UNKNOWN, 2006, Object.class.getName()),
/*  654 */   ROWID(Category.UNKNOWN, -8, Object.class.getName()),
/*  655 */   SMALLINT(Category.NUMERIC, 5, Short.class.getName()),
/*  656 */   SQLXML(Category.SQLXML, 2009, Object.class.getName()),
/*  657 */   STRUCT(Category.UNKNOWN, 2002, Object.class.getName()),
/*  658 */   TIME(Category.TIME, 92, Time.class.getName()),
/*  659 */   TIME_WITH_TIMEZONE(Category.TIME_WITH_TIMEZONE, 2013, OffsetTime.class.getName()),
/*  660 */   TIMESTAMP(Category.TIMESTAMP, 93, Timestamp.class.getName()),
/*  661 */   TIMESTAMP_WITH_TIMEZONE(Category.TIMESTAMP_WITH_TIMEZONE, 2014, OffsetDateTime.class.getName()),
/*  662 */   TINYINT(Category.NUMERIC, -6, Short.class.getName()),
/*  663 */   VARBINARY(Category.BINARY, -3, "[B"),
/*  664 */   VARCHAR(Category.CHARACTER, 12, String.class.getName()),
/*  665 */   MONEY(Category.NUMERIC, -148, BigDecimal.class.getName()),
/*  666 */   SMALLMONEY(Category.NUMERIC, -146, BigDecimal.class.getName()),
/*  667 */   TVP(Category.TVP, -153, Object.class.getName()),
/*  668 */   DATETIME(Category.TIMESTAMP, -151, Timestamp.class.getName()),
/*  669 */   SMALLDATETIME(Category.TIMESTAMP, -150, Timestamp.class.getName()),
/*  670 */   GUID(Category.CHARACTER, -145, String.class.getName()),
/*  671 */   SQL_VARIANT(Category.SQL_VARIANT, -156, Object.class.getName()),
/*  672 */   GEOMETRY(Category.GEOMETRY, -157, Object.class.getName()),
/*  673 */   GEOGRAPHY(Category.GEOGRAPHY, -158, Object.class.getName()),
/*  674 */   LOCALDATETIME(Category.TIMESTAMP, 93, LocalDateTime.class.getName());
/*      */   final Category category;
/*      */   private final int intValue;
/*      */   private final String className; private static final JDBCType[] VALUES; private static final EnumSet<JDBCType> signedTypes; private static final EnumSet<JDBCType> binaryTypes; private static final EnumSet<Category> textualCategories; final String className() { return this.className; } JDBCType(Category category, int intValue, String className) { this.category = category;
/*      */     this.intValue = intValue;
/*  679 */     this.className = className; } public int getIntValue() { return this.intValue; } static { VALUES = values();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  943 */     signedTypes = EnumSet.of(SMALLINT, new JDBCType[] { INTEGER, BIGINT, REAL, FLOAT, DOUBLE, DECIMAL, NUMERIC, MONEY, SMALLMONEY });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  955 */     binaryTypes = EnumSet.of(BINARY, VARBINARY, LONGVARBINARY, BLOB);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  970 */     textualCategories = EnumSet.of(Category.CHARACTER, new Category[] { Category.LONG_CHARACTER, Category.CLOB, Category.NCHARACTER, Category.LONG_NCHARACTER, Category.NCLOB }); }
/*      */   enum Category {
/*      */     CHARACTER, LONG_CHARACTER, CLOB, NCHARACTER, LONG_NCHARACTER, NCLOB, BINARY, LONG_BINARY, BLOB, NUMERIC, DATE, TIME, TIMESTAMP, TIME_WITH_TIMEZONE, TIMESTAMP_WITH_TIMEZONE, DATETIMEOFFSET, SQLXML, UNKNOWN, TVP, GUID, SQL_VARIANT, GEOMETRY, GEOGRAPHY;
/*      */     private static final Category[] VALUES = values(); static {  } } enum SetterConversion {
/*  974 */     CHARACTER((String)JDBCType.Category.CHARACTER, EnumSet.of(JDBCType.Category.NUMERIC, new JDBCType.Category[] { JDBCType.Category.DATE, JDBCType.Category.TIME, JDBCType.Category.TIMESTAMP, JDBCType.Category.DATETIMEOFFSET, JDBCType.Category.CHARACTER, JDBCType.Category.LONG_CHARACTER, JDBCType.Category.NCHARACTER, JDBCType.Category.LONG_NCHARACTER, JDBCType.Category.BINARY, JDBCType.Category.LONG_BINARY, JDBCType.Category.GUID, JDBCType.Category.SQL_VARIANT })), LONG_CHARACTER((String)JDBCType.Category.LONG_CHARACTER, EnumSet.of(JDBCType.Category.CHARACTER, new JDBCType.Category[] { JDBCType.Category.LONG_CHARACTER, JDBCType.Category.NCHARACTER, JDBCType.Category.LONG_NCHARACTER, JDBCType.Category.BINARY, JDBCType.Category.LONG_BINARY })), CLOB((String)JDBCType.Category.CLOB, EnumSet.of(JDBCType.Category.CLOB, JDBCType.Category.LONG_CHARACTER, JDBCType.Category.LONG_NCHARACTER)), NCHARACTER((String)JDBCType.Category.NCHARACTER, EnumSet.of(JDBCType.Category.NCHARACTER, JDBCType.Category.LONG_NCHARACTER, JDBCType.Category.NCLOB, JDBCType.Category.SQL_VARIANT)), LONG_NCHARACTER((String)JDBCType.Category.LONG_NCHARACTER, EnumSet.of(JDBCType.Category.NCHARACTER, JDBCType.Category.LONG_NCHARACTER)), NCLOB((String)JDBCType.Category.NCLOB, EnumSet.of(JDBCType.Category.LONG_NCHARACTER, JDBCType.Category.NCLOB)), BINARY((String)JDBCType.Category.BINARY, EnumSet.of(JDBCType.Category.NUMERIC, new JDBCType.Category[] { JDBCType.Category.DATE, JDBCType.Category.TIME, JDBCType.Category.TIMESTAMP, JDBCType.Category.CHARACTER, JDBCType.Category.LONG_CHARACTER, JDBCType.Category.NCHARACTER, JDBCType.Category.LONG_NCHARACTER, JDBCType.Category.BINARY, JDBCType.Category.LONG_BINARY, JDBCType.Category.BLOB, JDBCType.Category.GUID, JDBCType.Category.SQL_VARIANT })), LONG_BINARY((String)JDBCType.Category.LONG_BINARY, EnumSet.of(JDBCType.Category.BINARY, JDBCType.Category.LONG_BINARY)), BLOB((String)JDBCType.Category.BLOB, EnumSet.of(JDBCType.Category.LONG_BINARY, JDBCType.Category.BLOB)), NUMERIC((String)JDBCType.Category.NUMERIC, EnumSet.of(JDBCType.Category.NUMERIC, new JDBCType.Category[] { JDBCType.Category.CHARACTER, JDBCType.Category.LONG_CHARACTER, JDBCType.Category.NCHARACTER, JDBCType.Category.LONG_NCHARACTER, JDBCType.Category.SQL_VARIANT })), DATE((String)JDBCType.Category.DATE, EnumSet.of(JDBCType.Category.DATE, new JDBCType.Category[] { JDBCType.Category.TIMESTAMP, JDBCType.Category.DATETIMEOFFSET, JDBCType.Category.CHARACTER, JDBCType.Category.LONG_CHARACTER, JDBCType.Category.NCHARACTER, JDBCType.Category.LONG_NCHARACTER, JDBCType.Category.SQL_VARIANT })), TIME((String)JDBCType.Category.TIME, EnumSet.of(JDBCType.Category.TIME, new JDBCType.Category[] { JDBCType.Category.TIMESTAMP, JDBCType.Category.DATETIMEOFFSET, JDBCType.Category.CHARACTER, JDBCType.Category.LONG_CHARACTER, JDBCType.Category.NCHARACTER, JDBCType.Category.LONG_NCHARACTER, JDBCType.Category.SQL_VARIANT })), TIMESTAMP((String)JDBCType.Category.TIMESTAMP, EnumSet.of(JDBCType.Category.DATE, new JDBCType.Category[] { JDBCType.Category.TIME, JDBCType.Category.TIMESTAMP, JDBCType.Category.DATETIMEOFFSET, JDBCType.Category.CHARACTER, JDBCType.Category.LONG_CHARACTER, JDBCType.Category.NCHARACTER, JDBCType.Category.LONG_NCHARACTER, JDBCType.Category.SQL_VARIANT })), TIME_WITH_TIMEZONE((String)JDBCType.Category.TIME_WITH_TIMEZONE, EnumSet.of(JDBCType.Category.TIME_WITH_TIMEZONE, JDBCType.Category.CHARACTER, JDBCType.Category.LONG_CHARACTER, JDBCType.Category.NCHARACTER, JDBCType.Category.LONG_NCHARACTER)), TIMESTAMP_WITH_TIMEZONE((String)JDBCType.Category.TIMESTAMP_WITH_TIMEZONE, EnumSet.of(JDBCType.Category.TIMESTAMP_WITH_TIMEZONE, new JDBCType.Category[] { JDBCType.Category.TIME_WITH_TIMEZONE, JDBCType.Category.CHARACTER, JDBCType.Category.LONG_CHARACTER, JDBCType.Category.NCHARACTER, JDBCType.Category.LONG_NCHARACTER })), DATETIMEOFFSET((String)JDBCType.Category.DATETIMEOFFSET, EnumSet.of(JDBCType.Category.DATE, JDBCType.Category.TIME, JDBCType.Category.TIMESTAMP, JDBCType.Category.DATETIMEOFFSET)), SQLXML((String)JDBCType.Category.SQLXML, EnumSet.of(JDBCType.Category.SQLXML)), TVP((String)JDBCType.Category.TVP, EnumSet.of(JDBCType.Category.TVP)), GEOMETRY((String)JDBCType.Category.GEOMETRY, EnumSet.of(JDBCType.Category.GEOMETRY)), GEOGRAPHY((String)JDBCType.Category.GEOGRAPHY, EnumSet.of(JDBCType.Category.GEOGRAPHY)); private final JDBCType.Category from; private final EnumSet<JDBCType.Category> to; private static final SetterConversion[] VALUES = values(); private static final EnumMap<JDBCType.Category, EnumSet<JDBCType.Category>> conversionMap = new EnumMap<>(JDBCType.Category.class); static { for (JDBCType.Category category : JDBCType.Category.VALUES) conversionMap.put(category, EnumSet.noneOf(JDBCType.Category.class));  for (SetterConversion conversion : VALUES) ((EnumSet<JDBCType.Category>)conversionMap.get(conversion.from)).addAll(conversion.to);  } SetterConversion(JDBCType.Category from, EnumSet<JDBCType.Category> to) { this.from = from; this.to = to; } static boolean converts(JDBCType fromJDBCType, JDBCType toJDBCType) { return ((EnumSet)conversionMap.get(fromJDBCType.category)).contains(toJDBCType.category); } } boolean isTextual() { return textualCategories.contains(this.category); } boolean convertsTo(JDBCType jdbcType) { return SetterConversion.converts(this, jdbcType); } enum UpdaterConversion {
/*      */     CHARACTER((String)JDBCType.Category.CHARACTER, EnumSet.of(SSType.Category.NUMERIC, new SSType.Category[] { SSType.Category.DATE, SSType.Category.TIME, SSType.Category.DATETIME, SSType.Category.DATETIME2, SSType.Category.DATETIMEOFFSET, SSType.Category.CHARACTER, SSType.Category.LONG_CHARACTER, SSType.Category.NCHARACTER, SSType.Category.LONG_NCHARACTER, SSType.Category.XML, SSType.Category.BINARY, SSType.Category.LONG_BINARY, SSType.Category.UDT, SSType.Category.GUID, SSType.Category.TIMESTAMP, SSType.Category.SQL_VARIANT })), LONG_CHARACTER((String)JDBCType.Category.LONG_CHARACTER, EnumSet.of(SSType.Category.CHARACTER, new SSType.Category[] { SSType.Category.LONG_CHARACTER, SSType.Category.NCHARACTER, SSType.Category.LONG_NCHARACTER, SSType.Category.XML, SSType.Category.BINARY, SSType.Category.LONG_BINARY })), CLOB((String)JDBCType.Category.CLOB, EnumSet.of(SSType.Category.LONG_CHARACTER, SSType.Category.LONG_NCHARACTER, SSType.Category.XML)), NCHARACTER((String)JDBCType.Category.NCHARACTER, EnumSet.of(SSType.Category.NCHARACTER, SSType.Category.LONG_NCHARACTER, SSType.Category.XML, SSType.Category.SQL_VARIANT)), LONG_NCHARACTER((String)JDBCType.Category.LONG_NCHARACTER, EnumSet.of(SSType.Category.NCHARACTER, SSType.Category.LONG_NCHARACTER, SSType.Category.XML)), NCLOB((String)JDBCType.Category.NCLOB, EnumSet.of(SSType.Category.LONG_NCHARACTER, SSType.Category.XML)), BINARY((String)JDBCType.Category.BINARY, EnumSet.of(SSType.Category.NUMERIC, new SSType.Category[] { SSType.Category.DATETIME, SSType.Category.CHARACTER, SSType.Category.LONG_CHARACTER, SSType.Category.NCHARACTER, SSType.Category.LONG_NCHARACTER, SSType.Category.XML, SSType.Category.BINARY, SSType.Category.LONG_BINARY, SSType.Category.UDT, SSType.Category.TIMESTAMP, SSType.Category.GUID, SSType.Category.SQL_VARIANT })), LONG_BINARY((String)JDBCType.Category.LONG_BINARY, EnumSet.of(SSType.Category.XML, SSType.Category.BINARY, SSType.Category.LONG_BINARY, SSType.Category.UDT)), BLOB((String)JDBCType.Category.BLOB, EnumSet.of(SSType.Category.LONG_BINARY, SSType.Category.XML)), SQLXML((String)JDBCType.Category.SQLXML, EnumSet.of(SSType.Category.XML)), NUMERIC((String)JDBCType.Category.NUMERIC, EnumSet.of(SSType.Category.NUMERIC, new SSType.Category[] { SSType.Category.CHARACTER, SSType.Category.LONG_CHARACTER, SSType.Category.NCHARACTER, SSType.Category.LONG_NCHARACTER, SSType.Category.SQL_VARIANT })), DATE((String)JDBCType.Category.DATE, EnumSet.of(SSType.Category.DATE, new SSType.Category[] { SSType.Category.DATETIME, SSType.Category.DATETIME2, SSType.Category.DATETIMEOFFSET, SSType.Category.CHARACTER, SSType.Category.LONG_CHARACTER, SSType.Category.NCHARACTER, SSType.Category.LONG_NCHARACTER, SSType.Category.SQL_VARIANT })), TIME((String)JDBCType.Category.TIME, EnumSet.of(SSType.Category.TIME, new SSType.Category[] { SSType.Category.DATETIME, SSType.Category.DATETIME2, SSType.Category.DATETIMEOFFSET, SSType.Category.CHARACTER, SSType.Category.LONG_CHARACTER, SSType.Category.NCHARACTER, SSType.Category.LONG_NCHARACTER, SSType.Category.SQL_VARIANT })), TIMESTAMP((String)JDBCType.Category.TIMESTAMP, EnumSet.of(SSType.Category.DATE, new SSType.Category[] { SSType.Category.TIME, SSType.Category.DATETIME, SSType.Category.DATETIME2, SSType.Category.DATETIMEOFFSET, SSType.Category.CHARACTER, SSType.Category.LONG_CHARACTER, SSType.Category.NCHARACTER, SSType.Category.LONG_NCHARACTER, SSType.Category.SQL_VARIANT })), DATETIMEOFFSET((String)JDBCType.Category.DATETIMEOFFSET, EnumSet.of(SSType.Category.DATE, new SSType.Category[] { SSType.Category.TIME, SSType.Category.DATETIME, SSType.Category.DATETIME2, SSType.Category.DATETIMEOFFSET, SSType.Category.CHARACTER, SSType.Category.LONG_CHARACTER, SSType.Category.NCHARACTER, SSType.Category.LONG_NCHARACTER })), TIME_WITH_TIMEZONE((String)JDBCType.Category.TIME_WITH_TIMEZONE, EnumSet.of(SSType.Category.TIME, new SSType.Category[] { SSType.Category.DATETIME, SSType.Category.DATETIME2, SSType.Category.DATETIMEOFFSET, SSType.Category.CHARACTER, SSType.Category.LONG_CHARACTER, SSType.Category.NCHARACTER, SSType.Category.LONG_NCHARACTER })), TIMESTAMP_WITH_TIMEZONE((String)JDBCType.Category.TIMESTAMP_WITH_TIMEZONE, EnumSet.of(SSType.Category.DATE, new SSType.Category[] { SSType.Category.TIME, SSType.Category.DATETIME, SSType.Category.DATETIME2, SSType.Category.DATETIMEOFFSET, SSType.Category.CHARACTER, SSType.Category.LONG_CHARACTER, SSType.Category.NCHARACTER, SSType.Category.LONG_NCHARACTER })), SQL_VARIANT((String)JDBCType.Category.SQL_VARIANT, EnumSet.of(SSType.Category.SQL_VARIANT)); private final JDBCType.Category from; private final EnumSet<SSType.Category> to; private static final UpdaterConversion[] VALUES = values(); private static final EnumMap<JDBCType.Category, EnumSet<SSType.Category>> conversionMap = new EnumMap<>(JDBCType.Category.class);
/*      */     static { for (JDBCType.Category category : JDBCType.Category.VALUES) conversionMap.put(category, EnumSet.noneOf(SSType.Category.class));  for (UpdaterConversion conversion : VALUES) ((EnumSet<SSType.Category>)conversionMap.get(conversion.from)).addAll(conversion.to);  }
/*      */     UpdaterConversion(JDBCType.Category from, EnumSet<SSType.Category> to) { this.from = from; this.to = to; }
/*      */     static boolean converts(JDBCType fromJDBCType, SSType toSSType) { return ((EnumSet)conversionMap.get(fromJDBCType.category)).contains(toSSType.category); } }
/*      */   boolean convertsTo(SSType ssType) { return UpdaterConversion.converts(this, ssType); }
/*      */   static JDBCType of(int intValue) throws SQLServerException { for (JDBCType jdbcType : VALUES) { if (jdbcType.intValue == intValue) return jdbcType;  }  MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_unknownJDBCType")); Object[] msgArgs = { Integer.valueOf(intValue) }; SQLServerException.makeFromDriverError(null, null, form.format(msgArgs), null, true); return UNKNOWN; }
/*      */   boolean isSigned() { return signedTypes.contains(this); }
/*      */   boolean isBinary() { return binaryTypes.contains(this); }
/*  983 */   boolean isUnsupported() { return (Category.UNKNOWN == this.category); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int asJavaSqlType() {
/*  992 */     if ("1.5".equals(Util.SYSTEM_SPEC_VERSION)) {
/*  993 */       switch (this) {
/*      */         case NCHAR:
/*  995 */           return 1;
/*      */         case NVARCHAR:
/*      */         case SQLXML:
/*  998 */           return 12;
/*      */         case LONGNVARCHAR:
/* 1000 */           return -1;
/*      */         case NCLOB:
/* 1002 */           return 2005;
/*      */         case ROWID:
/* 1004 */           return 1111;
/*      */       } 
/* 1006 */       return this.intValue;
/*      */     } 
/*      */     
/* 1009 */     return this.intValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   enum NormalizationAE
/*      */   {
/* 1017 */     CHARACTER_NORMALIZED_TO((String)JDBCType.CHAR, EnumSet.of(SSType.CHAR, SSType.VARCHAR, SSType.VARCHARMAX)),
/*      */     
/* 1019 */     VARCHARACTER_NORMALIZED_TO((String)JDBCType.VARCHAR, EnumSet.of(SSType.CHAR, SSType.VARCHAR, SSType.VARCHARMAX)),
/*      */     
/* 1021 */     LONGVARCHARACTER_NORMALIZED_TO((String)JDBCType.LONGVARCHAR, EnumSet.of(SSType.CHAR, SSType.VARCHAR, SSType.VARCHARMAX)),
/*      */ 
/*      */     
/* 1024 */     NCHAR_NORMALIZED_TO((String)JDBCType.NCHAR, EnumSet.of(SSType.NCHAR, SSType.NVARCHAR, SSType.NVARCHARMAX)),
/*      */     
/* 1026 */     NVARCHAR_NORMALIZED_TO((String)JDBCType.NVARCHAR, EnumSet.of(SSType.NCHAR, SSType.NVARCHAR, SSType.NVARCHARMAX)),
/*      */     
/* 1028 */     LONGNVARCHAR_NORMALIZED_TO((String)JDBCType.LONGNVARCHAR, EnumSet.of(SSType.NCHAR, SSType.NVARCHAR, SSType.NVARCHARMAX)),
/*      */ 
/*      */     
/* 1031 */     BIT_NORMALIZED_TO((String)JDBCType.BIT, EnumSet.of(SSType.BIT, SSType.TINYINT, SSType.SMALLINT, SSType.INTEGER, SSType.BIGINT)),
/*      */ 
/*      */     
/* 1034 */     TINYINT_NORMALIZED_TO((String)JDBCType.TINYINT, EnumSet.of(SSType.TINYINT, SSType.SMALLINT, SSType.INTEGER, SSType.BIGINT)),
/*      */ 
/*      */     
/* 1037 */     SMALLINT_NORMALIZED_TO((String)JDBCType.SMALLINT, EnumSet.of(SSType.SMALLINT, SSType.INTEGER, SSType.BIGINT)),
/*      */     
/* 1039 */     INTEGER_NORMALIZED_TO((String)JDBCType.INTEGER, EnumSet.of(SSType.INTEGER, SSType.BIGINT)),
/*      */     
/* 1041 */     BIGINT_NORMALIZED_TO((String)JDBCType.BIGINT, EnumSet.of(SSType.BIGINT)),
/*      */     
/* 1043 */     BINARY_NORMALIZED_TO((String)JDBCType.BINARY, EnumSet.of(SSType.BINARY, SSType.VARBINARY, SSType.VARBINARYMAX)),
/*      */     
/* 1045 */     VARBINARY_NORMALIZED_TO((String)JDBCType.VARBINARY, EnumSet.of(SSType.BINARY, SSType.VARBINARY, SSType.VARBINARYMAX)),
/*      */     
/* 1047 */     LONGVARBINARY_NORMALIZED_TO((String)JDBCType.LONGVARBINARY, EnumSet.of(SSType.BINARY, SSType.VARBINARY, SSType.VARBINARYMAX)),
/*      */ 
/*      */     
/* 1050 */     FLOAT_NORMALIZED_TO((String)JDBCType.DOUBLE, EnumSet.of(SSType.FLOAT)),
/*      */     
/* 1052 */     REAL_NORMALIZED_TO((String)JDBCType.REAL, EnumSet.of(SSType.REAL)),
/*      */     
/* 1054 */     DECIMAL_NORMALIZED_TO((String)JDBCType.DECIMAL, EnumSet.of(SSType.DECIMAL, SSType.NUMERIC)),
/*      */     
/* 1056 */     SMALLMONEY_NORMALIZED_TO((String)JDBCType.SMALLMONEY, EnumSet.of(SSType.SMALLMONEY, SSType.MONEY)),
/*      */     
/* 1058 */     MONEY_NORMALIZED_TO((String)JDBCType.MONEY, EnumSet.of(SSType.MONEY)),
/*      */     
/* 1060 */     NUMERIC_NORMALIZED_TO((String)JDBCType.NUMERIC, EnumSet.of(SSType.DECIMAL, SSType.NUMERIC)),
/*      */     
/* 1062 */     DATE_NORMALIZED_TO((String)JDBCType.DATE, EnumSet.of(SSType.DATE)),
/*      */     
/* 1064 */     TIME_NORMALIZED_TO((String)JDBCType.TIME, EnumSet.of(SSType.TIME)),
/*      */     
/* 1066 */     DATETIME2_NORMALIZED_TO((String)JDBCType.TIMESTAMP, EnumSet.of(SSType.DATETIME2)),
/*      */     
/* 1068 */     DATETIMEOFFSET_NORMALIZED_TO((String)JDBCType.DATETIMEOFFSET, EnumSet.of(SSType.DATETIMEOFFSET)),
/*      */     
/* 1070 */     DATETIME_NORMALIZED_TO((String)JDBCType.DATETIME, EnumSet.of(SSType.DATETIME)),
/*      */     
/* 1072 */     SMALLDATETIME_NORMALIZED_TO((String)JDBCType.SMALLDATETIME, EnumSet.of(SSType.SMALLDATETIME)),
/*      */     
/* 1074 */     GUID_NORMALIZED_TO((String)JDBCType.GUID, EnumSet.of(SSType.GUID));
/*      */     
/*      */     private final JDBCType from;
/*      */     private final EnumSet<SSType> to;
/* 1078 */     private static final NormalizationAE[] VALUES = values();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1085 */     private static final EnumMap<JDBCType, EnumSet<SSType>> normalizationMapAE = new EnumMap<>(JDBCType.class);
/*      */     
/*      */     static {
/* 1088 */       for (JDBCType jdbcType : JDBCType.VALUES) {
/* 1089 */         normalizationMapAE.put(jdbcType, EnumSet.noneOf(SSType.class));
/*      */       }
/* 1091 */       for (NormalizationAE conversion : VALUES)
/* 1092 */         ((EnumSet<SSType>)normalizationMapAE.get(conversion.from)).addAll(conversion.to);  } NormalizationAE(JDBCType from, EnumSet<SSType> to) {
/*      */       this.from = from;
/*      */       this.to = to;
/*      */     } static boolean converts(JDBCType fromJDBCType, SSType toSSType) {
/* 1096 */       return ((EnumSet)normalizationMapAE.get(fromJDBCType)).contains(toSSType);
/*      */     }
/*      */   }
/*      */   
/*      */   boolean normalizationCheck(SSType ssType) {
/* 1101 */     return NormalizationAE.converts(this, ssType);
/*      */   }
/*      */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\JDBCType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */