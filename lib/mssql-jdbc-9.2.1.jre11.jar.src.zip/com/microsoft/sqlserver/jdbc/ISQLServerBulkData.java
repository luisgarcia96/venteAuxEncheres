package com.microsoft.sqlserver.jdbc;

import java.io.Serializable;
import java.sql.SQLException;
import java.util.Set;

public interface ISQLServerBulkData extends Serializable {
  Set<Integer> getColumnOrdinals();
  
  String getColumnName(int paramInt);
  
  int getColumnType(int paramInt);
  
  int getPrecision(int paramInt);
  
  int getScale(int paramInt);
  
  Object[] getRowData() throws SQLException;
  
  boolean next() throws SQLException;
}


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\ISQLServerBulkData.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */