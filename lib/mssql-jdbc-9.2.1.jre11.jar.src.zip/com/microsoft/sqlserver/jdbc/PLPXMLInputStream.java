/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class PLPXMLInputStream
/*     */   extends PLPInputStream
/*     */ {
/* 410 */   private static final byte[] xmlBOM = new byte[] { -1, -2 };
/* 411 */   private final ByteArrayInputStream bomStream = new ByteArrayInputStream(xmlBOM);
/*     */ 
/*     */ 
/*     */   
/*     */   static final PLPXMLInputStream makeXMLStream(TDSReader tdsReader, InputStreamGetterArgs getterArgs, ServerDTVImpl dtv) throws SQLServerException {
/* 416 */     long payloadLength = tdsReader.readLong();
/*     */ 
/*     */     
/* 419 */     if (-1L == payloadLength) {
/* 420 */       return null;
/*     */     }
/* 422 */     PLPXMLInputStream is = new PLPXMLInputStream(tdsReader, payloadLength, getterArgs, dtv);
/* 423 */     is.setLoggingInfo(getterArgs.logContext);
/*     */     
/* 425 */     return is;
/*     */   }
/*     */ 
/*     */   
/*     */   PLPXMLInputStream(TDSReader tdsReader, long statedPayloadLength, InputStreamGetterArgs getterArgs, ServerDTVImpl dtv) throws SQLServerException {
/* 430 */     super(tdsReader, statedPayloadLength, getterArgs.isAdaptive, getterArgs.isStreaming, dtv);
/*     */   }
/*     */ 
/*     */   
/*     */   int readBytes(byte[] b, int offset, int maxBytes) throws IOException {
/* 435 */     assert offset >= 0;
/* 436 */     assert maxBytes >= 0;
/*     */     
/* 438 */     if (0 == maxBytes) {
/* 439 */       return 0;
/*     */     }
/* 441 */     int bytesRead = 0;
/* 442 */     int xmlBytesRead = 0;
/*     */ 
/*     */     
/* 445 */     if (null == b) {
/*     */       int bomBytesSkipped;
/*     */       
/* 448 */       while (bytesRead < maxBytes && 0 != (bomBytesSkipped = (int)this.bomStream.skip(maxBytes - bytesRead))) {
/* 449 */         bytesRead += bomBytesSkipped;
/*     */       }
/*     */     } else {
/*     */       int bomBytesRead;
/* 453 */       while (bytesRead < maxBytes && -1 != (bomBytesRead = this.bomStream.read(b, offset + bytesRead, maxBytes - bytesRead))) {
/* 454 */         bytesRead += bomBytesRead;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 459 */     while (bytesRead < maxBytes && -1 != (xmlBytesRead = super.readBytes(b, offset + bytesRead, maxBytes - bytesRead))) {
/* 460 */       bytesRead += xmlBytesRead;
/*     */     }
/* 462 */     if (bytesRead > 0) {
/* 463 */       return bytesRead;
/*     */     }
/*     */     
/* 466 */     assert -1 == xmlBytesRead;
/* 467 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public void mark(int readLimit) {
/* 472 */     this.bomStream.mark(xmlBOM.length);
/* 473 */     super.mark(readLimit);
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset() throws IOException {
/* 478 */     this.bomStream.reset();
/* 479 */     super.reset();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getBytes() throws SQLServerException {
/* 489 */     byte[] bom = new byte[2];
/* 490 */     byte[] bytesToReturn = null;
/*     */     
/*     */     try {
/* 493 */       int bytesread = this.bomStream.read(bom);
/* 494 */       byte[] valueWithoutBOM = super.getBytes();
/*     */       
/* 496 */       if (bytesread > 0)
/* 497 */       { assert 2 == bytesread;
/* 498 */         byte[] valueWithBOM = new byte[valueWithoutBOM.length + bytesread];
/* 499 */         System.arraycopy(bom, 0, valueWithBOM, 0, bytesread);
/* 500 */         System.arraycopy(valueWithoutBOM, 0, valueWithBOM, bytesread, valueWithoutBOM.length);
/* 501 */         bytesToReturn = valueWithBOM; }
/*     */       else
/* 503 */       { bytesToReturn = valueWithoutBOM; } 
/* 504 */     } catch (IOException e) {
/* 505 */       SQLServerException.makeFromDriverError(null, null, e.getMessage(), null, true);
/*     */     } 
/*     */     
/* 508 */     return bytesToReturn;
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\PLPXMLInputStream.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */