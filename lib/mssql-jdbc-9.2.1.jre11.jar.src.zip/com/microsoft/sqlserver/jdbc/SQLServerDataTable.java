/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SQLServerDataTable
/*     */ {
/*  28 */   int rowCount = 0;
/*  29 */   int columnCount = 0;
/*  30 */   Map<Integer, SQLServerDataColumn> columnMetadata = null;
/*  31 */   Set<String> columnNames = null;
/*  32 */   Map<Integer, Object[]> rows = null;
/*  33 */   private String tvpName = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SQLServerDataTable() throws SQLServerException {
/*  44 */     this.columnMetadata = new LinkedHashMap<>();
/*  45 */     this.columnNames = new HashSet<>();
/*  46 */     this.rows = (Map)new HashMap<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void clear() {
/*  53 */     this.rowCount = 0;
/*  54 */     this.columnCount = 0;
/*  55 */     this.columnMetadata.clear();
/*  56 */     this.columnNames.clear();
/*  57 */     this.rows.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Iterator<Map.Entry<Integer, Object[]>> getIterator() {
/*  66 */     if (null != this.rows && null != this.rows.entrySet()) {
/*  67 */       return this.rows.entrySet().iterator();
/*     */     }
/*  69 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void addColumnMetadata(String columnName, int sqlType) throws SQLServerException {
/*  84 */     Util.checkDuplicateColumnName(columnName, this.columnNames);
/*  85 */     this.columnMetadata.put(Integer.valueOf(this.columnCount++), new SQLServerDataColumn(columnName, sqlType));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void addColumnMetadata(SQLServerDataColumn column) throws SQLServerException {
/*  98 */     Util.checkDuplicateColumnName(column.columnName, this.columnNames);
/*  99 */     this.columnMetadata.put(Integer.valueOf(this.columnCount++), column);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void addRow(Object... values) throws SQLServerException {
/*     */     try {
/* 112 */       int columnCount = this.columnMetadata.size();
/*     */       
/* 114 */       if (null != values && values.length > columnCount) {
/*     */         
/* 116 */         MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_moreDataInRowThanColumnInTVP"));
/* 117 */         Object[] msgArgs = new Object[0];
/* 118 */         throw new SQLServerException(null, form.format(msgArgs), null, 0, false);
/*     */       } 
/*     */       
/* 121 */       Iterator<Map.Entry<Integer, SQLServerDataColumn>> columnsIterator = this.columnMetadata.entrySet().iterator();
/* 122 */       Object[] rowValues = new Object[columnCount];
/* 123 */       int currentColumn = 0;
/* 124 */       while (columnsIterator.hasNext()) {
/* 125 */         Object val = null;
/*     */         
/* 127 */         if (null != values && currentColumn < values.length && null != values[currentColumn])
/* 128 */           val = values[currentColumn]; 
/* 129 */         currentColumn++;
/* 130 */         Map.Entry<Integer, SQLServerDataColumn> pair = columnsIterator.next();
/* 131 */         JDBCType jdbcType = JDBCType.of(((SQLServerDataColumn)pair.getValue()).javaSqlType);
/* 132 */         internalAddrow(jdbcType, val, rowValues, pair);
/*     */       } 
/* 134 */       this.rows.put(Integer.valueOf(this.rowCount++), rowValues);
/* 135 */     } catch (NumberFormatException e) {
/* 136 */       throw new SQLServerException(SQLServerException.getErrString("R_TVPInvalidColumnValue"), e);
/* 137 */     } catch (ClassCastException e) {
/* 138 */       throw new SQLServerException(SQLServerException.getErrString("R_TVPInvalidColumnValue"), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void internalAddrow(JDBCType jdbcType, Object val, Object[] rowValues, Map.Entry<Integer, SQLServerDataColumn> pair) throws SQLServerException {
/* 159 */     int key = ((Integer)pair.getKey()).intValue();
/*     */     
/* 161 */     if (null != val) {
/* 162 */       int nValueLen; BigDecimal bd; boolean isColumnMetadataUpdated; int precision, numberOfDigitsIntegerPart; JDBCType internalJDBCType; JavaType javaType; SQLServerDataColumn currentColumnMetadata = pair.getValue();
/*     */ 
/*     */       
/* 165 */       switch (jdbcType) {
/*     */         case BIGINT:
/* 167 */           rowValues[key] = (val instanceof Long) ? val : Long.valueOf(Long.parseLong(val.toString()));
/*     */           return;
/*     */         
/*     */         case BIT:
/* 171 */           if (val instanceof Boolean) {
/* 172 */             rowValues[key] = val;
/*     */           } else {
/* 174 */             String valString = val.toString();
/*     */             
/* 176 */             if ("0".equals(valString) || valString.equalsIgnoreCase(Boolean.FALSE.toString())) {
/* 177 */               rowValues[key] = Boolean.FALSE;
/* 178 */             } else if ("1".equals(valString) || valString.equalsIgnoreCase(Boolean.TRUE.toString())) {
/* 179 */               rowValues[key] = Boolean.TRUE;
/*     */             } else {
/*     */               
/* 182 */               MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_TVPInvalidColumnValue"));
/* 183 */               Object[] arrayOfObject = { jdbcType };
/* 184 */               throw new SQLServerException(null, messageFormat.format(arrayOfObject), null, 0, false);
/*     */             } 
/*     */           } 
/*     */           return;
/*     */         
/*     */         case INTEGER:
/* 190 */           rowValues[key] = (val instanceof Integer) ? val : Integer.valueOf(Integer.parseInt(val.toString()));
/*     */           return;
/*     */         
/*     */         case SMALLINT:
/*     */         case TINYINT:
/* 195 */           rowValues[key] = (val instanceof Short) ? val : Short.valueOf(Short.parseShort(val.toString()));
/*     */           return;
/*     */         
/*     */         case DECIMAL:
/*     */         case NUMERIC:
/* 200 */           bd = null;
/* 201 */           isColumnMetadataUpdated = false;
/* 202 */           bd = new BigDecimal(val.toString());
/*     */ 
/*     */           
/* 205 */           precision = Util.getValueLengthBaseOnJavaType(bd, JavaType.of(bd), null, null, jdbcType);
/* 206 */           if (bd.scale() > currentColumnMetadata.scale) {
/* 207 */             currentColumnMetadata.scale = bd.scale();
/* 208 */             isColumnMetadataUpdated = true;
/*     */           } 
/* 210 */           if (precision > currentColumnMetadata.precision) {
/* 211 */             currentColumnMetadata.precision = precision;
/* 212 */             isColumnMetadataUpdated = true;
/*     */           } 
/*     */ 
/*     */           
/* 216 */           numberOfDigitsIntegerPart = precision - bd.scale();
/* 217 */           if (numberOfDigitsIntegerPart > currentColumnMetadata.numberOfDigitsIntegerPart) {
/* 218 */             currentColumnMetadata.numberOfDigitsIntegerPart = numberOfDigitsIntegerPart;
/* 219 */             isColumnMetadataUpdated = true;
/*     */           } 
/*     */           
/* 222 */           if (isColumnMetadataUpdated) {
/* 223 */             currentColumnMetadata.precision = currentColumnMetadata.scale + currentColumnMetadata.numberOfDigitsIntegerPart;
/*     */             
/* 225 */             this.columnMetadata.put(pair.getKey(), currentColumnMetadata);
/*     */           } 
/* 227 */           rowValues[key] = bd;
/*     */           return;
/*     */         
/*     */         case DOUBLE:
/* 231 */           rowValues[key] = (val instanceof Double) ? val : Double.valueOf(Double.parseDouble(val.toString()));
/*     */           return;
/*     */         
/*     */         case FLOAT:
/*     */         case REAL:
/* 236 */           rowValues[key] = (val instanceof Float) ? val : Float.valueOf(Float.parseFloat(val.toString()));
/*     */           return;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case TIMESTAMP_WITH_TIMEZONE:
/*     */         case TIME_WITH_TIMEZONE:
/*     */         case DATE:
/*     */         case TIME:
/*     */         case TIMESTAMP:
/*     */         case DATETIMEOFFSET:
/*     */         case DATETIME:
/*     */         case SMALLDATETIME:
/* 252 */           if (val instanceof java.util.Date || val instanceof microsoft.sql.DateTimeOffset || val instanceof java.time.OffsetDateTime || val instanceof java.time.OffsetTime) {
/*     */             
/* 254 */             rowValues[key] = val.toString();
/*     */           } else {
/* 256 */             rowValues[key] = val;
/*     */           } 
/*     */           return;
/*     */         case BINARY:
/*     */         case VARBINARY:
/*     */         case LONGVARBINARY:
/* 262 */           nValueLen = ((byte[])val).length;
/*     */           
/* 264 */           if (nValueLen > currentColumnMetadata.precision) {
/* 265 */             currentColumnMetadata.precision = nValueLen;
/* 266 */             this.columnMetadata.put(pair.getKey(), currentColumnMetadata);
/*     */           } 
/* 268 */           rowValues[key] = val;
/*     */           return;
/*     */         
/*     */         case CHAR:
/*     */         case VARCHAR:
/*     */         case NCHAR:
/*     */         case NVARCHAR:
/*     */         case LONGVARCHAR:
/*     */         case LONGNVARCHAR:
/*     */         case SQLXML:
/* 278 */           if (val instanceof java.util.UUID)
/* 279 */             val = val.toString(); 
/* 280 */           nValueLen = 2 * ((String)val).length();
/*     */           
/* 282 */           if (nValueLen > currentColumnMetadata.precision) {
/* 283 */             currentColumnMetadata.precision = nValueLen;
/* 284 */             this.columnMetadata.put(pair.getKey(), currentColumnMetadata);
/*     */           } 
/* 286 */           rowValues[key] = val;
/*     */           return;
/*     */ 
/*     */         
/*     */         case SQL_VARIANT:
/* 291 */           javaType = JavaType.of(val);
/* 292 */           internalJDBCType = javaType.getJDBCType(SSType.UNKNOWN, jdbcType);
/* 293 */           internalAddrow(internalJDBCType, val, rowValues, pair);
/*     */           return;
/*     */       } 
/*     */       
/* 297 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_unsupportedDataTypeTVP"));
/* 298 */       Object[] msgArgs = { jdbcType };
/* 299 */       throw new SQLServerException(null, form.format(msgArgs), null, 0, false);
/*     */     } 
/*     */     
/* 302 */     rowValues[key] = null;
/* 303 */     if (jdbcType == JDBCType.SQL_VARIANT) {
/* 304 */       throw new SQLServerException(SQLServerException.getErrString("R_invalidValueForTVPWithSQLVariant"), null);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Map<Integer, SQLServerDataColumn> getColumnMetadata() {
/* 317 */     return this.columnMetadata;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTvpName() {
/* 326 */     return this.tvpName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTvpName(String tvpName) {
/* 336 */     this.tvpName = tvpName;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 341 */     int hash = 7;
/* 342 */     hash = 31 * hash + this.rowCount;
/* 343 */     hash = 31 * hash + this.columnCount;
/* 344 */     hash = 31 * hash + ((null != this.columnMetadata) ? this.columnMetadata.hashCode() : 0);
/* 345 */     hash = 31 * hash + ((null != this.columnNames) ? this.columnNames.hashCode() : 0);
/* 346 */     hash = 31 * hash + getRowsHashCode();
/* 347 */     hash = 31 * hash + ((null != this.tvpName) ? this.tvpName.hashCode() : 0);
/* 348 */     return hash;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object object) {
/* 353 */     if (this == object) {
/* 354 */       return true;
/*     */     }
/*     */     
/* 357 */     if (null != object && object.getClass() == SQLServerDataTable.class) {
/* 358 */       SQLServerDataTable aSQLServerDataTable = (SQLServerDataTable)object;
/* 359 */       if (hashCode() == aSQLServerDataTable.hashCode()) {
/*     */ 
/*     */         
/* 362 */         boolean equalColumnMetadata = this.columnMetadata.equals(aSQLServerDataTable.columnMetadata);
/* 363 */         boolean equalColumnNames = this.columnNames.equals(aSQLServerDataTable.columnNames);
/* 364 */         boolean equalRowData = compareRows(aSQLServerDataTable.rows);
/*     */         
/* 366 */         return (this.rowCount == aSQLServerDataTable.rowCount && this.columnCount == aSQLServerDataTable.columnCount && this.tvpName == aSQLServerDataTable.tvpName && equalColumnMetadata && equalColumnNames && equalRowData);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 371 */     return false;
/*     */   }
/*     */   
/*     */   private int getRowsHashCode() {
/* 375 */     if (null == this.rows) {
/* 376 */       return 0;
/*     */     }
/* 378 */     int h = 0;
/* 379 */     for (Map.Entry<Integer, Object[]> entry : this.rows.entrySet()) {
/* 380 */       h += ((Integer)entry.getKey()).intValue() ^ Arrays.hashCode(entry.getValue());
/*     */     }
/* 382 */     return h;
/*     */   }
/*     */   
/*     */   private boolean compareRows(Map<Integer, Object[]> otherRows) {
/* 386 */     if (this.rows == otherRows) {
/* 387 */       return true;
/*     */     }
/* 389 */     if (this.rows.size() != otherRows.size()) {
/* 390 */       return false;
/*     */     }
/*     */     try {
/* 393 */       for (Map.Entry<Integer, Object[]> e : this.rows.entrySet()) {
/* 394 */         Integer key = e.getKey();
/* 395 */         Object[] value = e.getValue();
/* 396 */         if (null == value) {
/* 397 */           if (null != otherRows.get(key) || !otherRows.containsKey(key))
/* 398 */             return false; 
/*     */           continue;
/*     */         } 
/* 401 */         if (!Arrays.equals(value, otherRows.get(key))) {
/* 402 */           return false;
/*     */         }
/*     */       }
/*     */     
/* 406 */     } catch (ClassCastException unused) {
/* 407 */       return false;
/* 408 */     } catch (NullPointerException unused) {
/* 409 */       return false;
/*     */     } 
/* 411 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerDataTable.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */