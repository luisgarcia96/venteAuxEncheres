/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import java.util.Hashtable;
/*    */ import javax.naming.Context;
/*    */ import javax.naming.Name;
/*    */ import javax.naming.RefAddr;
/*    */ import javax.naming.Reference;
/*    */ import javax.naming.spi.ObjectFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SQLServerDataSourceObjectFactory
/*    */   implements ObjectFactory
/*    */ {
/*    */   public Object getObjectInstance(Object ref, Name name, Context c, Hashtable<?, ?> h) throws SQLServerException {
/*    */     try {
/* 37 */       Reference r = (Reference)ref;
/*    */       
/* 39 */       RefAddr ra = r.get("class");
/*    */ 
/*    */       
/* 42 */       if (null == ra) {
/* 43 */         throwInvalidDataSourceRefException();
/*    */       }
/*    */       
/* 46 */       String className = (String)ra.getContent();
/*    */       
/* 48 */       if (null == className) {
/* 49 */         throwInvalidDataSourceRefException();
/*    */       }
/*    */ 
/*    */       
/* 53 */       if ("com.microsoft.sqlserver.jdbc.SQLServerDataSource".equals(className) || "com.microsoft.sqlserver.jdbc.SQLServerConnectionPoolDataSource"
/* 54 */         .equals(className) || "com.microsoft.sqlserver.jdbc.SQLServerXADataSource"
/* 55 */         .equals(className)) {
/*    */ 
/*    */         
/* 58 */         Class<?> dataSourceClass = Class.forName(className);
/* 59 */         Object dataSourceClassInstance = dataSourceClass.getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
/*    */ 
/*    */ 
/*    */         
/* 63 */         SQLServerDataSource ds = (SQLServerDataSource)dataSourceClassInstance;
/* 64 */         ds.initializeFromReference(r);
/* 65 */         return dataSourceClassInstance;
/*    */       } 
/*    */       
/* 68 */       throwInvalidDataSourceRefException();
/* 69 */     } catch (ClassNotFoundException|InstantiationException|IllegalAccessException|IllegalArgumentException|java.lang.reflect.InvocationTargetException|NoSuchMethodException|SecurityException e) {
/*    */       
/* 71 */       throwInvalidDataSourceRefException();
/*    */     } 
/*    */     
/* 74 */     return null;
/*    */   }
/*    */   
/*    */   private void throwInvalidDataSourceRefException() throws SQLServerException {
/* 78 */     SQLServerException.makeFromDriverError(null, null, 
/* 79 */         SQLServerException.getErrString("R_invalidDataSourceReference"), null, true);
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerDataSourceObjectFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */