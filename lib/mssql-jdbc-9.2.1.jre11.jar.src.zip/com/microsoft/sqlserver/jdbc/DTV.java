/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.math.MathContext;
/*      */ import java.math.RoundingMode;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.ByteOrder;
/*      */ import java.nio.charset.StandardCharsets;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Date;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.text.MessageFormat;
/*      */ import java.time.LocalDate;
/*      */ import java.time.LocalDateTime;
/*      */ import java.time.LocalTime;
/*      */ import java.time.OffsetDateTime;
/*      */ import java.time.OffsetTime;
/*      */ import java.util.Calendar;
/*      */ import java.util.Date;
/*      */ import java.util.GregorianCalendar;
/*      */ import java.util.Locale;
/*      */ import java.util.SimpleTimeZone;
/*      */ import java.util.TimeZone;
/*      */ import java.util.UUID;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ import microsoft.sql.DateTimeOffset;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class DTV
/*      */ {
/*  125 */   private static final Logger aeLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.DTV");
/*      */ 
/*      */   
/*      */   private DTVImpl impl;
/*      */   
/*  130 */   CryptoMetadata cryptoMeta = null;
/*  131 */   JDBCType jdbcTypeSetByUser = null;
/*  132 */   int valueLength = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean sendStringParametersAsUnicode = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setValue(SQLCollation collation, JDBCType jdbcType, Object value, JavaType javaType, StreamSetterArgs streamSetterArgs, Calendar calendar, Integer scale, SQLServerConnection con, boolean forceEncrypt) throws SQLServerException {
/*  144 */     if (null == this.impl) {
/*  145 */       this.impl = new AppDTVImpl();
/*      */     }
/*  147 */     this.impl.setValue(this, collation, jdbcType, value, javaType, streamSetterArgs, calendar, scale, con, forceEncrypt);
/*      */   }
/*      */   
/*      */   final void setValue(Object value, JavaType javaType) {
/*  151 */     this.impl.setValue(value, javaType);
/*      */   }
/*      */   
/*      */   final void clear() {
/*  155 */     this.impl = null;
/*      */   }
/*      */   
/*      */   final void skipValue(TypeInfo type, TDSReader tdsReader, boolean isDiscard) throws SQLServerException {
/*  159 */     if (null == this.impl) {
/*  160 */       this.impl = new ServerDTVImpl();
/*      */     }
/*  162 */     this.impl.skipValue(type, tdsReader, isDiscard);
/*      */   }
/*      */   
/*      */   final void initFromCompressedNull() {
/*  166 */     if (null == this.impl) {
/*  167 */       this.impl = new ServerDTVImpl();
/*      */     }
/*  169 */     this.impl.initFromCompressedNull();
/*      */   }
/*      */   
/*      */   final void setStreamSetterArgs(StreamSetterArgs streamSetterArgs) {
/*  173 */     this.impl.setStreamSetterArgs(streamSetterArgs);
/*      */   }
/*      */   
/*      */   final void setCalendar(Calendar calendar) {
/*  177 */     this.impl.setCalendar(calendar);
/*      */   }
/*      */   
/*      */   final void setScale(Integer scale) {
/*  181 */     this.impl.setScale(scale);
/*      */   }
/*      */   
/*      */   final void setForceEncrypt(boolean forceEncrypt) {
/*  185 */     this.impl.setForceEncrypt(forceEncrypt);
/*      */   }
/*      */   
/*      */   StreamSetterArgs getStreamSetterArgs() {
/*  189 */     return this.impl.getStreamSetterArgs();
/*      */   }
/*      */   
/*      */   Calendar getCalendar() {
/*  193 */     return this.impl.getCalendar();
/*      */   }
/*      */   
/*      */   Integer getScale() {
/*  197 */     return this.impl.getScale();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isNull() {
/*  204 */     return (null == this.impl || this.impl.isNull());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final boolean isInitialized() {
/*  211 */     return (null != this.impl);
/*      */   }
/*      */   
/*      */   final void setJdbcType(JDBCType jdbcType) {
/*  215 */     if (null == this.impl) {
/*  216 */       this.impl = new AppDTVImpl();
/*      */     }
/*  218 */     this.impl.setJdbcType(jdbcType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final JDBCType getJdbcType() {
/*  225 */     assert null != this.impl;
/*  226 */     return this.impl.getJdbcType();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final JavaType getJavaType() {
/*  233 */     assert null != this.impl;
/*  234 */     return this.impl.getJavaType();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Object getValue(JDBCType jdbcType, int scale, InputStreamGetterArgs streamGetterArgs, Calendar cal, TypeInfo typeInfo, CryptoMetadata cryptoMetadata, TDSReader tdsReader) throws SQLServerException {
/*  245 */     if (null == this.impl)
/*  246 */       this.impl = new ServerDTVImpl(); 
/*  247 */     return this.impl.getValue(this, jdbcType, scale, streamGetterArgs, cal, typeInfo, cryptoMetadata, tdsReader);
/*      */   }
/*      */   
/*      */   Object getSetterValue() {
/*  251 */     return this.impl.getSetterValue();
/*      */   }
/*      */   
/*      */   SqlVariant getInternalVariant() {
/*  255 */     return this.impl.getInternalVariant();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setImpl(DTVImpl impl) {
/*  262 */     this.impl = impl;
/*      */   }
/*      */   
/*      */   final class SendByRPCOp
/*      */     extends DTVExecuteOp {
/*      */     private final String name;
/*      */     private final TypeInfo typeInfo;
/*      */     private final SQLCollation collation;
/*      */     private final int precision;
/*      */     private final int outScale;
/*      */     private final boolean isOutParam;
/*      */     private final TDSWriter tdsWriter;
/*      */     private final SQLServerConnection conn;
/*      */     
/*      */     SendByRPCOp(String name, TypeInfo typeInfo, SQLCollation collation, int precision, int outScale, boolean isOutParam, TDSWriter tdsWriter, SQLServerConnection conn) {
/*  277 */       this.name = name;
/*  278 */       this.typeInfo = typeInfo;
/*  279 */       this.collation = collation;
/*  280 */       this.precision = precision;
/*  281 */       this.outScale = outScale;
/*  282 */       this.isOutParam = isOutParam;
/*  283 */       this.tdsWriter = tdsWriter;
/*  284 */       this.conn = conn;
/*      */     }
/*      */     
/*      */     void execute(DTV dtv, String strValue) throws SQLServerException {
/*  288 */       this.tdsWriter.writeRPCStringUnicode(this.name, strValue, this.isOutParam, this.collation);
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV dtv, Clob clobValue) throws SQLServerException {
/*  293 */       assert null != clobValue;
/*      */       
/*  295 */       long clobLength = 0L;
/*  296 */       Reader clobReader = null;
/*      */       
/*      */       try {
/*  299 */         clobLength = DataTypes.getCheckedLength(this.conn, dtv.getJdbcType(), clobValue.length(), false);
/*  300 */         clobReader = clobValue.getCharacterStream();
/*  301 */       } catch (SQLException e) {
/*  302 */         SQLServerException.makeFromDriverError(this.conn, null, e.getMessage(), null, false);
/*      */       } 
/*      */ 
/*      */       
/*  306 */       JDBCType jdbcType = dtv.getJdbcType();
/*  307 */       if (null != this.collation && (JDBCType.CHAR == jdbcType || JDBCType.VARCHAR == jdbcType || JDBCType.LONGVARCHAR == jdbcType || JDBCType.CLOB == jdbcType)) {
/*      */         
/*  309 */         if (null == clobReader) {
/*  310 */           this.tdsWriter.writeRPCByteArray(this.name, null, this.isOutParam, jdbcType, this.collation);
/*      */         } else {
/*  312 */           ReaderInputStream clobStream = new ReaderInputStream(clobReader, this.collation.getCharset(), clobLength);
/*      */ 
/*      */           
/*  315 */           this.tdsWriter.writeRPCInputStream(this.name, clobStream, -1L, this.isOutParam, jdbcType, this.collation);
/*      */         
/*      */         }
/*      */       
/*      */       }
/*  320 */       else if (null == clobReader) {
/*  321 */         this.tdsWriter.writeRPCStringUnicode(this.name, null, this.isOutParam, this.collation);
/*      */       } else {
/*  323 */         this.tdsWriter.writeRPCReaderUnicode(this.name, clobReader, clobLength, this.isOutParam, this.collation);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV dtv, Byte byteValue) throws SQLServerException {
/*  329 */       this.tdsWriter.writeRPCByte(this.name, byteValue, this.isOutParam);
/*      */     }
/*      */     
/*      */     void execute(DTV dtv, Integer intValue) throws SQLServerException {
/*  333 */       this.tdsWriter.writeRPCInt(this.name, intValue, this.isOutParam);
/*      */     }
/*      */     
/*      */     void execute(DTV dtv, Time timeValue) throws SQLServerException {
/*  337 */       sendTemporal(dtv, JavaType.TIME, timeValue);
/*      */     }
/*      */     
/*      */     void execute(DTV dtv, Date dateValue) throws SQLServerException {
/*  341 */       sendTemporal(dtv, JavaType.DATE, dateValue);
/*      */     }
/*      */     
/*      */     void execute(DTV dtv, Timestamp timestampValue) throws SQLServerException {
/*  345 */       sendTemporal(dtv, JavaType.TIMESTAMP, timestampValue);
/*      */     }
/*      */     
/*      */     void execute(DTV dtv, Date utilDateValue) throws SQLServerException {
/*  349 */       sendTemporal(dtv, JavaType.UTILDATE, utilDateValue);
/*      */     }
/*      */     
/*      */     void execute(DTV dtv, Calendar calendarValue) throws SQLServerException {
/*  353 */       sendTemporal(dtv, JavaType.CALENDAR, calendarValue);
/*      */     }
/*      */     
/*      */     void execute(DTV dtv, LocalDate localDateValue) throws SQLServerException {
/*  357 */       sendTemporal(dtv, JavaType.LOCALDATE, localDateValue);
/*      */     }
/*      */     
/*      */     void execute(DTV dtv, LocalTime localTimeValue) throws SQLServerException {
/*  361 */       sendTemporal(dtv, JavaType.LOCALTIME, localTimeValue);
/*      */     }
/*      */     
/*      */     void execute(DTV dtv, LocalDateTime localDateTimeValue) throws SQLServerException {
/*  365 */       sendTemporal(dtv, JavaType.LOCALDATETIME, localDateTimeValue);
/*      */     }
/*      */     
/*      */     void execute(DTV dtv, OffsetTime offsetTimeValue) throws SQLServerException {
/*  369 */       sendTemporal(dtv, JavaType.OFFSETTIME, offsetTimeValue);
/*      */     }
/*      */     
/*      */     void execute(DTV dtv, OffsetDateTime offsetDateTimeValue) throws SQLServerException {
/*  373 */       sendTemporal(dtv, JavaType.OFFSETDATETIME, offsetDateTimeValue);
/*      */     }
/*      */     
/*      */     void execute(DTV dtv, DateTimeOffset dtoValue) throws SQLServerException {
/*  377 */       sendTemporal(dtv, JavaType.DATETIMEOFFSET, dtoValue);
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV dtv, TVP tvpValue) throws SQLServerException {
/*  382 */       this.tdsWriter.writeTVP(tvpValue);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void clearSetCalendar(Calendar cal, boolean lenient, Integer year, Integer month, Integer day_of_month, Integer hour_of_day, Integer minute, Integer second) {
/*  390 */       cal.clear();
/*  391 */       cal.setLenient(lenient);
/*  392 */       if (null != year) {
/*  393 */         cal.set(1, year.intValue());
/*      */       }
/*  395 */       if (null != month) {
/*  396 */         cal.set(2, month.intValue());
/*      */       }
/*  398 */       if (null != day_of_month) {
/*  399 */         cal.set(5, day_of_month.intValue());
/*      */       }
/*  401 */       if (null != hour_of_day) {
/*  402 */         cal.set(11, hour_of_day.intValue());
/*      */       }
/*  404 */       if (null != minute) {
/*  405 */         cal.set(12, minute.intValue());
/*      */       }
/*  407 */       if (null != second) {
/*  408 */         cal.set(13, second.intValue());
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void sendTemporal(DTV dtv, JavaType javaType, Object value) throws SQLServerException {
/*  428 */       JDBCType jdbcType = dtv.getJdbcType();
/*  429 */       GregorianCalendar calendar = null;
/*  430 */       int subSecondNanos = 0;
/*  431 */       int minutesOffset = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  448 */       if (null != value) {
/*  449 */         Timestamp timestampValue; LocalTime LocalTimeValue; LocalDateTime localDateTimeValue; OffsetTime offsetTimeValue; LocalDate baseDate; OffsetDateTime offsetDateTimeValue; DateTimeOffset dtoValue; TimeZone timeZone = TimeZone.getDefault();
/*      */         
/*  451 */         long utcMillis = 0L;
/*      */ 
/*      */         
/*  454 */         switch (javaType) {
/*      */ 
/*      */           
/*      */           case DATETIME:
/*  458 */             timeZone = (null != dtv.getCalendar()) ? dtv.getCalendar().getTimeZone() : TimeZone.getDefault();
/*      */             
/*  460 */             utcMillis = ((Time)value).getTime();
/*  461 */             subSecondNanos = 1000000 * (int)(utcMillis % 1000L);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  470 */             if (subSecondNanos < 0) {
/*  471 */               subSecondNanos += 1000000000;
/*      */             }
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case DATETIME2:
/*  479 */             timeZone = (null != dtv.getCalendar()) ? dtv.getCalendar().getTimeZone() : TimeZone.getDefault();
/*      */             
/*  481 */             utcMillis = ((Date)value).getTime();
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case DATE:
/*  488 */             timeZone = (null != dtv.getCalendar()) ? dtv.getCalendar().getTimeZone() : TimeZone.getDefault();
/*      */             
/*  490 */             timestampValue = (Timestamp)value;
/*  491 */             utcMillis = timestampValue.getTime();
/*  492 */             subSecondNanos = timestampValue.getNanos();
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case TIME:
/*  501 */             timeZone = (null != dtv.getCalendar()) ? dtv.getCalendar().getTimeZone() : TimeZone.getDefault();
/*      */             
/*  503 */             utcMillis = ((Date)value).getTime();
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  508 */             subSecondNanos = 1000000 * (int)(utcMillis % 1000L);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  517 */             if (subSecondNanos < 0) {
/*  518 */               subSecondNanos += 1000000000;
/*      */             }
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case DATETIMEOFFSET:
/*  527 */             timeZone = (null != dtv.getCalendar()) ? dtv.getCalendar().getTimeZone() : TimeZone.getDefault();
/*      */             
/*  529 */             utcMillis = ((Calendar)value).getTimeInMillis();
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  534 */             subSecondNanos = 1000000 * (int)(utcMillis % 1000L);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  543 */             if (subSecondNanos < 0) {
/*  544 */               subSecondNanos += 1000000000;
/*      */             }
/*      */             break;
/*      */ 
/*      */           
/*      */           case SMALLDATETIME:
/*  550 */             calendar = new GregorianCalendar(UTC.timeZone, Locale.US);
/*      */ 
/*      */             
/*  553 */             clearSetCalendar(calendar, true, Integer.valueOf(((LocalDate)value).getYear()), 
/*  554 */                 Integer.valueOf(((LocalDate)value).getMonthValue() - 1), 
/*      */ 
/*      */ 
/*      */                 
/*  558 */                 Integer.valueOf(((LocalDate)value).getDayOfMonth()), null, null, null);
/*      */             break;
/*      */ 
/*      */           
/*      */           case VARBINARY:
/*  563 */             calendar = new GregorianCalendar(UTC.timeZone, Locale.US);
/*      */ 
/*      */             
/*  566 */             LocalTimeValue = (LocalTime)value;
/*  567 */             clearSetCalendar(calendar, true, Integer.valueOf(this.conn.baseYear()), Integer.valueOf(1), Integer.valueOf(1), Integer.valueOf(LocalTimeValue.getHour()), 
/*      */ 
/*      */                 
/*  570 */                 Integer.valueOf(LocalTimeValue.getMinute()), Integer.valueOf(LocalTimeValue.getSecond()));
/*  571 */             subSecondNanos = LocalTimeValue.getNano();
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case VARBINARYMAX:
/*  580 */             calendar = new GregorianCalendar(UTC.timeZone, Locale.US);
/*      */             
/*  582 */             localDateTimeValue = (LocalDateTime)value;
/*  583 */             clearSetCalendar(calendar, true, Integer.valueOf(localDateTimeValue.getYear()), 
/*  584 */                 Integer.valueOf(localDateTimeValue.getMonthValue() - 1), Integer.valueOf(localDateTimeValue.getDayOfMonth()), 
/*  585 */                 Integer.valueOf(localDateTimeValue.getHour()), 
/*  586 */                 Integer.valueOf(localDateTimeValue.getMinute()), Integer.valueOf(localDateTimeValue.getSecond()));
/*  587 */             subSecondNanos = localDateTimeValue.getNano();
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case null:
/*  594 */             offsetTimeValue = (OffsetTime)value;
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             try {
/*  600 */               minutesOffset = offsetTimeValue.getOffset().getTotalSeconds() / 60;
/*  601 */             } catch (Exception e) {
/*  602 */               throw new SQLServerException(SQLServerException.getErrString("R_zoneOffsetError"), null, 0, e);
/*      */             } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  616 */             subSecondNanos = offsetTimeValue.getNano();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  627 */             timeZone = (JDBCType.TIME_WITH_TIMEZONE == jdbcType && (null == this.typeInfo || SSType.DATETIMEOFFSET == this.typeInfo.getSSType())) ? UTC.timeZone : new SimpleTimeZone(minutesOffset * 60 * 1000, "");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  633 */             baseDate = LocalDate.of(this.conn.baseYear(), 1, 1);
/*  634 */             utcMillis = offsetTimeValue.atDate(baseDate).toEpochSecond() * 1000L;
/*      */             break;
/*      */           
/*      */           case null:
/*  638 */             offsetDateTimeValue = (OffsetDateTime)value;
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             try {
/*  644 */               minutesOffset = offsetDateTimeValue.getOffset().getTotalSeconds() / 60;
/*  645 */             } catch (Exception e) {
/*  646 */               throw new SQLServerException(SQLServerException.getErrString("R_zoneOffsetError"), null, 0, e);
/*      */             } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  661 */             subSecondNanos = offsetDateTimeValue.getNano();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  673 */             timeZone = ((JDBCType.TIMESTAMP_WITH_TIMEZONE == jdbcType || JDBCType.TIME_WITH_TIMEZONE == jdbcType) && (null == this.typeInfo || SSType.DATETIMEOFFSET == this.typeInfo.getSSType())) ? UTC.timeZone : new SimpleTimeZone(minutesOffset * 60 * 1000, "");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  679 */             utcMillis = offsetDateTimeValue.toEpochSecond() * 1000L;
/*      */             break;
/*      */           
/*      */           case null:
/*  683 */             dtoValue = (DateTimeOffset)value;
/*  684 */             utcMillis = dtoValue.getTimestamp().getTime();
/*  685 */             subSecondNanos = dtoValue.getTimestamp().getNanos();
/*  686 */             minutesOffset = dtoValue.getMinutesOffset();
/*      */ 
/*      */ 
/*      */             
/*  690 */             assert null == dtv.getCalendar();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  703 */             timeZone = (JDBCType.DATETIMEOFFSET == jdbcType && (null == this.typeInfo || SSType.DATETIMEOFFSET == this.typeInfo.getSSType() || SSType.VARBINARY == this.typeInfo.getSSType() || SSType.VARBINARYMAX == this.typeInfo.getSSType())) ? UTC.timeZone : new SimpleTimeZone(minutesOffset * 60 * 1000, "");
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           default:
/*  712 */             throw new AssertionError("Unexpected JavaType: " + javaType);
/*      */         } 
/*      */ 
/*      */         
/*  716 */         if (null == calendar) {
/*      */ 
/*      */           
/*  719 */           calendar = new GregorianCalendar(timeZone, Locale.US);
/*      */ 
/*      */ 
/*      */           
/*  723 */           calendar.setLenient(true);
/*      */ 
/*      */ 
/*      */           
/*  727 */           calendar.clear();
/*      */ 
/*      */           
/*  730 */           calendar.setTimeInMillis(utcMillis);
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  738 */       if (null != this.typeInfo) {
/*      */         int scale;
/*  740 */         switch (this.typeInfo.getSSType()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case DATETIME:
/*      */           case DATETIME2:
/*  749 */             scale = (this.typeInfo.getSSType() == SSType.DATETIME) ? (this.typeInfo.getScale() + 4) : this.typeInfo.getScale();
/*  750 */             this.tdsWriter.writeRPCDateTime2(this.name, 
/*  751 */                 timestampNormalizedCalendar(calendar, javaType, this.conn.baseYear()), subSecondNanos, scale, this.isOutParam);
/*      */             return;
/*      */ 
/*      */ 
/*      */           
/*      */           case DATE:
/*  757 */             this.tdsWriter.writeRPCDate(this.name, calendar, this.isOutParam);
/*      */             return;
/*      */ 
/*      */ 
/*      */           
/*      */           case TIME:
/*  763 */             this.tdsWriter.writeRPCTime(this.name, calendar, subSecondNanos, this.typeInfo.getScale(), this.isOutParam);
/*      */             return;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case DATETIMEOFFSET:
/*  771 */             if (JavaType.DATETIMEOFFSET != javaType) {
/*  772 */               calendar = timestampNormalizedCalendar(localCalendarAsUTC(calendar), javaType, this.conn
/*  773 */                   .baseYear());
/*      */               
/*  775 */               minutesOffset = 0;
/*      */             } 
/*      */             
/*  778 */             this.tdsWriter.writeRPCDateTimeOffset(this.name, calendar, minutesOffset, subSecondNanos, this.typeInfo
/*  779 */                 .getScale(), this.isOutParam);
/*      */             return;
/*      */ 
/*      */           
/*      */           case SMALLDATETIME:
/*  784 */             this.tdsWriter.writeRPCDateTime(this.name, 
/*  785 */                 timestampNormalizedCalendar(calendar, javaType, this.conn.baseYear()), subSecondNanos, this.isOutParam);
/*      */             return;
/*      */ 
/*      */           
/*      */           case VARBINARY:
/*      */           case VARBINARYMAX:
/*  791 */             switch (jdbcType) {
/*      */               case DATETIME:
/*      */               case DATETIME2:
/*  794 */                 this.tdsWriter.writeEncryptedRPCDateTime(this.name, 
/*  795 */                     timestampNormalizedCalendar(calendar, javaType, this.conn.baseYear()), subSecondNanos, this.isOutParam, jdbcType);
/*      */                 return;
/*      */ 
/*      */               
/*      */               case DATE:
/*  800 */                 assert null != DTV.this.cryptoMeta;
/*  801 */                 this.tdsWriter.writeEncryptedRPCDateTime2(this.name, 
/*  802 */                     timestampNormalizedCalendar(calendar, javaType, this.conn.baseYear()), subSecondNanos, DTV.this.valueLength, this.isOutParam);
/*      */                 return;
/*      */ 
/*      */ 
/*      */               
/*      */               case TIME:
/*  808 */                 assert null != DTV.this.cryptoMeta;
/*  809 */                 this.tdsWriter.writeEncryptedRPCTime(this.name, calendar, subSecondNanos, DTV.this.valueLength, this.isOutParam);
/*      */                 return;
/*      */ 
/*      */               
/*      */               case DATETIMEOFFSET:
/*  814 */                 assert null != DTV.this.cryptoMeta;
/*  815 */                 this.tdsWriter.writeEncryptedRPCDate(this.name, calendar, this.isOutParam);
/*      */                 return;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               case SMALLDATETIME:
/*      */               case VARBINARY:
/*  824 */                 if (JavaType.DATETIMEOFFSET != javaType && JavaType.OFFSETDATETIME != javaType) {
/*  825 */                   calendar = timestampNormalizedCalendar(localCalendarAsUTC(calendar), javaType, this.conn
/*  826 */                       .baseYear());
/*      */                   
/*  828 */                   minutesOffset = 0;
/*      */                 } 
/*      */                 
/*  831 */                 assert null != DTV.this.cryptoMeta;
/*  832 */                 this.tdsWriter.writeEncryptedRPCDateTimeOffset(this.name, calendar, minutesOffset, subSecondNanos, DTV.this.valueLength, this.isOutParam);
/*      */                 return;
/*      */             } 
/*      */ 
/*      */             
/*  837 */             assert false : "Unexpected JDBCType: " + jdbcType;
/*      */             return;
/*      */         } 
/*      */ 
/*      */         
/*  842 */         assert false : "Unexpected SSType: " + this.typeInfo.getSSType();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*  855 */       else if (this.conn.isKatmaiOrLater()) {
/*  856 */         if (DTV.aeLogger.isLoggable(Level.FINE) && null != DTV.this.cryptoMeta) {
/*  857 */           DTV.aeLogger.fine("Encrypting temporal data type.");
/*      */         }
/*      */         
/*  860 */         switch (jdbcType) {
/*      */           case DATETIME:
/*      */           case DATETIME2:
/*      */           case DATE:
/*  864 */             if (null != DTV.this.cryptoMeta) {
/*  865 */               if (JDBCType.DATETIME == jdbcType || JDBCType.SMALLDATETIME == jdbcType) {
/*  866 */                 this.tdsWriter.writeEncryptedRPCDateTime(this.name, 
/*  867 */                     timestampNormalizedCalendar(calendar, javaType, this.conn.baseYear()), subSecondNanos, this.isOutParam, jdbcType);
/*      */               }
/*  869 */               else if (0 == DTV.this.valueLength) {
/*  870 */                 this.tdsWriter.writeEncryptedRPCDateTime2(this.name, 
/*  871 */                     timestampNormalizedCalendar(calendar, javaType, this.conn.baseYear()), subSecondNanos, this.outScale, this.isOutParam);
/*      */               } else {
/*      */                 
/*  874 */                 this.tdsWriter.writeEncryptedRPCDateTime2(this.name, 
/*  875 */                     timestampNormalizedCalendar(calendar, javaType, this.conn.baseYear()), subSecondNanos, DTV.this.valueLength, this.isOutParam);
/*      */               } 
/*      */             } else {
/*      */               
/*  879 */               this.tdsWriter.writeRPCDateTime2(this.name, 
/*  880 */                   timestampNormalizedCalendar(calendar, javaType, this.conn.baseYear()), subSecondNanos, 7, this.isOutParam);
/*      */             } 
/*      */             return;
/*      */ 
/*      */ 
/*      */           
/*      */           case TIME:
/*  887 */             if (null != DTV.this.cryptoMeta) {
/*  888 */               if (0 == DTV.this.valueLength) {
/*  889 */                 this.tdsWriter.writeEncryptedRPCTime(this.name, calendar, subSecondNanos, this.outScale, this.isOutParam);
/*      */               } else {
/*      */                 
/*  892 */                 this.tdsWriter.writeEncryptedRPCTime(this.name, calendar, subSecondNanos, DTV.this.valueLength, this.isOutParam);
/*      */               
/*      */               }
/*      */ 
/*      */             
/*      */             }
/*  898 */             else if (this.conn.getSendTimeAsDatetime()) {
/*  899 */               this.tdsWriter.writeRPCDateTime(this.name, 
/*  900 */                   timestampNormalizedCalendar(calendar, JavaType.TIME, 1970), subSecondNanos, this.isOutParam);
/*      */             } else {
/*      */               
/*  903 */               this.tdsWriter.writeRPCTime(this.name, calendar, subSecondNanos, 7, this.isOutParam);
/*      */             } 
/*      */             return;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case DATETIMEOFFSET:
/*  911 */             if (null != DTV.this.cryptoMeta) {
/*  912 */               this.tdsWriter.writeEncryptedRPCDate(this.name, calendar, this.isOutParam);
/*      */             } else {
/*  914 */               this.tdsWriter.writeRPCDate(this.name, calendar, this.isOutParam);
/*      */             } 
/*      */             return;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case VARBINARYMAX:
/*  922 */             if (JavaType.OFFSETDATETIME != javaType && JavaType.OFFSETTIME != javaType) {
/*  923 */               calendar = timestampNormalizedCalendar(localCalendarAsUTC(calendar), javaType, this.conn
/*  924 */                   .baseYear());
/*      */               
/*  926 */               minutesOffset = 0;
/*      */             } 
/*      */             
/*  929 */             this.tdsWriter.writeRPCDateTimeOffset(this.name, calendar, minutesOffset, subSecondNanos, 7, this.isOutParam);
/*      */             return;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case SMALLDATETIME:
/*      */           case VARBINARY:
/*  940 */             if (JavaType.DATETIMEOFFSET != javaType && JavaType.OFFSETDATETIME != javaType) {
/*  941 */               calendar = timestampNormalizedCalendar(localCalendarAsUTC(calendar), javaType, this.conn
/*  942 */                   .baseYear());
/*      */               
/*  944 */               minutesOffset = 0;
/*      */             } 
/*      */             
/*  947 */             if (null != DTV.this.cryptoMeta) {
/*  948 */               if (0 == DTV.this.valueLength) {
/*  949 */                 this.tdsWriter.writeEncryptedRPCDateTimeOffset(this.name, calendar, minutesOffset, subSecondNanos, this.outScale, this.isOutParam);
/*      */               } else {
/*      */                 
/*  952 */                 this.tdsWriter.writeEncryptedRPCDateTimeOffset(this.name, calendar, minutesOffset, subSecondNanos, 
/*      */                     
/*  954 */                     (0 == DTV.this.valueLength) ? 7 : DTV.this.valueLength, this.isOutParam);
/*      */               } 
/*      */             } else {
/*      */               
/*  958 */               this.tdsWriter.writeRPCDateTimeOffset(this.name, calendar, minutesOffset, subSecondNanos, 7, this.isOutParam);
/*      */             } 
/*      */             return;
/*      */         } 
/*      */ 
/*      */         
/*  964 */         assert false : "Unexpected JDBCType: " + jdbcType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  978 */         assert JDBCType.TIME == jdbcType || JDBCType.DATE == jdbcType || JDBCType.TIMESTAMP == jdbcType : "Unexpected JDBCType: " + jdbcType;
/*      */ 
/*      */         
/*  981 */         this.tdsWriter.writeRPCDateTime(this.name, 
/*  982 */             timestampNormalizedCalendar(calendar, javaType, 1970), subSecondNanos, this.isOutParam);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private GregorianCalendar timestampNormalizedCalendar(GregorianCalendar calendar, JavaType javaType, int baseYear) {
/* 1005 */       if (null != calendar) {
/* 1006 */         switch (javaType) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case DATETIME2:
/*      */           case SMALLDATETIME:
/* 1014 */             calendar.set(11, 0);
/* 1015 */             calendar.set(12, 0);
/* 1016 */             calendar.set(13, 0);
/* 1017 */             calendar.set(14, 0);
/*      */             break;
/*      */           
/*      */           case DATETIME:
/*      */           case VARBINARY:
/*      */           case null:
/* 1023 */             assert 1970 == baseYear || 1900 == baseYear;
/* 1024 */             calendar.set(baseYear, 0, 1);
/*      */             break;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/* 1032 */       return calendar;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private GregorianCalendar localCalendarAsUTC(GregorianCalendar cal) {
/* 1042 */       if (null == cal) {
/* 1043 */         return null;
/*      */       }
/*      */       
/* 1046 */       int year = cal.get(1);
/* 1047 */       int month = cal.get(2);
/* 1048 */       int date = cal.get(5);
/* 1049 */       int hour = cal.get(11);
/* 1050 */       int minute = cal.get(12);
/* 1051 */       int second = cal.get(13);
/* 1052 */       int millis = cal.get(14);
/*      */       
/* 1054 */       cal.setTimeZone(UTC.timeZone);
/* 1055 */       cal.set(year, month, date, hour, minute, second);
/* 1056 */       cal.set(14, millis);
/* 1057 */       return cal;
/*      */     }
/*      */     
/*      */     void execute(DTV dtv, Float floatValue) throws SQLServerException {
/* 1061 */       if (JDBCType.REAL == dtv.getJdbcType()) {
/* 1062 */         this.tdsWriter.writeRPCReal(this.name, floatValue, this.isOutParam);
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1072 */         Double doubleValue = (null == floatValue) ? null : Double.valueOf(floatValue.floatValue());
/* 1073 */         this.tdsWriter.writeRPCDouble(this.name, doubleValue, this.isOutParam);
/*      */       } 
/*      */     }
/*      */     
/*      */     void execute(DTV dtv, Double doubleValue) throws SQLServerException {
/* 1078 */       this.tdsWriter.writeRPCDouble(this.name, doubleValue, this.isOutParam);
/*      */     }
/*      */     
/*      */     void execute(DTV dtv, BigDecimal bigDecimalValue) throws SQLServerException {
/* 1082 */       if (DDC.exceedsMaxRPCDecimalPrecisionOrScale(bigDecimalValue)) {
/* 1083 */         if (JDBCType.DECIMAL == dtv.getJdbcType() || JDBCType.NUMERIC == dtv.getJdbcType()) {
/*      */           
/* 1085 */           MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_valueOutOfRangeSQLType"));
/* 1086 */           Object[] msgArgs = { dtv.getJdbcType() };
/* 1087 */           throw new SQLServerException(form.format(msgArgs), SQLState.NUMERIC_DATA_OUT_OF_RANGE, DriverError.NOT_SET, null);
/*      */         } 
/*      */         
/* 1090 */         String strValue = bigDecimalValue.toString();
/* 1091 */         this.tdsWriter.writeRPCStringUnicode(this.name, strValue, this.isOutParam, this.collation);
/*      */       } else {
/*      */         
/* 1094 */         this.tdsWriter.writeRPCBigDecimal(this.name, bigDecimalValue, this.outScale, this.isOutParam);
/*      */       } 
/*      */     }
/*      */     
/*      */     void execute(DTV dtv, Long longValue) throws SQLServerException {
/* 1099 */       this.tdsWriter.writeRPCLong(this.name, longValue, this.isOutParam);
/*      */     }
/*      */     
/*      */     void execute(DTV dtv, BigInteger bigIntegerValue) throws SQLServerException {
/* 1103 */       this.tdsWriter.writeRPCLong(this.name, Long.valueOf(bigIntegerValue.longValue()), this.isOutParam);
/*      */     }
/*      */     
/*      */     void execute(DTV dtv, Short shortValue) throws SQLServerException {
/* 1107 */       this.tdsWriter.writeRPCShort(this.name, shortValue, this.isOutParam);
/*      */     }
/*      */     
/*      */     void execute(DTV dtv, Boolean booleanValue) throws SQLServerException {
/* 1111 */       this.tdsWriter.writeRPCBit(this.name, booleanValue, this.isOutParam);
/*      */     }
/*      */     
/*      */     void execute(DTV dtv, byte[] byteArrayValue) throws SQLServerException {
/* 1115 */       if (null != DTV.this.cryptoMeta) {
/* 1116 */         this.tdsWriter.writeRPCNameValType(this.name, this.isOutParam, TDSType.BIGVARBINARY);
/* 1117 */         if (null != byteArrayValue) {
/* 1118 */           byteArrayValue = SQLServerSecurityUtility.encryptWithKey(byteArrayValue, DTV.this.cryptoMeta, this.conn);
/* 1119 */           this.tdsWriter.writeEncryptedRPCByteArray(byteArrayValue);
/* 1120 */           writeEncryptData(dtv, false);
/*      */         }
/*      */         else {
/*      */           
/* 1124 */           if ((JDBCType.LONGVARCHAR == DTV.this.jdbcTypeSetByUser || JDBCType.LONGNVARCHAR == DTV.this.jdbcTypeSetByUser || JDBCType.LONGVARBINARY == DTV.this.jdbcTypeSetByUser || (8000 == this.precision && JDBCType.VARCHAR == DTV.this.jdbcTypeSetByUser) || (4000 == this.precision && JDBCType.NVARCHAR == DTV.this.jdbcTypeSetByUser) || (8000 == this.precision && JDBCType.VARBINARY == DTV.this.jdbcTypeSetByUser)) && null == dtv
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1131 */             .getJavaType() && this.isOutParam) {
/* 1132 */             this.tdsWriter.writeEncryptedRPCPLP();
/*      */           } else {
/* 1134 */             this.tdsWriter.writeEncryptedRPCByteArray(byteArrayValue);
/*      */           } 
/*      */           
/* 1137 */           writeEncryptData(dtv, true);
/*      */         } 
/*      */       } else {
/*      */         
/* 1141 */         this.tdsWriter.writeRPCByteArray(this.name, byteArrayValue, this.isOutParam, dtv.getJdbcType(), this.collation);
/*      */       } 
/*      */     }
/*      */     void writeEncryptData(DTV dtv, boolean isNull) throws SQLServerException {
/*      */       MessageFormat form;
/* 1146 */       JDBCType destType = (null == DTV.this.jdbcTypeSetByUser) ? dtv.getJdbcType() : DTV.this.jdbcTypeSetByUser;
/*      */       
/* 1148 */       switch (destType.getIntValue()) {
/*      */         case 4:
/* 1150 */           this.tdsWriter.writeByte(TDSType.INTN.byteValue());
/* 1151 */           this.tdsWriter.writeByte((byte)4);
/*      */           break;
/*      */         
/*      */         case -5:
/* 1155 */           this.tdsWriter.writeByte(TDSType.INTN.byteValue());
/* 1156 */           this.tdsWriter.writeByte((byte)8);
/*      */           break;
/*      */         
/*      */         case -7:
/* 1160 */           this.tdsWriter.writeByte(TDSType.BITN.byteValue());
/* 1161 */           this.tdsWriter.writeByte((byte)1);
/*      */           break;
/*      */         
/*      */         case 5:
/* 1165 */           this.tdsWriter.writeByte(TDSType.INTN.byteValue());
/* 1166 */           this.tdsWriter.writeByte((byte)2);
/*      */           break;
/*      */         
/*      */         case -6:
/* 1170 */           this.tdsWriter.writeByte(TDSType.INTN.byteValue());
/* 1171 */           this.tdsWriter.writeByte((byte)1);
/*      */           break;
/*      */         
/*      */         case 8:
/* 1175 */           this.tdsWriter.writeByte(TDSType.FLOATN.byteValue());
/* 1176 */           this.tdsWriter.writeByte((byte)8);
/*      */           break;
/*      */         
/*      */         case 7:
/* 1180 */           this.tdsWriter.writeByte(TDSType.FLOATN.byteValue());
/* 1181 */           this.tdsWriter.writeByte((byte)4);
/*      */           break;
/*      */ 
/*      */         
/*      */         case -148:
/*      */         case -146:
/*      */         case 2:
/*      */         case 3:
/* 1189 */           if (JDBCType.MONEY == destType || JDBCType.SMALLMONEY == destType) {
/* 1190 */             this.tdsWriter.writeByte(TDSType.MONEYN.byteValue());
/* 1191 */             this.tdsWriter.writeByte((byte)((JDBCType.MONEY == destType) ? 8 : 4)); break;
/*      */           } 
/* 1193 */           this.tdsWriter.writeByte(TDSType.NUMERICN.byteValue());
/* 1194 */           if (isNull) {
/* 1195 */             this.tdsWriter.writeByte((byte)17);
/*      */             
/* 1197 */             if (null != DTV.this.cryptoMeta && null != DTV.this.cryptoMeta.getBaseTypeInfo()) {
/* 1198 */               this.tdsWriter.writeByte(
/*      */                   
/* 1200 */                   (byte)((0 != DTV.this.valueLength) ? DTV.this.valueLength : DTV.this.cryptoMeta.getBaseTypeInfo().getPrecision()));
/*      */             } else {
/* 1202 */               this.tdsWriter.writeByte((byte)((0 != DTV.this.valueLength) ? DTV.this.valueLength : 18));
/*      */             } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1211 */             this.tdsWriter.writeByte((byte)this.outScale); break;
/*      */           } 
/* 1213 */           this.tdsWriter.writeByte((byte)17);
/*      */           
/* 1215 */           if (null != DTV.this.cryptoMeta && null != DTV.this.cryptoMeta.getBaseTypeInfo()) {
/* 1216 */             this.tdsWriter.writeByte((byte)DTV.this.cryptoMeta.getBaseTypeInfo().getPrecision());
/*      */           } else {
/* 1218 */             this.tdsWriter.writeByte((byte)((0 != DTV.this.valueLength) ? DTV.this.valueLength : 18));
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1227 */           if (null != DTV.this.cryptoMeta && null != DTV.this.cryptoMeta.getBaseTypeInfo()) {
/* 1228 */             this.tdsWriter.writeByte((byte)DTV.this.cryptoMeta.getBaseTypeInfo().getScale()); break;
/*      */           } 
/* 1230 */           this.tdsWriter.writeByte((byte)((null != dtv.getScale()) ? dtv.getScale().intValue() : 0));
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case -145:
/* 1238 */           this.tdsWriter.writeByte(TDSType.GUID.byteValue());
/* 1239 */           if (isNull) {
/* 1240 */             this.tdsWriter.writeByte((byte)((0 != DTV.this.valueLength) ? DTV.this.valueLength : 1)); break;
/*      */           } 
/* 1242 */           this.tdsWriter.writeByte((byte)16);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 1:
/* 1247 */           this.tdsWriter.writeByte(TDSType.BIGCHAR.byteValue());
/*      */           
/* 1249 */           if (isNull) {
/* 1250 */             this.tdsWriter.writeShort((short)((0 != DTV.this.valueLength) ? DTV.this.valueLength : 1));
/*      */           } else {
/* 1252 */             this.tdsWriter.writeShort((short)DTV.this.valueLength);
/*      */           } 
/* 1254 */           if (null != this.collation) {
/* 1255 */             this.collation.writeCollation(this.tdsWriter); break;
/*      */           } 
/* 1257 */           this.conn.getDatabaseCollation().writeCollation(this.tdsWriter);
/*      */           break;
/*      */         
/*      */         case -15:
/* 1261 */           this.tdsWriter.writeByte(TDSType.NCHAR.byteValue());
/* 1262 */           if (isNull) {
/* 1263 */             this.tdsWriter.writeShort((short)((0 != DTV.this.valueLength) ? (DTV.this.valueLength * 2) : 1));
/*      */           }
/* 1265 */           else if (this.isOutParam) {
/* 1266 */             this.tdsWriter.writeShort((short)(DTV.this.valueLength * 2));
/*      */           }
/* 1268 */           else if (DTV.this.valueLength > 8000) {
/* 1269 */             this.tdsWriter.writeShort((short)-1);
/*      */           } else {
/* 1271 */             this.tdsWriter.writeShort((short)DTV.this.valueLength);
/*      */           } 
/*      */ 
/*      */           
/* 1275 */           if (null != this.collation) {
/* 1276 */             this.collation.writeCollation(this.tdsWriter); break;
/*      */           } 
/* 1278 */           this.conn.getDatabaseCollation().writeCollation(this.tdsWriter);
/*      */           break;
/*      */ 
/*      */         
/*      */         case -1:
/*      */         case 12:
/* 1284 */           this.tdsWriter.writeByte(TDSType.BIGVARCHAR.byteValue());
/* 1285 */           if (isNull) {
/* 1286 */             if (dtv.jdbcTypeSetByUser.getIntValue() == -1) {
/* 1287 */               this.tdsWriter.writeShort((short)-1);
/*      */             } else {
/* 1289 */               this.tdsWriter.writeShort((short)((0 != DTV.this.valueLength) ? DTV.this.valueLength : 1));
/*      */             }
/*      */           
/* 1292 */           } else if (dtv.jdbcTypeSetByUser.getIntValue() == -1) {
/* 1293 */             this.tdsWriter.writeShort((short)-1);
/* 1294 */           } else if (dtv.getJdbcType().getIntValue() == -1 || dtv
/* 1295 */             .getJdbcType().getIntValue() == -16) {
/* 1296 */             this.tdsWriter.writeShort((short)1);
/*      */           }
/* 1298 */           else if (DTV.this.valueLength > 8000) {
/* 1299 */             this.tdsWriter.writeShort((short)-1);
/*      */           } else {
/* 1301 */             this.tdsWriter.writeShort((short)DTV.this.valueLength);
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/* 1306 */           if (null != this.collation) {
/* 1307 */             this.collation.writeCollation(this.tdsWriter); break;
/*      */           } 
/* 1309 */           this.conn.getDatabaseCollation().writeCollation(this.tdsWriter);
/*      */           break;
/*      */         
/*      */         case -16:
/*      */         case -9:
/* 1314 */           this.tdsWriter.writeByte(TDSType.NVARCHAR.byteValue());
/* 1315 */           if (isNull) {
/* 1316 */             if (dtv.jdbcTypeSetByUser.getIntValue() == -16) {
/* 1317 */               this.tdsWriter.writeShort((short)-1);
/*      */             } else {
/* 1319 */               this.tdsWriter.writeShort((short)((0 != DTV.this.valueLength) ? (DTV.this.valueLength * 2) : 1));
/*      */             }
/*      */           
/* 1322 */           } else if (this.isOutParam) {
/*      */ 
/*      */ 
/*      */             
/* 1326 */             if (dtv.jdbcTypeSetByUser.getIntValue() == -16) {
/* 1327 */               this.tdsWriter.writeShort((short)-1);
/*      */             } else {
/* 1329 */               this.tdsWriter.writeShort((short)(DTV.this.valueLength * 2));
/*      */             }
/*      */           
/* 1332 */           } else if (DTV.this.valueLength > 8000) {
/* 1333 */             this.tdsWriter.writeShort((short)-1);
/*      */           } else {
/* 1335 */             this.tdsWriter.writeShort((short)DTV.this.valueLength);
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/* 1340 */           if (null != this.collation) {
/* 1341 */             this.collation.writeCollation(this.tdsWriter); break;
/*      */           } 
/* 1343 */           this.conn.getDatabaseCollation().writeCollation(this.tdsWriter);
/*      */           break;
/*      */         
/*      */         case -2:
/* 1347 */           this.tdsWriter.writeByte(TDSType.BIGBINARY.byteValue());
/* 1348 */           if (isNull) {
/* 1349 */             this.tdsWriter.writeShort((short)((0 != DTV.this.valueLength) ? DTV.this.valueLength : 1)); break;
/*      */           } 
/* 1351 */           this.tdsWriter.writeShort((short)DTV.this.valueLength);
/*      */           break;
/*      */ 
/*      */         
/*      */         case -4:
/*      */         case -3:
/* 1357 */           this.tdsWriter.writeByte(TDSType.BIGVARBINARY.byteValue());
/* 1358 */           if (isNull) {
/* 1359 */             if (dtv.jdbcTypeSetByUser.getIntValue() == -4) {
/* 1360 */               this.tdsWriter.writeShort((short)-1); break;
/*      */             } 
/* 1362 */             this.tdsWriter.writeShort((short)((0 != DTV.this.valueLength) ? DTV.this.valueLength : 1));
/*      */             break;
/*      */           } 
/* 1365 */           if (dtv.jdbcTypeSetByUser.getIntValue() == -4) {
/* 1366 */             this.tdsWriter.writeShort((short)-1); break;
/*      */           } 
/* 1368 */           this.tdsWriter.writeShort((short)DTV.this.valueLength);
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 1373 */           form = new MessageFormat(SQLServerException.getErrString("R_UnsupportedDataTypeAE"));
/* 1374 */           throw new SQLServerException(form.format(new Object[] { destType }, ), null, 0, null);
/*      */       } 
/*      */       
/* 1377 */       this.tdsWriter.writeCryptoMetaData();
/*      */     }
/*      */     
/*      */     void execute(DTV dtv, Blob blobValue) throws SQLServerException {
/* 1381 */       assert null != blobValue;
/*      */       
/* 1383 */       long blobLength = 0L;
/* 1384 */       InputStream blobStream = null;
/*      */       
/*      */       try {
/* 1387 */         blobLength = DataTypes.getCheckedLength(this.conn, dtv.getJdbcType(), blobValue.length(), false);
/* 1388 */         blobStream = blobValue.getBinaryStream();
/* 1389 */       } catch (SQLException e) {
/* 1390 */         SQLServerException.makeFromDriverError(this.conn, null, e.getMessage(), null, false);
/*      */       } 
/*      */       
/* 1393 */       if (null == blobStream) {
/* 1394 */         this.tdsWriter.writeRPCByteArray(this.name, null, this.isOutParam, dtv.getJdbcType(), this.collation);
/*      */       } else {
/* 1396 */         this.tdsWriter.writeRPCInputStream(this.name, blobStream, blobLength, this.isOutParam, dtv.getJdbcType(), this.collation);
/*      */       } 
/*      */     }
/*      */     
/*      */     void execute(DTV dtv, SQLServerSQLXML xmlValue) throws SQLServerException {
/* 1401 */       InputStream o = (null == xmlValue) ? null : xmlValue.getValue();
/* 1402 */       this.tdsWriter.writeRPCXML(this.name, o, (null == o) ? 0L : dtv.getStreamSetterArgs().getLength(), this.isOutParam);
/*      */     }
/*      */     
/*      */     void execute(DTV dtv, InputStream inputStreamValue) throws SQLServerException {
/* 1406 */       this.tdsWriter.writeRPCInputStream(this.name, inputStreamValue, 
/* 1407 */           (null == inputStreamValue) ? 0L : dtv.getStreamSetterArgs().getLength(), this.isOutParam, dtv.getJdbcType(), this.collation);
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV dtv, Reader readerValue) throws SQLServerException {
/* 1412 */       JDBCType jdbcType = dtv.getJdbcType();
/*      */ 
/*      */       
/* 1415 */       assert null != readerValue;
/*      */ 
/*      */       
/* 1418 */       assert JDBCType.NCHAR == jdbcType || JDBCType.NVARCHAR == jdbcType || JDBCType.LONGNVARCHAR == jdbcType || JDBCType.NCLOB == jdbcType : "SendByRPCOp(Reader): Unexpected JDBC type " + jdbcType;
/*      */ 
/*      */ 
/*      */       
/* 1422 */       this.tdsWriter.writeRPCReaderUnicode(this.name, readerValue, dtv.getStreamSetterArgs().getLength(), this.isOutParam, this.collation);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void execute(DTV dtv, SqlVariant sqlVariantValue) throws SQLServerException {
/* 1433 */       this.tdsWriter.writeRPCSqlVariant(this.name, sqlVariantValue, this.isOutParam);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void executeOp(DTVExecuteOp op) throws SQLServerException {
/* 1444 */     JDBCType jdbcType = getJdbcType();
/* 1445 */     Object value = getSetterValue();
/* 1446 */     JavaType javaType = getJavaType();
/* 1447 */     boolean unsupportedConversion = false;
/* 1448 */     byte[] byteValue = null;
/*      */     
/* 1450 */     if (null != this.cryptoMeta && !JavaType.SetterConversionAE.converts(javaType, jdbcType, this.sendStringParametersAsUnicode)) {
/* 1451 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_unsupportedConversionAE"));
/*      */       
/* 1453 */       Object[] msgArgs = { javaType.toString().toLowerCase(Locale.ENGLISH), jdbcType.toString().toLowerCase(Locale.ENGLISH) };
/* 1454 */       throw new SQLServerException(form.format(msgArgs), null);
/*      */     } 
/*      */     
/* 1457 */     if (null == value) {
/*      */       
/* 1459 */       switch (jdbcType) {
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/* 1464 */           if (null != this.cryptoMeta) {
/* 1465 */             op.execute(this, (byte[])null); break;
/*      */           } 
/* 1467 */           op.execute(this, (String)null);
/*      */           break;
/*      */         
/*      */         case null:
/* 1471 */           if (null != this.cryptoMeta) {
/* 1472 */             op.execute(this, (byte[])null); break;
/*      */           } 
/* 1474 */           op.execute(this, (Integer)null);
/*      */           break;
/*      */         
/*      */         case DATETIMEOFFSET:
/* 1478 */           op.execute(this, (Date)null);
/*      */           break;
/*      */         
/*      */         case TIME:
/* 1482 */           op.execute(this, (Time)null);
/*      */           break;
/*      */         
/*      */         case DATETIME:
/*      */         case DATETIME2:
/*      */         case DATE:
/* 1488 */           op.execute(this, (Timestamp)null);
/*      */           break;
/*      */         
/*      */         case SMALLDATETIME:
/*      */         case VARBINARY:
/*      */         case VARBINARYMAX:
/* 1494 */           op.execute(this, (DateTimeOffset)null);
/*      */           break;
/*      */         
/*      */         case null:
/*      */         case null:
/* 1499 */           if (null != this.cryptoMeta) {
/* 1500 */             op.execute(this, (byte[])null); break;
/*      */           } 
/* 1502 */           op.execute(this, (Float)null);
/*      */           break;
/*      */         
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/* 1509 */           if (null != this.cryptoMeta) {
/* 1510 */             op.execute(this, (byte[])null); break;
/*      */           } 
/* 1512 */           op.execute(this, (BigDecimal)null);
/*      */           break;
/*      */         
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/* 1524 */           op.execute(this, (byte[])null);
/*      */           break;
/*      */         
/*      */         case null:
/* 1528 */           if (null != this.cryptoMeta) {
/* 1529 */             op.execute(this, (byte[])null); break;
/*      */           } 
/* 1531 */           op.execute(this, (Byte)null);
/*      */           break;
/*      */         
/*      */         case null:
/* 1535 */           if (null != this.cryptoMeta) {
/* 1536 */             op.execute(this, (byte[])null); break;
/*      */           } 
/* 1538 */           op.execute(this, (Long)null);
/*      */           break;
/*      */         
/*      */         case null:
/* 1542 */           if (null != this.cryptoMeta) {
/* 1543 */             op.execute(this, (byte[])null); break;
/*      */           } 
/* 1545 */           op.execute(this, (Double)null);
/*      */           break;
/*      */         
/*      */         case null:
/* 1549 */           if (null != this.cryptoMeta) {
/* 1550 */             op.execute(this, (byte[])null); break;
/*      */           } 
/* 1552 */           op.execute(this, (Short)null);
/*      */           break;
/*      */         
/*      */         case null:
/*      */         case null:
/* 1557 */           if (null != this.cryptoMeta) {
/* 1558 */             op.execute(this, (byte[])null); break;
/*      */           } 
/* 1560 */           op.execute(this, (Boolean)null);
/*      */           break;
/*      */         
/*      */         case null:
/* 1564 */           op.execute(this, (SQLServerSQLXML)null);
/*      */           break;
/*      */         
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/* 1576 */           unsupportedConversion = true;
/*      */           break;
/*      */         
/*      */         case null:
/* 1580 */           op.execute(this, (SqlVariant)null);
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 1585 */           assert false : "Unexpected JDBCType: " + jdbcType;
/* 1586 */           unsupportedConversion = true;
/*      */           break;
/*      */       } 
/*      */     
/*      */     } else {
/* 1591 */       if (aeLogger.isLoggable(Level.FINE) && null != this.cryptoMeta) {
/* 1592 */         aeLogger.fine("Encrypting java data type: " + javaType);
/*      */       }
/*      */       
/* 1595 */       switch (javaType) {
/*      */         case null:
/* 1597 */           if (JDBCType.GUID == jdbcType) {
/* 1598 */             if (null != this.cryptoMeta) {
/* 1599 */               if (value instanceof String) {
/* 1600 */                 value = UUID.fromString((String)value);
/*      */               }
/* 1602 */               byte[] bArray = Util.asGuidByteArray((UUID)value);
/* 1603 */               op.execute(this, bArray); break;
/*      */             } 
/* 1605 */             op.execute(this, String.valueOf(value)); break;
/*      */           } 
/* 1607 */           if (JDBCType.SQL_VARIANT == jdbcType) {
/* 1608 */             op.execute(this, String.valueOf(value)); break;
/* 1609 */           }  if (JDBCType.GEOMETRY == jdbcType) {
/* 1610 */             op.execute(this, ((Geometry)value).serialize()); break;
/* 1611 */           }  if (JDBCType.GEOGRAPHY == jdbcType) {
/* 1612 */             op.execute(this, ((Geography)value).serialize()); break;
/*      */           } 
/* 1614 */           if (null != this.cryptoMeta) {
/*      */ 
/*      */ 
/*      */             
/* 1618 */             if (jdbcType == JDBCType.LONGNVARCHAR && JDBCType.VARCHAR == this.jdbcTypeSetByUser && Integer.MAX_VALUE < this.valueLength) {
/*      */ 
/*      */               
/* 1621 */               MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_StreamingDataTypeAE"));
/* 1622 */               Object[] msgArgs = { Integer.valueOf(2147483647), JDBCType.LONGVARCHAR };
/* 1623 */               throw new SQLServerException(this, form.format(msgArgs), null, 0, false);
/* 1624 */             }  if (JDBCType.NVARCHAR == this.jdbcTypeSetByUser && 1073741823 < this.valueLength) {
/*      */ 
/*      */               
/* 1627 */               MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_StreamingDataTypeAE"));
/* 1628 */               Object[] msgArgs = { Integer.valueOf(1073741823), JDBCType.LONGNVARCHAR };
/* 1629 */               throw new SQLServerException(this, form.format(msgArgs), null, 0, false);
/*      */             } 
/*      */             
/* 1632 */             if (JDBCType.NVARCHAR == this.jdbcTypeSetByUser || JDBCType.NCHAR == this.jdbcTypeSetByUser || JDBCType.LONGNVARCHAR == this.jdbcTypeSetByUser) {
/*      */               
/* 1634 */               byteValue = ((String)value).getBytes(StandardCharsets.UTF_16LE);
/*      */             
/*      */             }
/* 1637 */             else if (JDBCType.VARCHAR == this.jdbcTypeSetByUser || JDBCType.CHAR == this.jdbcTypeSetByUser || JDBCType.LONGVARCHAR == this.jdbcTypeSetByUser) {
/*      */               
/* 1639 */               byteValue = ((String)value).getBytes();
/*      */             } 
/*      */             
/* 1642 */             op.execute(this, byteValue); break;
/*      */           } 
/* 1644 */           op.execute(this, (String)value);
/*      */           break;
/*      */ 
/*      */         
/*      */         case null:
/* 1649 */           if (null != this.cryptoMeta) {
/*      */             
/* 1651 */             byteValue = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(((Integer)value).longValue()).array();
/* 1652 */             op.execute(this, byteValue); break;
/*      */           } 
/* 1654 */           op.execute(this, (Integer)value);
/*      */           break;
/*      */         
/*      */         case DATETIME2:
/* 1658 */           op.execute(this, (Date)value);
/*      */           break;
/*      */         
/*      */         case DATETIME:
/* 1662 */           op.execute(this, (Time)value);
/*      */           break;
/*      */         
/*      */         case DATE:
/* 1666 */           op.execute(this, (Timestamp)value);
/*      */           break;
/*      */         
/*      */         case null:
/* 1670 */           op.execute(this, (TVP)value);
/*      */           break;
/*      */         
/*      */         case TIME:
/* 1674 */           op.execute(this, (Date)value);
/*      */           break;
/*      */         
/*      */         case DATETIMEOFFSET:
/* 1678 */           op.execute(this, (Calendar)value);
/*      */           break;
/*      */         
/*      */         case SMALLDATETIME:
/* 1682 */           op.execute(this, (LocalDate)value);
/*      */           break;
/*      */         
/*      */         case VARBINARY:
/* 1686 */           op.execute(this, (LocalTime)value);
/*      */           break;
/*      */         
/*      */         case VARBINARYMAX:
/* 1690 */           op.execute(this, (LocalDateTime)value);
/*      */           break;
/*      */         
/*      */         case null:
/* 1694 */           op.execute(this, (OffsetTime)value);
/*      */           break;
/*      */         
/*      */         case null:
/* 1698 */           op.execute(this, (OffsetDateTime)value);
/*      */           break;
/*      */         
/*      */         case null:
/* 1702 */           op.execute(this, (DateTimeOffset)value);
/*      */           break;
/*      */         
/*      */         case null:
/* 1706 */           op.execute(this, ((Geometry)value).serialize());
/*      */           break;
/*      */         
/*      */         case null:
/* 1710 */           op.execute(this, ((Geography)value).serialize());
/*      */           break;
/*      */         
/*      */         case null:
/* 1714 */           if (null != this.cryptoMeta) {
/* 1715 */             if (Float.isInfinite(((Float)value).floatValue())) {
/*      */               
/* 1717 */               MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_valueOutOfRange"));
/* 1718 */               throw new SQLServerException(form.format(new Object[] { jdbcType }, ), null, 0, null);
/*      */             } 
/*      */ 
/*      */             
/* 1722 */             byteValue = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putFloat(((Float)value).floatValue()).array();
/* 1723 */             op.execute(this, byteValue); break;
/*      */           } 
/* 1725 */           op.execute(this, (Float)value);
/*      */           break;
/*      */         
/*      */         case null:
/* 1729 */           if (null != this.cryptoMeta) {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1734 */             if (JDBCType.MONEY == jdbcType || JDBCType.SMALLMONEY == jdbcType) {
/*      */ 
/*      */ 
/*      */               
/* 1738 */               BigDecimal bdValue = (BigDecimal)value;
/*      */               
/* 1740 */               Util.validateMoneyRange(bdValue, jdbcType);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1748 */               int digitCount = Math.max(bdValue.precision() - bdValue.scale(), 0) + 4;
/*      */ 
/*      */ 
/*      */               
/* 1752 */               long moneyVal = ((BigDecimal)value).multiply(new BigDecimal(10000), new MathContext(digitCount, RoundingMode.HALF_UP)).longValue();
/* 1753 */               ByteBuffer bbuf = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN);
/* 1754 */               bbuf.putInt((int)(moneyVal >> 32L)).array();
/* 1755 */               bbuf.putInt((int)moneyVal).array();
/* 1756 */               op.execute(this, bbuf.array()); break;
/*      */             } 
/* 1758 */             BigDecimal bigDecimalVal = (BigDecimal)value;
/* 1759 */             byte[] decimalToByte = DDC.convertBigDecimalToBytes(bigDecimalVal, bigDecimalVal.scale());
/* 1760 */             byteValue = new byte[16];
/*      */             
/* 1762 */             System.arraycopy(decimalToByte, 2, byteValue, 0, decimalToByte.length - 2);
/* 1763 */             setScale(Integer.valueOf(bigDecimalVal.scale()));
/*      */             
/* 1765 */             if (null != this.cryptoMeta.getBaseTypeInfo()) {
/*      */ 
/*      */               
/* 1768 */               if (this.cryptoMeta.getBaseTypeInfo().getPrecision() < 
/* 1769 */                 Util.getValueLengthBaseOnJavaType(bigDecimalVal, javaType, null, null, jdbcType))
/*      */               {
/* 1771 */                 MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_valueOutOfRange"));
/* 1772 */                 Object[] msgArgs = { this.cryptoMeta.getBaseTypeInfo().getSSTypeName() };
/* 1773 */                 throw new SQLServerException(form.format(msgArgs), SQLState.NUMERIC_DATA_OUT_OF_RANGE, DriverError.NOT_SET, null);
/*      */ 
/*      */ 
/*      */               
/*      */               }
/*      */ 
/*      */ 
/*      */             
/*      */             }
/* 1782 */             else if (this.valueLength < Util.getValueLengthBaseOnJavaType(bigDecimalVal, javaType, null, null, jdbcType)) {
/*      */ 
/*      */               
/* 1785 */               MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_valueOutOfRange"));
/* 1786 */               Object[] msgArgs = { SSType.DECIMAL };
/* 1787 */               throw new SQLServerException(form.format(msgArgs), SQLState.NUMERIC_DATA_OUT_OF_RANGE, DriverError.NOT_SET, null);
/*      */             } 
/*      */ 
/*      */ 
/*      */             
/* 1792 */             op.execute(this, byteValue);
/*      */             break;
/*      */           } 
/* 1795 */           op.execute(this, (BigDecimal)value);
/*      */           break;
/*      */         
/*      */         case null:
/* 1799 */           if (null != this.cryptoMeta && Integer.MAX_VALUE < this.valueLength) {
/*      */             
/* 1801 */             MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_StreamingDataTypeAE"));
/* 1802 */             Object[] msgArgs = { Integer.valueOf(2147483647), JDBCType.BINARY };
/* 1803 */             throw new SQLServerException(this, form.format(msgArgs), null, 0, false);
/*      */           } 
/* 1805 */           op.execute(this, (byte[])value);
/*      */           break;
/*      */ 
/*      */         
/*      */         case null:
/* 1810 */           if (null != this.cryptoMeta) {
/*      */             
/* 1812 */             byteValue = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong((((Byte)value).byteValue() & 0xFF)).array();
/* 1813 */             op.execute(this, byteValue); break;
/*      */           } 
/* 1815 */           op.execute(this, (Byte)value);
/*      */           break;
/*      */         
/*      */         case null:
/* 1819 */           if (null != this.cryptoMeta) {
/*      */             
/* 1821 */             byteValue = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(((Long)value).longValue()).array();
/* 1822 */             op.execute(this, byteValue); break;
/*      */           } 
/* 1824 */           op.execute(this, (Long)value);
/*      */           break;
/*      */         
/*      */         case null:
/* 1828 */           op.execute(this, (BigInteger)value);
/*      */           break;
/*      */         
/*      */         case null:
/* 1832 */           if (null != this.cryptoMeta) {
/* 1833 */             if (Double.isInfinite(((Double)value).doubleValue())) {
/*      */               
/* 1835 */               MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_valueOutOfRange"));
/* 1836 */               throw new SQLServerException(form.format(new Object[] { jdbcType }, ), null, 0, null);
/*      */             } 
/*      */             
/* 1839 */             byteValue = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putDouble(((Double)value).doubleValue()).array();
/* 1840 */             op.execute(this, byteValue); break;
/*      */           } 
/* 1842 */           op.execute(this, (Double)value);
/*      */           break;
/*      */         
/*      */         case null:
/* 1846 */           if (null != this.cryptoMeta) {
/*      */             
/* 1848 */             byteValue = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(((Short)value).shortValue()).array();
/* 1849 */             op.execute(this, byteValue); break;
/*      */           } 
/* 1851 */           op.execute(this, (Short)value);
/*      */           break;
/*      */         
/*      */         case null:
/* 1855 */           if (null != this.cryptoMeta) {
/*      */             
/* 1857 */             byteValue = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(((Boolean)value).booleanValue() ? 1L : 0L).array();
/* 1858 */             op.execute(this, byteValue); break;
/*      */           } 
/* 1860 */           op.execute(this, (Boolean)value);
/*      */           break;
/*      */         
/*      */         case null:
/* 1864 */           op.execute(this, (Blob)value);
/*      */           break;
/*      */         
/*      */         case null:
/*      */         case null:
/* 1869 */           op.execute(this, (Clob)value);
/*      */           break;
/*      */         
/*      */         case null:
/* 1873 */           op.execute(this, (InputStream)value);
/*      */           break;
/*      */         
/*      */         case null:
/* 1877 */           op.execute(this, (Reader)value);
/*      */           break;
/*      */         
/*      */         case null:
/* 1881 */           op.execute(this, (SQLServerSQLXML)value);
/*      */           break;
/*      */         
/*      */         default:
/* 1885 */           assert false : "Unexpected JavaType: " + javaType;
/* 1886 */           unsupportedConversion = true;
/*      */           break;
/*      */       } 
/*      */     
/*      */     } 
/* 1891 */     if (unsupportedConversion) {
/* 1892 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_unsupportedConversionFromTo"));
/* 1893 */       Object[] msgArgs = { javaType, jdbcType };
/* 1894 */       throw new SQLServerException(form.format(msgArgs), SQLState.DATA_EXCEPTION_NOT_SPECIFIC, DriverError.NOT_SET, null);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   void sendCryptoMetaData(CryptoMetadata cryptoMeta, TDSWriter tdsWriter) {
/* 1900 */     this.cryptoMeta = cryptoMeta;
/* 1901 */     tdsWriter.setCryptoMetaData(cryptoMeta);
/*      */   }
/*      */   
/*      */   void setJdbcTypeSetByUser(JDBCType jdbcTypeSetByUser, int valueLength) {
/* 1905 */     this.jdbcTypeSetByUser = jdbcTypeSetByUser;
/* 1906 */     this.valueLength = valueLength;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void sendByRPC(String name, TypeInfo typeInfo, SQLCollation collation, int precision, int outScale, boolean isOutParam, TDSWriter tdsWriter, SQLServerConnection conn) throws SQLServerException {
/* 1915 */     executeOp(new SendByRPCOp(name, typeInfo, collation, precision, outScale, isOutParam, tdsWriter, conn));
/*      */   }
/*      */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\DTV.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */