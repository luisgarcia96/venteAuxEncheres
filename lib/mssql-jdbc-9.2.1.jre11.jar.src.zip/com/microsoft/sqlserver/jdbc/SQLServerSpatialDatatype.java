/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import com.microsoft.sqlserver.jdbc.spatialdatatypes.Figure;
/*      */ import com.microsoft.sqlserver.jdbc.spatialdatatypes.Point;
/*      */ import com.microsoft.sqlserver.jdbc.spatialdatatypes.Segment;
/*      */ import com.microsoft.sqlserver.jdbc.spatialdatatypes.Shape;
/*      */ import java.math.BigDecimal;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.ByteOrder;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ abstract class SQLServerSpatialDatatype
/*      */ {
/*      */   protected ByteBuffer buffer;
/*      */   protected InternalSpatialDatatype internalType;
/*      */   protected String wkt;
/*      */   protected String wktNoZM;
/*      */   protected byte[] clr;
/*      */   protected byte[] clrNoZM;
/*      */   protected int srid;
/*   40 */   protected byte version = 1;
/*      */   protected int numberOfPoints;
/*      */   protected int numberOfFigures;
/*      */   protected int numberOfShapes;
/*      */   protected int numberOfSegments;
/*      */   protected StringBuffer WKTsb;
/*      */   protected StringBuffer WKTsbNoZM;
/*   47 */   protected int currentPointIndex = 0;
/*   48 */   protected int currentFigureIndex = 0;
/*   49 */   protected int currentSegmentIndex = 0;
/*   50 */   protected int currentShapeIndex = 0;
/*   51 */   protected int currentWKBPointIndex = 0;
/*   52 */   protected int currentWKBFigureIndex = 0;
/*   53 */   protected int currentWKBSegmentIndex = 0;
/*   54 */   protected int currentWKBShapeIndex = 0;
/*      */   protected double[] xValues;
/*      */   protected double[] yValues;
/*      */   protected double[] zValues;
/*      */   protected double[] mValues;
/*   59 */   protected Figure[] figures = new Figure[0];
/*   60 */   protected Shape[] shapes = new Shape[0];
/*   61 */   protected Segment[] segments = new Segment[0];
/*      */   
/*      */   protected byte[] wkb;
/*      */   
/*   65 */   protected byte endian = 1;
/*      */ 
/*      */   
/*      */   protected int wkbType;
/*      */   
/*   70 */   private final int WKB_POINT_SIZE = 16;
/*   71 */   private final int BYTE_ORDER_SIZE = 1;
/*   72 */   private final int INTERNAL_TYPE_SIZE = 4;
/*   73 */   private final int NUMBER_OF_SHAPES_SIZE = 4;
/*   74 */   private final int LINEAR_RING_HEADER_SIZE = 4;
/*   75 */   private final int WKB_POINT_HEADER_SIZE = 5;
/*   76 */   private final int WKB_HEADER_SIZE = 9;
/*   77 */   private final int WKB_FULLGLOBE_CODE = 126;
/*      */   
/*      */   protected boolean hasZvalues = false;
/*      */   
/*      */   protected boolean hasMvalues = false;
/*      */   
/*      */   protected boolean isValid = true;
/*      */   protected boolean isSinglePoint = false;
/*      */   protected boolean isSingleLineSegment = false;
/*      */   protected boolean isLargerThanHemisphere = false;
/*      */   protected boolean isNull = true;
/*   88 */   protected final byte FA_INTERIOR_RING = 0;
/*   89 */   protected final byte FA_STROKE = 1;
/*   90 */   protected final byte FA_EXTERIOR_RING = 2;
/*      */   
/*   92 */   protected final byte FA_POINT = 0;
/*   93 */   protected final byte FA_LINE = 1;
/*   94 */   protected final byte FA_ARC = 2;
/*   95 */   protected final byte FA_COMPOSITE_CURVE = 3;
/*      */ 
/*      */   
/*   98 */   protected int currentWktPos = 0;
/*   99 */   protected List<Point> pointList = new ArrayList<>();
/*  100 */   protected List<Figure> figureList = new ArrayList<>();
/*  101 */   protected List<Shape> shapeList = new ArrayList<>();
/*  102 */   protected List<Segment> segmentList = new ArrayList<>();
/*  103 */   protected byte serializationProperties = 0;
/*      */   
/*  105 */   private final byte SEGMENT_LINE = 0;
/*  106 */   private final byte SEGMENT_ARC = 1;
/*  107 */   private final byte SEGMENT_FIRST_LINE = 2;
/*  108 */   private final byte SEGMENT_FIRST_ARC = 3;
/*      */   
/*  110 */   private final byte hasZvaluesMask = 1;
/*  111 */   private final byte hasMvaluesMask = 2;
/*  112 */   private final byte isValidMask = 4;
/*  113 */   private final byte isSinglePointMask = 8;
/*  114 */   private final byte isSingleLineSegmentMask = 16;
/*  115 */   private final byte isLargerThanHemisphereMask = 32;
/*      */   
/*  117 */   private List<Integer> version_one_shape_indexes = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void serializeToClr(boolean excludeZMFromCLR, SQLServerSpatialDatatype type) {
/*  128 */     ByteBuffer buf = ByteBuffer.allocate(determineClrCapacity(excludeZMFromCLR));
/*  129 */     createSerializationProperties();
/*      */     
/*  131 */     buf.order(ByteOrder.LITTLE_ENDIAN);
/*  132 */     buf.putInt(this.srid);
/*  133 */     buf.put(this.version);
/*  134 */     if (excludeZMFromCLR) {
/*  135 */       byte serializationPropertiesNoZM = this.serializationProperties;
/*  136 */       if (this.hasZvalues) {
/*  137 */         serializationPropertiesNoZM = (byte)(serializationPropertiesNoZM - 1);
/*      */       }
/*      */       
/*  140 */       if (this.hasMvalues) {
/*  141 */         serializationPropertiesNoZM = (byte)(serializationPropertiesNoZM - 2);
/*      */       }
/*  143 */       buf.put(serializationPropertiesNoZM);
/*      */     } else {
/*  145 */       buf.put(this.serializationProperties);
/*      */     } 
/*      */     
/*  148 */     if (!this.isSinglePoint && !this.isSingleLineSegment) {
/*  149 */       buf.putInt(this.numberOfPoints);
/*      */     }
/*      */     
/*  152 */     if (type instanceof Geometry) {
/*  153 */       for (int j = 0; j < this.numberOfPoints; j++) {
/*  154 */         buf.putDouble(this.xValues[j]);
/*  155 */         buf.putDouble(this.yValues[j]);
/*      */       } 
/*      */     } else {
/*  158 */       for (int j = 0; j < this.numberOfPoints; j++) {
/*  159 */         buf.putDouble(this.yValues[j]);
/*  160 */         buf.putDouble(this.xValues[j]);
/*      */       } 
/*      */     } 
/*      */     
/*  164 */     if (!excludeZMFromCLR) {
/*  165 */       if (this.hasZvalues) {
/*  166 */         for (int j = 0; j < this.numberOfPoints; j++) {
/*  167 */           buf.putDouble(this.zValues[j]);
/*      */         }
/*      */       }
/*      */       
/*  171 */       if (this.hasMvalues) {
/*  172 */         for (int j = 0; j < this.numberOfPoints; j++) {
/*  173 */           buf.putDouble(this.mValues[j]);
/*      */         }
/*      */       }
/*      */     } 
/*      */     
/*  178 */     if (this.isSinglePoint || this.isSingleLineSegment) {
/*  179 */       if (excludeZMFromCLR) {
/*  180 */         this.clrNoZM = buf.array();
/*      */       } else {
/*  182 */         this.clr = buf.array();
/*      */       } 
/*      */       
/*      */       return;
/*      */     } 
/*  187 */     buf.putInt(this.numberOfFigures); int i;
/*  188 */     for (i = 0; i < this.numberOfFigures; i++) {
/*  189 */       buf.put(this.figures[i].getFiguresAttribute());
/*  190 */       buf.putInt(this.figures[i].getPointOffset());
/*      */     } 
/*      */     
/*  193 */     buf.putInt(this.numberOfShapes);
/*  194 */     for (i = 0; i < this.numberOfShapes; i++) {
/*  195 */       buf.putInt(this.shapes[i].getParentOffset());
/*  196 */       buf.putInt(this.shapes[i].getFigureOffset());
/*  197 */       buf.put(this.shapes[i].getOpenGISType());
/*      */     } 
/*      */     
/*  200 */     if (this.version == 2 && null != this.segments) {
/*  201 */       buf.putInt(this.numberOfSegments);
/*  202 */       for (i = 0; i < this.numberOfSegments; i++) {
/*  203 */         buf.put(this.segments[i].getSegmentType());
/*      */       }
/*      */     } 
/*      */     
/*  207 */     if (excludeZMFromCLR) {
/*  208 */       this.clrNoZM = buf.array();
/*      */     } else {
/*  210 */       this.clr = buf.array();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void serializeToWkb(SQLServerSpatialDatatype type) {
/*  221 */     ByteBuffer buf = ByteBuffer.allocate(determineWkbCapacity());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  238 */     buf.order(ByteOrder.LITTLE_ENDIAN);
/*  239 */     switch (this.internalType) {
/*      */       case POINT:
/*  241 */         addPointToBuffer(buf, this.numberOfPoints);
/*      */         break;
/*      */       case LINESTRING:
/*  244 */         addLineStringToBuffer(buf, this.numberOfPoints);
/*      */         break;
/*      */       case POLYGON:
/*  247 */         addPolygonToBuffer(buf, this.numberOfFigures);
/*      */         break;
/*      */       case MULTIPOINT:
/*  250 */         addMultiPointToBuffer(buf, this.numberOfFigures);
/*      */         break;
/*      */       case MULTILINESTRING:
/*  253 */         addMultiLineStringToBuffer(buf, this.numberOfFigures);
/*      */         break;
/*      */       case MULTIPOLYGON:
/*  256 */         addMultiPolygonToBuffer(buf, this.numberOfShapes - 1);
/*      */         break;
/*      */       case GEOMETRYCOLLECTION:
/*  259 */         addGeometryCollectionToBuffer(buf, calculateNumShapesInThisGeometryCollection());
/*      */         break;
/*      */       case CIRCULARSTRING:
/*  262 */         addCircularStringToBuffer(buf, this.numberOfPoints);
/*      */         break;
/*      */       case COMPOUNDCURVE:
/*  265 */         addCompoundCurveToBuffer(buf, calculateNumCurvesInThisFigure());
/*      */         break;
/*      */       case CURVEPOLYGON:
/*  268 */         addCurvePolygonToBuffer(buf, this.numberOfFigures);
/*      */         break;
/*      */       case FULLGLOBE:
/*  271 */         addFullGlobeToBuffer(buf);
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  278 */     this.wkb = buf.array();
/*      */   }
/*      */   
/*      */   private void addPointToBuffer(ByteBuffer buf, int numberOfPoints) {
/*  282 */     buf.put(this.endian);
/*      */     
/*  284 */     if (numberOfPoints == 0) {
/*  285 */       buf.putInt(InternalSpatialDatatype.MULTIPOINT.getTypeCode());
/*  286 */       buf.putInt(numberOfPoints);
/*      */     } else {
/*  288 */       buf.putInt(InternalSpatialDatatype.POINT.getTypeCode());
/*  289 */       addCoordinateToBuffer(buf, numberOfPoints);
/*  290 */       this.currentWKBFigureIndex++;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void addLineStringToBuffer(ByteBuffer buf, int numberOfPoints) {
/*  295 */     buf.put(this.endian);
/*  296 */     buf.putInt(InternalSpatialDatatype.LINESTRING.getTypeCode());
/*  297 */     buf.putInt(numberOfPoints);
/*  298 */     addCoordinateToBuffer(buf, numberOfPoints);
/*  299 */     if (numberOfPoints > 0) {
/*  300 */       this.currentWKBFigureIndex++;
/*      */     }
/*      */   }
/*      */   
/*      */   private void addPolygonToBuffer(ByteBuffer buf, int numberOfFigures) {
/*  305 */     buf.put(this.endian);
/*  306 */     buf.putInt(InternalSpatialDatatype.POLYGON.getTypeCode());
/*  307 */     buf.putInt(numberOfFigures);
/*  308 */     addStructureToBuffer(buf, numberOfFigures, InternalSpatialDatatype.POLYGON);
/*      */   }
/*      */   
/*      */   private void addMultiPointToBuffer(ByteBuffer buf, int numberOfFigures) {
/*  312 */     buf.put(this.endian);
/*  313 */     buf.putInt(InternalSpatialDatatype.MULTIPOINT.getTypeCode());
/*  314 */     buf.putInt(numberOfFigures);
/*  315 */     addStructureToBuffer(buf, numberOfFigures, InternalSpatialDatatype.MULTIPOINT);
/*      */   }
/*      */   
/*      */   private void addMultiLineStringToBuffer(ByteBuffer buf, int numberOfFigures) {
/*  319 */     buf.put(this.endian);
/*  320 */     buf.putInt(InternalSpatialDatatype.MULTILINESTRING.getTypeCode());
/*  321 */     buf.putInt(numberOfFigures);
/*  322 */     addStructureToBuffer(buf, numberOfFigures, InternalSpatialDatatype.MULTILINESTRING);
/*      */   }
/*      */   
/*      */   private void addMultiPolygonToBuffer(ByteBuffer buf, int numberOfShapes) {
/*  326 */     buf.put(this.endian);
/*  327 */     buf.putInt(InternalSpatialDatatype.MULTIPOLYGON.getTypeCode());
/*  328 */     buf.putInt(numberOfShapes);
/*      */     
/*  330 */     this.currentWKBShapeIndex++;
/*  331 */     addStructureToBuffer(buf, numberOfShapes, InternalSpatialDatatype.MULTIPOLYGON);
/*      */   }
/*      */   
/*      */   private void addCircularStringToBuffer(ByteBuffer buf, int numberOfPoints) {
/*  335 */     buf.put(this.endian);
/*  336 */     buf.putInt(InternalSpatialDatatype.CIRCULARSTRING.getTypeCode());
/*  337 */     buf.putInt(numberOfPoints);
/*  338 */     addCoordinateToBuffer(buf, numberOfPoints);
/*  339 */     if (numberOfPoints > 0) {
/*  340 */       this.currentWKBFigureIndex++;
/*      */     }
/*      */   }
/*      */   
/*      */   private void addCompoundCurveToBuffer(ByteBuffer buf, int numberOfCurves) {
/*  345 */     buf.put(this.endian);
/*  346 */     buf.putInt(InternalSpatialDatatype.COMPOUNDCURVE.getTypeCode());
/*  347 */     buf.putInt(numberOfCurves);
/*  348 */     addStructureToBuffer(buf, numberOfCurves, InternalSpatialDatatype.COMPOUNDCURVE);
/*  349 */     if (numberOfCurves > 0) {
/*  350 */       this.currentWKBFigureIndex++;
/*      */     }
/*      */   }
/*      */   
/*      */   private void addCurvePolygonToBuffer(ByteBuffer buf, int numberOfFigures) {
/*  355 */     buf.put(this.endian);
/*  356 */     buf.putInt(InternalSpatialDatatype.CURVEPOLYGON.getTypeCode());
/*  357 */     buf.putInt(numberOfFigures);
/*  358 */     for (int i = 0; i < numberOfFigures; i++) {
/*  359 */       int numCurvesInThisFigure; switch (this.figures[this.currentWKBFigureIndex].getFiguresAttribute()) {
/*      */         case 1:
/*  361 */           addStructureToBuffer(buf, 1, InternalSpatialDatatype.LINESTRING);
/*      */           break;
/*      */         case 2:
/*  364 */           addStructureToBuffer(buf, 1, InternalSpatialDatatype.CIRCULARSTRING);
/*      */           break;
/*      */         case 3:
/*  367 */           numCurvesInThisFigure = calculateNumCurvesInThisFigure();
/*  368 */           buf.put(this.endian);
/*  369 */           buf.putInt(InternalSpatialDatatype.COMPOUNDCURVE.getTypeCode());
/*  370 */           buf.putInt(numCurvesInThisFigure);
/*  371 */           addStructureToBuffer(buf, numCurvesInThisFigure, InternalSpatialDatatype.COMPOUNDCURVE);
/*  372 */           this.currentWKBFigureIndex++;
/*      */           break;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void addGeometryCollectionToBuffer(ByteBuffer buf, int numberOfRemainingGeometries) {
/*  382 */     buf.put(this.endian);
/*  383 */     buf.putInt(this.internalType.getTypeCode());
/*  384 */     buf.putInt(numberOfRemainingGeometries);
/*      */     
/*  386 */     this.currentWKBShapeIndex++;
/*  387 */     while (numberOfRemainingGeometries > 0) {
/*  388 */       switch (InternalSpatialDatatype.valueOf(this.shapes[this.currentWKBShapeIndex].getOpenGISType())) {
/*      */         case POINT:
/*  390 */           if (this.shapes[this.currentWKBShapeIndex].getFigureOffset() == -1) {
/*  391 */             addPointToBuffer(buf, 0);
/*      */           } else {
/*  393 */             addPointToBuffer(buf, calculateNumPointsInThisFigure());
/*      */           } 
/*  395 */           this.currentWKBShapeIndex++;
/*      */           break;
/*      */         case LINESTRING:
/*  398 */           if (this.shapes[this.currentWKBShapeIndex].getFigureOffset() == -1) {
/*  399 */             addLineStringToBuffer(buf, 0);
/*      */           } else {
/*  401 */             addLineStringToBuffer(buf, calculateNumPointsInThisFigure());
/*      */           } 
/*  403 */           this.currentWKBShapeIndex++;
/*      */           break;
/*      */         case POLYGON:
/*  406 */           if (this.shapes[this.currentWKBShapeIndex].getFigureOffset() == -1) {
/*  407 */             addPolygonToBuffer(buf, 0);
/*      */           } else {
/*  409 */             addPolygonToBuffer(buf, calculateNumFiguresInThisShape(false));
/*      */           } 
/*  411 */           this.currentWKBShapeIndex++;
/*      */           break;
/*      */         case MULTIPOINT:
/*  414 */           if (this.shapes[this.currentWKBShapeIndex].getFigureOffset() == -1) {
/*  415 */             addMultiPointToBuffer(buf, 0);
/*      */           } else {
/*  417 */             addMultiPointToBuffer(buf, calculateNumFiguresInThisShape(true));
/*      */           } 
/*  419 */           this.currentWKBShapeIndex++;
/*      */           break;
/*      */         case MULTILINESTRING:
/*  422 */           if (this.shapes[this.currentWKBShapeIndex].getFigureOffset() == -1) {
/*  423 */             addMultiLineStringToBuffer(buf, 0);
/*      */           } else {
/*  425 */             addMultiLineStringToBuffer(buf, calculateNumFiguresInThisShape(true));
/*      */           } 
/*  427 */           this.currentWKBShapeIndex++;
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case MULTIPOLYGON:
/*  434 */           if (this.shapes[this.currentWKBShapeIndex].getFigureOffset() == -1) {
/*  435 */             addMultiPolygonToBuffer(buf, 0); break;
/*      */           } 
/*  437 */           addMultiPolygonToBuffer(buf, calculateNumShapesInThisMultiPolygon());
/*      */           break;
/*      */         
/*      */         case GEOMETRYCOLLECTION:
/*  441 */           if (this.shapes[this.currentWKBShapeIndex].getFigureOffset() == -1) {
/*  442 */             addGeometryCollectionToBuffer(buf, 0); break;
/*      */           } 
/*  444 */           addGeometryCollectionToBuffer(buf, calculateNumShapesInThisGeometryCollection());
/*      */           break;
/*      */         
/*      */         case CIRCULARSTRING:
/*  448 */           if (this.shapes[this.currentWKBShapeIndex].getFigureOffset() == -1) {
/*  449 */             addCircularStringToBuffer(buf, 0);
/*      */           } else {
/*  451 */             addCircularStringToBuffer(buf, calculateNumPointsInThisFigure());
/*      */           } 
/*  453 */           this.currentWKBShapeIndex++;
/*      */           break;
/*      */         case COMPOUNDCURVE:
/*  456 */           if (this.shapes[this.currentWKBShapeIndex].getFigureOffset() == -1) {
/*  457 */             addCompoundCurveToBuffer(buf, 0);
/*      */           } else {
/*  459 */             addCompoundCurveToBuffer(buf, calculateNumCurvesInThisFigure());
/*      */           } 
/*  461 */           this.currentWKBShapeIndex++;
/*      */           break;
/*      */         case CURVEPOLYGON:
/*  464 */           if (this.shapes[this.currentWKBShapeIndex].getFigureOffset() == -1) {
/*  465 */             addCurvePolygonToBuffer(buf, 0);
/*      */           } else {
/*  467 */             addCurvePolygonToBuffer(buf, calculateNumFiguresInThisShape(false));
/*      */           } 
/*  469 */           this.currentWKBShapeIndex++;
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  475 */       numberOfRemainingGeometries--;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void addFullGlobeToBuffer(ByteBuffer buf) {
/*  480 */     buf.put(this.endian);
/*  481 */     buf.putInt(126);
/*      */   }
/*      */   
/*      */   private void addCoordinateToBuffer(ByteBuffer buf, int numPoint) {
/*  485 */     while (numPoint > 0) {
/*  486 */       buf.putDouble(this.xValues[this.currentWKBPointIndex]);
/*  487 */       buf.putDouble(this.yValues[this.currentWKBPointIndex]);
/*  488 */       this.currentWKBPointIndex++;
/*  489 */       numPoint--;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void addStructureToBuffer(ByteBuffer buf, int remainingStructureCount, InternalSpatialDatatype internalParentType) {
/*  495 */     int originalRemainingStructureCount = remainingStructureCount;
/*  496 */     while (remainingStructureCount > 0) {
/*  497 */       int numFiguresInThisShape, numPointsInThisFigure = calculateNumPointsInThisFigure();
/*  498 */       switch (internalParentType) {
/*      */         case LINESTRING:
/*  500 */           buf.put(this.endian);
/*  501 */           buf.putInt(InternalSpatialDatatype.LINESTRING.getTypeCode());
/*  502 */           buf.putInt(numPointsInThisFigure);
/*  503 */           addCoordinateToBuffer(buf, numPointsInThisFigure);
/*  504 */           this.currentWKBFigureIndex++;
/*      */           break;
/*      */         case POLYGON:
/*  507 */           buf.putInt(numPointsInThisFigure);
/*  508 */           addCoordinateToBuffer(buf, numPointsInThisFigure);
/*  509 */           this.currentWKBFigureIndex++;
/*      */           break;
/*      */         case MULTIPOINT:
/*  512 */           buf.put(this.endian);
/*  513 */           buf.putInt(InternalSpatialDatatype.POINT.getTypeCode());
/*  514 */           addCoordinateToBuffer(buf, 1);
/*  515 */           this.currentWKBFigureIndex++;
/*  516 */           this.currentWKBShapeIndex++;
/*      */           break;
/*      */         case MULTILINESTRING:
/*  519 */           buf.put(this.endian);
/*  520 */           buf.putInt(InternalSpatialDatatype.LINESTRING.getTypeCode());
/*  521 */           buf.putInt(numPointsInThisFigure);
/*  522 */           addCoordinateToBuffer(buf, numPointsInThisFigure);
/*  523 */           this.currentWKBFigureIndex++;
/*  524 */           this.currentWKBShapeIndex++;
/*      */           break;
/*      */         case MULTIPOLYGON:
/*  527 */           numFiguresInThisShape = calculateNumFiguresInThisShape(false);
/*  528 */           buf.put(this.endian);
/*  529 */           buf.putInt(InternalSpatialDatatype.POLYGON.getTypeCode());
/*  530 */           buf.putInt(numFiguresInThisShape);
/*  531 */           addStructureToBuffer(buf, numFiguresInThisShape, InternalSpatialDatatype.POLYGON);
/*  532 */           this.currentWKBShapeIndex++;
/*      */           break;
/*      */         case CIRCULARSTRING:
/*  535 */           buf.put(this.endian);
/*  536 */           buf.putInt(InternalSpatialDatatype.CIRCULARSTRING.getTypeCode());
/*  537 */           buf.putInt(numPointsInThisFigure);
/*  538 */           addCoordinateToBuffer(buf, numPointsInThisFigure);
/*  539 */           this.currentWKBFigureIndex++;
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case COMPOUNDCURVE:
/*  552 */           if (this.segments[this.currentWKBSegmentIndex].getSegmentType() == 3) {
/*  553 */             int numberOfPointsInStructure = 3;
/*  554 */             this.currentWKBSegmentIndex++;
/*  555 */             while (this.currentWKBSegmentIndex < this.segments.length && this.segments[this.currentWKBSegmentIndex]
/*  556 */               .getSegmentType() != 3 && this.segments[this.currentWKBSegmentIndex]
/*  557 */               .getSegmentType() != 2) {
/*  558 */               numberOfPointsInStructure += 2;
/*  559 */               this.currentWKBSegmentIndex++;
/*      */             } 
/*  561 */             buf.put(this.endian);
/*  562 */             buf.putInt(InternalSpatialDatatype.CIRCULARSTRING.getTypeCode());
/*  563 */             buf.putInt(numberOfPointsInStructure);
/*  564 */             if (originalRemainingStructureCount != remainingStructureCount) {
/*  565 */               this.currentWKBPointIndex--;
/*      */             }
/*  567 */             addCoordinateToBuffer(buf, numberOfPointsInStructure); break;
/*  568 */           }  if (this.segments[this.currentWKBSegmentIndex].getSegmentType() == 2) {
/*  569 */             int numberOfPointsInStructure = 2;
/*  570 */             this.currentWKBSegmentIndex++;
/*  571 */             while (this.currentWKBSegmentIndex < this.segments.length && this.segments[this.currentWKBSegmentIndex]
/*  572 */               .getSegmentType() != 3 && this.segments[this.currentWKBSegmentIndex]
/*  573 */               .getSegmentType() != 2) {
/*  574 */               numberOfPointsInStructure++;
/*  575 */               this.currentWKBSegmentIndex++;
/*      */             } 
/*  577 */             buf.put(this.endian);
/*  578 */             buf.putInt(InternalSpatialDatatype.LINESTRING.getTypeCode());
/*  579 */             buf.putInt(numberOfPointsInStructure);
/*  580 */             if (originalRemainingStructureCount != remainingStructureCount) {
/*  581 */               this.currentWKBPointIndex--;
/*      */             }
/*  583 */             addCoordinateToBuffer(buf, numberOfPointsInStructure);
/*      */           } 
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  593 */       remainingStructureCount--;
/*      */     } 
/*      */   }
/*      */   
/*      */   private int calculateNumPointsInThisFigure() {
/*  598 */     if (this.figures.length == 0) {
/*  599 */       return 0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  614 */     return (this.currentWKBFigureIndex == this.figures.length - 1) ? (
/*  615 */       this.numberOfPoints - this.figures[this.currentWKBFigureIndex]
/*  616 */       .getPointOffset()) : (
/*  617 */       this.figures[this.currentWKBFigureIndex + 1].getPointOffset() - this.figures[this.currentWKBFigureIndex]
/*  618 */       .getPointOffset());
/*      */   }
/*      */   
/*      */   private int calculateNumCurvesInThisFigure() {
/*  622 */     int numPointsInThisFigure = calculateNumPointsInThisFigure();
/*  623 */     int numCurvesInThisFigure = 0;
/*  624 */     int tempCurrentWKBSegmentIndex = this.currentWKBSegmentIndex;
/*  625 */     boolean isFirstSegment = true;
/*  626 */     while (numPointsInThisFigure > 0) {
/*  627 */       switch (this.segments[tempCurrentWKBSegmentIndex].getSegmentType()) {
/*      */         case 0:
/*  629 */           numPointsInThisFigure--;
/*      */           break;
/*      */         case 1:
/*  632 */           numPointsInThisFigure -= 2;
/*      */           break;
/*      */         case 2:
/*  635 */           if (isFirstSegment) {
/*  636 */             numPointsInThisFigure -= 2;
/*      */           } else {
/*  638 */             numPointsInThisFigure--;
/*      */           } 
/*  640 */           numCurvesInThisFigure++;
/*      */           break;
/*      */         case 3:
/*  643 */           if (isFirstSegment) {
/*  644 */             numPointsInThisFigure -= 3;
/*      */           } else {
/*  646 */             numPointsInThisFigure -= 2;
/*      */           } 
/*  648 */           numCurvesInThisFigure++;
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  654 */       isFirstSegment = false;
/*  655 */       tempCurrentWKBSegmentIndex++;
/*      */     } 
/*  657 */     return numCurvesInThisFigure;
/*      */   }
/*      */   
/*      */   private int calculateNumFiguresInThisShape(boolean containsInnerStructures) {
/*  661 */     if (this.shapes.length == 0) {
/*  662 */       return 0;
/*      */     }
/*      */     
/*  665 */     if (containsInnerStructures) {
/*  666 */       int nextNonInnerShapeIndex = this.currentWKBShapeIndex + 1;
/*  667 */       while (nextNonInnerShapeIndex < this.shapes.length && this.shapes[nextNonInnerShapeIndex]
/*  668 */         .getParentOffset() == this.currentWKBShapeIndex) {
/*  669 */         nextNonInnerShapeIndex++;
/*      */       }
/*      */       
/*  672 */       if (nextNonInnerShapeIndex == this.shapes.length) {
/*  673 */         return this.numberOfFigures - this.shapes[this.currentWKBShapeIndex].getFigureOffset();
/*      */       }
/*  675 */       int i = -1;
/*  676 */       int j = nextNonInnerShapeIndex;
/*  677 */       while (i == -1 && j < this.shapes.length - 1) {
/*  678 */         i = this.shapes[j + 1].getFigureOffset();
/*  679 */         j++;
/*      */       } 
/*      */       
/*  682 */       if (i == -1) {
/*  683 */         i = this.numberOfFigures;
/*      */       }
/*      */       
/*  686 */       return i - this.shapes[this.currentWKBShapeIndex].getFigureOffset();
/*      */     } 
/*      */     
/*  689 */     if (this.currentWKBShapeIndex == this.shapes.length - 1) {
/*  690 */       return this.numberOfFigures - this.shapes[this.currentWKBShapeIndex].getFigureOffset();
/*      */     }
/*  692 */     int figureIndexEnd = -1;
/*  693 */     int localCurrentShapeIndex = this.currentWKBShapeIndex;
/*  694 */     while (figureIndexEnd == -1 && localCurrentShapeIndex < this.shapes.length - 1) {
/*  695 */       figureIndexEnd = this.shapes[localCurrentShapeIndex + 1].getFigureOffset();
/*  696 */       localCurrentShapeIndex++;
/*      */     } 
/*      */     
/*  699 */     if (figureIndexEnd == -1) {
/*  700 */       figureIndexEnd = this.numberOfFigures;
/*      */     }
/*      */     
/*  703 */     return figureIndexEnd - this.shapes[this.currentWKBShapeIndex].getFigureOffset();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private int calculateNumShapesInThisMultiPolygon() {
/*  709 */     if (this.shapes.length == 0) {
/*  710 */       return 0;
/*      */     }
/*      */     
/*  713 */     int nextNonInnerShapeIndex = this.currentWKBShapeIndex + 1;
/*  714 */     while (nextNonInnerShapeIndex < this.shapes.length && this.shapes[nextNonInnerShapeIndex]
/*  715 */       .getParentOffset() == this.currentWKBShapeIndex) {
/*  716 */       nextNonInnerShapeIndex++;
/*      */     }
/*      */     
/*  719 */     return nextNonInnerShapeIndex - this.currentWKBShapeIndex - 1;
/*      */   }
/*      */   
/*      */   private int calculateNumShapesInThisGeometryCollection() {
/*  723 */     int numberOfGeometries = 0;
/*  724 */     for (int i = 0; i < this.shapes.length; i++) {
/*  725 */       if (this.shapes[i].getParentOffset() == this.currentWKBShapeIndex) {
/*  726 */         numberOfGeometries++;
/*      */       }
/*      */     } 
/*  729 */     return numberOfGeometries;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void parseClr(SQLServerSpatialDatatype type) throws SQLServerException {
/*  742 */     this.srid = readInt();
/*  743 */     this.version = readByte();
/*  744 */     this.serializationProperties = readByte();
/*      */     
/*  746 */     interpretSerializationPropBytes();
/*  747 */     readNumberOfPoints();
/*  748 */     readPoints(type);
/*      */     
/*  750 */     if (this.hasZvalues) {
/*  751 */       readZvalues();
/*      */     }
/*      */     
/*  754 */     if (this.hasMvalues) {
/*  755 */       readMvalues();
/*      */     }
/*      */     
/*  758 */     if (!this.isSinglePoint && !this.isSingleLineSegment) {
/*  759 */       readNumberOfFigures();
/*  760 */       readFigures();
/*  761 */       readNumberOfShapes();
/*  762 */       readShapes();
/*      */     } 
/*      */     
/*  765 */     determineInternalType();
/*      */     
/*  767 */     if (this.buffer.hasRemaining() && 
/*  768 */       this.version == 2 && this.internalType.getTypeCode() != 8 && this.internalType.getTypeCode() != 11) {
/*  769 */       readNumberOfSegments();
/*  770 */       readSegments();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void constructWKT(SQLServerSpatialDatatype sd, InternalSpatialDatatype isd, int pointIndexEnd, int figureIndexEnd, int segmentIndexEnd, int shapeIndexEnd) throws SQLServerException {
/*  795 */     if (this.numberOfPoints == 0) {
/*  796 */       if (isd.getTypeCode() == 11) {
/*  797 */         if (sd instanceof Geometry) {
/*  798 */           MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_illegalTypeForGeometry"));
/*  799 */           throw new SQLServerException(form.format(new Object[] { "Fullglobe" }, ), null, 0, null);
/*      */         } 
/*  801 */         appendToWKTBuffers("FULLGLOBE");
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/*  806 */       if (isd.getTypeCode() == 7 && this.currentShapeIndex != shapeIndexEnd - 1) {
/*  807 */         this.currentShapeIndex++;
/*  808 */         appendToWKTBuffers(isd.getTypeName() + "(");
/*  809 */         constructWKT(this, InternalSpatialDatatype.valueOf(this.shapes[this.currentShapeIndex].getOpenGISType()), this.numberOfPoints, this.numberOfFigures, this.numberOfSegments, this.numberOfShapes);
/*      */         
/*  811 */         appendToWKTBuffers(")");
/*      */         return;
/*      */       } 
/*  814 */       appendToWKTBuffers(isd.getTypeName() + " EMPTY"); return;
/*      */     } 
/*  816 */     if (figureIndexEnd == -1) {
/*      */       
/*  818 */       appendToWKTBuffers(isd.getTypeName() + " EMPTY");
/*      */       
/*      */       return;
/*      */     } 
/*  822 */     appendToWKTBuffers(isd.getTypeName());
/*  823 */     appendToWKTBuffers("(");
/*      */     
/*  825 */     switch (isd) {
/*      */       case POINT:
/*  827 */         constructPointWKT(this.currentPointIndex);
/*      */         break;
/*      */       case LINESTRING:
/*      */       case CIRCULARSTRING:
/*  831 */         constructLineWKT(this.currentPointIndex, pointIndexEnd);
/*      */         break;
/*      */       case POLYGON:
/*  834 */         constructShapeWKT(this.currentFigureIndex, figureIndexEnd);
/*      */         break;
/*      */       case MULTIPOINT:
/*      */       case MULTILINESTRING:
/*  838 */         constructMultiShapeWKT(this.currentShapeIndex, shapeIndexEnd);
/*      */         break;
/*      */       case COMPOUNDCURVE:
/*  841 */         constructCompoundcurveWKT(this.currentSegmentIndex, segmentIndexEnd, pointIndexEnd);
/*      */         break;
/*      */       case MULTIPOLYGON:
/*  844 */         constructMultipolygonWKT(this.currentShapeIndex, shapeIndexEnd);
/*      */         break;
/*      */       case GEOMETRYCOLLECTION:
/*  847 */         constructGeometryCollectionWKT(shapeIndexEnd);
/*      */         break;
/*      */       case CURVEPOLYGON:
/*  850 */         constructCurvepolygonWKT(this.currentFigureIndex, figureIndexEnd, this.currentSegmentIndex, segmentIndexEnd);
/*      */         break;
/*      */       default:
/*  853 */         throwIllegalWKTPosition();
/*      */         break;
/*      */     } 
/*  856 */     appendToWKTBuffers(")");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void parseWKTForSerialization(SQLServerSpatialDatatype sd, int startPos, int parentShapeIndex, boolean isGeoCollection) throws SQLServerException {
/*  880 */     while (hasMoreToken()) {
/*  881 */       int thisShapeIndex; if (startPos != 0) {
/*  882 */         if (this.wkt.charAt(this.currentWktPos) == ')')
/*      */           return; 
/*  884 */         if (this.wkt.charAt(this.currentWktPos) == ',') {
/*  885 */           this.currentWktPos++;
/*      */         }
/*      */       } 
/*      */       
/*  889 */       String nextToken = getNextStringToken().toUpperCase(Locale.US);
/*      */       
/*  891 */       InternalSpatialDatatype isd = InternalSpatialDatatype.INVALID_TYPE;
/*      */       try {
/*  893 */         isd = InternalSpatialDatatype.valueOf(nextToken);
/*  894 */       } catch (Exception e) {
/*  895 */         throwIllegalWKTPosition();
/*      */       } 
/*  897 */       byte fa = 0;
/*      */       
/*  899 */       if (this.version == 1 && ("CIRCULARSTRING".equals(nextToken) || "COMPOUNDCURVE".equals(nextToken) || "CURVEPOLYGON"
/*  900 */         .equals(nextToken))) {
/*  901 */         this.version = 2;
/*      */       }
/*      */ 
/*      */       
/*  905 */       if ("FULLGLOBE".equals(nextToken)) {
/*  906 */         if (sd instanceof Geometry) {
/*  907 */           MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_illegalTypeForGeometry"));
/*  908 */           throw new SQLServerException(form.format(new Object[] { "Fullglobe" }, ), null, 0, null);
/*      */         } 
/*      */         
/*  911 */         if (startPos != 0) {
/*  912 */           throwIllegalWKTPosition();
/*      */         }
/*      */         
/*  915 */         this.shapeList.add(new Shape(parentShapeIndex, -1, isd.getTypeCode()));
/*  916 */         this.isLargerThanHemisphere = true;
/*  917 */         this.version = 2;
/*      */         
/*      */         break;
/*      */       } 
/*      */       
/*  922 */       if (checkEmptyKeyword(parentShapeIndex, isd, false)) {
/*      */         continue;
/*      */       }
/*      */       
/*  926 */       readOpenBracket();
/*      */       
/*  928 */       switch (nextToken) {
/*      */         case "POINT":
/*  930 */           if (startPos == 0 && "POINT".equals(nextToken.toUpperCase())) {
/*  931 */             this.isSinglePoint = true;
/*  932 */             this.internalType = InternalSpatialDatatype.POINT;
/*      */           } 
/*      */           
/*  935 */           if (isGeoCollection) {
/*  936 */             this.shapeList.add(new Shape(parentShapeIndex, this.figureList.size(), isd.getTypeCode()));
/*  937 */             this.figureList.add(new Figure((byte)1, this.pointList.size()));
/*      */           } 
/*      */           
/*  940 */           readPointWkt();
/*      */           break;
/*      */         case "LINESTRING":
/*      */         case "CIRCULARSTRING":
/*  944 */           this.shapeList.add(new Shape(parentShapeIndex, this.figureList.size(), isd.getTypeCode()));
/*      */           
/*  946 */           fa = (isd.getTypeCode() == InternalSpatialDatatype.LINESTRING.getTypeCode()) ? 1 : 2;
/*  947 */           this.figureList.add(new Figure(fa, this.pointList.size()));
/*      */           
/*  949 */           readLineWkt();
/*      */           
/*  951 */           if (startPos == 0 && "LINESTRING".equals(nextToken.toUpperCase()) && this.pointList.size() == 2) {
/*  952 */             this.isSingleLineSegment = true;
/*      */           }
/*      */           break;
/*      */         case "POLYGON":
/*      */         case "MULTIPOINT":
/*      */         case "MULTILINESTRING":
/*  958 */           thisShapeIndex = this.shapeList.size();
/*  959 */           this.shapeList.add(new Shape(parentShapeIndex, this.figureList.size(), isd.getTypeCode()));
/*      */           
/*  961 */           readShapeWkt(thisShapeIndex, nextToken);
/*      */           break;
/*      */         
/*      */         case "MULTIPOLYGON":
/*  965 */           thisShapeIndex = this.shapeList.size();
/*  966 */           this.shapeList.add(new Shape(parentShapeIndex, this.figureList.size(), isd.getTypeCode()));
/*      */           
/*  968 */           readMultiPolygonWkt(thisShapeIndex, nextToken);
/*      */           break;
/*      */         
/*      */         case "COMPOUNDCURVE":
/*  972 */           this.shapeList.add(new Shape(parentShapeIndex, this.figureList.size(), isd.getTypeCode()));
/*  973 */           this.figureList.add(new Figure((byte)3, this.pointList.size()));
/*      */           
/*  975 */           readCompoundCurveWkt(true);
/*      */           break;
/*      */         
/*      */         case "CURVEPOLYGON":
/*  979 */           this.shapeList.add(new Shape(parentShapeIndex, this.figureList.size(), isd.getTypeCode()));
/*      */           
/*  981 */           readCurvePolygon();
/*      */           break;
/*      */         
/*      */         case "GEOMETRYCOLLECTION":
/*  985 */           thisShapeIndex = this.shapeList.size();
/*  986 */           this.shapeList.add(new Shape(parentShapeIndex, this.figureList.size(), isd.getTypeCode()));
/*      */           
/*  988 */           parseWKTForSerialization(this, this.currentWktPos, thisShapeIndex, true);
/*      */           break;
/*      */         
/*      */         default:
/*  992 */           throwIllegalWKTPosition(); break;
/*      */       } 
/*  994 */       readCloseBracket();
/*      */     } 
/*      */     
/*  997 */     populateStructures();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void constructPointWKT(int pointIndex) {
/* 1009 */     if (this.xValues[pointIndex] % 1.0D == 0.0D) {
/* 1010 */       appendToWKTBuffers(Integer.valueOf((int)this.xValues[pointIndex]));
/*      */     } else {
/* 1012 */       appendToWKTBuffers(Double.valueOf(this.xValues[pointIndex]));
/*      */     } 
/* 1014 */     appendToWKTBuffers(" ");
/*      */     
/* 1016 */     if (this.yValues[pointIndex] % 1.0D == 0.0D) {
/* 1017 */       appendToWKTBuffers(Integer.valueOf((int)this.yValues[pointIndex]));
/*      */     } else {
/* 1019 */       appendToWKTBuffers(Double.valueOf(this.yValues[pointIndex]));
/*      */     } 
/* 1021 */     appendToWKTBuffers(" ");
/*      */     
/* 1023 */     if (this.hasZvalues && !Double.isNaN(this.zValues[pointIndex])) {
/* 1024 */       if (this.zValues[pointIndex] % 1.0D == 0.0D) {
/* 1025 */         this.WKTsb.append((long)this.zValues[pointIndex]);
/*      */       } else {
/* 1027 */         this.WKTsb.append(this.zValues[pointIndex]);
/*      */       } 
/* 1029 */       this.WKTsb.append(" ");
/* 1030 */     } else if (this.hasMvalues && !Double.isNaN(this.mValues[pointIndex])) {
/*      */       
/* 1032 */       this.WKTsb.append("NULL ");
/*      */     } 
/*      */     
/* 1035 */     if (this.hasMvalues && !Double.isNaN(this.mValues[pointIndex])) {
/* 1036 */       if (this.mValues[pointIndex] % 1.0D == 0.0D) {
/* 1037 */         this.WKTsb.append((long)this.mValues[pointIndex]);
/*      */       } else {
/* 1039 */         this.WKTsb.append(this.mValues[pointIndex]);
/*      */       } 
/* 1041 */       this.WKTsb.append(" ");
/*      */     } 
/*      */     
/* 1044 */     this.currentPointIndex++;
/*      */     
/* 1046 */     this.WKTsb.setLength(this.WKTsb.length() - 1);
/* 1047 */     this.WKTsbNoZM.setLength(this.WKTsbNoZM.length() - 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void constructLineWKT(int pointStartIndex, int pointEndIndex) {
/* 1059 */     for (int i = pointStartIndex; i < pointEndIndex; i++) {
/* 1060 */       constructPointWKT(i);
/*      */ 
/*      */       
/* 1063 */       if (i != pointEndIndex - 1) {
/* 1064 */         appendToWKTBuffers(", ");
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void constructShapeWKT(int figureStartIndex, int figureEndIndex) {
/* 1078 */     for (int i = figureStartIndex; i < figureEndIndex; i++) {
/* 1079 */       appendToWKTBuffers("(");
/* 1080 */       if (i != this.numberOfFigures - 1) {
/* 1081 */         constructLineWKT(this.figures[i].getPointOffset(), this.figures[i + 1].getPointOffset());
/*      */       } else {
/* 1083 */         constructLineWKT(this.figures[i].getPointOffset(), this.numberOfPoints);
/*      */       } 
/*      */       
/* 1086 */       if (i != figureEndIndex - 1) {
/* 1087 */         appendToWKTBuffers("), ");
/*      */       } else {
/* 1089 */         appendToWKTBuffers(")");
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void constructMultiShapeWKT(int shapeStartIndex, int shapeEndIndex) {
/* 1103 */     for (int i = shapeStartIndex + 1; i < shapeEndIndex; i++) {
/* 1104 */       if (this.shapes[i].getFigureOffset() == -1) {
/* 1105 */         appendToWKTBuffers("EMPTY");
/*      */       } else {
/* 1107 */         constructShapeWKT(this.shapes[i].getFigureOffset(), this.shapes[i].getFigureOffset() + 1);
/*      */       } 
/* 1109 */       if (i != shapeEndIndex - 1) {
/* 1110 */         appendToWKTBuffers(", ");
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void constructCompoundcurveWKT(int segmentStartIndex, int segmentEndIndex, int pointEndIndex) {
/* 1126 */     for (int i = segmentStartIndex; i < segmentEndIndex; i++) {
/* 1127 */       byte segment = this.segments[i].getSegmentType();
/* 1128 */       constructSegmentWKT(i, segment, pointEndIndex);
/*      */       
/* 1130 */       if (i == segmentEndIndex - 1) {
/* 1131 */         appendToWKTBuffers(")");
/*      */         
/*      */         break;
/*      */       } 
/* 1135 */       switch (segment) {
/*      */         case 0:
/*      */         case 2:
/* 1138 */           if (this.segments[i + 1].getSegmentType() != 0) {
/* 1139 */             appendToWKTBuffers("), ");
/*      */           }
/*      */           break;
/*      */         case 1:
/*      */         case 3:
/* 1144 */           if (this.segments[i + 1].getSegmentType() != 1) {
/* 1145 */             appendToWKTBuffers("), ");
/*      */           }
/*      */           break;
/*      */         default:
/*      */           return;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void constructMultipolygonWKT(int shapeStartIndex, int shapeEndIndex) {
/* 1166 */     for (int i = shapeStartIndex + 1; i < shapeEndIndex; i++) {
/* 1167 */       int figureEndIndex = this.figures.length;
/* 1168 */       if (this.shapes[i].getFigureOffset() == -1) {
/* 1169 */         appendToWKTBuffers("EMPTY");
/* 1170 */         if (i != shapeEndIndex - 1) {
/* 1171 */           appendToWKTBuffers(", ");
/*      */         }
/*      */       } else {
/*      */         
/* 1175 */         int figureStartIndex = this.shapes[i].getFigureOffset();
/* 1176 */         if (i == this.shapes.length - 1) {
/* 1177 */           figureEndIndex = this.figures.length;
/*      */         } else {
/*      */           
/* 1180 */           int tempCurrentShapeIndex = i + 1;
/*      */ 
/*      */           
/* 1183 */           while (tempCurrentShapeIndex < this.shapes.length) {
/* 1184 */             if (this.shapes[tempCurrentShapeIndex].getFigureOffset() == -1) {
/* 1185 */               tempCurrentShapeIndex++;
/*      */               continue;
/*      */             } 
/* 1188 */             figureEndIndex = this.shapes[tempCurrentShapeIndex].getFigureOffset();
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1194 */         appendToWKTBuffers("(");
/*      */         
/* 1196 */         for (int j = figureStartIndex; j < figureEndIndex; j++) {
/* 1197 */           appendToWKTBuffers("(");
/*      */           
/* 1199 */           if (j == this.figures.length - 1) {
/* 1200 */             constructLineWKT(this.figures[j].getPointOffset(), this.numberOfPoints);
/*      */           } else {
/* 1202 */             constructLineWKT(this.figures[j].getPointOffset(), this.figures[j + 1].getPointOffset());
/*      */           } 
/*      */           
/* 1205 */           if (j == figureEndIndex - 1) {
/* 1206 */             appendToWKTBuffers(")");
/*      */           } else {
/* 1208 */             appendToWKTBuffers("), ");
/*      */           } 
/*      */         } 
/*      */         
/* 1212 */         appendToWKTBuffers(")");
/*      */         
/* 1214 */         if (i != shapeEndIndex - 1) {
/* 1215 */           appendToWKTBuffers(", ");
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void constructCurvepolygonWKT(int figureStartIndex, int figureEndIndex, int segmentStartIndex, int segmentEndIndex) {
/* 1234 */     for (int i = figureStartIndex; i < figureEndIndex; i++) {
/* 1235 */       int pointEndIndex; switch (this.figures[i].getFiguresAttribute()) {
/*      */         case 1:
/* 1237 */           appendToWKTBuffers("(");
/*      */           
/* 1239 */           if (i == this.figures.length - 1) {
/* 1240 */             constructLineWKT(this.currentPointIndex, this.numberOfPoints);
/*      */           } else {
/* 1242 */             constructLineWKT(this.currentPointIndex, this.figures[i + 1].getPointOffset());
/*      */           } 
/*      */           
/* 1245 */           appendToWKTBuffers(")");
/*      */           break;
/*      */         case 2:
/* 1248 */           appendToWKTBuffers("CIRCULARSTRING(");
/*      */           
/* 1250 */           if (i == this.figures.length - 1) {
/* 1251 */             constructLineWKT(this.currentPointIndex, this.numberOfPoints);
/*      */           } else {
/* 1253 */             constructLineWKT(this.currentPointIndex, this.figures[i + 1].getPointOffset());
/*      */           } 
/*      */           
/* 1256 */           appendToWKTBuffers(")");
/*      */           break;
/*      */         
/*      */         case 3:
/* 1260 */           appendToWKTBuffers("COMPOUNDCURVE(");
/*      */           
/* 1262 */           pointEndIndex = 0;
/*      */           
/* 1264 */           if (i == this.figures.length - 1) {
/* 1265 */             pointEndIndex = this.numberOfPoints;
/*      */           } else {
/* 1267 */             pointEndIndex = this.figures[i + 1].getPointOffset();
/*      */           } 
/*      */           
/* 1270 */           while (this.currentPointIndex < pointEndIndex) {
/* 1271 */             byte segment = this.segments[segmentStartIndex].getSegmentType();
/* 1272 */             constructSegmentWKT(segmentStartIndex, segment, pointEndIndex);
/*      */             
/* 1274 */             if (this.currentPointIndex >= pointEndIndex) {
/* 1275 */               appendToWKTBuffers("))");
/*      */             } else {
/* 1277 */               switch (segment) {
/*      */                 case 0:
/*      */                 case 2:
/* 1280 */                   if (this.segments[segmentStartIndex + 1].getSegmentType() != 0) {
/* 1281 */                     appendToWKTBuffers("), ");
/*      */                   }
/*      */                   break;
/*      */                 case 1:
/*      */                 case 3:
/* 1286 */                   if (this.segments[segmentStartIndex + 1].getSegmentType() != 1) {
/* 1287 */                     appendToWKTBuffers("), ");
/*      */                   }
/*      */                   break;
/*      */                 
/*      */                 default:
/*      */                   return;
/*      */               } 
/*      */             } 
/* 1295 */             segmentStartIndex++;
/*      */           } 
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/*      */           return;
/*      */       } 
/*      */       
/* 1304 */       if (i != figureEndIndex - 1) {
/* 1305 */         appendToWKTBuffers(", ");
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void constructSegmentWKT(int currentSegment, byte segment, int pointEndIndex) {
/* 1325 */     switch (segment) {
/*      */       case 0:
/* 1327 */         appendToWKTBuffers(", ");
/* 1328 */         constructLineWKT(this.currentPointIndex, this.currentPointIndex + 1);
/*      */         
/* 1330 */         if (currentSegment != this.segments.length - 1)
/*      */         {
/* 1332 */           if (this.segments[currentSegment + 1].getSegmentType() != 0) {
/*      */             
/* 1334 */             this.currentPointIndex--;
/* 1335 */             incrementPointNumStartIfPointNotReused(pointEndIndex);
/*      */           } 
/*      */         }
/*      */         return;
/*      */       case 1:
/* 1340 */         appendToWKTBuffers(", ");
/* 1341 */         constructLineWKT(this.currentPointIndex, this.currentPointIndex + 2);
/*      */         
/* 1343 */         if (currentSegment != this.segments.length - 1)
/*      */         {
/* 1345 */           if (this.segments[currentSegment + 1].getSegmentType() != 1) {
/*      */             
/* 1347 */             this.currentPointIndex--;
/*      */ 
/*      */             
/* 1350 */             incrementPointNumStartIfPointNotReused(pointEndIndex);
/*      */           } 
/*      */         }
/*      */         return;
/*      */       case 2:
/* 1355 */         appendToWKTBuffers("(");
/* 1356 */         constructLineWKT(this.currentPointIndex, this.currentPointIndex + 2);
/*      */         
/* 1358 */         if (currentSegment != this.segments.length - 1)
/*      */         {
/* 1360 */           if (this.segments[currentSegment + 1].getSegmentType() != 0) {
/*      */             
/* 1362 */             this.currentPointIndex--;
/*      */ 
/*      */             
/* 1365 */             incrementPointNumStartIfPointNotReused(pointEndIndex);
/*      */           } 
/*      */         }
/*      */         return;
/*      */       case 3:
/* 1370 */         appendToWKTBuffers("CIRCULARSTRING(");
/* 1371 */         constructLineWKT(this.currentPointIndex, this.currentPointIndex + 3);
/*      */         
/* 1373 */         if (currentSegment != this.segments.length - 1)
/*      */         {
/* 1375 */           if (this.segments[currentSegment + 1].getSegmentType() != 1) {
/* 1376 */             this.currentPointIndex--;
/*      */ 
/*      */             
/* 1379 */             incrementPointNumStartIfPointNotReused(pointEndIndex);
/*      */           } 
/*      */         }
/*      */         return;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void constructGeometryCollectionWKT(int shapeEndIndex) throws SQLServerException {
/* 1397 */     this.currentShapeIndex++;
/* 1398 */     constructGeometryCollectionWKThelper(shapeEndIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void readPointWkt() throws SQLServerException {
/* 1409 */     int numOfCoordinates = 0;
/*      */     
/* 1411 */     double[] coords = new double[4];
/* 1412 */     for (int i = 0; i < coords.length; i++) {
/* 1413 */       coords[i] = Double.NaN;
/*      */     }
/*      */     
/* 1416 */     while (numOfCoordinates < 4) {
/* 1417 */       double sign = 1.0D;
/* 1418 */       if (this.wkt.charAt(this.currentWktPos) == '-') {
/* 1419 */         sign = -1.0D;
/* 1420 */         this.currentWktPos++;
/*      */       } 
/*      */       
/* 1423 */       int startPos = this.currentWktPos;
/*      */       
/* 1425 */       if (this.wkt.charAt(this.currentWktPos) == ')') {
/*      */         break;
/*      */       }
/*      */       
/* 1429 */       while (this.currentWktPos < this.wkt.length() && (
/* 1430 */         Character.isDigit(this.wkt.charAt(this.currentWktPos)) || this.wkt.charAt(this.currentWktPos) == '.' || this.wkt
/* 1431 */         .charAt(this.currentWktPos) == 'E' || this.wkt.charAt(this.currentWktPos) == 'e')) {
/* 1432 */         this.currentWktPos++;
/*      */       }
/*      */       
/*      */       try {
/* 1436 */         coords[numOfCoordinates] = sign * (new BigDecimal(this.wkt.substring(startPos, this.currentWktPos))).doubleValue();
/*      */         
/* 1438 */         if (numOfCoordinates == 2) {
/* 1439 */           this.hasZvalues = true;
/* 1440 */         } else if (numOfCoordinates == 3) {
/* 1441 */           this.hasMvalues = true;
/*      */         } 
/* 1443 */       } catch (Exception e) {
/*      */ 
/*      */         
/* 1446 */         if (this.wkt.length() > this.currentWktPos + 3 && "null"
/* 1447 */           .equalsIgnoreCase(this.wkt.substring(this.currentWktPos, this.currentWktPos + 4))) {
/* 1448 */           coords[numOfCoordinates] = Double.NaN;
/* 1449 */           this.currentWktPos += 4;
/*      */         } else {
/* 1451 */           throwIllegalWKTPosition();
/*      */         } 
/*      */       } 
/*      */       
/* 1455 */       numOfCoordinates++;
/*      */       
/* 1457 */       skipWhiteSpaces();
/*      */ 
/*      */ 
/*      */       
/* 1461 */       if (numOfCoordinates == 4 && 
/* 1462 */         checkSQLLength(this.currentWktPos + 1) && this.wkt.charAt(this.currentWktPos) != ',' && this.wkt
/* 1463 */         .charAt(this.currentWktPos) != ')') {
/* 1464 */         throwIllegalWKTPosition();
/*      */       }
/*      */ 
/*      */       
/* 1468 */       if (checkSQLLength(this.currentWktPos + 1) && this.wkt.charAt(this.currentWktPos) == ',') {
/*      */         
/* 1470 */         if (numOfCoordinates == 1) {
/* 1471 */           throwIllegalWKTPosition();
/*      */         }
/* 1473 */         this.currentWktPos++;
/* 1474 */         skipWhiteSpaces();
/*      */         break;
/*      */       } 
/* 1477 */       skipWhiteSpaces();
/*      */     } 
/*      */     
/* 1480 */     this.pointList.add(new Point(coords[0], coords[1], coords[2], coords[3]));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void readLineWkt() throws SQLServerException {
/* 1490 */     while (this.currentWktPos < this.wkt.length() && this.wkt.charAt(this.currentWktPos) != ')') {
/* 1491 */       readPointWkt();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void readShapeWkt(int parentShapeIndex, String nextToken) throws SQLServerException {
/* 1506 */     byte fa = 0;
/* 1507 */     while (this.currentWktPos < this.wkt.length() && this.wkt.charAt(this.currentWktPos) != ')') {
/*      */ 
/*      */ 
/*      */       
/* 1511 */       if (!"POLYGON".equals(nextToken) && 
/* 1512 */         checkEmptyKeyword(parentShapeIndex, InternalSpatialDatatype.valueOf(nextToken), true)) {
/*      */         continue;
/*      */       }
/*      */       
/* 1516 */       if ("MULTIPOINT".equals(nextToken)) {
/* 1517 */         this.shapeList.add(new Shape(parentShapeIndex, this.figureList
/* 1518 */               .size(), InternalSpatialDatatype.POINT.getTypeCode()));
/* 1519 */       } else if ("MULTILINESTRING".equals(nextToken)) {
/* 1520 */         this.shapeList.add(new Shape(parentShapeIndex, this.figureList.size(), InternalSpatialDatatype.LINESTRING
/* 1521 */               .getTypeCode()));
/*      */       } 
/*      */       
/* 1524 */       if (this.version == 1) {
/* 1525 */         if ("MULTIPOINT".equals(nextToken)) {
/* 1526 */           fa = 1;
/* 1527 */         } else if ("MULTILINESTRING".equals(nextToken) || "POLYGON".equals(nextToken)) {
/* 1528 */           fa = 2;
/*      */         } 
/* 1530 */         this.version_one_shape_indexes.add(Integer.valueOf(this.figureList.size()));
/* 1531 */       } else if (this.version == 2 && (
/* 1532 */         "MULTIPOINT".equals(nextToken) || "MULTILINESTRING".equals(nextToken) || "POLYGON".equals(nextToken) || "MULTIPOLYGON"
/* 1533 */         .equals(nextToken))) {
/* 1534 */         fa = 1;
/*      */       } 
/*      */ 
/*      */       
/* 1538 */       this.figureList.add(new Figure(fa, this.pointList.size()));
/* 1539 */       readOpenBracket();
/* 1540 */       readLineWkt();
/* 1541 */       readCloseBracket();
/*      */       
/* 1543 */       skipWhiteSpaces();
/*      */       
/* 1545 */       if (checkSQLLength(this.currentWktPos + 1) && this.wkt.charAt(this.currentWktPos) == ',') {
/* 1546 */         readComma(); continue;
/* 1547 */       }  if (this.wkt.charAt(this.currentWktPos) == ')') {
/*      */         continue;
/*      */       }
/* 1550 */       throwIllegalWKTPosition();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void readCurvePolygon() throws SQLServerException {
/* 1562 */     while (this.currentWktPos < this.wkt.length() && this.wkt.charAt(this.currentWktPos) != ')') {
/* 1563 */       String nextPotentialToken = getNextStringToken().toUpperCase(Locale.US);
/* 1564 */       if ("CIRCULARSTRING".equals(nextPotentialToken)) {
/* 1565 */         this.figureList.add(new Figure((byte)2, this.pointList.size()));
/* 1566 */         readOpenBracket();
/* 1567 */         readLineWkt();
/* 1568 */         readCloseBracket();
/* 1569 */       } else if ("COMPOUNDCURVE".equals(nextPotentialToken)) {
/* 1570 */         this.figureList.add(new Figure((byte)3, this.pointList.size()));
/* 1571 */         readOpenBracket();
/* 1572 */         readCompoundCurveWkt(true);
/* 1573 */         readCloseBracket();
/* 1574 */       } else if (this.wkt.charAt(this.currentWktPos) == '(') {
/* 1575 */         this.figureList.add(new Figure((byte)1, this.pointList.size()));
/* 1576 */         readOpenBracket();
/* 1577 */         readLineWkt();
/* 1578 */         readCloseBracket();
/*      */       } else {
/* 1580 */         throwIllegalWKTPosition();
/*      */       } 
/*      */       
/* 1583 */       if (checkSQLLength(this.currentWktPos + 1) && this.wkt.charAt(this.currentWktPos) == ',') {
/* 1584 */         readComma(); continue;
/* 1585 */       }  if (this.wkt.charAt(this.currentWktPos) == ')') {
/*      */         continue;
/*      */       }
/* 1588 */       throwIllegalWKTPosition();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void readMultiPolygonWkt(int thisShapeIndex, String nextToken) throws SQLServerException {
/* 1604 */     while (this.currentWktPos < this.wkt.length() && this.wkt.charAt(this.currentWktPos) != ')') {
/* 1605 */       if (checkEmptyKeyword(thisShapeIndex, InternalSpatialDatatype.valueOf(nextToken), true)) {
/*      */         continue;
/*      */       }
/* 1608 */       this.shapeList.add(new Shape(thisShapeIndex, this.figureList.size(), InternalSpatialDatatype.POLYGON.getTypeCode()));
/*      */       
/* 1610 */       readOpenBracket();
/* 1611 */       readShapeWkt(thisShapeIndex, nextToken);
/* 1612 */       readCloseBracket();
/*      */       
/* 1614 */       if (checkSQLLength(this.currentWktPos + 1) && this.wkt.charAt(this.currentWktPos) == ',') {
/* 1615 */         readComma(); continue;
/* 1616 */       }  if (this.wkt.charAt(this.currentWktPos) == ')') {
/*      */         continue;
/*      */       }
/* 1619 */       throwIllegalWKTPosition();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void readSegmentWkt(int segmentType, boolean isFirstIteration) throws SQLServerException {
/* 1635 */     this.segmentList.add(new Segment((byte)segmentType));
/*      */     
/* 1637 */     int segmentLength = segmentType;
/*      */ 
/*      */     
/* 1640 */     if (segmentLength < 2) {
/* 1641 */       segmentLength++;
/*      */     }
/*      */     
/* 1644 */     for (int i = 0; i < segmentLength; i++) {
/*      */ 
/*      */ 
/*      */       
/* 1648 */       if (i == 0 && !isFirstIteration && segmentType >= 2) {
/* 1649 */         skipFirstPointWkt();
/*      */       } else {
/* 1651 */         readPointWkt();
/*      */       } 
/*      */     } 
/*      */     
/* 1655 */     if (this.currentWktPos < this.wkt.length() && this.wkt.charAt(this.currentWktPos) != ')') {
/* 1656 */       if (segmentType == 3 || segmentType == 1) {
/* 1657 */         readSegmentWkt(1, false);
/* 1658 */       } else if (segmentType == 2 || segmentType == 0) {
/* 1659 */         readSegmentWkt(0, false);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void readCompoundCurveWkt(boolean isFirstIteration) throws SQLServerException {
/* 1673 */     while (this.currentWktPos < this.wkt.length() && this.wkt.charAt(this.currentWktPos) != ')') {
/* 1674 */       String nextPotentialToken = getNextStringToken().toUpperCase(Locale.US);
/* 1675 */       if ("CIRCULARSTRING".equals(nextPotentialToken)) {
/* 1676 */         readOpenBracket();
/* 1677 */         readSegmentWkt(3, isFirstIteration);
/* 1678 */         readCloseBracket();
/* 1679 */       } else if (this.wkt.charAt(this.currentWktPos) == '(') {
/* 1680 */         readOpenBracket();
/* 1681 */         readSegmentWkt(2, isFirstIteration);
/* 1682 */         readCloseBracket();
/*      */       } else {
/* 1684 */         throwIllegalWKTPosition();
/*      */       } 
/*      */       
/* 1687 */       isFirstIteration = false;
/*      */       
/* 1689 */       if (checkSQLLength(this.currentWktPos + 1) && this.wkt.charAt(this.currentWktPos) == ',') {
/* 1690 */         readComma(); continue;
/* 1691 */       }  if (this.wkt.charAt(this.currentWktPos) == ')') {
/*      */         continue;
/*      */       }
/* 1694 */       throwIllegalWKTPosition();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getNextStringToken() {
/* 1706 */     skipWhiteSpaces();
/* 1707 */     int endIndex = this.currentWktPos;
/* 1708 */     while (endIndex < this.wkt.length() && Character.isLetter(this.wkt.charAt(endIndex))) {
/* 1709 */       endIndex++;
/*      */     }
/* 1711 */     int temp = this.currentWktPos;
/* 1712 */     this.currentWktPos = endIndex;
/* 1713 */     skipWhiteSpaces();
/*      */     
/* 1715 */     return this.wkt.substring(temp, endIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void populateStructures() {
/* 1722 */     if (this.pointList.size() > 0) {
/* 1723 */       this.xValues = new double[this.pointList.size()];
/* 1724 */       this.yValues = new double[this.pointList.size()];
/*      */       int i;
/* 1726 */       for (i = 0; i < this.pointList.size(); i++) {
/* 1727 */         this.xValues[i] = ((Point)this.pointList.get(i)).getX();
/* 1728 */         this.yValues[i] = ((Point)this.pointList.get(i)).getY();
/*      */       } 
/*      */       
/* 1731 */       if (this.hasZvalues) {
/* 1732 */         this.zValues = new double[this.pointList.size()];
/* 1733 */         for (i = 0; i < this.pointList.size(); i++) {
/* 1734 */           this.zValues[i] = ((Point)this.pointList.get(i)).getZ();
/*      */         }
/*      */       } 
/*      */       
/* 1738 */       if (this.hasMvalues) {
/* 1739 */         this.mValues = new double[this.pointList.size()];
/* 1740 */         for (i = 0; i < this.pointList.size(); i++) {
/* 1741 */           this.mValues[i] = ((Point)this.pointList.get(i)).getM();
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1749 */     if (this.version == 2) {
/* 1750 */       for (int i = 0; i < this.version_one_shape_indexes.size(); i++) {
/* 1751 */         ((Figure)this.figureList.get(((Integer)this.version_one_shape_indexes.get(i)).intValue())).setFiguresAttribute((byte)1);
/*      */       }
/*      */     }
/*      */     
/* 1755 */     if (this.figureList.size() > 0) {
/* 1756 */       this.figures = new Figure[this.figureList.size()];
/*      */       
/* 1758 */       for (int i = 0; i < this.figureList.size(); i++) {
/* 1759 */         this.figures[i] = this.figureList.get(i);
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1768 */     if (this.pointList.size() == 0 && this.shapeList.size() > 0 && ((Shape)this.shapeList.get(0)).getOpenGISType() == 7) {
/* 1769 */       ((Shape)this.shapeList.get(0)).setFigureOffset(-1);
/*      */     }
/*      */     
/* 1772 */     if (this.shapeList.size() > 0) {
/* 1773 */       this.shapes = new Shape[this.shapeList.size()];
/*      */       
/* 1775 */       for (int i = 0; i < this.shapeList.size(); i++) {
/* 1776 */         this.shapes[i] = this.shapeList.get(i);
/*      */       }
/*      */     } 
/*      */     
/* 1780 */     if (this.segmentList.size() > 0) {
/* 1781 */       this.segments = new Segment[this.segmentList.size()];
/*      */       
/* 1783 */       for (int i = 0; i < this.segmentList.size(); i++) {
/* 1784 */         this.segments[i] = this.segmentList.get(i);
/*      */       }
/*      */     } 
/*      */     
/* 1788 */     this.numberOfPoints = this.pointList.size();
/* 1789 */     this.numberOfFigures = this.figureList.size();
/* 1790 */     this.numberOfShapes = this.shapeList.size();
/* 1791 */     this.numberOfSegments = this.segmentList.size();
/*      */   }
/*      */   
/*      */   protected void readOpenBracket() throws SQLServerException {
/* 1795 */     skipWhiteSpaces();
/* 1796 */     if (this.wkt.charAt(this.currentWktPos) == '(') {
/* 1797 */       this.currentWktPos++;
/* 1798 */       skipWhiteSpaces();
/*      */     } else {
/* 1800 */       throwIllegalWKTPosition();
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void readCloseBracket() throws SQLServerException {
/* 1805 */     skipWhiteSpaces();
/* 1806 */     if (this.wkt.charAt(this.currentWktPos) == ')') {
/* 1807 */       this.currentWktPos++;
/* 1808 */       skipWhiteSpaces();
/*      */     } else {
/* 1810 */       throwIllegalWKTPosition();
/*      */     } 
/*      */   }
/*      */   
/*      */   protected boolean hasMoreToken() {
/* 1815 */     skipWhiteSpaces();
/* 1816 */     return (this.currentWktPos < this.wkt.length());
/*      */   }
/*      */   
/*      */   protected void createSerializationProperties() {
/* 1820 */     this.serializationProperties = 0;
/* 1821 */     if (this.hasZvalues) {
/* 1822 */       this.serializationProperties = (byte)(this.serializationProperties + 1);
/*      */     }
/*      */     
/* 1825 */     if (this.hasMvalues) {
/* 1826 */       this.serializationProperties = (byte)(this.serializationProperties + 2);
/*      */     }
/*      */     
/* 1829 */     if (this.isValid) {
/* 1830 */       this.serializationProperties = (byte)(this.serializationProperties + 4);
/*      */     }
/*      */     
/* 1833 */     if (this.isSinglePoint) {
/* 1834 */       this.serializationProperties = (byte)(this.serializationProperties + 8);
/*      */     }
/*      */     
/* 1837 */     if (this.isSingleLineSegment) {
/* 1838 */       this.serializationProperties = (byte)(this.serializationProperties + 16);
/*      */     }
/*      */     
/* 1841 */     if (this.version == 2 && 
/* 1842 */       this.isLargerThanHemisphere) {
/* 1843 */       this.serializationProperties = (byte)(this.serializationProperties + 32);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   protected int determineClrCapacity(boolean excludeZMFromCLR) {
/* 1849 */     int totalSize = 0;
/*      */     
/* 1851 */     totalSize += 6;
/*      */     
/* 1853 */     if (this.isSinglePoint || this.isSingleLineSegment) {
/* 1854 */       totalSize += 16 * this.numberOfPoints;
/*      */       
/* 1856 */       if (!excludeZMFromCLR) {
/* 1857 */         if (this.hasZvalues) {
/* 1858 */           totalSize += 8 * this.numberOfPoints;
/*      */         }
/*      */         
/* 1861 */         if (this.hasMvalues) {
/* 1862 */           totalSize += 8 * this.numberOfPoints;
/*      */         }
/*      */       } 
/*      */       
/* 1866 */       return totalSize;
/*      */     } 
/*      */     
/* 1869 */     int pointSize = 16;
/* 1870 */     if (!excludeZMFromCLR) {
/* 1871 */       if (this.hasZvalues) {
/* 1872 */         pointSize += 8;
/*      */       }
/*      */       
/* 1875 */       if (this.hasMvalues) {
/* 1876 */         pointSize += 8;
/*      */       }
/*      */     } 
/*      */     
/* 1880 */     totalSize += 12;
/* 1881 */     totalSize += this.numberOfPoints * pointSize;
/* 1882 */     totalSize += this.numberOfFigures * 5;
/* 1883 */     totalSize += this.numberOfShapes * 9;
/*      */     
/* 1885 */     if (this.version == 2) {
/* 1886 */       totalSize += 4;
/* 1887 */       totalSize += this.numberOfSegments;
/*      */     } 
/*      */     
/* 1890 */     return totalSize;
/*      */   }
/*      */   
/*      */   protected int determineWkbCapacity() {
/* 1894 */     int i, actualNumberOfPoints, numberOfCompositeCurves, j, totalSize = 0;
/*      */     
/* 1896 */     totalSize++;
/* 1897 */     totalSize += 4;
/*      */     
/* 1899 */     switch (this.internalType) {
/*      */       
/*      */       case POINT:
/* 1902 */         if (this.numberOfPoints == 0) {
/* 1903 */           totalSize += 4;
/*      */         }
/* 1905 */         totalSize += this.numberOfPoints * 16;
/*      */         break;
/*      */       case LINESTRING:
/* 1908 */         totalSize += 4;
/* 1909 */         totalSize += this.numberOfPoints * 16;
/*      */         break;
/*      */       case POLYGON:
/* 1912 */         totalSize += 4;
/* 1913 */         totalSize += this.figures.length * 4 + this.numberOfPoints * 16;
/*      */         break;
/*      */       case MULTIPOINT:
/* 1916 */         totalSize += 4;
/* 1917 */         totalSize += this.numberOfFigures * 5;
/* 1918 */         totalSize += this.numberOfPoints * 16;
/*      */         break;
/*      */       case MULTILINESTRING:
/* 1921 */         totalSize += 4;
/* 1922 */         totalSize += this.numberOfFigures * 9;
/* 1923 */         totalSize += this.numberOfPoints * 16;
/*      */         break;
/*      */       case MULTIPOLYGON:
/* 1926 */         totalSize += 4;
/* 1927 */         totalSize += (this.numberOfShapes - 1) * 9;
/* 1928 */         for (i = 1; i < this.shapes.length; i++) {
/* 1929 */           if (i == this.shapes.length - 1) {
/* 1930 */             totalSize += 4 * (this.figures.length - this.shapes[i].getFigureOffset());
/*      */           } else {
/* 1932 */             int nextFigureOffset = this.shapes[i + 1].getFigureOffset();
/* 1933 */             totalSize += 4 * (nextFigureOffset - this.shapes[i].getFigureOffset());
/*      */           } 
/*      */         } 
/* 1936 */         totalSize += this.numberOfPoints * 16;
/*      */         break;
/*      */       case GEOMETRYCOLLECTION:
/* 1939 */         totalSize += 4;
/* 1940 */         actualNumberOfPoints = this.numberOfPoints;
/* 1941 */         for (Segment s : this.segments) {
/* 1942 */           if (s.getSegmentType() == 3 || s.getSegmentType() == 2) {
/* 1943 */             totalSize += 9;
/* 1944 */             actualNumberOfPoints++;
/*      */           } 
/*      */         } 
/* 1947 */         numberOfCompositeCurves = 0;
/* 1948 */         for (Figure f : this.figures) {
/* 1949 */           if (f.getFiguresAttribute() == 3) {
/* 1950 */             numberOfCompositeCurves++;
/*      */           }
/*      */         } 
/* 1953 */         if (numberOfCompositeCurves > 1) {
/* 1954 */           actualNumberOfPoints -= numberOfCompositeCurves - 1;
/*      */         }
/* 1956 */         if (this.numberOfSegments > 0) {
/* 1957 */           actualNumberOfPoints--;
/*      */         }
/*      */         
/* 1960 */         for (j = 1; j < this.shapes.length; j++) {
/* 1961 */           if (this.shapes[j].getOpenGISType() == InternalSpatialDatatype.POINT.getTypeCode()) {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1966 */             if (this.shapes[j].getFigureOffset() == -1) {
/* 1967 */               totalSize += 9;
/*      */             } else {
/* 1969 */               totalSize += 5;
/*      */             } 
/* 1971 */           } else if (this.shapes[j].getOpenGISType() == InternalSpatialDatatype.POLYGON.getTypeCode()) {
/* 1972 */             if (this.shapes[j].getFigureOffset() != -1) {
/* 1973 */               if (j == this.shapes.length - 1) {
/* 1974 */                 totalSize += 4 * (this.figures.length - this.shapes[j].getFigureOffset());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               }
/*      */               else {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/* 1988 */                 int figureIndexEnd = -1;
/* 1989 */                 int localCurrentShapeIndex = j;
/* 1990 */                 while (figureIndexEnd == -1 && localCurrentShapeIndex < this.shapes.length - 1) {
/* 1991 */                   figureIndexEnd = this.shapes[localCurrentShapeIndex + 1].getFigureOffset();
/* 1992 */                   localCurrentShapeIndex++;
/*      */                 } 
/*      */                 
/* 1995 */                 if (figureIndexEnd == -1) {
/* 1996 */                   figureIndexEnd = this.numberOfFigures;
/*      */                 }
/*      */                 
/* 1999 */                 totalSize += 4 * (figureIndexEnd - this.shapes[j].getFigureOffset());
/*      */               } 
/*      */             }
/* 2002 */             totalSize += 9;
/* 2003 */           } else if (this.shapes[j].getOpenGISType() == InternalSpatialDatatype.CURVEPOLYGON.getTypeCode()) {
/* 2004 */             if (this.shapes[j].getFigureOffset() != -1) {
/* 2005 */               if (j == this.shapes.length - 1) {
/* 2006 */                 totalSize += 9 * (this.figures.length - this.shapes[j].getFigureOffset());
/*      */               } else {
/* 2008 */                 int figureIndexEnd = -1;
/* 2009 */                 int localCurrentShapeIndex = j;
/* 2010 */                 while (figureIndexEnd == -1 && localCurrentShapeIndex < this.shapes.length - 1) {
/* 2011 */                   figureIndexEnd = this.shapes[localCurrentShapeIndex + 1].getFigureOffset();
/* 2012 */                   localCurrentShapeIndex++;
/*      */                 } 
/*      */                 
/* 2015 */                 if (figureIndexEnd == -1) {
/* 2016 */                   figureIndexEnd = this.numberOfFigures;
/*      */                 }
/* 2018 */                 totalSize += 9 * (figureIndexEnd - this.shapes[j].getFigureOffset());
/*      */               } 
/*      */             }
/* 2021 */             totalSize += 9;
/*      */           } else {
/* 2023 */             totalSize += 9;
/*      */           } 
/*      */         } 
/* 2026 */         totalSize += actualNumberOfPoints * 16;
/*      */         break;
/*      */       case CIRCULARSTRING:
/* 2029 */         totalSize += 4;
/* 2030 */         totalSize += this.numberOfPoints * 16;
/*      */         break;
/*      */       case COMPOUNDCURVE:
/* 2033 */         totalSize += 4;
/* 2034 */         actualNumberOfPoints = this.numberOfPoints;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2052 */         for (Segment s : this.segments) {
/* 2053 */           if (s.getSegmentType() == 3 || s.getSegmentType() == 2) {
/* 2054 */             totalSize += 9;
/* 2055 */             actualNumberOfPoints++;
/*      */           } 
/*      */         } 
/* 2058 */         if (this.numberOfSegments > 0) {
/* 2059 */           actualNumberOfPoints--;
/*      */         }
/* 2061 */         totalSize += actualNumberOfPoints * 16;
/*      */         break;
/*      */       case CURVEPOLYGON:
/* 2064 */         totalSize += 4;
/* 2065 */         actualNumberOfPoints = this.numberOfPoints;
/* 2066 */         for (Segment s : this.segments) {
/* 2067 */           if (s.getSegmentType() == 3 || s.getSegmentType() == 2) {
/* 2068 */             totalSize += 9;
/* 2069 */             actualNumberOfPoints++;
/*      */           } 
/*      */         } 
/* 2072 */         numberOfCompositeCurves = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2082 */         for (Figure f : this.figures) {
/* 2083 */           totalSize += 9;
/* 2084 */           if (f.getFiguresAttribute() == 3) {
/* 2085 */             numberOfCompositeCurves++;
/*      */           }
/*      */         } 
/*      */         
/* 2089 */         if (numberOfCompositeCurves > 1) {
/* 2090 */           actualNumberOfPoints -= numberOfCompositeCurves - 1;
/*      */         }
/* 2092 */         if (this.numberOfSegments > 0) {
/* 2093 */           actualNumberOfPoints--;
/*      */         }
/* 2095 */         totalSize += actualNumberOfPoints * 16;
/*      */         break;
/*      */       case FULLGLOBE:
/* 2098 */         totalSize = 5;
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2104 */     return totalSize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void appendToWKTBuffers(Object o) {
/* 2114 */     this.WKTsb.append(o);
/* 2115 */     this.WKTsbNoZM.append(o);
/*      */   }
/*      */   
/*      */   protected void interpretSerializationPropBytes() {
/* 2119 */     this.hasZvalues = ((this.serializationProperties & 0x1) != 0);
/* 2120 */     this.hasMvalues = ((this.serializationProperties & 0x2) != 0);
/* 2121 */     this.isValid = ((this.serializationProperties & 0x4) != 0);
/* 2122 */     this.isSinglePoint = ((this.serializationProperties & 0x8) != 0);
/* 2123 */     this.isSingleLineSegment = ((this.serializationProperties & 0x10) != 0);
/* 2124 */     this.isLargerThanHemisphere = ((this.serializationProperties & 0x20) != 0);
/*      */   }
/*      */   
/*      */   protected void readNumberOfPoints() throws SQLServerException {
/* 2128 */     if (this.isSinglePoint) {
/* 2129 */       this.numberOfPoints = 1;
/* 2130 */     } else if (this.isSingleLineSegment) {
/* 2131 */       this.numberOfPoints = 2;
/*      */     } else {
/* 2133 */       this.numberOfPoints = readInt();
/* 2134 */       checkNegSize(this.numberOfPoints);
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void readZvalues() throws SQLServerException {
/* 2139 */     this.zValues = new double[this.numberOfPoints];
/* 2140 */     for (int i = 0; i < this.numberOfPoints; i++) {
/* 2141 */       this.zValues[i] = readDouble();
/*      */     }
/*      */   }
/*      */   
/*      */   protected void readMvalues() throws SQLServerException {
/* 2146 */     this.mValues = new double[this.numberOfPoints];
/* 2147 */     for (int i = 0; i < this.numberOfPoints; i++) {
/* 2148 */       this.mValues[i] = readDouble();
/*      */     }
/*      */   }
/*      */   
/*      */   protected void readNumberOfFigures() throws SQLServerException {
/* 2153 */     this.numberOfFigures = readInt();
/* 2154 */     checkNegSize(this.numberOfFigures);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void readFigures() throws SQLServerException {
/* 2160 */     this.figures = new Figure[this.numberOfFigures];
/* 2161 */     for (int i = 0; i < this.numberOfFigures; i++) {
/* 2162 */       byte fa = readByte();
/* 2163 */       int po = readInt();
/* 2164 */       this.figures[i] = new Figure(fa, po);
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void readNumberOfShapes() throws SQLServerException {
/* 2169 */     this.numberOfShapes = readInt();
/* 2170 */     checkNegSize(this.numberOfShapes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void readShapes() throws SQLServerException {
/* 2177 */     this.shapes = new Shape[this.numberOfShapes];
/* 2178 */     for (int i = 0; i < this.numberOfShapes; i++) {
/* 2179 */       int po = readInt();
/* 2180 */       int fo = readInt();
/* 2181 */       byte ogt = readByte();
/* 2182 */       this.shapes[i] = new Shape(po, fo, ogt);
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void readNumberOfSegments() throws SQLServerException {
/* 2187 */     this.numberOfSegments = readInt();
/* 2188 */     checkNegSize(this.numberOfSegments);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void readSegments() throws SQLServerException {
/* 2193 */     this.segments = new Segment[this.numberOfSegments];
/* 2194 */     for (int i = 0; i < this.numberOfSegments; i++) {
/* 2195 */       byte st = readByte();
/* 2196 */       this.segments[i] = new Segment(st);
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void determineInternalType() {
/* 2201 */     if (this.isSinglePoint) {
/* 2202 */       this.internalType = InternalSpatialDatatype.POINT;
/* 2203 */     } else if (this.isSingleLineSegment) {
/* 2204 */       this.internalType = InternalSpatialDatatype.LINESTRING;
/*      */     } else {
/* 2206 */       this.internalType = InternalSpatialDatatype.valueOf(this.shapes[0].getOpenGISType());
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean checkEmptyKeyword(int parentShapeIndex, InternalSpatialDatatype isd, boolean isInsideAnotherShape) throws SQLServerException {
/* 2212 */     String potentialEmptyKeyword = getNextStringToken().toUpperCase(Locale.US);
/* 2213 */     if ("EMPTY".equals(potentialEmptyKeyword)) {
/*      */       
/* 2215 */       byte typeCode = 0;
/*      */       
/* 2217 */       if (isInsideAnotherShape) {
/* 2218 */         byte parentTypeCode = isd.getTypeCode();
/* 2219 */         if (parentTypeCode == 4) {
/* 2220 */           typeCode = InternalSpatialDatatype.POINT.getTypeCode();
/* 2221 */         } else if (parentTypeCode == 5) {
/* 2222 */           typeCode = InternalSpatialDatatype.LINESTRING.getTypeCode();
/* 2223 */         } else if (parentTypeCode == 6) {
/* 2224 */           typeCode = InternalSpatialDatatype.POLYGON.getTypeCode();
/* 2225 */         } else if (parentTypeCode == 7) {
/* 2226 */           typeCode = InternalSpatialDatatype.GEOMETRYCOLLECTION.getTypeCode();
/*      */         } else {
/* 2228 */           String strError = SQLServerException.getErrString("R_illegalWKT");
/* 2229 */           throw new SQLServerException(strError, null, 0, null);
/*      */         } 
/*      */       } else {
/* 2232 */         typeCode = isd.getTypeCode();
/*      */       } 
/*      */       
/* 2235 */       this.shapeList.add(new Shape(parentShapeIndex, -1, typeCode));
/* 2236 */       skipWhiteSpaces();
/* 2237 */       if (this.currentWktPos < this.wkt.length() && this.wkt.charAt(this.currentWktPos) == ',') {
/* 2238 */         this.currentWktPos++;
/* 2239 */         skipWhiteSpaces();
/*      */       } 
/* 2241 */       return true;
/*      */     } 
/*      */     
/* 2244 */     if (!"".equals(potentialEmptyKeyword)) {
/* 2245 */       throwIllegalWKTPosition();
/*      */     }
/* 2247 */     return false;
/*      */   }
/*      */   
/*      */   protected void throwIllegalWKT() throws SQLServerException {
/* 2251 */     String strError = SQLServerException.getErrString("R_illegalWKT");
/* 2252 */     throw new SQLServerException(strError, null, 0, null);
/*      */   }
/*      */   
/*      */   protected void throwIllegalByteArray() throws SQLServerException {
/* 2256 */     MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_ParsingError"));
/* 2257 */     Object[] msgArgs = { JDBCType.VARBINARY };
/* 2258 */     throw new SQLServerException(this, form.format(msgArgs), null, 0, false);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void incrementPointNumStartIfPointNotReused(int pointEndIndex) {
/* 2264 */     if (this.currentPointIndex + 1 >= pointEndIndex) {
/* 2265 */       this.currentPointIndex++;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void constructGeometryCollectionWKThelper(int shapeEndIndex) throws SQLServerException {
/* 2279 */     while (this.currentShapeIndex < shapeEndIndex) {
/* 2280 */       InternalSpatialDatatype isd = InternalSpatialDatatype.valueOf(this.shapes[this.currentShapeIndex].getOpenGISType());
/*      */       
/* 2282 */       int figureIndex = this.shapes[this.currentShapeIndex].getFigureOffset();
/* 2283 */       int pointIndexEnd = this.numberOfPoints;
/* 2284 */       int figureIndexEnd = this.numberOfFigures;
/* 2285 */       int segmentIndexEnd = this.numberOfSegments;
/* 2286 */       int shapeIndexEnd = this.numberOfShapes;
/* 2287 */       int figureIndexIncrement = 0;
/* 2288 */       int segmentIndexIncrement = 0;
/* 2289 */       int shapeIndexIncrement = 0;
/* 2290 */       int localCurrentSegmentIndex = 0;
/* 2291 */       int localCurrentShapeIndex = 0;
/*      */ 
/*      */       
/* 2294 */       if (this.shapes[this.currentShapeIndex].getFigureOffset() == -1) {
/* 2295 */         this.currentShapeIndex++;
/* 2296 */         figureIndexEnd = -1;
/*      */       } else {
/* 2298 */         int thisShapesParentOffset; int tempShapeIndex; int geometryCollectionParentIndex; int increment; switch (isd) {
/*      */           case POINT:
/* 2300 */             figureIndexIncrement++;
/* 2301 */             this.currentShapeIndex++;
/*      */             break;
/*      */           case LINESTRING:
/*      */           case CIRCULARSTRING:
/* 2305 */             figureIndexIncrement++;
/* 2306 */             this.currentShapeIndex++;
/* 2307 */             if (figureIndex + 1 < this.figures.length) {
/* 2308 */               pointIndexEnd = this.figures[figureIndex + 1].getPointOffset(); break;
/*      */             } 
/* 2310 */             pointIndexEnd = this.numberOfPoints;
/*      */             break;
/*      */           
/*      */           case POLYGON:
/*      */           case CURVEPOLYGON:
/* 2315 */             figureIndexEnd = -1;
/* 2316 */             localCurrentShapeIndex = this.currentShapeIndex;
/* 2317 */             while (figureIndexEnd == -1 && localCurrentShapeIndex < this.shapes.length - 1) {
/* 2318 */               figureIndexEnd = this.shapes[localCurrentShapeIndex + 1].getFigureOffset();
/* 2319 */               localCurrentShapeIndex++;
/*      */             } 
/*      */             
/* 2322 */             if (figureIndexEnd == -1) {
/* 2323 */               figureIndexEnd = this.numberOfFigures;
/*      */             }
/*      */             
/* 2326 */             this.currentShapeIndex++;
/* 2327 */             figureIndexIncrement = figureIndexEnd - this.currentFigureIndex;
/*      */ 
/*      */             
/* 2330 */             localCurrentSegmentIndex = this.currentSegmentIndex;
/*      */             
/* 2332 */             if (isd.equals(InternalSpatialDatatype.CURVEPOLYGON))
/*      */             {
/*      */               
/* 2335 */               for (int i = this.currentFigureIndex; i < figureIndexEnd; i++) {
/*      */                 
/* 2337 */                 if (this.figures[i].getFiguresAttribute() == 3) {
/*      */                   int pointOffsetEnd;
/*      */                   
/* 2340 */                   if (i == this.figures.length - 1) {
/* 2341 */                     pointOffsetEnd = this.numberOfPoints;
/*      */                   } else {
/* 2343 */                     pointOffsetEnd = this.figures[i + 1].getPointOffset();
/*      */                   } 
/*      */                   
/* 2346 */                   int j = calculateSegmentIncrement(localCurrentSegmentIndex, pointOffsetEnd - this.figures[i]
/* 2347 */                       .getPointOffset());
/*      */                   
/* 2349 */                   segmentIndexIncrement += j;
/* 2350 */                   localCurrentSegmentIndex += j;
/*      */                 } 
/*      */               } 
/*      */             }
/*      */             
/* 2355 */             segmentIndexEnd = localCurrentSegmentIndex;
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case MULTIPOINT:
/*      */           case MULTILINESTRING:
/*      */           case MULTIPOLYGON:
/* 2367 */             thisShapesParentOffset = this.shapes[this.currentShapeIndex].getParentOffset();
/*      */             
/* 2369 */             tempShapeIndex = this.currentShapeIndex;
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 2374 */             tempShapeIndex++;
/* 2375 */             while (tempShapeIndex < this.shapes.length && this.shapes[tempShapeIndex]
/* 2376 */               .getParentOffset() != thisShapesParentOffset) {
/* 2377 */               if (tempShapeIndex != this.shapes.length - 1 && this.shapes[tempShapeIndex + 1]
/*      */                 
/* 2379 */                 .getFigureOffset() != -1) {
/* 2380 */                 figureIndexEnd = this.shapes[tempShapeIndex + 1].getFigureOffset();
/*      */               }
/* 2382 */               tempShapeIndex++;
/*      */             } 
/*      */             
/* 2385 */             figureIndexIncrement = figureIndexEnd - this.currentFigureIndex;
/* 2386 */             shapeIndexIncrement = tempShapeIndex - this.currentShapeIndex;
/* 2387 */             shapeIndexEnd = tempShapeIndex;
/*      */             break;
/*      */           case GEOMETRYCOLLECTION:
/* 2390 */             appendToWKTBuffers(isd.getTypeName());
/*      */ 
/*      */             
/* 2393 */             if (this.shapes[this.currentShapeIndex].getFigureOffset() == -1) {
/* 2394 */               appendToWKTBuffers(" EMPTY");
/* 2395 */               this.currentShapeIndex++;
/* 2396 */               if (this.currentShapeIndex < shapeEndIndex) {
/* 2397 */                 appendToWKTBuffers(", ");
/*      */               }
/*      */               
/*      */               continue;
/*      */             } 
/* 2402 */             appendToWKTBuffers("(");
/*      */             
/* 2404 */             geometryCollectionParentIndex = this.shapes[this.currentShapeIndex].getParentOffset();
/*      */ 
/*      */             
/* 2407 */             localCurrentShapeIndex = this.currentShapeIndex;
/*      */             
/* 2409 */             while (localCurrentShapeIndex < this.shapes.length - 1 && this.shapes[localCurrentShapeIndex + 1]
/* 2410 */               .getParentOffset() > geometryCollectionParentIndex) {
/* 2411 */               localCurrentShapeIndex++;
/*      */             }
/*      */ 
/*      */ 
/*      */             
/* 2416 */             localCurrentShapeIndex++;
/*      */             
/* 2418 */             this.currentShapeIndex++;
/* 2419 */             constructGeometryCollectionWKThelper(localCurrentShapeIndex);
/*      */             
/* 2421 */             if (this.currentShapeIndex < shapeEndIndex) {
/* 2422 */               appendToWKTBuffers("), "); continue;
/*      */             } 
/* 2424 */             appendToWKTBuffers(")");
/*      */             continue;
/*      */ 
/*      */           
/*      */           case COMPOUNDCURVE:
/* 2429 */             if (this.currentFigureIndex == this.figures.length - 1) {
/* 2430 */               pointIndexEnd = this.numberOfPoints;
/*      */             } else {
/* 2432 */               pointIndexEnd = this.figures[this.currentFigureIndex + 1].getPointOffset();
/*      */             } 
/*      */             
/* 2435 */             increment = calculateSegmentIncrement(this.currentSegmentIndex, pointIndexEnd - this.figures[this.currentFigureIndex]
/* 2436 */                 .getPointOffset());
/*      */             
/* 2438 */             segmentIndexIncrement = increment;
/* 2439 */             segmentIndexEnd = this.currentSegmentIndex + increment;
/* 2440 */             figureIndexIncrement++;
/* 2441 */             this.currentShapeIndex++;
/*      */             break;
/*      */           case FULLGLOBE:
/* 2444 */             appendToWKTBuffers("FULLGLOBE");
/*      */             break;
/*      */         } 
/*      */ 
/*      */ 
/*      */       
/*      */       } 
/* 2451 */       constructWKT(this, isd, pointIndexEnd, figureIndexEnd, segmentIndexEnd, shapeIndexEnd);
/* 2452 */       this.currentFigureIndex += figureIndexIncrement;
/* 2453 */       this.currentSegmentIndex += segmentIndexIncrement;
/* 2454 */       this.currentShapeIndex += shapeIndexIncrement;
/*      */       
/* 2456 */       if (this.currentShapeIndex < shapeEndIndex) {
/* 2457 */         appendToWKTBuffers(", ");
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int calculateSegmentIncrement(int segmentStart, int pointDifference) {
/* 2475 */     int segmentIncrement = 0;
/*      */     
/* 2477 */     while (pointDifference > 0) {
/* 2478 */       switch (this.segments[segmentStart].getSegmentType()) {
/*      */         case 0:
/* 2480 */           pointDifference--;
/*      */           
/* 2482 */           if (segmentStart == this.segments.length - 1 || pointDifference < 1)
/*      */             break; 
/* 2484 */           if (this.segments[segmentStart + 1].getSegmentType() != 0) {
/* 2485 */             pointDifference++;
/*      */           }
/*      */           break;
/*      */         case 1:
/* 2489 */           pointDifference -= 2;
/*      */           
/* 2491 */           if (segmentStart == this.segments.length - 1 || pointDifference < 1)
/*      */             break; 
/* 2493 */           if (this.segments[segmentStart + 1].getSegmentType() != 1) {
/* 2494 */             pointDifference++;
/*      */           }
/*      */           break;
/*      */         case 2:
/* 2498 */           pointDifference -= 2;
/*      */           
/* 2500 */           if (segmentStart == this.segments.length - 1 || pointDifference < 1)
/*      */             break; 
/* 2502 */           if (this.segments[segmentStart + 1].getSegmentType() != 0) {
/* 2503 */             pointDifference++;
/*      */           }
/*      */           break;
/*      */         case 3:
/* 2507 */           pointDifference -= 3;
/*      */           
/* 2509 */           if (segmentStart == this.segments.length - 1 || pointDifference < 1)
/*      */             break; 
/* 2511 */           if (this.segments[segmentStart + 1].getSegmentType() != 1) {
/* 2512 */             pointDifference++;
/*      */           }
/*      */           break;
/*      */         default:
/* 2516 */           return segmentIncrement;
/*      */       } 
/* 2518 */       segmentStart++;
/* 2519 */       segmentIncrement++;
/*      */     } 
/*      */     
/* 2522 */     return segmentIncrement;
/*      */   }
/*      */   
/*      */   private void skipFirstPointWkt() {
/* 2526 */     int numOfCoordinates = 0;
/*      */     
/* 2528 */     while (numOfCoordinates < 4) {
/* 2529 */       if (this.wkt.charAt(this.currentWktPos) == '-') {
/* 2530 */         this.currentWktPos++;
/*      */       }
/*      */       
/* 2533 */       if (this.wkt.charAt(this.currentWktPos) == ')') {
/*      */         break;
/*      */       }
/*      */       
/* 2537 */       while (this.currentWktPos < this.wkt.length() && (
/* 2538 */         Character.isDigit(this.wkt.charAt(this.currentWktPos)) || this.wkt.charAt(this.currentWktPos) == '.' || this.wkt
/* 2539 */         .charAt(this.currentWktPos) == 'E' || this.wkt.charAt(this.currentWktPos) == 'e')) {
/* 2540 */         this.currentWktPos++;
/*      */       }
/*      */       
/* 2543 */       skipWhiteSpaces();
/* 2544 */       if (this.wkt.charAt(this.currentWktPos) == ',') {
/* 2545 */         this.currentWktPos++;
/* 2546 */         skipWhiteSpaces();
/* 2547 */         numOfCoordinates++;
/*      */         break;
/*      */       } 
/* 2550 */       skipWhiteSpaces();
/*      */       
/* 2552 */       numOfCoordinates++;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void readComma() throws SQLServerException {
/* 2557 */     skipWhiteSpaces();
/* 2558 */     if (this.wkt.charAt(this.currentWktPos) == ',') {
/* 2559 */       this.currentWktPos++;
/* 2560 */       skipWhiteSpaces();
/*      */     } else {
/* 2562 */       throwIllegalWKTPosition();
/*      */     } 
/*      */   }
/*      */   
/*      */   private void skipWhiteSpaces() {
/* 2567 */     while (this.currentWktPos < this.wkt.length() && Character.isWhitespace(this.wkt.charAt(this.currentWktPos))) {
/* 2568 */       this.currentWktPos++;
/*      */     }
/*      */   }
/*      */   
/*      */   private void checkNegSize(int num) throws SQLServerException {
/* 2573 */     if (num < 0) {
/* 2574 */       throwIllegalByteArray();
/*      */     }
/*      */   }
/*      */   
/*      */   private void readPoints(SQLServerSpatialDatatype type) throws SQLServerException {
/* 2579 */     this.xValues = new double[this.numberOfPoints];
/* 2580 */     this.yValues = new double[this.numberOfPoints];
/*      */     
/* 2582 */     if (type instanceof Geometry) {
/* 2583 */       for (int i = 0; i < this.numberOfPoints; i++) {
/* 2584 */         this.xValues[i] = readDouble();
/* 2585 */         this.yValues[i] = readDouble();
/*      */       } 
/*      */     } else {
/* 2588 */       for (int i = 0; i < this.numberOfPoints; i++) {
/* 2589 */         this.yValues[i] = readDouble();
/* 2590 */         this.xValues[i] = readDouble();
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void checkBuffer(int i) throws SQLServerException {
/* 2596 */     if (this.buffer.remaining() < i) {
/* 2597 */       throwIllegalByteArray();
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean checkSQLLength(int length) throws SQLServerException {
/* 2602 */     if (null == this.wkt || this.wkt.length() < length) {
/* 2603 */       throwIllegalWKTPosition();
/*      */     }
/* 2605 */     return true;
/*      */   }
/*      */   
/*      */   private void throwIllegalWKTPosition() throws SQLServerException {
/* 2609 */     MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_illegalWKTposition"));
/* 2610 */     throw new SQLServerException(form.format(new Object[] { Integer.valueOf(this.currentWktPos) }, ), null, 0, null);
/*      */   }
/*      */   
/*      */   protected byte readByte() throws SQLServerException {
/* 2614 */     checkBuffer(1);
/* 2615 */     return this.buffer.get();
/*      */   }
/*      */   
/*      */   protected int readInt() throws SQLServerException {
/* 2619 */     checkBuffer(4);
/* 2620 */     return this.buffer.getInt();
/*      */   }
/*      */   
/*      */   protected double readDouble() throws SQLServerException {
/* 2624 */     checkBuffer(8);
/* 2625 */     return this.buffer.getDouble();
/*      */   }
/*      */ 
/*      */   
/*      */   public List<Point> getPointList() {
/* 2630 */     return this.pointList;
/*      */   }
/*      */   
/*      */   public List<Figure> getFigureList() {
/* 2634 */     return this.figureList;
/*      */   }
/*      */   
/*      */   public List<Shape> getShapeList() {
/* 2638 */     return this.shapeList;
/*      */   }
/*      */   
/*      */   public List<Segment> getSegmentList() {
/* 2642 */     return this.segmentList;
/*      */   }
/*      */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerSpatialDatatype.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */