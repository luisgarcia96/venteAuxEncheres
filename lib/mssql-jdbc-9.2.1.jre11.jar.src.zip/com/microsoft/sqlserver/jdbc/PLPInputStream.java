/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PLPInputStream
/*     */   extends BaseInputStream
/*     */ {
/*     */   static final long PLP_NULL = -1L;
/*     */   static final long UNKNOWN_PLP_LEN = -2L;
/*  26 */   private static final byte[] EMPTY_PLP_BYTES = new byte[0];
/*     */   
/*     */   private static final int PLP_EOS = -1;
/*     */   private int currentChunkRemain;
/*     */   private int markedChunkRemain;
/*  31 */   private int leftOverReadLimit = 0;
/*     */   
/*  33 */   private byte[] oneByteArray = new byte[1];
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final boolean isNull(TDSReader tdsReader) throws SQLServerException {
/*  39 */     TDSReaderMark mark = tdsReader.mark();
/*     */     
/*     */     try {
/*  42 */       return (null == makeTempStream(tdsReader, false, (ServerDTVImpl)null));
/*     */     } finally {
/*  44 */       tdsReader.reset(mark);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final PLPInputStream makeTempStream(TDSReader tdsReader, boolean discardValue, ServerDTVImpl dtv) throws SQLServerException {
/*  63 */     return makeStream(tdsReader, discardValue, discardValue, dtv);
/*     */   }
/*     */ 
/*     */   
/*     */   static final PLPInputStream makeStream(TDSReader tdsReader, InputStreamGetterArgs getterArgs, ServerDTVImpl dtv) throws SQLServerException {
/*  68 */     PLPInputStream is = makeStream(tdsReader, getterArgs.isAdaptive, getterArgs.isStreaming, dtv);
/*  69 */     if (null != is)
/*  70 */       is.setLoggingInfo(getterArgs.logContext); 
/*  71 */     return is;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static PLPInputStream makeStream(TDSReader tdsReader, boolean isAdaptive, boolean isStreaming, ServerDTVImpl dtv) throws SQLServerException {
/*  77 */     long payloadLength = tdsReader.readLong();
/*     */ 
/*     */     
/*  80 */     if (-1L == payloadLength) {
/*  81 */       return null;
/*     */     }
/*  83 */     return new PLPInputStream(tdsReader, payloadLength, isAdaptive, isStreaming, dtv);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   PLPInputStream(TDSReader tdsReader, long statedPayloadLength, boolean isAdaptive, boolean isStreaming, ServerDTVImpl dtv) {
/*  91 */     super(tdsReader, isAdaptive, isStreaming, dtv);
/*  92 */     this.payloadLength = (-2L != statedPayloadLength) ? (int)statedPayloadLength : -1;
/*  93 */     this.currentChunkRemain = this.markedChunkRemain = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getBytes() throws SQLServerException {
/*     */     byte[] value;
/* 105 */     readBytesInternal((byte[])null, 0, 0);
/*     */     
/* 107 */     if (-1 == this.currentChunkRemain) {
/* 108 */       value = EMPTY_PLP_BYTES;
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 113 */       value = new byte[(-1 != this.payloadLength) ? this.payloadLength : this.currentChunkRemain];
/*     */       
/* 115 */       int bytesRead = 0;
/* 116 */       while (-1 != this.currentChunkRemain) {
/*     */ 
/*     */         
/* 119 */         if (value.length == bytesRead) {
/* 120 */           byte[] newValue = new byte[bytesRead + this.currentChunkRemain];
/* 121 */           System.arraycopy(value, 0, newValue, 0, bytesRead);
/* 122 */           value = newValue;
/*     */         } 
/*     */         
/* 125 */         bytesRead += readBytesInternal(value, bytesRead, this.currentChunkRemain);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 131 */       close();
/* 132 */     } catch (IOException e) {
/* 133 */       SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, e.getMessage(), (String)null, true);
/*     */     } 
/*     */     
/* 136 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long skip(long n) throws IOException {
/* 150 */     checkClosed();
/* 151 */     if (n < 0L)
/* 152 */       return 0L; 
/* 153 */     if (n > 2147483647L) {
/* 154 */       n = 2147483647L;
/*     */     }
/* 156 */     long bytesread = readBytes((byte[])null, 0, (int)n);
/*     */     
/* 158 */     if (-1L == bytesread) {
/* 159 */       return 0L;
/*     */     }
/* 161 */     return bytesread;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int available() throws IOException {
/* 174 */     checkClosed();
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 179 */       if (0 == this.currentChunkRemain) {
/* 180 */         readBytesInternal((byte[])null, 0, 0);
/*     */       }
/* 182 */       if (-1 == this.currentChunkRemain) {
/* 183 */         return 0;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 188 */       int available = this.tdsReader.available();
/* 189 */       if (available > this.currentChunkRemain) {
/* 190 */         available = this.currentChunkRemain;
/*     */       }
/* 192 */       return available;
/* 193 */     } catch (SQLServerException e) {
/* 194 */       throw new IOException(e.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read() throws IOException {
/* 208 */     checkClosed();
/*     */     
/* 210 */     if (-1 != readBytes(this.oneByteArray, 0, 1))
/* 211 */       return this.oneByteArray[0] & 0xFF; 
/* 212 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(byte[] b) throws IOException {
/* 227 */     if (null == b) {
/* 228 */       throw new NullPointerException();
/*     */     }
/* 230 */     checkClosed();
/*     */     
/* 232 */     return readBytes(b, 0, b.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(byte[] b, int offset, int maxBytes) throws IOException {
/* 250 */     if (null == b) {
/* 251 */       throw new NullPointerException();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 256 */     if (offset < 0 || maxBytes < 0 || offset + maxBytes > b.length) {
/* 257 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 259 */     checkClosed();
/*     */     
/* 261 */     return readBytes(b, offset, maxBytes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int readBytes(byte[] b, int offset, int maxBytes) throws IOException {
/* 281 */     if (0 == maxBytes) {
/* 282 */       return 0;
/*     */     }
/*     */     try {
/* 285 */       return readBytesInternal(b, offset, maxBytes);
/* 286 */     } catch (SQLServerException e) {
/* 287 */       throw new IOException(e.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int readBytesInternal(byte[] b, int offset, int maxBytes) throws SQLServerException {
/* 296 */     if (-1 == this.currentChunkRemain) {
/* 297 */       return -1;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 302 */     int bytesRead = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     while (true) {
/* 308 */       if (0 == this.currentChunkRemain) {
/* 309 */         this.currentChunkRemain = (int)this.tdsReader.readUnsignedInt();
/* 310 */         assert this.currentChunkRemain >= 0;
/* 311 */         if (0 == this.currentChunkRemain) {
/* 312 */           this.currentChunkRemain = -1;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 317 */       if (bytesRead == maxBytes) {
/*     */         break;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 324 */       int bytesToRead = maxBytes - bytesRead;
/* 325 */       if (bytesToRead > this.currentChunkRemain) {
/* 326 */         bytesToRead = this.currentChunkRemain;
/*     */       }
/*     */       
/* 329 */       if (null == b) {
/* 330 */         this.tdsReader.skip(bytesToRead);
/*     */       } else {
/* 332 */         this.tdsReader.readBytes(b, offset + bytesRead, bytesToRead);
/*     */       } 
/* 334 */       bytesRead += bytesToRead;
/* 335 */       this.currentChunkRemain -= bytesToRead;
/*     */     } 
/*     */     
/* 338 */     if (bytesRead > 0) {
/* 339 */       if (this.isReadLimitSet && this.leftOverReadLimit > 0) {
/* 340 */         this.leftOverReadLimit -= bytesRead;
/* 341 */         if (this.leftOverReadLimit < 0)
/* 342 */           clearCurrentMark(); 
/*     */       } 
/* 344 */       return bytesRead;
/*     */     } 
/*     */     
/* 347 */     if (-1 == this.currentChunkRemain) {
/* 348 */       return -1;
/*     */     }
/* 350 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mark(int readLimit) {
/* 363 */     if (null != this.tdsReader && readLimit > 0) {
/* 364 */       this.currentMark = this.tdsReader.mark();
/* 365 */       this.markedChunkRemain = this.currentChunkRemain;
/* 366 */       this.leftOverReadLimit = readLimit;
/* 367 */       setReadLimit(readLimit);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 379 */     if (null == this.tdsReader) {
/*     */       return;
/*     */     }
/* 382 */     while (skip(this.tdsReader.getConnection().getTDSPacketSize()) != 0L);
/*     */     
/* 384 */     closeHelper();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() throws IOException {
/* 395 */     resetHelper();
/* 396 */     this.leftOverReadLimit = this.readLimit;
/* 397 */     this.currentChunkRemain = this.markedChunkRemain;
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\PLPInputStream.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */