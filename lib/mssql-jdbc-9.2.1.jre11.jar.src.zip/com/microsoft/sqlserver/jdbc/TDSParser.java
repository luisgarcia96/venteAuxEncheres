/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class TDSParser
/*     */ {
/*  17 */   private static Logger logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.TDS.TOKEN");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void parse(TDSReader tdsReader, String logContext) throws SQLServerException {
/*  26 */     parse(tdsReader, new TDSTokenHandler(logContext));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void parse(TDSReader tdsReader, TDSTokenHandler tdsTokenHandler) throws SQLServerException {
/*  37 */     parse(tdsReader, tdsTokenHandler, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void parse(TDSReader tdsReader, TDSTokenHandler tdsTokenHandler, boolean readOnlyWarningsFlag) throws SQLServerException {
/*  52 */     boolean isLogging = logger.isLoggable(Level.FINEST);
/*     */ 
/*     */     
/*  55 */     boolean parsing = true;
/*     */ 
/*     */     
/*  58 */     boolean isLoginAck = false;
/*  59 */     boolean isFeatureExtAck = false;
/*  60 */     while (parsing) {
/*  61 */       int tdsTokenType = tdsReader.peekTokenType();
/*  62 */       if (isLogging) {
/*  63 */         logger.finest(tdsReader.toString() + ": " + tdsReader.toString() + ": Processing " + tdsTokenHandler.logContext);
/*     */       }
/*     */       
/*  66 */       if (readOnlyWarningsFlag && 171 != tdsTokenType) {
/*  67 */         parsing = false;
/*     */         return;
/*     */       } 
/*  70 */       switch (tdsTokenType) {
/*     */         case 237:
/*  72 */           parsing = tdsTokenHandler.onSSPI(tdsReader);
/*     */           continue;
/*     */         case 173:
/*  75 */           isLoginAck = true;
/*  76 */           parsing = tdsTokenHandler.onLoginAck(tdsReader);
/*     */           continue;
/*     */         case 174:
/*  79 */           isFeatureExtAck = true;
/*  80 */           tdsReader.getConnection().processFeatureExtAck(tdsReader);
/*  81 */           parsing = true;
/*     */           continue;
/*     */         case 227:
/*  84 */           parsing = tdsTokenHandler.onEnvChange(tdsReader);
/*     */           continue;
/*     */         case 121:
/*  87 */           parsing = tdsTokenHandler.onRetStatus(tdsReader);
/*     */           continue;
/*     */         case 172:
/*  90 */           parsing = tdsTokenHandler.onRetValue(tdsReader);
/*     */           continue;
/*     */         case 253:
/*     */         case 254:
/*     */         case 255:
/*  95 */           tdsReader.getCommand().checkForInterrupt();
/*  96 */           parsing = tdsTokenHandler.onDone(tdsReader);
/*     */           continue;
/*     */         
/*     */         case 170:
/* 100 */           parsing = tdsTokenHandler.onError(tdsReader);
/*     */           continue;
/*     */         case 171:
/* 103 */           parsing = tdsTokenHandler.onInfo(tdsReader);
/*     */           continue;
/*     */         case 169:
/* 106 */           parsing = tdsTokenHandler.onOrder(tdsReader);
/*     */           continue;
/*     */         case 129:
/* 109 */           parsing = tdsTokenHandler.onColMetaData(tdsReader);
/*     */           continue;
/*     */         case 209:
/* 112 */           parsing = tdsTokenHandler.onRow(tdsReader);
/*     */           continue;
/*     */         case 210:
/* 115 */           parsing = tdsTokenHandler.onNBCRow(tdsReader);
/*     */           continue;
/*     */         case 165:
/* 118 */           parsing = tdsTokenHandler.onColInfo(tdsReader);
/*     */           continue;
/*     */         case 164:
/* 121 */           parsing = tdsTokenHandler.onTabName(tdsReader);
/*     */           continue;
/*     */         
/*     */         case 238:
/* 125 */           parsing = tdsTokenHandler.onFedAuthInfo(tdsReader);
/*     */           continue;
/*     */         case -1:
/* 128 */           tdsReader.getCommand().onTokenEOF();
/* 129 */           tdsTokenHandler.onEOF(tdsReader);
/* 130 */           parsing = false;
/*     */           continue;
/*     */       } 
/*     */       
/* 134 */       throwUnexpectedTokenException(tdsReader, tdsTokenHandler.logContext);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 140 */     if (isLoginAck && !isFeatureExtAck) {
/* 141 */       tdsReader.tryProcessFeatureExtAck(isFeatureExtAck);
/*     */     }
/*     */   }
/*     */   
/*     */   static void throwUnexpectedTokenException(TDSReader tdsReader, String logContext) throws SQLServerException {
/* 146 */     if (logger.isLoggable(Level.SEVERE)) {
/* 147 */       logger.severe(tdsReader.toString() + ": " + tdsReader.toString() + ": Encountered unexpected " + logContext);
/*     */     }
/* 149 */     tdsReader.throwInvalidTDSToken(TDS.getTokenName(tdsReader.peekTokenType()));
/*     */   }
/*     */ 
/*     */   
/*     */   static void ignoreLengthPrefixedToken(TDSReader tdsReader) throws SQLServerException {
/* 154 */     tdsReader.readUnsignedByte();
/* 155 */     int envValueLength = tdsReader.readUnsignedShort();
/* 156 */     byte[] envValueData = new byte[envValueLength];
/* 157 */     tdsReader.readBytes(envValueData, 0, envValueLength);
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\TDSParser.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */