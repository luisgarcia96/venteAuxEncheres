/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.math.BigInteger;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.security.GeneralSecurityException;
/*     */ import java.security.KeyFactory;
/*     */ import java.security.KeyPair;
/*     */ import java.security.KeyPairGenerator;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.interfaces.ECPrivateKey;
/*     */ import java.security.interfaces.ECPublicKey;
/*     */ import java.security.spec.ECGenParameterSpec;
/*     */ import java.security.spec.ECPoint;
/*     */ import java.security.spec.ECPublicKeySpec;
/*     */ import java.util.Arrays;
/*     */ import javax.crypto.KeyAgreement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class BaseAttestationRequest
/*     */ {
/* 248 */   protected static final byte[] ECDH_MAGIC = new byte[] { 69, 67, 75, 51, 48, 0, 0, 0 };
/*     */   
/*     */   protected static final int ENCLAVE_LENGTH = 104;
/*     */   protected static final int BIG_INTEGER_SIZE = 48;
/*     */   protected PrivateKey privateKey;
/*     */   protected byte[] enclaveChallenge;
/*     */   protected byte[] x;
/*     */   protected byte[] y;
/*     */   
/*     */   byte[] getBytes() throws IOException {
/* 258 */     return null;
/*     */   }
/*     */   
/*     */   byte[] createSessionSecret(byte[] serverResponse) throws GeneralSecurityException, SQLServerException {
/* 262 */     if (serverResponse == null || serverResponse.length != 104) {
/* 263 */       SQLServerException.makeFromDriverError(null, this, 
/* 264 */           SQLServerResource.getResource("R_MalformedECDHPublicKey"), "0", false);
/*     */     }
/* 266 */     ByteBuffer sr = ByteBuffer.wrap(serverResponse);
/* 267 */     byte[] magic = new byte[8];
/* 268 */     sr.get(magic);
/* 269 */     if (!Arrays.equals(magic, ECDH_MAGIC)) {
/* 270 */       SQLServerException.makeFromDriverError(null, this, SQLServerResource.getResource("R_MalformedECDHHeader"), "0", false);
/*     */     }
/*     */     
/* 273 */     byte[] x = new byte[48];
/* 274 */     byte[] y = new byte[48];
/* 275 */     sr.get(x);
/* 276 */     sr.get(y);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 282 */     ECPublicKeySpec keySpec = new ECPublicKeySpec(new ECPoint(new BigInteger(1, x), new BigInteger(1, y)), ((ECPrivateKey)this.privateKey).getParams());
/* 283 */     KeyAgreement ka = KeyAgreement.getInstance("ECDH");
/* 284 */     ka.init(this.privateKey);
/*     */     
/* 286 */     ka.doPhase(KeyFactory.getInstance("EC").generatePublic(keySpec), true);
/*     */     
/* 288 */     return MessageDigest.getInstance("SHA-256").digest(ka.generateSecret());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void initBcryptECDH() throws SQLServerException {
/*     */     try {
/* 296 */       KeyPairGenerator kpg = KeyPairGenerator.getInstance("EC");
/* 297 */       kpg.initialize(new ECGenParameterSpec("secp384r1"));
/* 298 */       KeyPair kp = kpg.generateKeyPair();
/* 299 */       ECPublicKey publicKey = (ECPublicKey)kp.getPublic();
/* 300 */       this.privateKey = kp.getPrivate();
/* 301 */       ECPoint w = publicKey.getW();
/* 302 */       this.x = adjustBigInt(w.getAffineX().toByteArray());
/* 303 */       this.y = adjustBigInt(w.getAffineY().toByteArray());
/* 304 */     } catch (GeneralSecurityException|IOException e) {
/* 305 */       SQLServerException.makeFromDriverError(null, this, e.getLocalizedMessage(), "0", false);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] adjustBigInt(byte[] b) throws IOException {
/* 313 */     if (0 == b[0] && 48 < b.length) {
/* 314 */       b = Arrays.copyOfRange(b, 1, b.length);
/*     */     }
/*     */     
/* 317 */     if (b.length < 48) {
/* 318 */       ByteArrayOutputStream output = new ByteArrayOutputStream();
/* 319 */       for (int i = 0; i < 48 - b.length; i++) {
/* 320 */         output.write(0);
/*     */       }
/* 322 */       output.write(b);
/* 323 */       b = output.toByteArray();
/*     */     } 
/* 325 */     return b;
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\BaseAttestationRequest.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */