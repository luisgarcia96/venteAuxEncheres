/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ enum StreamType
/*     */ {
/* 302 */   NONE(JDBCType.UNKNOWN, "None"),
/* 303 */   ASCII(JDBCType.LONGVARCHAR, "AsciiStream"),
/* 304 */   BINARY(JDBCType.LONGVARBINARY, "BinaryStream"),
/* 305 */   CHARACTER(JDBCType.LONGVARCHAR, "CharacterStream"),
/* 306 */   NCHARACTER(JDBCType.LONGNVARCHAR, "NCharacterStream"),
/* 307 */   SQLXML(JDBCType.SQLXML, "SQLXML");
/*     */   
/*     */   private final JDBCType jdbcType;
/*     */   private final String name;
/*     */   
/*     */   JDBCType getJDBCType() {
/* 313 */     return this.jdbcType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   StreamType(JDBCType jdbcType, String name) {
/* 320 */     this.jdbcType = jdbcType;
/* 321 */     this.name = name;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 325 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean convertsFrom(TypeInfo typeInfo) {
/* 330 */     if (ASCII == this) {
/*     */       
/* 332 */       if (SSType.XML == typeInfo.getSSType()) {
/* 333 */         return false;
/*     */       }
/*     */       
/* 336 */       if (null != typeInfo.getSQLCollation() && !typeInfo.getSQLCollation().supportsAsciiConversion()) {
/* 337 */         return false;
/*     */       }
/*     */     } 
/* 340 */     return typeInfo.getSSType().convertsTo(this.jdbcType);
/*     */   }
/*     */ 
/*     */   
/*     */   boolean convertsTo(TypeInfo typeInfo) {
/* 345 */     if (ASCII == this) {
/*     */       
/* 347 */       if (SSType.XML == typeInfo.getSSType()) {
/* 348 */         return false;
/*     */       }
/*     */       
/* 351 */       if (null != typeInfo.getSQLCollation() && !typeInfo.getSQLCollation().supportsAsciiConversion()) {
/* 352 */         return false;
/*     */       }
/*     */     } 
/* 355 */     return this.jdbcType.convertsTo(typeInfo.getSSType());
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\StreamType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */