/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.sql.BatchUpdateException;
/*      */ import java.sql.Connection;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLTimeoutException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.Vector;
/*      */ import java.util.concurrent.atomic.AtomicInteger;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class SQLServerStatement
/*      */   implements ISQLServerStatement
/*      */ {
/*      */   private static final long serialVersionUID = -4421134713913331507L;
/*      */   static final char LEFT_CURLY_BRACKET = '{';
/*      */   static final char RIGHT_CURLY_BRACKET = '}';
/*      */   private boolean isResponseBufferingAdaptive = false;
/*      */   
/*      */   final boolean getIsResponseBufferingAdaptive() {
/*   63 */     return this.isResponseBufferingAdaptive;
/*      */   }
/*      */   private boolean wasResponseBufferingSet = false;
/*      */   static final String identityQuery = " select SCOPE_IDENTITY() AS GENERATED_KEYS";
/*      */   
/*      */   final boolean wasResponseBufferingSet() {
/*   69 */     return this.wasResponseBufferingSet;
/*      */   }
/*      */ 
/*      */   
/*      */   String procedureName;
/*      */   
/*      */   private int serverCursorId;
/*      */   
/*      */   private int serverCursorRowCount;
/*      */   boolean stmtPoolable;
/*      */   
/*      */   final int getServerCursorId() {
/*   81 */     return this.serverCursorId;
/*      */   }
/*      */   private TDSReader tdsReader; Parameter[] inOutParam; final SQLServerConnection connection; int queryTimeout;
/*      */   int cancelQueryTimeoutSeconds;
/*      */   
/*      */   final int getServerCursorRowCount() {
/*   87 */     return this.serverCursorRowCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final TDSReader resultsReader() {
/*   97 */     return this.tdsReader;
/*      */   }
/*      */   
/*      */   final boolean wasExecuted() {
/*  101 */     return (null != this.tdsReader);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isCloseOnCompletion = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  137 */   private volatile TDSCommand currentCommand = null;
/*  138 */   private TDSCommand lastStmtExecCmd = null;
/*      */   
/*      */   final void discardLastExecutionResults() {
/*  141 */     if (null != this.lastStmtExecCmd && !this.bIsClosed) {
/*  142 */       this.lastStmtExecCmd.close();
/*  143 */       this.lastStmtExecCmd = null;
/*      */     } 
/*  145 */     clearLastResult();
/*      */   }
/*      */ 
/*      */   
/*  149 */   static final Logger loggerExternal = Logger.getLogger("com.microsoft.sqlserver.jdbc.Statement");
/*      */   private final String loggingClassName;
/*      */   private final String traceID;
/*      */   
/*      */   String getClassNameLogging() {
/*  154 */     return this.loggingClassName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  162 */   protected SQLServerStatementColumnEncryptionSetting stmtColumnEncriptionSetting = SQLServerStatementColumnEncryptionSetting.UseConnectionSetting; private ExecuteProperties execProps;
/*      */   
/*      */   protected SQLServerStatementColumnEncryptionSetting getStmtColumnEncriptionSetting() {
/*  165 */     return this.stmtColumnEncriptionSetting;
/*      */   }
/*      */   
/*      */   final class ExecuteProperties
/*      */   {
/*      */     private final boolean wasResponseBufferingSet;
/*      */     private final boolean isResponseBufferingAdaptive;
/*      */     private final int holdability;
/*      */     
/*      */     final boolean wasResponseBufferingSet() {
/*  175 */       return this.wasResponseBufferingSet;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     final boolean isResponseBufferingAdaptive() {
/*  181 */       return this.isResponseBufferingAdaptive;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     final int getHoldability() {
/*  187 */       return this.holdability;
/*      */     }
/*      */     
/*      */     ExecuteProperties(SQLServerStatement stmt) {
/*  191 */       this.wasResponseBufferingSet = stmt.wasResponseBufferingSet();
/*  192 */       this.isResponseBufferingAdaptive = stmt.getIsResponseBufferingAdaptive();
/*  193 */       this.holdability = stmt.connection.getHoldabilityInternal();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   final ExecuteProperties getExecProps() {
/*  200 */     return this.execProps;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void executeStatement(TDSCommand newStmtCmd) throws SQLServerException, SQLTimeoutException {
/*  213 */     discardLastExecutionResults();
/*      */ 
/*      */     
/*  216 */     checkClosed();
/*      */     
/*  218 */     this.execProps = new ExecuteProperties(this);
/*      */ 
/*      */     
/*      */     try {
/*  222 */       executeCommand(newStmtCmd);
/*  223 */     } catch (SQLServerException e) {
/*  224 */       if (e.getDriverErrorCode() == 9) {
/*  225 */         throw new SQLTimeoutException(e.getMessage(), e.getSQLState(), e.getErrorCode(), e.getCause());
/*      */       }
/*  227 */       throw e;
/*      */     } finally {
/*  229 */       this.lastStmtExecCmd = newStmtCmd;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void executeCommand(TDSCommand newCommand) throws SQLServerException {
/*  246 */     this.currentCommand = newCommand;
/*  247 */     this.connection.executeCommand(newCommand);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean moreResults = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   SQLServerResultSet resultSet;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  264 */   int resultSetCount = 0;
/*      */   static final int EXECUTE_NOT_SET = 0;
/*      */   static final int EXECUTE_QUERY = 1;
/*      */   static final int EXECUTE_UPDATE = 2;
/*      */   
/*      */   synchronized void incrResultSetCount() {
/*  270 */     this.resultSetCount++;
/*      */   }
/*      */   static final int EXECUTE = 3;
/*      */   static final int EXECUTE_BATCH = 4;
/*      */   static final int EXECUTE_QUERY_INTERNAL = 5;
/*      */   
/*      */   synchronized void decrResultSetCount() {
/*  277 */     this.resultSetCount--;
/*  278 */     assert this.resultSetCount >= 0;
/*      */ 
/*      */     
/*  281 */     if (this.isCloseOnCompletion && (4 != this.executeMethod || !this.moreResults) && this.resultSetCount == 0) {
/*  282 */       closeInternal();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  296 */   int executeMethod = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  301 */   long updateCount = -1L;
/*      */ 
/*      */ 
/*      */   
/*      */   boolean escapeProcessing;
/*      */ 
/*      */ 
/*      */   
/*  309 */   int maxRows = 0;
/*      */ 
/*      */   
/*  312 */   int maxFieldSize = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int resultSetConcurrency;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int appResultSetType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int resultSetType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final int getSQLResultSetType() {
/*  345 */     return this.resultSetType;
/*      */   }
/*      */   
/*      */   final int getCursorType() {
/*  349 */     return getResultSetScrollOpt() & 0xFFFFEFFF;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final boolean isCursorable(int executeMethod) {
/*  365 */     return (this.resultSetType != 2003 && (3 == executeMethod || 1 == executeMethod));
/*      */   }
/*      */ 
/*      */   
/*      */   boolean executedSqlDirectly = false;
/*      */   
/*      */   boolean expectCursorOutParams;
/*      */   
/*      */   String cursorName;
/*      */   
/*      */   int nFetchSize;
/*      */   
/*      */   int defaultFetchSize;
/*      */   
/*      */   int nFetchDirection;
/*      */   
/*      */   boolean bIsClosed;
/*      */   
/*      */   boolean bRequestedGeneratedKeys;
/*      */   
/*      */   private ResultSet autoGeneratedKeys;
/*      */   
/*      */   class StmtExecOutParamHandler
/*      */     extends TDSTokenHandler
/*      */   {
/*      */     StmtExecOutParamHandler() {
/*  391 */       super("StmtExecOutParamHandler");
/*      */     }
/*      */     
/*      */     boolean onRetStatus(TDSReader tdsReader) throws SQLServerException {
/*  395 */       (new StreamRetStatus()).setFromTDS(tdsReader);
/*  396 */       return true;
/*      */     }
/*      */     
/*      */     boolean onRetValue(TDSReader tdsReader) throws SQLServerException {
/*  400 */       if (SQLServerStatement.this.expectCursorOutParams) {
/*      */         
/*  402 */         Parameter param = new Parameter(Util.shouldHonorAEForParameters(SQLServerStatement.this.stmtColumnEncriptionSetting, SQLServerStatement.this.connection));
/*      */ 
/*      */         
/*  405 */         param.skipRetValStatus(tdsReader);
/*  406 */         SQLServerStatement.this.serverCursorId = param.getInt(tdsReader);
/*  407 */         param.skipValue(tdsReader, true);
/*      */         
/*  409 */         param = new Parameter(Util.shouldHonorAEForParameters(SQLServerStatement.this.stmtColumnEncriptionSetting, SQLServerStatement.this.connection));
/*      */         
/*  411 */         param.skipRetValStatus(tdsReader);
/*  412 */         if (-1 == (SQLServerStatement.this.serverCursorRowCount = param.getInt(tdsReader)))
/*  413 */           SQLServerStatement.this.serverCursorRowCount = -3; 
/*  414 */         param.skipValue(tdsReader, true);
/*      */ 
/*      */         
/*  417 */         SQLServerStatement.this.expectCursorOutParams = false;
/*  418 */         return true;
/*      */       } 
/*      */       
/*  421 */       return false;
/*      */     }
/*      */     
/*      */     boolean onDone(TDSReader tdsReader) throws SQLServerException {
/*  425 */       return false;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  465 */   private final ArrayList<String> batchStatementBuffer = new ArrayList<>();
/*      */ 
/*      */ 
/*      */   
/*  469 */   private static final Logger stmtlogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerStatement");
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  474 */     return this.traceID;
/*      */   }
/*      */ 
/*      */   
/*      */   String getClassNameInternal() {
/*  479 */     return "SQLServerStatement";
/*      */   }
/*      */ 
/*      */   
/*  483 */   private static final AtomicInteger lastStatementID = new AtomicInteger(0); Vector<SQLWarning> sqlWarnings; boolean isInternalEncryptionQuery;
/*      */   
/*      */   private static int nextStatementID() {
/*  486 */     return lastStatementID.incrementAndGet();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   SQLServerStatement(SQLServerConnection con, int nType, int nConcur, SQLServerStatementColumnEncryptionSetting stmtColEncSetting) throws SQLServerException {
/*  510 */     int statementID = nextStatementID();
/*  511 */     String classN = getClassNameInternal();
/*  512 */     this.traceID = classN + ":" + classN;
/*  513 */     this.loggingClassName = "com.microsoft.sqlserver.jdbc." + classN + ":" + statementID;
/*      */     
/*  515 */     this.stmtPoolable = false;
/*  516 */     this.connection = con;
/*  517 */     this.bIsClosed = false;
/*      */ 
/*      */     
/*  520 */     if (1003 != nType && 1005 != nType && 1004 != nType && 2003 != nType && 2004 != nType && 1006 != nType && 1005 != nType && 1004 != nType)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  526 */       SQLServerException.makeFromDriverError(this.connection, this, 
/*  527 */           SQLServerException.getErrString("R_unsupportedCursor"), (String)null, true);
/*      */     }
/*      */ 
/*      */     
/*  531 */     if (1007 != nConcur && 1008 != nConcur && 1009 != nConcur && 1008 != nConcur && 1010 != nConcur)
/*      */     {
/*      */ 
/*      */       
/*  535 */       SQLServerException.makeFromDriverError(this.connection, this, 
/*  536 */           SQLServerException.getErrString("R_unsupportedConcurrency"), (String)null, true);
/*      */     }
/*      */     
/*  539 */     if (null == stmtColEncSetting) {
/*  540 */       SQLServerException.makeFromDriverError(this.connection, this, 
/*  541 */           SQLServerException.getErrString("R_unsupportedStmtColEncSetting"), (String)null, true);
/*      */     }
/*      */     
/*  544 */     this.stmtColumnEncriptionSetting = stmtColEncSetting;
/*      */     
/*  546 */     this.resultSetConcurrency = nConcur;
/*      */ 
/*      */ 
/*      */     
/*  550 */     this.appResultSetType = nType;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  555 */     if (1003 == nType) {
/*  556 */       if (1007 == nConcur) {
/*      */ 
/*      */         
/*  559 */         String selectMethod = con.getSelectMethod();
/*  560 */         this
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  566 */           .resultSetType = (null == selectMethod || !"cursor".equals(selectMethod)) ? 2003 : 2004;
/*      */       } else {
/*  568 */         this.resultSetType = 2004;
/*      */       } 
/*  570 */     } else if (1004 == nType) {
/*  571 */       this.resultSetType = 1004;
/*  572 */     } else if (1005 == nType) {
/*  573 */       this.resultSetType = 1005;
/*      */     } else {
/*      */       
/*  576 */       this.resultSetType = nType;
/*      */     } 
/*      */ 
/*      */     
/*  580 */     this
/*      */       
/*  582 */       .nFetchDirection = (2003 == this.resultSetType || 2004 == this.resultSetType) ? 1000 : 1002;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  589 */     this.nFetchSize = (1009 == this.resultSetConcurrency) ? 8 : 128;
/*      */ 
/*      */     
/*  592 */     this.defaultFetchSize = this.nFetchSize;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  599 */     if (1007 != nConcur && (2003 == this.resultSetType || 1004 == this.resultSetType))
/*      */     {
/*  601 */       SQLServerException.makeFromDriverError(this.connection, this, 
/*  602 */           SQLServerException.getErrString("R_unsupportedCursorAndConcurrency"), (String)null, true);
/*      */     }
/*      */ 
/*      */     
/*  606 */     setResponseBuffering(this.connection.getResponseBuffering());
/*      */     
/*  608 */     setDefaultQueryTimeout();
/*  609 */     setDefaultQueryCancelTimeout();
/*      */     
/*  611 */     if (stmtlogger.isLoggable(Level.FINER)) {
/*  612 */       stmtlogger.finer("Properties for " + toString() + ": Result type:" + this.appResultSetType + " (" + this.resultSetType + ") Concurrency:" + this.resultSetConcurrency + " Fetchsize:" + this.nFetchSize + " bIsClosed:" + this.bIsClosed + " useLastUpdateCount:" + this.connection
/*      */           
/*  614 */           .useLastUpdateCount());
/*      */     }
/*      */     
/*  617 */     if (stmtlogger.isLoggable(Level.FINE)) {
/*  618 */       stmtlogger.fine(toString() + " created by (" + toString() + ")");
/*      */     }
/*      */   }
/*      */   
/*      */   private void setDefaultQueryCancelTimeout() {
/*  623 */     int cancelQueryTimeoutSeconds = this.connection.getCancelQueryTimeoutSeconds();
/*  624 */     if (cancelQueryTimeoutSeconds > 0) {
/*  625 */       this.cancelQueryTimeoutSeconds = cancelQueryTimeoutSeconds;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private void setDefaultQueryTimeout() {
/*  631 */     int queryTimeoutSeconds = this.connection.getQueryTimeoutSeconds();
/*  632 */     if (queryTimeoutSeconds > 0) {
/*  633 */       this.queryTimeout = queryTimeoutSeconds;
/*      */     }
/*      */   }
/*      */   
/*      */   final Logger getStatementLogger() {
/*  638 */     return stmtlogger;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void closeInternal() {
/*  652 */     assert !this.bIsClosed;
/*  653 */     discardLastExecutionResults();
/*      */     
/*  655 */     this.bIsClosed = true;
/*  656 */     this.autoGeneratedKeys = null;
/*  657 */     this.sqlWarnings = null;
/*  658 */     this.inOutParam = null;
/*      */     
/*  660 */     this.connection.removeOpenStatement(this);
/*      */   }
/*      */ 
/*      */   
/*      */   public void close() throws SQLServerException {
/*  665 */     loggerExternal.entering(getClassNameLogging(), "close");
/*      */     
/*  667 */     if (!this.bIsClosed) {
/*  668 */       closeInternal();
/*      */     }
/*  670 */     loggerExternal.exiting(getClassNameLogging(), "close");
/*      */   }
/*      */ 
/*      */   
/*      */   public void closeOnCompletion() throws SQLException {
/*  675 */     loggerExternal.entering(getClassNameLogging(), "closeOnCompletion");
/*      */     
/*  677 */     checkClosed();
/*      */ 
/*      */     
/*  680 */     this.isCloseOnCompletion = true;
/*      */     
/*  682 */     loggerExternal.exiting(getClassNameLogging(), "closeOnCompletion");
/*      */   }
/*      */ 
/*      */   
/*      */   public ResultSet executeQuery(String sql) throws SQLServerException, SQLTimeoutException {
/*  687 */     loggerExternal.entering(getClassNameLogging(), "executeQuery", sql);
/*  688 */     if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) {
/*  689 */       loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */     }
/*  691 */     checkClosed();
/*  692 */     executeStatement(new StmtExecCmd(this, sql, 1, 2));
/*  693 */     loggerExternal.exiting(getClassNameLogging(), "executeQuery", this.resultSet);
/*  694 */     return this.resultSet;
/*      */   }
/*      */   
/*      */   final SQLServerResultSet executeQueryInternal(String sql) throws SQLServerException, SQLTimeoutException {
/*  698 */     checkClosed();
/*  699 */     executeStatement(new StmtExecCmd(this, sql, 5, 2));
/*  700 */     return this.resultSet;
/*      */   }
/*      */ 
/*      */   
/*      */   public int executeUpdate(String sql) throws SQLServerException, SQLTimeoutException {
/*  705 */     loggerExternal.entering(getClassNameLogging(), "executeUpdate", sql);
/*  706 */     if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) {
/*  707 */       loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */     }
/*  709 */     checkClosed();
/*  710 */     executeStatement(new StmtExecCmd(this, sql, 2, 2));
/*      */ 
/*      */     
/*  713 */     if (this.updateCount < -2147483648L || this.updateCount > 2147483647L) {
/*  714 */       SQLServerException.makeFromDriverError(this.connection, this, 
/*  715 */           SQLServerException.getErrString("R_updateCountOutofRange"), (String)null, true);
/*      */     }
/*  717 */     loggerExternal.exiting(getClassNameLogging(), "executeUpdate", Long.valueOf(this.updateCount));
/*      */     
/*  719 */     return (int)this.updateCount;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public long executeLargeUpdate(String sql) throws SQLServerException, SQLTimeoutException {
/*  725 */     loggerExternal.entering(getClassNameLogging(), "executeLargeUpdate", sql);
/*  726 */     if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) {
/*  727 */       loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */     }
/*  729 */     checkClosed();
/*  730 */     executeStatement(new StmtExecCmd(this, sql, 2, 2));
/*      */     
/*  732 */     loggerExternal.exiting(getClassNameLogging(), "executeLargeUpdate", Long.valueOf(this.updateCount));
/*  733 */     return this.updateCount;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean execute(String sql) throws SQLServerException, SQLTimeoutException {
/*  738 */     loggerExternal.entering(getClassNameLogging(), "execute", sql);
/*  739 */     if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) {
/*  740 */       loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */     }
/*  742 */     checkClosed();
/*  743 */     executeStatement(new StmtExecCmd(this, sql, 3, 2));
/*  744 */     loggerExternal.exiting(getClassNameLogging(), "execute", Boolean.valueOf((null != this.resultSet)));
/*  745 */     return (null != this.resultSet);
/*      */   }
/*      */ 
/*      */   
/*      */   private final class StmtExecCmd
/*      */     extends TDSCommand
/*      */   {
/*      */     private static final long serialVersionUID = 4534132352812876292L;
/*      */     final SQLServerStatement stmt;
/*      */     final String sql;
/*      */     final int executeMethod;
/*      */     final int autoGeneratedKeys;
/*      */     
/*      */     StmtExecCmd(SQLServerStatement stmt, String sql, int executeMethod, int autoGeneratedKeys) {
/*  759 */       super(stmt.toString() + " executeXXX", stmt.queryTimeout, stmt.cancelQueryTimeoutSeconds);
/*  760 */       this.stmt = stmt;
/*  761 */       this.sql = sql;
/*  762 */       this.executeMethod = executeMethod;
/*  763 */       this.autoGeneratedKeys = autoGeneratedKeys;
/*      */     }
/*      */     
/*      */     final boolean doExecute() throws SQLServerException {
/*  767 */       this.stmt.doExecuteStatement(this);
/*  768 */       return false;
/*      */     }
/*      */     
/*      */     final void processResponse(TDSReader tdsReader) throws SQLServerException {
/*  772 */       SQLServerStatement.this.ensureExecuteResultsReader(tdsReader);
/*  773 */       SQLServerStatement.this.processExecuteResults();
/*      */     }
/*      */   }
/*      */   
/*      */   private String ensureSQLSyntax(String sql) throws SQLServerException {
/*  778 */     if (sql.indexOf('{') >= 0) {
/*      */       
/*  780 */       SQLServerConnection.CityHash128Key cacheKey = new SQLServerConnection.CityHash128Key(sql);
/*      */ 
/*      */       
/*  783 */       ParsedSQLCacheItem cacheItem = SQLServerConnection.getCachedParsedSQL(cacheKey);
/*  784 */       if (null == cacheItem) {
/*  785 */         cacheItem = SQLServerConnection.parseAndCacheSQL(cacheKey, sql);
/*      */       }
/*      */       
/*  788 */       this.procedureName = cacheItem.procedureName;
/*  789 */       return cacheItem.processedSQL;
/*      */     } 
/*      */     
/*  792 */     return sql;
/*      */   }
/*      */   
/*      */   void startResults() {
/*  796 */     this.moreResults = true;
/*      */   }
/*      */   
/*      */   final void setMaxRowsAndMaxFieldSize() throws SQLServerException {
/*  800 */     if (1 == this.executeMethod || 3 == this.executeMethod) {
/*  801 */       this.connection.setMaxRows(this.maxRows);
/*  802 */       this.connection.setMaxFieldSize(this.maxFieldSize);
/*      */     } else {
/*  804 */       assert 2 == this.executeMethod || 4 == this.executeMethod || 5 == this.executeMethod;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  809 */       this.connection.setMaxRows(0);
/*      */     } 
/*      */   }
/*      */   
/*      */   final void doExecuteStatement(StmtExecCmd execCmd) throws SQLServerException {
/*  814 */     resetForReexecute();
/*      */ 
/*      */     
/*  817 */     this.executeMethod = execCmd.executeMethod;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  822 */     String sql = ensureSQLSyntax(execCmd.sql);
/*  823 */     if (!this.isInternalEncryptionQuery && this.connection.isAEv2()) {
/*  824 */       execCmd.enclaveCEKs = this.connection.initEnclaveParameters(sql, null, null, null);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  837 */     setMaxRowsAndMaxFieldSize();
/*      */     
/*  839 */     if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) {
/*  840 */       loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */     }
/*  842 */     if (isCursorable(this.executeMethod) && isSelect(sql)) {
/*  843 */       if (stmtlogger.isLoggable(Level.FINE)) {
/*  844 */         stmtlogger.fine(toString() + " Executing server side cursor " + toString());
/*      */       }
/*  846 */       doExecuteCursored(execCmd, sql);
/*      */     } else {
/*      */       
/*  849 */       this.executedSqlDirectly = true;
/*  850 */       this.expectCursorOutParams = false;
/*      */       
/*  852 */       TDSWriter tdsWriter = execCmd.startRequest((byte)1);
/*      */       
/*  854 */       tdsWriter.sendEnclavePackage(sql, execCmd.enclaveCEKs);
/*      */       
/*  856 */       tdsWriter.writeString(sql);
/*      */ 
/*      */ 
/*      */       
/*  860 */       if (1 == execCmd.autoGeneratedKeys && (2 == this.executeMethod || 3 == this.executeMethod) && sql
/*      */         
/*  862 */         .trim().toUpperCase().startsWith("INSERT")) {
/*  863 */         tdsWriter.writeString(" select SCOPE_IDENTITY() AS GENERATED_KEYS");
/*      */       }
/*      */       
/*  866 */       if (stmtlogger.isLoggable(Level.FINE)) {
/*  867 */         stmtlogger.fine(toString() + " Executing (not server cursor) " + toString());
/*      */       }
/*      */       
/*  870 */       ensureExecuteResultsReader(execCmd.startResponse(this.isResponseBufferingAdaptive));
/*  871 */       startResults();
/*  872 */       getNextResult(true);
/*      */     } 
/*      */ 
/*      */     
/*  876 */     if (null == this.resultSet) {
/*  877 */       if (1 == this.executeMethod) {
/*  878 */         SQLServerException.makeFromDriverError(this.connection, this, 
/*  879 */             SQLServerException.getErrString("R_noResultset"), (String)null, true);
/*      */ 
/*      */       
/*      */       }
/*      */     
/*      */     }
/*  885 */     else if (2 == this.executeMethod || 4 == this.executeMethod) {
/*  886 */       SQLServerException.makeFromDriverError(this.connection, this, 
/*  887 */           SQLServerException.getErrString("R_resultsetGeneratedForUpdate"), (String)null, false);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private final class StmtBatchExecCmd
/*      */     extends TDSCommand
/*      */   {
/*      */     private static final long serialVersionUID = -4621631860790243331L;
/*      */     
/*      */     final SQLServerStatement stmt;
/*      */     
/*      */     StmtBatchExecCmd(SQLServerStatement stmt) {
/*  900 */       super(stmt.toString() + " executeBatch", stmt.queryTimeout, stmt.cancelQueryTimeoutSeconds);
/*  901 */       this.stmt = stmt;
/*      */     }
/*      */     
/*      */     final boolean doExecute() throws SQLServerException {
/*  905 */       this.stmt.doExecuteStatementBatch(this);
/*  906 */       return false;
/*      */     }
/*      */     
/*      */     final void processResponse(TDSReader tdsReader) throws SQLServerException {
/*  910 */       SQLServerStatement.this.ensureExecuteResultsReader(tdsReader);
/*  911 */       SQLServerStatement.this.processExecuteResults();
/*      */     }
/*      */   }
/*      */   
/*      */   private void doExecuteStatementBatch(StmtBatchExecCmd execCmd) throws SQLServerException {
/*  916 */     resetForReexecute();
/*      */ 
/*      */     
/*  919 */     this.connection.setMaxRows(0);
/*      */     
/*  921 */     String batchStatementString = String.join(";", (Iterable)this.batchStatementBuffer);
/*  922 */     if (this.connection.isAEv2()) {
/*  923 */       execCmd.enclaveCEKs = this.connection.initEnclaveParameters(batchStatementString, null, null, null);
/*      */     }
/*      */     
/*  926 */     if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) {
/*  927 */       loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */     }
/*      */ 
/*      */     
/*  931 */     this.executeMethod = 4;
/*  932 */     this.executedSqlDirectly = true;
/*  933 */     this.expectCursorOutParams = false;
/*      */     
/*  935 */     TDSWriter tdsWriter = execCmd.startRequest((byte)1);
/*      */ 
/*      */     
/*  938 */     tdsWriter.sendEnclavePackage(batchStatementString, execCmd.enclaveCEKs);
/*  939 */     tdsWriter.writeString(batchStatementString);
/*      */ 
/*      */     
/*  942 */     ensureExecuteResultsReader(execCmd.startResponse(this.isResponseBufferingAdaptive));
/*  943 */     startResults();
/*  944 */     getNextResult(true);
/*      */ 
/*      */     
/*  947 */     if (null != this.resultSet) {
/*  948 */       SQLServerException.makeFromDriverError(this.connection, this, 
/*  949 */           SQLServerException.getErrString("R_resultsetGeneratedForUpdate"), (String)null, false);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void resetForReexecute() throws SQLServerException {
/*  957 */     ensureExecuteResultsReader(null);
/*  958 */     this.autoGeneratedKeys = null;
/*  959 */     this.updateCount = -1L;
/*  960 */     this.sqlWarnings = null;
/*  961 */     this.executedSqlDirectly = false;
/*  962 */     startResults();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final boolean isSelect(String sql) throws SQLServerException {
/*  973 */     checkClosed();
/*      */ 
/*      */     
/*  976 */     String temp = sql.trim();
/*  977 */     if (null == sql || sql.length() < 6) {
/*  978 */       return false;
/*      */     }
/*  980 */     return "select".equalsIgnoreCase(temp.substring(0, 6));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final boolean isInsert(String sql) throws SQLServerException {
/*  991 */     checkClosed();
/*      */ 
/*      */     
/*  994 */     String temp = sql.trim();
/*  995 */     if (null == sql || sql.length() < 6) {
/*  996 */       return false;
/*      */     }
/*  998 */     if ("/*".equalsIgnoreCase(temp.substring(0, 2))) {
/*  999 */       int index = temp.indexOf("*/") + 2;
/* 1000 */       return isInsert(temp.substring(index));
/*      */     } 
/* 1002 */     return "insert".equalsIgnoreCase(temp.substring(0, 6));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static String replaceParameterWithString(String str, char marker, String replaceStr) {
/* 1017 */     int index = 0;
/* 1018 */     while ((index = str.indexOf("" + marker)) >= 0) {
/* 1019 */       str = str.substring(0, index) + str.substring(0, index) + replaceStr;
/*      */     }
/* 1021 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static String replaceMarkerWithNull(String sql) {
/* 1032 */     if (!sql.contains("'")) {
/* 1033 */       return replaceParameterWithString(sql, '?', "null");
/*      */     }
/* 1035 */     StringTokenizer st = new StringTokenizer(sql, "'", true);
/* 1036 */     boolean beforeColon = true;
/* 1037 */     StringBuilder retSql = new StringBuilder();
/* 1038 */     while (st.hasMoreTokens()) {
/* 1039 */       String str = st.nextToken();
/* 1040 */       if ("'".equals(str)) {
/* 1041 */         retSql.append("'");
/* 1042 */         beforeColon = !beforeColon;
/*      */         continue;
/*      */       } 
/* 1045 */       if (beforeColon) {
/* 1046 */         String repStr = replaceParameterWithString(str, '?', "null");
/* 1047 */         retSql.append(repStr);
/*      */         continue;
/*      */       } 
/* 1050 */       retSql.append(str);
/*      */     } 
/*      */ 
/*      */     
/* 1054 */     return retSql.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void checkClosed() throws SQLServerException {
/* 1063 */     this.connection.checkClosed();
/* 1064 */     if (this.bIsClosed) {
/* 1065 */       SQLServerException.makeFromDriverError(this.connection, this, 
/* 1066 */           SQLServerException.getErrString("R_statementIsClosed"), (String)null, false);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getMaxFieldSize() throws SQLServerException {
/* 1074 */     loggerExternal.entering(getClassNameLogging(), "getMaxFieldSize");
/* 1075 */     checkClosed();
/* 1076 */     loggerExternal.exiting(getClassNameLogging(), "getMaxFieldSize", Integer.valueOf(this.maxFieldSize));
/* 1077 */     return this.maxFieldSize;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setMaxFieldSize(int max) throws SQLServerException {
/* 1082 */     loggerExternal.entering(getClassNameLogging(), "setMaxFieldSize", Integer.valueOf(max));
/* 1083 */     checkClosed();
/* 1084 */     if (max < 0) {
/* 1085 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidLength"));
/* 1086 */       Object[] msgArgs = { Integer.valueOf(max) };
/* 1087 */       SQLServerException.makeFromDriverError(this.connection, this, form.format(msgArgs), (String)null, true);
/*      */     } 
/* 1089 */     this.maxFieldSize = max;
/* 1090 */     loggerExternal.exiting(getClassNameLogging(), "setMaxFieldSize");
/*      */   }
/*      */ 
/*      */   
/*      */   public final int getMaxRows() throws SQLServerException {
/* 1095 */     loggerExternal.entering(getClassNameLogging(), "getMaxRows");
/* 1096 */     checkClosed();
/* 1097 */     loggerExternal.exiting(getClassNameLogging(), "getMaxRows", Integer.valueOf(this.maxRows));
/* 1098 */     return this.maxRows;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final long getLargeMaxRows() throws SQLServerException {
/* 1104 */     loggerExternal.entering(getClassNameLogging(), "getLargeMaxRows");
/*      */ 
/*      */ 
/*      */     
/* 1108 */     loggerExternal.exiting(getClassNameLogging(), "getLargeMaxRows", Long.valueOf(this.maxRows));
/*      */     
/* 1110 */     return getMaxRows();
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setMaxRows(int max) throws SQLServerException {
/* 1115 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1116 */       loggerExternal.entering(getClassNameLogging(), "setMaxRows", Integer.valueOf(max)); 
/* 1117 */     checkClosed();
/* 1118 */     if (max < 0) {
/* 1119 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidRowcount"));
/* 1120 */       Object[] msgArgs = { Integer.valueOf(max) };
/* 1121 */       SQLServerException.makeFromDriverError(this.connection, this, form.format(msgArgs), (String)null, true);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1127 */     if (1006 != this.resultSetType)
/* 1128 */       this.maxRows = max; 
/* 1129 */     loggerExternal.exiting(getClassNameLogging(), "setMaxRows");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setLargeMaxRows(long max) throws SQLServerException {
/* 1135 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 1136 */       loggerExternal.entering(getClassNameLogging(), "setLargeMaxRows", Long.valueOf(max));
/*      */     }
/*      */ 
/*      */     
/* 1140 */     if (max > 2147483647L) {
/* 1141 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidMaxRows"));
/* 1142 */       Object[] msgArgs = { Long.valueOf(max) };
/* 1143 */       SQLServerException.makeFromDriverError(this.connection, this, form.format(msgArgs), (String)null, true);
/*      */     } 
/* 1145 */     setMaxRows((int)max);
/* 1146 */     loggerExternal.exiting(getClassNameLogging(), "setLargeMaxRows");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setEscapeProcessing(boolean enable) throws SQLServerException {
/* 1151 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1152 */       loggerExternal.entering(getClassNameLogging(), "setEscapeProcessing", Boolean.valueOf(enable)); 
/* 1153 */     checkClosed();
/* 1154 */     this.escapeProcessing = enable;
/* 1155 */     loggerExternal.exiting(getClassNameLogging(), "setEscapeProcessing");
/*      */   }
/*      */ 
/*      */   
/*      */   public final int getQueryTimeout() throws SQLServerException {
/* 1160 */     loggerExternal.entering(getClassNameLogging(), "getQueryTimeout");
/* 1161 */     checkClosed();
/* 1162 */     loggerExternal.exiting(getClassNameLogging(), "getQueryTimeout", Integer.valueOf(this.queryTimeout));
/* 1163 */     return this.queryTimeout;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setQueryTimeout(int seconds) throws SQLServerException {
/* 1168 */     loggerExternal.entering(getClassNameLogging(), "setQueryTimeout", Integer.valueOf(seconds));
/* 1169 */     checkClosed();
/* 1170 */     if (seconds < 0) {
/* 1171 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidQueryTimeOutValue"));
/* 1172 */       Object[] msgArgs = { Integer.valueOf(seconds) };
/* 1173 */       SQLServerException.makeFromDriverError(this.connection, this, form.format(msgArgs), (String)null, true);
/*      */     } 
/* 1175 */     this.queryTimeout = seconds;
/* 1176 */     loggerExternal.exiting(getClassNameLogging(), "setQueryTimeout");
/*      */   }
/*      */ 
/*      */   
/*      */   public final int getCancelQueryTimeout() throws SQLServerException {
/* 1181 */     loggerExternal.entering(getClassNameLogging(), "getCancelQueryTimeout");
/* 1182 */     checkClosed();
/* 1183 */     loggerExternal.exiting(getClassNameLogging(), "getCancelQueryTimeout", Integer.valueOf(this.cancelQueryTimeoutSeconds));
/* 1184 */     return this.cancelQueryTimeoutSeconds;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setCancelQueryTimeout(int seconds) throws SQLServerException {
/* 1189 */     loggerExternal.entering(getClassNameLogging(), "setCancelQueryTimeout", Integer.valueOf(seconds));
/* 1190 */     checkClosed();
/* 1191 */     if (seconds < 0) {
/* 1192 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidCancelQueryTimeout"));
/* 1193 */       Object[] msgArgs = { Integer.valueOf(seconds) };
/* 1194 */       SQLServerException.makeFromDriverError(this.connection, this, form.format(msgArgs), (String)null, true);
/*      */     } 
/* 1196 */     this.cancelQueryTimeoutSeconds = seconds;
/* 1197 */     loggerExternal.exiting(getClassNameLogging(), "setCancelQueryTimeout");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void cancel() throws SQLServerException {
/* 1202 */     loggerExternal.entering(getClassNameLogging(), "cancel");
/* 1203 */     checkClosed();
/*      */ 
/*      */     
/* 1206 */     if (null != this.currentCommand)
/* 1207 */       this.currentCommand.interrupt(SQLServerException.getErrString("R_queryCancelled")); 
/* 1208 */     loggerExternal.exiting(getClassNameLogging(), "cancel");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final SQLWarning getWarnings() throws SQLServerException {
/* 1218 */     loggerExternal.entering(getClassNameLogging(), "getWarnings");
/* 1219 */     checkClosed();
/* 1220 */     if (this.sqlWarnings == null)
/* 1221 */       return null; 
/* 1222 */     SQLWarning warn = this.sqlWarnings.elementAt(0);
/* 1223 */     loggerExternal.exiting(getClassNameLogging(), "getWarnings", warn);
/* 1224 */     return warn;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void clearWarnings() throws SQLServerException {
/* 1229 */     loggerExternal.entering(getClassNameLogging(), "clearWarnings");
/* 1230 */     checkClosed();
/* 1231 */     this.sqlWarnings = null;
/* 1232 */     loggerExternal.exiting(getClassNameLogging(), "clearWarnings");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setCursorName(String name) throws SQLServerException {
/* 1237 */     loggerExternal.entering(getClassNameLogging(), "setCursorName", name);
/* 1238 */     checkClosed();
/* 1239 */     this.cursorName = name;
/* 1240 */     loggerExternal.exiting(getClassNameLogging(), "setCursorName");
/*      */   }
/*      */   
/*      */   final String getCursorName() {
/* 1244 */     return this.cursorName;
/*      */   }
/*      */ 
/*      */   
/*      */   public final ResultSet getResultSet() throws SQLServerException {
/* 1249 */     loggerExternal.entering(getClassNameLogging(), "getResultSet");
/* 1250 */     checkClosed();
/* 1251 */     loggerExternal.exiting(getClassNameLogging(), "getResultSet", this.resultSet);
/* 1252 */     return this.resultSet;
/*      */   }
/*      */ 
/*      */   
/*      */   public final int getUpdateCount() throws SQLServerException {
/* 1257 */     loggerExternal.entering(getClassNameLogging(), "getUpdateCount");
/*      */     
/* 1259 */     checkClosed();
/*      */ 
/*      */     
/* 1262 */     if (this.updateCount < -2147483648L || this.updateCount > 2147483647L) {
/* 1263 */       SQLServerException.makeFromDriverError(this.connection, this, 
/* 1264 */           SQLServerException.getErrString("R_updateCountOutofRange"), (String)null, true);
/*      */     }
/* 1266 */     loggerExternal.exiting(getClassNameLogging(), "getUpdateCount", Long.valueOf(this.updateCount));
/*      */     
/* 1268 */     return (int)this.updateCount;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final long getLargeUpdateCount() throws SQLServerException {
/* 1274 */     loggerExternal.entering(getClassNameLogging(), "getUpdateCount");
/* 1275 */     checkClosed();
/* 1276 */     loggerExternal.exiting(getClassNameLogging(), "getUpdateCount", Long.valueOf(this.updateCount));
/* 1277 */     return this.updateCount;
/*      */   }
/*      */   
/*      */   final void ensureExecuteResultsReader(TDSReader tdsReader) {
/* 1281 */     this.tdsReader = tdsReader;
/*      */   }
/*      */   
/*      */   final void processExecuteResults() throws SQLServerException {
/* 1285 */     if (wasExecuted()) {
/* 1286 */       processBatch();
/* 1287 */       TDSParser.parse(resultsReader(), "batch completion");
/* 1288 */       ensureExecuteResultsReader(null);
/*      */     } 
/*      */   }
/*      */   
/*      */   void processBatch() throws SQLServerException {
/* 1293 */     processResults();
/*      */   }
/*      */   
/*      */   final void processResults() throws SQLServerException {
/* 1297 */     SQLServerException interruptException = null;
/*      */     
/* 1299 */     while (this.moreResults) {
/*      */       
/*      */       try {
/* 1302 */         getNextResult(true);
/* 1303 */       } catch (SQLServerException e) {
/*      */ 
/*      */         
/* 1306 */         if (this.moreResults) {
/*      */           
/* 1308 */           if (2 == e.getDriverErrorCode()) {
/* 1309 */             if (stmtlogger.isLoggable(Level.FINEST)) {
/* 1310 */               stmtlogger.finest("" + this + " ignoring database error: " + this + " " + e
/* 1311 */                   .getErrorCode());
/*      */             }
/*      */ 
/*      */             
/*      */             continue;
/*      */           } 
/*      */ 
/*      */           
/* 1319 */           if (e.getSQLState() != null && e
/* 1320 */             .getSQLState().equals(SQLState.STATEMENT_CANCELED.getSQLStateCode())) {
/* 1321 */             interruptException = e;
/*      */             
/*      */             continue;
/*      */           } 
/*      */         } 
/*      */         
/* 1327 */         this.moreResults = false;
/* 1328 */         throw e;
/*      */       } 
/*      */     } 
/*      */     
/* 1332 */     clearLastResult();
/*      */     
/* 1334 */     if (null != interruptException) {
/* 1335 */       throw interruptException;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean getMoreResults() throws SQLServerException {
/* 1346 */     loggerExternal.entering(getClassNameLogging(), "getMoreResults");
/* 1347 */     checkClosed();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1352 */     getNextResult(true);
/* 1353 */     loggerExternal.exiting(getClassNameLogging(), "getMoreResults", Boolean.valueOf((null != this.resultSet)));
/* 1354 */     return (null != this.resultSet);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void clearLastResult() {
/* 1370 */     this.updateCount = -1L;
/*      */ 
/*      */     
/* 1373 */     if (null != this.resultSet) {
/*      */       
/*      */       try {
/*      */ 
/*      */         
/* 1378 */         this.resultSet.close();
/* 1379 */       } catch (SQLServerException e) {
/* 1380 */         stmtlogger.finest("" + this + " clearing last result; ignored error closing ResultSet: " + this + " " + e.getErrorCode());
/*      */       } finally {
/*      */         
/* 1383 */         this.resultSet = null;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final boolean getNextResult(boolean clearFlag) throws SQLServerException {
/*      */     final class NextResult
/*      */       extends TDSTokenHandler
/*      */     {
/* 1402 */       private StreamDone stmtDoneToken = null;
/*      */       
/*      */       final boolean isUpdateCount() {
/* 1405 */         return (null != this.stmtDoneToken);
/*      */       }
/*      */       
/*      */       final long getUpdateCount() {
/* 1409 */         return this.stmtDoneToken.getUpdateCount();
/*      */       }
/*      */       
/*      */       private boolean isResultSet = false;
/*      */       
/*      */       final boolean isResultSet() {
/* 1415 */         return this.isResultSet;
/*      */       }
/*      */       
/* 1418 */       private StreamRetStatus procedureRetStatToken = null;
/*      */       
/*      */       NextResult() {
/* 1421 */         super("getNextResult");
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       boolean onColMetaData(TDSReader tdsReader) throws SQLServerException {
/* 1431 */         if (null == this.stmtDoneToken && null == getDatabaseError())
/*      */         {
/* 1433 */           this.isResultSet = true;
/*      */         }
/* 1435 */         return false;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       boolean onDone(TDSReader tdsReader) throws SQLServerException {
/* 1441 */         StreamDone doneToken = new StreamDone();
/* 1442 */         doneToken.setFromTDS(tdsReader);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1448 */         if (doneToken.isAttnAck()) {
/* 1449 */           return false;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1457 */         if (doneToken.cmdIsDMLOrDDL()) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1462 */           if (-1L == doneToken.getUpdateCount() && 4 != SQLServerStatement.this.executeMethod) {
/* 1463 */             return true;
/*      */           }
/* 1465 */           if (-1L != doneToken.getUpdateCount() && 1 == SQLServerStatement.this.executeMethod) {
/* 1466 */             return true;
/*      */           }
/*      */ 
/*      */           
/* 1470 */           this.stmtDoneToken = doneToken;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1476 */           if (255 != doneToken.getTokenType()) {
/* 1477 */             return false;
/*      */           }
/* 1479 */           if (4 != SQLServerStatement.this.executeMethod)
/*      */           {
/* 1481 */             if (null != SQLServerStatement.this.procedureName) {
/* 1482 */               return false;
/*      */             }
/*      */             
/* 1485 */             if (3 == SQLServerStatement.this.executeMethod) {
/* 1486 */               return false;
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1493 */             if (!SQLServerStatement.this.connection.useLastUpdateCount()) {
/* 1494 */               return false;
/*      */ 
/*      */ 
/*      */             
/*      */             }
/*      */ 
/*      */           
/*      */           }
/*      */ 
/*      */ 
/*      */         
/*      */         }
/*      */         else {
/*      */ 
/*      */ 
/*      */           
/* 1510 */           if (doneToken.isFinal()) {
/* 1511 */             SQLServerStatement.this.moreResults = false;
/* 1512 */             return false;
/*      */           } 
/*      */           
/* 1515 */           if (4 == SQLServerStatement.this.executeMethod)
/*      */           {
/*      */             
/* 1518 */             if (255 != doneToken.getTokenType() || doneToken.wasRPCInBatch()) {
/* 1519 */               SQLServerStatement.this.moreResults = false;
/* 1520 */               return false;
/*      */             } 
/*      */           }
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1527 */         if (doneToken.isError()) {
/* 1528 */           return false;
/*      */         }
/*      */         
/* 1531 */         return true;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       boolean onRetStatus(TDSReader tdsReader) throws SQLServerException {
/* 1538 */         if (SQLServerStatement.this.consumeExecOutParam(tdsReader)) {
/* 1539 */           SQLServerStatement.this.moreResults = false;
/*      */ 
/*      */ 
/*      */         
/*      */         }
/*      */         else {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1549 */           this.procedureRetStatToken = new StreamRetStatus();
/* 1550 */           this.procedureRetStatToken.setFromTDS(tdsReader);
/*      */         } 
/*      */         
/* 1553 */         return true;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       boolean onRetValue(TDSReader tdsReader) throws SQLServerException {
/* 1561 */         if (SQLServerStatement.this.moreResults && null == this.procedureRetStatToken) {
/*      */           
/* 1563 */           Parameter p = new Parameter(Util.shouldHonorAEForParameters(SQLServerStatement.this.stmtColumnEncriptionSetting, SQLServerStatement.this.connection));
/* 1564 */           p.skipRetValStatus(tdsReader);
/* 1565 */           p.skipValue(tdsReader, true);
/* 1566 */           return true;
/*      */         } 
/*      */         
/* 1569 */         return false;
/*      */       }
/*      */       
/*      */       boolean onInfo(TDSReader tdsReader) throws SQLServerException {
/* 1573 */         StreamInfo infoToken = new StreamInfo();
/* 1574 */         infoToken.setFromTDS(tdsReader);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1588 */         if (16954 == infoToken.msg.getErrorNumber()) {
/* 1589 */           SQLServerStatement.this.executedSqlDirectly = true;
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 1594 */         SQLWarning warning = new SQLWarning(infoToken.msg.getErrorMessage(), SQLServerException.generateStateCode(SQLServerStatement.this.connection, infoToken.msg.getErrorNumber(), Integer.valueOf(infoToken.msg.getErrorState())), infoToken.msg.getErrorNumber());
/*      */         
/* 1596 */         if (SQLServerStatement.this.sqlWarnings == null) {
/* 1597 */           SQLServerStatement.this.sqlWarnings = new Vector<>();
/*      */         } else {
/* 1599 */           int n = SQLServerStatement.this.sqlWarnings.size();
/* 1600 */           SQLWarning w = SQLServerStatement.this.sqlWarnings.elementAt(n - 1);
/* 1601 */           w.setNextWarning(warning);
/*      */         } 
/* 1603 */         SQLServerStatement.this.sqlWarnings.add(warning);
/* 1604 */         return true;
/*      */       }
/*      */     };
/*      */ 
/*      */     
/* 1609 */     if (!wasExecuted()) {
/* 1610 */       this.moreResults = false;
/* 1611 */       return false;
/*      */     } 
/*      */ 
/*      */     
/* 1615 */     if (clearFlag) {
/* 1616 */       clearLastResult();
/*      */     }
/*      */ 
/*      */     
/* 1620 */     if (!this.moreResults) {
/* 1621 */       return false;
/*      */     }
/*      */ 
/*      */     
/* 1625 */     NextResult nextResult = new NextResult();
/*      */ 
/*      */     
/* 1628 */     TDSParser.parse(resultsReader(), nextResult, !clearFlag);
/*      */ 
/*      */     
/* 1631 */     if (null != nextResult.getDatabaseError()) {
/* 1632 */       SQLServerException.makeFromDatabaseError(this.connection, (Object)null, nextResult.getDatabaseError().getErrorMessage(), nextResult
/* 1633 */           .getDatabaseError(), false);
/*      */     }
/*      */ 
/*      */     
/* 1637 */     if (!clearFlag) {
/* 1638 */       return false;
/*      */     }
/*      */     
/* 1641 */     if (nextResult.isResultSet()) {
/* 1642 */       this.resultSet = new SQLServerResultSet(this);
/* 1643 */       return true;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1653 */     if (nextResult.isUpdateCount()) {
/* 1654 */       this.updateCount = nextResult.getUpdateCount();
/* 1655 */       return true;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1665 */     this.updateCount = -1L;
/* 1666 */     if (!this.moreResults) {
/* 1667 */       return true;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1673 */     this.moreResults = false;
/* 1674 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean consumeExecOutParam(TDSReader tdsReader) throws SQLServerException {
/* 1684 */     if (this.expectCursorOutParams) {
/* 1685 */       TDSParser.parse(tdsReader, new StmtExecOutParamHandler());
/* 1686 */       return true;
/*      */     } 
/*      */     
/* 1689 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setFetchDirection(int nDir) throws SQLServerException {
/* 1696 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1697 */       loggerExternal.entering(getClassNameLogging(), "setFetchDirection", Integer.valueOf(nDir)); 
/* 1698 */     checkClosed();
/* 1699 */     if ((1000 != nDir && 1001 != nDir && 1002 != nDir) || (1000 != nDir && (2003 == this.resultSetType || 2004 == this.resultSetType))) {
/*      */ 
/*      */ 
/*      */       
/* 1703 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidFetchDirection"));
/* 1704 */       Object[] msgArgs = { Integer.valueOf(nDir) };
/* 1705 */       SQLServerException.makeFromDriverError(this.connection, this, form.format(msgArgs), (String)null, false);
/*      */     } 
/*      */     
/* 1708 */     this.nFetchDirection = nDir;
/* 1709 */     loggerExternal.exiting(getClassNameLogging(), "setFetchDirection");
/*      */   }
/*      */ 
/*      */   
/*      */   public final int getFetchDirection() throws SQLServerException {
/* 1714 */     loggerExternal.entering(getClassNameLogging(), "getFetchDirection");
/* 1715 */     checkClosed();
/* 1716 */     loggerExternal.exiting(getClassNameLogging(), "getFetchDirection", Integer.valueOf(this.nFetchDirection));
/* 1717 */     return this.nFetchDirection;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setFetchSize(int rows) throws SQLServerException {
/* 1722 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1723 */       loggerExternal.entering(getClassNameLogging(), "setFetchSize", Integer.valueOf(rows)); 
/* 1724 */     checkClosed();
/* 1725 */     if (rows < 0) {
/* 1726 */       SQLServerException.makeFromDriverError(this.connection, this, 
/* 1727 */           SQLServerException.getErrString("R_invalidFetchSize"), (String)null, false);
/*      */     }
/* 1729 */     this.nFetchSize = (0 == rows) ? this.defaultFetchSize : rows;
/* 1730 */     loggerExternal.exiting(getClassNameLogging(), "setFetchSize");
/*      */   }
/*      */ 
/*      */   
/*      */   public final int getFetchSize() throws SQLServerException {
/* 1735 */     loggerExternal.entering(getClassNameLogging(), "getFetchSize");
/* 1736 */     checkClosed();
/* 1737 */     loggerExternal.exiting(getClassNameLogging(), "getFetchSize", Integer.valueOf(this.nFetchSize));
/* 1738 */     return this.nFetchSize;
/*      */   }
/*      */ 
/*      */   
/*      */   public final int getResultSetConcurrency() throws SQLServerException {
/* 1743 */     loggerExternal.entering(getClassNameLogging(), "getResultSetConcurrency");
/* 1744 */     checkClosed();
/* 1745 */     loggerExternal.exiting(getClassNameLogging(), "getResultSetConcurrency", Integer.valueOf(this.resultSetConcurrency));
/* 1746 */     return this.resultSetConcurrency;
/*      */   }
/*      */ 
/*      */   
/*      */   public final int getResultSetType() throws SQLServerException {
/* 1751 */     loggerExternal.entering(getClassNameLogging(), "getResultSetType");
/* 1752 */     checkClosed();
/* 1753 */     loggerExternal.exiting(getClassNameLogging(), "getResultSetType", Integer.valueOf(this.appResultSetType));
/* 1754 */     return this.appResultSetType;
/*      */   }
/*      */ 
/*      */   
/*      */   public void addBatch(String sql) throws SQLServerException {
/* 1759 */     loggerExternal.entering(getClassNameLogging(), "addBatch", sql);
/* 1760 */     checkClosed();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1765 */     sql = ensureSQLSyntax(sql);
/*      */     
/* 1767 */     this.batchStatementBuffer.add(sql);
/* 1768 */     loggerExternal.exiting(getClassNameLogging(), "addBatch");
/*      */   }
/*      */ 
/*      */   
/*      */   public void clearBatch() throws SQLServerException {
/* 1773 */     loggerExternal.entering(getClassNameLogging(), "clearBatch");
/* 1774 */     checkClosed();
/* 1775 */     this.batchStatementBuffer.clear();
/* 1776 */     loggerExternal.exiting(getClassNameLogging(), "clearBatch");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int[] executeBatch() throws SQLServerException, BatchUpdateException, SQLTimeoutException {
/* 1784 */     loggerExternal.entering(getClassNameLogging(), "executeBatch");
/* 1785 */     if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) {
/* 1786 */       loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */     }
/* 1788 */     checkClosed();
/* 1789 */     discardLastExecutionResults();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 1795 */       int batchSize = this.batchStatementBuffer.size();
/* 1796 */       int[] updateCounts = new int[batchSize];
/* 1797 */       for (int batchNum = 0; batchNum < batchSize; batchNum++) {
/* 1798 */         updateCounts[batchNum] = -3;
/*      */       }
/*      */ 
/*      */       
/* 1802 */       SQLServerException lastError = null;
/*      */       
/* 1804 */       for (int i = 0; i < batchSize; i++) {
/*      */ 
/*      */         
/*      */         try {
/*      */ 
/*      */           
/* 1810 */           if (0 == i) {
/*      */             
/* 1812 */             executeStatement(new StmtBatchExecCmd(this));
/*      */           
/*      */           }
/*      */           else {
/*      */             
/* 1817 */             startResults();
/* 1818 */             if (!getNextResult(true)) {
/*      */               break;
/*      */             }
/*      */           } 
/* 1822 */           if (null != this.resultSet) {
/* 1823 */             SQLServerException.makeFromDriverError(this.connection, this, 
/* 1824 */                 SQLServerException.getErrString("R_resultsetGeneratedForUpdate"), (String)null, true);
/*      */           } else {
/* 1826 */             updateCounts[i] = (-1 != (int)this.updateCount) ? (int)this.updateCount : 
/* 1827 */               -2;
/*      */           } 
/* 1829 */         } catch (SQLServerException e) {
/*      */ 
/*      */ 
/*      */           
/* 1833 */           if (this.connection.isSessionUnAvailable() || this.connection.rolledBackTransaction()) {
/* 1834 */             throw e;
/*      */           }
/*      */ 
/*      */           
/* 1838 */           lastError = e;
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 1843 */       if (null != lastError) {
/* 1844 */         throw new BatchUpdateException(lastError.getMessage(), lastError.getSQLState(), lastError
/* 1845 */             .getErrorCode(), updateCounts);
/*      */       }
/* 1847 */       loggerExternal.exiting(getClassNameLogging(), "executeBatch", updateCounts);
/* 1848 */       return updateCounts;
/*      */     
/*      */     }
/*      */     finally {
/*      */ 
/*      */       
/* 1854 */       this.batchStatementBuffer.clear();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public long[] executeLargeBatch() throws SQLServerException, BatchUpdateException, SQLTimeoutException {
/* 1861 */     loggerExternal.entering(getClassNameLogging(), "executeLargeBatch");
/* 1862 */     if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) {
/* 1863 */       loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */     }
/* 1865 */     checkClosed();
/* 1866 */     discardLastExecutionResults();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 1872 */       int batchSize = this.batchStatementBuffer.size();
/* 1873 */       long[] updateCounts = new long[batchSize];
/* 1874 */       for (int batchNum = 0; batchNum < batchSize; batchNum++) {
/* 1875 */         updateCounts[batchNum] = -3L;
/*      */       }
/*      */ 
/*      */       
/* 1879 */       SQLServerException lastError = null;
/*      */       
/* 1881 */       for (int i = 0; i < batchSize; i++) {
/*      */ 
/*      */         
/*      */         try {
/*      */ 
/*      */           
/* 1887 */           if (0 == i) {
/*      */             
/* 1889 */             executeStatement(new StmtBatchExecCmd(this));
/*      */           
/*      */           }
/*      */           else {
/*      */             
/* 1894 */             startResults();
/* 1895 */             if (!getNextResult(true)) {
/*      */               break;
/*      */             }
/*      */           } 
/* 1899 */           if (null != this.resultSet) {
/* 1900 */             SQLServerException.makeFromDriverError(this.connection, this, 
/* 1901 */                 SQLServerException.getErrString("R_resultsetGeneratedForUpdate"), (String)null, true);
/*      */           } else {
/* 1903 */             updateCounts[i] = (-1L != this.updateCount) ? this.updateCount : -2L;
/*      */           } 
/* 1905 */         } catch (SQLServerException e) {
/*      */ 
/*      */ 
/*      */           
/* 1909 */           if (this.connection.isSessionUnAvailable() || this.connection.rolledBackTransaction()) {
/* 1910 */             throw e;
/*      */           }
/*      */ 
/*      */           
/* 1914 */           lastError = e;
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 1919 */       if (null != lastError) {
/* 1920 */         DriverJDBCVersion.throwBatchUpdateException(lastError, updateCounts);
/*      */       }
/* 1922 */       loggerExternal.exiting(getClassNameLogging(), "executeLargeBatch", updateCounts);
/* 1923 */       return updateCounts;
/*      */     
/*      */     }
/*      */     finally {
/*      */ 
/*      */       
/* 1929 */       this.batchStatementBuffer.clear();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Connection getConnection() throws SQLServerException {
/* 1942 */     loggerExternal.entering(getClassNameLogging(), "getConnection");
/* 1943 */     if (this.bIsClosed) {
/* 1944 */       SQLServerException.makeFromDriverError(this.connection, this, 
/* 1945 */           SQLServerException.getErrString("R_statementIsClosed"), (String)null, false);
/*      */     }
/* 1947 */     Connection con = this.connection.getConnection();
/* 1948 */     loggerExternal.exiting(getClassNameLogging(), "getConnection", con);
/* 1949 */     return con;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   final int getResultSetScrollOpt() {
/* 1955 */     int scrollOpt = (null == this.inOutParam) ? 0 : 4096;
/*      */     
/* 1957 */     switch (this.resultSetType) {
/*      */       case 2004:
/* 1959 */         return scrollOpt | ((1007 == this.resultSetConcurrency) ? 16 : 
/* 1960 */           4);
/*      */       
/*      */       case 1006:
/* 1963 */         return scrollOpt | 0x2;
/*      */       
/*      */       case 1005:
/* 1966 */         return scrollOpt | 0x1;
/*      */       
/*      */       case 1004:
/* 1969 */         return scrollOpt | 0x8;
/*      */     } 
/*      */ 
/*      */     
/* 1973 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   final int getResultSetCCOpt() {
/* 1978 */     switch (this.resultSetConcurrency) {
/*      */       case 1007:
/* 1980 */         return 8193;
/*      */ 
/*      */       
/*      */       case 1008:
/* 1984 */         return 24580;
/*      */       
/*      */       case 1009:
/* 1987 */         return 24578;
/*      */       
/*      */       case 1010:
/* 1990 */         return 24584;
/*      */     } 
/*      */ 
/*      */     
/* 1994 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   private void doExecuteCursored(StmtExecCmd execCmd, String sql) throws SQLServerException {
/* 1999 */     if (stmtlogger.isLoggable(Level.FINER)) {
/* 2000 */       stmtlogger.finer(toString() + " Execute for cursor open SQL:" + toString() + " Scrollability:" + sql + " Concurrency:" + 
/* 2001 */           getResultSetScrollOpt());
/*      */     }
/*      */     
/* 2004 */     this.executedSqlDirectly = false;
/* 2005 */     this.expectCursorOutParams = true;
/* 2006 */     TDSWriter tdsWriter = execCmd.startRequest((byte)3);
/* 2007 */     tdsWriter.writeShort((short)-1);
/* 2008 */     tdsWriter.writeShort((short)2);
/* 2009 */     tdsWriter.writeByte((byte)0);
/* 2010 */     tdsWriter.writeByte((byte)0);
/* 2011 */     tdsWriter.sendEnclavePackage(sql, execCmd.enclaveCEKs);
/*      */ 
/*      */     
/* 2014 */     tdsWriter.writeRPCInt(null, Integer.valueOf(0), true);
/*      */ 
/*      */     
/* 2017 */     tdsWriter.writeRPCStringUnicode(sql);
/*      */ 
/*      */     
/* 2020 */     tdsWriter.writeRPCInt(null, Integer.valueOf(getResultSetScrollOpt()), false);
/*      */ 
/*      */     
/* 2023 */     tdsWriter.writeRPCInt(null, Integer.valueOf(getResultSetCCOpt()), false);
/*      */ 
/*      */     
/* 2026 */     tdsWriter.writeRPCInt(null, Integer.valueOf(0), true);
/*      */     
/* 2028 */     ensureExecuteResultsReader(execCmd.startResponse(this.isResponseBufferingAdaptive));
/* 2029 */     startResults();
/* 2030 */     getNextResult(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getResultSetHoldability() throws SQLException {
/* 2037 */     loggerExternal.entering(getClassNameLogging(), "getResultSetHoldability");
/* 2038 */     checkClosed();
/* 2039 */     int holdability = this.connection.getHoldability();
/* 2040 */     loggerExternal.exiting(getClassNameLogging(), "getResultSetHoldability", Integer.valueOf(holdability));
/* 2041 */     return holdability;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean execute(String sql, int autoGeneratedKeys) throws SQLServerException, SQLTimeoutException {
/* 2047 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 2048 */       loggerExternal.entering(getClassNameLogging(), "execute", new Object[] { sql, Integer.valueOf(autoGeneratedKeys) });
/* 2049 */       if (Util.isActivityTraceOn()) {
/* 2050 */         loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */       }
/*      */     } 
/* 2053 */     checkClosed();
/* 2054 */     if (autoGeneratedKeys != 1 && autoGeneratedKeys != 2) {
/* 2055 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidAutoGeneratedKeys"));
/* 2056 */       Object[] msgArgs = { Integer.valueOf(autoGeneratedKeys) };
/* 2057 */       SQLServerException.makeFromDriverError(this.connection, this, form.format(msgArgs), (String)null, false);
/*      */     } 
/*      */     
/* 2060 */     executeStatement(new StmtExecCmd(this, sql, 3, autoGeneratedKeys));
/* 2061 */     loggerExternal.exiting(getClassNameLogging(), "execute", Boolean.valueOf((null != this.resultSet)));
/* 2062 */     return (null != this.resultSet);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean execute(String sql, int[] columnIndexes) throws SQLServerException, SQLTimeoutException {
/* 2068 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2069 */       loggerExternal.entering(getClassNameLogging(), "execute", new Object[] { sql, columnIndexes }); 
/* 2070 */     checkClosed();
/* 2071 */     if (columnIndexes == null || columnIndexes.length != 1) {
/* 2072 */       SQLServerException.makeFromDriverError(this.connection, this, 
/* 2073 */           SQLServerException.getErrString("R_invalidColumnArrayLength"), (String)null, false);
/*      */     }
/* 2075 */     boolean fSuccess = execute(sql, 1);
/* 2076 */     loggerExternal.exiting(getClassNameLogging(), "execute", Boolean.valueOf(fSuccess));
/* 2077 */     return fSuccess;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean execute(String sql, String[] columnNames) throws SQLServerException, SQLTimeoutException {
/* 2083 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2084 */       loggerExternal.entering(getClassNameLogging(), "execute", new Object[] { sql, columnNames }); 
/* 2085 */     checkClosed();
/* 2086 */     if (columnNames == null || columnNames.length != 1) {
/* 2087 */       SQLServerException.makeFromDriverError(this.connection, this, 
/* 2088 */           SQLServerException.getErrString("R_invalidColumnArrayLength"), (String)null, false);
/*      */     }
/* 2090 */     boolean fSuccess = execute(sql, 1);
/* 2091 */     loggerExternal.exiting(getClassNameLogging(), "execute", Boolean.valueOf(fSuccess));
/* 2092 */     return fSuccess;
/*      */   }
/*      */ 
/*      */   
/*      */   public final int executeUpdate(String sql, int autoGeneratedKeys) throws SQLServerException, SQLTimeoutException {
/* 2097 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 2098 */       loggerExternal.entering(getClassNameLogging(), "executeUpdate", new Object[] { sql, Integer.valueOf(autoGeneratedKeys) });
/* 2099 */       if (Util.isActivityTraceOn()) {
/* 2100 */         loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */       }
/*      */     } 
/* 2103 */     checkClosed();
/* 2104 */     if (autoGeneratedKeys != 1 && autoGeneratedKeys != 2) {
/* 2105 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidAutoGeneratedKeys"));
/* 2106 */       Object[] msgArgs = { Integer.valueOf(autoGeneratedKeys) };
/* 2107 */       SQLServerException.makeFromDriverError(this.connection, this, form.format(msgArgs), (String)null, false);
/*      */     } 
/* 2109 */     executeStatement(new StmtExecCmd(this, sql, 2, autoGeneratedKeys));
/*      */ 
/*      */     
/* 2112 */     if (this.updateCount < -2147483648L || this.updateCount > 2147483647L) {
/* 2113 */       SQLServerException.makeFromDriverError(this.connection, this, 
/* 2114 */           SQLServerException.getErrString("R_updateCountOutofRange"), (String)null, true);
/*      */     }
/* 2116 */     loggerExternal.exiting(getClassNameLogging(), "executeUpdate", Long.valueOf(this.updateCount));
/*      */     
/* 2118 */     return (int)this.updateCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final long executeLargeUpdate(String sql, int autoGeneratedKeys) throws SQLServerException, SQLTimeoutException {
/* 2125 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 2126 */       loggerExternal.entering(getClassNameLogging(), "executeLargeUpdate", new Object[] { sql, Integer.valueOf(autoGeneratedKeys) });
/* 2127 */       if (Util.isActivityTraceOn()) {
/* 2128 */         loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */       }
/*      */     } 
/* 2131 */     checkClosed();
/* 2132 */     if (autoGeneratedKeys != 1 && autoGeneratedKeys != 2) {
/* 2133 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidAutoGeneratedKeys"));
/* 2134 */       Object[] msgArgs = { Integer.valueOf(autoGeneratedKeys) };
/* 2135 */       SQLServerException.makeFromDriverError(this.connection, this, form.format(msgArgs), (String)null, false);
/*      */     } 
/* 2137 */     executeStatement(new StmtExecCmd(this, sql, 2, autoGeneratedKeys));
/* 2138 */     loggerExternal.exiting(getClassNameLogging(), "executeLargeUpdate", Long.valueOf(this.updateCount));
/* 2139 */     return this.updateCount;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final int executeUpdate(String sql, int[] columnIndexes) throws SQLServerException, SQLTimeoutException {
/* 2145 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2146 */       loggerExternal.entering(getClassNameLogging(), "executeUpdate", new Object[] { sql, columnIndexes }); 
/* 2147 */     checkClosed();
/* 2148 */     if (columnIndexes == null || columnIndexes.length != 1) {
/* 2149 */       SQLServerException.makeFromDriverError(this.connection, this, 
/* 2150 */           SQLServerException.getErrString("R_invalidColumnArrayLength"), (String)null, false);
/*      */     }
/* 2152 */     int count = executeUpdate(sql, 1);
/* 2153 */     loggerExternal.exiting(getClassNameLogging(), "executeUpdate", Integer.valueOf(count));
/* 2154 */     return count;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final long executeLargeUpdate(String sql, int[] columnIndexes) throws SQLServerException, SQLTimeoutException {
/* 2161 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2162 */       loggerExternal.entering(getClassNameLogging(), "executeLargeUpdate", new Object[] { sql, columnIndexes }); 
/* 2163 */     checkClosed();
/* 2164 */     if (columnIndexes == null || columnIndexes.length != 1) {
/* 2165 */       SQLServerException.makeFromDriverError(this.connection, this, 
/* 2166 */           SQLServerException.getErrString("R_invalidColumnArrayLength"), (String)null, false);
/*      */     }
/* 2168 */     long count = executeLargeUpdate(sql, 1);
/* 2169 */     loggerExternal.exiting(getClassNameLogging(), "executeLargeUpdate", Long.valueOf(count));
/* 2170 */     return count;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final int executeUpdate(String sql, String[] columnNames) throws SQLServerException, SQLTimeoutException {
/* 2176 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2177 */       loggerExternal.entering(getClassNameLogging(), "executeUpdate", new Object[] { sql, columnNames }); 
/* 2178 */     checkClosed();
/* 2179 */     if (columnNames == null || columnNames.length != 1) {
/* 2180 */       SQLServerException.makeFromDriverError(this.connection, this, 
/* 2181 */           SQLServerException.getErrString("R_invalidColumnArrayLength"), (String)null, false);
/*      */     }
/* 2183 */     int count = executeUpdate(sql, 1);
/* 2184 */     loggerExternal.exiting(getClassNameLogging(), "executeUpdate", Integer.valueOf(count));
/* 2185 */     return count;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final long executeLargeUpdate(String sql, String[] columnNames) throws SQLServerException, SQLTimeoutException {
/* 2192 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2193 */       loggerExternal.entering(getClassNameLogging(), "executeLargeUpdate", new Object[] { sql, columnNames }); 
/* 2194 */     checkClosed();
/* 2195 */     if (columnNames == null || columnNames.length != 1) {
/* 2196 */       SQLServerException.makeFromDriverError(this.connection, this, 
/* 2197 */           SQLServerException.getErrString("R_invalidColumnArrayLength"), (String)null, false);
/*      */     }
/* 2199 */     long count = executeLargeUpdate(sql, 1);
/* 2200 */     loggerExternal.exiting(getClassNameLogging(), "executeLargeUpdate", Long.valueOf(count));
/* 2201 */     return count;
/*      */   }
/*      */ 
/*      */   
/*      */   public final ResultSet getGeneratedKeys() throws SQLServerException {
/* 2206 */     loggerExternal.entering(getClassNameLogging(), "getGeneratedKeys");
/* 2207 */     checkClosed();
/*      */     
/* 2209 */     if (null == this.autoGeneratedKeys) {
/* 2210 */       long orgUpd = this.updateCount;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2215 */       if (!getNextResult(true) || null == this.resultSet) {
/* 2216 */         SQLServerException.makeFromDriverError(this.connection, this, 
/* 2217 */             SQLServerException.getErrString("R_statementMustBeExecuted"), (String)null, false);
/*      */       }
/*      */       
/* 2220 */       this.autoGeneratedKeys = this.resultSet;
/* 2221 */       this.updateCount = orgUpd;
/*      */     } 
/* 2223 */     loggerExternal.exiting(getClassNameLogging(), "getGeneratedKeys", this.autoGeneratedKeys);
/* 2224 */     return this.autoGeneratedKeys;
/*      */   }
/*      */ 
/*      */   
/*      */   public final boolean getMoreResults(int mode) throws SQLException {
/* 2229 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2230 */       loggerExternal.entering(getClassNameLogging(), "getMoreResults", Integer.valueOf(mode)); 
/* 2231 */     checkClosed();
/* 2232 */     if (2 == mode) {
/* 2233 */       SQLServerException.throwNotSupportedException(this.connection, this);
/*      */     }
/*      */     
/* 2236 */     if (1 != mode && 3 != mode) {
/* 2237 */       SQLServerException.makeFromDriverError(this.connection, this, 
/* 2238 */           SQLServerException.getErrString("R_modeSuppliedNotValid"), (String)null, true);
/*      */     }
/* 2240 */     ResultSet rsPrevious = this.resultSet;
/* 2241 */     boolean fResults = getMoreResults();
/* 2242 */     if (rsPrevious != null) {
/*      */       try {
/* 2244 */         rsPrevious.close();
/* 2245 */       } catch (SQLException e) {
/* 2246 */         throw new SQLServerException(e.getMessage(), null, 0, e);
/*      */       } 
/*      */     }
/*      */     
/* 2250 */     loggerExternal.exiting(getClassNameLogging(), "getMoreResults", Boolean.valueOf(fResults));
/* 2251 */     return fResults;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isClosed() throws SQLException {
/* 2256 */     loggerExternal.entering(getClassNameLogging(), "isClosed");
/* 2257 */     boolean result = (this.bIsClosed || this.connection.isSessionUnAvailable());
/* 2258 */     loggerExternal.exiting(getClassNameLogging(), "isClosed", Boolean.valueOf(result));
/* 2259 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isCloseOnCompletion() throws SQLException {
/* 2264 */     loggerExternal.entering(getClassNameLogging(), "isCloseOnCompletion");
/* 2265 */     checkClosed();
/* 2266 */     loggerExternal.exiting(getClassNameLogging(), "isCloseOnCompletion", Boolean.valueOf(this.isCloseOnCompletion));
/* 2267 */     return this.isCloseOnCompletion;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isPoolable() throws SQLException {
/* 2272 */     loggerExternal.entering(getClassNameLogging(), "isPoolable");
/* 2273 */     checkClosed();
/* 2274 */     loggerExternal.exiting(getClassNameLogging(), "isPoolable", Boolean.valueOf(this.stmtPoolable));
/* 2275 */     return this.stmtPoolable;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setPoolable(boolean poolable) throws SQLException {
/* 2280 */     loggerExternal.entering(getClassNameLogging(), "setPoolable", Boolean.valueOf(poolable));
/* 2281 */     checkClosed();
/* 2282 */     this.stmtPoolable = poolable;
/* 2283 */     loggerExternal.exiting(getClassNameLogging(), "setPoolable");
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isWrapperFor(Class<?> iface) throws SQLException {
/* 2288 */     loggerExternal.entering(getClassNameLogging(), "isWrapperFor");
/* 2289 */     boolean f = iface.isInstance(this);
/* 2290 */     loggerExternal.exiting(getClassNameLogging(), "isWrapperFor", Boolean.valueOf(f));
/* 2291 */     return f;
/*      */   }
/*      */   
/*      */   public <T> T unwrap(Class<T> iface) throws SQLException {
/*      */     T t;
/* 2296 */     loggerExternal.entering(getClassNameLogging(), "unwrap");
/*      */     
/*      */     try {
/* 2299 */       t = iface.cast(this);
/* 2300 */     } catch (ClassCastException e) {
/* 2301 */       throw new SQLServerException(e.getMessage(), e);
/*      */     } 
/* 2303 */     loggerExternal.exiting(getClassNameLogging(), "unwrap", t);
/* 2304 */     return t;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setResponseBuffering(String value) throws SQLServerException {
/* 2328 */     loggerExternal.entering(getClassNameLogging(), "setResponseBuffering", value);
/* 2329 */     checkClosed();
/* 2330 */     if ("full".equalsIgnoreCase(value)) {
/* 2331 */       this.isResponseBufferingAdaptive = false;
/* 2332 */       this.wasResponseBufferingSet = true;
/* 2333 */     } else if ("adaptive".equalsIgnoreCase(value)) {
/* 2334 */       this.isResponseBufferingAdaptive = true;
/* 2335 */       this.wasResponseBufferingSet = true;
/*      */     } else {
/* 2337 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidresponseBuffering"));
/* 2338 */       Object[] msgArgs = { value };
/* 2339 */       SQLServerException.makeFromDriverError(this.connection, this, form.format(msgArgs), (String)null, false);
/*      */     } 
/* 2341 */     loggerExternal.exiting(getClassNameLogging(), "setResponseBuffering");
/*      */   }
/*      */   
/*      */   public final String getResponseBuffering() throws SQLServerException {
/*      */     String responseBuff;
/* 2346 */     loggerExternal.entering(getClassNameLogging(), "getResponseBuffering");
/* 2347 */     checkClosed();
/*      */     
/* 2349 */     if (this.wasResponseBufferingSet)
/* 2350 */     { if (this.isResponseBufferingAdaptive) {
/* 2351 */         responseBuff = "adaptive";
/*      */       } else {
/* 2353 */         responseBuff = "full";
/*      */       }  }
/* 2355 */     else { responseBuff = this.connection.getResponseBuffering(); }
/*      */     
/* 2357 */     loggerExternal.exiting(getClassNameLogging(), "getResponseBuffering", responseBuff);
/* 2358 */     return responseBuff;
/*      */   }
/*      */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerStatement.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */