/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import java.nio.charset.StandardCharsets;
/*    */ import java.text.MessageFormat;
/*    */ import java.util.Base64;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SQLServerAeadAes256CbcHmac256Factory
/*    */   extends SQLServerEncryptionAlgorithmFactory
/*    */ {
/* 20 */   private byte algorithmVersion = 1;
/* 21 */   private ConcurrentHashMap<String, SQLServerAeadAes256CbcHmac256Algorithm> encryptionAlgorithms = new ConcurrentHashMap<>();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   SQLServerEncryptionAlgorithm create(SQLServerSymmetricKey columnEncryptionKey, SQLServerEncryptionType encryptionType, String encryptionAlgorithm) throws SQLServerException {
/* 27 */     assert columnEncryptionKey != null;
/* 28 */     if (encryptionType != SQLServerEncryptionType.Deterministic && encryptionType != SQLServerEncryptionType.Randomized) {
/*    */       
/* 30 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_InvalidEncryptionType"));
/* 31 */       Object[] msgArgs = { encryptionType, encryptionAlgorithm, "'" + SQLServerEncryptionType.Deterministic + "," + SQLServerEncryptionType.Randomized + "'" };
/*    */       
/* 33 */       throw new SQLServerException(this, form.format(msgArgs), null, 0, false);
/*    */     } 
/*    */ 
/*    */     
/* 37 */     StringBuilder factoryKeyBuilder = new StringBuilder();
/* 38 */     factoryKeyBuilder.append(
/* 39 */         Base64.getEncoder().encodeToString((new String(columnEncryptionKey.getRootKey(), StandardCharsets.UTF_8)).getBytes()));
/*    */     
/* 41 */     factoryKeyBuilder.append(":");
/* 42 */     factoryKeyBuilder.append(encryptionType);
/* 43 */     factoryKeyBuilder.append(":");
/* 44 */     factoryKeyBuilder.append(this.algorithmVersion);
/*    */     
/* 46 */     String factoryKey = factoryKeyBuilder.toString();
/*    */ 
/*    */ 
/*    */     
/* 50 */     if (!this.encryptionAlgorithms.containsKey(factoryKey)) {
/*    */       
/* 52 */       SQLServerAeadAes256CbcHmac256EncryptionKey encryptedKey = new SQLServerAeadAes256CbcHmac256EncryptionKey(columnEncryptionKey.getRootKey(), "AEAD_AES_256_CBC_HMAC_SHA256");
/* 53 */       SQLServerAeadAes256CbcHmac256Algorithm aesAlgorithm = new SQLServerAeadAes256CbcHmac256Algorithm(encryptedKey, encryptionType, this.algorithmVersion);
/* 54 */       this.encryptionAlgorithms.putIfAbsent(factoryKey, aesAlgorithm);
/*    */     } 
/*    */     
/* 57 */     return this.encryptionAlgorithms.get(factoryKey);
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerAeadAes256CbcHmac256Factory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */