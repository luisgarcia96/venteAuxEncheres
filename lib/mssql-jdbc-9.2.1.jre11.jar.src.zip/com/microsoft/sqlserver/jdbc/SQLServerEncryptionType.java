/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import java.text.MessageFormat;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ enum SQLServerEncryptionType
/*    */ {
/*    */   final byte value;
/*    */   private static final SQLServerEncryptionType[] VALUES;
/* 17 */   Deterministic((byte)1),
/* 18 */   Randomized((byte)2),
/* 19 */   PlainText((byte)0);
/*    */   
/*    */   static {
/* 22 */     VALUES = values();
/*    */   }
/*    */   SQLServerEncryptionType(byte val) {
/* 25 */     this.value = val;
/*    */   }
/*    */   
/*    */   byte getValue() {
/* 29 */     return this.value;
/*    */   }
/*    */   
/*    */   static SQLServerEncryptionType of(byte val) throws SQLServerException {
/* 33 */     for (SQLServerEncryptionType type : VALUES) {
/* 34 */       if (val == type.value) {
/* 35 */         return type;
/*    */       }
/*    */     } 
/* 38 */     MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_unknownColumnEncryptionType"));
/* 39 */     Object[] msgArgs = { Byte.valueOf(val) };
/* 40 */     SQLServerException.makeFromDriverError(null, null, form.format(msgArgs), null, true);
/*    */ 
/*    */     
/* 43 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerEncryptionType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */