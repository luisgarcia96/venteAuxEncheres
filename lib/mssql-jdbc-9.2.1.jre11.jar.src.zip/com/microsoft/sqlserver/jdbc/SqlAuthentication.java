/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import java.text.MessageFormat;
/*    */ import java.util.Locale;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ enum SqlAuthentication
/*    */ {
/* 64 */   NotSpecified,
/* 65 */   SqlPassword,
/* 66 */   ActiveDirectoryPassword,
/* 67 */   ActiveDirectoryIntegrated,
/* 68 */   ActiveDirectoryMSI,
/* 69 */   ActiveDirectoryServicePrincipal,
/* 70 */   ActiveDirectoryInteractive;
/*    */   
/*    */   static SqlAuthentication valueOfString(String value) throws SQLServerException {
/* 73 */     SqlAuthentication method = null;
/*    */     
/* 75 */     if (value.toLowerCase(Locale.US).equalsIgnoreCase(NotSpecified.toString())) {
/* 76 */       method = NotSpecified;
/* 77 */     } else if (value.toLowerCase(Locale.US).equalsIgnoreCase(SqlPassword.toString())) {
/* 78 */       method = SqlPassword;
/* 79 */     } else if (value.toLowerCase(Locale.US)
/* 80 */       .equalsIgnoreCase(ActiveDirectoryPassword.toString())) {
/* 81 */       method = ActiveDirectoryPassword;
/* 82 */     } else if (value.toLowerCase(Locale.US)
/* 83 */       .equalsIgnoreCase(ActiveDirectoryIntegrated.toString())) {
/* 84 */       method = ActiveDirectoryIntegrated;
/* 85 */     } else if (value.toLowerCase(Locale.US).equalsIgnoreCase(ActiveDirectoryMSI.toString())) {
/* 86 */       method = ActiveDirectoryMSI;
/* 87 */     } else if (value.toLowerCase(Locale.US)
/* 88 */       .equalsIgnoreCase(ActiveDirectoryServicePrincipal.toString())) {
/* 89 */       method = ActiveDirectoryServicePrincipal;
/* 90 */     } else if (value.toLowerCase(Locale.US)
/* 91 */       .equalsIgnoreCase(ActiveDirectoryInteractive.toString())) {
/* 92 */       method = ActiveDirectoryInteractive;
/*    */     } else {
/* 94 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_InvalidConnectionSetting"));
/* 95 */       Object[] msgArgs = { "authentication", value };
/* 96 */       throw new SQLServerException(null, form.format(msgArgs), null, 0, false);
/*    */     } 
/* 98 */     return method;
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SqlAuthentication.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */