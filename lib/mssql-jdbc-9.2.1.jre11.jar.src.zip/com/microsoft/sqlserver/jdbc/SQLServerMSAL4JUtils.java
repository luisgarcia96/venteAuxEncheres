/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import com.microsoft.aad.msal4j.ClientCredentialFactory;
/*     */ import com.microsoft.aad.msal4j.ClientCredentialParameters;
/*     */ import com.microsoft.aad.msal4j.ConfidentialClientApplication;
/*     */ import com.microsoft.aad.msal4j.IAccount;
/*     */ import com.microsoft.aad.msal4j.IAuthenticationResult;
/*     */ import com.microsoft.aad.msal4j.IClientCredential;
/*     */ import com.microsoft.aad.msal4j.IClientSecret;
/*     */ import com.microsoft.aad.msal4j.IntegratedWindowsAuthenticationParameters;
/*     */ import com.microsoft.aad.msal4j.InteractiveRequestParameters;
/*     */ import com.microsoft.aad.msal4j.MsalInteractionRequiredException;
/*     */ import com.microsoft.aad.msal4j.PublicClientApplication;
/*     */ import com.microsoft.aad.msal4j.SilentParameters;
/*     */ import com.microsoft.aad.msal4j.SystemBrowserOptions;
/*     */ import com.microsoft.aad.msal4j.UserNamePasswordParameters;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URI;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.CompletableFuture;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.security.auth.kerberos.KerberosPrincipal;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SQLServerMSAL4JUtils
/*     */ {
/*     */   static final String REDIRECTURI = "http://localhost";
/*     */   private static final String SLASH_DEFAULT = "/.default";
/*  46 */   private static final Logger logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.SQLServerMSAL4JUtils");
/*     */ 
/*     */   
/*     */   static SqlFedAuthToken getSqlFedAuthToken(SQLServerConnection.SqlFedAuthInfo fedAuthInfo, String user, String password, String authenticationString) throws SQLServerException {
/*  50 */     ExecutorService executorService = Executors.newSingleThreadExecutor();
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  55 */       PublicClientApplication pca = ((PublicClientApplication.Builder)((PublicClientApplication.Builder)PublicClientApplication.builder("7f98cb04-cd1e-40df-9140-3bf7e2cea4db").executorService(executorService)).authority(fedAuthInfo.stsurl)).build();
/*  56 */       CompletableFuture<IAuthenticationResult> future = pca.acquireToken(
/*  57 */           UserNamePasswordParameters.builder(Collections.singleton(fedAuthInfo.spn + "/.default"), user, password.toCharArray())
/*  58 */           .build());
/*     */       
/*  60 */       IAuthenticationResult authenticationResult = future.get();
/*  61 */       return new SqlFedAuthToken(authenticationResult.accessToken(), authenticationResult.expiresOnDate());
/*  62 */     } catch (MalformedURLException|InterruptedException e) {
/*  63 */       throw new SQLServerException(e.getMessage(), e);
/*  64 */     } catch (ExecutionException e) {
/*  65 */       throw getCorrectedException(e, user, authenticationString);
/*     */     } finally {
/*  67 */       executorService.shutdown();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static SqlFedAuthToken getSqlFedAuthTokenPrincipal(SQLServerConnection.SqlFedAuthInfo fedAuthInfo, String aadPrincipalID, String aadPrincipalSecret, String authenticationString) throws SQLServerException {
/*  73 */     ExecutorService executorService = Executors.newSingleThreadExecutor();
/*     */     try {
/*  75 */       String defaultScopeSuffix = "/.default";
/*     */       
/*  77 */       String scope = fedAuthInfo.spn.endsWith(defaultScopeSuffix) ? fedAuthInfo.spn : (fedAuthInfo.spn + fedAuthInfo.spn);
/*  78 */       Set<String> scopes = new HashSet<>();
/*  79 */       scopes.add(scope);
/*  80 */       IClientSecret iClientSecret = ClientCredentialFactory.createFromSecret(aadPrincipalSecret);
/*     */ 
/*     */       
/*  83 */       ConfidentialClientApplication clientApplication = ((ConfidentialClientApplication.Builder)((ConfidentialClientApplication.Builder)ConfidentialClientApplication.builder(aadPrincipalID, (IClientCredential)iClientSecret).executorService(executorService)).authority(fedAuthInfo.stsurl)).build();
/*     */       
/*  85 */       CompletableFuture<IAuthenticationResult> future = clientApplication.acquireToken(ClientCredentialParameters.builder(scopes).build());
/*  86 */       IAuthenticationResult authenticationResult = future.get();
/*  87 */       return new SqlFedAuthToken(authenticationResult.accessToken(), authenticationResult.expiresOnDate());
/*  88 */     } catch (MalformedURLException|InterruptedException e) {
/*  89 */       throw new SQLServerException(e.getMessage(), e);
/*  90 */     } catch (ExecutionException e) {
/*  91 */       throw getCorrectedException(e, aadPrincipalID, authenticationString);
/*     */     } finally {
/*  93 */       executorService.shutdown();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static SqlFedAuthToken getSqlFedAuthTokenIntegrated(SQLServerConnection.SqlFedAuthInfo fedAuthInfo, String authenticationString) throws SQLServerException {
/*  99 */     ExecutorService executorService = Executors.newSingleThreadExecutor();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 106 */       KerberosPrincipal kerberosPrincipal = new KerberosPrincipal("username");
/* 107 */       String user = kerberosPrincipal.getName();
/*     */       
/* 109 */       if (logger.isLoggable(Level.FINE)) {
/* 110 */         logger.fine(logger.toString() + " realm name is:" + logger.toString());
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 115 */       PublicClientApplication pca = ((PublicClientApplication.Builder)((PublicClientApplication.Builder)PublicClientApplication.builder("7f98cb04-cd1e-40df-9140-3bf7e2cea4db").executorService(executorService)).authority(fedAuthInfo.stsurl)).build();
/*     */       
/* 117 */       CompletableFuture<IAuthenticationResult> future = pca.acquireToken(
/* 118 */           IntegratedWindowsAuthenticationParameters.builder(Collections.singleton(fedAuthInfo.spn + "/.default"), user).build());
/*     */       
/* 120 */       IAuthenticationResult authenticationResult = future.get();
/* 121 */       return new SqlFedAuthToken(authenticationResult.accessToken(), authenticationResult.expiresOnDate());
/* 122 */     } catch (InterruptedException|java.io.IOException e) {
/* 123 */       throw new SQLServerException(e.getMessage(), e);
/* 124 */     } catch (ExecutionException e) {
/* 125 */       throw getCorrectedException(e, "", authenticationString);
/*     */     } finally {
/* 127 */       executorService.shutdown();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static SqlFedAuthToken getSqlFedAuthTokenInteractive(SQLServerConnection.SqlFedAuthInfo fedAuthInfo, String user, String authenticationString) throws SQLServerException {
/* 133 */     ExecutorService executorService = Executors.newSingleThreadExecutor();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 139 */       PublicClientApplication pca = ((PublicClientApplication.Builder)((PublicClientApplication.Builder)((PublicClientApplication.Builder)((PublicClientApplication.Builder)PublicClientApplication.builder("7f98cb04-cd1e-40df-9140-3bf7e2cea4db").executorService(executorService)).setTokenCacheAccessAspect(PersistentTokenCacheAccessAspect.getInstance())).authority(fedAuthInfo.stsurl)).logPii(logger.isLoggable(Level.FINE))).build();
/*     */       
/* 141 */       CompletableFuture<IAuthenticationResult> future = null;
/* 142 */       IAuthenticationResult authenticationResult = null;
/*     */ 
/*     */       
/*     */       try {
/* 146 */         Set<IAccount> accountsInCache = pca.getAccounts().join();
/* 147 */         if (null != accountsInCache && !accountsInCache.isEmpty() && null != user && !user.isEmpty()) {
/* 148 */           IAccount account = getAccountByUsername(accountsInCache, user);
/* 149 */           if (null != account) {
/* 150 */             if (logger.isLoggable(Level.FINE)) {
/* 151 */               logger.fine(logger.toString() + "Silent authentication for user:" + logger.toString());
/*     */             }
/*     */             
/* 154 */             SilentParameters silentParameters = SilentParameters.builder(Collections.singleton(fedAuthInfo.spn + "/.default"), account).build();
/*     */             
/* 156 */             future = pca.acquireTokenSilently(silentParameters);
/*     */           } 
/*     */         } 
/* 159 */       } catch (MsalInteractionRequiredException msalInteractionRequiredException) {}
/*     */ 
/*     */ 
/*     */       
/* 163 */       if (null != future) {
/* 164 */         authenticationResult = future.get();
/*     */       } else {
/*     */         
/* 167 */         if (logger.isLoggable(Level.FINE)) {
/* 168 */           logger.fine(logger.toString() + "Interactive authentication");
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 173 */         InteractiveRequestParameters parameters = InteractiveRequestParameters.builder(new URI("http://localhost")).systemBrowserOptions(SystemBrowserOptions.builder().htmlMessageSuccess(SQLServerResource.getResource("R_MSALAuthComplete")).build()).loginHint(user).scopes(Collections.singleton(fedAuthInfo.spn + "/.default")).build();
/*     */         
/* 175 */         future = pca.acquireToken(parameters);
/* 176 */         authenticationResult = future.get();
/*     */       } 
/*     */       
/* 179 */       return new SqlFedAuthToken(authenticationResult.accessToken(), authenticationResult.expiresOnDate());
/* 180 */     } catch (MalformedURLException|InterruptedException|java.net.URISyntaxException e) {
/* 181 */       throw new SQLServerException(e.getMessage(), e);
/* 182 */     } catch (ExecutionException e) {
/* 183 */       throw getCorrectedException(e, user, authenticationString);
/*     */     } finally {
/* 185 */       executorService.shutdown();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static IAccount getAccountByUsername(Set<IAccount> accounts, String username) {
/* 191 */     if (!accounts.isEmpty()) {
/* 192 */       for (IAccount account : accounts) {
/* 193 */         if (account.username().equals(username)) {
/* 194 */           return account;
/*     */         }
/*     */       } 
/*     */     }
/* 198 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private static SQLServerException getCorrectedException(ExecutionException e, String user, String authenticationString) {
/* 203 */     if (logger.isLoggable(Level.SEVERE)) {
/* 204 */       logger.fine(logger.toString() + " MSAL exception:" + logger.toString());
/*     */     }
/*     */     
/* 207 */     MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_MSALExecution"));
/* 208 */     Object[] msgArgs = { user, authenticationString };
/*     */     
/* 210 */     if (null == e.getCause() || null == e.getCause().getMessage())
/*     */     {
/* 212 */       return new SQLServerException(form.format(msgArgs), null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 218 */     String correctedErrorMessage = e.getCause().getMessage().replaceAll("\\\\r\\\\n", "\r\n");
/* 219 */     RuntimeException correctedAuthenticationException = new RuntimeException(correctedErrorMessage);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 225 */     ExecutionException correctedExecutionException = new ExecutionException(correctedAuthenticationException);
/*     */     
/* 227 */     return new SQLServerException(form.format(msgArgs), null, 0, correctedExecutionException);
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerMSAL4JUtils.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */