/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ServerPortPlaceHolder
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 7393779415545731523L;
/*     */   private final String serverName;
/*     */   private final int port;
/*     */   private final String instanceName;
/*     */   private final boolean checkLink;
/*     */   private final SQLServerConnectionSecurityManager securityManager;
/*     */   
/*     */   ServerPortPlaceHolder(String name, int conPort, String instance, boolean fLink) {
/* 130 */     this.serverName = name;
/* 131 */     this.port = conPort;
/* 132 */     this.instanceName = instance;
/* 133 */     this.checkLink = fLink;
/* 134 */     this.securityManager = new SQLServerConnectionSecurityManager(this.serverName, this.port);
/* 135 */     doSecurityCheck();
/*     */   }
/*     */ 
/*     */   
/*     */   int getPortNumber() {
/* 140 */     return this.port;
/*     */   }
/*     */   
/*     */   String getServerName() {
/* 144 */     return this.serverName;
/*     */   }
/*     */   
/*     */   String getInstanceName() {
/* 148 */     return this.instanceName;
/*     */   }
/*     */   
/*     */   void doSecurityCheck() {
/* 152 */     this.securityManager.checkConnect();
/* 153 */     if (this.checkLink)
/* 154 */       this.securityManager.checkLink(); 
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\ServerPortPlaceHolder.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */