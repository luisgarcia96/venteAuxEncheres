/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.logging.Level;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class FailoverMapSingleton
/*    */ {
/* 13 */   private static int initialHashmapSize = 5;
/* 14 */   private static HashMap<String, FailoverInfo> failoverMap = new HashMap<>(initialHashmapSize);
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static String concatPrimaryDatabase(String primary, String instance, String database) {
/* 20 */     StringBuilder buf = new StringBuilder();
/* 21 */     buf.append(primary);
/* 22 */     if (null != instance) {
/* 23 */       buf.append("\\");
/* 24 */       buf.append(instance);
/*    */     } 
/* 26 */     buf.append(";");
/* 27 */     buf.append(database);
/* 28 */     return buf.toString();
/*    */   }
/*    */ 
/*    */   
/*    */   static FailoverInfo getFailoverInfo(SQLServerConnection connection, String primaryServer, String instance, String database) {
/* 33 */     synchronized (FailoverMapSingleton.class) {
/* 34 */       if (failoverMap.isEmpty()) {
/* 35 */         return null;
/*    */       }
/* 37 */       String mapKey = concatPrimaryDatabase(primaryServer, instance, database);
/* 38 */       if (connection.getConnectionLogger().isLoggable(Level.FINER))
/* 39 */         connection.getConnectionLogger()
/* 40 */           .finer(connection.toString() + " Looking up info in the map using key: " + connection.toString()); 
/* 41 */       FailoverInfo fo = failoverMap.get(mapKey);
/* 42 */       if (null != fo)
/* 43 */         fo.log(connection); 
/* 44 */       return fo;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static void putFailoverInfo(SQLServerConnection connection, String primaryServer, String instance, String database, FailoverInfo actualFailoverInfo, boolean actualuseFailover, String failoverPartner) throws SQLServerException {
/* 57 */     synchronized (FailoverMapSingleton.class) {
/*    */       FailoverInfo fo;
/* 59 */       if (null == (fo = getFailoverInfo(connection, primaryServer, instance, database))) {
/* 60 */         if (connection.getConnectionLogger().isLoggable(Level.FINE)) {
/* 61 */           connection.getConnectionLogger().fine(connection.toString() + " Failover map add server: " + connection.toString() + "; database:" + primaryServer + "; Mirror:" + database);
/*    */         }
/* 63 */         failoverMap.put(concatPrimaryDatabase(primaryServer, instance, database), actualFailoverInfo);
/*    */       } else {
/*    */         
/* 66 */         fo.failoverAdd(connection, actualuseFailover, failoverPartner);
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\FailoverMapSingleton.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */