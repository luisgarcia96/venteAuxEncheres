/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import com.microsoft.sqlserver.jdbc.dataclassification.ColumnSensitivity;
/*     */ import com.microsoft.sqlserver.jdbc.dataclassification.InformationType;
/*     */ import com.microsoft.sqlserver.jdbc.dataclassification.Label;
/*     */ import com.microsoft.sqlserver.jdbc.dataclassification.SensitivityClassification;
/*     */ import com.microsoft.sqlserver.jdbc.dataclassification.SensitivityProperty;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class StreamColumns
/*     */   extends StreamPacket
/*     */ {
/*     */   private Column[] columns;
/*  29 */   private CekTable cekTable = null;
/*     */   
/*     */   private boolean shouldHonorAEForRead = false;
/*     */   
/*     */   private boolean sensitivityRankSupported = false;
/*     */ 
/*     */   
/*     */   CekTable getCekTable() {
/*  37 */     return this.cekTable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   StreamColumns() {
/*  44 */     super(129);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   StreamColumns(boolean honorAE) {
/*  51 */     super(129);
/*  52 */     this.shouldHonorAEForRead = honorAE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   CekTableEntry readCEKTableEntry(TDSReader tdsReader) throws SQLServerException {
/*  62 */     int databaseId = tdsReader.readInt();
/*     */ 
/*     */     
/*  65 */     int cekId = tdsReader.readInt();
/*     */ 
/*     */     
/*  68 */     int cekVersion = tdsReader.readInt();
/*     */ 
/*     */     
/*  71 */     byte[] cekMdVersion = new byte[8];
/*  72 */     tdsReader.readBytes(cekMdVersion, 0, 8);
/*     */ 
/*     */     
/*  75 */     int cekValueCount = tdsReader.readUnsignedByte();
/*     */     
/*  77 */     CekTableEntry cekTableEntry = new CekTableEntry(cekValueCount);
/*     */     
/*  79 */     for (int i = 0; i < cekValueCount; i++) {
/*     */       
/*  81 */       short encryptedCEKlength = tdsReader.readShort();
/*     */       
/*  83 */       byte[] encryptedCek = new byte[encryptedCEKlength];
/*     */ 
/*     */       
/*  86 */       tdsReader.readBytes(encryptedCek, 0, encryptedCEKlength);
/*     */ 
/*     */       
/*  89 */       int keyStoreLength = tdsReader.readUnsignedByte();
/*     */ 
/*     */       
/*  92 */       String keyStoreName = tdsReader.readUnicodeString(keyStoreLength);
/*     */ 
/*     */       
/*  95 */       int keyPathLength = tdsReader.readShort();
/*     */ 
/*     */       
/*  98 */       String keyPath = tdsReader.readUnicodeString(keyPathLength);
/*     */ 
/*     */       
/* 101 */       int algorithmLength = tdsReader.readUnsignedByte();
/*     */ 
/*     */       
/* 104 */       String algorithmName = tdsReader.readUnicodeString(algorithmLength);
/*     */ 
/*     */       
/* 107 */       cekTableEntry.add(encryptedCek, databaseId, cekId, cekVersion, cekMdVersion, keyPath, keyStoreName, algorithmName);
/*     */     } 
/*     */     
/* 110 */     return cekTableEntry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void readCEKTable(TDSReader tdsReader) throws SQLServerException {
/* 120 */     int tableSize = tdsReader.readShort();
/*     */ 
/*     */ 
/*     */     
/* 124 */     if (0 != tableSize) {
/* 125 */       this.cekTable = new CekTable(tableSize);
/*     */ 
/*     */       
/* 128 */       for (int i = 0; i < tableSize; i++)
/*     */       {
/* 130 */         this.cekTable.setCekTableEntry(i, readCEKTableEntry(tdsReader));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   CryptoMetadata readCryptoMetadata(TDSReader tdsReader) throws SQLServerException {
/* 141 */     short ordinal = 0;
/*     */     
/* 143 */     if (null != this.cekTable) {
/* 144 */       ordinal = tdsReader.readShort();
/*     */     }
/*     */     
/* 147 */     TypeInfo typeInfo = TypeInfo.getInstance(tdsReader, false);
/*     */ 
/*     */     
/* 150 */     byte algorithmId = (byte)tdsReader.readUnsignedByte();
/*     */     
/* 152 */     String algorithmName = null;
/* 153 */     if (0 == algorithmId) {
/*     */       
/* 155 */       int nameSize = tdsReader.readUnsignedByte();
/* 156 */       algorithmName = tdsReader.readUnicodeString(nameSize);
/*     */     } 
/*     */ 
/*     */     
/* 160 */     byte encryptionType = (byte)tdsReader.readUnsignedByte();
/*     */ 
/*     */     
/* 163 */     byte normalizationRuleVersion = (byte)tdsReader.readUnsignedByte();
/*     */     
/* 165 */     CryptoMetadata cryptoMeta = new CryptoMetadata((this.cekTable == null) ? null : this.cekTable.getCekTableEntry(ordinal), ordinal, algorithmId, algorithmName, encryptionType, normalizationRuleVersion);
/*     */     
/* 167 */     cryptoMeta.setBaseTypeInfo(typeInfo);
/*     */     
/* 169 */     return cryptoMeta;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setFromTDS(TDSReader tdsReader) throws SQLServerException {
/* 178 */     if (129 != tdsReader.readUnsignedByte() && 
/* 179 */       !$assertionsDisabled) throw new AssertionError();
/*     */     
/* 181 */     int nTotColumns = tdsReader.readUnsignedShort();
/*     */ 
/*     */     
/* 184 */     if (65535 == nTotColumns) {
/*     */       return;
/*     */     }
/* 187 */     if (tdsReader.getServerSupportsColumnEncryption()) {
/* 188 */       readCEKTable(tdsReader);
/*     */     }
/*     */     
/* 191 */     this.columns = new Column[nTotColumns];
/*     */     
/* 193 */     for (int numColumns = 0; numColumns < nTotColumns; numColumns++) {
/*     */       
/* 195 */       TypeInfo typeInfo = TypeInfo.getInstance(tdsReader, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 201 */       SQLIdentifier tableName = new SQLIdentifier();
/* 202 */       if (SSType.TEXT == typeInfo.getSSType() || SSType.NTEXT == typeInfo.getSSType() || SSType.IMAGE == typeInfo
/* 203 */         .getSSType())
/*     */       {
/* 205 */         tableName = tdsReader.readSQLIdentifier();
/*     */       }
/*     */       
/* 208 */       CryptoMetadata cryptoMeta = null;
/* 209 */       if (tdsReader.getServerSupportsColumnEncryption() && typeInfo.isEncrypted()) {
/* 210 */         cryptoMeta = readCryptoMetadata(tdsReader);
/* 211 */         cryptoMeta.baseTypeInfo.setFlags(Short.valueOf(typeInfo.getFlagsAsShort()));
/* 212 */         typeInfo.setSQLCollation(cryptoMeta.baseTypeInfo.getSQLCollation());
/*     */       } 
/*     */ 
/*     */       
/* 216 */       String columnName = tdsReader.readUnicodeString(tdsReader.readUnsignedByte());
/*     */       
/* 218 */       if (this.shouldHonorAEForRead) {
/* 219 */         this.columns[numColumns] = new Column(typeInfo, columnName, tableName, cryptoMeta);
/*     */       }
/*     */       else {
/*     */         
/* 223 */         this.columns[numColumns] = new Column(typeInfo, columnName, tableName, null);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 228 */     if (tdsReader.getServerSupportsDataClassification() && tdsReader
/* 229 */       .peekTokenType() == 163)
/*     */     {
/* 231 */       tdsReader.trySetSensitivityClassification(processDataClassification(tdsReader));
/*     */     }
/*     */   }
/*     */   
/*     */   private String readByteString(TDSReader tdsReader) throws SQLServerException {
/* 236 */     String value = "";
/* 237 */     int byteLen = tdsReader.readUnsignedByte();
/* 238 */     value = tdsReader.readUnicodeString(byteLen);
/* 239 */     return value;
/*     */   }
/*     */   
/*     */   private Label readSensitivityLabel(TDSReader tdsReader) throws SQLServerException {
/* 243 */     String name = readByteString(tdsReader);
/* 244 */     String id = readByteString(tdsReader);
/* 245 */     return new Label(name, id);
/*     */   }
/*     */   
/*     */   private InformationType readSensitivityInformationType(TDSReader tdsReader) throws SQLServerException {
/* 249 */     String name = readByteString(tdsReader);
/* 250 */     String id = readByteString(tdsReader);
/* 251 */     return new InformationType(name, id);
/*     */   }
/*     */   
/*     */   private SensitivityClassification processDataClassification(TDSReader tdsReader) throws SQLServerException {
/* 255 */     if (!tdsReader.getServerSupportsDataClassification()) {
/* 256 */       tdsReader.throwInvalidTDS();
/*     */     }
/*     */     
/* 259 */     int dataClassificationToken = tdsReader.readUnsignedByte();
/* 260 */     assert dataClassificationToken == 163;
/*     */     
/* 262 */     SensitivityClassification sensitivityClassification = null;
/*     */ 
/*     */     
/* 265 */     int sensitivityLabelCount = tdsReader.readUnsignedShort();
/* 266 */     List<Label> sensitivityLabels = new ArrayList<>(sensitivityLabelCount);
/*     */     
/* 268 */     for (int i = 0; i < sensitivityLabelCount; i++) {
/* 269 */       sensitivityLabels.add(readSensitivityLabel(tdsReader));
/*     */     }
/*     */ 
/*     */     
/* 273 */     int informationTypeCount = tdsReader.readUnsignedShort();
/*     */     
/* 275 */     List<InformationType> informationTypes = new ArrayList<>(informationTypeCount);
/* 276 */     for (int j = 0; j < informationTypeCount; j++) {
/* 277 */       informationTypes.add(readSensitivityInformationType(tdsReader));
/*     */     }
/*     */     
/* 280 */     this
/* 281 */       .sensitivityRankSupported = (tdsReader.getServerSupportedDataClassificationVersion() >= 2);
/*     */ 
/*     */     
/* 284 */     int sensitivityRank = SensitivityClassification.SensitivityRank.NOT_DEFINED.getValue();
/* 285 */     if (this.sensitivityRankSupported) {
/* 286 */       sensitivityRank = tdsReader.readInt();
/* 287 */       if (!SensitivityClassification.SensitivityRank.isValid(sensitivityRank)) {
/* 288 */         tdsReader.throwInvalidTDS();
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 293 */     int numResultSetColumns = tdsReader.readUnsignedShort();
/*     */     
/* 295 */     List<ColumnSensitivity> columnSensitivities = new ArrayList<>(numResultSetColumns);
/* 296 */     for (int columnNum = 0; columnNum < numResultSetColumns; columnNum++) {
/*     */ 
/*     */       
/* 299 */       int numSensitivityProperties = tdsReader.readUnsignedShort();
/* 300 */       List<SensitivityProperty> sensitivityProperties = new ArrayList<>(numSensitivityProperties);
/*     */       
/* 302 */       for (int sourceNum = 0; sourceNum < numSensitivityProperties; sourceNum++) {
/*     */ 
/*     */         
/* 305 */         int sensitivityLabelIndex = tdsReader.readUnsignedShort();
/* 306 */         Label label = null;
/* 307 */         if (sensitivityLabelIndex != Integer.MAX_VALUE) {
/* 308 */           if (sensitivityLabelIndex >= sensitivityLabels.size()) {
/* 309 */             tdsReader.throwInvalidTDS();
/*     */           }
/* 311 */           label = sensitivityLabels.get(sensitivityLabelIndex);
/*     */         } 
/*     */         
/* 314 */         int informationTypeIndex = tdsReader.readUnsignedShort();
/* 315 */         InformationType informationType = null;
/* 316 */         if (informationTypeIndex != Integer.MAX_VALUE) {
/* 317 */           if (informationTypeIndex >= informationTypes.size());
/* 318 */           informationType = informationTypes.get(informationTypeIndex);
/*     */         } 
/*     */         
/* 321 */         int sensitivityRankProperty = SensitivityClassification.SensitivityRank.NOT_DEFINED.getValue();
/* 322 */         if (this.sensitivityRankSupported) {
/* 323 */           sensitivityRankProperty = tdsReader.readInt();
/* 324 */           if (!SensitivityClassification.SensitivityRank.isValid(sensitivityRankProperty)) {
/* 325 */             tdsReader.throwInvalidTDS();
/*     */           }
/*     */           
/* 328 */           sensitivityProperties.add(new SensitivityProperty(label, informationType, sensitivityRankProperty));
/*     */         } else {
/* 330 */           sensitivityProperties.add(new SensitivityProperty(label, informationType));
/*     */         } 
/*     */       } 
/* 333 */       columnSensitivities.add(new ColumnSensitivity(sensitivityProperties));
/*     */     } 
/* 335 */     if (this.sensitivityRankSupported) {
/* 336 */       sensitivityClassification = new SensitivityClassification(sensitivityLabels, informationTypes, columnSensitivities, sensitivityRank);
/*     */     } else {
/*     */       
/* 339 */       sensitivityClassification = new SensitivityClassification(sensitivityLabels, informationTypes, columnSensitivities);
/*     */     } 
/*     */ 
/*     */     
/* 343 */     return sensitivityClassification;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Column[] buildColumns(StreamColInfo colInfoToken, StreamTabName tabNameToken) throws SQLServerException {
/* 351 */     if (null != colInfoToken && null != tabNameToken) {
/* 352 */       tabNameToken.applyTo(this.columns, colInfoToken.applyTo(this.columns));
/*     */     }
/* 354 */     return this.columns;
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\StreamColumns.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */