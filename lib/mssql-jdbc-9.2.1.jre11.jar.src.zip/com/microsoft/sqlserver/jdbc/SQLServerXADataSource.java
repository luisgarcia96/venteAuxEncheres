/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.InvalidObjectException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectStreamException;
/*     */ import java.io.Serializable;
/*     */ import java.sql.SQLException;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.naming.Reference;
/*     */ import javax.sql.XAConnection;
/*     */ import javax.sql.XADataSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SQLServerXADataSource
/*     */   extends SQLServerConnectionPoolDataSource
/*     */   implements XADataSource
/*     */ {
/*  45 */   static Logger xaLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.XA");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XAConnection getXAConnection(String user, String password) throws SQLException {
/*  57 */     if (loggerExternal.isLoggable(Level.FINER)) {
/*  58 */       loggerExternal.entering(getClassNameLogging(), "getXAConnection", new Object[] { user, "Password not traced" });
/*     */     }
/*  60 */     SQLServerXAConnection pooledXAConnection = new SQLServerXAConnection(this, user, password);
/*     */     
/*  62 */     if (xaLogger.isLoggable(Level.FINER)) {
/*  63 */       xaLogger.finer(toString() + " user:" + toString() + user);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  70 */     if (xaLogger.isLoggable(Level.FINER))
/*  71 */       xaLogger.finer(toString() + " Start get physical connection."); 
/*  72 */     SQLServerConnection physicalConnection = pooledXAConnection.getPhysicalConnection();
/*  73 */     if (xaLogger.isLoggable(Level.FINE))
/*  74 */       xaLogger.fine(toString() + " End get physical connection, " + toString()); 
/*  75 */     if (loggerExternal.isLoggable(Level.FINER))
/*  76 */       loggerExternal.exiting(getClassNameLogging(), "getXAConnection", pooledXAConnection); 
/*  77 */     return pooledXAConnection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XAConnection getXAConnection() throws SQLException {
/*  90 */     if (loggerExternal.isLoggable(Level.FINER))
/*  91 */       loggerExternal.entering(getClassNameLogging(), "getXAConnection"); 
/*  92 */     return getXAConnection(getUser(), getPassword());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Reference getReference() {
/*  99 */     if (loggerExternal.isLoggable(Level.FINER))
/* 100 */       loggerExternal.entering(getClassNameLogging(), "getReference"); 
/* 101 */     Reference ref = getReferenceInternal("com.microsoft.sqlserver.jdbc.SQLServerXADataSource");
/* 102 */     if (loggerExternal.isLoggable(Level.FINER))
/* 103 */       loggerExternal.exiting(getClassNameLogging(), "getReference", ref); 
/* 104 */     return ref;
/*     */   }
/*     */   
/*     */   private Object writeReplace() throws ObjectStreamException {
/* 108 */     return new SerializationProxy(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream stream) throws InvalidObjectException {
/* 114 */     throw new InvalidObjectException("");
/*     */   }
/*     */ 
/*     */   
/*     */   private static class SerializationProxy
/*     */     implements Serializable
/*     */   {
/*     */     private final Reference ref;
/*     */     
/*     */     private static final long serialVersionUID = 454661379842314126L;
/*     */ 
/*     */     
/*     */     SerializationProxy(SQLServerXADataSource ds) {
/* 127 */       this.ref = ds.getReferenceInternal(null);
/*     */     }
/*     */     
/*     */     private Object readResolve() {
/* 131 */       SQLServerXADataSource ds = new SQLServerXADataSource();
/* 132 */       ds.initializeFromReference(this.ref);
/* 133 */       return ds;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerXADataSource.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */