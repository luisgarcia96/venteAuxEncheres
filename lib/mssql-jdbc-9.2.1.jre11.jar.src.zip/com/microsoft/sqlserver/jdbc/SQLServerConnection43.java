/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import java.sql.ShardingKey;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SQLServerConnection43
/*    */   extends SQLServerConnection
/*    */   implements ISQLServerConnection43
/*    */ {
/*    */   private static final long serialVersionUID = -6904163521498951547L;
/*    */   
/*    */   SQLServerConnection43(String parentInfo) throws SQLServerException {
/* 25 */     super(parentInfo);
/*    */   }
/*    */ 
/*    */   
/*    */   public void beginRequest() throws SQLException {
/* 30 */     beginRequestInternal();
/*    */   }
/*    */ 
/*    */   
/*    */   public void endRequest() throws SQLException {
/* 35 */     endRequestInternal();
/*    */   }
/*    */ 
/*    */   
/*    */   public void setShardingKey(ShardingKey shardingKey) throws SQLException {
/* 40 */     SQLServerException.throwFeatureNotSupportedException();
/*    */   }
/*    */ 
/*    */   
/*    */   public void setShardingKey(ShardingKey shardingKey, ShardingKey superShardingKey) throws SQLException {
/* 45 */     SQLServerException.throwFeatureNotSupportedException();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean setShardingKeyIfValid(ShardingKey shardingKey, int timeout) throws SQLException {
/* 50 */     SQLServerException.throwFeatureNotSupportedException();
/* 51 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean setShardingKeyIfValid(ShardingKey shardingKey, ShardingKey superShardingKey, int timeout) throws SQLException {
/* 57 */     SQLServerException.throwFeatureNotSupportedException();
/* 58 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerConnection43.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */