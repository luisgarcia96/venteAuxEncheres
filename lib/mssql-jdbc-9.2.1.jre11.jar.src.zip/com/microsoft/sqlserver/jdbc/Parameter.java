/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.BufferedReader;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Date;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.text.MessageFormat;
/*      */ import java.time.LocalDate;
/*      */ import java.time.LocalDateTime;
/*      */ import java.time.LocalTime;
/*      */ import java.time.OffsetDateTime;
/*      */ import java.time.OffsetTime;
/*      */ import java.util.Calendar;
/*      */ import java.util.Date;
/*      */ import java.util.Locale;
/*      */ import microsoft.sql.DateTimeOffset;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class Parameter
/*      */ {
/*      */   private TypeInfo typeInfo;
/*   38 */   CryptoMetadata cryptoMeta = null;
/*      */   
/*      */   TypeInfo getTypeInfo() {
/*   41 */     return this.typeInfo;
/*      */   }
/*      */   
/*      */   final CryptoMetadata getCryptoMetadata() {
/*   45 */     return this.cryptoMeta;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean shouldHonorAEForParameter = false;
/*      */   
/*      */   private boolean userProvidesPrecision = false;
/*      */   private boolean userProvidesScale = false;
/*   53 */   private String typeDefinition = null;
/*      */   
/*      */   boolean renewDefinition = false;
/*      */   
/*   57 */   private JDBCType jdbcTypeSetByUser = null;
/*      */ 
/*      */   
/*   60 */   private int valueLength = 0;
/*      */   
/*      */   private boolean forceEncryption = false;
/*      */   
/*      */   int scale;
/*      */   
/*      */   private int outScale;
/*      */   private String name;
/*      */   
/*      */   boolean isOutput() {
/*   70 */     return (null != this.registeredOutDTV);
/*      */   }
/*      */   private String schemaName; private DTV getterDTV; private DTV registeredOutDTV;
/*      */   private DTV setterDTV;
/*      */   private DTV inputDTV;
/*      */   
/*      */   JDBCType getJdbcType() throws SQLServerException {
/*   77 */     return (null != this.inputDTV) ? this.inputDTV.getJdbcType() : JDBCType.UNKNOWN;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static JDBCType getSSPAUJDBCType(JDBCType jdbcType) {
/*   85 */     switch (jdbcType) {
/*      */       case CHAR:
/*   87 */         return JDBCType.NCHAR;
/*      */       case VARCHAR:
/*   89 */         return JDBCType.NVARCHAR;
/*      */       case LONGVARCHAR:
/*   91 */         return JDBCType.LONGNVARCHAR;
/*      */       case CLOB:
/*   93 */         return JDBCType.NCLOB;
/*      */     } 
/*   95 */     return jdbcType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void registerForOutput(JDBCType jdbcType, SQLServerConnection con) throws SQLServerException {
/*  104 */     if (JDBCType.DATETIMEOFFSET == jdbcType && !con.isKatmaiOrLater()) {
/*  105 */       throw new SQLServerException(SQLServerException.getErrString("R_notSupported"), SQLState.DATA_EXCEPTION_NOT_SPECIFIC, DriverError.NOT_SET, null);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  113 */     if (con.sendStringParametersAsUnicode()) {
/*      */       
/*  115 */       if (this.shouldHonorAEForParameter) {
/*  116 */         setJdbcTypeSetByUser(jdbcType);
/*      */       }
/*      */       
/*  119 */       jdbcType = getSSPAUJDBCType(jdbcType);
/*      */     } 
/*      */     
/*  122 */     this.registeredOutDTV = new DTV();
/*  123 */     this.registeredOutDTV.setJdbcType(jdbcType);
/*      */     
/*  125 */     if (null == this.setterDTV) {
/*  126 */       this.inputDTV = this.registeredOutDTV;
/*      */     }
/*  128 */     resetOutputValue();
/*      */   }
/*      */   Parameter(boolean honorAE) {
/*  131 */     this.scale = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  136 */     this.outScale = 4;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  166 */     this.registeredOutDTV = null;
/*  167 */     this.setterDTV = null;
/*  168 */     this.inputDTV = null;
/*      */     this.shouldHonorAEForParameter = honorAE;
/*      */   }
/*      */   int getOutScale() {
/*      */     return this.outScale;
/*      */   }
/*      */   void setOutScale(int outScale) {
/*      */     this.outScale = outScale;
/*      */     this.userProvidesScale = true;
/*      */   }
/*      */   
/*      */   final Parameter cloneForBatch() {
/*  180 */     Parameter clonedParam = new Parameter(this.shouldHonorAEForParameter);
/*  181 */     clonedParam.typeInfo = this.typeInfo;
/*  182 */     clonedParam.typeDefinition = this.typeDefinition;
/*  183 */     clonedParam.outScale = this.outScale;
/*  184 */     clonedParam.name = this.name;
/*  185 */     clonedParam.getterDTV = this.getterDTV;
/*  186 */     clonedParam.registeredOutDTV = this.registeredOutDTV;
/*  187 */     clonedParam.setterDTV = this.setterDTV;
/*  188 */     clonedParam.inputDTV = this.inputDTV;
/*  189 */     clonedParam.cryptoMeta = this.cryptoMeta;
/*  190 */     clonedParam.jdbcTypeSetByUser = this.jdbcTypeSetByUser;
/*  191 */     clonedParam.valueLength = this.valueLength;
/*  192 */     clonedParam.userProvidesPrecision = this.userProvidesPrecision;
/*  193 */     clonedParam.userProvidesScale = this.userProvidesScale;
/*  194 */     return clonedParam;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void skipValue(TDSReader tdsReader, boolean isDiscard) throws SQLServerException {
/*  201 */     if (null == this.getterDTV) {
/*  202 */       this.getterDTV = new DTV();
/*      */     }
/*  204 */     deriveTypeInfo(tdsReader);
/*      */     
/*  206 */     this.getterDTV.skipValue(this.typeInfo, tdsReader, isDiscard);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void skipRetValStatus(TDSReader tdsReader) throws SQLServerException {
/*  214 */     StreamRetValue srv = new StreamRetValue();
/*  215 */     srv.setFromTDS(tdsReader);
/*      */   }
/*      */ 
/*      */   
/*      */   void clearInputValue() {
/*  220 */     this.setterDTV = null;
/*  221 */     this.inputDTV = this.registeredOutDTV;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void resetOutputValue() {
/*  227 */     this.getterDTV = null;
/*  228 */     this.typeInfo = null;
/*      */   }
/*      */   
/*      */   void deriveTypeInfo(TDSReader tdsReader) throws SQLServerException {
/*  232 */     if (null == this.typeInfo) {
/*  233 */       this.typeInfo = TypeInfo.getInstance(tdsReader, true);
/*      */       
/*  235 */       if (this.shouldHonorAEForParameter && this.typeInfo.isEncrypted()) {
/*      */ 
/*      */         
/*  238 */         CekTableEntry cekEntry = this.cryptoMeta.getCekTableEntry();
/*  239 */         this.cryptoMeta = (new StreamRetValue()).getCryptoMetadata(tdsReader);
/*  240 */         this.cryptoMeta.setCekTableEntry(cekEntry);
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   void setFromReturnStatus(int returnStatus, SQLServerConnection con) throws SQLServerException {
/*  246 */     if (null == this.getterDTV) {
/*  247 */       this.getterDTV = new DTV();
/*      */     }
/*  249 */     this.getterDTV.setValue(null, JDBCType.INTEGER, Integer.valueOf(returnStatus), JavaType.INTEGER, null, null, null, con, 
/*  250 */         getForceEncryption());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setValue(JDBCType jdbcType, Object value, JavaType javaType, StreamSetterArgs streamSetterArgs, Calendar calendar, Integer precision, Integer scale, SQLServerConnection con, boolean forceEncrypt, SQLServerStatementColumnEncryptionSetting stmtColumnEncriptionSetting, int parameterIndex, String userSQL, String tvpName) throws SQLServerException {
/*  258 */     if (this.shouldHonorAEForParameter) {
/*  259 */       this.userProvidesPrecision = false;
/*  260 */       this.userProvidesScale = false;
/*      */       
/*  262 */       if (null != precision) {
/*  263 */         this.userProvidesPrecision = true;
/*      */       }
/*      */       
/*  266 */       if (null != scale) {
/*  267 */         this.userProvidesScale = true;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  274 */       if (!isOutput() && 
/*  275 */         JavaType.SHORT == javaType && (JDBCType.TINYINT == jdbcType || JDBCType.SMALLINT == jdbcType))
/*      */       {
/*      */         
/*  278 */         if (((Short)value).shortValue() >= 0 && ((Short)value).shortValue() <= 255) {
/*  279 */           value = Byte.valueOf(((Short)value).byteValue());
/*  280 */           javaType = JavaType.of(value);
/*  281 */           jdbcType = javaType.getJDBCType(SSType.UNKNOWN, jdbcType);
/*      */ 
/*      */ 
/*      */         
/*      */         }
/*  286 */         else if (JDBCType.TINYINT == jdbcType) {
/*      */           
/*  288 */           MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_InvalidDataForAE"));
/*      */           
/*  290 */           Object[] msgArgs = { javaType.toString().toLowerCase(Locale.ENGLISH), jdbcType.toString().toLowerCase(Locale.ENGLISH) };
/*  291 */           throw new SQLServerException(form.format(msgArgs), null);
/*      */         } 
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  299 */     if (forceEncrypt && !Util.shouldHonorAEForParameters(stmtColumnEncriptionSetting, con)) {
/*      */ 
/*      */       
/*  302 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_ForceEncryptionTrue_HonorAEFalse"));
/*  303 */       Object[] msgArgs = { Integer.valueOf(parameterIndex), userSQL };
/*  304 */       SQLServerException.makeFromDriverError(con, this, form.format(msgArgs), null, true);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  309 */     if ((JDBCType.DATETIMEOFFSET == jdbcType || JavaType.DATETIMEOFFSET == javaType) && !con.isKatmaiOrLater()) {
/*  310 */       throw new SQLServerException(SQLServerException.getErrString("R_notSupported"), SQLState.DATA_EXCEPTION_NOT_SPECIFIC, DriverError.NOT_SET, null);
/*      */     }
/*      */ 
/*      */     
/*  314 */     if (JavaType.TVP == javaType) {
/*      */       TVP tvpValue;
/*  316 */       if (null == value) {
/*  317 */         tvpValue = new TVP(tvpName);
/*  318 */       } else if (value instanceof SQLServerDataTable) {
/*  319 */         tvpValue = new TVP(tvpName, (SQLServerDataTable)value);
/*  320 */       } else if (value instanceof ResultSet) {
/*  321 */         tvpValue = new TVP(tvpName, (ResultSet)value);
/*  322 */       } else if (value instanceof ISQLServerDataRecord) {
/*  323 */         tvpValue = new TVP(tvpName, (ISQLServerDataRecord)value);
/*      */       } else {
/*  325 */         MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_TVPInvalidValue"));
/*  326 */         Object[] msgArgs = { Integer.valueOf(parameterIndex) };
/*  327 */         throw new SQLServerException(form.format(msgArgs), null);
/*      */       } 
/*      */       
/*  330 */       if (!tvpValue.isNull() && 0 == tvpValue.getTVPColumnCount()) {
/*  331 */         throw new SQLServerException(SQLServerException.getErrString("R_TVPEmptyMetadata"), null);
/*      */       }
/*  333 */       this.name = tvpValue.getTVPName();
/*  334 */       this.schemaName = tvpValue.getOwningSchemaNameTVP();
/*      */       
/*  336 */       value = tvpValue;
/*      */     } 
/*      */ 
/*      */     
/*  340 */     if (this.shouldHonorAEForParameter) {
/*  341 */       setForceEncryption(forceEncrypt);
/*      */ 
/*      */       
/*  344 */       if (!isOutput() || this.jdbcTypeSetByUser == null) {
/*  345 */         setJdbcTypeSetByUser(jdbcType);
/*      */       }
/*      */ 
/*      */       
/*  349 */       if ((!jdbcType.isTextual() && !jdbcType.isBinary()) || !isOutput() || this.valueLength == 0) {
/*  350 */         this.valueLength = Util.getValueLengthBaseOnJavaType(value, javaType, precision, scale, jdbcType);
/*      */       }
/*      */       
/*  353 */       if (null != scale) {
/*  354 */         this.outScale = scale.intValue();
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  363 */     if (con.sendStringParametersAsUnicode() && (JavaType.STRING == javaType || JavaType.READER == javaType || JavaType.CLOB == javaType || JavaType.OBJECT == javaType))
/*      */     {
/*  365 */       jdbcType = getSSPAUJDBCType(jdbcType);
/*      */     }
/*      */     
/*  368 */     DTV newDTV = new DTV();
/*  369 */     newDTV.setValue(con.getDatabaseCollation(), jdbcType, value, javaType, streamSetterArgs, calendar, scale, con, forceEncrypt);
/*      */ 
/*      */     
/*  372 */     if (!con.sendStringParametersAsUnicode()) {
/*  373 */       newDTV.sendStringParametersAsUnicode = false;
/*      */     }
/*      */     
/*  376 */     this.inputDTV = this.setterDTV = newDTV;
/*      */   }
/*      */   
/*      */   boolean isNull() {
/*  380 */     if (null != this.getterDTV) {
/*  381 */       return this.getterDTV.isNull();
/*      */     }
/*  383 */     return false;
/*      */   }
/*      */   
/*      */   boolean isValueGotten() {
/*  387 */     return (null != this.getterDTV);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   Object getValue(JDBCType jdbcType, InputStreamGetterArgs getterArgs, Calendar cal, TDSReader tdsReader) throws SQLServerException {
/*  393 */     if (null == this.getterDTV) {
/*  394 */       this.getterDTV = new DTV();
/*      */     }
/*  396 */     deriveTypeInfo(tdsReader);
/*      */ 
/*      */     
/*  399 */     return this.getterDTV.getValue(jdbcType, this.outScale, getterArgs, cal, this.typeInfo, this.cryptoMeta, tdsReader);
/*      */   }
/*      */   
/*      */   Object getSetterValue() {
/*  403 */     return this.setterDTV.getSetterValue();
/*      */   }
/*      */   
/*      */   int getInt(TDSReader tdsReader) throws SQLServerException {
/*  407 */     Integer value = (Integer)getValue(JDBCType.INTEGER, null, null, tdsReader);
/*  408 */     return (null != value) ? value.intValue() : 0;
/*      */   }
/*      */ 
/*      */   
/*      */   final class GetTypeDefinitionOp
/*      */     extends DTVExecuteOp
/*      */   {
/*      */     private static final String NVARCHAR_MAX = "nvarchar(max)";
/*      */     
/*      */     private static final String NVARCHAR_4K = "nvarchar(4000)";
/*      */     
/*      */     private static final String NTEXT = "ntext";
/*      */     
/*      */     private static final String VARCHAR_MAX = "varchar(max)";
/*      */     private static final String VARCHAR_8K = "varchar(8000)";
/*      */     private static final String TEXT = "text";
/*      */     private static final String VARBINARY_MAX = "varbinary(max)";
/*      */     private static final String VARBINARY_8K = "varbinary(8000)";
/*      */     private static final String IMAGE = "image";
/*      */     private final Parameter param;
/*      */     private final SQLServerConnection con;
/*      */     
/*      */     GetTypeDefinitionOp(Parameter param, SQLServerConnection con) {
/*  431 */       this.param = param;
/*  432 */       this.con = con;
/*      */     } private void setTypeDefinition(DTV dtv) {
/*      */       Integer inScale;
/*      */       String schema;
/*  436 */       switch (dtv.getJdbcType()) {
/*      */         case TINYINT:
/*  438 */           this.param.typeDefinition = SSType.TINYINT.toString();
/*      */           return;
/*      */         
/*      */         case SMALLINT:
/*  442 */           this.param.typeDefinition = SSType.SMALLINT.toString();
/*      */           return;
/*      */         
/*      */         case INTEGER:
/*  446 */           this.param.typeDefinition = SSType.INTEGER.toString();
/*      */           return;
/*      */         
/*      */         case BIGINT:
/*  450 */           this.param.typeDefinition = SSType.BIGINT.toString();
/*      */           return;
/*      */ 
/*      */         
/*      */         case REAL:
/*  455 */           if (this.param.shouldHonorAEForParameter && null != Parameter.this.jdbcTypeSetByUser && (null != this.param
/*  456 */             .getCryptoMetadata() || !this.param.renewDefinition)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  463 */             this.param.typeDefinition = SSType.REAL.toString();
/*      */           } else {
/*      */             
/*  466 */             this.param.typeDefinition = SSType.FLOAT.toString();
/*      */           } 
/*      */           return;
/*      */         
/*      */         case FLOAT:
/*      */         case DOUBLE:
/*  472 */           this.param.typeDefinition = SSType.FLOAT.toString();
/*      */           return;
/*      */ 
/*      */         
/*      */         case DECIMAL:
/*      */         case NUMERIC:
/*  478 */           if (Parameter.this.scale > 38) {
/*  479 */             Parameter.this.scale = 38;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  485 */           inScale = dtv.getScale();
/*  486 */           if (null != inScale && Parameter.this.scale < inScale.intValue()) {
/*  487 */             Parameter.this.scale = inScale.intValue();
/*      */           }
/*  489 */           if (this.param.isOutput() && Parameter.this.scale < this.param.getOutScale()) {
/*  490 */             Parameter.this.scale = this.param.getOutScale();
/*      */           }
/*  492 */           if (this.param.shouldHonorAEForParameter && null != Parameter.this.jdbcTypeSetByUser && (null != this.param
/*  493 */             .getCryptoMetadata() || !this.param.renewDefinition)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  500 */             if (0 == Parameter.this.valueLength) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  507 */               if (!Parameter.this.isOutput()) {
/*  508 */                 this.param.typeDefinition = "decimal(18, " + Parameter.this.scale + ")";
/*      */               
/*      */               }
/*      */             }
/*  512 */             else if (18 >= Parameter.this.valueLength) {
/*  513 */               this.param.typeDefinition = "decimal(18," + Parameter.this.scale + ")";
/*      */ 
/*      */               
/*  516 */               if (18 < Parameter.this.valueLength + Parameter.this.scale) {
/*  517 */                 this.param.typeDefinition = "decimal(" + 18 + Parameter.this.scale + "," + Parameter.this.scale + ")";
/*      */               }
/*      */             } else {
/*      */               
/*  521 */               this.param.typeDefinition = "decimal(38," + Parameter.this.scale + ")";
/*      */             } 
/*      */ 
/*      */ 
/*      */             
/*  526 */             if (Parameter.this.isOutput()) {
/*  527 */               this.param.typeDefinition = "decimal(38, " + Parameter.this.scale + ")";
/*      */             }
/*      */ 
/*      */             
/*  531 */             if (Parameter.this.userProvidesPrecision) {
/*  532 */               this.param.typeDefinition = "decimal(" + Parameter.this.valueLength + "," + Parameter.this.scale + ")";
/*      */             }
/*      */           } else {
/*  535 */             this.param.typeDefinition = "decimal(38," + Parameter.this.scale + ")";
/*      */           } 
/*      */           return;
/*      */         
/*      */         case MONEY:
/*  540 */           this.param.typeDefinition = SSType.MONEY.toString();
/*      */           return;
/*      */         case SMALLMONEY:
/*  543 */           this.param.typeDefinition = SSType.MONEY.toString();
/*      */           
/*  545 */           if (this.param.shouldHonorAEForParameter && (null != this.param
/*  546 */             .getCryptoMetadata() || !this.param.renewDefinition)) {
/*  547 */             this.param.typeDefinition = SSType.SMALLMONEY.toString();
/*      */           }
/*      */           return;
/*      */         
/*      */         case BIT:
/*      */         case BOOLEAN:
/*  553 */           this.param.typeDefinition = SSType.BIT.toString();
/*      */           return;
/*      */         
/*      */         case LONGVARBINARY:
/*      */         case BLOB:
/*  558 */           this.param.typeDefinition = "varbinary(max)";
/*      */           return;
/*      */ 
/*      */         
/*      */         case BINARY:
/*      */         case VARBINARY:
/*  564 */           if (!"varbinary(max)".equals(this.param.typeDefinition) && !"image".equals(this.param.typeDefinition))
/*      */           {
/*  566 */             if (this.param.shouldHonorAEForParameter && null != Parameter.this.jdbcTypeSetByUser && (null != this.param
/*  567 */               .getCryptoMetadata() || !this.param.renewDefinition)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  574 */               if (0 == Parameter.this.valueLength) {
/*      */                 
/*  576 */                 this.param.typeDefinition = "varbinary(1)";
/*  577 */                 Parameter.this.valueLength++;
/*      */               } else {
/*  579 */                 this.param.typeDefinition = "varbinary(" + Parameter.this.valueLength + ")";
/*      */               } 
/*      */               
/*  582 */               if (JDBCType.LONGVARBINARY == Parameter.this.jdbcTypeSetByUser) {
/*  583 */                 this.param.typeDefinition = "varbinary(max)";
/*      */               }
/*      */             } else {
/*  586 */               this.param.typeDefinition = "varbinary(8000)";
/*      */             } 
/*      */           }
/*      */           return;
/*      */         case DATE:
/*  591 */           this.param.typeDefinition = this.con.isKatmaiOrLater() ? SSType.DATE.toString() : SSType.DATETIME.toString();
/*      */           return;
/*      */         
/*      */         case TIME:
/*  595 */           if (this.param.shouldHonorAEForParameter && (null != this.param
/*  596 */             .getCryptoMetadata() || !this.param.renewDefinition)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  605 */             if (Parameter.this.userProvidesScale) {
/*  606 */               this.param.typeDefinition = SSType.TIME.toString() + "(" + SSType.TIME.toString() + ")";
/*      */             } else {
/*  608 */               this.param.typeDefinition = SSType.TIME.toString() + "(" + SSType.TIME.toString() + ")";
/*      */             } 
/*      */           } else {
/*  611 */             this.param
/*  612 */               .typeDefinition = this.con.getSendTimeAsDatetime() ? SSType.DATETIME.toString() : SSType.TIME.toString();
/*      */           } 
/*      */           return;
/*      */ 
/*      */ 
/*      */         
/*      */         case TIMESTAMP:
/*  619 */           if (this.param.shouldHonorAEForParameter && (null != this.param
/*  620 */             .getCryptoMetadata() || !this.param.renewDefinition)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  627 */             if (Parameter.this.userProvidesScale) {
/*  628 */               this.param
/*      */                 
/*  630 */                 .typeDefinition = this.con.isKatmaiOrLater() ? (SSType.DATETIME2.toString() + "(" + SSType.DATETIME2.toString() + ")") : SSType.DATETIME.toString();
/*      */             } else {
/*  632 */               this.param
/*      */ 
/*      */                 
/*  635 */                 .typeDefinition = this.con.isKatmaiOrLater() ? (SSType.DATETIME2.toString() + "(" + SSType.DATETIME2.toString() + ")") : SSType.DATETIME.toString();
/*      */             } 
/*      */           } else {
/*  638 */             this.param
/*  639 */               .typeDefinition = this.con.isKatmaiOrLater() ? SSType.DATETIME2.toString() : SSType.DATETIME.toString();
/*      */           } 
/*      */           return;
/*      */ 
/*      */         
/*      */         case DATETIME:
/*  645 */           this.param.typeDefinition = SSType.DATETIME2.toString();
/*      */           
/*  647 */           if (this.param.shouldHonorAEForParameter && (null != this.param
/*  648 */             .getCryptoMetadata() || !this.param.renewDefinition)) {
/*  649 */             this.param.typeDefinition = SSType.DATETIME.toString();
/*      */           }
/*      */           
/*  652 */           if (!this.param.shouldHonorAEForParameter) {
/*      */ 
/*      */             
/*  655 */             if (this.param.isOutput()) {
/*  656 */               this.param.typeDefinition = SSType.DATETIME2.toString() + "(" + SSType.DATETIME2.toString() + ")";
/*      */ 
/*      */             
/*      */             }
/*      */           
/*      */           }
/*  662 */           else if (null == this.param.getCryptoMetadata() && this.param.renewDefinition && 
/*  663 */             this.param.isOutput()) {
/*  664 */             this.param.typeDefinition = SSType.DATETIME2.toString() + "(" + SSType.DATETIME2.toString() + ")";
/*      */           } 
/*      */           return;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case SMALLDATETIME:
/*  672 */           this.param.typeDefinition = SSType.DATETIME2.toString();
/*      */           
/*  674 */           if (this.param.shouldHonorAEForParameter && (null != this.param
/*  675 */             .getCryptoMetadata() || !this.param.renewDefinition)) {
/*  676 */             this.param.typeDefinition = SSType.SMALLDATETIME.toString();
/*      */           }
/*      */           return;
/*      */ 
/*      */         
/*      */         case TIME_WITH_TIMEZONE:
/*      */         case TIMESTAMP_WITH_TIMEZONE:
/*      */         case DATETIMEOFFSET:
/*  684 */           if (this.param.shouldHonorAEForParameter && (null != this.param
/*  685 */             .getCryptoMetadata() || !this.param.renewDefinition)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  692 */             if (Parameter.this.userProvidesScale) {
/*  693 */               this.param.typeDefinition = SSType.DATETIMEOFFSET.toString() + "(" + SSType.DATETIMEOFFSET.toString() + ")";
/*      */             } else {
/*  695 */               this.param.typeDefinition = SSType.DATETIMEOFFSET.toString() + "(" + SSType.DATETIMEOFFSET.toString() + ")";
/*      */             } 
/*      */           } else {
/*  698 */             this.param.typeDefinition = SSType.DATETIMEOFFSET.toString();
/*      */           } 
/*      */           return;
/*      */         
/*      */         case LONGVARCHAR:
/*      */         case CLOB:
/*  704 */           this.param.typeDefinition = "varchar(max)";
/*      */           return;
/*      */ 
/*      */         
/*      */         case CHAR:
/*      */         case VARCHAR:
/*  710 */           if (!"varchar(max)".equals(this.param.typeDefinition) && !"text".equals(this.param.typeDefinition))
/*      */           {
/*      */ 
/*      */             
/*  714 */             if (this.param.shouldHonorAEForParameter && null != Parameter.this.jdbcTypeSetByUser && (null != this.param
/*  715 */               .getCryptoMetadata() || !this.param.renewDefinition)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  722 */               if (0 == Parameter.this.valueLength) {
/*      */                 
/*  724 */                 this.param.typeDefinition = "varchar(1)";
/*  725 */                 Parameter.this.valueLength++;
/*      */               } else {
/*  727 */                 this.param.typeDefinition = "varchar(" + Parameter.this.valueLength + ")";
/*      */                 
/*  729 */                 if (8000 <= Parameter.this.valueLength) {
/*  730 */                   this.param.typeDefinition = "varchar(max)";
/*      */                 }
/*      */               } 
/*      */             } else {
/*  734 */               this.param.typeDefinition = "varchar(8000)";
/*      */             }  } 
/*      */           return;
/*      */         case LONGNVARCHAR:
/*  738 */           if (this.param.shouldHonorAEForParameter && (null != this.param
/*  739 */             .getCryptoMetadata() || !this.param.renewDefinition)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  746 */             if (null != Parameter.this.jdbcTypeSetByUser && (Parameter.this.jdbcTypeSetByUser == JDBCType.VARCHAR || Parameter.this.jdbcTypeSetByUser == JDBCType.CHAR || Parameter.this.jdbcTypeSetByUser == JDBCType.LONGVARCHAR)) {
/*      */ 
/*      */               
/*  749 */               if (0 == Parameter.this.valueLength) {
/*      */                 
/*  751 */                 this.param.typeDefinition = "varchar(1)";
/*  752 */                 Parameter.this.valueLength++;
/*  753 */               } else if (8000 < Parameter.this.valueLength) {
/*  754 */                 this.param.typeDefinition = "varchar(max)";
/*      */               } else {
/*  756 */                 this.param.typeDefinition = "varchar(" + Parameter.this.valueLength + ")";
/*      */               } 
/*      */               
/*  759 */               if (Parameter.this.jdbcTypeSetByUser == JDBCType.LONGVARCHAR) {
/*  760 */                 this.param.typeDefinition = "varchar(max)";
/*      */               }
/*  762 */             } else if (null != Parameter.this.jdbcTypeSetByUser && (Parameter.this.jdbcTypeSetByUser == JDBCType.NVARCHAR || Parameter.this.jdbcTypeSetByUser == JDBCType.LONGNVARCHAR)) {
/*      */               
/*  764 */               if (0 == Parameter.this.valueLength) {
/*      */                 
/*  766 */                 this.param.typeDefinition = "nvarchar(1)";
/*  767 */                 Parameter.this.valueLength++;
/*  768 */               } else if (4000 < Parameter.this.valueLength) {
/*  769 */                 this.param.typeDefinition = "nvarchar(max)";
/*      */               } else {
/*  771 */                 this.param.typeDefinition = "nvarchar(" + Parameter.this.valueLength + ")";
/*      */               } 
/*      */               
/*  774 */               if (Parameter.this.jdbcTypeSetByUser == JDBCType.LONGNVARCHAR) {
/*  775 */                 this.param.typeDefinition = "nvarchar(max)";
/*      */               }
/*      */             }
/*  778 */             else if (0 == Parameter.this.valueLength) {
/*      */               
/*  780 */               this.param.typeDefinition = "nvarchar(1)";
/*  781 */               Parameter.this.valueLength++;
/*      */             } else {
/*  783 */               this.param.typeDefinition = "nvarchar(" + Parameter.this.valueLength + ")";
/*      */               
/*  785 */               if (8000 <= Parameter.this.valueLength) {
/*  786 */                 this.param.typeDefinition = "nvarchar(max)";
/*      */               }
/*      */             }
/*      */           
/*      */           } else {
/*      */             
/*  792 */             this.param.typeDefinition = "nvarchar(max)";
/*      */           } 
/*      */           return;
/*      */ 
/*      */         
/*      */         case NCLOB:
/*  798 */           this.param.typeDefinition = "nvarchar(max)";
/*      */           return;
/*      */ 
/*      */         
/*      */         case NCHAR:
/*      */         case NVARCHAR:
/*  804 */           if (!"nvarchar(max)".equals(this.param.typeDefinition) && !"ntext".equals(this.param.typeDefinition))
/*      */           {
/*      */             
/*  807 */             if (this.param.shouldHonorAEForParameter && (null != this.param
/*  808 */               .getCryptoMetadata() || !this.param.renewDefinition)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  815 */               if (null != Parameter.this.jdbcTypeSetByUser && (Parameter.this.jdbcTypeSetByUser == JDBCType.VARCHAR || Parameter.this.jdbcTypeSetByUser == JDBCType.CHAR || JDBCType.LONGVARCHAR == Parameter.this.jdbcTypeSetByUser)) {
/*      */ 
/*      */                 
/*  818 */                 if (0 == Parameter.this.valueLength) {
/*      */                   
/*  820 */                   this.param.typeDefinition = "varchar(1)";
/*  821 */                   Parameter.this.valueLength++;
/*      */                 } else {
/*  823 */                   this.param.typeDefinition = "varchar(" + Parameter.this.valueLength + ")";
/*      */                   
/*  825 */                   if (8000 < Parameter.this.valueLength) {
/*  826 */                     this.param.typeDefinition = "varchar(max)";
/*      */                   }
/*      */                 } 
/*      */                 
/*  830 */                 if (JDBCType.LONGVARCHAR == Parameter.this.jdbcTypeSetByUser) {
/*  831 */                   this.param.typeDefinition = "varchar(max)";
/*      */                 }
/*  833 */               } else if (null != Parameter.this.jdbcTypeSetByUser && (Parameter.this.jdbcTypeSetByUser == JDBCType.NVARCHAR || Parameter.this.jdbcTypeSetByUser == JDBCType.NCHAR || JDBCType.LONGNVARCHAR == Parameter.this.jdbcTypeSetByUser)) {
/*      */ 
/*      */                 
/*  836 */                 if (0 == Parameter.this.valueLength) {
/*      */                   
/*  838 */                   this.param.typeDefinition = "nvarchar(1)";
/*  839 */                   Parameter.this.valueLength++;
/*      */                 } else {
/*  841 */                   this.param.typeDefinition = "nvarchar(" + Parameter.this.valueLength + ")";
/*      */                   
/*  843 */                   if (8000 <= Parameter.this.valueLength) {
/*  844 */                     this.param.typeDefinition = "nvarchar(max)";
/*      */                   }
/*      */                 } 
/*      */                 
/*  848 */                 if (JDBCType.LONGNVARCHAR == Parameter.this.jdbcTypeSetByUser) {
/*  849 */                   this.param.typeDefinition = "nvarchar(max)";
/*      */                 }
/*      */               }
/*  852 */               else if (0 == Parameter.this.valueLength) {
/*      */                 
/*  854 */                 this.param.typeDefinition = "nvarchar(1)";
/*  855 */                 Parameter.this.valueLength++;
/*      */               } else {
/*  857 */                 this.param.typeDefinition = "nvarchar(" + Parameter.this.valueLength + ")";
/*      */                 
/*  859 */                 if (8000 <= Parameter.this.valueLength) {
/*  860 */                   this.param.typeDefinition = "nvarchar(max)";
/*      */                 }
/*      */               }
/*      */             
/*      */             } else {
/*      */               
/*  866 */               this.param.typeDefinition = "nvarchar(4000)";
/*      */             }  }  return;
/*      */         case SQLXML:
/*  869 */           this.param.typeDefinition = SSType.XML.toString();
/*      */           return;
/*      */ 
/*      */         
/*      */         case TVP:
/*  874 */           schema = this.param.schemaName;
/*      */           
/*  876 */           if (null != schema) {
/*  877 */             this.param.typeDefinition = "[" + schema + "].[" + this.param.name + "] READONLY";
/*      */           } else {
/*  879 */             this.param.typeDefinition = "[" + this.param.name + "] READONLY";
/*      */           } 
/*      */           return;
/*      */ 
/*      */         
/*      */         case GUID:
/*  885 */           this.param.typeDefinition = SSType.GUID.toString();
/*      */           return;
/*      */         
/*      */         case SQL_VARIANT:
/*  889 */           this.param.typeDefinition = SSType.SQL_VARIANT.toString();
/*      */           return;
/*      */         
/*      */         case GEOMETRY:
/*  893 */           this.param.typeDefinition = SSType.GEOMETRY.toString();
/*      */           return;
/*      */         
/*      */         case GEOGRAPHY:
/*  897 */           this.param.typeDefinition = SSType.GEOGRAPHY.toString();
/*      */           return;
/*      */       } 
/*  900 */       assert false : "Unexpected JDBC type " + dtv.getJdbcType();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     void execute(DTV dtv, String strValue) throws SQLServerException {
/*  906 */       if (null != strValue && strValue.length() > 4000) {
/*  907 */         dtv.setJdbcType(JDBCType.LONGNVARCHAR);
/*      */       }
/*  909 */       setTypeDefinition(dtv);
/*      */     }
/*      */     
/*      */     void execute(DTV dtv, Clob clobValue) throws SQLServerException {
/*  913 */       setTypeDefinition(dtv);
/*      */     }
/*      */     
/*      */     void execute(DTV dtv, Byte byteValue) throws SQLServerException {
/*  917 */       setTypeDefinition(dtv);
/*      */     }
/*      */     
/*      */     void execute(DTV dtv, Integer intValue) throws SQLServerException {
/*  921 */       setTypeDefinition(dtv);
/*      */     }
/*      */     
/*      */     void execute(DTV dtv, Time timeValue) throws SQLServerException {
/*  925 */       setTypeDefinition(dtv);
/*      */     }
/*      */     
/*      */     void execute(DTV dtv, Date dateValue) throws SQLServerException {
/*  929 */       setTypeDefinition(dtv);
/*      */     }
/*      */     
/*      */     void execute(DTV dtv, Timestamp timestampValue) throws SQLServerException {
/*  933 */       setTypeDefinition(dtv);
/*      */     }
/*      */     
/*      */     void execute(DTV dtv, Date utildateValue) throws SQLServerException {
/*  937 */       setTypeDefinition(dtv);
/*      */     }
/*      */     
/*      */     void execute(DTV dtv, Calendar calendarValue) throws SQLServerException {
/*  941 */       setTypeDefinition(dtv);
/*      */     }
/*      */     
/*      */     void execute(DTV dtv, LocalDate localDateValue) throws SQLServerException {
/*  945 */       setTypeDefinition(dtv);
/*      */     }
/*      */     
/*      */     void execute(DTV dtv, LocalTime localTimeValue) throws SQLServerException {
/*  949 */       setTypeDefinition(dtv);
/*      */     }
/*      */     
/*      */     void execute(DTV dtv, LocalDateTime localDateTimeValue) throws SQLServerException {
/*  953 */       setTypeDefinition(dtv);
/*      */     }
/*      */     
/*      */     void execute(DTV dtv, OffsetTime offsetTimeValue) throws SQLServerException {
/*  957 */       setTypeDefinition(dtv);
/*      */     }
/*      */     
/*      */     void execute(DTV dtv, OffsetDateTime OffsetDateTimeValue) throws SQLServerException {
/*  961 */       setTypeDefinition(dtv);
/*      */     }
/*      */     
/*      */     void execute(DTV dtv, DateTimeOffset dtoValue) throws SQLServerException {
/*  965 */       setTypeDefinition(dtv);
/*      */     }
/*      */     
/*      */     void execute(DTV dtv, Float floatValue) throws SQLServerException {
/*  969 */       Parameter.this.scale = 4;
/*  970 */       setTypeDefinition(dtv);
/*      */     }
/*      */     
/*      */     void execute(DTV dtv, Double doubleValue) throws SQLServerException {
/*  974 */       Parameter.this.scale = 4;
/*  975 */       setTypeDefinition(dtv);
/*      */     }
/*      */     
/*      */     void execute(DTV dtv, BigDecimal bigDecimalValue) throws SQLServerException {
/*  979 */       if (null != bigDecimalValue) {
/*  980 */         Parameter.this.scale = bigDecimalValue.scale();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  987 */         if (Parameter.this.scale < 0) {
/*  988 */           Parameter.this.scale = 0;
/*      */         }
/*      */       } 
/*  991 */       setTypeDefinition(dtv);
/*      */     }
/*      */     
/*      */     void execute(DTV dtv, Long longValue) throws SQLServerException {
/*  995 */       setTypeDefinition(dtv);
/*      */     }
/*      */     
/*      */     void execute(DTV dtv, BigInteger bigIntegerValue) throws SQLServerException {
/*  999 */       setTypeDefinition(dtv);
/*      */     }
/*      */     
/*      */     void execute(DTV dtv, Short shortValue) throws SQLServerException {
/* 1003 */       setTypeDefinition(dtv);
/*      */     }
/*      */     
/*      */     void execute(DTV dtv, Boolean booleanValue) throws SQLServerException {
/* 1007 */       setTypeDefinition(dtv);
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV dtv, byte[] byteArrayValue) throws SQLServerException {
/* 1012 */       if (null != byteArrayValue && byteArrayValue.length > 8000 && dtv
/* 1013 */         .getJdbcType() != JDBCType.GEOMETRY && dtv.getJdbcType() != JDBCType.GEOGRAPHY) {
/* 1014 */         dtv.setJdbcType(dtv.getJdbcType().isBinary() ? JDBCType.LONGVARBINARY : JDBCType.LONGVARCHAR);
/*      */       }
/* 1016 */       setTypeDefinition(dtv);
/*      */     }
/*      */     
/*      */     void execute(DTV dtv, Blob blobValue) throws SQLServerException {
/* 1020 */       setTypeDefinition(dtv);
/*      */     }
/*      */     
/*      */     void execute(DTV dtv, InputStream inputStreamValue) throws SQLServerException {
/* 1024 */       StreamSetterArgs streamSetterArgs = dtv.getStreamSetterArgs();
/*      */       
/* 1026 */       JDBCType jdbcType = dtv.getJdbcType();
/*      */ 
/*      */       
/* 1029 */       if (JDBCType.CHAR == jdbcType || JDBCType.VARCHAR == jdbcType || JDBCType.BINARY == jdbcType || JDBCType.VARBINARY == jdbcType)
/*      */       {
/*      */         
/* 1032 */         if (streamSetterArgs.getLength() > 8000L) {
/* 1033 */           dtv.setJdbcType(jdbcType.isBinary() ? JDBCType.LONGVARBINARY : JDBCType.LONGVARCHAR);
/*      */ 
/*      */         
/*      */         }
/* 1037 */         else if (-1L == streamSetterArgs.getLength()) {
/* 1038 */           byte[] vartypeBytes = new byte[8001];
/* 1039 */           BufferedInputStream bufferedStream = new BufferedInputStream(inputStreamValue, vartypeBytes.length);
/*      */           
/* 1041 */           int bytesRead = 0;
/*      */           
/*      */           try {
/* 1044 */             bufferedStream.mark(vartypeBytes.length);
/*      */             
/* 1046 */             bytesRead = bufferedStream.read(vartypeBytes, 0, vartypeBytes.length);
/*      */             
/* 1048 */             if (-1 == bytesRead) {
/* 1049 */               bytesRead = 0;
/*      */             }
/* 1051 */             bufferedStream.reset();
/* 1052 */           } catch (IOException e) {
/* 1053 */             MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_errorReadingStream"));
/* 1054 */             Object[] msgArgs = { e.toString() };
/* 1055 */             SQLServerException.makeFromDriverError(null, null, form.format(msgArgs), "", true);
/*      */           } 
/*      */           
/* 1058 */           dtv.setValue(bufferedStream, JavaType.INPUTSTREAM);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1066 */           if (bytesRead > 8000) {
/* 1067 */             dtv.setJdbcType(jdbcType.isBinary() ? JDBCType.LONGVARBINARY : JDBCType.LONGVARCHAR);
/*      */           } else {
/* 1069 */             streamSetterArgs.setLength(bytesRead);
/*      */           } 
/*      */         } 
/*      */       }
/* 1073 */       setTypeDefinition(dtv);
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV dtv, Reader readerValue) throws SQLServerException {
/* 1078 */       if (JDBCType.NCHAR == dtv.getJdbcType() || JDBCType.NVARCHAR == dtv.getJdbcType()) {
/* 1079 */         StreamSetterArgs streamSetterArgs = dtv.getStreamSetterArgs();
/*      */ 
/*      */         
/* 1082 */         if (streamSetterArgs.getLength() > 4000L) {
/* 1083 */           dtv.setJdbcType(JDBCType.LONGNVARCHAR);
/*      */ 
/*      */         
/*      */         }
/* 1087 */         else if (-1L == streamSetterArgs.getLength()) {
/* 1088 */           char[] vartypeChars = new char[4001];
/* 1089 */           BufferedReader bufferedReader = new BufferedReader(readerValue, vartypeChars.length);
/*      */           
/* 1091 */           int charsRead = 0;
/*      */           
/*      */           try {
/* 1094 */             bufferedReader.mark(vartypeChars.length);
/*      */             
/* 1096 */             charsRead = bufferedReader.read(vartypeChars, 0, vartypeChars.length);
/*      */             
/* 1098 */             if (-1 == charsRead) {
/* 1099 */               charsRead = 0;
/*      */             }
/* 1101 */             bufferedReader.reset();
/* 1102 */           } catch (IOException e) {
/* 1103 */             MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_errorReadingStream"));
/* 1104 */             Object[] msgArgs = { e.toString() };
/* 1105 */             SQLServerException.makeFromDriverError(null, null, form.format(msgArgs), "", true);
/*      */           } 
/*      */           
/* 1108 */           dtv.setValue(bufferedReader, JavaType.READER);
/*      */           
/* 1110 */           if (charsRead > 4000) {
/* 1111 */             dtv.setJdbcType(JDBCType.LONGNVARCHAR);
/*      */           } else {
/* 1113 */             streamSetterArgs.setLength(charsRead);
/*      */           } 
/*      */         } 
/*      */       } 
/* 1117 */       setTypeDefinition(dtv);
/*      */     }
/*      */     
/*      */     void execute(DTV dtv, SQLServerSQLXML xmlValue) throws SQLServerException {
/* 1121 */       setTypeDefinition(dtv);
/*      */     }
/*      */     
/*      */     void execute(DTV dtv, TVP tvpValue) throws SQLServerException {
/* 1125 */       setTypeDefinition(dtv);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void execute(DTV dtv, SqlVariant SqlVariantValue) throws SQLServerException {
/* 1135 */       setTypeDefinition(dtv);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String getTypeDefinition(SQLServerConnection con, TDSReader tdsReader) throws SQLServerException {
/* 1145 */     if (null == this.inputDTV) {
/* 1146 */       return null;
/*      */     }
/* 1148 */     this.inputDTV.executeOp(new GetTypeDefinitionOp(this, con));
/* 1149 */     return this.typeDefinition;
/*      */   }
/*      */   
/*      */   void sendByRPC(TDSWriter tdsWriter, SQLServerConnection conn) throws SQLServerException {
/* 1153 */     assert null != this.inputDTV : "Parameter was neither set nor registered";
/*      */     
/*      */     try {
/* 1156 */       this.inputDTV.sendCryptoMetaData(this.cryptoMeta, tdsWriter);
/* 1157 */       this.inputDTV.setJdbcTypeSetByUser(getJdbcTypeSetByUser(), getValueLength());
/* 1158 */       this.inputDTV.sendByRPC(this.name, null, conn.getDatabaseCollation(), this.valueLength, isOutput() ? this.outScale : this.scale, 
/* 1159 */           isOutput(), tdsWriter, conn);
/*      */     } finally {
/*      */       
/* 1162 */       this.inputDTV.sendCryptoMetaData(null, tdsWriter);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1173 */     if (JavaType.INPUTSTREAM == this.inputDTV.getJavaType() || JavaType.READER == this.inputDTV.getJavaType()) {
/* 1174 */       this.inputDTV = this.setterDTV = null;
/*      */     }
/*      */   }
/*      */   
/*      */   JDBCType getJdbcTypeSetByUser() {
/* 1179 */     return this.jdbcTypeSetByUser;
/*      */   }
/*      */   
/*      */   void setJdbcTypeSetByUser(JDBCType jdbcTypeSetByUser) {
/* 1183 */     this.jdbcTypeSetByUser = jdbcTypeSetByUser;
/*      */   }
/*      */   
/*      */   int getValueLength() {
/* 1187 */     return this.valueLength;
/*      */   }
/*      */   
/*      */   void setValueLength(int valueLength) {
/* 1191 */     this.valueLength = valueLength;
/* 1192 */     this.userProvidesPrecision = true;
/*      */   }
/*      */   
/*      */   boolean getForceEncryption() {
/* 1196 */     return this.forceEncryption;
/*      */   }
/*      */   
/*      */   void setForceEncryption(boolean forceEncryption) {
/* 1200 */     this.forceEncryption = forceEncryption;
/*      */   }
/*      */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\Parameter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */