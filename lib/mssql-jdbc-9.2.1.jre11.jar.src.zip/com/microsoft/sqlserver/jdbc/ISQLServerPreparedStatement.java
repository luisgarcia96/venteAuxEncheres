package com.microsoft.sqlserver.jdbc;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.ParameterMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLType;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import microsoft.sql.DateTimeOffset;

public interface ISQLServerPreparedStatement extends PreparedStatement, ISQLServerStatement {
  void setDateTimeOffset(int paramInt, DateTimeOffset paramDateTimeOffset) throws SQLServerException;
  
  void setObject(int paramInt, Object paramObject, SQLType paramSQLType, Integer paramInteger1, Integer paramInteger2) throws SQLServerException;
  
  void setObject(int paramInt, Object paramObject, SQLType paramSQLType, Integer paramInteger1, Integer paramInteger2, boolean paramBoolean) throws SQLServerException;
  
  int getPreparedStatementHandle() throws SQLServerException;
  
  void setBigDecimal(int paramInt1, BigDecimal paramBigDecimal, int paramInt2, int paramInt3) throws SQLServerException;
  
  void setBigDecimal(int paramInt1, BigDecimal paramBigDecimal, int paramInt2, int paramInt3, boolean paramBoolean) throws SQLServerException;
  
  void setMoney(int paramInt, BigDecimal paramBigDecimal) throws SQLServerException;
  
  void setMoney(int paramInt, BigDecimal paramBigDecimal, boolean paramBoolean) throws SQLServerException;
  
  void setSmallMoney(int paramInt, BigDecimal paramBigDecimal) throws SQLServerException;
  
  void setSmallMoney(int paramInt, BigDecimal paramBigDecimal, boolean paramBoolean) throws SQLServerException;
  
  void setBoolean(int paramInt, boolean paramBoolean1, boolean paramBoolean2) throws SQLServerException;
  
  void setByte(int paramInt, byte paramByte, boolean paramBoolean) throws SQLServerException;
  
  void setBytes(int paramInt, byte[] paramArrayOfbyte, boolean paramBoolean) throws SQLServerException;
  
  void setUniqueIdentifier(int paramInt, String paramString) throws SQLServerException;
  
  void setUniqueIdentifier(int paramInt, String paramString, boolean paramBoolean) throws SQLServerException;
  
  void setDouble(int paramInt, double paramDouble, boolean paramBoolean) throws SQLServerException;
  
  void setFloat(int paramInt, float paramFloat, boolean paramBoolean) throws SQLServerException;
  
  void setGeometry(int paramInt, Geometry paramGeometry) throws SQLServerException;
  
  void setGeography(int paramInt, Geography paramGeography) throws SQLServerException;
  
  void setInt(int paramInt1, int paramInt2, boolean paramBoolean) throws SQLServerException;
  
  void setLong(int paramInt, long paramLong, boolean paramBoolean) throws SQLServerException;
  
  void setObject(int paramInt1, Object paramObject, int paramInt2, Integer paramInteger, int paramInt3) throws SQLServerException;
  
  void setObject(int paramInt1, Object paramObject, int paramInt2, Integer paramInteger, int paramInt3, boolean paramBoolean) throws SQLServerException;
  
  void setShort(int paramInt, short paramShort, boolean paramBoolean) throws SQLServerException;
  
  void setString(int paramInt, String paramString, boolean paramBoolean) throws SQLServerException;
  
  void setNString(int paramInt, String paramString, boolean paramBoolean) throws SQLServerException;
  
  void setTime(int paramInt1, Time paramTime, int paramInt2) throws SQLServerException;
  
  void setTime(int paramInt1, Time paramTime, int paramInt2, boolean paramBoolean) throws SQLServerException;
  
  void setTimestamp(int paramInt1, Timestamp paramTimestamp, int paramInt2) throws SQLServerException;
  
  void setTimestamp(int paramInt1, Timestamp paramTimestamp, int paramInt2, boolean paramBoolean) throws SQLServerException;
  
  void setDateTimeOffset(int paramInt1, DateTimeOffset paramDateTimeOffset, int paramInt2) throws SQLServerException;
  
  void setDateTimeOffset(int paramInt1, DateTimeOffset paramDateTimeOffset, int paramInt2, boolean paramBoolean) throws SQLServerException;
  
  void setDateTime(int paramInt, Timestamp paramTimestamp) throws SQLServerException;
  
  void setDateTime(int paramInt, Timestamp paramTimestamp, boolean paramBoolean) throws SQLServerException;
  
  void setSmallDateTime(int paramInt, Timestamp paramTimestamp) throws SQLServerException;
  
  void setSmallDateTime(int paramInt, Timestamp paramTimestamp, boolean paramBoolean) throws SQLServerException;
  
  void setStructured(int paramInt, String paramString, SQLServerDataTable paramSQLServerDataTable) throws SQLServerException;
  
  void setStructured(int paramInt, String paramString, ResultSet paramResultSet) throws SQLServerException;
  
  void setStructured(int paramInt, String paramString, ISQLServerDataRecord paramISQLServerDataRecord) throws SQLServerException;
  
  void setDate(int paramInt, Date paramDate, Calendar paramCalendar, boolean paramBoolean) throws SQLServerException;
  
  void setTime(int paramInt, Time paramTime, Calendar paramCalendar, boolean paramBoolean) throws SQLServerException;
  
  void setTimestamp(int paramInt, Timestamp paramTimestamp, Calendar paramCalendar, boolean paramBoolean) throws SQLServerException;
  
  ParameterMetaData getParameterMetaData(boolean paramBoolean) throws SQLServerException;
  
  boolean getUseFmtOnly() throws SQLServerException;
  
  void setUseFmtOnly(boolean paramBoolean) throws SQLServerException;
}


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\ISQLServerPreparedStatement.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */