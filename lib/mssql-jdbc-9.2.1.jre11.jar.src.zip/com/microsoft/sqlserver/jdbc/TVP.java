/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.sql.SQLException;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class TVP
/*     */ {
/*     */   String TVPName;
/*     */   String TVP_owningSchema;
/*     */   String TVP_dbName;
/*  50 */   ResultSet sourceResultSet = null;
/*  51 */   SQLServerDataTable sourceDataTable = null;
/*  52 */   Map<Integer, SQLServerMetaData> columnMetadata = null;
/*  53 */   Iterator<Map.Entry<Integer, Object[]>> sourceDataTableRowIterator = null;
/*  54 */   ISQLServerDataRecord sourceRecord = null;
/*  55 */   TVPType tvpType = null;
/*  56 */   Set<String> columnNames = null;
/*     */   
/*     */   enum MPIState
/*     */   {
/*  60 */     MPI_Value,
/*  61 */     MPI_ParseNonQuote,
/*  62 */     MPI_LookForSeparator,
/*  63 */     MPI_LookForNextCharOrSeparator,
/*  64 */     MPI_ParseQuote,
/*  65 */     MPI_RightQuote;
/*     */   }
/*     */   
/*     */   void initTVP(TVPType type, String tvpPartName) throws SQLServerException {
/*  69 */     this.tvpType = type;
/*  70 */     this.columnMetadata = new LinkedHashMap<>();
/*  71 */     parseTypeName(tvpPartName);
/*     */   }
/*     */   
/*     */   TVP(String tvpPartName) throws SQLServerException {
/*  75 */     initTVP(TVPType.Null, tvpPartName);
/*     */   }
/*     */ 
/*     */   
/*     */   TVP(String tvpPartName, SQLServerDataTable tvpDataTable) throws SQLServerException {
/*  80 */     if (tvpPartName == null) {
/*  81 */       tvpPartName = tvpDataTable.getTvpName();
/*     */     }
/*  83 */     initTVP(TVPType.SQLServerDataTable, tvpPartName);
/*  84 */     this.sourceDataTable = tvpDataTable;
/*  85 */     this.sourceDataTableRowIterator = this.sourceDataTable.getIterator();
/*  86 */     populateMetadataFromDataTable();
/*     */   }
/*     */   
/*     */   TVP(String tvpPartName, ResultSet tvpResultSet) throws SQLServerException {
/*  90 */     initTVP(TVPType.ResultSet, tvpPartName);
/*  91 */     this.sourceResultSet = tvpResultSet;
/*     */     
/*  93 */     populateMetadataFromResultSet();
/*     */   }
/*     */   
/*     */   TVP(String tvpPartName, ISQLServerDataRecord tvpRecord) throws SQLServerException {
/*  97 */     initTVP(TVPType.ISQLServerDataRecord, tvpPartName);
/*  98 */     this.sourceRecord = tvpRecord;
/*  99 */     this.columnNames = new HashSet<>();
/*     */ 
/*     */     
/* 102 */     populateMetadataFromDataRecord();
/*     */ 
/*     */     
/* 105 */     validateOrderProperty();
/*     */   }
/*     */   
/*     */   boolean isNull() {
/* 109 */     return (TVPType.Null == this.tvpType);
/*     */   }
/*     */   
/*     */   Object[] getRowData() throws SQLServerException {
/* 113 */     if (TVPType.ResultSet == this.tvpType) {
/* 114 */       int colCount = this.columnMetadata.size();
/* 115 */       Object[] rowData = new Object[colCount];
/* 116 */       for (int i = 0; i < colCount; i++) {
/*     */ 
/*     */         
/*     */         try {
/*     */ 
/*     */           
/* 122 */           if (92 == this.sourceResultSet.getMetaData().getColumnType(i + 1)) {
/* 123 */             rowData[i] = this.sourceResultSet.getTimestamp(i + 1);
/*     */           } else {
/* 125 */             rowData[i] = this.sourceResultSet.getObject(i + 1);
/*     */           } 
/* 127 */         } catch (SQLException e) {
/* 128 */           throw new SQLServerException(SQLServerException.getErrString("R_unableRetrieveSourceData"), e);
/*     */         } 
/*     */       } 
/* 131 */       return rowData;
/* 132 */     }  if (TVPType.SQLServerDataTable == this.tvpType) {
/* 133 */       Map.Entry<Integer, Object[]> rowPair = this.sourceDataTableRowIterator.next();
/* 134 */       return rowPair.getValue();
/*     */     } 
/* 136 */     return this.sourceRecord.getRowData();
/*     */   }
/*     */   
/*     */   boolean next() throws SQLServerException {
/* 140 */     if (TVPType.ResultSet == this.tvpType)
/*     */       try {
/* 142 */         return this.sourceResultSet.next();
/* 143 */       } catch (SQLException e) {
/* 144 */         throw new SQLServerException(SQLServerException.getErrString("R_unableRetrieveSourceData"), e);
/*     */       }  
/* 146 */     if (TVPType.SQLServerDataTable == this.tvpType)
/* 147 */       return this.sourceDataTableRowIterator.hasNext(); 
/* 148 */     if (null != this.sourceRecord) {
/* 149 */       return this.sourceRecord.next();
/*     */     }
/* 151 */     return false;
/*     */   }
/*     */   
/*     */   void populateMetadataFromDataTable() throws SQLServerException {
/* 155 */     if (null != this.sourceDataTable) {
/* 156 */       Map<Integer, SQLServerDataColumn> dataTableMetaData = this.sourceDataTable.getColumnMetadata();
/* 157 */       if (null == dataTableMetaData || dataTableMetaData.isEmpty()) {
/* 158 */         throw new SQLServerException(SQLServerException.getErrString("R_TVPEmptyMetadata"), null);
/*     */       }
/* 160 */       dataTableMetaData.entrySet()
/* 161 */         .forEach(E -> this.columnMetadata.put((Integer)E.getKey(), new SQLServerMetaData(((SQLServerDataColumn)E.getValue()).columnName, ((SQLServerDataColumn)E.getValue()).javaSqlType, ((SQLServerDataColumn)E.getValue()).precision, ((SQLServerDataColumn)E.getValue()).scale)));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   void populateMetadataFromResultSet() throws SQLServerException {
/* 167 */     if (null != this.sourceResultSet) {
/*     */       try {
/* 169 */         ResultSetMetaData rsmd = this.sourceResultSet.getMetaData();
/* 170 */         for (int i = 0; i < rsmd.getColumnCount(); i++) {
/*     */           
/* 172 */           SQLServerMetaData columnMetaData = new SQLServerMetaData(rsmd.getColumnName(i + 1), rsmd.getColumnType(i + 1), rsmd.getPrecision(i + 1), rsmd.getScale(i + 1));
/* 173 */           this.columnMetadata.put(Integer.valueOf(i), columnMetaData);
/*     */         } 
/* 175 */       } catch (SQLException e) {
/* 176 */         throw new SQLServerException(SQLServerException.getErrString("R_unableRetrieveColMeta"), e);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   void populateMetadataFromDataRecord() throws SQLServerException {
/* 182 */     if (null != this.sourceRecord) {
/* 183 */       if (0 >= this.sourceRecord.getColumnCount()) {
/* 184 */         throw new SQLServerException(SQLServerException.getErrString("R_TVPEmptyMetadata"), null);
/*     */       }
/* 186 */       for (int i = 0; i < this.sourceRecord.getColumnCount(); i++) {
/* 187 */         Util.checkDuplicateColumnName((this.sourceRecord.getColumnMetaData(i + 1)).columnName, this.columnNames);
/*     */ 
/*     */         
/* 190 */         SQLServerMetaData metaData = new SQLServerMetaData(this.sourceRecord.getColumnMetaData(i + 1));
/* 191 */         this.columnMetadata.put(Integer.valueOf(i), metaData);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   void validateOrderProperty() throws SQLServerException {
/* 197 */     int columnCount = this.columnMetadata.size();
/* 198 */     boolean[] sortOrdinalSpecified = new boolean[columnCount];
/*     */     
/* 200 */     int maxSortOrdinal = -1;
/* 201 */     int sortCount = 0;
/* 202 */     for (Map.Entry<Integer, SQLServerMetaData> columnPair : this.columnMetadata.entrySet()) {
/* 203 */       SQLServerSortOrder columnSortOrder = ((SQLServerMetaData)columnPair.getValue()).sortOrder;
/* 204 */       int columnSortOrdinal = ((SQLServerMetaData)columnPair.getValue()).sortOrdinal;
/*     */       
/* 206 */       if (SQLServerSortOrder.Unspecified != columnSortOrder) {
/*     */         
/* 208 */         if (columnCount <= columnSortOrdinal) {
/*     */           
/* 210 */           MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_TVPSortOrdinalGreaterThanFieldCount"));
/* 211 */           throw new SQLServerException(form.format(new Object[] { Integer.valueOf(columnSortOrdinal), columnPair.getKey() }, ), null, 0, null);
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 216 */         if (sortOrdinalSpecified[columnSortOrdinal]) {
/*     */           
/* 218 */           MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_TVPDuplicateSortOrdinal"));
/* 219 */           throw new SQLServerException(form.format(new Object[] { Integer.valueOf(columnSortOrdinal) }, ), null, 0, null);
/*     */         } 
/*     */         
/* 222 */         sortOrdinalSpecified[columnSortOrdinal] = true;
/* 223 */         if (columnSortOrdinal > maxSortOrdinal) {
/* 224 */           maxSortOrdinal = columnSortOrdinal;
/*     */         }
/* 226 */         sortCount++;
/*     */       } 
/*     */     } 
/*     */     
/* 230 */     if (0 < sortCount)
/*     */     {
/* 232 */       if (maxSortOrdinal >= sortCount) {
/*     */         int i;
/*     */         
/* 235 */         for (i = 0; i < sortCount && 
/* 236 */           sortOrdinalSpecified[i]; i++);
/*     */ 
/*     */         
/* 239 */         MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_TVPMissingSortOrdinal"));
/* 240 */         throw new SQLServerException(form.format(new Object[] { Integer.valueOf(i) }, ), null, 0, null);
/*     */       }  } 
/*     */   }
/*     */   
/*     */   void parseTypeName(String name) throws SQLServerException {
/*     */     MessageFormat form;
/* 246 */     String leftQuote = "[\"";
/* 247 */     String rightQuote = "]\"";
/* 248 */     char separator = '.';
/* 249 */     int limit = 3;
/* 250 */     String[] parsedNames = new String[limit];
/* 251 */     int stringCount = 0;
/*     */     
/* 253 */     if (null == name || 0 == name.length()) {
/* 254 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidTVPName"));
/* 255 */       Object[] msgArgs = new Object[0];
/* 256 */       throw new SQLServerException(null, messageFormat.format(msgArgs), null, 0, false);
/*     */     } 
/*     */     
/* 259 */     StringBuilder sb = new StringBuilder(name.length());
/*     */ 
/*     */     
/* 262 */     StringBuilder whitespaceSB = null;
/*     */ 
/*     */     
/* 265 */     char rightQuoteChar = ' ';
/* 266 */     MPIState state = MPIState.MPI_Value;
/*     */     
/* 268 */     for (int index = 0; index < name.length(); index++) {
/* 269 */       int quoteIndex; char testchar = name.charAt(index);
/* 270 */       switch (state) {
/*     */         
/*     */         case MPI_Value:
/* 273 */           if (Character.isWhitespace(testchar))
/*     */             break; 
/* 275 */           if (testchar == separator) {
/*     */ 
/*     */             
/* 278 */             parsedNames[stringCount] = "";
/* 279 */             stringCount++; break;
/* 280 */           }  if (-1 != (quoteIndex = leftQuote.indexOf(testchar))) {
/*     */             
/* 282 */             rightQuoteChar = rightQuote.charAt(quoteIndex);
/* 283 */             sb.setLength(0);
/* 284 */             state = MPIState.MPI_ParseQuote; break;
/* 285 */           }  if (-1 != rightQuote.indexOf(testchar)) {
/*     */ 
/*     */             
/* 288 */             MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidThreePartName"));
/* 289 */             throw new SQLServerException(null, messageFormat.format(new Object[0]), null, 0, false);
/*     */           } 
/* 291 */           sb.setLength(0);
/* 292 */           sb.append(testchar);
/* 293 */           state = MPIState.MPI_ParseNonQuote;
/*     */           break;
/*     */ 
/*     */         
/*     */         case MPI_ParseNonQuote:
/* 298 */           if (testchar == separator) {
/* 299 */             parsedNames[stringCount] = sb.toString();
/* 300 */             stringCount = incrementStringCount(parsedNames, stringCount);
/* 301 */             state = MPIState.MPI_Value;
/*     */             break;
/*     */           } 
/* 304 */           if (-1 != rightQuote.indexOf(testchar) || -1 != leftQuote.indexOf(testchar)) {
/*     */             
/* 306 */             MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidThreePartName"));
/* 307 */             throw new SQLServerException(null, messageFormat.format(new Object[0]), null, 0, false);
/* 308 */           }  if (Character.isWhitespace(testchar)) {
/*     */             
/* 310 */             parsedNames[stringCount] = sb.toString();
/* 311 */             if (null == whitespaceSB)
/* 312 */               whitespaceSB = new StringBuilder(); 
/* 313 */             whitespaceSB.setLength(0);
/*     */ 
/*     */             
/* 316 */             whitespaceSB.append(testchar);
/* 317 */             state = MPIState.MPI_LookForNextCharOrSeparator; break;
/*     */           } 
/* 319 */           sb.append(testchar);
/*     */           break;
/*     */ 
/*     */         
/*     */         case MPI_LookForNextCharOrSeparator:
/* 324 */           if (!Character.isWhitespace(testchar)) {
/*     */             
/* 326 */             if (testchar == separator) {
/* 327 */               stringCount = incrementStringCount(parsedNames, stringCount);
/* 328 */               state = MPIState.MPI_Value;
/*     */               break;
/*     */             } 
/* 331 */             sb.append(whitespaceSB);
/* 332 */             sb.append(testchar);
/*     */             
/* 334 */             parsedNames[stringCount] = sb.toString();
/* 335 */             state = MPIState.MPI_ParseNonQuote;
/*     */             break;
/*     */           } 
/* 338 */           if (null == whitespaceSB) {
/* 339 */             whitespaceSB = new StringBuilder();
/*     */           }
/* 341 */           whitespaceSB.append(testchar);
/*     */           break;
/*     */ 
/*     */ 
/*     */         
/*     */         case MPI_ParseQuote:
/* 347 */           if (testchar == rightQuoteChar) {
/* 348 */             state = MPIState.MPI_RightQuote; break;
/*     */           } 
/* 350 */           sb.append(testchar);
/*     */           break;
/*     */         
/*     */         case MPI_RightQuote:
/* 354 */           if (testchar == rightQuoteChar) {
/*     */             
/* 356 */             sb.append(testchar);
/* 357 */             state = MPIState.MPI_ParseQuote; break;
/* 358 */           }  if (testchar == separator) {
/*     */             
/* 360 */             parsedNames[stringCount] = sb.toString();
/* 361 */             stringCount = incrementStringCount(parsedNames, stringCount);
/* 362 */             state = MPIState.MPI_Value; break;
/* 363 */           }  if (!Character.isWhitespace(testchar)) {
/*     */ 
/*     */             
/* 366 */             MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidThreePartName"));
/* 367 */             throw new SQLServerException(null, messageFormat.format(new Object[0]), null, 0, false);
/*     */           } 
/*     */ 
/*     */           
/* 371 */           parsedNames[stringCount] = sb.toString();
/* 372 */           state = MPIState.MPI_LookForSeparator;
/*     */           break;
/*     */ 
/*     */         
/*     */         case MPI_LookForSeparator:
/* 377 */           if (!Character.isWhitespace(testchar)) {
/*     */             
/* 379 */             if (testchar == separator) {
/*     */               
/* 381 */               stringCount = incrementStringCount(parsedNames, stringCount);
/* 382 */               state = MPIState.MPI_Value;
/*     */               
/*     */               break;
/*     */             } 
/* 386 */             MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidThreePartName"));
/* 387 */             throw new SQLServerException(null, messageFormat.format(new Object[0]), null, 0, false);
/*     */           } 
/*     */           break;
/*     */       } 
/*     */ 
/*     */     
/*     */     } 
/* 394 */     if (stringCount > limit - 1) {
/* 395 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidThreePartName"));
/* 396 */       throw new SQLServerException(null, messageFormat.format(new Object[0]), null, 0, false);
/*     */     } 
/*     */ 
/*     */     
/* 400 */     switch (state) {
/*     */       case MPI_Value:
/*     */       case MPI_LookForNextCharOrSeparator:
/*     */       case MPI_LookForSeparator:
/*     */         break;
/*     */       
/*     */       case MPI_ParseNonQuote:
/*     */       case MPI_RightQuote:
/* 408 */         parsedNames[stringCount] = sb.toString();
/*     */         break;
/*     */ 
/*     */       
/*     */       default:
/* 413 */         form = new MessageFormat(SQLServerException.getErrString("R_invalidThreePartName"));
/* 414 */         throw new SQLServerException(null, form.format(new Object[0]), null, 0, false);
/*     */     } 
/*     */     
/* 417 */     if (parsedNames[0] == null) {
/* 418 */       form = new MessageFormat(SQLServerException.getErrString("R_invalidThreePartName"));
/* 419 */       throw new SQLServerException(null, form.format(new Object[0]), null, 0, false);
/*     */     } 
/*     */ 
/*     */     
/* 423 */     int offset = limit - stringCount - 1;
/* 424 */     if (offset > 0) {
/* 425 */       for (int x = limit - 1; x >= offset; x--) {
/* 426 */         parsedNames[x] = parsedNames[x - offset];
/* 427 */         parsedNames[x - offset] = null;
/*     */       } 
/*     */     }
/*     */     
/* 431 */     this.TVPName = parsedNames[2];
/* 432 */     this.TVP_owningSchema = parsedNames[1];
/* 433 */     this.TVP_dbName = parsedNames[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int incrementStringCount(String[] ary, int position) throws SQLServerException {
/* 443 */     position++;
/* 444 */     int limit = ary.length;
/* 445 */     if (position >= limit) {
/* 446 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidThreePartName"));
/* 447 */       throw new SQLServerException(null, form.format(new Object[0]), null, 0, false);
/*     */     } 
/* 449 */     ary[position] = new String();
/* 450 */     return position;
/*     */   }
/*     */   
/*     */   String getTVPName() {
/* 454 */     return this.TVPName;
/*     */   }
/*     */   
/*     */   String getDbNameTVP() {
/* 458 */     return this.TVP_dbName;
/*     */   }
/*     */   
/*     */   String getOwningSchemaNameTVP() {
/* 462 */     return this.TVP_owningSchema;
/*     */   }
/*     */   
/*     */   int getTVPColumnCount() {
/* 466 */     return this.columnMetadata.size();
/*     */   }
/*     */   
/*     */   Map<Integer, SQLServerMetaData> getColumnMetadata() {
/* 470 */     return this.columnMetadata;
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\TVP.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */