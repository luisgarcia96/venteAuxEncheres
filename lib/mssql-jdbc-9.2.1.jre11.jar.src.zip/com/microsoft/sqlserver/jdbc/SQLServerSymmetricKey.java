/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SQLServerSymmetricKey
/*    */ {
/*    */   private byte[] rootKey;
/*    */   
/*    */   SQLServerSymmetricKey(byte[] rootKey) throws SQLServerException {
/* 17 */     if (null == rootKey) {
/* 18 */       throw new SQLServerException(this, SQLServerException.getErrString("R_NullColumnEncryptionKey"), null, 0, false);
/*    */     }
/* 20 */     if (0 == rootKey.length) {
/* 21 */       throw new SQLServerException(this, SQLServerException.getErrString("R_EmptyColumnEncryptionKey"), null, 0, false);
/*    */     }
/*    */     
/* 24 */     this.rootKey = rootKey;
/*    */   }
/*    */   
/*    */   byte[] getRootKey() {
/* 28 */     return this.rootKey;
/*    */   }
/*    */   
/*    */   int length() {
/* 32 */     return this.rootKey.length;
/*    */   }
/*    */   
/*    */   void zeroOutKey() {
/* 36 */     for (int i = 0; i < this.rootKey.length; i++)
/* 37 */       this.rootKey[i] = 0; 
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerSymmetricKey.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */