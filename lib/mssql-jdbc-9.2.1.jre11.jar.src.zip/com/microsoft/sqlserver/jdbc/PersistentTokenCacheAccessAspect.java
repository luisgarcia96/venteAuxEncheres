/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import com.microsoft.aad.msal4j.ITokenCacheAccessAspect;
/*    */ import com.microsoft.aad.msal4j.ITokenCacheAccessContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PersistentTokenCacheAccessAspect
/*    */   implements ITokenCacheAccessAspect
/*    */ {
/* 22 */   private static PersistentTokenCacheAccessAspect instance = new PersistentTokenCacheAccessAspect();
/*    */ 
/*    */ 
/*    */   
/*    */   static PersistentTokenCacheAccessAspect getInstance() {
/* 27 */     return instance;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 33 */   private String cache = null;
/*    */ 
/*    */   
/*    */   public synchronized void beforeCacheAccess(ITokenCacheAccessContext iTokenCacheAccessContext) {
/* 37 */     if (null != this.cache && null != iTokenCacheAccessContext && null != iTokenCacheAccessContext.tokenCache()) {
/* 38 */       iTokenCacheAccessContext.tokenCache().deserialize(this.cache);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public synchronized void afterCacheAccess(ITokenCacheAccessContext iTokenCacheAccessContext) {
/* 44 */     if (null != iTokenCacheAccessContext && iTokenCacheAccessContext.hasCacheChanged() && null != iTokenCacheAccessContext
/* 45 */       .tokenCache()) {
/* 46 */       this.cache = iTokenCacheAccessContext.tokenCache().serialize();
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static void clearUserTokenCache() {
/* 54 */     if (null != instance.cache && !instance.cache.isEmpty())
/* 55 */       instance.cache = null; 
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\PersistentTokenCacheAccessAspect.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */