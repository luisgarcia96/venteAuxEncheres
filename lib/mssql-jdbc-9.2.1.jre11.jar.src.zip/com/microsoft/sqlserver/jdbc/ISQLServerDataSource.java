package com.microsoft.sqlserver.jdbc;

import javax.sql.CommonDataSource;
import org.ietf.jgss.GSSCredential;

public interface ISQLServerDataSource extends CommonDataSource {
  void setApplicationIntent(String paramString);
  
  String getApplicationIntent();
  
  void setApplicationName(String paramString);
  
  String getApplicationName();
  
  void setDatabaseName(String paramString);
  
  String getDatabaseName();
  
  void setInstanceName(String paramString);
  
  String getInstanceName();
  
  void setIntegratedSecurity(boolean paramBoolean);
  
  void setLastUpdateCount(boolean paramBoolean);
  
  boolean getLastUpdateCount();
  
  void setEncrypt(boolean paramBoolean);
  
  boolean getEncrypt();
  
  void setTransparentNetworkIPResolution(boolean paramBoolean);
  
  boolean getTransparentNetworkIPResolution();
  
  void setTrustServerCertificate(boolean paramBoolean);
  
  boolean getTrustServerCertificate();
  
  void setTrustStoreType(String paramString);
  
  String getTrustStoreType();
  
  void setTrustStore(String paramString);
  
  String getTrustStore();
  
  void setTrustStorePassword(String paramString);
  
  void setHostNameInCertificate(String paramString);
  
  String getHostNameInCertificate();
  
  void setLockTimeout(int paramInt);
  
  int getLockTimeout();
  
  void setPassword(String paramString);
  
  void setPortNumber(int paramInt);
  
  int getPortNumber();
  
  void setSelectMethod(String paramString);
  
  String getSelectMethod();
  
  void setResponseBuffering(String paramString);
  
  String getResponseBuffering();
  
  void setSendTimeAsDatetime(boolean paramBoolean);
  
  boolean getSendTimeAsDatetime();
  
  void setSendStringParametersAsUnicode(boolean paramBoolean);
  
  boolean getSendStringParametersAsUnicode();
  
  void setServerNameAsACE(boolean paramBoolean);
  
  boolean getServerNameAsACE();
  
  void setServerName(String paramString);
  
  String getServerName();
  
  void setFailoverPartner(String paramString);
  
  String getFailoverPartner();
  
  void setMultiSubnetFailover(boolean paramBoolean);
  
  boolean getMultiSubnetFailover();
  
  void setUser(String paramString);
  
  String getUser();
  
  void setWorkstationID(String paramString);
  
  String getWorkstationID();
  
  void setXopenStates(boolean paramBoolean);
  
  boolean getXopenStates();
  
  void setURL(String paramString);
  
  String getURL();
  
  void setDescription(String paramString);
  
  String getDescription();
  
  void setPacketSize(int paramInt);
  
  int getPacketSize();
  
  void setAuthenticationScheme(String paramString);
  
  void setAuthentication(String paramString);
  
  String getAuthentication();
  
  void setServerSpn(String paramString);
  
  String getServerSpn();
  
  void setGSSCredentials(GSSCredential paramGSSCredential);
  
  GSSCredential getGSSCredentials();
  
  void setAccessToken(String paramString);
  
  String getAccessToken();
  
  void setColumnEncryptionSetting(String paramString);
  
  String getColumnEncryptionSetting();
  
  void setKeyStoreAuthentication(String paramString);
  
  String getKeyStoreAuthentication();
  
  void setKeyStoreSecret(String paramString);
  
  void setKeyStoreLocation(String paramString);
  
  String getKeyStoreLocation();
  
  void setQueryTimeout(int paramInt);
  
  int getQueryTimeout();
  
  void setCancelQueryTimeout(int paramInt);
  
  int getCancelQueryTimeout();
  
  void setEnablePrepareOnFirstPreparedStatementCall(boolean paramBoolean);
  
  boolean getEnablePrepareOnFirstPreparedStatementCall();
  
  void setServerPreparedStatementDiscardThreshold(int paramInt);
  
  int getServerPreparedStatementDiscardThreshold();
  
  void setStatementPoolingCacheSize(int paramInt);
  
  int getStatementPoolingCacheSize();
  
  void setDisableStatementPooling(boolean paramBoolean);
  
  boolean getDisableStatementPooling();
  
  void setSocketTimeout(int paramInt);
  
  int getSocketTimeout();
  
  void setJASSConfigurationName(String paramString);
  
  String getJASSConfigurationName();
  
  void setFIPS(boolean paramBoolean);
  
  boolean getFIPS();
  
  void setSSLProtocol(String paramString);
  
  String getSSLProtocol();
  
  String getSocketFactoryClass();
  
  void setSocketFactoryClass(String paramString);
  
  String getSocketFactoryConstructorArg();
  
  void setSocketFactoryConstructorArg(String paramString);
  
  void setTrustManagerClass(String paramString);
  
  String getTrustManagerClass();
  
  void setTrustManagerConstructorArg(String paramString);
  
  String getTrustManagerConstructorArg();
  
  boolean getUseBulkCopyForBatchInsert();
  
  void setUseBulkCopyForBatchInsert(boolean paramBoolean);
  
  void setMSIClientId(String paramString);
  
  String getMSIClientId();
  
  void setKeyStorePrincipalId(String paramString);
  
  String getKeyStorePrincipalId();
  
  void setKeyVaultProviderClientId(String paramString);
  
  String getKeyVaultProviderClientId();
  
  void setKeyVaultProviderClientKey(String paramString);
  
  String getDomain();
  
  void setDomain(String paramString);
  
  boolean getUseFmtOnly();
  
  void setUseFmtOnly(boolean paramBoolean);
  
  String getEnclaveAttestationUrl();
  
  void setEnclaveAttestationUrl(String paramString);
  
  String getEnclaveAttestationProtocol();
  
  void setEnclaveAttestationProtocol(String paramString);
  
  String getClientCertificate();
  
  void setClientCertificate(String paramString);
  
  String getClientKey();
  
  void setClientKey(String paramString);
  
  void setClientKeyPassword(String paramString);
  
  void setDelayLoadingLobs(boolean paramBoolean);
  
  boolean getDelayLoadingLobs();
  
  boolean getSendTemporalDataTypesAsStringForBulkCopy();
  
  void setSendTemporalDataTypesAsStringForBulkCopy(boolean paramBoolean);
  
  String getAADSecurePrincipalId();
  
  void setAADSecurePrincipalId(String paramString);
  
  String getAADSecurePrincipalSecret();
  
  void setAADSecurePrincipalSecret(String paramString);
  
  String getMaxResultBuffer();
  
  void setMaxResultBuffer(String paramString);
}


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\ISQLServerDataSource.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */