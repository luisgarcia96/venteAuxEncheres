/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import javax.transaction.xa.Xid;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class XidImpl
/*    */   implements Xid
/*    */ {
/*    */   private final int formatId;
/*    */   private final byte[] gtrid;
/*    */   private final byte[] bqual;
/*    */   private final String traceID;
/*    */   
/*    */   public XidImpl(int formatId, byte[] gtrid, byte[] bqual) {
/* 54 */     this.formatId = formatId;
/* 55 */     this.gtrid = gtrid;
/* 56 */     this.bqual = bqual;
/* 57 */     this.traceID = " XID:" + xidDisplay(this);
/*    */   }
/*    */   
/*    */   public byte[] getGlobalTransactionId() {
/* 61 */     return this.gtrid;
/*    */   }
/*    */   
/*    */   public byte[] getBranchQualifier() {
/* 65 */     return this.bqual;
/*    */   }
/*    */   
/*    */   public int getFormatId() {
/* 69 */     return this.formatId;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 78 */     return this.traceID;
/*    */   }
/*    */ 
/*    */   
/*    */   static String xidDisplay(Xid xid) {
/* 83 */     if (null == xid)
/* 84 */       return "(null)"; 
/* 85 */     StringBuilder sb = new StringBuilder(300);
/* 86 */     sb.append("formatId=");
/* 87 */     sb.append(xid.getFormatId());
/* 88 */     sb.append(" gtrid=");
/* 89 */     sb.append(Util.byteToHexDisplayString(xid.getGlobalTransactionId()));
/* 90 */     sb.append(" bqual=");
/* 91 */     sb.append(Util.byteToHexDisplayString(xid.getBranchQualifier()));
/* 92 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\XidImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */