/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import com.azure.core.credential.AccessToken;
/*    */ import com.azure.core.credential.TokenRequestContext;
/*    */ import java.util.Objects;
/*    */ import java.util.concurrent.atomic.AtomicBoolean;
/*    */ import java.util.function.Function;
/*    */ import reactor.core.publisher.FluxSink;
/*    */ import reactor.core.publisher.Mono;
/*    */ import reactor.core.publisher.ReplayProcessor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ScopeTokenCache
/*    */ {
/*    */   private final AtomicBoolean wip;
/*    */   private AccessToken cache;
/* 23 */   private final ReplayProcessor<AccessToken> emitterProcessor = ReplayProcessor.create(1);
/* 24 */   private final FluxSink<AccessToken> sink = this.emitterProcessor.sink(FluxSink.OverflowStrategy.BUFFER);
/*    */ 
/*    */   
/*    */   private final Function<TokenRequestContext, Mono<AccessToken>> getNew;
/*    */ 
/*    */   
/*    */   private TokenRequestContext request;
/*    */ 
/*    */ 
/*    */   
/*    */   ScopeTokenCache(Function<TokenRequestContext, Mono<AccessToken>> getNew) {
/* 35 */     this.wip = new AtomicBoolean(false);
/* 36 */     this.getNew = getNew;
/*    */   }
/*    */   
/*    */   void setRequest(TokenRequestContext request) {
/* 40 */     this.request = request;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   Mono<AccessToken> getToken() {
/* 49 */     if (this.cache != null && !this.cache.isExpired()) {
/* 50 */       return Mono.just(this.cache);
/*    */     }
/* 52 */     return Mono.defer(() -> {
/*    */           if (!this.wip.getAndSet(true)) {
/*    */             Objects.requireNonNull(this.sink);
/*    */             Objects.requireNonNull(this.sink);
/*    */             return ((Mono)this.getNew.apply(this.request)).doOnNext(()).doOnNext(this.sink::next).doOnError(this.sink::error).doOnTerminate(());
/*    */           } 
/*    */           return this.emitterProcessor.next();
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\ScopeTokenCache.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */