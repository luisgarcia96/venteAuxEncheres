/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.io.Writer;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.sql.Clob;
/*     */ import java.sql.SQLException;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class SQLServerClobBase
/*     */   extends SQLServerLob
/*     */ {
/*     */   private static final long serialVersionUID = 8691072211054430124L;
/*     */   protected String value;
/*     */   private final SQLCollation sqlCollation;
/*     */   private boolean isClosed = false;
/*     */   protected final TypeInfo typeInfo;
/*  95 */   private ArrayList<Closeable> activeStreams = new ArrayList<>(1);
/*     */   
/*     */   transient SQLServerConnection con;
/*     */   
/*     */   private final Logger logger;
/*     */   
/* 101 */   private final String traceID = getClass().getName().substring(1 + getClass().getName().lastIndexOf('.')) + ":" + getClass().getName().substring(1 + getClass().getName().lastIndexOf('.'));
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 105 */     return this.traceID;
/*     */   }
/*     */ 
/*     */   
/* 109 */   private static final AtomicInteger BASE_ID = new AtomicInteger(0);
/*     */   
/* 111 */   private Charset defaultCharset = null;
/*     */ 
/*     */   
/*     */   private static int nextInstanceID() {
/* 115 */     return BASE_ID.incrementAndGet();
/*     */   }
/*     */   
/*     */   abstract JDBCType getJdbcType();
/*     */   
/*     */   private String getDisplayClassName() {
/* 121 */     String fullClassName = getJdbcType().className();
/* 122 */     return fullClassName.substring(1 + fullClassName.lastIndexOf('.'));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SQLServerClobBase(SQLServerConnection connection, Object data, SQLCollation collation, Logger logger, TypeInfo typeInfo) {
/* 141 */     this.con = connection;
/* 142 */     if (data instanceof BaseInputStream) {
/* 143 */       this.activeStreams.add((Closeable)data);
/*     */     } else {
/* 145 */       this.value = (String)data;
/*     */     } 
/* 147 */     this.sqlCollation = collation;
/* 148 */     this.logger = logger;
/* 149 */     this.typeInfo = typeInfo;
/* 150 */     if (logger.isLoggable(Level.FINE)) {
/* 151 */       String loggingInfo = (null != connection) ? connection.toString() : "null connection";
/* 152 */       logger.fine(toString() + " created by (" + toString() + ")");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void free() throws SQLException {
/* 166 */     if (!this.isClosed) {
/*     */ 
/*     */       
/* 169 */       if (null != this.activeStreams) {
/* 170 */         for (Closeable stream : this.activeStreams) {
/*     */           try {
/* 172 */             stream.close();
/* 173 */           } catch (IOException ioException) {
/* 174 */             this.logger.fine(toString() + " ignored IOException closing stream " + toString() + ": " + stream);
/*     */           } 
/*     */         } 
/*     */         
/* 178 */         this.activeStreams = null;
/*     */       } 
/*     */ 
/*     */       
/* 182 */       this.value = null;
/*     */       
/* 184 */       this.isClosed = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkClosed() throws SQLServerException {
/* 192 */     if (this.isClosed) {
/* 193 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_isFreed"));
/* 194 */       SQLServerException.makeFromDriverError(this.con, null, form.format(new Object[] { getDisplayClassName() }, ), null, true);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputStream getAsciiStream() throws SQLException {
/* 207 */     checkClosed();
/* 208 */     if (null != this.sqlCollation && !this.sqlCollation.supportsAsciiConversion()) {
/* 209 */       DataTypes.throwConversionError(getDisplayClassName(), "AsciiStream");
/*     */     }
/*     */     
/* 212 */     if (!this.delayLoadingLob && null == this.value && !this.activeStreams.isEmpty()) {
/* 213 */       getStringFromStream();
/*     */     }
/*     */ 
/*     */     
/* 217 */     InputStream getterStream = null;
/* 218 */     if (null == this.value && !this.activeStreams.isEmpty()) {
/* 219 */       InputStream inputStream = (InputStream)this.activeStreams.get(0);
/*     */       try {
/* 221 */         inputStream.reset();
/* 222 */       } catch (IOException e) {
/* 223 */         SQLServerException.makeFromDriverError(this.con, null, e.getMessage(), null, false);
/*     */       } 
/* 225 */       getterStream = new BufferedInputStream(inputStream);
/*     */     }
/* 227 */     else if (null != this.value) {
/* 228 */       getterStream = new ByteArrayInputStream(this.value.getBytes(StandardCharsets.US_ASCII));
/*     */     } 
/*     */     
/* 231 */     this.activeStreams.add(getterStream);
/* 232 */     return getterStream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Reader getCharacterStream() throws SQLException {
/* 243 */     checkClosed();
/*     */     
/* 245 */     if (!this.delayLoadingLob && null == this.value && !this.activeStreams.isEmpty()) {
/* 246 */       getStringFromStream();
/*     */     }
/*     */     
/* 249 */     Reader getterStream = null;
/* 250 */     if (null == this.value && !this.activeStreams.isEmpty()) {
/* 251 */       InputStream inputStream = (InputStream)this.activeStreams.get(0);
/*     */       try {
/* 253 */         inputStream.reset();
/* 254 */       } catch (IOException e) {
/* 255 */         SQLServerException.makeFromDriverError(this.con, null, e.getMessage(), null, false);
/*     */       } 
/* 257 */       Charset cs = (this.defaultCharset == null) ? this.typeInfo.getCharset() : this.defaultCharset;
/* 258 */       getterStream = new BufferedReader(new InputStreamReader(inputStream, cs));
/*     */     } else {
/* 260 */       getterStream = new StringReader(this.value);
/*     */     } 
/* 262 */     this.activeStreams.add(getterStream);
/* 263 */     return getterStream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Reader getCharacterStream(long pos, long length) throws SQLException {
/* 279 */     SQLServerException.throwFeatureNotSupportedException();
/* 280 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSubString(long pos, int length) throws SQLException {
/* 296 */     checkClosed();
/*     */     
/* 298 */     getStringFromStream();
/* 299 */     if (pos < 1L) {
/* 300 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidPositionIndex"));
/* 301 */       Object[] msgArgs = { Long.valueOf(pos) };
/* 302 */       SQLServerException.makeFromDriverError(this.con, null, form.format(msgArgs), null, true);
/*     */     } 
/*     */     
/* 305 */     if (length < 0) {
/* 306 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidLength"));
/* 307 */       Object[] msgArgs = { Integer.valueOf(length) };
/* 308 */       SQLServerException.makeFromDriverError(this.con, null, form.format(msgArgs), null, true);
/*     */     } 
/*     */ 
/*     */     
/* 312 */     pos--;
/*     */ 
/*     */     
/* 315 */     if (pos > this.value.length()) {
/* 316 */       pos = this.value.length();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 321 */     if (length > this.value.length() - pos) {
/* 322 */       length = (int)(this.value.length() - pos);
/*     */     }
/*     */ 
/*     */     
/* 326 */     return this.value.substring((int)pos, (int)pos + length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long length() throws SQLException {
/* 337 */     checkClosed();
/* 338 */     if (null == this.value && this.activeStreams.get(0) instanceof BaseInputStream) {
/* 339 */       int length = ((BaseInputStream)this.activeStreams.get(0)).payloadLength;
/* 340 */       if (null != this.typeInfo) {
/* 341 */         String columnTypeName = this.typeInfo.getSSTypeName();
/* 342 */         return ("nvarchar".equalsIgnoreCase(columnTypeName) || "ntext"
/* 343 */           .equalsIgnoreCase(columnTypeName)) ? (length / 2) : length;
/*     */       } 
/* 345 */       return length;
/* 346 */     }  if (null == this.value) {
/* 347 */       return 0L;
/*     */     }
/* 349 */     return this.value.length();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void fillFromStream() throws SQLException {
/* 358 */     if (!this.isClosed) {
/* 359 */       getStringFromStream();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void getStringFromStream() throws SQLServerException {
/* 369 */     if (null == this.value && !this.activeStreams.isEmpty()) {
/* 370 */       BaseInputStream stream = (BaseInputStream)this.activeStreams.get(0);
/*     */       try {
/* 372 */         stream.reset();
/* 373 */       } catch (IOException e) {
/* 374 */         SQLServerException.makeFromDriverError(this.con, null, e.getMessage(), null, false);
/*     */       } 
/* 376 */       Charset cs = (this.defaultCharset == null) ? this.typeInfo.getCharset() : this.defaultCharset;
/* 377 */       this.value = new String(stream.getBytes(), cs);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long position(Clob searchstr, long start) throws SQLException {
/* 394 */     checkClosed();
/*     */     
/* 396 */     getStringFromStream();
/* 397 */     if (start < 1L) {
/* 398 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidPositionIndex"));
/* 399 */       Object[] msgArgs = { Long.valueOf(start) };
/* 400 */       SQLServerException.makeFromDriverError(this.con, null, form.format(msgArgs), null, true);
/*     */     } 
/*     */     
/* 403 */     if (null == searchstr) {
/* 404 */       return -1L;
/*     */     }
/* 406 */     return position(searchstr.getSubString(1L, (int)searchstr.length()), start);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long position(String searchstr, long start) throws SQLException {
/* 422 */     checkClosed();
/*     */     
/* 424 */     getStringFromStream();
/* 425 */     if (start < 1L) {
/* 426 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidPositionIndex"));
/* 427 */       Object[] msgArgs = { Long.valueOf(start) };
/* 428 */       SQLServerException.makeFromDriverError(this.con, null, form.format(msgArgs), null, true);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 434 */     if (null == searchstr) {
/* 435 */       return -1L;
/*     */     }
/* 437 */     int pos = this.value.indexOf(searchstr, (int)(start - 1L));
/* 438 */     if (-1 != pos) {
/* 439 */       return pos + 1L;
/*     */     }
/* 441 */     return -1L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void truncate(long len) throws SQLException {
/* 455 */     checkClosed();
/*     */     
/* 457 */     getStringFromStream();
/* 458 */     if (len < 0L) {
/* 459 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidLength"));
/* 460 */       Object[] msgArgs = { Long.valueOf(len) };
/* 461 */       SQLServerException.makeFromDriverError(this.con, null, form.format(msgArgs), null, true);
/*     */     } 
/*     */     
/* 464 */     if (len <= 2147483647L && this.value.length() > len) {
/* 465 */       this.value = this.value.substring(0, (int)len);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OutputStream setAsciiStream(long pos) throws SQLException {
/* 479 */     checkClosed();
/*     */     
/* 481 */     if (pos < 1L) {
/* 482 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidPositionIndex"));
/* 483 */       Object[] msgArgs = { Long.valueOf(pos) };
/* 484 */       SQLServerException.makeFromDriverError(this.con, null, form.format(msgArgs), null, true);
/*     */     } 
/*     */     
/* 487 */     return new SQLServerClobAsciiOutputStream(this, pos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Writer setCharacterStream(long pos) throws SQLException {
/* 501 */     checkClosed();
/*     */     
/* 503 */     if (pos < 1L) {
/* 504 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidPositionIndex"));
/* 505 */       Object[] msgArgs = { Long.valueOf(pos) };
/* 506 */       SQLServerException.makeFromDriverError(this.con, null, form.format(msgArgs), null, true);
/*     */     } 
/*     */     
/* 509 */     return new SQLServerClobWriter(this, pos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int setString(long pos, String s) throws SQLException {
/* 524 */     checkClosed();
/*     */     
/* 526 */     if (null == s) {
/* 527 */       SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_cantSetNull"), null, true);
/*     */     }
/*     */     
/* 530 */     return setString(pos, s, 0, s.length());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int setString(long pos, String str, int offset, int len) throws SQLException {
/* 555 */     checkClosed();
/*     */     
/* 557 */     getStringFromStream();
/* 558 */     if (null == str) {
/* 559 */       SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_cantSetNull"), null, true);
/*     */     }
/*     */ 
/*     */     
/* 563 */     if (offset < 0 || offset > str.length()) {
/* 564 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidOffset"));
/* 565 */       Object[] msgArgs = { Integer.valueOf(offset) };
/* 566 */       SQLServerException.makeFromDriverError(this.con, null, form.format(msgArgs), null, true);
/*     */     } 
/*     */ 
/*     */     
/* 570 */     if (len < 0 || len > str.length() - offset) {
/* 571 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidLength"));
/* 572 */       Object[] msgArgs = { Integer.valueOf(len) };
/* 573 */       SQLServerException.makeFromDriverError(this.con, null, form.format(msgArgs), null, true);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 580 */     if (pos < 1L || pos > (this.value.length() + 1)) {
/* 581 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidPositionIndex"));
/* 582 */       Object[] msgArgs = { Long.valueOf(pos) };
/* 583 */       SQLServerException.makeFromDriverError(this.con, null, form.format(msgArgs), null, true);
/*     */     } 
/*     */ 
/*     */     
/* 587 */     pos--;
/*     */ 
/*     */     
/* 590 */     if (len >= this.value.length() - pos) {
/*     */ 
/*     */       
/* 593 */       DataTypes.getCheckedLength(this.con, getJdbcType(), pos + len, false);
/* 594 */       assert pos + len <= 2147483647L;
/*     */ 
/*     */       
/* 597 */       StringBuilder sb = new StringBuilder((int)pos + len);
/* 598 */       sb.append(this.value.substring(0, (int)pos));
/*     */ 
/*     */       
/* 601 */       sb.append(str.substring(offset, offset + len));
/*     */ 
/*     */       
/* 604 */       this.value = sb.toString();
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 610 */       StringBuilder sb = new StringBuilder(this.value.length());
/* 611 */       sb.append(this.value.substring(0, (int)pos));
/*     */ 
/*     */       
/* 614 */       sb.append(str.substring(offset, offset + len));
/*     */ 
/*     */ 
/*     */       
/* 618 */       sb.append(this.value.substring((int)pos + len));
/*     */ 
/*     */       
/* 621 */       this.value = sb.toString();
/*     */     } 
/*     */     
/* 624 */     return len;
/*     */   }
/*     */   
/*     */   protected void setDefaultCharset(Charset c) {
/* 628 */     this.defaultCharset = c;
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerClobBase.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */