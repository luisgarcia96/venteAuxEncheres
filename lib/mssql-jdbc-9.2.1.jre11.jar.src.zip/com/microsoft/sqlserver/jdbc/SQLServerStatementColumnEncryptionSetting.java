/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum SQLServerStatementColumnEncryptionSetting
/*    */ {
/* 18 */   UseConnectionSetting,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 23 */   Enabled,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 29 */   ResultSetOnly,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 34 */   Disabled;
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerStatementColumnEncryptionSetting.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */