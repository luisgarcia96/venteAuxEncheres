/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Locale;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ enum SSLProtocol
/*     */ {
/* 181 */   TLS("TLS"),
/* 182 */   TLS_V10("TLSv1"),
/* 183 */   TLS_V11("TLSv1.1"),
/* 184 */   TLS_V12("TLSv1.2");
/*     */   
/*     */   private final String name;
/*     */   
/*     */   SSLProtocol(String name) {
/* 189 */     this.name = name;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 194 */     return this.name;
/*     */   }
/*     */   
/*     */   static SSLProtocol valueOfString(String value) throws SQLServerException {
/* 198 */     SSLProtocol protocol = null;
/*     */     
/* 200 */     if (value.toLowerCase(Locale.ENGLISH).equalsIgnoreCase(TLS.toString())) {
/* 201 */       protocol = TLS;
/* 202 */     } else if (value.toLowerCase(Locale.ENGLISH).equalsIgnoreCase(TLS_V10.toString())) {
/* 203 */       protocol = TLS_V10;
/* 204 */     } else if (value.toLowerCase(Locale.ENGLISH).equalsIgnoreCase(TLS_V11.toString())) {
/* 205 */       protocol = TLS_V11;
/* 206 */     } else if (value.toLowerCase(Locale.ENGLISH).equalsIgnoreCase(TLS_V12.toString())) {
/* 207 */       protocol = TLS_V12;
/*     */     } else {
/* 209 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidSSLProtocol"));
/* 210 */       Object[] msgArgs = { value };
/* 211 */       throw new SQLServerException(null, form.format(msgArgs), null, 0, false);
/*     */     } 
/* 213 */     return protocol;
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SSLProtocol.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */