/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import com.azure.core.credential.AccessToken;
/*     */ import com.azure.core.credential.TokenRequestContext;
/*     */ import com.azure.core.http.HttpPipelineCallContext;
/*     */ import com.azure.core.http.HttpPipelineNextPolicy;
/*     */ import com.azure.core.http.HttpResponse;
/*     */ import com.azure.core.http.policy.HttpPipelinePolicy;
/*     */ import com.azure.core.util.CoreUtils;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class KeyVaultCustomCredentialPolicy
/*     */   implements HttpPipelinePolicy
/*     */ {
/*     */   private static final String WWW_AUTHENTICATE = "WWW-Authenticate";
/*     */   private static final String BEARER_TOKEN_PREFIX = "Bearer ";
/*     */   private static final String AUTHORIZATION = "Authorization";
/*     */   private final ScopeTokenCache cache;
/*     */   private final KeyVaultTokenCredential keyVaultTokenCredential;
/*     */   
/*     */   KeyVaultCustomCredentialPolicy(KeyVaultTokenCredential credential) throws SQLServerException {
/*  40 */     if (null == credential) {
/*  41 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_NullValue"));
/*  42 */       Object[] msgArgs1 = { "Credential" };
/*  43 */       throw new SQLServerException(form.format(msgArgs1), null);
/*     */     } 
/*     */     
/*  46 */     Objects.requireNonNull(credential); this.cache = new ScopeTokenCache(credential::getToken);
/*  47 */     this.keyVaultTokenCredential = credential;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<HttpResponse> process(HttpPipelineCallContext context, HttpPipelineNextPolicy next) {
/*  61 */     if (!"https".equals(context.getHttpRequest().getUrl().getProtocol())) {
/*  62 */       return Mono.error(new RuntimeException(SQLServerException.getErrString("R_TokenRequireUrl")));
/*     */     }
/*     */     
/*  65 */     return next.clone().process()
/*     */       
/*  67 */       .doOnNext(HttpResponse::close).map(res -> res.getHeaderValue("WWW-Authenticate"))
/*  68 */       .map(header -> extractChallenge(header, "Bearer ")).flatMap(map -> {
/*     */           this.keyVaultTokenCredential.setAuthorization((String)map.get("authorization"));
/*     */           this.keyVaultTokenCredential.setResource((String)map.get("resource"));
/*     */           this.keyVaultTokenCredential.setScope((String)map.get("scope"));
/*     */           this.cache.setRequest((new TokenRequestContext()).addScopes(new String[] { (String)map.get("resource") + "/.default" }));
/*     */           return this.cache.getToken();
/*  74 */         }).flatMap(token -> {
/*     */           context.getHttpRequest().setHeader("Authorization", "Bearer " + token.getToken());
/*     */           return next.process();
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Map<String, String> extractChallenge(String authenticateHeader, String authChallengePrefix) {
/*  90 */     if (!isValidChallenge(authenticateHeader, authChallengePrefix)) {
/*  91 */       return null;
/*     */     }
/*     */     
/*  94 */     authenticateHeader = authenticateHeader.toLowerCase(Locale.ROOT).replace(authChallengePrefix.toLowerCase(Locale.ROOT), "");
/*     */     
/*  96 */     String[] challenges = authenticateHeader.split(", ");
/*  97 */     Map<String, String> challengeMap = new HashMap<>();
/*  98 */     for (String pair : challenges) {
/*  99 */       String[] keyValue = pair.split("=");
/* 100 */       challengeMap.put(keyValue[0].replaceAll("\"", ""), keyValue[1].replaceAll("\"", ""));
/*     */     } 
/* 102 */     return challengeMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isValidChallenge(String authenticateHeader, String authChallengePrefix) {
/* 115 */     return (!CoreUtils.isNullOrEmpty(authenticateHeader) && authenticateHeader.toLowerCase(Locale.ROOT)
/* 116 */       .startsWith(authChallengePrefix.toLowerCase(Locale.ROOT)));
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\KeyVaultCustomCredentialPolicy.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */