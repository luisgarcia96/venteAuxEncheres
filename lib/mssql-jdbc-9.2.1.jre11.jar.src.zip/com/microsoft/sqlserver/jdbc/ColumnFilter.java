package com.microsoft.sqlserver.jdbc;

abstract class ColumnFilter {
  abstract Object apply(Object paramObject, JDBCType paramJDBCType) throws SQLServerException;
}


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\ColumnFilter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */