/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.net.InetAddress;
/*      */ import java.net.UnknownHostException;
/*      */ import java.text.DecimalFormat;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.Date;
/*      */ import java.util.Locale;
/*      */ import java.util.Properties;
/*      */ import java.util.Set;
/*      */ import java.util.UUID;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.LogManager;
/*      */ import java.util.logging.Logger;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class Util
/*      */ {
/*   31 */   static final String SYSTEM_SPEC_VERSION = System.getProperty("java.specification.version");
/*   32 */   static final char[] hexChars = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
/*      */ 
/*      */   
/*      */   static final String WSIDNotAvailable = "";
/*      */   
/*      */   static final String ACTIVITY_ID_TRACE_PROPERTY = "com.microsoft.sqlserver.jdbc.traceactivity";
/*      */   
/*   39 */   static final String SYSTEM_JRE = System.getProperty("java.vendor") + " " + System.getProperty("java.vendor"); static final boolean use43Wrapper;
/*      */   
/*      */   static boolean isIBM() {
/*   42 */     return SYSTEM_JRE.startsWith("IBM");
/*      */   }
/*      */   
/*      */   static String getJVMArchOnWindows() {
/*   46 */     return System.getProperty("os.arch").contains("64") ? "x64" : "x86";
/*      */   }
/*      */   
/*      */   static final boolean isCharType(int jdbcType) {
/*   50 */     switch (jdbcType) {
/*      */       case -16:
/*      */       case -15:
/*      */       case -9:
/*      */       case -1:
/*      */       case 1:
/*      */       case 12:
/*   57 */         return true;
/*      */     } 
/*   59 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   static final Boolean isCharType(SSType ssType) {
/*   64 */     switch (ssType) {
/*      */       case OBJECT:
/*      */       case STRING:
/*      */       case BYTEARRAY:
/*      */       case BIGDECIMAL:
/*      */       case TIMESTAMP:
/*      */       case TIME:
/*   71 */         return Boolean.valueOf(true);
/*      */     } 
/*   73 */     return Boolean.valueOf(false);
/*      */   }
/*      */ 
/*      */   
/*      */   static final Boolean isBinaryType(SSType ssType) {
/*   78 */     switch (ssType) {
/*      */       case DATETIMEOFFSET:
/*      */       case CLOB:
/*      */       case NCLOB:
/*      */       case READER:
/*   83 */         return Boolean.valueOf(true);
/*      */     } 
/*   85 */     return Boolean.valueOf(false);
/*      */   }
/*      */ 
/*      */   
/*      */   static final Boolean isBinaryType(int jdbcType) {
/*   90 */     switch (jdbcType) {
/*      */       case -4:
/*      */       case -3:
/*      */       case -2:
/*   94 */         return Boolean.valueOf(true);
/*      */     } 
/*   96 */     return Boolean.valueOf(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static short readShort(byte[] data, int nOffset) {
/*  110 */     return (short)(data[nOffset] & 0xFF | (data[nOffset + 1] & 0xFF) << 8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static int readUnsignedShort(byte[] data, int nOffset) {
/*  123 */     return data[nOffset] & 0xFF | (data[nOffset + 1] & 0xFF) << 8;
/*      */   }
/*      */   
/*      */   static int readUnsignedShortBigEndian(byte[] data, int nOffset) {
/*  127 */     return (data[nOffset] & 0xFF) << 8 | data[nOffset + 1] & 0xFF;
/*      */   }
/*      */   
/*      */   static void writeShort(short value, byte[] valueBytes, int offset) {
/*  131 */     valueBytes[offset + 0] = (byte)(value >> 0 & 0xFF);
/*  132 */     valueBytes[offset + 1] = (byte)(value >> 8 & 0xFF);
/*      */   }
/*      */   
/*      */   static void writeShortBigEndian(short value, byte[] valueBytes, int offset) {
/*  136 */     valueBytes[offset + 0] = (byte)(value >> 8 & 0xFF);
/*  137 */     valueBytes[offset + 1] = (byte)(value >> 0 & 0xFF);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static int readInt(byte[] data, int nOffset) {
/*  150 */     int b1 = data[nOffset + 0] & 0xFF;
/*  151 */     int b2 = (data[nOffset + 1] & 0xFF) << 8;
/*  152 */     int b3 = (data[nOffset + 2] & 0xFF) << 16;
/*  153 */     int b4 = (data[nOffset + 3] & 0xFF) << 24;
/*  154 */     return b4 | b3 | b2 | b1;
/*      */   }
/*      */   
/*      */   static int readIntBigEndian(byte[] data, int nOffset) {
/*  158 */     return (data[nOffset + 3] & 0xFF) << 0 | (data[nOffset + 2] & 0xFF) << 8 | (data[nOffset + 1] & 0xFF) << 16 | (data[nOffset + 0] & 0xFF) << 24;
/*      */   }
/*      */ 
/*      */   
/*      */   static void writeInt(int value, byte[] valueBytes, int offset) {
/*  163 */     valueBytes[offset + 0] = (byte)(value >> 0 & 0xFF);
/*  164 */     valueBytes[offset + 1] = (byte)(value >> 8 & 0xFF);
/*  165 */     valueBytes[offset + 2] = (byte)(value >> 16 & 0xFF);
/*  166 */     valueBytes[offset + 3] = (byte)(value >> 24 & 0xFF);
/*      */   }
/*      */   
/*      */   static void writeIntBigEndian(int value, byte[] valueBytes, int offset) {
/*  170 */     valueBytes[offset + 0] = (byte)(value >> 24 & 0xFF);
/*  171 */     valueBytes[offset + 1] = (byte)(value >> 16 & 0xFF);
/*  172 */     valueBytes[offset + 2] = (byte)(value >> 8 & 0xFF);
/*  173 */     valueBytes[offset + 3] = (byte)(value >> 0 & 0xFF);
/*      */   }
/*      */   
/*      */   static void writeLongBigEndian(long value, byte[] valueBytes, int offset) {
/*  177 */     valueBytes[offset + 0] = (byte)(int)(value >> 56L & 0xFFL);
/*  178 */     valueBytes[offset + 1] = (byte)(int)(value >> 48L & 0xFFL);
/*  179 */     valueBytes[offset + 2] = (byte)(int)(value >> 40L & 0xFFL);
/*  180 */     valueBytes[offset + 3] = (byte)(int)(value >> 32L & 0xFFL);
/*  181 */     valueBytes[offset + 4] = (byte)(int)(value >> 24L & 0xFFL);
/*  182 */     valueBytes[offset + 5] = (byte)(int)(value >> 16L & 0xFFL);
/*  183 */     valueBytes[offset + 6] = (byte)(int)(value >> 8L & 0xFFL);
/*  184 */     valueBytes[offset + 7] = (byte)(int)(value >> 0L & 0xFFL);
/*      */   }
/*      */   
/*      */   static BigDecimal readBigDecimal(byte[] valueBytes, int valueLength, int scale) {
/*  188 */     int sign = (0 == valueBytes[0]) ? -1 : 1;
/*  189 */     byte[] magnitude = new byte[valueLength - 1];
/*  190 */     for (int i = 1; i <= magnitude.length; i++)
/*  191 */       magnitude[magnitude.length - i] = valueBytes[i]; 
/*  192 */     return new BigDecimal(new BigInteger(sign, magnitude), scale);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static long readLong(byte[] data, int nOffset) {
/*  205 */     return (data[nOffset + 7] & 0xFF) << 56L | (data[nOffset + 6] & 0xFF) << 48L | (data[nOffset + 5] & 0xFF) << 40L | (data[nOffset + 4] & 0xFF) << 32L | (data[nOffset + 3] & 0xFF) << 24L | (data[nOffset + 2] & 0xFF) << 16L | (data[nOffset + 1] & 0xFF) << 8L | (data[nOffset] & 0xFF);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void writeLong(long value, byte[] valueBytes, int offset) {
/*  222 */     valueBytes[offset++] = (byte)(int)(value & 0xFFL);
/*  223 */     valueBytes[offset++] = (byte)(int)(value >> 8L & 0xFFL);
/*  224 */     valueBytes[offset++] = (byte)(int)(value >> 16L & 0xFFL);
/*  225 */     valueBytes[offset++] = (byte)(int)(value >> 24L & 0xFFL);
/*  226 */     valueBytes[offset++] = (byte)(int)(value >> 32L & 0xFFL);
/*  227 */     valueBytes[offset++] = (byte)(int)(value >> 40L & 0xFFL);
/*  228 */     valueBytes[offset++] = (byte)(int)(value >> 48L & 0xFFL);
/*  229 */     valueBytes[offset] = (byte)(int)(value >> 56L & 0xFFL);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Properties parseUrl(String url, Logger logger) throws SQLServerException {
/*      */     String property;
/*  242 */     Properties p = new Properties();
/*  243 */     String tmpUrl = url;
/*  244 */     String sPrefix = "jdbc:sqlserver://";
/*  245 */     StringBuilder result = new StringBuilder();
/*  246 */     String name = "";
/*  247 */     String value = "";
/*      */     
/*  249 */     if (!tmpUrl.startsWith(sPrefix)) {
/*  250 */       return null;
/*      */     }
/*  252 */     tmpUrl = tmpUrl.substring(sPrefix.length());
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  257 */     int inStart = 0;
/*  258 */     int inServerName = 1;
/*  259 */     int inPort = 2;
/*  260 */     int inInstanceName = 3;
/*  261 */     int inEscapedValueStart = 4;
/*  262 */     int inEscapedValueEnd = 5;
/*  263 */     int inValue = 6;
/*  264 */     int inName = 7;
/*      */     
/*  266 */     int state = 0;
/*      */     
/*  268 */     int i = 0;
/*  269 */     while (i < tmpUrl.length()) {
/*  270 */       StringBuilder builder; char ch = tmpUrl.charAt(i);
/*  271 */       switch (state) {
/*      */         case 0:
/*  273 */           if (ch == ';') {
/*      */             
/*  275 */             state = 7; break;
/*      */           } 
/*  277 */           result.append(ch);
/*  278 */           state = 1;
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         case 1:
/*  284 */           if (ch == ';' || ch == ':' || ch == '\\') {
/*      */             
/*  286 */             String str = result.toString().trim();
/*  287 */             if (str.length() > 0) {
/*  288 */               p.put(SQLServerDriverStringProperty.SERVER_NAME.toString(), str);
/*  289 */               if (logger.isLoggable(Level.FINE)) {
/*  290 */                 logger.fine("Property:serverName Value:" + str);
/*      */               }
/*      */             } 
/*  293 */             result.setLength(0);
/*      */             
/*  295 */             if (ch == ';') {
/*  296 */               state = 7; break;
/*  297 */             }  if (ch == ':') {
/*  298 */               state = 2; break;
/*      */             } 
/*  300 */             state = 3; break;
/*      */           } 
/*  302 */           result.append(ch);
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 2:
/*  309 */           if (ch == ';') {
/*  310 */             String str = result.toString().trim();
/*  311 */             if (logger.isLoggable(Level.FINE)) {
/*  312 */               logger.fine("Property:portNumber Value:" + str);
/*      */             }
/*  314 */             p.put(SQLServerDriverIntProperty.PORT_NUMBER.toString(), str);
/*  315 */             result.setLength(0);
/*  316 */             state = 7; break;
/*      */           } 
/*  318 */           result.append(ch);
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         case 3:
/*  324 */           if (ch == ';' || ch == ':') {
/*      */             
/*  326 */             String str = result.toString().trim();
/*  327 */             if (logger.isLoggable(Level.FINE)) {
/*  328 */               logger.fine("Property:instanceName Value:" + str);
/*      */             }
/*  330 */             p.put(SQLServerDriverStringProperty.INSTANCE_NAME.toString(), str.toLowerCase(Locale.US));
/*  331 */             result.setLength(0);
/*      */             
/*  333 */             if (ch == ';') {
/*  334 */               state = 7; break;
/*      */             } 
/*  336 */             state = 2; break;
/*      */           } 
/*  338 */           result.append(ch);
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         case 7:
/*  344 */           if (ch == '=') {
/*      */             
/*  346 */             name = name.trim();
/*  347 */             if (name.length() <= 0) {
/*  348 */               SQLServerException.makeFromDriverError(null, null, 
/*  349 */                   SQLServerException.getErrString("R_errorConnectionString"), null, true);
/*      */             }
/*  351 */             state = 6; break;
/*  352 */           }  if (ch == ';') {
/*  353 */             name = name.trim();
/*  354 */             if (name.length() > 0) {
/*  355 */               SQLServerException.makeFromDriverError(null, null, 
/*  356 */                   SQLServerException.getErrString("R_errorConnectionString"), null, true);
/*      */             }
/*      */             break;
/*      */           } 
/*  360 */           builder = new StringBuilder();
/*  361 */           builder.append(name);
/*  362 */           builder.append(ch);
/*  363 */           name = builder.toString();
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         case 6:
/*  369 */           if (ch == ';') {
/*      */             
/*  371 */             value = value.trim();
/*  372 */             name = SQLServerDriver.getNormalizedPropertyName(name, logger);
/*  373 */             if (null != name) {
/*  374 */               if (logger.isLoggable(Level.FINE) && 
/*  375 */                 !name.equals(SQLServerDriverStringProperty.USER.toString())) {
/*  376 */                 if (!name.toLowerCase(Locale.ENGLISH).contains("password") && 
/*  377 */                   !name.toLowerCase(Locale.ENGLISH).contains("keystoresecret")) {
/*  378 */                   logger.fine("Property:" + name + " Value:" + value);
/*      */                 } else {
/*  380 */                   logger.fine("Property:" + name);
/*      */                 } 
/*      */               }
/*      */               
/*  384 */               p.put(name, value);
/*      */             } 
/*  386 */             name = "";
/*  387 */             value = "";
/*  388 */             state = 7; break;
/*      */           } 
/*  390 */           if (ch == '{') {
/*  391 */             state = 4;
/*  392 */             value = value.trim();
/*  393 */             if (value.length() > 0)
/*  394 */               SQLServerException.makeFromDriverError(null, null, 
/*  395 */                   SQLServerException.getErrString("R_errorConnectionString"), null, true); 
/*      */             break;
/*      */           } 
/*  398 */           builder = new StringBuilder();
/*  399 */           builder.append(value);
/*  400 */           builder.append(ch);
/*  401 */           value = builder.toString();
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 4:
/*  412 */           if (ch == '}' && i + 1 < tmpUrl.length() && tmpUrl.charAt(i + 1) == '}') {
/*  413 */             builder = new StringBuilder();
/*  414 */             builder.append(value);
/*  415 */             builder.append(ch);
/*  416 */             value = builder.toString();
/*  417 */             i++;
/*      */             break;
/*      */           } 
/*  420 */           if (ch == '}') {
/*      */             
/*  422 */             name = SQLServerDriver.getNormalizedPropertyName(name, logger);
/*  423 */             if (null != name) {
/*  424 */               if (logger.isLoggable(Level.FINE) && 
/*  425 */                 !name.equals(SQLServerDriverStringProperty.USER.toString()) && 
/*  426 */                 !name.equals(SQLServerDriverStringProperty.PASSWORD.toString())) {
/*  427 */                 logger.fine("Property:" + name + " Value:" + value);
/*      */               }
/*  429 */               p.put(name, value);
/*      */             } 
/*      */             
/*  432 */             name = "";
/*  433 */             value = "";
/*      */ 
/*      */             
/*  436 */             state = 5; break;
/*      */           } 
/*  438 */           builder = new StringBuilder();
/*  439 */           builder.append(value);
/*  440 */           builder.append(ch);
/*  441 */           value = builder.toString();
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 5:
/*  448 */           if (ch == ';') {
/*      */             
/*  450 */             state = 7; break;
/*  451 */           }  if (ch != ' ')
/*      */           {
/*  453 */             SQLServerException.makeFromDriverError(null, null, 
/*  454 */                 SQLServerException.getErrString("R_errorConnectionString"), null, true);
/*      */           }
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/*  460 */           assert false : "parseURL: Invalid state " + state; break;
/*      */       } 
/*  462 */       i++;
/*      */     } 
/*      */ 
/*      */     
/*  466 */     switch (state) {
/*      */       case 1:
/*  468 */         property = result.toString().trim();
/*  469 */         if (property.length() > 0) {
/*  470 */           if (logger.isLoggable(Level.FINE)) {
/*  471 */             logger.fine("Property:serverName Value:" + property);
/*      */           }
/*  473 */           p.put(SQLServerDriverStringProperty.SERVER_NAME.toString(), property);
/*      */         } 
/*      */       
/*      */       case 2:
/*  477 */         property = result.toString().trim();
/*  478 */         if (logger.isLoggable(Level.FINE)) {
/*  479 */           logger.fine("Property:portNumber Value:" + property);
/*      */         }
/*  481 */         p.put(SQLServerDriverIntProperty.PORT_NUMBER.toString(), property);
/*      */       
/*      */       case 3:
/*  484 */         property = result.toString().trim();
/*  485 */         if (logger.isLoggable(Level.FINE)) {
/*  486 */           logger.fine("Property:instanceName Value:" + property);
/*      */         }
/*  488 */         p.put(SQLServerDriverStringProperty.INSTANCE_NAME.toString(), property);
/*      */ 
/*      */       
/*      */       case 6:
/*  492 */         value = value.trim();
/*  493 */         name = SQLServerDriver.getNormalizedPropertyName(name, logger);
/*  494 */         if (null != name) {
/*  495 */           if (logger.isLoggable(Level.FINE) && 
/*  496 */             !name.equals(SQLServerDriverStringProperty.USER.toString()) && 
/*  497 */             !name.equals(SQLServerDriverStringProperty.PASSWORD.toString()) && 
/*  498 */             !name.equals(SQLServerDriverStringProperty.KEY_STORE_SECRET.toString())) {
/*  499 */             logger.fine("Property:" + name + " Value:" + value);
/*      */           }
/*  501 */           p.put(name, value);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 0:
/*      */       case 5:
/*  522 */         return p;
/*      */       case 7:
/*      */         name = name.trim();
/*      */         if (name.length() > 0) {
/*      */           SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_errorConnectionString"), null, true);
/*      */         }
/*      */     } 
/*      */     SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_errorConnectionString"), null, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static String escapeSQLId(String inID) {
/*  543 */     StringBuilder outID = new StringBuilder(inID.length() + 2);
/*      */     
/*  545 */     outID.append('[');
/*  546 */     for (int i = 0; i < inID.length(); i++) {
/*  547 */       char ch = inID.charAt(i);
/*  548 */       if (']' == ch) {
/*  549 */         outID.append("]]");
/*      */       } else {
/*  551 */         outID.append(ch);
/*      */       } 
/*  553 */     }  outID.append(']');
/*  554 */     return outID.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void checkDuplicateColumnName(String columnName, Set<String> columnNames) throws SQLServerException {
/*  567 */     if (!columnNames.add(columnName)) {
/*  568 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_TVPDuplicateColumnName"));
/*  569 */       Object[] msgArgs = { columnName };
/*  570 */       throw new SQLServerException(null, form.format(msgArgs), null, 0, false);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static String readUnicodeString(byte[] b, int offset, int byteLength, SQLServerConnection conn) throws SQLServerException {
/*      */     try {
/*  590 */       return new String(b, offset, byteLength, Encoding.UNICODE.charset());
/*  591 */     } catch (IndexOutOfBoundsException ex) {
/*      */       
/*  593 */       String txtMsg = SQLServerException.checkAndAppendClientConnId(SQLServerException.getErrString("R_stringReadError"), conn);
/*  594 */       MessageFormat form = new MessageFormat(txtMsg);
/*  595 */       Object[] msgArgs = { Integer.valueOf(offset) };
/*      */       
/*  597 */       throw new SQLServerException(form.format(msgArgs), null, 0, ex);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static String byteToHexDisplayString(byte[] b) {
/*  611 */     if (null == b) {
/*  612 */       return "(null)";
/*      */     }
/*  614 */     StringBuilder sb = new StringBuilder(b.length * 2 + 2);
/*  615 */     sb.append("0x");
/*  616 */     for (byte aB : b) {
/*  617 */       int hexVal = aB & 0xFF;
/*  618 */       sb.append(hexChars[(hexVal & 0xF0) >> 4]);
/*  619 */       sb.append(hexChars[hexVal & 0xF]);
/*      */     } 
/*  621 */     return sb.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static String bytesToHexString(byte[] b, int length) {
/*  632 */     StringBuilder sb = new StringBuilder(length * 2);
/*  633 */     for (int i = 0; i < length; i++) {
/*  634 */       int hexVal = b[i] & 0xFF;
/*  635 */       sb.append(hexChars[(hexVal & 0xF0) >> 4]);
/*  636 */       sb.append(hexChars[hexVal & 0xF]);
/*      */     } 
/*  638 */     return sb.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static String lookupHostName() {
/*      */     try {
/*  652 */       InetAddress localAddress = InetAddress.getLocalHost();
/*  653 */       if (null != localAddress) {
/*  654 */         String value = localAddress.getHostName();
/*  655 */         if (null != value && value.length() > 0) {
/*  656 */           return value;
/*      */         }
/*  658 */         value = localAddress.getHostAddress();
/*  659 */         if (null != value && value.length() > 0)
/*  660 */           return value; 
/*      */       } 
/*  662 */     } catch (UnknownHostException e) {
/*  663 */       return "";
/*      */     } 
/*      */     
/*  666 */     return "";
/*      */   }
/*      */   
/*      */   static final byte[] asGuidByteArray(UUID aId) {
/*  670 */     long msb = aId.getMostSignificantBits();
/*  671 */     long lsb = aId.getLeastSignificantBits();
/*  672 */     byte[] buffer = new byte[16];
/*  673 */     writeLongBigEndian(msb, buffer, 0);
/*  674 */     writeLongBigEndian(lsb, buffer, 8);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  683 */     byte tmpByte = buffer[0];
/*  684 */     buffer[0] = buffer[3];
/*  685 */     buffer[3] = tmpByte;
/*  686 */     tmpByte = buffer[1];
/*  687 */     buffer[1] = buffer[2];
/*  688 */     buffer[2] = tmpByte;
/*      */ 
/*      */     
/*  691 */     tmpByte = buffer[4];
/*  692 */     buffer[4] = buffer[5];
/*  693 */     buffer[5] = tmpByte;
/*      */ 
/*      */     
/*  696 */     tmpByte = buffer[6];
/*  697 */     buffer[6] = buffer[7];
/*  698 */     buffer[7] = tmpByte;
/*      */     
/*  700 */     return buffer;
/*      */   }
/*      */   
/*      */   static final UUID readGUIDtoUUID(byte[] inputGUID) throws SQLServerException {
/*  704 */     if (inputGUID.length != 16) {
/*  705 */       throw new SQLServerException("guid length must be 16", null);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  715 */     byte tmpByte = inputGUID[0];
/*  716 */     inputGUID[0] = inputGUID[3];
/*  717 */     inputGUID[3] = tmpByte;
/*  718 */     tmpByte = inputGUID[1];
/*  719 */     inputGUID[1] = inputGUID[2];
/*  720 */     inputGUID[2] = tmpByte;
/*      */ 
/*      */     
/*  723 */     tmpByte = inputGUID[4];
/*  724 */     inputGUID[4] = inputGUID[5];
/*  725 */     inputGUID[5] = tmpByte;
/*      */ 
/*      */     
/*  728 */     tmpByte = inputGUID[6];
/*  729 */     inputGUID[6] = inputGUID[7];
/*  730 */     inputGUID[7] = tmpByte;
/*      */     
/*  732 */     long msb = 0L;
/*  733 */     for (int i = 0; i < 8; i++) {
/*  734 */       msb = msb << 8L | inputGUID[i] & 0xFFL;
/*      */     }
/*  736 */     long lsb = 0L;
/*  737 */     for (int j = 8; j < 16; j++) {
/*  738 */       lsb = lsb << 8L | inputGUID[j] & 0xFFL;
/*      */     }
/*  740 */     return new UUID(msb, lsb);
/*      */   }
/*      */   
/*      */   static final String readGUID(byte[] inputGUID) throws SQLServerException {
/*  744 */     String guidTemplate = "NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN";
/*  745 */     byte[] guid = inputGUID;
/*      */     
/*  747 */     StringBuilder sb = new StringBuilder(guidTemplate.length()); int i;
/*  748 */     for (i = 0; i < 4; i++) {
/*  749 */       sb.append(hexChars[(guid[3 - i] & 0xF0) >> 4]);
/*  750 */       sb.append(hexChars[guid[3 - i] & 0xF]);
/*      */     } 
/*  752 */     sb.append('-');
/*  753 */     for (i = 0; i < 2; i++) {
/*  754 */       sb.append(hexChars[(guid[5 - i] & 0xF0) >> 4]);
/*  755 */       sb.append(hexChars[guid[5 - i] & 0xF]);
/*      */     } 
/*  757 */     sb.append('-');
/*  758 */     for (i = 0; i < 2; i++) {
/*  759 */       sb.append(hexChars[(guid[7 - i] & 0xF0) >> 4]);
/*  760 */       sb.append(hexChars[guid[7 - i] & 0xF]);
/*      */     } 
/*  762 */     sb.append('-');
/*  763 */     for (i = 0; i < 2; i++) {
/*  764 */       sb.append(hexChars[(guid[8 + i] & 0xF0) >> 4]);
/*  765 */       sb.append(hexChars[guid[8 + i] & 0xF]);
/*      */     } 
/*  767 */     sb.append('-');
/*  768 */     for (i = 0; i < 6; i++) {
/*  769 */       sb.append(hexChars[(guid[10 + i] & 0xF0) >> 4]);
/*  770 */       sb.append(hexChars[guid[10 + i] & 0xF]);
/*      */     } 
/*      */     
/*  773 */     return sb.toString();
/*      */   }
/*      */   
/*      */   static boolean isActivityTraceOn() {
/*  777 */     LogManager lm = LogManager.getLogManager();
/*  778 */     String activityTrace = lm.getProperty("com.microsoft.sqlserver.jdbc.traceactivity");
/*  779 */     return "on".equalsIgnoreCase(activityTrace);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static boolean shouldHonorAEForRead(SQLServerStatementColumnEncryptionSetting stmtColumnEncryptionSetting, SQLServerConnection connection) {
/*  791 */     switch (stmtColumnEncryptionSetting) {
/*      */       case OBJECT:
/*  793 */         return false;
/*      */       case STRING:
/*      */       case BYTEARRAY:
/*  796 */         return true;
/*      */     } 
/*      */     
/*  799 */     assert SQLServerStatementColumnEncryptionSetting.UseConnectionSetting == stmtColumnEncryptionSetting : "Unexpected value for command level override";
/*  800 */     return (connection != null && connection.isColumnEncryptionSettingEnabled());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static boolean shouldHonorAEForParameters(SQLServerStatementColumnEncryptionSetting stmtColumnEncryptionSetting, SQLServerConnection connection) {
/*  813 */     switch (stmtColumnEncryptionSetting) {
/*      */       case OBJECT:
/*      */       case BYTEARRAY:
/*  816 */         return false;
/*      */       case STRING:
/*  818 */         return true;
/*      */     } 
/*      */     
/*  821 */     assert SQLServerStatementColumnEncryptionSetting.UseConnectionSetting == stmtColumnEncryptionSetting : "Unexpected value for command level override";
/*  822 */     return (connection != null && connection.isColumnEncryptionSettingEnabled());
/*      */   }
/*      */ 
/*      */   
/*      */   static void validateMoneyRange(BigDecimal bd, JDBCType jdbcType) throws SQLServerException {
/*  827 */     if (null == bd) {
/*      */       return;
/*      */     }
/*  830 */     switch (jdbcType) {
/*      */       case OBJECT:
/*  832 */         if (1 != bd.compareTo(SSType.MAX_VALUE_MONEY) && -1 != bd.compareTo(SSType.MIN_VALUE_MONEY)) {
/*      */           return;
/*      */         }
/*      */         break;
/*      */       case STRING:
/*  837 */         if (1 != bd.compareTo(SSType.MAX_VALUE_SMALLMONEY) && -1 != bd
/*  838 */           .compareTo(SSType.MIN_VALUE_SMALLMONEY)) {
/*      */           return;
/*      */         }
/*      */         break;
/*      */     } 
/*      */ 
/*      */     
/*  845 */     MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_valueOutOfRange"));
/*  846 */     Object[] msgArgs = { jdbcType };
/*  847 */     throw new SQLServerException(form.format(msgArgs), null);
/*      */   }
/*      */   
/*      */   static int getValueLengthBaseOnJavaType(Object value, JavaType javaType, Integer precision, Integer scale, JDBCType jdbcType) throws SQLServerException {
/*      */     int length;
/*  852 */     switch (javaType) {
/*      */ 
/*      */       
/*      */       case OBJECT:
/*  856 */         switch (jdbcType) {
/*      */           case BYTEARRAY:
/*      */           case BIGDECIMAL:
/*  859 */             javaType = JavaType.BIGDECIMAL;
/*      */             break;
/*      */           case TIMESTAMP:
/*  862 */             javaType = JavaType.TIME;
/*      */             break;
/*      */           case TIME:
/*  865 */             javaType = JavaType.TIMESTAMP;
/*      */             break;
/*      */           case DATETIMEOFFSET:
/*  868 */             javaType = JavaType.DATETIMEOFFSET;
/*      */             break;
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*      */         break;
/*      */     } 
/*      */ 
/*      */     
/*  878 */     switch (javaType) {
/*      */       case STRING:
/*  880 */         if (JDBCType.GUID == jdbcType) {
/*  881 */           String guidTemplate = "XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX";
/*  882 */           return (null == value) ? 0 : guidTemplate.length();
/*  883 */         }  if (JDBCType.TIMESTAMP == jdbcType || JDBCType.TIME == jdbcType || JDBCType.DATETIMEOFFSET == jdbcType)
/*      */         {
/*  885 */           return (null == scale) ? 7 : scale.intValue(); } 
/*  886 */         if (JDBCType.BINARY == jdbcType || JDBCType.VARBINARY == jdbcType)
/*  887 */           return (null == value) ? 0 : (ParameterUtils.HexToBin((String)value)).length; 
/*  888 */         if (JDBCType.GEOMETRY == jdbcType)
/*  889 */           return (null == value) ? 0 : (((Geometry)value).serialize()).length; 
/*  890 */         if (JDBCType.GEOGRAPHY == jdbcType) {
/*  891 */           return (null == value) ? 0 : (((Geography)value).serialize()).length;
/*      */         }
/*  893 */         return (null == value) ? 0 : ((String)value).length();
/*      */       
/*      */       case BYTEARRAY:
/*  896 */         return (null == value) ? 0 : ((byte[])value).length;
/*      */       
/*      */       case BIGDECIMAL:
/*  899 */         if (null == precision) {
/*  900 */           if (null == value) {
/*  901 */             length = 0;
/*      */           }
/*  903 */           else if (0 == ((BigDecimal)value).intValue()) {
/*  904 */             String s = "" + value;
/*  905 */             s = s.replaceAll("\\-", "");
/*  906 */             if (s.startsWith("0.")) {
/*      */               
/*  908 */               s = s.replaceAll("0\\.", "");
/*      */             } else {
/*  910 */               s = s.replaceAll("\\.", "");
/*      */             } 
/*  912 */             length = s.length();
/*      */           
/*      */           }
/*  915 */           else if (("" + value).contains("E")) {
/*  916 */             DecimalFormat dform = new DecimalFormat("###.#####");
/*  917 */             String s = dform.format(value);
/*  918 */             s = s.replaceAll("\\.", "");
/*  919 */             s = s.replaceAll("\\-", "");
/*  920 */             length = s.length();
/*      */           } else {
/*  922 */             length = ((BigDecimal)value).precision();
/*      */           } 
/*      */         } else {
/*      */           
/*  926 */           length = precision.intValue();
/*      */         } 
/*  928 */         return length;
/*      */       case TIMESTAMP:
/*      */       case TIME:
/*      */       case DATETIMEOFFSET:
/*  932 */         return (null == scale) ? 7 : scale.intValue();
/*      */       case CLOB:
/*  934 */         return (null == value) ? 0 : 2147483646;
/*      */       case NCLOB:
/*      */       case READER:
/*  937 */         return (null == value) ? 0 : 1073741823;
/*      */     } 
/*  939 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static synchronized boolean checkIfNeedNewAccessToken(SQLServerConnection connection, Date accessTokenExpireDate) {
/*  948 */     Date now = new Date();
/*      */ 
/*      */ 
/*      */     
/*  952 */     if (accessTokenExpireDate.getTime() - now.getTime() < 2700000L) {
/*      */ 
/*      */       
/*  955 */       if (accessTokenExpireDate.getTime() - now.getTime() < 600000L) {
/*  956 */         return true;
/*      */       }
/*      */       
/*  959 */       if (connection.attemptRefreshTokenLocked) {
/*  960 */         return false;
/*      */       }
/*  962 */       connection.attemptRefreshTokenLocked = true;
/*  963 */       return true;
/*      */     } 
/*      */ 
/*      */     
/*  967 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static {
/*  973 */     boolean supportJDBC43 = true;
/*      */     try {
/*  975 */       DriverJDBCVersion.checkSupportsJDBC43();
/*  976 */     } catch (UnsupportedOperationException e) {
/*  977 */       supportJDBC43 = false;
/*      */     } 
/*      */     
/*  980 */     double jvmVersion = Double.parseDouble(SYSTEM_SPEC_VERSION);
/*      */     
/*  982 */     use43Wrapper = (supportJDBC43 && 9.0D <= jvmVersion);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static boolean use43Wrapper() {
/*  988 */     return use43Wrapper;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static <T> T newInstance(Class<?> returnType, String className, String constructorArg, Object[] msgArgs) throws InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException, ClassNotFoundException {
/*  994 */     Class<?> clazz = Class.forName(className);
/*  995 */     if (!returnType.isAssignableFrom(clazz)) {
/*  996 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_unassignableError"));
/*  997 */       throw new IllegalArgumentException(form.format(msgArgs));
/*      */     } 
/*  999 */     if (constructorArg == null) {
/* 1000 */       return clazz.getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
/*      */     }
/* 1002 */     return clazz.getDeclaredConstructor(new Class[] { String.class }).newInstance(new Object[] { constructorArg });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static String escapeSingleQuotes(String name) {
/* 1014 */     return name.replace("'", "''");
/*      */   }
/*      */   
/*      */   static String convertInputStreamToString(InputStream is) throws IOException {
/* 1018 */     ByteArrayOutputStream result = new ByteArrayOutputStream();
/* 1019 */     byte[] buffer = new byte[1024];
/*      */     int length;
/* 1021 */     while ((length = is.read(buffer)) != -1) {
/* 1022 */       result.write(buffer, 0, length);
/*      */     }
/* 1024 */     return result.toString();
/*      */   }
/*      */   
/*      */   static String zeroOneToYesNo(int i) {
/* 1028 */     return (0 == i) ? "NO" : "YES";
/*      */   }
/*      */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\Util.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */