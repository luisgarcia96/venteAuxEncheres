/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SQLServerResultSetMetaData
/*     */   implements ISQLServerResultSetMetaData
/*     */ {
/*     */   private static final long serialVersionUID = -5747558730471411712L;
/*     */   private SQLServerConnection con;
/*     */   private final SQLServerResultSet rs;
/*  28 */   private static final Logger logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerResultSetMetaData");
/*     */   
/*  30 */   private static final AtomicInteger baseID = new AtomicInteger(0);
/*     */   
/*     */   private final String traceID;
/*     */ 
/*     */   
/*     */   private static int nextInstanceID() {
/*  36 */     return baseID.incrementAndGet();
/*     */   }
/*     */   
/*     */   public final String toString() {
/*  40 */     return this.traceID;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SQLServerResultSetMetaData(SQLServerConnection con, SQLServerResultSet rs) {
/*  52 */     this.traceID = " SQLServerResultSetMetaData:" + nextInstanceID();
/*  53 */     this.con = con;
/*  54 */     this.rs = rs;
/*  55 */     assert rs != null;
/*  56 */     if (logger.isLoggable(Level.FINE)) {
/*  57 */       logger.fine(toString() + " created by (" + toString() + ")");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isWrapperFor(Class<?> iface) throws SQLException {
/*  65 */     boolean f = iface.isInstance(this);
/*  66 */     return f;
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T unwrap(Class<T> iface) throws SQLException {
/*     */     T t;
/*     */     try {
/*  73 */       t = iface.cast(this);
/*  74 */     } catch (ClassCastException e) {
/*  75 */       throw new SQLServerException(e.getMessage(), e);
/*     */     } 
/*  77 */     return t;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getCatalogName(int column) throws SQLServerException {
/*  82 */     return this.rs.getColumn(column).getTableName().getDatabaseName();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getColumnCount() throws SQLServerException {
/*  87 */     return this.rs.getColumnCount();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getColumnDisplaySize(int column) throws SQLServerException {
/*  92 */     CryptoMetadata cryptoMetadata = this.rs.getColumn(column).getCryptoMetadata();
/*  93 */     if (null != cryptoMetadata) {
/*  94 */       return cryptoMetadata.getBaseTypeInfo().getDisplaySize();
/*     */     }
/*     */     
/*  97 */     return this.rs.getColumn(column).getTypeInfo().getDisplaySize();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getColumnLabel(int column) throws SQLServerException {
/* 102 */     return this.rs.getColumn(column).getColumnName();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getColumnName(int column) throws SQLServerException {
/* 107 */     return this.rs.getColumn(column).getColumnName();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getColumnType(int column) throws SQLServerException {
/* 113 */     TypeInfo typeInfo = this.rs.getColumn(column).getTypeInfo();
/*     */     
/* 115 */     CryptoMetadata cryptoMetadata = this.rs.getColumn(column).getCryptoMetadata();
/* 116 */     if (null != cryptoMetadata) {
/* 117 */       typeInfo = cryptoMetadata.getBaseTypeInfo();
/*     */     }
/*     */     
/* 120 */     JDBCType jdbcType = typeInfo.getSSType().getJDBCType();
/* 121 */     SSType sqlType = typeInfo.getSSType();
/*     */ 
/*     */     
/* 124 */     if (SSType.SQL_VARIANT == sqlType) {
/* 125 */       jdbcType = JDBCType.SQL_VARIANT;
/*     */     }
/* 127 */     if (SSType.UDT == sqlType) {
/* 128 */       if (typeInfo.getSSTypeName().equalsIgnoreCase(SSType.GEOMETRY.name())) {
/* 129 */         jdbcType = JDBCType.GEOMETRY;
/*     */       }
/* 131 */       if (typeInfo.getSSTypeName().equalsIgnoreCase(SSType.GEOGRAPHY.name())) {
/* 132 */         jdbcType = JDBCType.GEOGRAPHY;
/*     */       }
/*     */     } 
/* 135 */     int r = jdbcType.asJavaSqlType();
/* 136 */     if (this.con.isKatmaiOrLater()) {
/* 137 */       switch (sqlType) {
/*     */         case VARCHARMAX:
/* 139 */           r = SSType.VARCHAR.getJDBCType().asJavaSqlType();
/*     */           break;
/*     */         case NVARCHARMAX:
/* 142 */           r = SSType.NVARCHAR.getJDBCType().asJavaSqlType();
/*     */           break;
/*     */         case VARBINARYMAX:
/* 145 */           r = SSType.VARBINARY.getJDBCType().asJavaSqlType();
/*     */           break;
/*     */         case DATETIME:
/*     */         case SMALLDATETIME:
/* 149 */           r = SSType.DATETIME2.getJDBCType().asJavaSqlType();
/*     */           break;
/*     */         case MONEY:
/*     */         case SMALLMONEY:
/* 153 */           r = SSType.DECIMAL.getJDBCType().asJavaSqlType();
/*     */           break;
/*     */         case GUID:
/* 156 */           r = SSType.CHAR.getJDBCType().asJavaSqlType();
/*     */           break;
/*     */       } 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 163 */     return r;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getColumnTypeName(int column) throws SQLServerException {
/* 168 */     CryptoMetadata cryptoMetadata = this.rs.getColumn(column).getCryptoMetadata();
/* 169 */     if (null != cryptoMetadata) {
/* 170 */       return cryptoMetadata.getBaseTypeInfo().getSSTypeName();
/*     */     }
/*     */     
/* 173 */     return this.rs.getColumn(column).getTypeInfo().getSSTypeName();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrecision(int column) throws SQLServerException {
/* 178 */     CryptoMetadata cryptoMetadata = this.rs.getColumn(column).getCryptoMetadata();
/* 179 */     if (null != cryptoMetadata) {
/* 180 */       return cryptoMetadata.getBaseTypeInfo().getPrecision();
/*     */     }
/*     */     
/* 183 */     return this.rs.getColumn(column).getTypeInfo().getPrecision();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getScale(int column) throws SQLServerException {
/* 188 */     CryptoMetadata cryptoMetadata = this.rs.getColumn(column).getCryptoMetadata();
/* 189 */     if (null != cryptoMetadata) {
/* 190 */       return cryptoMetadata.getBaseTypeInfo().getScale();
/*     */     }
/*     */     
/* 193 */     return this.rs.getColumn(column).getTypeInfo().getScale();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSchemaName(int column) throws SQLServerException {
/* 198 */     return this.rs.getColumn(column).getTableName().getSchemaName();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getTableName(int column) throws SQLServerException {
/* 203 */     return this.rs.getColumn(column).getTableName().getObjectName();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAutoIncrement(int column) throws SQLServerException {
/* 208 */     CryptoMetadata cryptoMetadata = this.rs.getColumn(column).getCryptoMetadata();
/* 209 */     if (null != cryptoMetadata) {
/* 210 */       return cryptoMetadata.getBaseTypeInfo().isIdentity();
/*     */     }
/*     */     
/* 213 */     return this.rs.getColumn(column).getTypeInfo().isIdentity();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCaseSensitive(int column) throws SQLServerException {
/* 218 */     CryptoMetadata cryptoMetadata = this.rs.getColumn(column).getCryptoMetadata();
/* 219 */     if (null != cryptoMetadata) {
/* 220 */       return cryptoMetadata.getBaseTypeInfo().isCaseSensitive();
/*     */     }
/*     */     
/* 223 */     return this.rs.getColumn(column).getTypeInfo().isCaseSensitive();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCurrency(int column) throws SQLServerException {
/* 228 */     SSType ssType = this.rs.getColumn(column).getTypeInfo().getSSType();
/*     */     
/* 230 */     CryptoMetadata cryptoMetadata = this.rs.getColumn(column).getCryptoMetadata();
/* 231 */     if (null != cryptoMetadata) {
/* 232 */       ssType = cryptoMetadata.getBaseTypeInfo().getSSType();
/*     */     }
/*     */     
/* 235 */     return (SSType.MONEY == ssType || SSType.SMALLMONEY == ssType);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDefinitelyWritable(int column) throws SQLServerException {
/* 240 */     CryptoMetadata cryptoMetadata = this.rs.getColumn(column).getCryptoMetadata();
/* 241 */     if (null != cryptoMetadata) {
/* 242 */       return (TypeInfo.UPDATABLE_READ_WRITE == cryptoMetadata.getBaseTypeInfo().getUpdatability());
/*     */     }
/*     */     
/* 245 */     return (TypeInfo.UPDATABLE_READ_WRITE == this.rs.getColumn(column).getTypeInfo().getUpdatability());
/*     */   }
/*     */ 
/*     */   
/*     */   public int isNullable(int column) throws SQLServerException {
/* 250 */     CryptoMetadata cryptoMetadata = this.rs.getColumn(column).getCryptoMetadata();
/* 251 */     if (null != cryptoMetadata) {
/* 252 */       return cryptoMetadata.getBaseTypeInfo().isNullable() ? 1 : 0;
/*     */     }
/*     */     
/* 255 */     return this.rs.getColumn(column).getTypeInfo().isNullable() ? 1 : 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isReadOnly(int column) throws SQLServerException {
/* 260 */     CryptoMetadata cryptoMetadata = this.rs.getColumn(column).getCryptoMetadata();
/* 261 */     if (null != cryptoMetadata) {
/* 262 */       return (TypeInfo.UPDATABLE_READ_ONLY == cryptoMetadata.getBaseTypeInfo().getUpdatability());
/*     */     }
/*     */     
/* 265 */     return (TypeInfo.UPDATABLE_READ_ONLY == this.rs.getColumn(column).getTypeInfo().getUpdatability());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSearchable(int column) throws SQLServerException {
/* 270 */     SSType ssType = null;
/* 271 */     CryptoMetadata cryptoMetadata = this.rs.getColumn(column).getCryptoMetadata();
/*     */     
/* 273 */     if (null != cryptoMetadata) {
/* 274 */       ssType = cryptoMetadata.getBaseTypeInfo().getSSType();
/*     */     } else {
/* 276 */       ssType = this.rs.getColumn(column).getTypeInfo().getSSType();
/*     */     } 
/*     */     
/* 279 */     switch (ssType) {
/*     */       case IMAGE:
/*     */       case TEXT:
/*     */       case NTEXT:
/*     */       case UDT:
/*     */       case XML:
/* 285 */         return false;
/*     */     } 
/*     */     
/* 288 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSigned(int column) throws SQLServerException {
/* 294 */     CryptoMetadata cryptoMetadata = this.rs.getColumn(column).getCryptoMetadata();
/* 295 */     if (null != cryptoMetadata) {
/* 296 */       return cryptoMetadata.getBaseTypeInfo().getSSType().getJDBCType().isSigned();
/*     */     }
/*     */     
/* 299 */     return this.rs.getColumn(column).getTypeInfo().getSSType().getJDBCType().isSigned();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSparseColumnSet(int column) throws SQLServerException {
/* 304 */     CryptoMetadata cryptoMetadata = this.rs.getColumn(column).getCryptoMetadata();
/* 305 */     if (null != cryptoMetadata) {
/* 306 */       return cryptoMetadata.getBaseTypeInfo().isSparseColumnSet();
/*     */     }
/*     */     
/* 309 */     return this.rs.getColumn(column).getTypeInfo().isSparseColumnSet();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isWritable(int column) throws SQLServerException {
/* 314 */     int updatability = -1;
/* 315 */     CryptoMetadata cryptoMetadata = this.rs.getColumn(column).getCryptoMetadata();
/* 316 */     if (null != cryptoMetadata) {
/* 317 */       updatability = cryptoMetadata.getBaseTypeInfo().getUpdatability();
/*     */     } else {
/* 319 */       updatability = this.rs.getColumn(column).getTypeInfo().getUpdatability();
/*     */     } 
/* 321 */     return (TypeInfo.UPDATABLE_READ_WRITE == updatability || TypeInfo.UPDATABLE_UNKNOWN == updatability);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getColumnClassName(int column) throws SQLServerException {
/* 326 */     CryptoMetadata cryptoMetadata = this.rs.getColumn(column).getCryptoMetadata();
/* 327 */     if (null != cryptoMetadata) {
/* 328 */       return cryptoMetadata.getBaseTypeInfo().getSSType().getJDBCType().className();
/*     */     }
/*     */     
/* 331 */     return this.rs.getColumn(column).getTypeInfo().getSSType().getJDBCType().className();
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerResultSetMetaData.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */