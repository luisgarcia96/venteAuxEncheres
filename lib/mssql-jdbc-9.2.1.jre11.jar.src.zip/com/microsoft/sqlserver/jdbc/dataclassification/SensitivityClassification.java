/*     */ package com.microsoft.sqlserver.jdbc.dataclassification;
/*     */ 
/*     */ import com.microsoft.sqlserver.jdbc.SQLServerException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SensitivityClassification
/*     */ {
/*     */   private List<Label> labels;
/*     */   private List<InformationType> informationTypes;
/*     */   private List<ColumnSensitivity> columnSensitivities;
/*     */   private int sensitivityRank;
/*     */   
/*     */   public enum SensitivityRank
/*     */   {
/*  21 */     NOT_DEFINED(-1),
/*  22 */     NONE(0),
/*  23 */     LOW(10),
/*  24 */     MEDIUM(20),
/*  25 */     HIGH(30),
/*  26 */     CRITICAL(40);
/*     */     
/*  28 */     private static final SensitivityRank[] VALUES = values();
/*     */     private int rank;
/*     */     
/*     */     SensitivityRank(int rank) {
/*  32 */       this.rank = rank;
/*     */     } static {
/*     */     
/*     */     } public int getValue() {
/*  36 */       return this.rank;
/*     */     }
/*     */     
/*     */     public static boolean isValid(int rank) throws SQLServerException {
/*  40 */       for (SensitivityRank r : VALUES) {
/*  41 */         if (r.getValue() == rank) {
/*  42 */           return true;
/*     */         }
/*     */       } 
/*  45 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SensitivityClassification(List<Label> labels, List<InformationType> informationTypes, List<ColumnSensitivity> columnSensitivity) {
/*  71 */     this.labels = new ArrayList<>(labels);
/*  72 */     this.informationTypes = new ArrayList<>(informationTypes);
/*  73 */     this.columnSensitivities = new ArrayList<>(columnSensitivity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SensitivityClassification(List<Label> labels, List<InformationType> informationTypes, List<ColumnSensitivity> columnSensitivity, int sensitivityRank) {
/*  90 */     this.labels = new ArrayList<>(labels);
/*  91 */     this.informationTypes = new ArrayList<>(informationTypes);
/*  92 */     this.columnSensitivities = new ArrayList<>(columnSensitivity);
/*  93 */     this.sensitivityRank = sensitivityRank;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Label> getLabels() {
/* 102 */     return this.labels;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<InformationType> getInformationTypes() {
/* 111 */     return this.informationTypes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ColumnSensitivity> getColumnSensitivities() {
/* 120 */     return this.columnSensitivities;
/*     */   }
/*     */   
/*     */   public int getSensitivityRank() {
/* 124 */     return this.sensitivityRank;
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\dataclassification\SensitivityClassification.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */