/*    */ package com.microsoft.sqlserver.jdbc.dataclassification;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SensitivityProperty
/*    */ {
/*    */   private Label label;
/*    */   private InformationType informationType;
/*    */   private int sensitivityRank;
/*    */   
/*    */   public SensitivityProperty(Label label, InformationType informationType) {
/* 25 */     this.label = label;
/* 26 */     this.informationType = informationType;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SensitivityProperty(Label label, InformationType informationType, int sensitivityRank) {
/* 40 */     this.label = label;
/* 41 */     this.informationType = informationType;
/* 42 */     this.sensitivityRank = sensitivityRank;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Label getLabel() {
/* 51 */     return this.label;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public InformationType getInformationType() {
/* 60 */     return this.informationType;
/*    */   }
/*    */   
/*    */   public int getSensitivityRank() {
/* 64 */     return this.sensitivityRank;
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\dataclassification\SensitivityProperty.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */