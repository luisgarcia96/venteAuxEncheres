/*    */ package com.microsoft.sqlserver.jdbc.dataclassification;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ColumnSensitivity
/*    */ {
/*    */   private List<SensitivityProperty> sensitivityProperties;
/*    */   
/*    */   public ColumnSensitivity(List<SensitivityProperty> sensitivityProperties) {
/* 25 */     this.sensitivityProperties = new ArrayList<>(sensitivityProperties);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List<SensitivityProperty> getSensitivityProperties() {
/* 35 */     return this.sensitivityProperties;
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\dataclassification\ColumnSensitivity.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */