/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.security.SecureRandom;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class AASAttestationParameters
/*     */   extends BaseAttestationRequest
/*     */ {
/* 163 */   private static final byte[] ENCLAVE_TYPE = new byte[] { 1, 0, 0, 0 };
/*     */   
/* 165 */   private static byte[] NONCE_LENGTH = new byte[] { 0, 1, 0, 0 };
/* 166 */   private byte[] nonce = new byte[256];
/*     */   
/*     */   AASAttestationParameters(String attestationUrl) throws SQLServerException, IOException {
/* 169 */     byte[] attestationUrlBytes = (attestationUrl + "\000").getBytes(StandardCharsets.UTF_16LE);
/*     */     
/* 171 */     ByteArrayOutputStream os = new ByteArrayOutputStream();
/* 172 */     os.write(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(attestationUrlBytes.length).array());
/* 173 */     os.write(attestationUrlBytes);
/* 174 */     os.write(NONCE_LENGTH);
/* 175 */     (new SecureRandom()).nextBytes(this.nonce);
/* 176 */     os.write(this.nonce);
/* 177 */     this.enclaveChallenge = os.toByteArray();
/*     */     
/* 179 */     initBcryptECDH();
/*     */   }
/*     */ 
/*     */   
/*     */   byte[] getBytes() throws IOException {
/* 184 */     ByteArrayOutputStream os = new ByteArrayOutputStream();
/* 185 */     os.write(ENCLAVE_TYPE);
/* 186 */     os.write(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(this.enclaveChallenge.length).array());
/* 187 */     os.write(this.enclaveChallenge);
/* 188 */     os.write(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(104).array());
/* 189 */     os.write(ECDH_MAGIC);
/* 190 */     os.write(this.x);
/* 191 */     os.write(this.y);
/* 192 */     return os.toByteArray();
/*     */   }
/*     */   
/*     */   byte[] getNonce() {
/* 196 */     return this.nonce;
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\AASAttestationParameters.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */