/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.security.GeneralSecurityException;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SQLServerAASEnclaveProvider
/*     */   implements ISQLServerEnclaveProvider
/*     */ {
/*  45 */   private static EnclaveSessionCache enclaveCache = new EnclaveSessionCache();
/*     */   
/*  47 */   private AASAttestationParameters aasParams = null;
/*  48 */   private AASAttestationResponse hgsResponse = null;
/*  49 */   private String attestationUrl = null;
/*  50 */   private EnclaveSession enclaveSession = null;
/*     */ 
/*     */   
/*     */   public void getAttestationParameters(String url) throws SQLServerException {
/*  54 */     if (null == this.aasParams) {
/*  55 */       this.attestationUrl = url;
/*     */       try {
/*  57 */         this.aasParams = new AASAttestationParameters(this.attestationUrl);
/*  58 */       } catch (IOException e) {
/*  59 */         SQLServerException.makeFromDriverError(null, this, e.getLocalizedMessage(), "0", false);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayList<byte[]> createEnclaveSession(SQLServerConnection connection, String userSql, String preparedTypeDefinitions, Parameter[] params, ArrayList<String> parameterNames) throws SQLServerException {
/*  70 */     StringBuilder keyLookup = (new StringBuilder(connection.getServerName())).append(connection.getCatalog()).append(this.attestationUrl);
/*  71 */     EnclaveCacheEntry entry = enclaveCache.getSession(keyLookup.toString());
/*  72 */     if (null != entry) {
/*  73 */       this.enclaveSession = entry.getEnclaveSession();
/*  74 */       this.aasParams = (AASAttestationParameters)entry.getBaseAttestationRequest();
/*     */     } 
/*  76 */     ArrayList<byte[]> b = describeParameterEncryption(connection, userSql, preparedTypeDefinitions, params, parameterNames);
/*     */     
/*  78 */     if (connection.enclaveEstablished())
/*  79 */       return b; 
/*  80 */     if (null != this.hgsResponse && !connection.enclaveEstablished()) {
/*     */       try {
/*  82 */         this
/*  83 */           .enclaveSession = new EnclaveSession(this.hgsResponse.getSessionID(), this.aasParams.createSessionSecret(this.hgsResponse.getDHpublicKey()));
/*  84 */         enclaveCache.addEntry(connection.getServerName(), connection.getCatalog(), connection.enclaveAttestationUrl, this.aasParams, this.enclaveSession);
/*     */       }
/*  86 */       catch (GeneralSecurityException e) {
/*  87 */         SQLServerException.makeFromDriverError(connection, this, e.getLocalizedMessage(), "0", false);
/*     */       } 
/*     */     }
/*  90 */     return b;
/*     */   }
/*     */ 
/*     */   
/*     */   public void invalidateEnclaveSession() {
/*  95 */     if (null != this.enclaveSession) {
/*  96 */       enclaveCache.removeEntry(this.enclaveSession);
/*     */     }
/*  98 */     this.enclaveSession = null;
/*  99 */     this.aasParams = null;
/* 100 */     this.attestationUrl = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public EnclaveSession getEnclaveSession() {
/* 105 */     return this.enclaveSession;
/*     */   }
/*     */   
/*     */   private void validateAttestationResponse() throws SQLServerException {
/* 109 */     if (null != this.hgsResponse) {
/*     */       try {
/* 111 */         this.hgsResponse.validateToken(this.attestationUrl, this.aasParams.getNonce());
/* 112 */         this.hgsResponse.validateDHPublicKey(this.aasParams.getNonce());
/* 113 */       } catch (GeneralSecurityException e) {
/* 114 */         SQLServerException.makeFromDriverError(null, this, e.getLocalizedMessage(), "0", false);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ArrayList<byte[]> describeParameterEncryption(SQLServerConnection connection, String userSql, String preparedTypeDefinitions, Parameter[] params, ArrayList<String> parameterNames) throws SQLServerException {
/* 122 */     ArrayList<byte[]> enclaveRequestedCEKs = (ArrayList)new ArrayList<>(); 
/* 123 */     try { PreparedStatement stmt = connection.prepareStatement(connection.enclaveEstablished() ? "EXEC sp_describe_parameter_encryption ?,?" : "EXEC sp_describe_parameter_encryption ?,?,?");
/*     */       
/* 125 */       try { ResultSet rs = connection.enclaveEstablished() ? executeSDPEv1(stmt, userSql, preparedTypeDefinitions) : executeSDPEv2(stmt, userSql, preparedTypeDefinitions, this.aasParams); 
/* 126 */         try { if (null == rs)
/*     */           
/*     */           { 
/* 129 */             ArrayList<byte[]> arrayList = enclaveRequestedCEKs;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 146 */             if (rs != null) rs.close(); 
/* 147 */             if (stmt != null) stmt.close();  return arrayList; }  processSDPEv1(userSql, preparedTypeDefinitions, params, parameterNames, connection, stmt, rs, enclaveRequestedCEKs); if (connection.isAEv2() && stmt.getMoreResults()) { ResultSet hgsRs = stmt.getResultSet(); try { if (hgsRs.next()) { this.hgsResponse = new AASAttestationResponse(hgsRs.getBytes(1)); validateAttestationResponse(); } else { SQLServerException.makeFromDriverError(null, this, SQLServerException.getErrString("R_UnableRetrieveParameterMetadata"), "0", false); }  if (hgsRs != null) hgsRs.close();  } catch (Throwable throwable) { if (hgsRs != null) try { hgsRs.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  }  if (rs != null) rs.close();  } catch (Throwable throwable) { if (rs != null) try { rs.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  if (stmt != null) stmt.close();  } catch (Throwable throwable) { if (stmt != null) try { stmt.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException|IOException e)
/* 148 */     { if (e instanceof SQLServerException) {
/* 149 */         throw (SQLServerException)e;
/*     */       }
/* 151 */       throw new SQLServerException(SQLServerException.getErrString("R_UnableRetrieveParameterMetadata"), null, 0, e); }
/*     */ 
/*     */ 
/*     */     
/* 155 */     return enclaveRequestedCEKs;
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerAASEnclaveProvider.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */