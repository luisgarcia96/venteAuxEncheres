/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.text.MessageFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SQLServerMetaData
/*     */ {
/*  19 */   String columnName = null;
/*     */   int javaSqlType;
/*  21 */   int precision = 0;
/*  22 */   int scale = 0;
/*     */   boolean useServerDefault = false;
/*     */   boolean isUniqueKey = false;
/*  25 */   SQLServerSortOrder sortOrder = SQLServerSortOrder.Unspecified;
/*     */ 
/*     */ 
/*     */   
/*     */   int sortOrdinal;
/*     */ 
/*     */   
/*     */   private SQLCollation collation;
/*     */ 
/*     */   
/*     */   static final int defaultSortOrdinal = -1;
/*     */ 
/*     */ 
/*     */   
/*     */   public SQLServerMetaData(String columnName, int sqlType) {
/*  40 */     this.columnName = columnName;
/*  41 */     this.javaSqlType = sqlType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SQLServerMetaData(String columnName, int sqlType, int precision, int scale) {
/*  57 */     this.columnName = columnName;
/*  58 */     this.javaSqlType = sqlType;
/*  59 */     this.precision = precision;
/*  60 */     this.scale = scale;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SQLServerMetaData(String columnName, int sqlType, int length) {
/*  75 */     this.columnName = columnName;
/*  76 */     this.javaSqlType = sqlType;
/*  77 */     this.precision = length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SQLServerMetaData(String columnName, int sqlType, int precision, int scale, boolean useServerDefault, boolean isUniqueKey, SQLServerSortOrder sortOrder, int sortOrdinal) throws SQLServerException {
/* 104 */     this.columnName = columnName;
/* 105 */     this.javaSqlType = sqlType;
/* 106 */     this.precision = precision;
/* 107 */     this.scale = scale;
/* 108 */     this.useServerDefault = useServerDefault;
/* 109 */     this.isUniqueKey = isUniqueKey;
/* 110 */     this.sortOrder = sortOrder;
/* 111 */     this.sortOrdinal = sortOrdinal;
/* 112 */     validateSortOrder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SQLServerMetaData(SQLServerMetaData sqlServerMetaData) {
/* 122 */     this.columnName = sqlServerMetaData.columnName;
/* 123 */     this.javaSqlType = sqlServerMetaData.javaSqlType;
/* 124 */     this.precision = sqlServerMetaData.precision;
/* 125 */     this.scale = sqlServerMetaData.scale;
/* 126 */     this.useServerDefault = sqlServerMetaData.useServerDefault;
/* 127 */     this.isUniqueKey = sqlServerMetaData.isUniqueKey;
/* 128 */     this.sortOrder = sqlServerMetaData.sortOrder;
/* 129 */     this.sortOrdinal = sqlServerMetaData.sortOrdinal;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getColumName() {
/* 138 */     return this.columnName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSqlType() {
/* 147 */     return this.javaSqlType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPrecision() {
/* 156 */     return this.precision;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getScale() {
/* 165 */     return this.scale;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean useServerDefault() {
/* 174 */     return this.useServerDefault;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isUniqueKey() {
/* 183 */     return this.isUniqueKey;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SQLServerSortOrder getSortOrder() {
/* 192 */     return this.sortOrder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSortOrdinal() {
/* 201 */     return this.sortOrdinal;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SQLCollation getCollation() {
/* 210 */     return this.collation;
/*     */   }
/*     */ 
/*     */   
/*     */   void validateSortOrder() throws SQLServerException {
/* 215 */     if (((SQLServerSortOrder.Unspecified == this.sortOrder) ? true : false) != ((-1 == this.sortOrdinal) ? true : false)) {
/* 216 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_TVPMissingSortOrderOrOrdinal"));
/* 217 */       throw new SQLServerException(form.format(new Object[] { this.sortOrder, Integer.valueOf(this.sortOrdinal) }, ), null, 0, null);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerMetaData.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */