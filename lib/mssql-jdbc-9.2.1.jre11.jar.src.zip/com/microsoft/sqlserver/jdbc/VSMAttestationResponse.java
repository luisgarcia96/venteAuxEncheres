/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import java.security.GeneralSecurityException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.Signature;
/*     */ import java.security.SignatureException;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.CertificateFactory;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.security.spec.MGF1ParameterSpec;
/*     */ import java.security.spec.PSSParameterSpec;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Collection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class VSMAttestationResponse
/*     */   extends BaseAttestationResponse
/*     */ {
/*     */   private byte[] healthReportCertificate;
/*     */   private byte[] enclaveReportPackage;
/*     */   private X509Certificate healthCert;
/*     */   
/*     */   VSMAttestationResponse(byte[] b) throws SQLServerException {
/* 232 */     ByteBuffer response = (null != b) ? ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN) : null;
/* 233 */     if (null != response) {
/* 234 */       this.totalSize = response.getInt();
/* 235 */       this.identitySize = response.getInt();
/* 236 */       int healthReportSize = response.getInt();
/* 237 */       int enclaveReportSize = response.getInt();
/*     */       
/* 239 */       this.enclavePK = new byte[this.identitySize];
/* 240 */       this.healthReportCertificate = new byte[healthReportSize];
/* 241 */       this.enclaveReportPackage = new byte[enclaveReportSize];
/*     */       
/* 243 */       response.get(this.enclavePK, 0, this.identitySize);
/* 244 */       response.get(this.healthReportCertificate, 0, healthReportSize);
/* 245 */       response.get(this.enclaveReportPackage, 0, enclaveReportSize);
/*     */       
/* 247 */       this.sessionInfoSize = response.getInt();
/* 248 */       response.get(this.sessionID, 0, 8);
/* 249 */       this.DHPKsize = response.getInt();
/* 250 */       this.DHPKSsize = response.getInt();
/*     */       
/* 252 */       this.DHpublicKey = new byte[this.DHPKsize];
/* 253 */       this.publicKeySig = new byte[this.DHPKSsize];
/*     */       
/* 255 */       response.get(this.DHpublicKey, 0, this.DHPKsize);
/* 256 */       response.get(this.publicKeySig, 0, this.DHPKSsize);
/*     */     } 
/*     */     
/* 259 */     if (null == response || 0 != response.remaining()) {
/* 260 */       SQLServerException.makeFromDriverError(null, this, 
/* 261 */           SQLServerResource.getResource("R_EnclaveResponseLengthError"), "0", false);
/*     */     }
/*     */     
/*     */     try {
/* 265 */       CertificateFactory cf = CertificateFactory.getInstance("X.509");
/* 266 */       this.healthCert = (X509Certificate)cf.generateCertificate(new ByteArrayInputStream(this.healthReportCertificate));
/* 267 */     } catch (CertificateException ce) {
/* 268 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_HealthCertError"));
/* 269 */       Object[] msgArgs = { ce.getLocalizedMessage() };
/* 270 */       SQLServerException.makeFromDriverError(null, null, form.format(msgArgs), null, true);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   void validateCert(byte[] b) throws SQLServerException {
/* 276 */     if (null != b) {
/*     */       try {
/* 278 */         CertificateFactory cf = CertificateFactory.getInstance("X.509");
/*     */         
/* 280 */         Collection<X509Certificate> certs = (Collection)cf.generateCertificates(new ByteArrayInputStream(b));
/* 281 */         for (X509Certificate cert : certs) {
/*     */           try {
/* 283 */             cert.checkValidity();
/* 284 */             this.healthCert.verify(cert.getPublicKey());
/*     */             return;
/* 286 */           } catch (SignatureException|java.security.cert.CertificateExpiredException signatureException) {}
/*     */         }
/*     */       
/*     */       }
/* 290 */       catch (GeneralSecurityException e) {
/* 291 */         SQLServerException.makeFromDriverError(null, this, e.getLocalizedMessage(), "0", false);
/*     */       } 
/*     */     }
/* 294 */     SQLServerException.makeFromDriverError(null, this, SQLServerResource.getResource("R_InvalidHealthCert"), "0", false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void validateStatementSignature() throws SQLServerException, GeneralSecurityException {
/* 316 */     ByteBuffer enclaveReportPackageBuffer = ByteBuffer.wrap(this.enclaveReportPackage).order(ByteOrder.LITTLE_ENDIAN);
/* 317 */     int packageSize = enclaveReportPackageBuffer.getInt();
/* 318 */     int version = enclaveReportPackageBuffer.getInt();
/* 319 */     int signatureScheme = enclaveReportPackageBuffer.getInt();
/* 320 */     int signedStatementSize = enclaveReportPackageBuffer.getInt();
/* 321 */     int signatureSize = enclaveReportPackageBuffer.getInt();
/* 322 */     int reserved = enclaveReportPackageBuffer.getInt();
/*     */     
/* 324 */     byte[] signedStatement = new byte[signedStatementSize];
/* 325 */     enclaveReportPackageBuffer.get(signedStatement, 0, signedStatementSize);
/* 326 */     byte[] signatureBlob = new byte[signatureSize];
/* 327 */     enclaveReportPackageBuffer.get(signatureBlob, 0, signatureSize);
/*     */     
/* 329 */     if (enclaveReportPackageBuffer.remaining() != 0) {
/* 330 */       SQLServerException.makeFromDriverError(null, this, 
/* 331 */           SQLServerResource.getResource("R_EnclavePackageLengthError"), "0", false);
/*     */     }
/*     */     
/* 334 */     Signature sig = null;
/*     */     try {
/* 336 */       sig = Signature.getInstance("RSASSA-PSS");
/* 337 */     } catch (NoSuchAlgorithmException e) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 342 */       SQLServerBouncyCastleLoader.loadBouncyCastle();
/* 343 */       sig = Signature.getInstance("RSASSA-PSS");
/*     */     } 
/* 345 */     PSSParameterSpec pss = new PSSParameterSpec("SHA-256", "MGF1", MGF1ParameterSpec.SHA256, 32, 1);
/* 346 */     sig.setParameter(pss);
/* 347 */     sig.initVerify(this.healthCert);
/* 348 */     sig.update(signedStatement);
/* 349 */     if (!sig.verify(signatureBlob))
/* 350 */       SQLServerException.makeFromDriverError(null, this, 
/* 351 */           SQLServerResource.getResource("R_InvalidSignedStatement"), "0", false); 
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\VSMAttestationResponse.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */