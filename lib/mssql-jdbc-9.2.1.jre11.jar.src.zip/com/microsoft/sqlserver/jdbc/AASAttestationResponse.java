/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import com.google.gson.JsonArray;
/*     */ import com.google.gson.JsonElement;
/*     */ import com.google.gson.JsonObject;
/*     */ import com.google.gson.JsonParser;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import java.security.GeneralSecurityException;
/*     */ import java.security.Signature;
/*     */ import java.security.cert.CertificateFactory;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.Arrays;
/*     */ import java.util.Base64;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class AASAttestationResponse
/*     */   extends BaseAttestationResponse
/*     */ {
/*     */   private byte[] attestationToken;
/* 226 */   private static Hashtable<String, JWTCertificateEntry> certificateCache = new Hashtable<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AASAttestationResponse(byte[] b) throws SQLServerException {
/* 244 */     ByteBuffer response = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN);
/* 245 */     this.totalSize = response.getInt();
/* 246 */     this.identitySize = response.getInt();
/* 247 */     this.attestationTokenSize = response.getInt();
/* 248 */     this.enclaveType = response.getInt();
/*     */     
/* 250 */     this.enclavePK = new byte[this.identitySize];
/* 251 */     this.attestationToken = new byte[this.attestationTokenSize];
/*     */     
/* 253 */     response.get(this.enclavePK, 0, this.identitySize);
/* 254 */     response.get(this.attestationToken, 0, this.attestationTokenSize);
/*     */     
/* 256 */     this.sessionInfoSize = response.getInt();
/* 257 */     response.get(this.sessionID, 0, 8);
/* 258 */     this.DHPKsize = response.getInt();
/* 259 */     this.DHPKSsize = response.getInt();
/*     */     
/* 261 */     this.DHpublicKey = new byte[this.DHPKsize];
/* 262 */     this.publicKeySig = new byte[this.DHPKSsize];
/*     */     
/* 264 */     response.get(this.DHpublicKey, 0, this.DHPKsize);
/* 265 */     response.get(this.publicKeySig, 0, this.DHPKSsize);
/*     */     
/* 267 */     if (0 != response.remaining()) {
/* 268 */       SQLServerException.makeFromDriverError(null, this, 
/* 269 */           SQLServerResource.getResource("R_EnclaveResponseLengthError"), "0", false);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void validateToken(String attestationUrl, byte[] nonce) throws SQLServerException {
/*     */     try {
/* 278 */       String jwtToken = (new String(this.attestationToken)).trim();
/* 279 */       if (jwtToken.startsWith("\"") && jwtToken.endsWith("\"")) {
/* 280 */         jwtToken = jwtToken.substring(1, jwtToken.length() - 1);
/*     */       }
/* 282 */       String[] splitString = jwtToken.split("\\.");
/* 283 */       Base64.Decoder decoder = Base64.getUrlDecoder();
/* 284 */       String header = new String(decoder.decode(splitString[0]));
/* 285 */       String body = new String(decoder.decode(splitString[1]));
/* 286 */       byte[] stmtSig = decoder.decode(splitString[2]);
/*     */       
/* 288 */       JsonArray keys = null;
/* 289 */       JWTCertificateEntry cacheEntry = certificateCache.get(attestationUrl);
/* 290 */       if (null != cacheEntry && !cacheEntry.expired()) {
/* 291 */         keys = cacheEntry.getCertificates();
/* 292 */       } else if (null != cacheEntry && cacheEntry.expired()) {
/* 293 */         certificateCache.remove(attestationUrl);
/*     */       } 
/*     */       
/* 296 */       if (null == keys) {
/*     */         
/* 298 */         String authorityUrl = (new URL(attestationUrl)).getAuthority();
/* 299 */         URL wellKnownUrl = new URL("https://" + authorityUrl + "/.well-known/openid-configuration");
/* 300 */         URLConnection con = wellKnownUrl.openConnection();
/* 301 */         String wellKnownUrlJson = new String(Util.convertInputStreamToString(con.getInputStream()));
/* 302 */         JsonObject attestationJson = JsonParser.parseString(wellKnownUrlJson).getAsJsonObject();
/*     */         
/* 304 */         URL jwksUrl = new URL(attestationJson.get("jwks_uri").getAsString());
/* 305 */         URLConnection jwksCon = jwksUrl.openConnection();
/* 306 */         String jwksUrlJson = new String(Util.convertInputStreamToString(jwksCon.getInputStream()));
/* 307 */         JsonObject jwksJson = JsonParser.parseString(jwksUrlJson).getAsJsonObject();
/* 308 */         keys = jwksJson.get("keys").getAsJsonArray();
/* 309 */         certificateCache.put(attestationUrl, new JWTCertificateEntry(keys));
/*     */       } 
/*     */ 
/*     */       
/* 313 */       JsonObject headerJsonObject = JsonParser.parseString(header).getAsJsonObject();
/* 314 */       String keyID = headerJsonObject.get("kid").getAsString();
/*     */       
/* 316 */       for (JsonElement key : keys) {
/* 317 */         JsonObject keyObj = key.getAsJsonObject();
/* 318 */         String kId = keyObj.get("kid").getAsString();
/* 319 */         if (kId.equals(keyID)) {
/* 320 */           JsonArray certsFromServer = keyObj.get("x5c").getAsJsonArray();
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 325 */           byte[] signatureBytes = (splitString[0] + "." + splitString[0]).getBytes();
/* 326 */           for (JsonElement jsonCert : certsFromServer) {
/* 327 */             CertificateFactory cf = CertificateFactory.getInstance("X.509");
/* 328 */             X509Certificate cert = (X509Certificate)cf.generateCertificate(new ByteArrayInputStream(
/* 329 */                   Base64.getDecoder().decode(jsonCert.getAsString())));
/* 330 */             Signature sig = Signature.getInstance("SHA256withRSA");
/* 331 */             sig.initVerify(cert.getPublicKey());
/* 332 */             sig.update(signatureBytes);
/* 333 */             if (sig.verify(stmtSig)) {
/*     */               
/* 335 */               JsonObject bodyJsonObject = JsonParser.parseString(body).getAsJsonObject();
/* 336 */               String aasEhd = bodyJsonObject.get("aas-ehd").getAsString();
/* 337 */               if (!Arrays.equals(Base64.getUrlDecoder().decode(aasEhd), this.enclavePK)) {
/* 338 */                 SQLServerException.makeFromDriverError(null, this, 
/* 339 */                     SQLServerResource.getResource("R_AasEhdError"), "0", false);
/*     */               }
/* 341 */               if (this.enclaveType == 1) {
/*     */                 
/* 343 */                 String rpData = bodyJsonObject.get("rp_data").getAsString();
/* 344 */                 if (!Arrays.equals(Base64.getUrlDecoder().decode(rpData), nonce)) {
/* 345 */                   SQLServerException.makeFromDriverError(null, this, 
/* 346 */                       SQLServerResource.getResource("R_VbsRpDataError"), "0", false);
/*     */                 }
/*     */               } 
/*     */               return;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 354 */       SQLServerException.makeFromDriverError(null, this, SQLServerResource.getResource("R_AasJWTError"), "0", false);
/*     */     }
/* 356 */     catch (IOException|GeneralSecurityException e) {
/* 357 */       SQLServerException.makeFromDriverError(null, this, e.getLocalizedMessage(), "", false);
/*     */     } 
/*     */   }
/*     */   
/*     */   void validateDHPublicKey(byte[] nonce) throws SQLServerException, GeneralSecurityException {
/* 362 */     if (this.enclaveType == 2) {
/* 363 */       for (int i = 0; i < this.enclavePK.length; i++) {
/* 364 */         this.enclavePK[i] = (byte)(this.enclavePK[i] ^ nonce[i % nonce.length]);
/*     */       }
/*     */     }
/* 367 */     validateDHPublicKey();
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\AASAttestationResponse.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */