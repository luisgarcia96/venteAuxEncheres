/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import java.text.MessageFormat;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ enum sqlVariantProbBytes
/*    */ {
/*    */   private final int intValue;
/*    */   private static final int MAXELEMENTS = 23;
/* 15 */   INTN(0),
/* 16 */   INT8(0),
/* 17 */   INT4(0),
/* 18 */   INT2(0),
/* 19 */   INT1(0),
/* 20 */   FLOAT4(0),
/* 21 */   FLOAT8(0),
/* 22 */   DATETIME4(0),
/* 23 */   DATETIME8(0),
/* 24 */   MONEY4(0),
/* 25 */   MONEY8(0),
/* 26 */   BITN(0),
/* 27 */   GUID(0),
/* 28 */   DATEN(0),
/* 29 */   TIMEN(1),
/* 30 */   DATETIME2N(1),
/* 31 */   DECIMALN(2),
/* 32 */   NUMERICN(2),
/* 33 */   BIGBINARY(2),
/* 34 */   BIGVARBINARY(2),
/* 35 */   BIGCHAR(7),
/* 36 */   BIGVARCHAR(7),
/* 37 */   NCHAR(7),
/* 38 */   NVARCHAR(7);
/*    */   
/*    */   private static final sqlVariantProbBytes[] valuesTypes;
/*    */   
/*    */   static {
/* 43 */     valuesTypes = new sqlVariantProbBytes[23];
/*    */   }
/*    */   sqlVariantProbBytes(int intValue) {
/* 46 */     this.intValue = intValue;
/*    */   }
/*    */   
/*    */   int getIntValue() {
/* 50 */     return this.intValue;
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\sqlVariantProbBytes.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */