/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.lang.management.ManagementFactory;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MaxResultBufferParser
/*     */ {
/*  19 */   private static final Logger logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.MaxResultBufferParser");
/*  20 */   private static final String[] PERCENT_PHRASES = new String[] { "percent", "pct", "p" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String ERROR_MESSAGE = "MaxResultBuffer property is badly formatted: {0}.";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long validateMaxResultBuffer(String input) throws SQLServerException {
/*  37 */     long number = -1L;
/*     */ 
/*     */     
/*  40 */     if (StringUtils.isEmpty(input) || input.equals("-1")) {
/*  41 */       return number;
/*     */     }
/*     */ 
/*     */     
/*  45 */     if (!StringUtils.isEmpty(input) && input.matches("-?\\d+(\\.\\d+)?")) {
/*     */       try {
/*  47 */         number = Long.parseLong(input);
/*  48 */       } catch (NumberFormatException e) {
/*  49 */         if (logger.isLoggable(Level.SEVERE)) {
/*  50 */           logger.log(Level.SEVERE, "MaxResultBuffer property is badly formatted: {0}.", new Object[] { input });
/*     */         }
/*  52 */         throwNewInvalidMaxResultBufferParameterException(e, new Object[] { input });
/*     */       } 
/*  54 */       return adjustMemory(number, 1L);
/*     */     } 
/*     */     
/*  57 */     for (String percentPhrase : PERCENT_PHRASES) {
/*  58 */       if (input.endsWith(percentPhrase)) {
/*  59 */         String str = input.substring(0, input.length() - percentPhrase.length());
/*     */         try {
/*  61 */           number = Long.parseLong(str);
/*  62 */         } catch (NumberFormatException e) {
/*  63 */           if (logger.isLoggable(Level.SEVERE)) {
/*  64 */             logger.log(Level.SEVERE, "MaxResultBuffer property is badly formatted: {0}.", new Object[] { input });
/*     */           }
/*  66 */           throwNewInvalidMaxResultBufferParameterException(e, new Object[] { str });
/*     */         } 
/*  68 */         return adjustMemoryPercentage(number);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*  73 */     long multiplier = getMultiplier(input);
/*  74 */     String numberString = input.substring(0, input.length() - 1);
/*     */     
/*     */     try {
/*  77 */       number = Long.parseLong(numberString);
/*  78 */     } catch (NumberFormatException e) {
/*  79 */       if (logger.isLoggable(Level.SEVERE)) {
/*  80 */         logger.log(Level.SEVERE, "MaxResultBuffer property is badly formatted: {0}.", new Object[] { input });
/*     */       }
/*  82 */       throwNewInvalidMaxResultBufferParameterException(e, new Object[] { numberString });
/*     */     } 
/*  84 */     return adjustMemory(number, multiplier);
/*     */   }
/*     */ 
/*     */   
/*     */   private static void checkForNegativeValue(long value) throws SQLServerException {
/*  89 */     if (value <= 0L) {
/*  90 */       Object[] objectToThrow = { Long.valueOf(value) };
/*     */       
/*  92 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_maxResultBufferNegativeParameterValue"));
/*  93 */       if (logger.isLoggable(Level.SEVERE)) {
/*  94 */         logger.log(Level.SEVERE, SQLServerException.getErrString("R_maxResultBufferNegativeParameterValue"), objectToThrow);
/*     */       }
/*     */       
/*  97 */       throw new SQLServerException(form.format(objectToThrow), new Throwable());
/*     */     } 
/*     */   }
/*     */   
/*     */   private static long getMultiplier(String input) throws SQLServerException {
/* 102 */     long multiplier = 1L;
/* 103 */     switch (Character.toUpperCase(input.charAt(input.length() - 1)))
/*     */     { case 'K':
/* 105 */         multiplier = 1000L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 122 */         return multiplier;case 'M': multiplier = 1000000L; return multiplier;case 'G': multiplier = 1000000000L; return multiplier;case 'T': multiplier = 1000000000000L; return multiplier; }  if (logger.isLoggable(Level.SEVERE)) logger.log(Level.SEVERE, "MaxResultBuffer property is badly formatted: {0}.", new Object[] { input });  throwNewInvalidMaxResultBufferParameterException(null, new Object[] { input }); return multiplier;
/*     */   }
/*     */   
/*     */   private static long adjustMemoryPercentage(long percentage) throws SQLServerException {
/* 126 */     checkForNegativeValue(percentage);
/* 127 */     if (percentage > 90L) {
/* 128 */       return (long)(0.9D * getMaxMemory());
/*     */     }
/* 130 */     return (long)(percentage / 100.0D * getMaxMemory());
/*     */   }
/*     */   
/*     */   private static long adjustMemory(long size, long multiplier) throws SQLServerException {
/* 134 */     checkForNegativeValue(size);
/* 135 */     if ((size * multiplier) > 0.9D * getMaxMemory()) {
/* 136 */       return (long)(0.9D * getMaxMemory());
/*     */     }
/* 138 */     return size * multiplier;
/*     */   }
/*     */   
/*     */   private static long getMaxMemory() {
/* 142 */     return ManagementFactory.getMemoryMXBean().getHeapMemoryUsage().getMax();
/*     */   }
/*     */ 
/*     */   
/*     */   private static void throwNewInvalidMaxResultBufferParameterException(Throwable cause, Object... arguments) throws SQLServerException {
/* 147 */     MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_maxResultBufferInvalidSyntax"));
/* 148 */     throw new SQLServerException(form.format(arguments), cause);
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\MaxResultBufferParser.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */