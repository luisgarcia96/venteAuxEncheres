/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import java.sql.DriverPropertyInfo;
/*    */ import java.util.Properties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class SQLServerDriverPropertyInfo
/*    */ {
/*    */   private final String name;
/*    */   private final String description;
/*    */   private final String defaultValue;
/*    */   private final boolean required;
/*    */   private final String[] choices;
/*    */   
/*    */   final String getName() {
/* 30 */     return this.name;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   SQLServerDriverPropertyInfo(String name, String defaultValue, boolean required, String[] choices) {
/* 39 */     this.name = name;
/* 40 */     this.description = SQLServerResource.getResource("R_" + name + "PropertyDescription");
/* 41 */     this.defaultValue = defaultValue;
/* 42 */     this.required = required;
/* 43 */     this.choices = choices;
/*    */   }
/*    */ 
/*    */   
/*    */   DriverPropertyInfo build(Properties connProperties) {
/* 48 */     String propValue = this.name.equals(SQLServerDriverStringProperty.PASSWORD.toString()) ? "" : connProperties.getProperty(this.name);
/*    */     
/* 50 */     if (null == propValue) {
/* 51 */       propValue = this.defaultValue;
/*    */     }
/* 53 */     DriverPropertyInfo info = new DriverPropertyInfo(this.name, propValue);
/* 54 */     info.description = this.description;
/* 55 */     info.required = this.required;
/* 56 */     info.choices = this.choices;
/*    */     
/* 58 */     return info;
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerDriverPropertyInfo.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */