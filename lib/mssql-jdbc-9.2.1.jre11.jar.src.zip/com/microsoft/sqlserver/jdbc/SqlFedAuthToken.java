/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Date;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SqlFedAuthToken
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = -1343105491285383937L;
/*    */   final Date expiresOn;
/*    */   final String accessToken;
/*    */   
/*    */   SqlFedAuthToken(String accessToken, long expiresIn) {
/* 22 */     this.accessToken = accessToken;
/*    */     
/* 24 */     Date now = new Date();
/* 25 */     now.setTime(now.getTime() + expiresIn * 1000L);
/* 26 */     this.expiresOn = now;
/*    */   }
/*    */   
/*    */   SqlFedAuthToken(String accessToken, Date expiresOn) {
/* 30 */     this.accessToken = accessToken;
/* 31 */     this.expiresOn = expiresOn;
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SqlFedAuthToken.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */