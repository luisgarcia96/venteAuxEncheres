/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import com.microsoft.sqlserver.jdbc.dataclassification.SensitivityClassification;
/*      */ import java.io.Closeable;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.Serializable;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Connection;
/*      */ import java.sql.Date;
/*      */ import java.sql.NClob;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.RowId;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLType;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.SQLXML;
/*      */ import java.sql.Statement;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.text.MessageFormat;
/*      */ import java.time.LocalDate;
/*      */ import java.time.LocalDateTime;
/*      */ import java.time.LocalTime;
/*      */ import java.time.OffsetDateTime;
/*      */ import java.time.OffsetTime;
/*      */ import java.util.Calendar;
/*      */ import java.util.HashMap;
/*      */ import java.util.Map;
/*      */ import java.util.UUID;
/*      */ import java.util.concurrent.atomic.AtomicInteger;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ import microsoft.sql.DateTimeOffset;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class SQLServerResultSet
/*      */   implements ISQLServerResultSet, Serializable
/*      */ {
/*      */   private static final long serialVersionUID = -1624082547992040463L;
/*   59 */   private static final AtomicInteger lastResultSetID = new AtomicInteger(0);
/*      */   private final String traceID;
/*      */   
/*      */   private static int nextResultSetID() {
/*   63 */     return lastResultSetID.incrementAndGet();
/*      */   }
/*      */ 
/*      */   
/*   67 */   static final Logger logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerResultSet");
/*      */ 
/*      */   
/*      */   public String toString() {
/*   71 */     return this.traceID;
/*      */   }
/*      */   
/*      */   String logCursorState() {
/*   75 */     return " currentRow:" + this.currentRow + " numFetchedRows:" + this.numFetchedRows + " rowCount:" + this.rowCount;
/*      */   }
/*      */ 
/*      */   
/*   79 */   protected static final Logger loggerExternal = Logger.getLogger("com.microsoft.sqlserver.jdbc.ResultSet"); private final String loggingClassName; private final SQLServerStatement stmt;
/*      */   private final int maxRows;
/*      */   private SQLServerResultSetMetaData metaData;
/*      */   
/*      */   String getClassNameLogging() {
/*   84 */     return this.loggingClassName;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isClosed = false;
/*      */ 
/*      */   
/*      */   private final int serverCursorId;
/*      */ 
/*      */   
/*      */   private int fetchDirection;
/*      */ 
/*      */   
/*      */   private int fetchSize;
/*      */ 
/*      */   
/*      */   protected int getServerCursorId() {
/*  102 */     return this.serverCursorId;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isOnInsertRow = false;
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean lastValueWasNull = false;
/*      */ 
/*      */ 
/*      */   
/*      */   private int lastColumnIndex;
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean areNullCompressedColumnsInitialized = false;
/*      */ 
/*      */ 
/*      */   
/*  125 */   private RowType resultSetCurrentRowType = RowType.UNKNOWN; private transient Closeable activeStream; private SQLServerLob activeLOB; private final ScrollWindow scrollWindow; private static final int BEFORE_FIRST_ROW = 0; private static final int AFTER_LAST_ROW = -1;
/*      */   private static final int UNKNOWN_ROW = -2;
/*      */   
/*      */   final RowType getCurrentRowType() {
/*  129 */     return this.resultSetCurrentRowType;
/*      */   }
/*      */ 
/*      */   
/*      */   final void setCurrentRowType(RowType rowType) {
/*  134 */     this.resultSetCurrentRowType = rowType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  155 */   private int currentRow = 0;
/*      */ 
/*      */   
/*      */   private boolean updatedCurrentRow = false;
/*      */ 
/*      */   
/*  161 */   private final Map<String, Integer> columnNames = new HashMap<>();
/*      */   
/*      */   final boolean getUpdatedCurrentRow() {
/*  164 */     return this.updatedCurrentRow;
/*      */   }
/*      */   
/*      */   final void setUpdatedCurrentRow(boolean rowUpdated) {
/*  168 */     this.updatedCurrentRow = rowUpdated;
/*      */   }
/*      */   private boolean deletedCurrentRow = false; static final int UNKNOWN_ROW_COUNT = -3;
/*      */   private int rowCount;
/*      */   private final Column[] columns;
/*      */   
/*      */   final boolean getDeletedCurrentRow() {
/*  175 */     return this.deletedCurrentRow;
/*      */   }
/*      */   
/*      */   final void setDeletedCurrentRow(boolean rowDeleted) {
/*  179 */     this.deletedCurrentRow = rowDeleted;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  195 */   private CekTable cekTable = null; private TDSReader tdsReader; private final FetchBuffer fetchBuffer; private SQLServerException rowErrorException;
/*      */   private int numFetchedRows;
/*      */   
/*      */   CekTable getCekTable() {
/*  199 */     return this.cekTable;
/*      */   }
/*      */   
/*      */   final void setColumnName(int index, String name) {
/*  203 */     this.columns[index - 1].setColumnName(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void skipColumns(int columnsToSkip, boolean discardValues) throws SQLServerException {
/*  211 */     assert this.lastColumnIndex >= 1;
/*  212 */     assert 0 <= columnsToSkip && columnsToSkip <= this.columns.length;
/*      */     
/*  214 */     for (int columnsSkipped = 0; columnsSkipped < columnsToSkip; columnsSkipped++) {
/*  215 */       Column column = getColumn(this.lastColumnIndex++);
/*  216 */       column.skipValue(this.tdsReader, (discardValues && isForwardOnly()));
/*  217 */       if (discardValues) {
/*  218 */         column.clear();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected TDSReader getTDSReader() {
/*  226 */     return this.tdsReader;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SensitivityClassification getSensitivityClassification() {
/*  233 */     return this.tdsReader.sensitivityClassification;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   SQLServerResultSet(SQLServerStatement stmtIn) throws SQLServerException {
/*      */     final class ServerCursorInitializer
/*      */       extends CursorInitializer
/*      */     {
/*      */       private final SQLServerStatement stmt;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       final int getRowCount() {
/*  297 */         return this.stmt.getServerCursorRowCount();
/*      */       }
/*      */       
/*      */       final int getServerCursorId() {
/*  301 */         return this.stmt.getServerCursorId();
/*      */       }
/*      */       
/*      */       ServerCursorInitializer(SQLServerStatement stmt) {
/*  305 */         super("ServerCursorInitializer");
/*  306 */         this.stmt = stmt;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       boolean onRetStatus(TDSReader tdsReader) throws SQLServerException {
/*  315 */         this.stmt.consumeExecOutParam(tdsReader);
/*  316 */         return true;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       boolean onRetValue(TDSReader tdsReader) throws SQLServerException {
/*  323 */         return false;
/*      */       }
/*      */     };
/*      */     
/*      */     final class ClientCursorInitializer
/*      */       extends CursorInitializer
/*      */     {
/*  330 */       private int rowCount = -3;
/*      */       
/*      */       final int getRowCount() {
/*  333 */         return this.rowCount;
/*      */       }
/*      */       
/*      */       final int getServerCursorId() {
/*  337 */         return 0;
/*      */       }
/*      */       
/*      */       ClientCursorInitializer() {
/*  341 */         super("ClientCursorInitializer");
/*      */       }
/*      */ 
/*      */       
/*      */       boolean onRow(TDSReader tdsReader) throws SQLServerException {
/*  346 */         return false;
/*      */       }
/*      */ 
/*      */       
/*      */       boolean onNBCRow(TDSReader tdsReader) throws SQLServerException {
/*  351 */         return false;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       boolean onError(TDSReader tdsReader) throws SQLServerException {
/*  358 */         this.rowCount = 0;
/*  359 */         return false;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       boolean onDone(TDSReader tdsReader) throws SQLServerException {
/*  365 */         this.rowCount = 0;
/*      */ 
/*      */         
/*  368 */         int packetType = tdsReader.peekTokenType();
/*  369 */         if (253 == packetType) {
/*  370 */           short status = tdsReader.peekStatusFlag();
/*      */           
/*  372 */           if ((status & 0x2) != 0) {
/*      */             
/*  374 */             StreamDone doneToken = new StreamDone();
/*  375 */             doneToken.setFromTDS(tdsReader);
/*  376 */             return true;
/*      */           } 
/*      */         } 
/*      */         
/*  380 */         return false;
/*      */       }
/*      */     };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  440 */     this.rowErrorException = null; int resultSetID = nextResultSetID(); this.loggingClassName = "com.microsoft.sqlserver.jdbc.SQLServerResultSet:" + resultSetID; this.traceID = "SQLServerResultSet:" + resultSetID; this.stmt = stmtIn; this.maxRows = stmtIn.maxRows; this.fetchSize = stmtIn.nFetchSize; this.fetchDirection = stmtIn.nFetchDirection; CursorInitializer initializer = stmtIn.executedSqlDirectly ? new ClientCursorInitializer() : new ServerCursorInitializer(stmtIn); TDSParser.parse(stmtIn.resultsReader(), initializer); this.columns = initializer.buildColumns(); this.rowCount = initializer.getRowCount(); this.serverCursorId = initializer.getServerCursorId(); this.tdsReader = (0 == this.serverCursorId) ? stmtIn.resultsReader() : null; this.fetchBuffer = new FetchBuffer(); this.scrollWindow = isForwardOnly() ? null : new ScrollWindow(this.fetchSize); this.numFetchedRows = 0; stmtIn.incrResultSetCount(); if (logger.isLoggable(Level.FINE))
/*      */       logger.fine(toString() + " created by (" + toString() + ")"); 
/*      */   } public boolean isWrapperFor(Class<?> iface) throws SQLException { loggerExternal.entering(getClassNameLogging(), "isWrapperFor"); boolean f = iface.isInstance(this); loggerExternal.exiting(getClassNameLogging(), "isWrapperFor", Boolean.valueOf(f)); return f; } public <T> T unwrap(Class<T> iface) throws SQLException { T t; loggerExternal.entering(getClassNameLogging(), "unwrap"); try {
/*      */       t = iface.cast(this);
/*      */     } catch (ClassCastException e) {
/*      */       throw new SQLServerException(e.getMessage(), e);
/*      */     } 
/*      */     loggerExternal.exiting(getClassNameLogging(), "unwrap", t);
/*      */     return t; }
/*  449 */   void checkClosed() throws SQLServerException { if (this.isClosed) {
/*  450 */       SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, SQLServerException.getErrString("R_resultsetClosed"), (String)null, false);
/*      */     }
/*      */ 
/*      */     
/*  454 */     this.stmt.checkClosed();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  459 */     if (null != this.rowErrorException) {
/*  460 */       throw this.rowErrorException;
/*      */     } }
/*      */ 
/*      */   
/*      */   public boolean isClosed() throws SQLException {
/*  465 */     loggerExternal.entering(getClassNameLogging(), "isClosed");
/*  466 */     boolean result = (this.isClosed || this.stmt.isClosed());
/*  467 */     loggerExternal.exiting(getClassNameLogging(), "isClosed", Boolean.valueOf(result));
/*  468 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void throwNotScrollable() throws SQLException {
/*  479 */     SQLServerException.makeFromDriverError(this.stmt.connection, this, 
/*  480 */         SQLServerException.getErrString("R_requestedOpNotSupportedOnForward"), (String)null, true);
/*      */   }
/*      */   
/*      */   protected boolean isForwardOnly() {
/*  484 */     return (2003 == this.stmt.getSQLResultSetType() || 2004 == this.stmt
/*  485 */       .getSQLResultSetType());
/*      */   }
/*      */   
/*      */   private boolean isDynamic() {
/*  489 */     return (0 != this.serverCursorId && 2 == this.stmt.getCursorType());
/*      */   }
/*      */   
/*      */   private void verifyResultSetIsScrollable() throws SQLException {
/*  493 */     if (isForwardOnly()) {
/*  494 */       throwNotScrollable();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void throwNotUpdatable() throws SQLServerException {
/*  504 */     SQLServerException.makeFromDriverError(this.stmt.connection, this, 
/*  505 */         SQLServerException.getErrString("R_resultsetNotUpdatable"), (String)null, true);
/*      */   }
/*      */   
/*      */   private void verifyResultSetIsUpdatable() throws SQLServerException {
/*  509 */     if (1007 == this.stmt.resultSetConcurrency || 0 == this.serverCursorId) {
/*  510 */       throwNotUpdatable();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean hasCurrentRow() {
/*  520 */     return (0 != this.currentRow && -1 != this.currentRow);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void verifyResultSetHasCurrentRow() throws SQLServerException {
/*  539 */     if (!hasCurrentRow()) {
/*  540 */       SQLServerException.makeFromDriverError(this.stmt.connection, this.stmt, 
/*  541 */           SQLServerException.getErrString("R_resultsetNoCurrentRow"), (String)null, true);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void verifyCurrentRowIsNotDeleted(String errResource) throws SQLServerException {
/*  552 */     if (currentRowDeleted()) {
/*  553 */       SQLServerException.makeFromDriverError(this.stmt.connection, this.stmt, SQLServerException.getErrString(errResource), (String)null, true);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void verifyValidColumnIndex(int index) throws SQLServerException {
/*  566 */     int nCols = this.columns.length;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  571 */     if (0 != this.serverCursorId) {
/*  572 */       nCols--;
/*      */     }
/*  574 */     if (index < 1 || index > nCols) {
/*  575 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_indexOutOfRange"));
/*  576 */       Object[] msgArgs = { Integer.valueOf(index) };
/*  577 */       SQLServerException.makeFromDriverError(this.stmt.connection, this.stmt, form.format(msgArgs), "07009", false);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void verifyResultSetIsNotOnInsertRow() throws SQLServerException {
/*  588 */     if (this.isOnInsertRow) {
/*  589 */       SQLServerException.makeFromDriverError(this.stmt.connection, this.stmt, 
/*  590 */           SQLServerException.getErrString("R_mustNotBeOnInsertRow"), (String)null, true);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private void throwUnsupportedCursorOp() throws SQLServerException {
/*  596 */     SQLServerException.makeFromDriverError(this.stmt.connection, this, 
/*  597 */         SQLServerException.getErrString("R_unsupportedCursorOperation"), (String)null, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void closeInternal() {
/*  610 */     if (this.isClosed) {
/*      */       return;
/*      */     }
/*      */     
/*  614 */     this.isClosed = true;
/*      */ 
/*      */     
/*  617 */     discardFetchBuffer();
/*      */ 
/*      */     
/*  620 */     closeServerCursor();
/*      */ 
/*      */     
/*  623 */     this.metaData = null;
/*      */ 
/*      */     
/*  626 */     this.stmt.decrResultSetCount();
/*      */   }
/*      */ 
/*      */   
/*      */   public void close() throws SQLServerException {
/*  631 */     loggerExternal.entering(getClassNameLogging(), "close");
/*  632 */     if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) {
/*  633 */       loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */     }
/*  635 */     closeInternal();
/*  636 */     loggerExternal.exiting(getClassNameLogging(), "close");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int findColumn(String userProvidedColumnName) throws SQLServerException {
/*  650 */     loggerExternal.entering(getClassNameLogging(), "findColumn", userProvidedColumnName);
/*  651 */     checkClosed();
/*      */     
/*  653 */     Integer value = this.columnNames.get(userProvidedColumnName);
/*  654 */     if (null != value) {
/*  655 */       return value.intValue();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     int i;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  678 */     for (i = 0; i < this.columns.length; i++) {
/*  679 */       if (this.columns[i].getColumnName().equals(userProvidedColumnName)) {
/*  680 */         this.columnNames.put(userProvidedColumnName, Integer.valueOf(i + 1));
/*  681 */         loggerExternal.exiting(getClassNameLogging(), "findColumn", Integer.valueOf(i + 1));
/*  682 */         return i + 1;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  690 */     for (i = 0; i < this.columns.length; i++) {
/*  691 */       if (this.columns[i].getColumnName().equalsIgnoreCase(userProvidedColumnName)) {
/*  692 */         this.columnNames.put(userProvidedColumnName, Integer.valueOf(i + 1));
/*  693 */         loggerExternal.exiting(getClassNameLogging(), "findColumn", Integer.valueOf(i + 1));
/*  694 */         return i + 1;
/*      */       } 
/*      */     } 
/*  697 */     MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidColumnName"));
/*  698 */     Object[] msgArgs = { userProvidedColumnName };
/*  699 */     SQLServerException.makeFromDriverError(this.stmt.connection, this.stmt, form.format(msgArgs), "07009", false);
/*      */     
/*  701 */     return 0;
/*      */   }
/*      */   
/*      */   final int getColumnCount() {
/*  705 */     int nCols = this.columns.length;
/*  706 */     if (0 != this.serverCursorId)
/*  707 */       nCols--; 
/*  708 */     return nCols;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   final Column getColumn(int columnIndex) throws SQLServerException {
/*  714 */     if (null != this.activeStream) {
/*      */       try {
/*  716 */         fillLOBs();
/*  717 */         this.activeStream.close();
/*  718 */       } catch (IOException e) {
/*  719 */         SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, e.getMessage(), (String)null, true);
/*      */       } finally {
/*  721 */         this.activeStream = null;
/*      */       } 
/*      */     }
/*      */     
/*  725 */     return this.columns[columnIndex - 1];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void initializeNullCompressedColumns() throws SQLServerException {
/*  735 */     if (this.resultSetCurrentRowType.equals(RowType.NBCROW) && !this.areNullCompressedColumnsInitialized) {
/*  736 */       int columnNo = 0;
/*      */       
/*  738 */       int noOfBytes = (this.columns.length - 1 >> 3) + 1;
/*      */ 
/*      */       
/*  741 */       for (int byteNo = 0; byteNo < noOfBytes; byteNo++) {
/*      */         
/*  743 */         int byteValue = this.tdsReader.readUnsignedByte();
/*      */ 
/*      */ 
/*      */         
/*  747 */         if (byteValue == 0) {
/*  748 */           columnNo += 8;
/*      */         }
/*      */         else {
/*      */           
/*  752 */           for (int bitNo = 0; bitNo < 8 && columnNo < this.columns.length; bitNo++, columnNo++) {
/*  753 */             if ((byteValue & 1 << bitNo) != 0)
/*  754 */               this.columns[columnNo].initFromCompressedNull(); 
/*      */           } 
/*      */         } 
/*      */       } 
/*  758 */       this.areNullCompressedColumnsInitialized = true;
/*      */     } 
/*      */   }
/*      */   
/*      */   private Column loadColumn(int index) throws SQLServerException {
/*  763 */     assert 1 <= index && index <= this.columns.length;
/*      */     
/*  765 */     initializeNullCompressedColumns();
/*      */ 
/*      */ 
/*      */     
/*  769 */     if (index > this.lastColumnIndex && !this.columns[index - 1].isInitialized()) {
/*  770 */       skipColumns(index - this.lastColumnIndex, false);
/*      */     }
/*      */     
/*  773 */     return getColumn(index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearWarnings() throws SQLServerException {
/*  784 */     loggerExternal.entering(getClassNameLogging(), "clearWarnings");
/*  785 */     loggerExternal.exiting(getClassNameLogging(), "clearWarnings");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void moverInit() throws SQLServerException {
/*  791 */     fillLOBs();
/*  792 */     cancelInsert();
/*  793 */     cancelUpdates();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean relative(int rows) throws SQLException {
/*  798 */     if (loggerExternal.isLoggable(Level.FINER)) {
/*  799 */       loggerExternal.entering(getClassNameLogging(), "relative", Integer.valueOf(rows));
/*      */     }
/*  801 */     if (logger.isLoggable(Level.FINER)) {
/*  802 */       logger.finer(toString() + " rows:" + toString() + rows);
/*      */     }
/*  804 */     checkClosed();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  809 */     verifyResultSetIsScrollable();
/*  810 */     verifyResultSetHasCurrentRow();
/*      */     
/*  812 */     moverInit();
/*  813 */     moveRelative(rows);
/*  814 */     boolean value = hasCurrentRow();
/*  815 */     loggerExternal.exiting(getClassNameLogging(), "relative", Boolean.valueOf(value));
/*  816 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   private void moveRelative(int rowsToMove) throws SQLServerException {
/*  821 */     assert hasCurrentRow();
/*      */ 
/*      */     
/*  824 */     if (0 == rowsToMove) {
/*      */       return;
/*      */     }
/*  827 */     if (rowsToMove > 0) {
/*  828 */       moveForward(rowsToMove);
/*      */     } else {
/*  830 */       moveBackward(rowsToMove);
/*      */     } 
/*      */   }
/*      */   private void moveForward(int rowsToMove) throws SQLServerException {
/*  834 */     assert hasCurrentRow();
/*  835 */     assert rowsToMove > 0;
/*      */ 
/*      */     
/*  838 */     if (this.scrollWindow.getRow() + rowsToMove <= this.scrollWindow.getMaxRows()) {
/*  839 */       int rowsMoved = 0;
/*  840 */       while (rowsToMove > 0 && this.scrollWindow.next(this)) {
/*  841 */         rowsMoved++;
/*  842 */         rowsToMove--;
/*      */       } 
/*      */ 
/*      */       
/*  846 */       updateCurrentRow(rowsMoved);
/*      */ 
/*      */       
/*  849 */       if (0 == rowsToMove) {
/*      */         return;
/*      */       }
/*      */     } 
/*      */     
/*  854 */     assert rowsToMove > 0;
/*      */ 
/*      */ 
/*      */     
/*  858 */     if (0 == this.serverCursorId) {
/*  859 */       assert -2 != this.currentRow;
/*  860 */       this.currentRow = clientMoveAbsolute(this.currentRow + rowsToMove);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  873 */     if (1 == rowsToMove) {
/*  874 */       doServerFetch(2, 0, this.fetchSize);
/*      */     } else {
/*  876 */       doServerFetch(32, rowsToMove + this.scrollWindow.getRow() - 1, this.fetchSize);
/*      */     } 
/*      */     
/*  879 */     if (!this.scrollWindow.next(this)) {
/*  880 */       this.currentRow = -1;
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*  885 */     updateCurrentRow(rowsToMove);
/*      */   }
/*      */   
/*      */   private void moveBackward(int rowsToMove) throws SQLServerException {
/*  889 */     assert hasCurrentRow();
/*  890 */     assert rowsToMove < 0;
/*      */ 
/*      */     
/*  893 */     if (this.scrollWindow.getRow() + rowsToMove >= 1) {
/*  894 */       for (int rowsMoved = 0; rowsMoved > rowsToMove; rowsMoved--) {
/*  895 */         this.scrollWindow.previous(this);
/*      */       }
/*  897 */       updateCurrentRow(rowsToMove);
/*      */ 
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */ 
/*      */     
/*  905 */     if (0 == this.serverCursorId) {
/*  906 */       assert -2 != this.currentRow;
/*      */ 
/*      */ 
/*      */       
/*  910 */       if (this.currentRow + rowsToMove < 1) {
/*  911 */         moveBeforeFirst();
/*      */       } else {
/*  913 */         this.currentRow = clientMoveAbsolute(this.currentRow + rowsToMove);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  935 */     if (-1 == rowsToMove) {
/*  936 */       doServerFetch(512, 0, this.fetchSize);
/*      */ 
/*      */       
/*  939 */       if (!this.scrollWindow.next(this)) {
/*  940 */         this.currentRow = 0;
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/*  945 */       while (this.scrollWindow.next(this));
/*      */ 
/*      */       
/*  948 */       this.scrollWindow.previous(this);
/*      */     } else {
/*  950 */       doServerFetch(32, rowsToMove + this.scrollWindow.getRow() - 1, this.fetchSize);
/*      */ 
/*      */       
/*  953 */       if (!this.scrollWindow.next(this)) {
/*  954 */         this.currentRow = 0;
/*      */         
/*      */         return;
/*      */       } 
/*      */     } 
/*      */     
/*  960 */     updateCurrentRow(rowsToMove);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void updateCurrentRow(int rowsToMove) {
/*  970 */     if (-2 != this.currentRow) {
/*  971 */       assert this.currentRow >= 1;
/*  972 */       this.currentRow += rowsToMove;
/*  973 */       assert this.currentRow >= 1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean next() throws SQLServerException {
/*  985 */     loggerExternal.entering(getClassNameLogging(), "next");
/*  986 */     if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) {
/*  987 */       loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */     }
/*  989 */     if (logger.isLoggable(Level.FINER)) {
/*  990 */       logger.finer(toString() + toString());
/*      */     }
/*  992 */     checkClosed();
/*      */     
/*  994 */     moverInit();
/*      */ 
/*      */ 
/*      */     
/*  998 */     if (-1 == this.currentRow) {
/*  999 */       loggerExternal.exiting(getClassNameLogging(), "next", Boolean.valueOf(false));
/* 1000 */       return false;
/*      */     } 
/*      */ 
/*      */     
/* 1004 */     if (!isForwardOnly()) {
/* 1005 */       if (0 == this.currentRow) {
/* 1006 */         moveFirst();
/*      */       } else {
/* 1008 */         moveForward(1);
/*      */       } 
/* 1010 */       boolean value = hasCurrentRow();
/* 1011 */       loggerExternal.exiting(getClassNameLogging(), "next", Boolean.valueOf(value));
/* 1012 */       return value;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1019 */     if (0 != this.serverCursorId && this.maxRows > 0 && 
/* 1020 */       this.currentRow == this.maxRows) {
/* 1021 */       this.currentRow = -1;
/* 1022 */       loggerExternal.exiting(getClassNameLogging(), "next", Boolean.valueOf(false));
/* 1023 */       return false;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1029 */     if (fetchBufferNext()) {
/*      */ 
/*      */ 
/*      */       
/* 1033 */       if (0 == this.currentRow) {
/* 1034 */         this.currentRow = 1;
/*      */       } else {
/* 1036 */         updateCurrentRow(1);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1041 */       assert 0 == this.maxRows || this.currentRow <= this.maxRows;
/* 1042 */       loggerExternal.exiting(getClassNameLogging(), "next", Boolean.valueOf(true));
/*      */       
/* 1044 */       return true;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1050 */     if (0 != this.serverCursorId) {
/* 1051 */       doServerFetch(2, 0, this.fetchSize);
/*      */ 
/*      */ 
/*      */       
/* 1055 */       if (fetchBufferNext()) {
/* 1056 */         if (0 == this.currentRow) {
/* 1057 */           this.currentRow = 1;
/*      */         } else {
/* 1059 */           updateCurrentRow(1);
/*      */         } 
/* 1061 */         assert 0 == this.maxRows || this.currentRow <= this.maxRows;
/* 1062 */         loggerExternal.exiting(getClassNameLogging(), "next", Boolean.valueOf(true));
/* 1063 */         return true;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1068 */     if (-3 == this.rowCount) {
/* 1069 */       this.rowCount = this.currentRow;
/*      */     }
/*      */     
/* 1072 */     if (this.stmt.resultsReader().peekTokenType() == 171) {
/* 1073 */       this.stmt.startResults();
/* 1074 */       this.stmt.getNextResult(false);
/*      */     } 
/*      */     
/* 1077 */     this.currentRow = -1;
/* 1078 */     loggerExternal.exiting(getClassNameLogging(), "next", Boolean.valueOf(false));
/* 1079 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean wasNull() throws SQLServerException {
/* 1084 */     loggerExternal.entering(getClassNameLogging(), "wasNull");
/* 1085 */     checkClosed();
/* 1086 */     loggerExternal.exiting(getClassNameLogging(), "wasNull", Boolean.valueOf(this.lastValueWasNull));
/* 1087 */     return this.lastValueWasNull;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isBeforeFirst() throws SQLException {
/* 1098 */     loggerExternal.entering(getClassNameLogging(), "isBeforeFirst");
/* 1099 */     if (logger.isLoggable(Level.FINER)) {
/* 1100 */       logger.finer(toString() + toString());
/*      */     }
/* 1102 */     checkClosed();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1111 */     if (0 != this.serverCursorId) {
/* 1112 */       switch (this.stmt.getCursorType()) {
/*      */         case 4:
/* 1114 */           throwNotScrollable();
/*      */           break;
/*      */         
/*      */         case 2:
/* 1118 */           throwUnsupportedCursorOp();
/*      */           break;
/*      */         
/*      */         case 16:
/* 1122 */           throwNotScrollable();
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 1131 */     if (this.isOnInsertRow) {
/* 1132 */       return false;
/*      */     }
/*      */ 
/*      */     
/* 1136 */     if (0 != this.currentRow) {
/* 1137 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1144 */     if (0 == this.serverCursorId) {
/* 1145 */       return fetchBufferHasRows();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1150 */     assert this.rowCount >= 0;
/* 1151 */     boolean value = (this.rowCount > 0);
/* 1152 */     loggerExternal.exiting(getClassNameLogging(), "isBeforeFirst", Boolean.valueOf(value));
/* 1153 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isAfterLast() throws SQLException {
/* 1158 */     loggerExternal.entering(getClassNameLogging(), "isAfterLast");
/* 1159 */     if (logger.isLoggable(Level.FINER)) {
/* 1160 */       logger.finer(toString() + toString());
/*      */     }
/* 1162 */     checkClosed();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1169 */     if (0 != this.serverCursorId) {
/* 1170 */       verifyResultSetIsScrollable();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1175 */       if (2 == this.stmt.getCursorType() && !isForwardOnly()) {
/* 1176 */         throwUnsupportedCursorOp();
/*      */       }
/*      */     } 
/* 1179 */     if (this.isOnInsertRow) {
/* 1180 */       return false;
/*      */     }
/*      */ 
/*      */     
/* 1184 */     assert -1 != this.currentRow || -3 != this.rowCount;
/*      */     
/* 1186 */     boolean value = (-1 == this.currentRow && this.rowCount > 0);
/* 1187 */     loggerExternal.exiting(getClassNameLogging(), "isAfterLast", Boolean.valueOf(value));
/* 1188 */     return value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isFirst() throws SQLException {
/* 1210 */     loggerExternal.entering(getClassNameLogging(), "isFirst");
/* 1211 */     if (logger.isLoggable(Level.FINER)) {
/* 1212 */       logger.finer(toString() + toString());
/*      */     }
/* 1214 */     checkClosed();
/*      */ 
/*      */ 
/*      */     
/* 1218 */     verifyResultSetIsScrollable();
/*      */ 
/*      */ 
/*      */     
/* 1222 */     if (isDynamic()) {
/* 1223 */       throwUnsupportedCursorOp();
/*      */     }
/* 1225 */     if (this.isOnInsertRow) {
/* 1226 */       return false;
/*      */     }
/*      */ 
/*      */     
/* 1230 */     assert -2 != this.currentRow;
/*      */ 
/*      */     
/* 1233 */     boolean value = (1 == this.currentRow);
/* 1234 */     loggerExternal.exiting(getClassNameLogging(), "isFirst", Boolean.valueOf(value));
/* 1235 */     return value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isLast() throws SQLException {
/* 1260 */     loggerExternal.entering(getClassNameLogging(), "isLast");
/* 1261 */     if (logger.isLoggable(Level.FINER)) {
/* 1262 */       logger.finer(toString() + toString());
/*      */     }
/* 1264 */     checkClosed();
/*      */ 
/*      */ 
/*      */     
/* 1268 */     verifyResultSetIsScrollable();
/*      */ 
/*      */ 
/*      */     
/* 1272 */     if (isDynamic()) {
/* 1273 */       throwUnsupportedCursorOp();
/*      */     }
/* 1275 */     if (this.isOnInsertRow) {
/* 1276 */       return false;
/*      */     }
/*      */ 
/*      */     
/* 1280 */     if (!hasCurrentRow()) {
/* 1281 */       return false;
/*      */     }
/*      */     
/* 1284 */     assert this.currentRow >= 1;
/*      */ 
/*      */     
/* 1287 */     if (-3 != this.rowCount) {
/* 1288 */       assert this.currentRow <= this.rowCount;
/* 1289 */       return (this.currentRow == this.rowCount);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1296 */     assert 0 == this.serverCursorId;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1303 */     boolean isLast = !next();
/* 1304 */     previous();
/* 1305 */     loggerExternal.exiting(getClassNameLogging(), "isLast", Boolean.valueOf(isLast));
/* 1306 */     return isLast;
/*      */   }
/*      */ 
/*      */   
/*      */   public void beforeFirst() throws SQLException {
/* 1311 */     loggerExternal.entering(getClassNameLogging(), "beforeFirst");
/* 1312 */     if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) {
/* 1313 */       loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */     }
/* 1315 */     if (logger.isLoggable(Level.FINER)) {
/* 1316 */       logger.finer(toString() + toString());
/*      */     }
/* 1318 */     checkClosed();
/*      */ 
/*      */ 
/*      */     
/* 1322 */     verifyResultSetIsScrollable();
/*      */     
/* 1324 */     moverInit();
/* 1325 */     moveBeforeFirst();
/* 1326 */     loggerExternal.exiting(getClassNameLogging(), "beforeFirst");
/*      */   }
/*      */   
/*      */   private void moveBeforeFirst() throws SQLServerException {
/* 1330 */     if (0 == this.serverCursorId) {
/* 1331 */       fetchBufferBeforeFirst();
/* 1332 */       this.scrollWindow.clear();
/*      */     } else {
/* 1334 */       doServerFetch(1, 0, 0);
/*      */     } 
/*      */     
/* 1337 */     this.currentRow = 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public void afterLast() throws SQLException {
/* 1342 */     loggerExternal.entering(getClassNameLogging(), "afterLast");
/* 1343 */     if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) {
/* 1344 */       loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */     }
/*      */     
/* 1347 */     if (logger.isLoggable(Level.FINER)) {
/* 1348 */       logger.finer(toString() + toString());
/*      */     }
/* 1350 */     checkClosed();
/*      */ 
/*      */ 
/*      */     
/* 1354 */     verifyResultSetIsScrollable();
/*      */     
/* 1356 */     moverInit();
/* 1357 */     moveAfterLast();
/* 1358 */     loggerExternal.exiting(getClassNameLogging(), "afterLast");
/*      */   }
/*      */   
/*      */   private void moveAfterLast() throws SQLServerException {
/* 1362 */     assert !isForwardOnly();
/*      */     
/* 1364 */     if (0 == this.serverCursorId) {
/* 1365 */       clientMoveAfterLast();
/*      */     } else {
/* 1367 */       doServerFetch(8, 0, 0);
/*      */     } 
/* 1369 */     this.currentRow = -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean first() throws SQLException {
/* 1391 */     loggerExternal.entering(getClassNameLogging(), "first");
/* 1392 */     if (logger.isLoggable(Level.FINER)) {
/* 1393 */       logger.finer(toString() + toString());
/*      */     }
/* 1395 */     checkClosed();
/*      */ 
/*      */ 
/*      */     
/* 1399 */     verifyResultSetIsScrollable();
/*      */     
/* 1401 */     moverInit();
/* 1402 */     moveFirst();
/* 1403 */     boolean value = hasCurrentRow();
/* 1404 */     loggerExternal.exiting(getClassNameLogging(), "first", Boolean.valueOf(value));
/* 1405 */     return value;
/*      */   }
/*      */   
/*      */   private void moveFirst() throws SQLServerException {
/* 1409 */     if (0 == this.serverCursorId) {
/* 1410 */       moveBeforeFirst();
/*      */     } else {
/*      */       
/* 1413 */       doServerFetch(1, 0, this.fetchSize);
/*      */     } 
/*      */ 
/*      */     
/* 1417 */     if (!this.scrollWindow.next(this)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1423 */       this.currentRow = -1;
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 1428 */     this.currentRow = isDynamic() ? -2 : 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean last() throws SQLException {
/* 1448 */     loggerExternal.entering(getClassNameLogging(), "last");
/* 1449 */     if (logger.isLoggable(Level.FINER)) {
/* 1450 */       logger.finer(toString() + toString());
/*      */     }
/* 1452 */     checkClosed();
/*      */ 
/*      */ 
/*      */     
/* 1456 */     verifyResultSetIsScrollable();
/*      */     
/* 1458 */     moverInit();
/* 1459 */     moveLast();
/* 1460 */     boolean value = hasCurrentRow();
/* 1461 */     loggerExternal.exiting(getClassNameLogging(), "last", Boolean.valueOf(value));
/* 1462 */     return value;
/*      */   }
/*      */   
/*      */   private void moveLast() throws SQLServerException {
/* 1466 */     if (0 == this.serverCursorId) {
/* 1467 */       this.currentRow = clientMoveAbsolute(-1);
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 1472 */     doServerFetch(8, 0, this.fetchSize);
/*      */ 
/*      */     
/* 1475 */     if (!this.scrollWindow.next(this)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1481 */       this.currentRow = -1;
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 1486 */     while (this.scrollWindow.next(this));
/* 1487 */     this.scrollWindow.previous(this);
/*      */ 
/*      */     
/* 1490 */     this.currentRow = isDynamic() ? -2 : this.rowCount;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getRow() throws SQLException {
/* 1495 */     loggerExternal.entering(getClassNameLogging(), "getRow");
/* 1496 */     if (logger.isLoggable(Level.FINER)) {
/* 1497 */       logger.finer(toString() + toString());
/*      */     }
/* 1499 */     checkClosed();
/*      */ 
/*      */ 
/*      */     
/* 1503 */     if (isDynamic() && !isForwardOnly()) {
/* 1504 */       throwUnsupportedCursorOp();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1511 */     if (!hasCurrentRow() || this.isOnInsertRow) {
/* 1512 */       return 0;
/*      */     }
/*      */     
/* 1515 */     assert this.currentRow >= 1;
/*      */ 
/*      */     
/* 1518 */     loggerExternal.exiting(getClassNameLogging(), "getRow", Integer.valueOf(this.currentRow));
/* 1519 */     return this.currentRow;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean absolute(int row) throws SQLException {
/* 1566 */     loggerExternal.entering(getClassNameLogging(), "absolute");
/* 1567 */     if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) {
/* 1568 */       loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */     }
/* 1570 */     if (logger.isLoggable(Level.FINER)) {
/* 1571 */       logger.finer(toString() + " row:" + toString() + row);
/*      */     }
/* 1573 */     checkClosed();
/*      */ 
/*      */ 
/*      */     
/* 1577 */     verifyResultSetIsScrollable();
/*      */ 
/*      */ 
/*      */     
/* 1581 */     if (isDynamic()) {
/* 1582 */       throwUnsupportedCursorOp();
/*      */     }
/* 1584 */     moverInit();
/* 1585 */     moveAbsolute(row);
/* 1586 */     boolean value = hasCurrentRow();
/* 1587 */     loggerExternal.exiting(getClassNameLogging(), "absolute", Boolean.valueOf(value));
/* 1588 */     return value;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void moveAbsolute(int row) throws SQLServerException {
/* 1594 */     assert -2 != this.currentRow;
/* 1595 */     assert !isDynamic();
/*      */     
/* 1597 */     switch (row) {
/*      */       
/*      */       case 0:
/* 1600 */         moveBeforeFirst();
/*      */         return;
/*      */ 
/*      */       
/*      */       case 1:
/* 1605 */         moveFirst();
/*      */         return;
/*      */ 
/*      */       
/*      */       case -1:
/* 1610 */         moveLast();
/*      */         return;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1619 */     if (hasCurrentRow()) {
/* 1620 */       assert this.currentRow >= 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1626 */       if (row > 0) {
/* 1627 */         moveRelative(row - this.currentRow);
/*      */ 
/*      */ 
/*      */         
/*      */         return;
/*      */       } 
/*      */ 
/*      */       
/* 1635 */       if (-3 != this.rowCount) {
/* 1636 */         assert row < 0;
/* 1637 */         moveRelative(this.rowCount + row + 1 - this.currentRow);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         return;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1649 */     if (0 == this.serverCursorId) {
/* 1650 */       this.currentRow = clientMoveAbsolute(row);
/*      */       
/*      */       return;
/*      */     } 
/* 1654 */     doServerFetch(16, row, this.fetchSize);
/*      */ 
/*      */ 
/*      */     
/* 1658 */     if (!this.scrollWindow.next(this)) {
/* 1659 */       this.currentRow = (row < 0) ? 0 : -1;
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 1665 */     if (row > 0) {
/*      */       
/* 1667 */       this.currentRow = row;
/*      */     } else {
/*      */       
/* 1670 */       assert row < 0;
/* 1671 */       assert this.rowCount + row + 1 >= 1;
/* 1672 */       this.currentRow = this.rowCount + row + 1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean fetchBufferHasRows() throws SQLServerException {
/* 1680 */     assert 0 == this.serverCursorId;
/* 1681 */     assert null != this.tdsReader;
/*      */     
/* 1683 */     assert this.lastColumnIndex >= 0;
/*      */ 
/*      */     
/* 1686 */     if (this.lastColumnIndex >= 1) {
/* 1687 */       return true;
/*      */     }
/*      */ 
/*      */     
/* 1691 */     int tdsTokenType = this.tdsReader.peekTokenType();
/*      */ 
/*      */ 
/*      */     
/* 1695 */     return (209 == tdsTokenType || 210 == tdsTokenType || 171 == tdsTokenType || 170 == tdsTokenType);
/*      */   }
/*      */ 
/*      */   
/*      */   final void discardCurrentRow() throws SQLServerException {
/* 1700 */     assert this.lastColumnIndex >= 0;
/*      */     
/* 1702 */     this.updatedCurrentRow = false;
/* 1703 */     this.deletedCurrentRow = false;
/* 1704 */     if (this.lastColumnIndex >= 1) {
/* 1705 */       initializeNullCompressedColumns();
/*      */       
/* 1707 */       for (int columnIndex = 1; columnIndex < this.lastColumnIndex; columnIndex++) {
/* 1708 */         getColumn(columnIndex).clear();
/*      */       }
/*      */ 
/*      */       
/* 1712 */       skipColumns(this.columns.length + 1 - this.lastColumnIndex, true);
/*      */     } 
/*      */ 
/*      */     
/* 1716 */     this.resultSetCurrentRowType = RowType.UNKNOWN;
/* 1717 */     this.areNullCompressedColumnsInitialized = false;
/*      */   }
/*      */   
/*      */   final int fetchBufferGetRow() {
/* 1721 */     if (isForwardOnly()) {
/* 1722 */       return this.numFetchedRows;
/*      */     }
/* 1724 */     return this.scrollWindow.getRow();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   final void fetchBufferBeforeFirst() throws SQLServerException {
/* 1730 */     assert 0 == this.serverCursorId;
/* 1731 */     assert null != this.tdsReader;
/*      */     
/* 1733 */     discardCurrentRow();
/*      */     
/* 1735 */     this.fetchBuffer.reset();
/* 1736 */     this.lastColumnIndex = 0;
/*      */   }
/*      */ 
/*      */   
/*      */   final TDSReaderMark fetchBufferMark() {
/* 1741 */     assert null != this.tdsReader;
/*      */     
/* 1743 */     return this.tdsReader.mark();
/*      */   }
/*      */ 
/*      */   
/*      */   final void fetchBufferReset(TDSReaderMark mark) throws SQLServerException {
/* 1748 */     assert null != this.tdsReader;
/*      */     
/* 1750 */     assert null != mark;
/*      */     
/* 1752 */     discardCurrentRow();
/*      */     
/* 1754 */     this.tdsReader.reset(mark);
/*      */     
/* 1756 */     this.lastColumnIndex = 1;
/*      */   }
/*      */ 
/*      */   
/*      */   final boolean fetchBufferNext() throws SQLServerException {
/* 1761 */     if (null == this.tdsReader) {
/* 1762 */       return false;
/*      */     }
/*      */     
/* 1765 */     discardCurrentRow();
/*      */ 
/*      */ 
/*      */     
/* 1769 */     RowType fetchBufferCurrentRowType = RowType.UNKNOWN;
/*      */     try {
/* 1771 */       fetchBufferCurrentRowType = this.fetchBuffer.nextRow();
/* 1772 */       if (fetchBufferCurrentRowType.equals(RowType.UNKNOWN))
/* 1773 */         return false; 
/* 1774 */     } catch (SQLServerException e) {
/* 1775 */       this.currentRow = -1;
/* 1776 */       this.rowErrorException = e;
/* 1777 */       throw e;
/*      */     } finally {
/* 1779 */       this.lastColumnIndex = 0;
/* 1780 */       this.resultSetCurrentRowType = fetchBufferCurrentRowType;
/*      */     } 
/*      */ 
/*      */     
/* 1784 */     this.numFetchedRows++;
/* 1785 */     this.lastColumnIndex = 1;
/* 1786 */     return true;
/*      */   }
/*      */   
/*      */   private void clientMoveAfterLast() throws SQLServerException {
/* 1790 */     assert -2 != this.currentRow;
/*      */     
/* 1792 */     int rowsSkipped = 0;
/* 1793 */     while (fetchBufferNext()) {
/* 1794 */       rowsSkipped++;
/*      */     }
/* 1796 */     if (-3 == this.rowCount) {
/* 1797 */       assert -1 != this.currentRow;
/* 1798 */       this.rowCount = ((0 == this.currentRow) ? 0 : this.currentRow) + rowsSkipped;
/*      */     } 
/*      */   }
/*      */   
/*      */   private int clientMoveAbsolute(int row) throws SQLServerException {
/* 1803 */     assert 0 == this.serverCursorId;
/*      */     
/* 1805 */     this.scrollWindow.clear();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1812 */     if (row < 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1817 */       if (-3 == this.rowCount) {
/* 1818 */         clientMoveAfterLast();
/* 1819 */         this.currentRow = -1;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1824 */       assert this.rowCount >= 0;
/*      */ 
/*      */ 
/*      */       
/* 1828 */       if (this.rowCount + row < 0) {
/* 1829 */         moveBeforeFirst();
/* 1830 */         return 0;
/*      */       } 
/*      */       
/* 1833 */       row = this.rowCount + row + 1;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1840 */     assert row > 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1846 */     if (-1 == this.currentRow || row <= this.currentRow) {
/* 1847 */       moveBeforeFirst();
/*      */     }
/*      */ 
/*      */     
/* 1851 */     assert 0 == this.currentRow || this.currentRow < row;
/* 1852 */     while (this.currentRow != row) {
/* 1853 */       if (!fetchBufferNext()) {
/* 1854 */         if (-3 == this.rowCount)
/* 1855 */           this.rowCount = this.currentRow; 
/* 1856 */         return -1;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1862 */       if (0 == this.currentRow) {
/* 1863 */         this.currentRow = 1; continue;
/*      */       } 
/* 1865 */       updateCurrentRow(1);
/*      */     } 
/*      */     
/* 1868 */     return row;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean previous() throws SQLException {
/* 1888 */     loggerExternal.entering(getClassNameLogging(), "previous");
/* 1889 */     if (logger.isLoggable(Level.FINER)) {
/* 1890 */       logger.finer(toString() + toString());
/*      */     }
/* 1892 */     checkClosed();
/*      */ 
/*      */ 
/*      */     
/* 1896 */     verifyResultSetIsScrollable();
/*      */     
/* 1898 */     moverInit();
/*      */     
/* 1900 */     if (0 == this.currentRow) {
/* 1901 */       return false;
/*      */     }
/* 1903 */     if (-1 == this.currentRow) {
/* 1904 */       moveLast();
/*      */     } else {
/* 1906 */       moveBackward(-1);
/*      */     } 
/* 1908 */     boolean value = hasCurrentRow();
/* 1909 */     loggerExternal.exiting(getClassNameLogging(), "previous", Boolean.valueOf(value));
/* 1910 */     return value;
/*      */   }
/*      */   
/*      */   private void cancelInsert() {
/* 1914 */     if (this.isOnInsertRow) {
/* 1915 */       this.isOnInsertRow = false;
/* 1916 */       clearColumnsValues();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   final void clearColumnsValues() {
/* 1922 */     for (Column column : this.columns) {
/* 1923 */       column.cancelUpdates();
/*      */     }
/*      */   }
/*      */   
/*      */   public SQLWarning getWarnings() throws SQLException {
/* 1928 */     loggerExternal.entering(getClassNameLogging(), "getWarnings");
/* 1929 */     loggerExternal.exiting(getClassNameLogging(), "getWarnings", null);
/* 1930 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setFetchDirection(int direction) throws SQLException {
/* 1935 */     loggerExternal.entering(getClassNameLogging(), "setFetchDirection", Integer.valueOf(direction));
/* 1936 */     checkClosed();
/*      */ 
/*      */ 
/*      */     
/* 1940 */     verifyResultSetIsScrollable();
/*      */     
/* 1942 */     if ((1000 != direction && 1001 != direction && 1002 != direction) || (1000 != direction && (2003 == this.stmt.resultSetType || 2004 == this.stmt.resultSetType))) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1948 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidFetchDirection"));
/* 1949 */       Object[] msgArgs = { Integer.valueOf(direction) };
/* 1950 */       SQLServerException.makeFromDriverError(this.stmt.connection, this.stmt, form.format(msgArgs), (String)null, false);
/*      */     } 
/*      */     
/* 1953 */     this.fetchDirection = direction;
/* 1954 */     loggerExternal.exiting(getClassNameLogging(), "setFetchDirection");
/*      */   }
/*      */ 
/*      */   
/*      */   public int getFetchDirection() throws SQLException {
/* 1959 */     loggerExternal.entering(getClassNameLogging(), "getFetchDirection");
/* 1960 */     checkClosed();
/* 1961 */     loggerExternal.exiting(getClassNameLogging(), "getFetchDirection", Integer.valueOf(this.fetchDirection));
/* 1962 */     return this.fetchDirection;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setFetchSize(int rows) throws SQLServerException {
/* 1967 */     loggerExternal.entering(getClassNameLogging(), "setFetchSize", Integer.valueOf(rows));
/* 1968 */     checkClosed();
/* 1969 */     if (rows < 0) {
/* 1970 */       SQLServerException.makeFromDriverError(this.stmt.connection, this.stmt, 
/* 1971 */           SQLServerException.getErrString("R_invalidFetchSize"), (String)null, false);
/*      */     }
/* 1973 */     this.fetchSize = (0 == rows) ? this.stmt.defaultFetchSize : rows;
/* 1974 */     loggerExternal.exiting(getClassNameLogging(), "setFetchSize");
/*      */   }
/*      */ 
/*      */   
/*      */   public int getFetchSize() throws SQLException {
/* 1979 */     loggerExternal.entering(getClassNameLogging(), "getFetchSize");
/* 1980 */     checkClosed();
/* 1981 */     loggerExternal.exiting(getClassNameLogging(), "getFloat", Integer.valueOf(this.fetchSize));
/* 1982 */     return this.fetchSize;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getType() throws SQLServerException {
/* 1987 */     loggerExternal.entering(getClassNameLogging(), "getType");
/* 1988 */     checkClosed();
/*      */     
/* 1990 */     int value = this.stmt.getResultSetType();
/* 1991 */     loggerExternal.exiting(getClassNameLogging(), "getType", Integer.valueOf(value));
/* 1992 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getConcurrency() throws SQLServerException {
/* 1997 */     loggerExternal.entering(getClassNameLogging(), "getConcurrency");
/* 1998 */     checkClosed();
/* 1999 */     int value = this.stmt.getResultSetConcurrency();
/* 2000 */     loggerExternal.exiting(getClassNameLogging(), "getConcurrency", Integer.valueOf(value));
/* 2001 */     return value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Column getterGetColumn(int index) throws SQLServerException {
/* 2023 */     verifyResultSetHasCurrentRow();
/* 2024 */     verifyCurrentRowIsNotDeleted("R_cantGetColumnValueFromDeletedRow");
/* 2025 */     verifyValidColumnIndex(index);
/*      */     
/* 2027 */     if (this.updatedCurrentRow) {
/* 2028 */       doRefreshRow();
/* 2029 */       verifyResultSetHasCurrentRow();
/*      */     } 
/*      */     
/* 2032 */     if (logger.isLoggable(Level.FINER)) {
/* 2033 */       logger.finer(toString() + " Getting Column:" + toString());
/*      */     }
/* 2035 */     fillLOBs();
/* 2036 */     return loadColumn(index);
/*      */   }
/*      */   
/*      */   private Object getValue(int columnIndex, JDBCType jdbcType) throws SQLServerException {
/* 2040 */     return getValue(columnIndex, jdbcType, null, null);
/*      */   }
/*      */   
/*      */   private Object getValue(int columnIndex, JDBCType jdbcType, Calendar cal) throws SQLServerException {
/* 2044 */     return getValue(columnIndex, jdbcType, null, cal);
/*      */   }
/*      */ 
/*      */   
/*      */   private Object getValue(int columnIndex, JDBCType jdbcType, InputStreamGetterArgs getterArgs) throws SQLServerException {
/* 2049 */     return getValue(columnIndex, jdbcType, getterArgs, null);
/*      */   }
/*      */ 
/*      */   
/*      */   private Object getValue(int columnIndex, JDBCType jdbcType, InputStreamGetterArgs getterArgs, Calendar cal) throws SQLServerException {
/* 2054 */     Object o = getterGetColumn(columnIndex).getValue(jdbcType, getterArgs, cal, this.tdsReader);
/* 2055 */     this.lastValueWasNull = (null == o);
/* 2056 */     return o;
/*      */   }
/*      */   
/*      */   void setInternalVariantType(int columnIndex, SqlVariant type) throws SQLServerException {
/* 2060 */     getterGetColumn(columnIndex).setInternalVariant(type);
/*      */   }
/*      */   
/*      */   SqlVariant getVariantInternalType(int columnIndex) throws SQLServerException {
/* 2064 */     return getterGetColumn(columnIndex).getInternalVariant();
/*      */   }
/*      */   
/*      */   private Object getStream(int columnIndex, StreamType streamType) throws SQLServerException {
/* 2068 */     Object value = getValue(columnIndex, streamType.getJDBCType(), new InputStreamGetterArgs(streamType, this.stmt
/* 2069 */           .getExecProps().isResponseBufferingAdaptive(), isForwardOnly(), toString()));
/*      */     
/* 2071 */     this.activeStream = (Closeable)value;
/* 2072 */     return value;
/*      */   }
/*      */   
/*      */   private SQLXML getSQLXMLInternal(int columnIndex) throws SQLServerException {
/* 2076 */     SQLServerSQLXML value = (SQLServerSQLXML)getValue(columnIndex, JDBCType.SQLXML, new InputStreamGetterArgs(StreamType.SQLXML, this.stmt
/* 2077 */           .getExecProps().isResponseBufferingAdaptive(), isForwardOnly(), toString()));
/*      */     
/* 2079 */     if (null != value)
/* 2080 */       this.activeStream = value.getStream(); 
/* 2081 */     return value;
/*      */   }
/*      */   
/*      */   private void configureLobs(SQLServerLob lob) throws SQLServerException {
/* 2085 */     if (null != this.stmt) {
/* 2086 */       Connection c = this.stmt.getConnection();
/* 2087 */       if (c instanceof ISQLServerConnection && 
/* 2088 */         null != c && !((ISQLServerConnection)c).getDelayLoadingLobs() && null != lob) {
/* 2089 */         lob.setDelayLoadingLob();
/*      */       }
/*      */     } 
/*      */     
/* 2093 */     this.activeLOB = lob;
/*      */   }
/*      */ 
/*      */   
/*      */   public InputStream getAsciiStream(int columnIndex) throws SQLServerException {
/* 2098 */     loggerExternal.entering(getClassNameLogging(), "getAsciiStream", Integer.valueOf(columnIndex));
/* 2099 */     checkClosed();
/* 2100 */     InputStream value = (InputStream)getStream(columnIndex, StreamType.ASCII);
/* 2101 */     loggerExternal.exiting(getClassNameLogging(), "getAsciiStream", value);
/* 2102 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public InputStream getAsciiStream(String columnName) throws SQLServerException {
/* 2107 */     loggerExternal.entering(getClassNameLogging(), "getAsciiStream", columnName);
/* 2108 */     checkClosed();
/* 2109 */     InputStream value = (InputStream)getStream(findColumn(columnName), StreamType.ASCII);
/* 2110 */     loggerExternal.exiting(getClassNameLogging(), "getAsciiStream", value);
/* 2111 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public BigDecimal getBigDecimal(int columnIndex, int scale) throws SQLServerException {
/* 2117 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2118 */       loggerExternal.entering(getClassNameLogging(), "getBigDecimal", new Object[] { Integer.valueOf(columnIndex), Integer.valueOf(scale) }); 
/* 2119 */     checkClosed();
/* 2120 */     BigDecimal value = (BigDecimal)getValue(columnIndex, JDBCType.DECIMAL);
/* 2121 */     if (null != value)
/* 2122 */       value = value.setScale(scale, 1); 
/* 2123 */     loggerExternal.exiting(getClassNameLogging(), "getBigDecimal", value);
/* 2124 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public BigDecimal getBigDecimal(String columnName, int scale) throws SQLServerException {
/* 2130 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2131 */       loggerExternal.entering(getClassNameLogging(), "columnName", new Object[] { columnName, Integer.valueOf(scale) }); 
/* 2132 */     checkClosed();
/* 2133 */     BigDecimal value = (BigDecimal)getValue(findColumn(columnName), JDBCType.DECIMAL);
/* 2134 */     if (null != value)
/* 2135 */       value = value.setScale(scale, 1); 
/* 2136 */     loggerExternal.exiting(getClassNameLogging(), "getBigDecimal", value);
/* 2137 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public InputStream getBinaryStream(int columnIndex) throws SQLServerException {
/* 2142 */     loggerExternal.entering(getClassNameLogging(), "getBinaryStream", Integer.valueOf(columnIndex));
/* 2143 */     checkClosed();
/* 2144 */     InputStream value = (InputStream)getStream(columnIndex, StreamType.BINARY);
/* 2145 */     loggerExternal.exiting(getClassNameLogging(), "getBinaryStream", value);
/* 2146 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public InputStream getBinaryStream(String columnName) throws SQLServerException {
/* 2151 */     loggerExternal.entering(getClassNameLogging(), "getBinaryStream", columnName);
/* 2152 */     checkClosed();
/* 2153 */     InputStream value = (InputStream)getStream(findColumn(columnName), StreamType.BINARY);
/* 2154 */     loggerExternal.exiting(getClassNameLogging(), "getBinaryStream", value);
/* 2155 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean getBoolean(int columnIndex) throws SQLServerException {
/* 2160 */     loggerExternal.entering(getClassNameLogging(), "getBoolean", Integer.valueOf(columnIndex));
/* 2161 */     checkClosed();
/* 2162 */     Boolean value = (Boolean)getValue(columnIndex, JDBCType.BIT);
/* 2163 */     loggerExternal.exiting(getClassNameLogging(), "getBoolean", value);
/* 2164 */     return (null != value) ? value.booleanValue() : false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean getBoolean(String columnName) throws SQLServerException {
/* 2169 */     loggerExternal.entering(getClassNameLogging(), "getBoolean", columnName);
/* 2170 */     checkClosed();
/* 2171 */     Boolean value = (Boolean)getValue(findColumn(columnName), JDBCType.BIT);
/* 2172 */     loggerExternal.exiting(getClassNameLogging(), "getBoolean", value);
/* 2173 */     return (null != value) ? value.booleanValue() : false;
/*      */   }
/*      */ 
/*      */   
/*      */   public byte getByte(int columnIndex) throws SQLServerException {
/* 2178 */     loggerExternal.entering(getClassNameLogging(), "getByte", Integer.valueOf(columnIndex));
/* 2179 */     checkClosed();
/* 2180 */     Short value = (Short)getValue(columnIndex, JDBCType.TINYINT);
/* 2181 */     loggerExternal.exiting(getClassNameLogging(), "getByte", value);
/* 2182 */     return (null != value) ? value.byteValue() : 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public byte getByte(String columnName) throws SQLServerException {
/* 2187 */     loggerExternal.entering(getClassNameLogging(), "getByte", columnName);
/* 2188 */     checkClosed();
/* 2189 */     Short value = (Short)getValue(findColumn(columnName), JDBCType.TINYINT);
/* 2190 */     loggerExternal.exiting(getClassNameLogging(), "getByte", value);
/* 2191 */     return (null != value) ? value.byteValue() : 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public byte[] getBytes(int columnIndex) throws SQLServerException {
/* 2196 */     loggerExternal.entering(getClassNameLogging(), "getBytes", Integer.valueOf(columnIndex));
/* 2197 */     checkClosed();
/* 2198 */     byte[] value = (byte[])getValue(columnIndex, JDBCType.BINARY);
/* 2199 */     loggerExternal.exiting(getClassNameLogging(), "getBytes", value);
/* 2200 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public byte[] getBytes(String columnName) throws SQLServerException {
/* 2205 */     loggerExternal.entering(getClassNameLogging(), "getBytes", columnName);
/* 2206 */     checkClosed();
/* 2207 */     byte[] value = (byte[])getValue(findColumn(columnName), JDBCType.BINARY);
/* 2208 */     loggerExternal.exiting(getClassNameLogging(), "getBytes", value);
/* 2209 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Date getDate(int columnIndex) throws SQLServerException {
/* 2214 */     loggerExternal.entering(getClassNameLogging(), "getDate", Integer.valueOf(columnIndex));
/* 2215 */     checkClosed();
/* 2216 */     Date value = (Date)getValue(columnIndex, JDBCType.DATE);
/* 2217 */     loggerExternal.exiting(getClassNameLogging(), "getDate", value);
/* 2218 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Date getDate(String columnName) throws SQLServerException {
/* 2223 */     loggerExternal.entering(getClassNameLogging(), "getDate", columnName);
/* 2224 */     checkClosed();
/* 2225 */     Date value = (Date)getValue(findColumn(columnName), JDBCType.DATE);
/* 2226 */     loggerExternal.exiting(getClassNameLogging(), "getDate", value);
/* 2227 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Date getDate(int columnIndex, Calendar cal) throws SQLServerException {
/* 2232 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2233 */       loggerExternal.entering(getClassNameLogging(), "getDate", new Object[] { Integer.valueOf(columnIndex), cal }); 
/* 2234 */     checkClosed();
/* 2235 */     Date value = (Date)getValue(columnIndex, JDBCType.DATE, cal);
/* 2236 */     loggerExternal.exiting(getClassNameLogging(), "getDate", value);
/* 2237 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Date getDate(String colName, Calendar cal) throws SQLServerException {
/* 2242 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2243 */       loggerExternal.entering(getClassNameLogging(), "getDate", new Object[] { colName, cal }); 
/* 2244 */     checkClosed();
/* 2245 */     Date value = (Date)getValue(findColumn(colName), JDBCType.DATE, cal);
/* 2246 */     loggerExternal.exiting(getClassNameLogging(), "getDate", value);
/* 2247 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public double getDouble(int columnIndex) throws SQLServerException {
/* 2252 */     loggerExternal.entering(getClassNameLogging(), "getDouble", Integer.valueOf(columnIndex));
/* 2253 */     checkClosed();
/* 2254 */     Double value = (Double)getValue(columnIndex, JDBCType.DOUBLE);
/* 2255 */     loggerExternal.exiting(getClassNameLogging(), "getDouble", value);
/* 2256 */     return (null != value) ? value.doubleValue() : 0.0D;
/*      */   }
/*      */ 
/*      */   
/*      */   public double getDouble(String columnName) throws SQLServerException {
/* 2261 */     loggerExternal.entering(getClassNameLogging(), "getDouble", columnName);
/* 2262 */     checkClosed();
/* 2263 */     Double value = (Double)getValue(findColumn(columnName), JDBCType.DOUBLE);
/* 2264 */     loggerExternal.exiting(getClassNameLogging(), "getDouble", value);
/* 2265 */     return (null != value) ? value.doubleValue() : 0.0D;
/*      */   }
/*      */ 
/*      */   
/*      */   public float getFloat(int columnIndex) throws SQLServerException {
/* 2270 */     loggerExternal.entering(getClassNameLogging(), "getFloat", Integer.valueOf(columnIndex));
/* 2271 */     checkClosed();
/* 2272 */     Float value = (Float)getValue(columnIndex, JDBCType.REAL);
/* 2273 */     loggerExternal.exiting(getClassNameLogging(), "getFloat", value);
/* 2274 */     return (null != value) ? value.floatValue() : 0.0F;
/*      */   }
/*      */ 
/*      */   
/*      */   public float getFloat(String columnName) throws SQLServerException {
/* 2279 */     loggerExternal.entering(getClassNameLogging(), "getFloat", columnName);
/* 2280 */     checkClosed();
/* 2281 */     Float value = (Float)getValue(findColumn(columnName), JDBCType.REAL);
/* 2282 */     loggerExternal.exiting(getClassNameLogging(), "getFloat", value);
/* 2283 */     return (null != value) ? value.floatValue() : 0.0F;
/*      */   }
/*      */ 
/*      */   
/*      */   public Geometry getGeometry(int columnIndex) throws SQLServerException {
/* 2288 */     loggerExternal.entering(getClassNameLogging(), "getFloat", Integer.valueOf(columnIndex));
/* 2289 */     checkClosed();
/* 2290 */     Geometry value = (Geometry)getValue(columnIndex, JDBCType.GEOMETRY);
/* 2291 */     loggerExternal.exiting(getClassNameLogging(), "getFloat", value);
/* 2292 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Geometry getGeometry(String columnName) throws SQLServerException {
/* 2297 */     loggerExternal.entering(getClassNameLogging(), "getFloat", columnName);
/* 2298 */     checkClosed();
/* 2299 */     Geometry value = (Geometry)getValue(findColumn(columnName), JDBCType.GEOMETRY);
/* 2300 */     loggerExternal.exiting(getClassNameLogging(), "getFloat", value);
/* 2301 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Geography getGeography(int columnIndex) throws SQLServerException {
/* 2306 */     loggerExternal.entering(getClassNameLogging(), "getFloat", Integer.valueOf(columnIndex));
/* 2307 */     checkClosed();
/* 2308 */     Geography value = (Geography)getValue(columnIndex, JDBCType.GEOGRAPHY);
/* 2309 */     loggerExternal.exiting(getClassNameLogging(), "getFloat", value);
/* 2310 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Geography getGeography(String columnName) throws SQLServerException {
/* 2315 */     loggerExternal.entering(getClassNameLogging(), "getFloat", columnName);
/* 2316 */     checkClosed();
/* 2317 */     Geography value = (Geography)getValue(findColumn(columnName), JDBCType.GEOGRAPHY);
/* 2318 */     loggerExternal.exiting(getClassNameLogging(), "getFloat", value);
/* 2319 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getInt(int columnIndex) throws SQLServerException {
/* 2324 */     loggerExternal.entering(getClassNameLogging(), "getInt", Integer.valueOf(columnIndex));
/* 2325 */     checkClosed();
/* 2326 */     Integer value = (Integer)getValue(columnIndex, JDBCType.INTEGER);
/* 2327 */     loggerExternal.exiting(getClassNameLogging(), "getInt", value);
/* 2328 */     return (null != value) ? value.intValue() : 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getInt(String columnName) throws SQLServerException {
/* 2333 */     loggerExternal.entering(getClassNameLogging(), "getInt", columnName);
/* 2334 */     checkClosed();
/* 2335 */     Integer value = (Integer)getValue(findColumn(columnName), JDBCType.INTEGER);
/* 2336 */     loggerExternal.exiting(getClassNameLogging(), "getInt", value);
/* 2337 */     return (null != value) ? value.intValue() : 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public long getLong(int columnIndex) throws SQLServerException {
/* 2342 */     loggerExternal.entering(getClassNameLogging(), "getLong", Integer.valueOf(columnIndex));
/* 2343 */     checkClosed();
/* 2344 */     Long value = (Long)getValue(columnIndex, JDBCType.BIGINT);
/* 2345 */     loggerExternal.exiting(getClassNameLogging(), "getLong", value);
/* 2346 */     return (null != value) ? value.longValue() : 0L;
/*      */   }
/*      */ 
/*      */   
/*      */   public long getLong(String columnName) throws SQLServerException {
/* 2351 */     loggerExternal.entering(getClassNameLogging(), "getLong", columnName);
/* 2352 */     checkClosed();
/* 2353 */     Long value = (Long)getValue(findColumn(columnName), JDBCType.BIGINT);
/* 2354 */     loggerExternal.exiting(getClassNameLogging(), "getLong", value);
/* 2355 */     return (null != value) ? value.longValue() : 0L;
/*      */   }
/*      */ 
/*      */   
/*      */   public ResultSetMetaData getMetaData() throws SQLServerException {
/* 2360 */     loggerExternal.entering(getClassNameLogging(), "getMetaData");
/* 2361 */     checkClosed();
/* 2362 */     if (this.metaData == null)
/* 2363 */       this.metaData = new SQLServerResultSetMetaData(this.stmt.connection, this); 
/* 2364 */     loggerExternal.exiting(getClassNameLogging(), "getMetaData", this.metaData);
/* 2365 */     return this.metaData;
/*      */   }
/*      */ 
/*      */   
/*      */   public Object getObject(int columnIndex) throws SQLServerException {
/* 2370 */     loggerExternal.entering(getClassNameLogging(), "getObject", Integer.valueOf(columnIndex));
/* 2371 */     checkClosed();
/* 2372 */     Object value = getValue(columnIndex, getterGetColumn(columnIndex).getTypeInfo().getSSType().getJDBCType());
/* 2373 */     loggerExternal.exiting(getClassNameLogging(), "getObject", value);
/* 2374 */     return value;
/*      */   }
/*      */   
/*      */   public <T> T getObject(int columnIndex, Class<T> type) throws SQLException {
/*      */     Object returnValue;
/* 2379 */     loggerExternal.entering(getClassNameLogging(), "getObject", Integer.valueOf(columnIndex));
/* 2380 */     checkClosed();
/*      */     
/* 2382 */     if (type == String.class) {
/* 2383 */       returnValue = getString(columnIndex);
/* 2384 */     } else if (type == Byte.class) {
/* 2385 */       byte byteValue = getByte(columnIndex);
/* 2386 */       returnValue = wasNull() ? null : Byte.valueOf(byteValue);
/* 2387 */     } else if (type == Short.class) {
/* 2388 */       short shortValue = getShort(columnIndex);
/* 2389 */       returnValue = wasNull() ? null : Short.valueOf(shortValue);
/* 2390 */     } else if (type == Integer.class) {
/* 2391 */       int intValue = getInt(columnIndex);
/* 2392 */       returnValue = wasNull() ? null : Integer.valueOf(intValue);
/* 2393 */     } else if (type == Long.class) {
/* 2394 */       long longValue = getLong(columnIndex);
/* 2395 */       returnValue = wasNull() ? null : Long.valueOf(longValue);
/* 2396 */     } else if (type == BigDecimal.class) {
/* 2397 */       returnValue = getBigDecimal(columnIndex);
/* 2398 */     } else if (type == Boolean.class) {
/* 2399 */       boolean booleanValue = getBoolean(columnIndex);
/* 2400 */       returnValue = wasNull() ? null : Boolean.valueOf(booleanValue);
/* 2401 */     } else if (type == Date.class) {
/* 2402 */       returnValue = getDate(columnIndex);
/* 2403 */     } else if (type == Time.class) {
/* 2404 */       returnValue = getTime(columnIndex);
/* 2405 */     } else if (type == Timestamp.class) {
/* 2406 */       returnValue = getTimestamp(columnIndex);
/* 2407 */     } else if (type == LocalDateTime.class || type == LocalDate.class || type == LocalTime.class) {
/*      */       
/* 2409 */       LocalDateTime ldt = getLocalDateTime(columnIndex);
/* 2410 */       if (null == ldt) {
/* 2411 */         returnValue = null;
/*      */       }
/* 2413 */       else if (type == LocalDateTime.class) {
/* 2414 */         returnValue = ldt;
/* 2415 */       } else if (type == LocalDate.class) {
/* 2416 */         returnValue = ldt.toLocalDate();
/*      */       } else {
/* 2418 */         returnValue = ldt.toLocalTime();
/*      */       }
/*      */     
/* 2421 */     } else if (type == OffsetDateTime.class) {
/* 2422 */       DateTimeOffset dateTimeOffset = getDateTimeOffset(columnIndex);
/* 2423 */       if (dateTimeOffset == null) {
/* 2424 */         returnValue = null;
/*      */       } else {
/* 2426 */         returnValue = dateTimeOffset.getOffsetDateTime();
/*      */       } 
/* 2428 */     } else if (type == OffsetTime.class) {
/* 2429 */       DateTimeOffset dateTimeOffset = getDateTimeOffset(columnIndex);
/* 2430 */       if (dateTimeOffset == null) {
/* 2431 */         returnValue = null;
/*      */       } else {
/* 2433 */         returnValue = dateTimeOffset.getOffsetDateTime().toOffsetTime();
/*      */       } 
/* 2435 */     } else if (type == DateTimeOffset.class) {
/* 2436 */       returnValue = getDateTimeOffset(columnIndex);
/* 2437 */     } else if (type == UUID.class) {
/*      */       
/* 2439 */       byte[] guid = getBytes(columnIndex);
/* 2440 */       returnValue = (guid != null) ? Util.readGUIDtoUUID(guid) : null;
/* 2441 */     } else if (type == SQLXML.class) {
/* 2442 */       returnValue = getSQLXML(columnIndex);
/* 2443 */     } else if (type == Blob.class) {
/* 2444 */       returnValue = getBlob(columnIndex);
/* 2445 */     } else if (type == Clob.class) {
/* 2446 */       returnValue = getClob(columnIndex);
/* 2447 */     } else if (type == NClob.class) {
/* 2448 */       returnValue = getNClob(columnIndex);
/* 2449 */     } else if (type == byte[].class) {
/* 2450 */       returnValue = getBytes(columnIndex);
/* 2451 */     } else if (type == Float.class) {
/* 2452 */       float floatValue = getFloat(columnIndex);
/* 2453 */       returnValue = wasNull() ? null : Float.valueOf(floatValue);
/* 2454 */     } else if (type == Double.class) {
/* 2455 */       double doubleValue = getDouble(columnIndex);
/* 2456 */       returnValue = wasNull() ? null : Double.valueOf(doubleValue);
/*      */     }
/*      */     else {
/*      */       
/* 2460 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_unsupportedConversionTo"));
/* 2461 */       Object[] msgArgs = { type };
/* 2462 */       throw new SQLServerException(form.format(msgArgs), SQLState.DATA_EXCEPTION_NOT_SPECIFIC, DriverError.NOT_SET, null);
/*      */     } 
/*      */     
/* 2465 */     loggerExternal.exiting(getClassNameLogging(), "getObject", Integer.valueOf(columnIndex));
/* 2466 */     return type.cast(returnValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public Object getObject(String columnName) throws SQLServerException {
/* 2471 */     loggerExternal.entering(getClassNameLogging(), "getObject", columnName);
/* 2472 */     checkClosed();
/* 2473 */     Object value = getObject(findColumn(columnName));
/* 2474 */     loggerExternal.exiting(getClassNameLogging(), "getObject", value);
/* 2475 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> T getObject(String columnName, Class<T> type) throws SQLException {
/* 2480 */     loggerExternal.entering(getClassNameLogging(), "getObject", columnName);
/* 2481 */     checkClosed();
/* 2482 */     T value = getObject(findColumn(columnName), type);
/* 2483 */     loggerExternal.exiting(getClassNameLogging(), "getObject", value);
/* 2484 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public short getShort(int columnIndex) throws SQLServerException {
/* 2489 */     loggerExternal.entering(getClassNameLogging(), "getShort", Integer.valueOf(columnIndex));
/* 2490 */     checkClosed();
/* 2491 */     Short value = (Short)getValue(columnIndex, JDBCType.SMALLINT);
/* 2492 */     loggerExternal.exiting(getClassNameLogging(), "getShort", value);
/* 2493 */     return (null != value) ? value.shortValue() : 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public short getShort(String columnName) throws SQLServerException {
/* 2498 */     loggerExternal.entering(getClassNameLogging(), "getShort", columnName);
/* 2499 */     checkClosed();
/* 2500 */     Short value = (Short)getValue(findColumn(columnName), JDBCType.SMALLINT);
/* 2501 */     loggerExternal.exiting(getClassNameLogging(), "getShort", value);
/* 2502 */     return (null != value) ? value.shortValue() : 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getString(int columnIndex) throws SQLServerException {
/* 2507 */     loggerExternal.entering(getClassNameLogging(), "getString", Integer.valueOf(columnIndex));
/* 2508 */     checkClosed();
/*      */     
/* 2510 */     String value = null;
/* 2511 */     Object objectValue = getValue(columnIndex, JDBCType.CHAR);
/* 2512 */     if (null != objectValue) {
/* 2513 */       value = objectValue.toString();
/*      */     }
/* 2515 */     loggerExternal.exiting(getClassNameLogging(), "getString", value);
/* 2516 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getString(String columnName) throws SQLServerException {
/* 2521 */     loggerExternal.entering(getClassNameLogging(), "getString", columnName);
/* 2522 */     checkClosed();
/*      */     
/* 2524 */     String value = null;
/* 2525 */     Object objectValue = getValue(findColumn(columnName), JDBCType.CHAR);
/* 2526 */     if (null != objectValue) {
/* 2527 */       value = objectValue.toString();
/*      */     }
/* 2529 */     loggerExternal.exiting(getClassNameLogging(), "getString", value);
/* 2530 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getNString(int columnIndex) throws SQLException {
/* 2535 */     loggerExternal.entering(getClassNameLogging(), "getNString", Integer.valueOf(columnIndex));
/* 2536 */     checkClosed();
/* 2537 */     String value = (String)getValue(columnIndex, JDBCType.NCHAR);
/* 2538 */     loggerExternal.exiting(getClassNameLogging(), "getNString", value);
/* 2539 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getNString(String columnLabel) throws SQLException {
/* 2544 */     loggerExternal.entering(getClassNameLogging(), "getNString", columnLabel);
/* 2545 */     checkClosed();
/* 2546 */     String value = (String)getValue(findColumn(columnLabel), JDBCType.NCHAR);
/* 2547 */     loggerExternal.exiting(getClassNameLogging(), "getNString", value);
/* 2548 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getUniqueIdentifier(int columnIndex) throws SQLServerException {
/* 2553 */     loggerExternal.entering(getClassNameLogging(), "getUniqueIdentifier", Integer.valueOf(columnIndex));
/* 2554 */     checkClosed();
/* 2555 */     String value = (String)getValue(columnIndex, JDBCType.GUID);
/* 2556 */     loggerExternal.exiting(getClassNameLogging(), "getUniqueIdentifier", value);
/* 2557 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getUniqueIdentifier(String columnLabel) throws SQLServerException {
/* 2562 */     loggerExternal.entering(getClassNameLogging(), "getUniqueIdentifier", columnLabel);
/* 2563 */     checkClosed();
/* 2564 */     String value = (String)getValue(findColumn(columnLabel), JDBCType.GUID);
/* 2565 */     loggerExternal.exiting(getClassNameLogging(), "getUniqueIdentifier", value);
/* 2566 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Time getTime(int columnIndex) throws SQLServerException {
/* 2571 */     loggerExternal.entering(getClassNameLogging(), "getTime", Integer.valueOf(columnIndex));
/* 2572 */     checkClosed();
/* 2573 */     Time value = (Time)getValue(columnIndex, JDBCType.TIME);
/* 2574 */     loggerExternal.exiting(getClassNameLogging(), "getTime", value);
/* 2575 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Time getTime(String columnName) throws SQLServerException {
/* 2580 */     loggerExternal.entering(getClassNameLogging(), "getTime", columnName);
/* 2581 */     checkClosed();
/* 2582 */     Time value = (Time)getValue(findColumn(columnName), JDBCType.TIME);
/* 2583 */     loggerExternal.exiting(getClassNameLogging(), "getTime", value);
/* 2584 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Time getTime(int columnIndex, Calendar cal) throws SQLServerException {
/* 2589 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2590 */       loggerExternal.entering(getClassNameLogging(), "getTime", new Object[] { Integer.valueOf(columnIndex), cal }); 
/* 2591 */     checkClosed();
/* 2592 */     Time value = (Time)getValue(columnIndex, JDBCType.TIME, cal);
/* 2593 */     loggerExternal.exiting(getClassNameLogging(), "getTime", value);
/* 2594 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Time getTime(String colName, Calendar cal) throws SQLServerException {
/* 2599 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2600 */       loggerExternal.entering(getClassNameLogging(), "getTime", new Object[] { colName, cal }); 
/* 2601 */     checkClosed();
/* 2602 */     Time value = (Time)getValue(findColumn(colName), JDBCType.TIME, cal);
/* 2603 */     loggerExternal.exiting(getClassNameLogging(), "getTime", value);
/* 2604 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(int columnIndex) throws SQLServerException {
/* 2609 */     loggerExternal.entering(getClassNameLogging(), "getTimestamp", Integer.valueOf(columnIndex));
/* 2610 */     checkClosed();
/* 2611 */     Timestamp value = (Timestamp)getValue(columnIndex, JDBCType.TIMESTAMP);
/* 2612 */     loggerExternal.exiting(getClassNameLogging(), "getTimestamp", value);
/* 2613 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(String columnName) throws SQLServerException {
/* 2618 */     loggerExternal.entering(getClassNameLogging(), "getTimestamp", columnName);
/* 2619 */     checkClosed();
/* 2620 */     Timestamp value = (Timestamp)getValue(findColumn(columnName), JDBCType.TIMESTAMP);
/* 2621 */     loggerExternal.exiting(getClassNameLogging(), "getTimestamp", value);
/* 2622 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(int columnIndex, Calendar cal) throws SQLServerException {
/* 2627 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2628 */       loggerExternal.entering(getClassNameLogging(), "getTimestamp", new Object[] { Integer.valueOf(columnIndex), cal }); 
/* 2629 */     checkClosed();
/* 2630 */     Timestamp value = (Timestamp)getValue(columnIndex, JDBCType.TIMESTAMP, cal);
/* 2631 */     loggerExternal.exiting(getClassNameLogging(), "getTimeStamp", value);
/* 2632 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(String colName, Calendar cal) throws SQLServerException {
/* 2637 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2638 */       loggerExternal.entering(getClassNameLogging(), "getTimestamp", new Object[] { colName, cal }); 
/* 2639 */     checkClosed();
/* 2640 */     Timestamp value = (Timestamp)getValue(findColumn(colName), JDBCType.TIMESTAMP, cal);
/* 2641 */     loggerExternal.exiting(getClassNameLogging(), "getTimestamp", value);
/* 2642 */     return value;
/*      */   }
/*      */   
/*      */   LocalDateTime getLocalDateTime(int columnIndex) throws SQLServerException {
/* 2646 */     loggerExternal.entering(getClassNameLogging(), "getLocalDateTime", Integer.valueOf(columnIndex));
/* 2647 */     checkClosed();
/* 2648 */     LocalDateTime value = (LocalDateTime)getValue(columnIndex, JDBCType.LOCALDATETIME);
/* 2649 */     loggerExternal.exiting(getClassNameLogging(), "getLocalDateTime", value);
/* 2650 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Timestamp getDateTime(int columnIndex) throws SQLServerException {
/* 2655 */     loggerExternal.entering(getClassNameLogging(), "getDateTime", Integer.valueOf(columnIndex));
/* 2656 */     checkClosed();
/* 2657 */     Timestamp value = (Timestamp)getValue(columnIndex, JDBCType.TIMESTAMP);
/* 2658 */     loggerExternal.exiting(getClassNameLogging(), "getDateTime", value);
/* 2659 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Timestamp getDateTime(String columnName) throws SQLServerException {
/* 2664 */     loggerExternal.entering(getClassNameLogging(), "getDateTime", columnName);
/* 2665 */     checkClosed();
/* 2666 */     Timestamp value = (Timestamp)getValue(findColumn(columnName), JDBCType.TIMESTAMP);
/* 2667 */     loggerExternal.exiting(getClassNameLogging(), "getDateTime", value);
/* 2668 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Timestamp getDateTime(int columnIndex, Calendar cal) throws SQLServerException {
/* 2673 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2674 */       loggerExternal.entering(getClassNameLogging(), "getDateTime", new Object[] { Integer.valueOf(columnIndex), cal }); 
/* 2675 */     checkClosed();
/* 2676 */     Timestamp value = (Timestamp)getValue(columnIndex, JDBCType.TIMESTAMP, cal);
/* 2677 */     loggerExternal.exiting(getClassNameLogging(), "getDateTime", value);
/* 2678 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Timestamp getDateTime(String colName, Calendar cal) throws SQLServerException {
/* 2683 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2684 */       loggerExternal.entering(getClassNameLogging(), "getDateTime", new Object[] { colName, cal }); 
/* 2685 */     checkClosed();
/* 2686 */     Timestamp value = (Timestamp)getValue(findColumn(colName), JDBCType.TIMESTAMP, cal);
/* 2687 */     loggerExternal.exiting(getClassNameLogging(), "getDateTime", value);
/* 2688 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Timestamp getSmallDateTime(int columnIndex) throws SQLServerException {
/* 2693 */     loggerExternal.entering(getClassNameLogging(), "getSmallDateTime", Integer.valueOf(columnIndex));
/* 2694 */     checkClosed();
/* 2695 */     Timestamp value = (Timestamp)getValue(columnIndex, JDBCType.TIMESTAMP);
/* 2696 */     loggerExternal.exiting(getClassNameLogging(), "getSmallDateTime", value);
/* 2697 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Timestamp getSmallDateTime(String columnName) throws SQLServerException {
/* 2702 */     loggerExternal.entering(getClassNameLogging(), "getSmallDateTime", columnName);
/* 2703 */     checkClosed();
/* 2704 */     Timestamp value = (Timestamp)getValue(findColumn(columnName), JDBCType.TIMESTAMP);
/* 2705 */     loggerExternal.exiting(getClassNameLogging(), "getSmallDateTime", value);
/* 2706 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Timestamp getSmallDateTime(int columnIndex, Calendar cal) throws SQLServerException {
/* 2711 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2712 */       loggerExternal.entering(getClassNameLogging(), "getSmallDateTime", new Object[] { Integer.valueOf(columnIndex), cal }); 
/* 2713 */     checkClosed();
/* 2714 */     Timestamp value = (Timestamp)getValue(columnIndex, JDBCType.TIMESTAMP, cal);
/* 2715 */     loggerExternal.exiting(getClassNameLogging(), "getSmallDateTime", value);
/* 2716 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Timestamp getSmallDateTime(String colName, Calendar cal) throws SQLServerException {
/* 2721 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2722 */       loggerExternal.entering(getClassNameLogging(), "getSmallDateTime", new Object[] { colName, cal }); 
/* 2723 */     checkClosed();
/* 2724 */     Timestamp value = (Timestamp)getValue(findColumn(colName), JDBCType.TIMESTAMP, cal);
/* 2725 */     loggerExternal.exiting(getClassNameLogging(), "getSmallDateTime", value);
/* 2726 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public DateTimeOffset getDateTimeOffset(int columnIndex) throws SQLServerException {
/* 2731 */     loggerExternal.entering(getClassNameLogging(), "getDateTimeOffset", Integer.valueOf(columnIndex));
/* 2732 */     checkClosed();
/*      */ 
/*      */     
/* 2735 */     if (!this.stmt.connection.isKatmaiOrLater()) {
/* 2736 */       throw new SQLServerException(SQLServerException.getErrString("R_notSupported"), SQLState.DATA_EXCEPTION_NOT_SPECIFIC, DriverError.NOT_SET, null);
/*      */     }
/*      */     
/* 2739 */     DateTimeOffset value = (DateTimeOffset)getValue(columnIndex, JDBCType.DATETIMEOFFSET);
/*      */     
/* 2741 */     loggerExternal.exiting(getClassNameLogging(), "getDateTimeOffset", value);
/* 2742 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public DateTimeOffset getDateTimeOffset(String columnName) throws SQLServerException {
/* 2747 */     loggerExternal.entering(getClassNameLogging(), "getDateTimeOffset", columnName);
/* 2748 */     checkClosed();
/*      */ 
/*      */     
/* 2751 */     if (!this.stmt.connection.isKatmaiOrLater()) {
/* 2752 */       throw new SQLServerException(SQLServerException.getErrString("R_notSupported"), SQLState.DATA_EXCEPTION_NOT_SPECIFIC, DriverError.NOT_SET, null);
/*      */     }
/*      */     
/* 2755 */     DateTimeOffset value = (DateTimeOffset)getValue(findColumn(columnName), JDBCType.DATETIMEOFFSET);
/*      */     
/* 2757 */     loggerExternal.exiting(getClassNameLogging(), "getDateTimeOffset", value);
/* 2758 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public InputStream getUnicodeStream(int columnIndex) throws SQLException {
/* 2764 */     loggerExternal.entering(getClassNameLogging(), "getUnicodeStream", Integer.valueOf(columnIndex));
/* 2765 */     SQLServerException.throwNotSupportedException(this.stmt.connection, this.stmt);
/* 2766 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public InputStream getUnicodeStream(String columnName) throws SQLException {
/* 2772 */     loggerExternal.entering(getClassNameLogging(), "getUnicodeStream", columnName);
/* 2773 */     SQLServerException.throwNotSupportedException(this.stmt.connection, this.stmt);
/* 2774 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public Object getObject(int i, Map<String, Class<?>> map) throws SQLException {
/* 2779 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2780 */       loggerExternal.entering(getClassNameLogging(), "getObject", new Object[] { Integer.valueOf(i), map }); 
/* 2781 */     SQLServerException.throwNotSupportedException(this.stmt.connection, this.stmt);
/* 2782 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public Ref getRef(int i) throws SQLException {
/* 2787 */     loggerExternal.entering(getClassNameLogging(), "getRef");
/* 2788 */     SQLServerException.throwNotSupportedException(this.stmt.connection, this.stmt);
/* 2789 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public Blob getBlob(int i) throws SQLServerException {
/* 2794 */     loggerExternal.entering(getClassNameLogging(), "getBlob", Integer.valueOf(i));
/* 2795 */     checkClosed();
/* 2796 */     Blob value = (Blob)getValue(i, JDBCType.BLOB);
/* 2797 */     loggerExternal.exiting(getClassNameLogging(), "getBlob", value);
/* 2798 */     configureLobs((SQLServerLob)value);
/* 2799 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Blob getBlob(String colName) throws SQLServerException {
/* 2804 */     loggerExternal.entering(getClassNameLogging(), "getBlob", colName);
/* 2805 */     checkClosed();
/* 2806 */     Blob value = (Blob)getValue(findColumn(colName), JDBCType.BLOB);
/* 2807 */     loggerExternal.exiting(getClassNameLogging(), "getBlob", value);
/* 2808 */     configureLobs((SQLServerLob)value);
/* 2809 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Clob getClob(int columnIndex) throws SQLServerException {
/* 2814 */     loggerExternal.entering(getClassNameLogging(), "getClob", Integer.valueOf(columnIndex));
/* 2815 */     checkClosed();
/* 2816 */     Clob value = (Clob)getValue(columnIndex, JDBCType.CLOB);
/* 2817 */     loggerExternal.exiting(getClassNameLogging(), "getClob", value);
/* 2818 */     configureLobs((SQLServerLob)value);
/* 2819 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Clob getClob(String colName) throws SQLServerException {
/* 2824 */     loggerExternal.entering(getClassNameLogging(), "getClob", colName);
/* 2825 */     checkClosed();
/* 2826 */     Clob value = (Clob)getValue(findColumn(colName), JDBCType.CLOB);
/* 2827 */     loggerExternal.exiting(getClassNameLogging(), "getClob", value);
/* 2828 */     configureLobs((SQLServerLob)value);
/* 2829 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public NClob getNClob(int columnIndex) throws SQLException {
/* 2834 */     loggerExternal.entering(getClassNameLogging(), "getNClob", Integer.valueOf(columnIndex));
/* 2835 */     checkClosed();
/* 2836 */     NClob value = (NClob)getValue(columnIndex, JDBCType.NCLOB);
/* 2837 */     loggerExternal.exiting(getClassNameLogging(), "getNClob", value);
/* 2838 */     configureLobs((SQLServerLob)value);
/* 2839 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public NClob getNClob(String columnLabel) throws SQLException {
/* 2844 */     loggerExternal.entering(getClassNameLogging(), "getNClob", columnLabel);
/* 2845 */     checkClosed();
/* 2846 */     NClob value = (NClob)getValue(findColumn(columnLabel), JDBCType.NCLOB);
/* 2847 */     loggerExternal.exiting(getClassNameLogging(), "getNClob", value);
/* 2848 */     configureLobs((SQLServerLob)value);
/* 2849 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Array getArray(int i) throws SQLException {
/* 2854 */     SQLServerException.throwNotSupportedException(this.stmt.connection, this.stmt);
/* 2855 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public Object getObject(String colName, Map<String, Class<?>> map) throws SQLException {
/* 2860 */     SQLServerException.throwNotSupportedException(this.stmt.connection, this.stmt);
/* 2861 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public Ref getRef(String colName) throws SQLException {
/* 2866 */     SQLServerException.throwNotSupportedException(this.stmt.connection, this.stmt);
/* 2867 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public Array getArray(String colName) throws SQLException {
/* 2872 */     SQLServerException.throwNotSupportedException(this.stmt.connection, this.stmt);
/* 2873 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getCursorName() throws SQLException {
/* 2878 */     loggerExternal.entering(getClassNameLogging(), "getCursorName");
/* 2879 */     SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, 
/* 2880 */         SQLServerException.getErrString("R_positionedUpdatesNotSupported"), (String)null, false);
/* 2881 */     loggerExternal.exiting(getClassNameLogging(), "getCursorName", null);
/* 2882 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public Reader getCharacterStream(int columnIndex) throws SQLException {
/* 2887 */     loggerExternal.entering(getClassNameLogging(), "getCharacterStream", Integer.valueOf(columnIndex));
/* 2888 */     checkClosed();
/* 2889 */     Reader value = (Reader)getStream(columnIndex, StreamType.CHARACTER);
/* 2890 */     loggerExternal.exiting(getClassNameLogging(), "getCharacterStream", value);
/* 2891 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Reader getCharacterStream(String columnName) throws SQLException {
/* 2896 */     checkClosed();
/* 2897 */     loggerExternal.entering(getClassNameLogging(), "getCharacterStream", columnName);
/* 2898 */     Reader value = (Reader)getStream(findColumn(columnName), StreamType.CHARACTER);
/* 2899 */     loggerExternal.exiting(getClassNameLogging(), "getCharacterStream", value);
/* 2900 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Reader getNCharacterStream(int columnIndex) throws SQLException {
/* 2905 */     loggerExternal.entering(getClassNameLogging(), "getNCharacterStream", Integer.valueOf(columnIndex));
/* 2906 */     checkClosed();
/* 2907 */     Reader value = (Reader)getStream(columnIndex, StreamType.NCHARACTER);
/* 2908 */     loggerExternal.exiting(getClassNameLogging(), "getNCharacterStream", value);
/* 2909 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Reader getNCharacterStream(String columnLabel) throws SQLException {
/* 2914 */     loggerExternal.entering(getClassNameLogging(), "getNCharacterStream", columnLabel);
/* 2915 */     checkClosed();
/* 2916 */     Reader value = (Reader)getStream(findColumn(columnLabel), StreamType.NCHARACTER);
/* 2917 */     loggerExternal.exiting(getClassNameLogging(), "getNCharacterStream", value);
/* 2918 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(int columnIndex) throws SQLException {
/* 2923 */     loggerExternal.entering(getClassNameLogging(), "getBigDecimal", Integer.valueOf(columnIndex));
/* 2924 */     checkClosed();
/* 2925 */     BigDecimal value = (BigDecimal)getValue(columnIndex, JDBCType.DECIMAL);
/* 2926 */     loggerExternal.exiting(getClassNameLogging(), "getBigDecimal", value);
/* 2927 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(String columnName) throws SQLException {
/* 2932 */     loggerExternal.entering(getClassNameLogging(), "getBigDecimal", columnName);
/* 2933 */     checkClosed();
/* 2934 */     BigDecimal value = (BigDecimal)getValue(findColumn(columnName), JDBCType.DECIMAL);
/* 2935 */     loggerExternal.exiting(getClassNameLogging(), "getBigDecimal", value);
/* 2936 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public BigDecimal getMoney(int columnIndex) throws SQLServerException {
/* 2941 */     loggerExternal.entering(getClassNameLogging(), "getMoney", Integer.valueOf(columnIndex));
/* 2942 */     checkClosed();
/* 2943 */     BigDecimal value = (BigDecimal)getValue(columnIndex, JDBCType.DECIMAL);
/* 2944 */     loggerExternal.exiting(getClassNameLogging(), "getMoney", value);
/* 2945 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public BigDecimal getMoney(String columnName) throws SQLServerException {
/* 2950 */     loggerExternal.entering(getClassNameLogging(), "getMoney", columnName);
/* 2951 */     checkClosed();
/* 2952 */     BigDecimal value = (BigDecimal)getValue(findColumn(columnName), JDBCType.DECIMAL);
/* 2953 */     loggerExternal.exiting(getClassNameLogging(), "getMoney", value);
/* 2954 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public BigDecimal getSmallMoney(int columnIndex) throws SQLServerException {
/* 2959 */     loggerExternal.entering(getClassNameLogging(), "getSmallMoney", Integer.valueOf(columnIndex));
/* 2960 */     checkClosed();
/* 2961 */     BigDecimal value = (BigDecimal)getValue(columnIndex, JDBCType.DECIMAL);
/* 2962 */     loggerExternal.exiting(getClassNameLogging(), "getSmallMoney", value);
/* 2963 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public BigDecimal getSmallMoney(String columnName) throws SQLServerException {
/* 2968 */     loggerExternal.entering(getClassNameLogging(), "getSmallMoney", columnName);
/* 2969 */     checkClosed();
/* 2970 */     BigDecimal value = (BigDecimal)getValue(findColumn(columnName), JDBCType.DECIMAL);
/* 2971 */     loggerExternal.exiting(getClassNameLogging(), "getSmallMoney", value);
/* 2972 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public RowId getRowId(int columnIndex) throws SQLException {
/* 2977 */     SQLServerException.throwNotSupportedException(this.stmt.connection, this.stmt);
/* 2978 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public RowId getRowId(String columnLabel) throws SQLException {
/* 2983 */     SQLServerException.throwNotSupportedException(this.stmt.connection, this.stmt);
/* 2984 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public SQLXML getSQLXML(int columnIndex) throws SQLException {
/* 2989 */     loggerExternal.entering(getClassNameLogging(), "getSQLXML", Integer.valueOf(columnIndex));
/* 2990 */     SQLXML xml = getSQLXMLInternal(columnIndex);
/* 2991 */     loggerExternal.exiting(getClassNameLogging(), "getSQLXML", xml);
/* 2992 */     return xml;
/*      */   }
/*      */ 
/*      */   
/*      */   public SQLXML getSQLXML(String columnLabel) throws SQLException {
/* 2997 */     loggerExternal.entering(getClassNameLogging(), "getSQLXML", columnLabel);
/* 2998 */     SQLXML xml = getSQLXMLInternal(findColumn(columnLabel));
/* 2999 */     loggerExternal.exiting(getClassNameLogging(), "getSQLXML", xml);
/* 3000 */     return xml;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean rowUpdated() throws SQLServerException {
/* 3005 */     loggerExternal.entering(getClassNameLogging(), "rowUpdated");
/* 3006 */     checkClosed();
/*      */ 
/*      */     
/* 3009 */     verifyResultSetIsUpdatable();
/*      */ 
/*      */ 
/*      */     
/* 3013 */     loggerExternal.exiting(getClassNameLogging(), "rowUpdated", Boolean.valueOf(false));
/* 3014 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean rowInserted() throws SQLServerException {
/* 3019 */     loggerExternal.entering(getClassNameLogging(), "rowInserted");
/* 3020 */     checkClosed();
/*      */ 
/*      */ 
/*      */     
/* 3024 */     verifyResultSetIsUpdatable();
/*      */ 
/*      */ 
/*      */     
/* 3028 */     loggerExternal.exiting(getClassNameLogging(), "rowInserted", Boolean.valueOf(false));
/* 3029 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean rowDeleted() throws SQLServerException {
/* 3034 */     loggerExternal.entering(getClassNameLogging(), "rowDeleted");
/* 3035 */     checkClosed();
/*      */ 
/*      */ 
/*      */     
/* 3039 */     verifyResultSetIsUpdatable();
/*      */     
/* 3041 */     if (this.isOnInsertRow || !hasCurrentRow()) {
/* 3042 */       return false;
/*      */     }
/* 3044 */     boolean deleted = currentRowDeleted();
/* 3045 */     loggerExternal.exiting(getClassNameLogging(), "rowDeleted", Boolean.valueOf(deleted));
/* 3046 */     return deleted;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean currentRowDeleted() throws SQLServerException {
/* 3057 */     assert hasCurrentRow();
/*      */ 
/*      */     
/* 3060 */     assert null != this.tdsReader;
/*      */     
/* 3062 */     return (this.deletedCurrentRow || (0 != this.serverCursorId && 2 == 
/* 3063 */       loadColumn(this.columns.length).getInt(this.tdsReader)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Column updaterGetColumn(int index) throws SQLServerException {
/* 3077 */     verifyResultSetIsUpdatable();
/*      */     
/* 3079 */     verifyValidColumnIndex(index);
/*      */ 
/*      */     
/* 3082 */     if (!this.columns[index - 1].isUpdatable()) {
/* 3083 */       SQLServerException.makeFromDriverError(this.stmt.connection, this.stmt, 
/* 3084 */           SQLServerException.getErrString("R_cantUpdateColumn"), "07009", false);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 3089 */     if (!this.isOnInsertRow) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3094 */       if (!hasCurrentRow()) {
/* 3095 */         SQLServerException.makeFromDriverError(this.stmt.connection, this.stmt, 
/* 3096 */             SQLServerException.getErrString("R_resultsetNoCurrentRow"), (String)null, true);
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 3101 */       verifyCurrentRowIsNotDeleted("R_cantUpdateDeletedRow");
/*      */     } 
/*      */     
/* 3104 */     return getColumn(index);
/*      */   }
/*      */ 
/*      */   
/*      */   private void updateValue(int columnIndex, JDBCType jdbcType, Object value, JavaType javaType, boolean forceEncrypt) throws SQLServerException {
/* 3109 */     updaterGetColumn(columnIndex).updateValue(jdbcType, value, javaType, null, null, null, this.stmt.connection, this.stmt.stmtColumnEncriptionSetting, null, forceEncrypt, columnIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void updateValue(int columnIndex, JDBCType jdbcType, Object value, JavaType javaType, Calendar cal, boolean forceEncrypt) throws SQLServerException {
/* 3115 */     updaterGetColumn(columnIndex).updateValue(jdbcType, value, javaType, null, cal, null, this.stmt.connection, this.stmt.stmtColumnEncriptionSetting, null, forceEncrypt, columnIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void updateValue(int columnIndex, JDBCType jdbcType, Object value, JavaType javaType, Integer precision, Integer scale, boolean forceEncrypt) throws SQLServerException {
/* 3121 */     updaterGetColumn(columnIndex).updateValue(jdbcType, value, javaType, null, null, scale, this.stmt.connection, this.stmt.stmtColumnEncriptionSetting, precision, forceEncrypt, columnIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void updateStream(int columnIndex, StreamType streamType, Object value, JavaType javaType, long length) throws SQLServerException {
/* 3127 */     updaterGetColumn(columnIndex).updateValue(streamType.getJDBCType(), value, javaType, new StreamSetterArgs(streamType, length), null, null, this.stmt.connection, this.stmt.stmtColumnEncriptionSetting, null, false, columnIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void updateSQLXMLInternal(int columnIndex, SQLXML value) throws SQLServerException {
/* 3133 */     updaterGetColumn(columnIndex).updateValue(JDBCType.SQLXML, value, JavaType.SQLXML, new StreamSetterArgs(StreamType.SQLXML, -1L), null, null, this.stmt.connection, this.stmt.stmtColumnEncriptionSetting, null, false, columnIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateNull(int index) throws SQLServerException {
/* 3140 */     loggerExternal.entering(getClassNameLogging(), "updateNull", Integer.valueOf(index));
/*      */     
/* 3142 */     checkClosed();
/* 3143 */     updateValue(index, updaterGetColumn(index).getTypeInfo().getSSType().getJDBCType(), null, JavaType.OBJECT, false);
/*      */ 
/*      */     
/* 3146 */     loggerExternal.exiting(getClassNameLogging(), "updateNull");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateBoolean(int index, boolean x) throws SQLException {
/* 3151 */     if (loggerExternal.isLoggable(Level.FINER))
/* 3152 */       loggerExternal.entering(getClassNameLogging(), "updateBoolean", new Object[] { Integer.valueOf(index), Boolean.valueOf(x) }); 
/* 3153 */     checkClosed();
/* 3154 */     updateValue(index, JDBCType.BIT, Boolean.valueOf(x), JavaType.BOOLEAN, false);
/*      */     
/* 3156 */     loggerExternal.exiting(getClassNameLogging(), "updateBoolean");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateBoolean(int index, boolean x, boolean forceEncrypt) throws SQLServerException {
/* 3161 */     if (loggerExternal.isLoggable(Level.FINER))
/* 3162 */       loggerExternal.entering(getClassNameLogging(), "updateBoolean", new Object[] { Integer.valueOf(index), Boolean.valueOf(x), Boolean.valueOf(forceEncrypt) }); 
/* 3163 */     checkClosed();
/* 3164 */     updateValue(index, JDBCType.BIT, Boolean.valueOf(x), JavaType.BOOLEAN, forceEncrypt);
/*      */     
/* 3166 */     loggerExternal.exiting(getClassNameLogging(), "updateBoolean");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateByte(int index, byte x) throws SQLException {
/* 3171 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3172 */       loggerExternal.entering(getClassNameLogging(), "updateByte", new Object[] { Integer.valueOf(index), Byte.valueOf(x) });
/*      */     }
/* 3174 */     checkClosed();
/* 3175 */     updateValue(index, JDBCType.TINYINT, Byte.valueOf(x), JavaType.BYTE, false);
/*      */     
/* 3177 */     loggerExternal.exiting(getClassNameLogging(), "updateByte");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateByte(int index, byte x, boolean forceEncrypt) throws SQLServerException {
/* 3182 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3183 */       loggerExternal.entering(getClassNameLogging(), "updateByte", new Object[] { Integer.valueOf(index), Byte.valueOf(x), Boolean.valueOf(forceEncrypt) });
/*      */     }
/* 3185 */     checkClosed();
/* 3186 */     updateValue(index, JDBCType.TINYINT, Byte.valueOf(x), JavaType.BYTE, forceEncrypt);
/*      */     
/* 3188 */     loggerExternal.exiting(getClassNameLogging(), "updateByte");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateShort(int index, short x) throws SQLException {
/* 3193 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3194 */       loggerExternal.entering(getClassNameLogging(), "updateShort", new Object[] { Integer.valueOf(index), Short.valueOf(x) });
/*      */     }
/* 3196 */     checkClosed();
/* 3197 */     updateValue(index, JDBCType.SMALLINT, Short.valueOf(x), JavaType.SHORT, false);
/*      */     
/* 3199 */     loggerExternal.exiting(getClassNameLogging(), "updateShort");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateShort(int index, short x, boolean forceEncrypt) throws SQLServerException {
/* 3204 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3205 */       loggerExternal.entering(getClassNameLogging(), "updateShort", new Object[] { Integer.valueOf(index), Short.valueOf(x), Boolean.valueOf(forceEncrypt) });
/*      */     }
/* 3207 */     checkClosed();
/* 3208 */     updateValue(index, JDBCType.SMALLINT, Short.valueOf(x), JavaType.SHORT, forceEncrypt);
/*      */     
/* 3210 */     loggerExternal.exiting(getClassNameLogging(), "updateShort");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateInt(int index, int x) throws SQLException {
/* 3215 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3216 */       loggerExternal.entering(getClassNameLogging(), "updateInt", new Object[] { Integer.valueOf(index), Integer.valueOf(x) });
/*      */     }
/* 3218 */     checkClosed();
/* 3219 */     updateValue(index, JDBCType.INTEGER, Integer.valueOf(x), JavaType.INTEGER, false);
/*      */     
/* 3221 */     loggerExternal.exiting(getClassNameLogging(), "updateInt");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateInt(int index, int x, boolean forceEncrypt) throws SQLServerException {
/* 3226 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3227 */       loggerExternal.entering(getClassNameLogging(), "updateInt", new Object[] { Integer.valueOf(index), Integer.valueOf(x), Boolean.valueOf(forceEncrypt) });
/*      */     }
/* 3229 */     checkClosed();
/* 3230 */     updateValue(index, JDBCType.INTEGER, Integer.valueOf(x), JavaType.INTEGER, forceEncrypt);
/*      */     
/* 3232 */     loggerExternal.exiting(getClassNameLogging(), "updateInt");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateLong(int index, long x) throws SQLException {
/* 3237 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3238 */       loggerExternal.entering(getClassNameLogging(), "updateLong", new Object[] { Integer.valueOf(index), Long.valueOf(x) });
/*      */     }
/* 3240 */     checkClosed();
/* 3241 */     updateValue(index, JDBCType.BIGINT, Long.valueOf(x), JavaType.LONG, false);
/*      */     
/* 3243 */     loggerExternal.exiting(getClassNameLogging(), "updateLong");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateLong(int index, long x, boolean forceEncrypt) throws SQLServerException {
/* 3248 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3249 */       loggerExternal.entering(getClassNameLogging(), "updateLong", new Object[] { Integer.valueOf(index), Long.valueOf(x), Boolean.valueOf(forceEncrypt) });
/*      */     }
/* 3251 */     checkClosed();
/* 3252 */     updateValue(index, JDBCType.BIGINT, Long.valueOf(x), JavaType.LONG, forceEncrypt);
/*      */     
/* 3254 */     loggerExternal.exiting(getClassNameLogging(), "updateLong");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateFloat(int index, float x) throws SQLException {
/* 3259 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3260 */       loggerExternal.entering(getClassNameLogging(), "updateFloat", new Object[] { Integer.valueOf(index), Float.valueOf(x) });
/*      */     }
/* 3262 */     checkClosed();
/* 3263 */     updateValue(index, JDBCType.REAL, Float.valueOf(x), JavaType.FLOAT, false);
/*      */     
/* 3265 */     loggerExternal.exiting(getClassNameLogging(), "updateFloat");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateFloat(int index, float x, boolean forceEncrypt) throws SQLServerException {
/* 3270 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3271 */       loggerExternal.entering(getClassNameLogging(), "updateFloat", new Object[] { Integer.valueOf(index), Float.valueOf(x), Boolean.valueOf(forceEncrypt) });
/*      */     }
/* 3273 */     checkClosed();
/* 3274 */     updateValue(index, JDBCType.REAL, Float.valueOf(x), JavaType.FLOAT, forceEncrypt);
/*      */     
/* 3276 */     loggerExternal.exiting(getClassNameLogging(), "updateFloat");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateDouble(int index, double x) throws SQLException {
/* 3281 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3282 */       loggerExternal.entering(getClassNameLogging(), "updateDouble", new Object[] { Integer.valueOf(index), Double.valueOf(x) });
/*      */     }
/* 3284 */     checkClosed();
/* 3285 */     updateValue(index, JDBCType.DOUBLE, Double.valueOf(x), JavaType.DOUBLE, false);
/*      */     
/* 3287 */     loggerExternal.exiting(getClassNameLogging(), "updateDouble");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateDouble(int index, double x, boolean forceEncrypt) throws SQLServerException {
/* 3292 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3293 */       loggerExternal.entering(getClassNameLogging(), "updateDouble", new Object[] { Integer.valueOf(index), Double.valueOf(x), Boolean.valueOf(forceEncrypt) });
/*      */     }
/* 3295 */     checkClosed();
/* 3296 */     updateValue(index, JDBCType.DOUBLE, Double.valueOf(x), JavaType.DOUBLE, forceEncrypt);
/*      */     
/* 3298 */     loggerExternal.exiting(getClassNameLogging(), "updateDouble");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateMoney(int index, BigDecimal x) throws SQLServerException {
/* 3303 */     if (loggerExternal.isLoggable(Level.FINER))
/* 3304 */       loggerExternal.entering(getClassNameLogging(), "updateMoney", new Object[] { Integer.valueOf(index), x }); 
/* 3305 */     checkClosed();
/* 3306 */     updateValue(index, JDBCType.MONEY, x, JavaType.BIGDECIMAL, false);
/*      */     
/* 3308 */     loggerExternal.exiting(getClassNameLogging(), "updateMoney");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateMoney(int index, BigDecimal x, boolean forceEncrypt) throws SQLServerException {
/* 3313 */     if (loggerExternal.isLoggable(Level.FINER))
/* 3314 */       loggerExternal.entering(getClassNameLogging(), "updateMoney", new Object[] { Integer.valueOf(index), x, Boolean.valueOf(forceEncrypt) }); 
/* 3315 */     checkClosed();
/* 3316 */     updateValue(index, JDBCType.MONEY, x, JavaType.BIGDECIMAL, forceEncrypt);
/*      */     
/* 3318 */     loggerExternal.exiting(getClassNameLogging(), "updateMoney");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateMoney(String columnName, BigDecimal x) throws SQLServerException {
/* 3323 */     if (loggerExternal.isLoggable(Level.FINER))
/* 3324 */       loggerExternal.entering(getClassNameLogging(), "updateMoney", new Object[] { columnName, x }); 
/* 3325 */     checkClosed();
/* 3326 */     updateValue(findColumn(columnName), JDBCType.MONEY, x, JavaType.BIGDECIMAL, false);
/*      */     
/* 3328 */     loggerExternal.exiting(getClassNameLogging(), "updateMoney");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateMoney(String columnName, BigDecimal x, boolean forceEncrypt) throws SQLServerException {
/* 3333 */     if (loggerExternal.isLoggable(Level.FINER))
/* 3334 */       loggerExternal.entering(getClassNameLogging(), "updateMoney", new Object[] { columnName, x, Boolean.valueOf(forceEncrypt) }); 
/* 3335 */     checkClosed();
/* 3336 */     updateValue(findColumn(columnName), JDBCType.MONEY, x, JavaType.BIGDECIMAL, forceEncrypt);
/*      */     
/* 3338 */     loggerExternal.exiting(getClassNameLogging(), "updateMoney");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateSmallMoney(int index, BigDecimal x) throws SQLServerException {
/* 3343 */     if (loggerExternal.isLoggable(Level.FINER))
/* 3344 */       loggerExternal.entering(getClassNameLogging(), "updateSmallMoney", new Object[] { Integer.valueOf(index), x }); 
/* 3345 */     checkClosed();
/* 3346 */     updateValue(index, JDBCType.SMALLMONEY, x, JavaType.BIGDECIMAL, false);
/*      */     
/* 3348 */     loggerExternal.exiting(getClassNameLogging(), "updateSmallMoney");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateSmallMoney(int index, BigDecimal x, boolean forceEncrypt) throws SQLServerException {
/* 3353 */     if (loggerExternal.isLoggable(Level.FINER))
/* 3354 */       loggerExternal.entering(getClassNameLogging(), "updateSmallMoney", new Object[] { Integer.valueOf(index), x, Boolean.valueOf(forceEncrypt) }); 
/* 3355 */     checkClosed();
/* 3356 */     updateValue(index, JDBCType.SMALLMONEY, x, JavaType.BIGDECIMAL, forceEncrypt);
/*      */     
/* 3358 */     loggerExternal.exiting(getClassNameLogging(), "updateSmallMoney");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateSmallMoney(String columnName, BigDecimal x) throws SQLServerException {
/* 3363 */     if (loggerExternal.isLoggable(Level.FINER))
/* 3364 */       loggerExternal.entering(getClassNameLogging(), "updateSmallMoney", new Object[] { columnName, x }); 
/* 3365 */     checkClosed();
/* 3366 */     updateValue(findColumn(columnName), JDBCType.SMALLMONEY, x, JavaType.BIGDECIMAL, false);
/*      */     
/* 3368 */     loggerExternal.exiting(getClassNameLogging(), "updateSmallMoney");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateSmallMoney(String columnName, BigDecimal x, boolean forceEncrypt) throws SQLServerException {
/* 3373 */     if (loggerExternal.isLoggable(Level.FINER))
/* 3374 */       loggerExternal.entering(getClassNameLogging(), "updateSmallMoney", new Object[] { columnName, x, 
/* 3375 */             Boolean.valueOf(forceEncrypt) }); 
/* 3376 */     checkClosed();
/* 3377 */     updateValue(findColumn(columnName), JDBCType.SMALLMONEY, x, JavaType.BIGDECIMAL, forceEncrypt);
/*      */     
/* 3379 */     loggerExternal.exiting(getClassNameLogging(), "updateSmallMoney");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateBigDecimal(int index, BigDecimal x) throws SQLServerException {
/* 3384 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3385 */       loggerExternal.entering(getClassNameLogging(), "updateBigDecimal", new Object[] { Integer.valueOf(index), x });
/*      */     }
/* 3387 */     checkClosed();
/* 3388 */     updateValue(index, JDBCType.DECIMAL, x, JavaType.BIGDECIMAL, false);
/*      */     
/* 3390 */     loggerExternal.exiting(getClassNameLogging(), "updateBigDecimal");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateBigDecimal(int index, BigDecimal x, Integer precision, Integer scale) throws SQLServerException {
/* 3395 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3396 */       loggerExternal.entering(getClassNameLogging(), "updateBigDecimal", new Object[] { Integer.valueOf(index), x, scale });
/*      */     }
/* 3398 */     checkClosed();
/* 3399 */     updateValue(index, JDBCType.DECIMAL, x, JavaType.BIGDECIMAL, precision, scale, false);
/*      */     
/* 3401 */     loggerExternal.exiting(getClassNameLogging(), "updateBigDecimal");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBigDecimal(int index, BigDecimal x, Integer precision, Integer scale, boolean forceEncrypt) throws SQLServerException {
/* 3407 */     if (loggerExternal.isLoggable(Level.FINER))
/* 3408 */       loggerExternal.entering(getClassNameLogging(), "updateBigDecimal", new Object[] {
/* 3409 */             Integer.valueOf(index), x, scale, Boolean.valueOf(forceEncrypt)
/*      */           }); 
/* 3411 */     checkClosed();
/* 3412 */     updateValue(index, JDBCType.DECIMAL, x, JavaType.BIGDECIMAL, precision, scale, forceEncrypt);
/*      */     
/* 3414 */     loggerExternal.exiting(getClassNameLogging(), "updateBigDecimal");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateString(int columnIndex, String stringValue) throws SQLServerException {
/* 3419 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3420 */       loggerExternal.entering(getClassNameLogging(), "updateString", new Object[] { Integer.valueOf(columnIndex), stringValue });
/*      */     }
/* 3422 */     checkClosed();
/* 3423 */     updateValue(columnIndex, JDBCType.VARCHAR, stringValue, JavaType.STRING, false);
/*      */     
/* 3425 */     loggerExternal.exiting(getClassNameLogging(), "updateString");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateString(int columnIndex, String stringValue, boolean forceEncrypt) throws SQLServerException {
/* 3430 */     if (loggerExternal.isLoggable(Level.FINER))
/* 3431 */       loggerExternal.entering(getClassNameLogging(), "updateString", new Object[] {
/* 3432 */             Integer.valueOf(columnIndex), stringValue, Boolean.valueOf(forceEncrypt)
/*      */           }); 
/* 3434 */     checkClosed();
/* 3435 */     updateValue(columnIndex, JDBCType.VARCHAR, stringValue, JavaType.STRING, forceEncrypt);
/*      */     
/* 3437 */     loggerExternal.exiting(getClassNameLogging(), "updateString");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateNString(int columnIndex, String nString) throws SQLException {
/* 3442 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3443 */       loggerExternal.entering(getClassNameLogging(), "updateNString", new Object[] { Integer.valueOf(columnIndex), nString });
/*      */     }
/* 3445 */     checkClosed();
/* 3446 */     updateValue(columnIndex, JDBCType.NVARCHAR, nString, JavaType.STRING, false);
/*      */     
/* 3448 */     loggerExternal.exiting(getClassNameLogging(), "updateNString");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateNString(int columnIndex, String nString, boolean forceEncrypt) throws SQLServerException {
/* 3453 */     if (loggerExternal.isLoggable(Level.FINER))
/* 3454 */       loggerExternal.entering(getClassNameLogging(), "updateNString", new Object[] {
/* 3455 */             Integer.valueOf(columnIndex), nString, Boolean.valueOf(forceEncrypt)
/*      */           }); 
/* 3457 */     checkClosed();
/* 3458 */     updateValue(columnIndex, JDBCType.NVARCHAR, nString, JavaType.STRING, forceEncrypt);
/*      */     
/* 3460 */     loggerExternal.exiting(getClassNameLogging(), "updateNString");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateNString(String columnLabel, String nString) throws SQLException {
/* 3465 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3466 */       loggerExternal.entering(getClassNameLogging(), "updateNString", new Object[] { columnLabel, nString });
/*      */     }
/* 3468 */     checkClosed();
/* 3469 */     updateValue(findColumn(columnLabel), JDBCType.NVARCHAR, nString, JavaType.STRING, false);
/*      */     
/* 3471 */     loggerExternal.exiting(getClassNameLogging(), "updateNString");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateNString(String columnLabel, String nString, boolean forceEncrypt) throws SQLServerException {
/* 3476 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3477 */       loggerExternal.entering(getClassNameLogging(), "updateNString", new Object[] { columnLabel, nString, 
/* 3478 */             Boolean.valueOf(forceEncrypt) });
/*      */     }
/* 3480 */     checkClosed();
/* 3481 */     updateValue(findColumn(columnLabel), JDBCType.NVARCHAR, nString, JavaType.STRING, forceEncrypt);
/*      */     
/* 3483 */     loggerExternal.exiting(getClassNameLogging(), "updateNString");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateBytes(int index, byte[] x) throws SQLException {
/* 3488 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3489 */       loggerExternal.entering(getClassNameLogging(), "updateBytes", new Object[] { Integer.valueOf(index), x });
/*      */     }
/* 3491 */     checkClosed();
/* 3492 */     updateValue(index, JDBCType.BINARY, x, JavaType.BYTEARRAY, false);
/*      */     
/* 3494 */     loggerExternal.exiting(getClassNameLogging(), "updateBytes");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateBytes(int index, byte[] x, boolean forceEncrypt) throws SQLServerException {
/* 3499 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3500 */       loggerExternal.entering(getClassNameLogging(), "updateBytes", new Object[] { Integer.valueOf(index), x, Boolean.valueOf(forceEncrypt) });
/*      */     }
/* 3502 */     checkClosed();
/* 3503 */     updateValue(index, JDBCType.BINARY, x, JavaType.BYTEARRAY, forceEncrypt);
/*      */     
/* 3505 */     loggerExternal.exiting(getClassNameLogging(), "updateBytes");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateDate(int index, Date x) throws SQLServerException {
/* 3510 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3511 */       loggerExternal.entering(getClassNameLogging(), "updateDate", new Object[] { Integer.valueOf(index), x });
/*      */     }
/* 3513 */     checkClosed();
/* 3514 */     updateValue(index, JDBCType.DATE, x, JavaType.DATE, false);
/*      */     
/* 3516 */     loggerExternal.exiting(getClassNameLogging(), "updateDate");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateDate(int index, Date x, boolean forceEncrypt) throws SQLServerException {
/* 3521 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3522 */       loggerExternal.entering(getClassNameLogging(), "updateDate", new Object[] { Integer.valueOf(index), x, Boolean.valueOf(forceEncrypt) });
/*      */     }
/* 3524 */     checkClosed();
/* 3525 */     updateValue(index, JDBCType.DATE, x, JavaType.DATE, forceEncrypt);
/*      */     
/* 3527 */     loggerExternal.exiting(getClassNameLogging(), "updateDate");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateTime(int index, Time x) throws SQLServerException {
/* 3532 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3533 */       loggerExternal.entering(getClassNameLogging(), "updateTime", new Object[] { Integer.valueOf(index), x });
/*      */     }
/* 3535 */     checkClosed();
/* 3536 */     updateValue(index, JDBCType.TIME, x, JavaType.TIME, false);
/*      */     
/* 3538 */     loggerExternal.exiting(getClassNameLogging(), "updateTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateTime(int index, Time x, Integer scale) throws SQLServerException {
/* 3543 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3544 */       loggerExternal.entering(getClassNameLogging(), "updateTime", new Object[] { Integer.valueOf(index), x, scale });
/*      */     }
/* 3546 */     checkClosed();
/* 3547 */     updateValue(index, JDBCType.TIME, x, JavaType.TIME, null, scale, false);
/*      */     
/* 3549 */     loggerExternal.exiting(getClassNameLogging(), "updateTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateTime(int index, Time x, Integer scale, boolean forceEncrypt) throws SQLServerException {
/* 3554 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3555 */       loggerExternal.entering(getClassNameLogging(), "updateTime", new Object[] { Integer.valueOf(index), x, scale, Boolean.valueOf(forceEncrypt) });
/*      */     }
/* 3557 */     checkClosed();
/* 3558 */     updateValue(index, JDBCType.TIME, x, JavaType.TIME, null, scale, forceEncrypt);
/*      */     
/* 3560 */     loggerExternal.exiting(getClassNameLogging(), "updateTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateTimestamp(int index, Timestamp x) throws SQLServerException {
/* 3565 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3566 */       loggerExternal.entering(getClassNameLogging(), "updateTimestamp", new Object[] { Integer.valueOf(index), x });
/*      */     }
/* 3568 */     checkClosed();
/* 3569 */     updateValue(index, JDBCType.TIMESTAMP, x, JavaType.TIMESTAMP, false);
/*      */     
/* 3571 */     loggerExternal.exiting(getClassNameLogging(), "updateTimestamp");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateTimestamp(int index, Timestamp x, int scale) throws SQLServerException {
/* 3576 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3577 */       loggerExternal.entering(getClassNameLogging(), "updateTimestamp", new Object[] { Integer.valueOf(index), x, Integer.valueOf(scale) });
/*      */     }
/* 3579 */     checkClosed();
/* 3580 */     updateValue(index, JDBCType.TIMESTAMP, x, JavaType.TIMESTAMP, null, Integer.valueOf(scale), false);
/*      */     
/* 3582 */     loggerExternal.exiting(getClassNameLogging(), "updateTimestamp");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateTimestamp(int index, Timestamp x, int scale, boolean forceEncrypt) throws SQLServerException {
/* 3588 */     if (loggerExternal.isLoggable(Level.FINER))
/* 3589 */       loggerExternal.entering(getClassNameLogging(), "updateTimestamp", new Object[] {
/* 3590 */             Integer.valueOf(index), x, Integer.valueOf(scale), Boolean.valueOf(forceEncrypt)
/*      */           }); 
/* 3592 */     checkClosed();
/* 3593 */     updateValue(index, JDBCType.TIMESTAMP, x, JavaType.TIMESTAMP, null, Integer.valueOf(scale), forceEncrypt);
/*      */     
/* 3595 */     loggerExternal.exiting(getClassNameLogging(), "updateTimestamp");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateDateTime(int index, Timestamp x) throws SQLServerException {
/* 3600 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3601 */       loggerExternal.entering(getClassNameLogging(), "updateDateTime", new Object[] { Integer.valueOf(index), x });
/*      */     }
/* 3603 */     checkClosed();
/* 3604 */     updateValue(index, JDBCType.DATETIME, x, JavaType.TIMESTAMP, false);
/*      */     
/* 3606 */     loggerExternal.exiting(getClassNameLogging(), "updateDateTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateDateTime(int index, Timestamp x, Integer scale) throws SQLServerException {
/* 3611 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3612 */       loggerExternal.entering(getClassNameLogging(), "updateDateTime", new Object[] { Integer.valueOf(index), x, scale });
/*      */     }
/* 3614 */     checkClosed();
/* 3615 */     updateValue(index, JDBCType.DATETIME, x, JavaType.TIMESTAMP, null, scale, false);
/*      */     
/* 3617 */     loggerExternal.exiting(getClassNameLogging(), "updateDateTime");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateDateTime(int index, Timestamp x, Integer scale, boolean forceEncrypt) throws SQLServerException {
/* 3623 */     if (loggerExternal.isLoggable(Level.FINER))
/* 3624 */       loggerExternal.entering(getClassNameLogging(), "updateDateTime", new Object[] {
/* 3625 */             Integer.valueOf(index), x, scale, Boolean.valueOf(forceEncrypt)
/*      */           }); 
/* 3627 */     checkClosed();
/* 3628 */     updateValue(index, JDBCType.DATETIME, x, JavaType.TIMESTAMP, null, scale, forceEncrypt);
/*      */     
/* 3630 */     loggerExternal.exiting(getClassNameLogging(), "updateDateTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateSmallDateTime(int index, Timestamp x) throws SQLServerException {
/* 3635 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3636 */       loggerExternal.entering(getClassNameLogging(), "updateSmallDateTime", new Object[] { Integer.valueOf(index), x });
/*      */     }
/* 3638 */     checkClosed();
/* 3639 */     updateValue(index, JDBCType.SMALLDATETIME, x, JavaType.TIMESTAMP, false);
/*      */     
/* 3641 */     loggerExternal.exiting(getClassNameLogging(), "updateSmallDateTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateSmallDateTime(int index, Timestamp x, Integer scale) throws SQLServerException {
/* 3646 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3647 */       loggerExternal.entering(getClassNameLogging(), "updateSmallDateTime", new Object[] { Integer.valueOf(index), x, scale });
/*      */     }
/* 3649 */     checkClosed();
/* 3650 */     updateValue(index, JDBCType.SMALLDATETIME, x, JavaType.TIMESTAMP, null, scale, false);
/*      */     
/* 3652 */     loggerExternal.exiting(getClassNameLogging(), "updateSmallDateTime");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateSmallDateTime(int index, Timestamp x, Integer scale, boolean forceEncrypt) throws SQLServerException {
/* 3658 */     if (loggerExternal.isLoggable(Level.FINER))
/* 3659 */       loggerExternal.entering(getClassNameLogging(), "updateSmallDateTime", new Object[] {
/* 3660 */             Integer.valueOf(index), x, scale, Boolean.valueOf(forceEncrypt)
/*      */           }); 
/* 3662 */     checkClosed();
/* 3663 */     updateValue(index, JDBCType.SMALLDATETIME, x, JavaType.TIMESTAMP, null, scale, forceEncrypt);
/*      */     
/* 3665 */     loggerExternal.exiting(getClassNameLogging(), "updateSmallDateTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateDateTimeOffset(int index, DateTimeOffset x) throws SQLServerException {
/* 3670 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3671 */       loggerExternal.entering(getClassNameLogging(), "updateDateTimeOffset", new Object[] { Integer.valueOf(index), x });
/*      */     }
/* 3673 */     checkClosed();
/* 3674 */     updateValue(index, JDBCType.DATETIMEOFFSET, x, JavaType.DATETIMEOFFSET, false);
/*      */     
/* 3676 */     loggerExternal.exiting(getClassNameLogging(), "updateDateTimeOffset");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateDateTimeOffset(int index, DateTimeOffset x, Integer scale) throws SQLServerException {
/* 3682 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3683 */       loggerExternal.entering(getClassNameLogging(), "updateDateTimeOffset", new Object[] { Integer.valueOf(index), x, scale });
/*      */     }
/* 3685 */     checkClosed();
/* 3686 */     updateValue(index, JDBCType.DATETIMEOFFSET, x, JavaType.DATETIMEOFFSET, null, scale, false);
/*      */     
/* 3688 */     loggerExternal.exiting(getClassNameLogging(), "updateDateTimeOffset");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateDateTimeOffset(int index, DateTimeOffset x, Integer scale, boolean forceEncrypt) throws SQLServerException {
/* 3694 */     if (loggerExternal.isLoggable(Level.FINER))
/* 3695 */       loggerExternal.entering(getClassNameLogging(), "updateDateTimeOffset", new Object[] {
/* 3696 */             Integer.valueOf(index), x, scale, Boolean.valueOf(forceEncrypt)
/*      */           }); 
/* 3698 */     checkClosed();
/* 3699 */     updateValue(index, JDBCType.DATETIMEOFFSET, x, JavaType.DATETIMEOFFSET, null, scale, forceEncrypt);
/*      */     
/* 3701 */     loggerExternal.exiting(getClassNameLogging(), "updateDateTimeOffset");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateUniqueIdentifier(int index, String x) throws SQLServerException {
/* 3706 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3707 */       loggerExternal.entering(getClassNameLogging(), "updateUniqueIdentifier", new Object[] { Integer.valueOf(index), x });
/*      */     }
/* 3709 */     checkClosed();
/* 3710 */     updateValue(index, JDBCType.GUID, x, JavaType.STRING, null, false);
/*      */     
/* 3712 */     loggerExternal.exiting(getClassNameLogging(), "updateUniqueIdentifier");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateUniqueIdentifier(int index, String x, boolean forceEncrypt) throws SQLServerException {
/* 3717 */     if (loggerExternal.isLoggable(Level.FINER))
/* 3718 */       loggerExternal.entering(getClassNameLogging(), "updateUniqueIdentifier", new Object[] {
/* 3719 */             Integer.valueOf(index), x, Boolean.valueOf(forceEncrypt)
/*      */           }); 
/* 3721 */     checkClosed();
/* 3722 */     updateValue(index, JDBCType.GUID, x, JavaType.STRING, null, forceEncrypt);
/*      */     
/* 3724 */     loggerExternal.exiting(getClassNameLogging(), "updateUniqueIdentifier");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateAsciiStream(int columnIndex, InputStream x) throws SQLException {
/* 3729 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3730 */       loggerExternal.entering(getClassNameLogging(), "updateAsciiStream", new Object[] { Integer.valueOf(columnIndex), x });
/*      */     }
/* 3732 */     checkClosed();
/* 3733 */     updateStream(columnIndex, StreamType.ASCII, x, JavaType.INPUTSTREAM, -1L);
/*      */     
/* 3735 */     loggerExternal.exiting(getClassNameLogging(), "updateAsciiStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateAsciiStream(int index, InputStream x, int length) throws SQLServerException {
/* 3740 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3741 */       loggerExternal.entering(getClassNameLogging(), "updateAsciiStream", new Object[] { Integer.valueOf(index), x, Integer.valueOf(length) });
/*      */     }
/* 3743 */     checkClosed();
/* 3744 */     updateStream(index, StreamType.ASCII, x, JavaType.INPUTSTREAM, length);
/*      */     
/* 3746 */     loggerExternal.exiting(getClassNameLogging(), "updateAsciiStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateAsciiStream(int columnIndex, InputStream x, long length) throws SQLException {
/* 3751 */     loggerExternal.entering(getClassNameLogging(), "updateAsciiStream", new Object[] { Integer.valueOf(columnIndex), x, Long.valueOf(length) });
/*      */     
/* 3753 */     checkClosed();
/* 3754 */     updateStream(columnIndex, StreamType.ASCII, x, JavaType.INPUTSTREAM, length);
/*      */     
/* 3756 */     loggerExternal.exiting(getClassNameLogging(), "updateAsciiStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateAsciiStream(String columnLabel, InputStream x) throws SQLException {
/* 3761 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3762 */       loggerExternal.entering(getClassNameLogging(), "updateAsciiStream", new Object[] { columnLabel, x });
/*      */     }
/* 3764 */     checkClosed();
/* 3765 */     updateStream(findColumn(columnLabel), StreamType.ASCII, x, JavaType.INPUTSTREAM, -1L);
/*      */ 
/*      */     
/* 3768 */     loggerExternal.exiting(getClassNameLogging(), "updateAsciiStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateAsciiStream(String columnName, InputStream x, int length) throws SQLServerException {
/* 3773 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3774 */       loggerExternal.entering(getClassNameLogging(), "updateAsciiStream", new Object[] { columnName, x, Integer.valueOf(length) });
/*      */     }
/* 3776 */     checkClosed();
/* 3777 */     updateStream(findColumn(columnName), StreamType.ASCII, x, JavaType.INPUTSTREAM, length);
/*      */     
/* 3779 */     loggerExternal.exiting(getClassNameLogging(), "updateAsciiStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateAsciiStream(String columnName, InputStream streamValue, long length) throws SQLException {
/* 3784 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3785 */       loggerExternal.entering(getClassNameLogging(), "updateAsciiStream", new Object[] { columnName, streamValue, 
/* 3786 */             Long.valueOf(length) });
/*      */     }
/* 3788 */     checkClosed();
/* 3789 */     updateStream(findColumn(columnName), StreamType.ASCII, streamValue, JavaType.INPUTSTREAM, length);
/*      */     
/* 3791 */     loggerExternal.exiting(getClassNameLogging(), "updateAsciiStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateBinaryStream(int columnIndex, InputStream x) throws SQLException {
/* 3796 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3797 */       loggerExternal.entering(getClassNameLogging(), "updateBinaryStream", new Object[] { Integer.valueOf(columnIndex), x });
/*      */     }
/* 3799 */     checkClosed();
/* 3800 */     updateStream(columnIndex, StreamType.BINARY, x, JavaType.INPUTSTREAM, -1L);
/*      */     
/* 3802 */     loggerExternal.exiting(getClassNameLogging(), "updateBinaryStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateBinaryStream(int columnIndex, InputStream streamValue, int length) throws SQLException {
/* 3807 */     if (loggerExternal.isLoggable(Level.FINER))
/* 3808 */       loggerExternal.entering(getClassNameLogging(), "updateBinaryStream", new Object[] {
/* 3809 */             Integer.valueOf(columnIndex), streamValue, Integer.valueOf(length)
/*      */           }); 
/* 3811 */     checkClosed();
/* 3812 */     updateStream(columnIndex, StreamType.BINARY, streamValue, JavaType.INPUTSTREAM, length);
/*      */     
/* 3814 */     loggerExternal.exiting(getClassNameLogging(), "updateBinaryStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateBinaryStream(int columnIndex, InputStream x, long length) throws SQLException {
/* 3819 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3820 */       loggerExternal.entering(getClassNameLogging(), "updateBinaryStream", new Object[] { Integer.valueOf(columnIndex), x, Long.valueOf(length) });
/*      */     }
/* 3822 */     checkClosed();
/* 3823 */     updateStream(columnIndex, StreamType.BINARY, x, JavaType.INPUTSTREAM, length);
/*      */     
/* 3825 */     loggerExternal.exiting(getClassNameLogging(), "updateBinaryStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateBinaryStream(String columnLabel, InputStream x) throws SQLException {
/* 3830 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3831 */       loggerExternal.entering(getClassNameLogging(), "updateBinaryStream", new Object[] { columnLabel, x });
/*      */     }
/* 3833 */     checkClosed();
/* 3834 */     updateStream(findColumn(columnLabel), StreamType.BINARY, x, JavaType.INPUTSTREAM, -1L);
/*      */ 
/*      */     
/* 3837 */     loggerExternal.exiting(getClassNameLogging(), "updateBinaryStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateBinaryStream(String columnName, InputStream streamValue, int length) throws SQLException {
/* 3842 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3843 */       loggerExternal.entering(getClassNameLogging(), "updateBinaryStream", new Object[] { columnName, streamValue, 
/* 3844 */             Integer.valueOf(length) });
/*      */     }
/* 3846 */     checkClosed();
/* 3847 */     updateStream(findColumn(columnName), StreamType.BINARY, streamValue, JavaType.INPUTSTREAM, length);
/*      */     
/* 3849 */     loggerExternal.exiting(getClassNameLogging(), "updateBinaryStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateBinaryStream(String columnLabel, InputStream x, long length) throws SQLException {
/* 3854 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3855 */       loggerExternal.entering(getClassNameLogging(), "updateBinaryStream", new Object[] { columnLabel, x, Long.valueOf(length) });
/*      */     }
/* 3857 */     checkClosed();
/* 3858 */     updateStream(findColumn(columnLabel), StreamType.BINARY, x, JavaType.INPUTSTREAM, length);
/*      */     
/* 3860 */     loggerExternal.exiting(getClassNameLogging(), "updateBinaryStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateCharacterStream(int columnIndex, Reader x) throws SQLException {
/* 3865 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3866 */       loggerExternal.entering(getClassNameLogging(), "updateCharacterStream", new Object[] { Integer.valueOf(columnIndex), x });
/*      */     }
/* 3868 */     checkClosed();
/* 3869 */     updateStream(columnIndex, StreamType.CHARACTER, x, JavaType.READER, -1L);
/*      */     
/* 3871 */     loggerExternal.exiting(getClassNameLogging(), "updateCharacterStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateCharacterStream(int columnIndex, Reader readerValue, int length) throws SQLServerException {
/* 3876 */     if (loggerExternal.isLoggable(Level.FINER))
/* 3877 */       loggerExternal.entering(getClassNameLogging(), "updateCharacterStream", new Object[] {
/* 3878 */             Integer.valueOf(columnIndex), readerValue, Integer.valueOf(length)
/*      */           }); 
/* 3880 */     checkClosed();
/* 3881 */     updateStream(columnIndex, StreamType.CHARACTER, readerValue, JavaType.READER, length);
/*      */     
/* 3883 */     loggerExternal.exiting(getClassNameLogging(), "updateCharacterStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateCharacterStream(int columnIndex, Reader x, long length) throws SQLException {
/* 3888 */     if (loggerExternal.isLoggable(Level.FINER))
/* 3889 */       loggerExternal.entering(getClassNameLogging(), "updateCharacterStream", new Object[] {
/* 3890 */             Integer.valueOf(columnIndex), x, Long.valueOf(length)
/*      */           }); 
/* 3892 */     checkClosed();
/* 3893 */     updateStream(columnIndex, StreamType.CHARACTER, x, JavaType.READER, length);
/*      */     
/* 3895 */     loggerExternal.exiting(getClassNameLogging(), "updateCharacterStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateCharacterStream(String columnLabel, Reader reader) throws SQLException {
/* 3900 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3901 */       loggerExternal.entering(getClassNameLogging(), "updateCharacterStream", new Object[] { columnLabel, reader });
/*      */     }
/* 3903 */     checkClosed();
/* 3904 */     updateStream(findColumn(columnLabel), StreamType.CHARACTER, reader, JavaType.READER, -1L);
/*      */ 
/*      */     
/* 3907 */     loggerExternal.exiting(getClassNameLogging(), "updateCharacterStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateCharacterStream(String columnName, Reader readerValue, int length) throws SQLServerException {
/* 3912 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3913 */       loggerExternal.entering(getClassNameLogging(), "updateCharacterStream", new Object[] { columnName, readerValue, 
/* 3914 */             Integer.valueOf(length) });
/*      */     }
/* 3916 */     checkClosed();
/* 3917 */     updateStream(findColumn(columnName), StreamType.CHARACTER, readerValue, JavaType.READER, length);
/*      */     
/* 3919 */     loggerExternal.exiting(getClassNameLogging(), "updateCharacterStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateCharacterStream(String columnLabel, Reader reader, long length) throws SQLException {
/* 3924 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3925 */       loggerExternal.entering(getClassNameLogging(), "updateCharacterStream", new Object[] { columnLabel, reader, 
/* 3926 */             Long.valueOf(length) });
/*      */     }
/* 3928 */     checkClosed();
/* 3929 */     updateStream(findColumn(columnLabel), StreamType.CHARACTER, reader, JavaType.READER, length);
/*      */     
/* 3931 */     loggerExternal.exiting(getClassNameLogging(), "updateNCharacterStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateNCharacterStream(int columnIndex, Reader x) throws SQLException {
/* 3936 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3937 */       loggerExternal.entering(getClassNameLogging(), "updateNCharacterStream", new Object[] { Integer.valueOf(columnIndex), x });
/*      */     }
/* 3939 */     checkClosed();
/* 3940 */     updateStream(columnIndex, StreamType.NCHARACTER, x, JavaType.READER, -1L);
/*      */     
/* 3942 */     loggerExternal.exiting(getClassNameLogging(), "updateNCharacterStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateNCharacterStream(int columnIndex, Reader x, long length) throws SQLException {
/* 3947 */     if (loggerExternal.isLoggable(Level.FINER))
/* 3948 */       loggerExternal.entering(getClassNameLogging(), "updateNCharacterStream", new Object[] {
/* 3949 */             Integer.valueOf(columnIndex), x, Long.valueOf(length)
/*      */           }); 
/* 3951 */     checkClosed();
/* 3952 */     updateStream(columnIndex, StreamType.NCHARACTER, x, JavaType.READER, length);
/*      */     
/* 3954 */     loggerExternal.exiting(getClassNameLogging(), "updateNCharacterStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateNCharacterStream(String columnLabel, Reader reader) throws SQLException {
/* 3959 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3960 */       loggerExternal.entering(getClassNameLogging(), "updateNCharacterStream", new Object[] { columnLabel, reader });
/*      */     }
/*      */     
/* 3963 */     checkClosed();
/* 3964 */     updateStream(findColumn(columnLabel), StreamType.NCHARACTER, reader, JavaType.READER, -1L);
/*      */ 
/*      */     
/* 3967 */     loggerExternal.exiting(getClassNameLogging(), "updateNCharacterStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateNCharacterStream(String columnLabel, Reader reader, long length) throws SQLException {
/* 3972 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3973 */       loggerExternal.entering(getClassNameLogging(), "updateNCharacterStream", new Object[] { columnLabel, reader, 
/* 3974 */             Long.valueOf(length) });
/*      */     }
/* 3976 */     checkClosed();
/* 3977 */     updateStream(findColumn(columnLabel), StreamType.NCHARACTER, reader, JavaType.READER, length);
/*      */     
/* 3979 */     loggerExternal.exiting(getClassNameLogging(), "updateNCharacterStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateObject(int index, Object obj) throws SQLServerException {
/* 3984 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3985 */       loggerExternal.entering(getClassNameLogging(), "updateObject", new Object[] { Integer.valueOf(index), obj });
/*      */     }
/* 3987 */     checkClosed();
/* 3988 */     updateObject(index, obj, null, null, null, false);
/*      */     
/* 3990 */     loggerExternal.exiting(getClassNameLogging(), "updateObject");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateObject(int index, Object x, int scale) throws SQLServerException {
/* 3995 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3996 */       loggerExternal.entering(getClassNameLogging(), "updateObject", new Object[] { Integer.valueOf(index), x, Integer.valueOf(scale) });
/*      */     }
/* 3998 */     checkClosed();
/* 3999 */     updateObject(index, x, Integer.valueOf(scale), null, null, false);
/*      */     
/* 4001 */     loggerExternal.exiting(getClassNameLogging(), "updateObject");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateObject(int index, Object x, int precision, int scale) throws SQLServerException {
/* 4006 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4007 */       loggerExternal.entering(getClassNameLogging(), "updateObject", new Object[] { Integer.valueOf(index), x, Integer.valueOf(scale) });
/*      */     }
/* 4009 */     checkClosed();
/* 4010 */     updateObject(index, x, Integer.valueOf(scale), null, Integer.valueOf(precision), false);
/*      */     
/* 4012 */     loggerExternal.exiting(getClassNameLogging(), "updateObject");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateObject(int index, Object x, int precision, int scale, boolean forceEncrypt) throws SQLServerException {
/* 4018 */     if (loggerExternal.isLoggable(Level.FINER))
/* 4019 */       loggerExternal.entering(getClassNameLogging(), "updateObject", new Object[] {
/* 4020 */             Integer.valueOf(index), x, Integer.valueOf(scale), Boolean.valueOf(forceEncrypt)
/*      */           }); 
/* 4022 */     checkClosed();
/* 4023 */     updateObject(index, x, Integer.valueOf(scale), null, Integer.valueOf(precision), forceEncrypt);
/*      */     
/* 4025 */     loggerExternal.exiting(getClassNameLogging(), "updateObject");
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void updateObject(int index, Object x, Integer scale, JDBCType jdbcType, Integer precision, boolean forceEncrypt) throws SQLServerException {
/* 4030 */     Column column = updaterGetColumn(index);
/* 4031 */     SSType ssType = column.getTypeInfo().getSSType();
/*      */     
/* 4033 */     if (null == x) {
/* 4034 */       if (null == jdbcType || jdbcType.isUnsupported())
/*      */       {
/* 4036 */         jdbcType = ssType.getJDBCType();
/*      */       }
/*      */       
/* 4039 */       column.updateValue(jdbcType, x, JavaType.OBJECT, null, null, scale, this.stmt.connection, this.stmt.stmtColumnEncriptionSetting, precision, forceEncrypt, index);
/*      */     } else {
/*      */       
/* 4042 */       JavaType javaType = JavaType.of(x);
/* 4043 */       JDBCType objectJdbcType = javaType.getJDBCType(ssType, ssType.getJDBCType());
/*      */       
/* 4045 */       if (null == jdbcType) {
/*      */         
/* 4047 */         jdbcType = objectJdbcType;
/*      */       
/*      */       }
/* 4050 */       else if (!objectJdbcType.convertsTo(jdbcType)) {
/* 4051 */         DataTypes.throwConversionError(objectJdbcType.toString(), jdbcType.toString());
/*      */       } 
/*      */       
/* 4054 */       StreamSetterArgs streamSetterArgs = null;
/* 4055 */       switch (javaType) {
/*      */         case READER:
/* 4057 */           streamSetterArgs = new StreamSetterArgs(StreamType.CHARACTER, -1L);
/*      */           break;
/*      */ 
/*      */         
/*      */         case INPUTSTREAM:
/* 4062 */           streamSetterArgs = new StreamSetterArgs(jdbcType.isTextual() ? StreamType.CHARACTER : StreamType.BINARY, -1L);
/*      */           break;
/*      */ 
/*      */         
/*      */         case SQLXML:
/* 4067 */           streamSetterArgs = new StreamSetterArgs(StreamType.SQLXML, -1L);
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4075 */       column.updateValue(jdbcType, x, javaType, streamSetterArgs, null, scale, this.stmt.connection, this.stmt.stmtColumnEncriptionSetting, precision, forceEncrypt, index);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateNull(String columnName) throws SQLServerException {
/* 4082 */     loggerExternal.entering(getClassNameLogging(), "updateNull", columnName);
/*      */     
/* 4084 */     checkClosed();
/* 4085 */     int columnIndex = findColumn(columnName);
/* 4086 */     updateValue(columnIndex, updaterGetColumn(columnIndex).getTypeInfo().getSSType().getJDBCType(), null, JavaType.OBJECT, false);
/*      */ 
/*      */     
/* 4089 */     loggerExternal.exiting(getClassNameLogging(), "updateNull");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateBoolean(String columnName, boolean x) throws SQLServerException {
/* 4094 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4095 */       loggerExternal.entering(getClassNameLogging(), "updateBoolean", new Object[] { columnName, Boolean.valueOf(x) });
/*      */     }
/* 4097 */     checkClosed();
/* 4098 */     updateValue(findColumn(columnName), JDBCType.BIT, Boolean.valueOf(x), JavaType.BOOLEAN, false);
/*      */     
/* 4100 */     loggerExternal.exiting(getClassNameLogging(), "updateBoolean");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateBoolean(String columnName, boolean x, boolean forceEncrypt) throws SQLServerException {
/* 4105 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4106 */       loggerExternal.entering(getClassNameLogging(), "updateBoolean", new Object[] { columnName, Boolean.valueOf(x), Boolean.valueOf(forceEncrypt) });
/*      */     }
/* 4108 */     checkClosed();
/* 4109 */     updateValue(findColumn(columnName), JDBCType.BIT, Boolean.valueOf(x), JavaType.BOOLEAN, forceEncrypt);
/*      */     
/* 4111 */     loggerExternal.exiting(getClassNameLogging(), "updateBoolean");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateByte(String columnName, byte x) throws SQLServerException {
/* 4116 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4117 */       loggerExternal.entering(getClassNameLogging(), "updateByte", new Object[] { columnName, Byte.valueOf(x) });
/*      */     }
/* 4119 */     checkClosed();
/* 4120 */     updateValue(findColumn(columnName), JDBCType.BINARY, Byte.valueOf(x), JavaType.BYTE, false);
/*      */     
/* 4122 */     loggerExternal.exiting(getClassNameLogging(), "updateByte");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateByte(String columnName, byte x, boolean forceEncrypt) throws SQLServerException {
/* 4127 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4128 */       loggerExternal.entering(getClassNameLogging(), "updateByte", new Object[] { columnName, Byte.valueOf(x), Boolean.valueOf(forceEncrypt) });
/*      */     }
/* 4130 */     checkClosed();
/* 4131 */     updateValue(findColumn(columnName), JDBCType.BINARY, Byte.valueOf(x), JavaType.BYTE, forceEncrypt);
/*      */     
/* 4133 */     loggerExternal.exiting(getClassNameLogging(), "updateByte");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateShort(String columnName, short x) throws SQLServerException {
/* 4138 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4139 */       loggerExternal.entering(getClassNameLogging(), "updateShort", new Object[] { columnName, Short.valueOf(x) });
/*      */     }
/* 4141 */     checkClosed();
/* 4142 */     updateValue(findColumn(columnName), JDBCType.SMALLINT, Short.valueOf(x), JavaType.SHORT, false);
/*      */     
/* 4144 */     loggerExternal.exiting(getClassNameLogging(), "updateShort");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateShort(String columnName, short x, boolean forceEncrypt) throws SQLServerException {
/* 4149 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4150 */       loggerExternal.entering(getClassNameLogging(), "updateShort", new Object[] { columnName, Short.valueOf(x), Boolean.valueOf(forceEncrypt) });
/*      */     }
/* 4152 */     checkClosed();
/* 4153 */     updateValue(findColumn(columnName), JDBCType.SMALLINT, Short.valueOf(x), JavaType.SHORT, forceEncrypt);
/*      */     
/* 4155 */     loggerExternal.exiting(getClassNameLogging(), "updateShort");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateInt(String columnName, int x) throws SQLServerException {
/* 4160 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4161 */       loggerExternal.entering(getClassNameLogging(), "updateInt", new Object[] { columnName, Integer.valueOf(x) });
/*      */     }
/* 4163 */     checkClosed();
/* 4164 */     updateValue(findColumn(columnName), JDBCType.INTEGER, Integer.valueOf(x), JavaType.INTEGER, false);
/*      */     
/* 4166 */     loggerExternal.exiting(getClassNameLogging(), "updateInt");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateInt(String columnName, int x, boolean forceEncrypt) throws SQLServerException {
/* 4171 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4172 */       loggerExternal.entering(getClassNameLogging(), "updateInt", new Object[] { columnName, Integer.valueOf(x), Boolean.valueOf(forceEncrypt) });
/*      */     }
/* 4174 */     checkClosed();
/* 4175 */     updateValue(findColumn(columnName), JDBCType.INTEGER, Integer.valueOf(x), JavaType.INTEGER, forceEncrypt);
/*      */     
/* 4177 */     loggerExternal.exiting(getClassNameLogging(), "updateInt");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateLong(String columnName, long x) throws SQLServerException {
/* 4182 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4183 */       loggerExternal.entering(getClassNameLogging(), "updateLong", new Object[] { columnName, Long.valueOf(x) });
/*      */     }
/* 4185 */     checkClosed();
/* 4186 */     updateValue(findColumn(columnName), JDBCType.BIGINT, Long.valueOf(x), JavaType.LONG, false);
/*      */     
/* 4188 */     loggerExternal.exiting(getClassNameLogging(), "updateLong");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateLong(String columnName, long x, boolean forceEncrypt) throws SQLServerException {
/* 4193 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4194 */       loggerExternal.entering(getClassNameLogging(), "updateLong", new Object[] { columnName, Long.valueOf(x), Boolean.valueOf(forceEncrypt) });
/*      */     }
/* 4196 */     checkClosed();
/* 4197 */     updateValue(findColumn(columnName), JDBCType.BIGINT, Long.valueOf(x), JavaType.LONG, forceEncrypt);
/*      */     
/* 4199 */     loggerExternal.exiting(getClassNameLogging(), "updateLong");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateFloat(String columnName, float x) throws SQLServerException {
/* 4204 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4205 */       loggerExternal.entering(getClassNameLogging(), "updateFloat", new Object[] { columnName, Float.valueOf(x) });
/*      */     }
/* 4207 */     checkClosed();
/* 4208 */     updateValue(findColumn(columnName), JDBCType.REAL, Float.valueOf(x), JavaType.FLOAT, false);
/*      */     
/* 4210 */     loggerExternal.exiting(getClassNameLogging(), "updateFloat");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateFloat(String columnName, float x, boolean forceEncrypt) throws SQLServerException {
/* 4215 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4216 */       loggerExternal.entering(getClassNameLogging(), "updateFloat", new Object[] { columnName, Float.valueOf(x), Boolean.valueOf(forceEncrypt) });
/*      */     }
/* 4218 */     checkClosed();
/* 4219 */     updateValue(findColumn(columnName), JDBCType.REAL, Float.valueOf(x), JavaType.FLOAT, forceEncrypt);
/*      */     
/* 4221 */     loggerExternal.exiting(getClassNameLogging(), "updateFloat");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateDouble(String columnName, double x) throws SQLServerException {
/* 4226 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4227 */       loggerExternal.entering(getClassNameLogging(), "updateDouble", new Object[] { columnName, Double.valueOf(x) });
/*      */     }
/* 4229 */     checkClosed();
/* 4230 */     updateValue(findColumn(columnName), JDBCType.DOUBLE, Double.valueOf(x), JavaType.DOUBLE, false);
/*      */     
/* 4232 */     loggerExternal.exiting(getClassNameLogging(), "updateDouble");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateDouble(String columnName, double x, boolean forceEncrypt) throws SQLServerException {
/* 4237 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4238 */       loggerExternal.entering(getClassNameLogging(), "updateDouble", new Object[] { columnName, Double.valueOf(x), Boolean.valueOf(forceEncrypt) });
/*      */     }
/* 4240 */     checkClosed();
/* 4241 */     updateValue(findColumn(columnName), JDBCType.DOUBLE, Double.valueOf(x), JavaType.DOUBLE, forceEncrypt);
/*      */     
/* 4243 */     loggerExternal.exiting(getClassNameLogging(), "updateDouble");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateBigDecimal(String columnName, BigDecimal x) throws SQLServerException {
/* 4248 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4249 */       loggerExternal.entering(getClassNameLogging(), "updateBigDecimal", new Object[] { columnName, x });
/*      */     }
/* 4251 */     checkClosed();
/* 4252 */     updateValue(findColumn(columnName), JDBCType.DECIMAL, x, JavaType.BIGDECIMAL, false);
/*      */     
/* 4254 */     loggerExternal.exiting(getClassNameLogging(), "updateBigDecimal");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateBigDecimal(String columnName, BigDecimal x, boolean forceEncrypt) throws SQLServerException {
/* 4259 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4260 */       loggerExternal.entering(getClassNameLogging(), "updateBigDecimal", new Object[] { columnName, x, 
/* 4261 */             Boolean.valueOf(forceEncrypt) });
/*      */     }
/* 4263 */     checkClosed();
/* 4264 */     updateValue(findColumn(columnName), JDBCType.DECIMAL, x, JavaType.BIGDECIMAL, forceEncrypt);
/*      */     
/* 4266 */     loggerExternal.exiting(getClassNameLogging(), "updateBigDecimal");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBigDecimal(String columnName, BigDecimal x, Integer precision, Integer scale) throws SQLServerException {
/* 4272 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4273 */       loggerExternal.entering(getClassNameLogging(), "updateBigDecimal", new Object[] { columnName, x, precision, scale });
/*      */     }
/*      */     
/* 4276 */     checkClosed();
/* 4277 */     updateValue(findColumn(columnName), JDBCType.DECIMAL, x, JavaType.BIGDECIMAL, precision, scale, false);
/*      */     
/* 4279 */     loggerExternal.exiting(getClassNameLogging(), "updateBigDecimal");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBigDecimal(String columnName, BigDecimal x, Integer precision, Integer scale, boolean forceEncrypt) throws SQLServerException {
/* 4285 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4286 */       loggerExternal.entering(getClassNameLogging(), "updateBigDecimal", new Object[] { columnName, x, precision, scale, 
/* 4287 */             Boolean.valueOf(forceEncrypt) });
/*      */     }
/* 4289 */     checkClosed();
/* 4290 */     updateValue(findColumn(columnName), JDBCType.DECIMAL, x, JavaType.BIGDECIMAL, precision, scale, forceEncrypt);
/*      */     
/* 4292 */     loggerExternal.exiting(getClassNameLogging(), "updateBigDecimal");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateString(String columnName, String x) throws SQLServerException {
/* 4297 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4298 */       loggerExternal.entering(getClassNameLogging(), "updateString", new Object[] { columnName, x });
/*      */     }
/* 4300 */     checkClosed();
/* 4301 */     updateValue(findColumn(columnName), JDBCType.VARCHAR, x, JavaType.STRING, false);
/*      */     
/* 4303 */     loggerExternal.exiting(getClassNameLogging(), "updateString");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateString(String columnName, String x, boolean forceEncrypt) throws SQLServerException {
/* 4308 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4309 */       loggerExternal.entering(getClassNameLogging(), "updateString", new Object[] { columnName, x, Boolean.valueOf(forceEncrypt) });
/*      */     }
/* 4311 */     checkClosed();
/* 4312 */     updateValue(findColumn(columnName), JDBCType.VARCHAR, x, JavaType.STRING, forceEncrypt);
/*      */     
/* 4314 */     loggerExternal.exiting(getClassNameLogging(), "updateString");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateBytes(String columnName, byte[] x) throws SQLServerException {
/* 4319 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4320 */       loggerExternal.entering(getClassNameLogging(), "updateBytes", new Object[] { columnName, x });
/*      */     }
/* 4322 */     checkClosed();
/* 4323 */     updateValue(findColumn(columnName), JDBCType.BINARY, x, JavaType.BYTEARRAY, false);
/*      */     
/* 4325 */     loggerExternal.exiting(getClassNameLogging(), "updateBytes");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateBytes(String columnName, byte[] x, boolean forceEncrypt) throws SQLServerException {
/* 4330 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4331 */       loggerExternal.entering(getClassNameLogging(), "updateBytes", new Object[] { columnName, x, Boolean.valueOf(forceEncrypt) });
/*      */     }
/* 4333 */     checkClosed();
/* 4334 */     updateValue(findColumn(columnName), JDBCType.BINARY, x, JavaType.BYTEARRAY, forceEncrypt);
/*      */     
/* 4336 */     loggerExternal.exiting(getClassNameLogging(), "updateBytes");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateDate(String columnName, Date x) throws SQLServerException {
/* 4341 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4342 */       loggerExternal.entering(getClassNameLogging(), "updateDate", new Object[] { columnName, x });
/*      */     }
/* 4344 */     checkClosed();
/* 4345 */     updateValue(findColumn(columnName), JDBCType.DATE, x, JavaType.DATE, false);
/*      */     
/* 4347 */     loggerExternal.exiting(getClassNameLogging(), "updateDate");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateDate(String columnName, Date x, boolean forceEncrypt) throws SQLServerException {
/* 4352 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4353 */       loggerExternal.entering(getClassNameLogging(), "updateDate", new Object[] { columnName, x, Boolean.valueOf(forceEncrypt) });
/*      */     }
/* 4355 */     checkClosed();
/* 4356 */     updateValue(findColumn(columnName), JDBCType.DATE, x, JavaType.DATE, forceEncrypt);
/*      */     
/* 4358 */     loggerExternal.exiting(getClassNameLogging(), "updateDate");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateTime(String columnName, Time x) throws SQLServerException {
/* 4363 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4364 */       loggerExternal.entering(getClassNameLogging(), "updateTime", new Object[] { columnName, x });
/*      */     }
/* 4366 */     checkClosed();
/* 4367 */     updateValue(findColumn(columnName), JDBCType.TIME, x, JavaType.TIME, false);
/*      */     
/* 4369 */     loggerExternal.exiting(getClassNameLogging(), "updateTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateTime(String columnName, Time x, int scale) throws SQLServerException {
/* 4374 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4375 */       loggerExternal.entering(getClassNameLogging(), "updateTime", new Object[] { columnName, x, Integer.valueOf(scale) });
/*      */     }
/* 4377 */     checkClosed();
/* 4378 */     updateValue(findColumn(columnName), JDBCType.TIME, x, JavaType.TIME, null, Integer.valueOf(scale), false);
/*      */     
/* 4380 */     loggerExternal.exiting(getClassNameLogging(), "updateTime");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateTime(String columnName, Time x, int scale, boolean forceEncrypt) throws SQLServerException {
/* 4386 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4387 */       loggerExternal.entering(getClassNameLogging(), "updateTime", new Object[] { columnName, x, 
/* 4388 */             Integer.valueOf(scale), Boolean.valueOf(forceEncrypt) });
/*      */     }
/* 4390 */     checkClosed();
/* 4391 */     updateValue(findColumn(columnName), JDBCType.TIME, x, JavaType.TIME, null, Integer.valueOf(scale), forceEncrypt);
/*      */     
/* 4393 */     loggerExternal.exiting(getClassNameLogging(), "updateTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateTimestamp(String columnName, Timestamp x) throws SQLServerException {
/* 4398 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4399 */       loggerExternal.entering(getClassNameLogging(), "updateTimestamp", new Object[] { columnName, x });
/*      */     }
/* 4401 */     checkClosed();
/* 4402 */     updateValue(findColumn(columnName), JDBCType.TIMESTAMP, x, JavaType.TIMESTAMP, false);
/*      */     
/* 4404 */     loggerExternal.exiting(getClassNameLogging(), "updateTimestamp");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateTimestamp(String columnName, Timestamp x, int scale) throws SQLServerException {
/* 4409 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4410 */       loggerExternal.entering(getClassNameLogging(), "updateTimestamp", new Object[] { columnName, x, Integer.valueOf(scale) });
/*      */     }
/* 4412 */     checkClosed();
/* 4413 */     updateValue(findColumn(columnName), JDBCType.TIMESTAMP, x, JavaType.TIMESTAMP, null, Integer.valueOf(scale), false);
/*      */     
/* 4415 */     loggerExternal.exiting(getClassNameLogging(), "updateTimestamp");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateTimestamp(String columnName, Timestamp x, int scale, boolean forceEncrypt) throws SQLServerException {
/* 4421 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4422 */       loggerExternal.entering(getClassNameLogging(), "updateTimestamp", new Object[] { columnName, x, 
/* 4423 */             Integer.valueOf(scale), Boolean.valueOf(forceEncrypt) });
/*      */     }
/* 4425 */     checkClosed();
/* 4426 */     updateValue(findColumn(columnName), JDBCType.TIMESTAMP, x, JavaType.TIMESTAMP, null, Integer.valueOf(scale), forceEncrypt);
/*      */     
/* 4428 */     loggerExternal.exiting(getClassNameLogging(), "updateTimestamp");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateDateTime(String columnName, Timestamp x) throws SQLServerException {
/* 4433 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4434 */       loggerExternal.entering(getClassNameLogging(), "updateDateTime", new Object[] { columnName, x });
/*      */     }
/* 4436 */     checkClosed();
/* 4437 */     updateValue(findColumn(columnName), JDBCType.DATETIME, x, JavaType.TIMESTAMP, false);
/*      */     
/* 4439 */     loggerExternal.exiting(getClassNameLogging(), "updateDateTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateDateTime(String columnName, Timestamp x, int scale) throws SQLServerException {
/* 4444 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4445 */       loggerExternal.entering(getClassNameLogging(), "updateDateTime", new Object[] { columnName, x, Integer.valueOf(scale) });
/*      */     }
/* 4447 */     checkClosed();
/* 4448 */     updateValue(findColumn(columnName), JDBCType.DATETIME, x, JavaType.TIMESTAMP, null, Integer.valueOf(scale), false);
/*      */     
/* 4450 */     loggerExternal.exiting(getClassNameLogging(), "updateDateTime");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateDateTime(String columnName, Timestamp x, int scale, boolean forceEncrypt) throws SQLServerException {
/* 4456 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4457 */       loggerExternal.entering(getClassNameLogging(), "updateDateTime", new Object[] { columnName, x, 
/* 4458 */             Integer.valueOf(scale), Boolean.valueOf(forceEncrypt) });
/*      */     }
/* 4460 */     checkClosed();
/* 4461 */     updateValue(findColumn(columnName), JDBCType.DATETIME, x, JavaType.TIMESTAMP, null, Integer.valueOf(scale), forceEncrypt);
/*      */     
/* 4463 */     loggerExternal.exiting(getClassNameLogging(), "updateDateTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateSmallDateTime(String columnName, Timestamp x) throws SQLServerException {
/* 4468 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4469 */       loggerExternal.entering(getClassNameLogging(), "updateSmallDateTime", new Object[] { columnName, x });
/*      */     }
/* 4471 */     checkClosed();
/* 4472 */     updateValue(findColumn(columnName), JDBCType.SMALLDATETIME, x, JavaType.TIMESTAMP, false);
/*      */     
/* 4474 */     loggerExternal.exiting(getClassNameLogging(), "updateSmallDateTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateSmallDateTime(String columnName, Timestamp x, int scale) throws SQLServerException {
/* 4479 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4480 */       loggerExternal.entering(getClassNameLogging(), "updateSmallDateTime", new Object[] { columnName, x, Integer.valueOf(scale) });
/*      */     }
/* 4482 */     checkClosed();
/* 4483 */     updateValue(findColumn(columnName), JDBCType.SMALLDATETIME, x, JavaType.TIMESTAMP, null, Integer.valueOf(scale), false);
/*      */     
/* 4485 */     loggerExternal.exiting(getClassNameLogging(), "updateSmallDateTime");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateSmallDateTime(String columnName, Timestamp x, int scale, boolean forceEncrypt) throws SQLServerException {
/* 4491 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4492 */       loggerExternal.entering(getClassNameLogging(), "updateSmallDateTime", new Object[] { columnName, x, 
/* 4493 */             Integer.valueOf(scale), Boolean.valueOf(forceEncrypt) });
/*      */     }
/* 4495 */     checkClosed();
/* 4496 */     updateValue(findColumn(columnName), JDBCType.SMALLDATETIME, x, JavaType.TIMESTAMP, null, Integer.valueOf(scale), forceEncrypt);
/*      */     
/* 4498 */     loggerExternal.exiting(getClassNameLogging(), "updateSmallDateTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateDateTimeOffset(String columnName, DateTimeOffset x) throws SQLServerException {
/* 4503 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4504 */       loggerExternal.entering(getClassNameLogging(), "updateDateTimeOffset", new Object[] { columnName, x });
/*      */     }
/* 4506 */     checkClosed();
/* 4507 */     updateValue(findColumn(columnName), JDBCType.DATETIMEOFFSET, x, JavaType.DATETIMEOFFSET, false);
/*      */     
/* 4509 */     loggerExternal.exiting(getClassNameLogging(), "updateDateTimeOffset");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateDateTimeOffset(String columnName, DateTimeOffset x, int scale) throws SQLServerException {
/* 4515 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4516 */       loggerExternal.entering(getClassNameLogging(), "updateDateTimeOffset", new Object[] { columnName, x, Integer.valueOf(scale) });
/*      */     }
/* 4518 */     checkClosed();
/* 4519 */     updateValue(findColumn(columnName), JDBCType.DATETIMEOFFSET, x, JavaType.DATETIMEOFFSET, null, Integer.valueOf(scale), false);
/*      */     
/* 4521 */     loggerExternal.exiting(getClassNameLogging(), "updateDateTimeOffset");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateDateTimeOffset(String columnName, DateTimeOffset x, int scale, boolean forceEncrypt) throws SQLServerException {
/* 4527 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4528 */       loggerExternal.entering(getClassNameLogging(), "updateDateTimeOffset", new Object[] { columnName, x, 
/* 4529 */             Integer.valueOf(scale), Boolean.valueOf(forceEncrypt) });
/*      */     }
/* 4531 */     checkClosed();
/* 4532 */     updateValue(findColumn(columnName), JDBCType.DATETIMEOFFSET, x, JavaType.DATETIMEOFFSET, null, Integer.valueOf(scale), forceEncrypt);
/*      */ 
/*      */     
/* 4535 */     loggerExternal.exiting(getClassNameLogging(), "updateDateTimeOffset");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateUniqueIdentifier(String columnName, String x) throws SQLServerException {
/* 4540 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4541 */       loggerExternal.entering(getClassNameLogging(), "updateUniqueIdentifier", new Object[] { columnName, x });
/*      */     }
/* 4543 */     checkClosed();
/* 4544 */     updateValue(findColumn(columnName), JDBCType.GUID, x, JavaType.STRING, null, false);
/*      */     
/* 4546 */     loggerExternal.exiting(getClassNameLogging(), "updateUniqueIdentifier");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateUniqueIdentifier(String columnName, String x, boolean forceEncrypt) throws SQLServerException {
/* 4551 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4552 */       loggerExternal.entering(getClassNameLogging(), "updateUniqueIdentifier", new Object[] { columnName, x, 
/* 4553 */             Boolean.valueOf(forceEncrypt) });
/*      */     }
/* 4555 */     checkClosed();
/* 4556 */     updateValue(findColumn(columnName), JDBCType.GUID, x, JavaType.STRING, null, forceEncrypt);
/*      */     
/* 4558 */     loggerExternal.exiting(getClassNameLogging(), "updateUniqueIdentifier");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateObject(String columnName, Object x, int scale) throws SQLServerException {
/* 4563 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4564 */       loggerExternal.entering(getClassNameLogging(), "updateObject", new Object[] { columnName, x, Integer.valueOf(scale) });
/*      */     }
/* 4566 */     checkClosed();
/* 4567 */     updateObject(findColumn(columnName), x, Integer.valueOf(scale), null, null, false);
/*      */     
/* 4569 */     loggerExternal.exiting(getClassNameLogging(), "updateObject");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateObject(String columnName, Object x, int precision, int scale) throws SQLServerException {
/* 4574 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4575 */       loggerExternal.entering(getClassNameLogging(), "updateObject", new Object[] { columnName, x, 
/* 4576 */             Integer.valueOf(precision), Integer.valueOf(scale) });
/*      */     }
/* 4578 */     checkClosed();
/* 4579 */     updateObject(findColumn(columnName), x, Integer.valueOf(scale), null, Integer.valueOf(precision), false);
/*      */     
/* 4581 */     loggerExternal.exiting(getClassNameLogging(), "updateObject");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateObject(String columnName, Object x, int precision, int scale, boolean forceEncrypt) throws SQLServerException {
/* 4587 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4588 */       loggerExternal.entering(getClassNameLogging(), "updateObject", new Object[] { columnName, x, 
/* 4589 */             Integer.valueOf(precision), Integer.valueOf(scale), Boolean.valueOf(forceEncrypt) });
/*      */     }
/* 4591 */     checkClosed();
/* 4592 */     updateObject(findColumn(columnName), x, Integer.valueOf(scale), null, Integer.valueOf(precision), forceEncrypt);
/*      */     
/* 4594 */     loggerExternal.exiting(getClassNameLogging(), "updateObject");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateObject(String columnName, Object x) throws SQLServerException {
/* 4599 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4600 */       loggerExternal.entering(getClassNameLogging(), "updateObject", new Object[] { columnName, x });
/*      */     }
/* 4602 */     checkClosed();
/* 4603 */     updateObject(findColumn(columnName), x, null, null, null, false);
/*      */     
/* 4605 */     loggerExternal.exiting(getClassNameLogging(), "updateObject");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateRowId(int columnIndex, RowId x) throws SQLException {
/* 4610 */     SQLServerException.throwNotSupportedException(this.stmt.connection, this.stmt);
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateRowId(String columnLabel, RowId x) throws SQLException {
/* 4615 */     SQLServerException.throwNotSupportedException(this.stmt.connection, this.stmt);
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateSQLXML(int columnIndex, SQLXML xmlObject) throws SQLException {
/* 4620 */     if (loggerExternal.isLoggable(Level.FINER))
/* 4621 */       loggerExternal.entering(getClassNameLogging(), "updateSQLXML", new Object[] { Integer.valueOf(columnIndex), xmlObject }); 
/* 4622 */     updateSQLXMLInternal(columnIndex, xmlObject);
/* 4623 */     loggerExternal.exiting(getClassNameLogging(), "updateSQLXML");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateSQLXML(String columnLabel, SQLXML x) throws SQLException {
/* 4628 */     if (loggerExternal.isLoggable(Level.FINER))
/* 4629 */       loggerExternal.entering(getClassNameLogging(), "updateSQLXML", new Object[] { columnLabel, x }); 
/* 4630 */     updateSQLXMLInternal(findColumn(columnLabel), x);
/* 4631 */     loggerExternal.exiting(getClassNameLogging(), "updateSQLXML");
/*      */   }
/*      */ 
/*      */   
/*      */   public int getHoldability() throws SQLException {
/* 4636 */     loggerExternal.entering(getClassNameLogging(), "getHoldability");
/*      */     
/* 4638 */     checkClosed();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4649 */     int holdability = (0 == this.stmt.getServerCursorId()) ? 1 : this.stmt.getExecProps().getHoldability();
/*      */     
/* 4651 */     loggerExternal.exiting(getClassNameLogging(), "getHoldability", Integer.valueOf(holdability));
/*      */     
/* 4653 */     return holdability;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void insertRow() throws SQLException {
/* 4660 */     loggerExternal.entering(getClassNameLogging(), "insertRow");
/* 4661 */     if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) {
/* 4662 */       loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */     }
/*      */     final class InsertRowRPC
/*      */       extends TDSCommand
/*      */     {
/*      */       private static final long serialVersionUID = 1L;
/*      */       
/*      */       final String tableName;
/*      */ 
/*      */       
/*      */       InsertRowRPC(String tableName) {
/* 4673 */         super("InsertRowRPC", 0, 0);
/* 4674 */         this.tableName = tableName;
/*      */       }
/*      */       
/*      */       final boolean doExecute() throws SQLServerException {
/* 4678 */         SQLServerResultSet.this.doInsertRowRPC(this, this.tableName);
/* 4679 */         return true;
/*      */       }
/*      */     };
/*      */     
/* 4683 */     if (logger.isLoggable(Level.FINER)) {
/* 4684 */       logger.finer(toString() + toString());
/*      */     }
/* 4686 */     checkClosed();
/*      */ 
/*      */ 
/*      */     
/* 4690 */     verifyResultSetIsUpdatable();
/*      */     
/* 4692 */     if (!this.isOnInsertRow) {
/* 4693 */       SQLServerException.makeFromDriverError(this.stmt.connection, this.stmt, 
/* 4694 */           SQLServerException.getErrString("R_mustBeOnInsertRow"), (String)null, true);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4712 */     Column tableColumn = null;
/* 4713 */     for (Column column : this.columns) {
/* 4714 */       if (column.hasUpdates()) {
/* 4715 */         tableColumn = column;
/*      */         
/*      */         break;
/*      */       } 
/* 4719 */       if (null == tableColumn && column.isUpdatable()) {
/* 4720 */         tableColumn = column;
/*      */       }
/*      */     } 
/* 4723 */     if (null == tableColumn) {
/* 4724 */       SQLServerException.makeFromDriverError(this.stmt.connection, this.stmt, 
/* 4725 */           SQLServerException.getErrString("R_noColumnParameterValue"), (String)null, true);
/*      */     }
/*      */     
/* 4728 */     assert tableColumn.isUpdatable();
/* 4729 */     assert null != tableColumn.getTableName();
/*      */     
/* 4731 */     this.stmt.executeCommand(new InsertRowRPC(tableColumn.getTableName().asEscapedString()));
/*      */     
/* 4733 */     if (-3 != this.rowCount)
/* 4734 */       this.rowCount++; 
/* 4735 */     loggerExternal.exiting(getClassNameLogging(), "insertRow");
/*      */   }
/*      */   
/*      */   private void doInsertRowRPC(TDSCommand command, String tableName) throws SQLServerException {
/* 4739 */     assert 0 != this.serverCursorId;
/* 4740 */     assert null != tableName;
/* 4741 */     assert tableName.length() > 0;
/*      */     
/* 4743 */     TDSWriter tdsWriter = command.startRequest((byte)3);
/* 4744 */     tdsWriter.writeShort((short)-1);
/* 4745 */     tdsWriter.writeShort((short)1);
/* 4746 */     tdsWriter.writeByte((byte)0);
/* 4747 */     tdsWriter.writeByte((byte)0);
/* 4748 */     tdsWriter.sendEnclavePackage(null, null);
/* 4749 */     tdsWriter.writeRPCInt(null, Integer.valueOf(this.serverCursorId), false);
/* 4750 */     tdsWriter.writeRPCInt(null, Integer.valueOf(4), false);
/* 4751 */     tdsWriter.writeRPCInt(null, Integer.valueOf(fetchBufferGetRow()), false);
/*      */     
/* 4753 */     if (hasUpdatedColumns()) {
/* 4754 */       tdsWriter.writeRPCStringUnicode(tableName);
/*      */       
/* 4756 */       for (Column column : this.columns)
/* 4757 */         column.sendByRPC(tdsWriter, this.stmt.connection); 
/*      */     } else {
/* 4759 */       tdsWriter.writeRPCStringUnicode("");
/* 4760 */       tdsWriter.writeRPCStringUnicode("INSERT INTO " + tableName + " DEFAULT VALUES");
/*      */     } 
/*      */     
/* 4763 */     TDSParser.parse(command.startResponse(), command.getLogContext());
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateRow() throws SQLException {
/* 4768 */     loggerExternal.entering(getClassNameLogging(), "updateRow");
/* 4769 */     if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) {
/* 4770 */       loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */     }
/*      */     final class UpdateRowRPC
/*      */       extends TDSCommand
/*      */     {
/*      */       private static final long serialVersionUID = 1L;
/*      */ 
/*      */       
/*      */       UpdateRowRPC() {
/* 4779 */         super("UpdateRowRPC", 0, 0);
/*      */       }
/*      */       
/*      */       final boolean doExecute() throws SQLServerException {
/* 4783 */         SQLServerResultSet.this.doUpdateRowRPC(this);
/* 4784 */         return true;
/*      */       }
/*      */     };
/*      */     
/* 4788 */     if (logger.isLoggable(Level.FINER)) {
/* 4789 */       logger.finer(toString() + toString());
/*      */     }
/* 4791 */     checkClosed();
/*      */ 
/*      */ 
/*      */     
/* 4795 */     verifyResultSetIsUpdatable();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4800 */     verifyResultSetIsNotOnInsertRow();
/* 4801 */     verifyResultSetHasCurrentRow();
/*      */ 
/*      */     
/* 4804 */     verifyCurrentRowIsNotDeleted("R_cantUpdateDeletedRow");
/*      */     
/* 4806 */     if (!hasUpdatedColumns()) {
/* 4807 */       SQLServerException.makeFromDriverError(this.stmt.connection, this.stmt, 
/* 4808 */           SQLServerException.getErrString("R_noColumnParameterValue"), (String)null, true);
/*      */     }
/*      */     
/*      */     try {
/* 4812 */       this.stmt.executeCommand(new UpdateRowRPC());
/*      */     } finally {
/* 4814 */       cancelUpdates();
/*      */     } 
/*      */     
/* 4817 */     this.updatedCurrentRow = true;
/* 4818 */     loggerExternal.exiting(getClassNameLogging(), "updateRow");
/*      */   }
/*      */   
/*      */   private void doUpdateRowRPC(TDSCommand command) throws SQLServerException {
/* 4822 */     assert 0 != this.serverCursorId;
/*      */     
/* 4824 */     TDSWriter tdsWriter = command.startRequest((byte)3);
/* 4825 */     tdsWriter.writeShort((short)-1);
/* 4826 */     tdsWriter.writeShort((short)1);
/* 4827 */     tdsWriter.writeByte((byte)0);
/* 4828 */     tdsWriter.writeByte((byte)0);
/* 4829 */     tdsWriter.sendEnclavePackage(null, null);
/* 4830 */     tdsWriter.writeRPCInt(null, Integer.valueOf(this.serverCursorId), false);
/* 4831 */     tdsWriter.writeRPCInt(null, Integer.valueOf(33), false);
/* 4832 */     tdsWriter.writeRPCInt(null, Integer.valueOf(fetchBufferGetRow()), false);
/* 4833 */     tdsWriter.writeRPCStringUnicode("");
/*      */     
/* 4835 */     assert hasUpdatedColumns();
/*      */     
/* 4837 */     for (Column column : this.columns) {
/* 4838 */       column.sendByRPC(tdsWriter, this.stmt.connection);
/*      */     }
/* 4840 */     TDSParser.parse(command.startResponse(), command.getLogContext());
/*      */   }
/*      */ 
/*      */   
/*      */   final boolean hasUpdatedColumns() {
/* 4845 */     for (Column column : this.columns) {
/* 4846 */       if (column.hasUpdates())
/* 4847 */         return true; 
/*      */     } 
/* 4849 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public void deleteRow() throws SQLException {
/* 4854 */     loggerExternal.entering(getClassNameLogging(), "deleteRow");
/* 4855 */     if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) {
/* 4856 */       loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */     }
/*      */     final class DeleteRowRPC
/*      */       extends TDSCommand
/*      */     {
/*      */       private static final long serialVersionUID = 1L;
/*      */ 
/*      */       
/*      */       DeleteRowRPC() {
/* 4865 */         super("DeleteRowRPC", 0, 0);
/*      */       }
/*      */       
/*      */       final boolean doExecute() throws SQLServerException {
/* 4869 */         SQLServerResultSet.this.doDeleteRowRPC(this);
/* 4870 */         return true;
/*      */       }
/*      */     };
/*      */     
/* 4874 */     if (logger.isLoggable(Level.FINER)) {
/* 4875 */       logger.finer(toString() + toString());
/*      */     }
/* 4877 */     checkClosed();
/*      */ 
/*      */ 
/*      */     
/* 4881 */     verifyResultSetIsUpdatable();
/*      */ 
/*      */     
/* 4884 */     verifyResultSetIsNotOnInsertRow();
/* 4885 */     verifyResultSetHasCurrentRow();
/*      */ 
/*      */     
/* 4888 */     verifyCurrentRowIsNotDeleted("R_cantUpdateDeletedRow");
/*      */     
/*      */     try {
/* 4891 */       this.stmt.executeCommand(new DeleteRowRPC());
/*      */     } finally {
/* 4893 */       cancelUpdates();
/*      */     } 
/*      */     
/* 4896 */     this.deletedCurrentRow = true;
/* 4897 */     loggerExternal.exiting(getClassNameLogging(), "deleteRow");
/*      */   }
/*      */   
/*      */   private void doDeleteRowRPC(TDSCommand command) throws SQLServerException {
/* 4901 */     assert 0 != this.serverCursorId;
/*      */     
/* 4903 */     TDSWriter tdsWriter = command.startRequest((byte)3);
/* 4904 */     tdsWriter.writeShort((short)-1);
/* 4905 */     tdsWriter.writeShort((short)1);
/* 4906 */     tdsWriter.writeByte((byte)0);
/* 4907 */     tdsWriter.writeByte((byte)0);
/* 4908 */     tdsWriter.sendEnclavePackage(null, null);
/* 4909 */     tdsWriter.writeRPCInt(null, Integer.valueOf(this.serverCursorId), false);
/* 4910 */     tdsWriter.writeRPCInt(null, Integer.valueOf(34), false);
/* 4911 */     tdsWriter.writeRPCInt(null, Integer.valueOf(fetchBufferGetRow()), false);
/* 4912 */     tdsWriter.writeRPCStringUnicode("");
/*      */     
/* 4914 */     TDSParser.parse(command.startResponse(), command.getLogContext());
/*      */   }
/*      */ 
/*      */   
/*      */   public void refreshRow() throws SQLException {
/* 4919 */     loggerExternal.entering(getClassNameLogging(), "refreshRow");
/* 4920 */     if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) {
/* 4921 */       loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */     }
/*      */     
/* 4924 */     if (logger.isLoggable(Level.FINER)) {
/* 4925 */       logger.finer(toString() + toString());
/*      */     }
/* 4927 */     checkClosed();
/*      */ 
/*      */ 
/*      */     
/* 4931 */     verifyResultSetIsScrollable();
/*      */ 
/*      */ 
/*      */     
/* 4935 */     verifyResultSetIsUpdatable();
/*      */ 
/*      */ 
/*      */     
/* 4939 */     verifyResultSetIsNotOnInsertRow();
/*      */ 
/*      */     
/* 4942 */     verifyResultSetHasCurrentRow();
/* 4943 */     verifyCurrentRowIsNotDeleted("R_cantUpdateDeletedRow");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4950 */     if (1004 == this.stmt.getResultSetType() || 0 == this.serverCursorId) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 4956 */     cancelUpdates();
/*      */     
/* 4958 */     doRefreshRow();
/* 4959 */     loggerExternal.exiting(getClassNameLogging(), "refreshRow");
/*      */   }
/*      */   
/*      */   private void doRefreshRow() throws SQLServerException {
/* 4963 */     assert hasCurrentRow();
/*      */ 
/*      */ 
/*      */     
/* 4967 */     int fetchBufferSavedRow = fetchBufferGetRow();
/*      */ 
/*      */ 
/*      */     
/* 4971 */     doServerFetch(128, 0, 0);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4977 */     int fetchBufferRestoredRow = 0;
/* 4978 */     while (fetchBufferRestoredRow < fetchBufferSavedRow && (
/* 4979 */       isForwardOnly() ? fetchBufferNext() : this.scrollWindow.next(this))) {
/* 4980 */       fetchBufferRestoredRow++;
/*      */     }
/*      */     
/* 4983 */     if (fetchBufferRestoredRow < fetchBufferSavedRow) {
/* 4984 */       this.currentRow = -1;
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 4990 */     this.updatedCurrentRow = false;
/*      */   }
/*      */   
/*      */   private void cancelUpdates() {
/* 4994 */     if (!this.isOnInsertRow) {
/* 4995 */       clearColumnsValues();
/*      */     }
/*      */   }
/*      */   
/*      */   public void cancelRowUpdates() throws SQLServerException {
/* 5000 */     loggerExternal.entering(getClassNameLogging(), "cancelRowUpdates");
/* 5001 */     checkClosed();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5006 */     verifyResultSetIsUpdatable();
/* 5007 */     verifyResultSetIsNotOnInsertRow();
/*      */     
/* 5009 */     cancelUpdates();
/* 5010 */     loggerExternal.exiting(getClassNameLogging(), "cancelRowUpdates");
/*      */   }
/*      */ 
/*      */   
/*      */   public void moveToInsertRow() throws SQLServerException {
/* 5015 */     loggerExternal.entering(getClassNameLogging(), "moveToInsertRow");
/* 5016 */     if (logger.isLoggable(Level.FINER)) {
/* 5017 */       logger.finer(toString() + toString());
/*      */     }
/* 5019 */     checkClosed();
/*      */ 
/*      */ 
/*      */     
/* 5023 */     verifyResultSetIsUpdatable();
/*      */     
/* 5025 */     cancelUpdates();
/* 5026 */     this.isOnInsertRow = true;
/* 5027 */     loggerExternal.exiting(getClassNameLogging(), "moveToInsertRow");
/*      */   }
/*      */ 
/*      */   
/*      */   public void moveToCurrentRow() throws SQLServerException {
/* 5032 */     loggerExternal.entering(getClassNameLogging(), "moveToCurrentRow");
/* 5033 */     if (logger.isLoggable(Level.FINER)) {
/* 5034 */       logger.finer(toString() + toString());
/*      */     }
/* 5036 */     checkClosed();
/*      */ 
/*      */ 
/*      */     
/* 5040 */     verifyResultSetIsUpdatable();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5046 */     cancelInsert();
/* 5047 */     loggerExternal.exiting(getClassNameLogging(), "moveToCurrentRow");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Statement getStatement() throws SQLServerException {
/* 5053 */     loggerExternal.entering(getClassNameLogging(), "getStatement");
/* 5054 */     checkClosed();
/* 5055 */     loggerExternal.exiting(getClassNameLogging(), "getStatement", this.stmt);
/* 5056 */     return this.stmt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateClob(int columnIndex, Clob clobValue) throws SQLException {
/* 5063 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 5064 */       loggerExternal.entering(getClassNameLogging(), "updateClob", new Object[] { Integer.valueOf(columnIndex), clobValue });
/*      */     }
/* 5066 */     checkClosed();
/* 5067 */     updateValue(columnIndex, JDBCType.CLOB, clobValue, JavaType.CLOB, false);
/*      */     
/* 5069 */     loggerExternal.exiting(getClassNameLogging(), "updateClob");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateClob(int columnIndex, Reader reader) throws SQLException {
/* 5074 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 5075 */       loggerExternal.entering(getClassNameLogging(), "updateClob", new Object[] { Integer.valueOf(columnIndex), reader });
/*      */     }
/* 5077 */     checkClosed();
/* 5078 */     updateStream(columnIndex, StreamType.CHARACTER, reader, JavaType.READER, -1L);
/*      */     
/* 5080 */     loggerExternal.exiting(getClassNameLogging(), "updateClob");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateClob(int columnIndex, Reader reader, long length) throws SQLException {
/* 5085 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 5086 */       loggerExternal.entering(getClassNameLogging(), "updateClob", new Object[] { Integer.valueOf(columnIndex), reader, Long.valueOf(length) });
/*      */     }
/* 5088 */     checkClosed();
/* 5089 */     updateStream(columnIndex, StreamType.CHARACTER, reader, JavaType.READER, length);
/*      */     
/* 5091 */     loggerExternal.exiting(getClassNameLogging(), "updateClob");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateClob(String columnName, Clob clobValue) throws SQLException {
/* 5096 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 5097 */       loggerExternal.entering(getClassNameLogging(), "updateClob", new Object[] { columnName, clobValue });
/*      */     }
/* 5099 */     checkClosed();
/* 5100 */     updateValue(findColumn(columnName), JDBCType.CLOB, clobValue, JavaType.CLOB, false);
/*      */     
/* 5102 */     loggerExternal.exiting(getClassNameLogging(), "updateClob");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateClob(String columnLabel, Reader reader) throws SQLException {
/* 5107 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 5108 */       loggerExternal.entering(getClassNameLogging(), "updateClob", new Object[] { columnLabel, reader });
/*      */     }
/* 5110 */     checkClosed();
/* 5111 */     updateStream(findColumn(columnLabel), StreamType.CHARACTER, reader, JavaType.READER, -1L);
/*      */ 
/*      */     
/* 5114 */     loggerExternal.exiting(getClassNameLogging(), "updateClob");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateClob(String columnLabel, Reader reader, long length) throws SQLException {
/* 5119 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 5120 */       loggerExternal.entering(getClassNameLogging(), "updateClob", new Object[] { columnLabel, reader, Long.valueOf(length) });
/*      */     }
/* 5122 */     checkClosed();
/* 5123 */     updateStream(findColumn(columnLabel), StreamType.CHARACTER, reader, JavaType.READER, length);
/*      */     
/* 5125 */     loggerExternal.exiting(getClassNameLogging(), "updateClob");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateNClob(int columnIndex, NClob nClob) throws SQLException {
/* 5130 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 5131 */       loggerExternal.entering(getClassNameLogging(), "updateClob", new Object[] { Integer.valueOf(columnIndex), nClob });
/*      */     }
/* 5133 */     checkClosed();
/* 5134 */     updateValue(columnIndex, JDBCType.NCLOB, nClob, JavaType.NCLOB, false);
/*      */     
/* 5136 */     loggerExternal.exiting(getClassNameLogging(), "updateNClob");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateNClob(int columnIndex, Reader reader) throws SQLException {
/* 5141 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 5142 */       loggerExternal.entering(getClassNameLogging(), "updateNClob", new Object[] { Integer.valueOf(columnIndex), reader });
/*      */     }
/* 5144 */     checkClosed();
/* 5145 */     updateStream(columnIndex, StreamType.NCHARACTER, reader, JavaType.READER, -1L);
/*      */     
/* 5147 */     loggerExternal.exiting(getClassNameLogging(), "updateNClob");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateNClob(int columnIndex, Reader reader, long length) throws SQLException {
/* 5152 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 5153 */       loggerExternal.entering(getClassNameLogging(), "updateNClob", new Object[] { Integer.valueOf(columnIndex), reader, Long.valueOf(length) });
/*      */     }
/* 5155 */     checkClosed();
/* 5156 */     updateStream(columnIndex, StreamType.NCHARACTER, reader, JavaType.READER, length);
/*      */     
/* 5158 */     loggerExternal.exiting(getClassNameLogging(), "updateNClob");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateNClob(String columnLabel, NClob nClob) throws SQLException {
/* 5163 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 5164 */       loggerExternal.entering(getClassNameLogging(), "updateNClob", new Object[] { columnLabel, nClob });
/*      */     }
/* 5166 */     checkClosed();
/* 5167 */     updateValue(findColumn(columnLabel), JDBCType.NCLOB, nClob, JavaType.NCLOB, false);
/*      */     
/* 5169 */     loggerExternal.exiting(getClassNameLogging(), "updateNClob");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateNClob(String columnLabel, Reader reader) throws SQLException {
/* 5174 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 5175 */       loggerExternal.entering(getClassNameLogging(), "updateNClob", new Object[] { columnLabel, reader });
/*      */     }
/* 5177 */     checkClosed();
/* 5178 */     updateStream(findColumn(columnLabel), StreamType.NCHARACTER, reader, JavaType.READER, -1L);
/*      */ 
/*      */     
/* 5181 */     loggerExternal.exiting(getClassNameLogging(), "updateNClob");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateNClob(String columnLabel, Reader reader, long length) throws SQLException {
/* 5186 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 5187 */       loggerExternal.entering(getClassNameLogging(), "updateNClob", new Object[] { columnLabel, reader, Long.valueOf(length) });
/*      */     }
/* 5189 */     checkClosed();
/* 5190 */     updateStream(findColumn(columnLabel), StreamType.NCHARACTER, reader, JavaType.READER, length);
/*      */     
/* 5192 */     loggerExternal.exiting(getClassNameLogging(), "updateNClob");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateBlob(int columnIndex, Blob blobValue) throws SQLException {
/* 5197 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 5198 */       loggerExternal.entering(getClassNameLogging(), "updateBlob", new Object[] { Integer.valueOf(columnIndex), blobValue });
/*      */     }
/* 5200 */     checkClosed();
/* 5201 */     updateValue(columnIndex, JDBCType.BLOB, blobValue, JavaType.BLOB, false);
/*      */     
/* 5203 */     loggerExternal.exiting(getClassNameLogging(), "updateBlob");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateBlob(int columnIndex, InputStream inputStream) throws SQLException {
/* 5208 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 5209 */       loggerExternal.entering(getClassNameLogging(), "updateBlob", new Object[] { Integer.valueOf(columnIndex), inputStream });
/*      */     }
/* 5211 */     checkClosed();
/* 5212 */     updateStream(columnIndex, StreamType.BINARY, inputStream, JavaType.INPUTSTREAM, -1L);
/*      */ 
/*      */     
/* 5215 */     loggerExternal.exiting(getClassNameLogging(), "updateBlob");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateBlob(int columnIndex, InputStream inputStream, long length) throws SQLException {
/* 5220 */     if (loggerExternal.isLoggable(Level.FINER))
/* 5221 */       loggerExternal.entering(getClassNameLogging(), "updateBlob", new Object[] {
/* 5222 */             Integer.valueOf(columnIndex), inputStream, Long.valueOf(length)
/*      */           }); 
/* 5224 */     checkClosed();
/* 5225 */     updateStream(columnIndex, StreamType.BINARY, inputStream, JavaType.INPUTSTREAM, length);
/*      */     
/* 5227 */     loggerExternal.exiting(getClassNameLogging(), "updateBlob");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateBlob(String columnName, Blob blobValue) throws SQLException {
/* 5232 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 5233 */       loggerExternal.entering(getClassNameLogging(), "updateBlob", new Object[] { columnName, blobValue });
/*      */     }
/* 5235 */     checkClosed();
/* 5236 */     updateValue(findColumn(columnName), JDBCType.BLOB, blobValue, JavaType.BLOB, false);
/*      */     
/* 5238 */     loggerExternal.exiting(getClassNameLogging(), "updateBlob");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateBlob(String columnLabel, InputStream inputStream) throws SQLException {
/* 5243 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 5244 */       loggerExternal.entering(getClassNameLogging(), "updateBlob", new Object[] { columnLabel, inputStream });
/*      */     }
/* 5246 */     checkClosed();
/* 5247 */     updateStream(findColumn(columnLabel), StreamType.BINARY, inputStream, JavaType.INPUTSTREAM, -1L);
/*      */ 
/*      */     
/* 5250 */     loggerExternal.exiting(getClassNameLogging(), "updateBlob");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateBlob(String columnLabel, InputStream inputStream, long length) throws SQLException {
/* 5255 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 5256 */       loggerExternal.entering(getClassNameLogging(), "updateBlob", new Object[] { columnLabel, inputStream, 
/* 5257 */             Long.valueOf(length) });
/*      */     }
/* 5259 */     checkClosed();
/* 5260 */     updateStream(findColumn(columnLabel), StreamType.BINARY, inputStream, JavaType.INPUTSTREAM, length);
/*      */     
/* 5262 */     loggerExternal.exiting(getClassNameLogging(), "updateBlob");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateArray(int columnIndex, Array x) throws SQLException {
/* 5267 */     SQLServerException.throwNotSupportedException(this.stmt.connection, this.stmt);
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateArray(String columnName, Array x) throws SQLException {
/* 5272 */     SQLServerException.throwNotSupportedException(this.stmt.connection, this.stmt);
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateRef(int columnIndex, Ref x) throws SQLException {
/* 5277 */     SQLServerException.throwNotSupportedException(this.stmt.connection, this.stmt);
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateRef(String columnName, Ref x) throws SQLException {
/* 5282 */     SQLServerException.throwNotSupportedException(this.stmt.connection, this.stmt);
/*      */   }
/*      */ 
/*      */   
/*      */   public URL getURL(int columnIndex) throws SQLException {
/* 5287 */     SQLServerException.throwNotSupportedException(this.stmt.connection, this.stmt);
/* 5288 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public URL getURL(String sColumn) throws SQLException {
/* 5293 */     SQLServerException.throwNotSupportedException(this.stmt.connection, this.stmt);
/* 5294 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final class FetchBuffer
/*      */   {
/*      */     private final class FetchBufferTokenHandler
/*      */       extends TDSTokenHandler
/*      */     {
/*      */       FetchBufferTokenHandler() {
/* 5320 */         super("FetchBufferTokenHandler");
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       boolean onColMetaData(TDSReader tdsReader) throws SQLServerException {
/* 5327 */         (new StreamColumns(Util.shouldHonorAEForRead(SQLServerResultSet.this.stmt.stmtColumnEncriptionSetting, SQLServerResultSet.this.stmt.connection)))
/* 5328 */           .setFromTDS(tdsReader);
/* 5329 */         return true;
/*      */       }
/*      */       
/*      */       boolean onRow(TDSReader tdsReader) throws SQLServerException {
/* 5333 */         SQLServerResultSet.FetchBuffer.this.ensureStartMark();
/*      */ 
/*      */ 
/*      */         
/* 5337 */         if (209 != tdsReader.readUnsignedByte() && 
/* 5338 */           !$assertionsDisabled) throw new AssertionError(); 
/* 5339 */         SQLServerResultSet.FetchBuffer.this.fetchBufferCurrentRowType = RowType.ROW;
/* 5340 */         return false;
/*      */       }
/*      */       
/*      */       boolean onNBCRow(TDSReader tdsReader) throws SQLServerException {
/* 5344 */         SQLServerResultSet.FetchBuffer.this.ensureStartMark();
/*      */ 
/*      */ 
/*      */         
/* 5348 */         if (210 != tdsReader.readUnsignedByte() && 
/* 5349 */           !$assertionsDisabled) throw new AssertionError();
/*      */         
/* 5351 */         SQLServerResultSet.FetchBuffer.this.fetchBufferCurrentRowType = RowType.NBCROW;
/* 5352 */         return false;
/*      */       }
/*      */       
/*      */       boolean onDone(TDSReader tdsReader) throws SQLServerException {
/* 5356 */         SQLServerResultSet.FetchBuffer.this.ensureStartMark();
/*      */         
/* 5358 */         StreamDone doneToken = new StreamDone();
/* 5359 */         doneToken.setFromTDS(tdsReader);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5364 */         SQLServerResultSet.FetchBuffer.this.done = true;
/* 5365 */         return (0 != SQLServerResultSet.this.serverCursorId);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       boolean onRetStatus(TDSReader tdsReader) throws SQLServerException {
/* 5372 */         StreamRetStatus retStatusToken = new StreamRetStatus();
/* 5373 */         retStatusToken.setFromTDS(tdsReader);
/* 5374 */         SQLServerResultSet.FetchBuffer.this.needsServerCursorFixup = (2 == retStatusToken.getStatus());
/* 5375 */         return true;
/*      */       }
/*      */       
/*      */       void onEOF(TDSReader tdsReader) throws SQLServerException {
/* 5379 */         super.onEOF(tdsReader);
/* 5380 */         SQLServerResultSet.FetchBuffer.this.done = true;
/*      */       }
/*      */     }
/*      */     
/* 5384 */     private final FetchBufferTokenHandler fetchBufferTokenHandler = new FetchBufferTokenHandler();
/*      */     
/*      */     private TDSReaderMark startMark;
/*      */ 
/*      */     
/*      */     final void clearStartMark() {
/* 5390 */       this.startMark = null;
/*      */     }
/*      */     
/* 5393 */     private RowType fetchBufferCurrentRowType = RowType.UNKNOWN;
/*      */     private boolean done;
/*      */     private boolean needsServerCursorFixup;
/*      */     
/*      */     final boolean needsServerCursorFixup() {
/* 5398 */       return this.needsServerCursorFixup;
/*      */     }
/*      */     
/*      */     FetchBuffer() {
/* 5402 */       init();
/*      */     }
/*      */     
/*      */     final void ensureStartMark() {
/* 5406 */       if (null == this.startMark && !SQLServerResultSet.this.isForwardOnly()) {
/* 5407 */         if (SQLServerResultSet.logger.isLoggable(Level.FINEST)) {
/* 5408 */           SQLServerResultSet.logger.finest(toString() + " Setting fetch buffer start mark");
/*      */         }
/* 5410 */         this.startMark = SQLServerResultSet.this.tdsReader.mark();
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     final void reset() {
/* 5418 */       assert null != SQLServerResultSet.this.tdsReader;
/* 5419 */       assert null != this.startMark;
/*      */       
/* 5421 */       SQLServerResultSet.this.tdsReader.reset(this.startMark);
/* 5422 */       this.fetchBufferCurrentRowType = RowType.UNKNOWN;
/* 5423 */       this.done = false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     final void init() {
/* 5431 */       this.startMark = (0 == SQLServerResultSet.this.serverCursorId && !SQLServerResultSet.this.isForwardOnly()) ? SQLServerResultSet.this.tdsReader.mark() : null;
/* 5432 */       this.fetchBufferCurrentRowType = RowType.UNKNOWN;
/* 5433 */       this.done = false;
/* 5434 */       this.needsServerCursorFixup = false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     final RowType nextRow() throws SQLServerException {
/* 5441 */       this.fetchBufferCurrentRowType = RowType.UNKNOWN;
/*      */       
/* 5443 */       while (null != SQLServerResultSet.this.tdsReader && !this.done && this.fetchBufferCurrentRowType.equals(RowType.UNKNOWN)) {
/* 5444 */         TDSParser.parse(SQLServerResultSet.this.tdsReader, this.fetchBufferTokenHandler);
/*      */       }
/* 5446 */       if (this.fetchBufferCurrentRowType.equals(RowType.UNKNOWN) && null != this.fetchBufferTokenHandler
/* 5447 */         .getDatabaseError()) {
/* 5448 */         SQLServerException.makeFromDatabaseError(SQLServerResultSet.this.stmt.connection, (Object)null, this.fetchBufferTokenHandler
/* 5449 */             .getDatabaseError().getErrorMessage(), this.fetchBufferTokenHandler
/* 5450 */             .getDatabaseError(), false);
/*      */       }
/*      */       
/* 5453 */       return this.fetchBufferCurrentRowType;
/*      */     }
/*      */   }
/*      */   private final class FetchBufferTokenHandler extends TDSTokenHandler {
/*      */     FetchBufferTokenHandler() { super("FetchBufferTokenHandler"); }
/*      */     boolean onColMetaData(TDSReader tdsReader) throws SQLServerException { (new StreamColumns(Util.shouldHonorAEForRead(SQLServerResultSet.this.stmt.stmtColumnEncriptionSetting, SQLServerResultSet.this.stmt.connection))).setFromTDS(tdsReader); return true; }
/*      */     boolean onRow(TDSReader tdsReader) throws SQLServerException { this.this$1.ensureStartMark(); if (209 != tdsReader.readUnsignedByte() && !$assertionsDisabled)
/*      */         throw new AssertionError();  this.this$1.fetchBufferCurrentRowType = RowType.ROW; return false; } boolean onNBCRow(TDSReader tdsReader) throws SQLServerException { this.this$1.ensureStartMark(); if (210 != tdsReader.readUnsignedByte() && !$assertionsDisabled)
/*      */         throw new AssertionError();  this.this$1.fetchBufferCurrentRowType = RowType.NBCROW; return false; } boolean onDone(TDSReader tdsReader) throws SQLServerException { this.this$1.ensureStartMark(); StreamDone doneToken = new StreamDone(); doneToken.setFromTDS(tdsReader); this.this$1.done = true;
/*      */       return (0 != SQLServerResultSet.this.serverCursorId); } boolean onRetStatus(TDSReader tdsReader) throws SQLServerException { StreamRetStatus retStatusToken = new StreamRetStatus();
/*      */       retStatusToken.setFromTDS(tdsReader);
/*      */       this.this$1.needsServerCursorFixup = (2 == retStatusToken.getStatus());
/*      */       return true; } void onEOF(TDSReader tdsReader) throws SQLServerException { super.onEOF(tdsReader);
/*      */       this.this$1.done = true; }
/*      */   } private final class CursorFetchCommand extends TDSCommand {
/* 5468 */     private static final long serialVersionUID = 1L; private final int serverCursorId; CursorFetchCommand(int serverCursorId, int fetchType, int startRow, int numRows) { super("doServerFetch", SQLServerResultSet.this.stmt.queryTimeout, SQLServerResultSet.this.stmt.cancelQueryTimeoutSeconds);
/* 5469 */       this.serverCursorId = serverCursorId;
/* 5470 */       this.fetchType = fetchType;
/* 5471 */       this.startRow = startRow;
/* 5472 */       this.numRows = numRows; }
/*      */     
/*      */     private int fetchType; private int startRow; private int numRows;
/*      */     final boolean doExecute() throws SQLServerException {
/* 5476 */       TDSWriter tdsWriter = startRequest((byte)3);
/* 5477 */       tdsWriter.writeShort((short)-1);
/* 5478 */       tdsWriter.writeShort((short)7);
/* 5479 */       tdsWriter.writeByte((byte)2);
/* 5480 */       tdsWriter.writeByte((byte)0);
/* 5481 */       tdsWriter.sendEnclavePackage(null, null);
/* 5482 */       tdsWriter.writeRPCInt(null, Integer.valueOf(this.serverCursorId), false);
/* 5483 */       tdsWriter.writeRPCInt(null, Integer.valueOf(this.fetchType), false);
/* 5484 */       tdsWriter.writeRPCInt(null, Integer.valueOf(this.startRow), false);
/* 5485 */       tdsWriter.writeRPCInt(null, Integer.valueOf(this.numRows), false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 5493 */       SQLServerResultSet.this.tdsReader = startResponse((SQLServerResultSet.this.isForwardOnly() && 1007 != SQLServerResultSet.this.stmt.resultSetConcurrency && SQLServerResultSet.this.stmt
/* 5494 */           .getExecProps().wasResponseBufferingSet() && SQLServerResultSet.this.stmt
/* 5495 */           .getExecProps().isResponseBufferingAdaptive()));
/*      */       
/* 5497 */       return false;
/*      */     }
/*      */     
/*      */     final void processResponse(TDSReader responseTDSReader) throws SQLServerException {
/* 5501 */       SQLServerResultSet.this.tdsReader = responseTDSReader;
/* 5502 */       SQLServerResultSet.this.discardFetchBuffer();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void doServerFetch(int fetchType, int startRow, int numRows) throws SQLServerException {
/* 5519 */     if (logger.isLoggable(Level.FINER)) {
/* 5520 */       logger.finer(toString() + " fetchType:" + toString() + " startRow:" + fetchType + " numRows:" + startRow);
/*      */     }
/*      */     
/* 5523 */     discardFetchBuffer();
/*      */ 
/*      */     
/* 5526 */     this.fetchBuffer.init();
/*      */ 
/*      */     
/* 5529 */     CursorFetchCommand cursorFetch = new CursorFetchCommand(this.serverCursorId, fetchType, startRow, numRows);
/* 5530 */     this.stmt.executeCommand(cursorFetch);
/*      */     
/* 5532 */     this.numFetchedRows = 0;
/* 5533 */     this.resultSetCurrentRowType = RowType.UNKNOWN;
/* 5534 */     this.areNullCompressedColumnsInitialized = false;
/* 5535 */     this.lastColumnIndex = 0;
/*      */ 
/*      */     
/* 5538 */     if (null != this.scrollWindow && 128 != fetchType) {
/* 5539 */       this.scrollWindow.resize(this.fetchSize);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5548 */     if (numRows < 0 || startRow < 0) {
/*      */       
/*      */       try {
/* 5551 */         while (this.scrollWindow.next(this));
/* 5552 */       } catch (SQLException e) {
/*      */ 
/*      */ 
/*      */         
/* 5556 */         if (logger.isLoggable(Level.FINER)) {
/* 5557 */           logger.finer(toString() + " Ignored exception from row error during server cursor fixup: " + toString());
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/* 5562 */       if (this.fetchBuffer.needsServerCursorFixup()) {
/* 5563 */         doServerFetch(1, 0, 0);
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/* 5568 */       this.scrollWindow.reset();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void fillLOBs() {
/* 5577 */     if (null != this.activeLOB) {
/*      */       try {
/* 5579 */         this.activeLOB.fillFromStream();
/* 5580 */       } catch (SQLException e) {
/* 5581 */         if (logger.isLoggable(Level.FINER)) {
/* 5582 */           logger.finer(toString() + "Filling Lobs before closing: " + toString());
/*      */         }
/*      */       } finally {
/* 5585 */         this.activeLOB = null;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void discardFetchBuffer() {
/* 5604 */     fillLOBs();
/*      */ 
/*      */     
/* 5607 */     this.fetchBuffer.clearStartMark();
/*      */ 
/*      */     
/* 5610 */     if (null != this.scrollWindow) {
/* 5611 */       this.scrollWindow.clear();
/*      */     }
/*      */ 
/*      */     
/*      */     try {
/* 5616 */       while (fetchBufferNext());
/* 5617 */     } catch (SQLServerException e) {
/* 5618 */       if (logger.isLoggable(Level.FINER)) {
/* 5619 */         logger.finer("" + this + " Encountered exception discarding fetch buffer: " + this);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void closeServerCursor() {
/* 5629 */     if (0 == this.serverCursorId) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 5634 */     if (this.stmt.connection.isSessionUnAvailable()) {
/* 5635 */       if (logger.isLoggable(Level.FINER))
/* 5636 */         logger.finer("" + this + ": Not closing cursor:" + this + "; connection is already closed."); 
/*      */     } else {
/* 5638 */       if (logger.isLoggable(Level.FINER)) {
/* 5639 */         logger.finer(toString() + " Closing cursor:" + toString());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/* 5666 */         this.stmt.executeCommand(new CloseServerCursorCommand());
/* 5667 */       } catch (SQLServerException e) {
/* 5668 */         if (logger.isLoggable(Level.FINER)) {
/* 5669 */           logger.finer(toString() + " Ignored error closing cursor:" + toString() + " " + this.serverCursorId);
/*      */         }
/*      */       } 
/* 5672 */       if (logger.isLoggable(Level.FINER)) {
/* 5673 */         logger.finer(toString() + " Closed cursor:" + toString());
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateObject(int index, Object obj, SQLType targetSqlType) throws SQLServerException {
/* 5680 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 5681 */       loggerExternal.entering(getClassNameLogging(), "updateObject", new Object[] { Integer.valueOf(index), obj, targetSqlType });
/*      */     }
/* 5683 */     checkClosed();
/*      */     
/* 5685 */     updateObject(index, obj, null, JDBCType.of(targetSqlType.getVendorTypeNumber().intValue()), null, false);
/*      */     
/* 5687 */     loggerExternal.exiting(getClassNameLogging(), "updateObject");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateObject(int index, Object obj, SQLType targetSqlType, int scale) throws SQLServerException {
/* 5693 */     if (loggerExternal.isLoggable(Level.FINER))
/* 5694 */       loggerExternal.entering(getClassNameLogging(), "updateObject", new Object[] {
/* 5695 */             Integer.valueOf(index), obj, targetSqlType, Integer.valueOf(scale)
/*      */           }); 
/* 5697 */     checkClosed();
/*      */     
/* 5699 */     updateObject(index, obj, Integer.valueOf(scale), JDBCType.of(targetSqlType.getVendorTypeNumber().intValue()), null, false);
/*      */     
/* 5701 */     loggerExternal.exiting(getClassNameLogging(), "updateObject");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateObject(int index, Object obj, SQLType targetSqlType, int scale, boolean forceEncrypt) throws SQLServerException {
/* 5708 */     if (loggerExternal.isLoggable(Level.FINER))
/* 5709 */       loggerExternal.entering(getClassNameLogging(), "updateObject", new Object[] {
/* 5710 */             Integer.valueOf(index), obj, targetSqlType, Integer.valueOf(scale), Boolean.valueOf(forceEncrypt)
/*      */           }); 
/* 5712 */     checkClosed();
/*      */     
/* 5714 */     updateObject(index, obj, Integer.valueOf(scale), JDBCType.of(targetSqlType.getVendorTypeNumber().intValue()), null, forceEncrypt);
/*      */     
/* 5716 */     loggerExternal.exiting(getClassNameLogging(), "updateObject");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateObject(String columnName, Object obj, SQLType targetSqlType, int scale) throws SQLServerException {
/* 5723 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 5724 */       loggerExternal.entering(getClassNameLogging(), "updateObject", new Object[] { columnName, obj, targetSqlType, 
/* 5725 */             Integer.valueOf(scale) });
/*      */     }
/* 5727 */     checkClosed();
/*      */ 
/*      */     
/* 5730 */     updateObject(findColumn(columnName), obj, Integer.valueOf(scale), JDBCType.of(targetSqlType.getVendorTypeNumber().intValue()), null, false);
/*      */     
/* 5732 */     loggerExternal.exiting(getClassNameLogging(), "updateObject");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateObject(String columnName, Object obj, SQLType targetSqlType, int scale, boolean forceEncrypt) throws SQLServerException {
/* 5739 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 5740 */       loggerExternal.entering(getClassNameLogging(), "updateObject", new Object[] { columnName, obj, targetSqlType, 
/* 5741 */             Integer.valueOf(scale), Boolean.valueOf(forceEncrypt) });
/*      */     }
/* 5743 */     checkClosed();
/*      */ 
/*      */     
/* 5746 */     updateObject(findColumn(columnName), obj, Integer.valueOf(scale), JDBCType.of(targetSqlType.getVendorTypeNumber().intValue()), null, forceEncrypt);
/*      */ 
/*      */     
/* 5749 */     loggerExternal.exiting(getClassNameLogging(), "updateObject");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateObject(String columnName, Object obj, SQLType targetSqlType) throws SQLServerException {
/* 5755 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 5756 */       loggerExternal.entering(getClassNameLogging(), "updateObject", new Object[] { columnName, obj, targetSqlType });
/*      */     }
/*      */     
/* 5759 */     checkClosed();
/*      */ 
/*      */     
/* 5762 */     updateObject(findColumn(columnName), obj, null, JDBCType.of(targetSqlType.getVendorTypeNumber().intValue()), null, false);
/*      */     
/* 5764 */     loggerExternal.exiting(getClassNameLogging(), "updateObject");
/*      */   }
/*      */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerResultSet.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */