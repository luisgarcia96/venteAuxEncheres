/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import java.io.InvalidObjectException;
/*    */ import java.io.ObjectInputStream;
/*    */ import java.io.ObjectStreamException;
/*    */ import java.io.Serializable;
/*    */ import java.sql.SQLException;
/*    */ import java.util.logging.Level;
/*    */ import javax.naming.Reference;
/*    */ import javax.sql.ConnectionPoolDataSource;
/*    */ import javax.sql.PooledConnection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SQLServerConnectionPoolDataSource
/*    */   extends SQLServerDataSource
/*    */   implements ConnectionPoolDataSource
/*    */ {
/*    */   public PooledConnection getPooledConnection() throws SQLException {
/* 26 */     if (loggerExternal.isLoggable(Level.FINER))
/* 27 */       loggerExternal.entering(getClassNameLogging(), "getPooledConnection"); 
/* 28 */     PooledConnection pcon = getPooledConnection(getUser(), getPassword());
/* 29 */     if (loggerExternal.isLoggable(Level.FINER))
/* 30 */       loggerExternal.exiting(getClassNameLogging(), "getPooledConnection", pcon); 
/* 31 */     return pcon;
/*    */   }
/*    */ 
/*    */   
/*    */   public PooledConnection getPooledConnection(String user, String password) throws SQLException {
/* 36 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 37 */       loggerExternal.entering(getClassNameLogging(), "getPooledConnection", new Object[] { user, "Password not traced" });
/*    */     }
/* 39 */     SQLServerPooledConnection pc = new SQLServerPooledConnection(this, user, password);
/* 40 */     if (loggerExternal.isLoggable(Level.FINER))
/* 41 */       loggerExternal.exiting(getClassNameLogging(), "getPooledConnection", pc); 
/* 42 */     return pc;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Reference getReference() {
/* 49 */     if (loggerExternal.isLoggable(Level.FINER))
/* 50 */       loggerExternal.entering(getClassNameLogging(), "getReference"); 
/* 51 */     Reference ref = getReferenceInternal("com.microsoft.sqlserver.jdbc.SQLServerConnectionPoolDataSource");
/* 52 */     if (loggerExternal.isLoggable(Level.FINER))
/* 53 */       loggerExternal.exiting(getClassNameLogging(), "getReference", ref); 
/* 54 */     return ref;
/*    */   }
/*    */   
/*    */   private Object writeReplace() throws ObjectStreamException {
/* 58 */     return new SerializationProxy(this);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private void readObject(ObjectInputStream stream) throws InvalidObjectException {
/* 64 */     throw new InvalidObjectException("");
/*    */   }
/*    */ 
/*    */   
/*    */   private static class SerializationProxy
/*    */     implements Serializable
/*    */   {
/*    */     private final Reference ref;
/*    */     
/*    */     private static final long serialVersionUID = 654661379842314126L;
/*    */ 
/*    */     
/*    */     SerializationProxy(SQLServerConnectionPoolDataSource ds) {
/* 77 */       this.ref = ds.getReferenceInternal(null);
/*    */     }
/*    */     
/*    */     private Object readResolve() {
/* 81 */       SQLServerConnectionPoolDataSource ds = new SQLServerConnectionPoolDataSource();
/* 82 */       ds.initializeFromReference(this.ref);
/* 83 */       return ds;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerConnectionPoolDataSource.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */