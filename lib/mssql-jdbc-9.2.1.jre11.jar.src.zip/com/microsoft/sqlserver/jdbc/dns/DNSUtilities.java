/*    */ package com.microsoft.sqlserver.jdbc.dns;
/*    */ 
/*    */ import java.util.Hashtable;
/*    */ import java.util.Set;
/*    */ import java.util.TreeSet;
/*    */ import java.util.logging.Level;
/*    */ import java.util.logging.Logger;
/*    */ import javax.naming.NamingEnumeration;
/*    */ import javax.naming.NamingException;
/*    */ import javax.naming.directory.Attribute;
/*    */ import javax.naming.directory.Attributes;
/*    */ import javax.naming.directory.DirContext;
/*    */ import javax.naming.directory.InitialDirContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DNSUtilities
/*    */ {
/* 26 */   private static final Logger LOG = Logger.getLogger(DNSUtilities.class.getName());
/*    */   
/* 28 */   private static final Level DNS_ERR_LOG_LEVEL = Level.FINE;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Set<DNSRecordSRV> findSrvRecords(String dnsSrvRecordToFind) throws NamingException {
/* 40 */     Hashtable<Object, Object> env = new Hashtable<>();
/* 41 */     env.put("java.naming.factory.initial", "com.sun.jndi.dns.DnsContextFactory");
/* 42 */     env.put("java.naming.provider.url", "dns:");
/* 43 */     DirContext ctx = new InitialDirContext(env);
/* 44 */     Attributes attrs = ctx.getAttributes(dnsSrvRecordToFind, new String[] { "SRV" });
/* 45 */     NamingEnumeration<? extends Attribute> allServers = attrs.getAll();
/* 46 */     TreeSet<DNSRecordSRV> records = new TreeSet<>();
/* 47 */     while (allServers.hasMoreElements()) {
/* 48 */       Attribute a = allServers.nextElement();
/* 49 */       NamingEnumeration<?> srvRecord = a.getAll();
/* 50 */       while (srvRecord.hasMore()) {
/* 51 */         String record = String.valueOf(srvRecord.nextElement());
/*    */         try {
/* 53 */           DNSRecordSRV rec = DNSRecordSRV.parseFromDNSRecord(record);
/* 54 */           if (rec != null) {
/* 55 */             records.add(rec);
/*    */           }
/* 57 */         } catch (IllegalArgumentException errorParsingRecord) {
/* 58 */           if (LOG.isLoggable(DNS_ERR_LOG_LEVEL)) {
/* 59 */             LOG.log(DNS_ERR_LOG_LEVEL, String.format("Failed to parse SRV DNS Record: '%s'", new Object[] { record }), errorParsingRecord);
/*    */           }
/*    */         } 
/*    */       } 
/*    */       
/* 64 */       srvRecord.close();
/*    */     } 
/* 66 */     allServers.close();
/* 67 */     return records;
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\dns\DNSUtilities.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */