/*    */ package com.microsoft.sqlserver.jdbc.dns;
/*    */ 
/*    */ import java.util.Set;
/*    */ import javax.naming.NameNotFoundException;
/*    */ import javax.naming.NamingException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DNSKerberosLocator
/*    */ {
/*    */   public static boolean isRealmValid(String realmName) throws NamingException {
/* 31 */     if (realmName == null || realmName.length() < 2) {
/* 32 */       return false;
/*    */     }
/* 34 */     if (realmName.charAt(0) == '.') {
/* 35 */       realmName = realmName.substring(1);
/*    */     }
/*    */     try {
/* 38 */       Set<DNSRecordSRV> records = DNSUtilities.findSrvRecords("_kerberos._udp." + realmName);
/* 39 */       return !records.isEmpty();
/* 40 */     } catch (NameNotFoundException wrongDomainException) {
/*    */       
/* 42 */       return false;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\dns\DNSKerberosLocator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */