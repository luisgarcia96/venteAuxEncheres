/*     */ package com.microsoft.sqlserver.jdbc.dns;
/*     */ 
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DNSRecordSRV
/*     */   implements Comparable<DNSRecordSRV>
/*     */ {
/*  16 */   private static final Pattern PATTERN = Pattern.compile("^([0-9]+) ([0-9]+) ([0-9]+) (.+)$");
/*     */ 
/*     */   
/*     */   private final int priority;
/*     */ 
/*     */   
/*     */   private final int weight;
/*     */   
/*     */   private final int port;
/*     */   
/*     */   private final String serverName;
/*     */ 
/*     */   
/*     */   public static DNSRecordSRV parseFromDNSRecord(String record) throws IllegalArgumentException {
/*  30 */     Matcher m = PATTERN.matcher(record);
/*  31 */     if (!m.matches()) {
/*  32 */       throw new IllegalArgumentException("record '" + record + "' cannot be matched as a valid DNS SRV Record");
/*     */     }
/*     */     try {
/*  35 */       int priority = Integer.parseInt(m.group(1));
/*  36 */       int weight = Integer.parseInt(m.group(2));
/*  37 */       int port = Integer.parseInt(m.group(3));
/*  38 */       String serverName = m.group(4);
/*     */       
/*  40 */       if (serverName.endsWith(".")) {
/*  41 */         serverName = serverName.substring(0, serverName.length() - 1);
/*     */       }
/*  43 */       return new DNSRecordSRV(priority, weight, port, serverName);
/*  44 */     } catch (IllegalArgumentException err) {
/*  45 */       throw err;
/*  46 */     } catch (Exception err) {
/*  47 */       throw new IllegalArgumentException("Failed to parse DNS SRV record '" + record + "'", err);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  53 */     return String.format("DNS.SRV[pri=%d w=%d port=%d h='%s']", new Object[] { Integer.valueOf(this.priority), Integer.valueOf(this.weight), Integer.valueOf(this.port), this.serverName });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DNSRecordSRV(int priority, int weight, int port, String serverName) throws IllegalArgumentException {
/*  71 */     if (priority < 0) {
/*  72 */       throw new IllegalArgumentException("priority must be >= 0, but was: " + priority);
/*     */     }
/*  74 */     this.priority = priority;
/*  75 */     if (weight < 0)
/*     */     {
/*  77 */       throw new IllegalArgumentException("weight must be >= 0, but was: " + weight);
/*     */     }
/*  79 */     this.weight = weight;
/*  80 */     if (port < 0 || port > 65535) {
/*  81 */       throw new IllegalArgumentException("port must be between 0 and 65535, but was: " + port);
/*     */     }
/*  83 */     this.port = port;
/*  84 */     if (serverName == null || serverName.trim().isEmpty()) {
/*  85 */       throw new IllegalArgumentException("hostname is not supposed to be null or empty in a SRV Record");
/*     */     }
/*  87 */     this.serverName = serverName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  96 */     return this.serverName.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object other) {
/* 101 */     if (other == this) {
/* 102 */       return true;
/*     */     }
/* 104 */     if (!(other instanceof DNSRecordSRV)) {
/* 105 */       return false;
/*     */     }
/*     */     
/* 108 */     DNSRecordSRV r = (DNSRecordSRV)other;
/* 109 */     return (this.port == r.port && this.weight == r.weight && this.priority == r.priority && this.serverName.equals(r.serverName));
/*     */   }
/*     */ 
/*     */   
/*     */   public int compareTo(DNSRecordSRV o) {
/* 114 */     if (o == null) {
/* 115 */       return 1;
/*     */     }
/* 117 */     int p = Integer.compare(this.priority, o.priority);
/* 118 */     if (p != 0) {
/* 119 */       return p;
/*     */     }
/* 121 */     p = Integer.compare(this.weight, o.weight);
/* 122 */     if (p != 0) {
/* 123 */       return p;
/*     */     }
/* 125 */     p = Integer.compare(this.port, o.port);
/* 126 */     if (p != 0) {
/* 127 */       return p;
/*     */     }
/* 129 */     return this.serverName.compareTo(o.serverName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPriority() {
/* 138 */     return this.priority;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getWeight() {
/* 147 */     return this.weight;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPort() {
/* 156 */     return this.port;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getServerName() {
/* 165 */     return this.serverName;
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\dns\DNSRecordSRV.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */