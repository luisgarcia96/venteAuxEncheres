/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ActivityCorrelator
/*    */ {
/* 18 */   private static Map<Long, ActivityId> activityIdTlsMap = new ConcurrentHashMap<>();
/*    */ 
/*    */   
/*    */   static void cleanupActivityId() {
/* 22 */     activityIdTlsMap.entrySet().removeIf(e -> (null == e.getValue() || null == ((ActivityId)e.getValue()).getThread() || ((ActivityId)e.getValue()).getThread() == Thread.currentThread() || !((ActivityId)e.getValue()).getThread().isAlive()));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static ActivityId getCurrent() {
/* 29 */     Thread thread = Thread.currentThread();
/* 30 */     if (!activityIdTlsMap.containsKey(Long.valueOf(thread.getId()))) {
/* 31 */       activityIdTlsMap.put(Long.valueOf(thread.getId()), new ActivityId(thread));
/*    */     }
/*    */     
/* 34 */     return activityIdTlsMap.get(Long.valueOf(thread.getId()));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static ActivityId getNext() {
/* 41 */     ActivityId activityId = getCurrent();
/*    */ 
/*    */     
/* 44 */     activityId.increment();
/*    */     
/* 46 */     return activityId;
/*    */   }
/*    */   
/*    */   static void setCurrentActivityIdSentFlag() {
/* 50 */     ActivityId activityId = getCurrent();
/* 51 */     activityId.setSentFlag();
/*    */   }
/*    */   
/*    */   static Map<Long, ActivityId> getActivityIdTlsMap() {
/* 55 */     return activityIdTlsMap;
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\ActivityCorrelator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */