/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.io.BufferedReader;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStreamReader;
/*      */ import java.io.Reader;
/*      */ import java.io.StringReader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.nio.charset.Charset;
/*      */ import java.nio.charset.StandardCharsets;
/*      */ import java.sql.Date;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.text.MessageFormat;
/*      */ import java.time.LocalDateTime;
/*      */ import java.util.Calendar;
/*      */ import java.util.GregorianCalendar;
/*      */ import java.util.Locale;
/*      */ import java.util.TimeZone;
/*      */ import microsoft.sql.DateTimeOffset;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class DDC
/*      */ {
/*      */   static final Object convertIntegerToObject(int intValue, int valueLength, JDBCType jdbcType, StreamType streamType) {
/*   52 */     switch (jdbcType) {
/*      */       case BINARY:
/*   54 */         return Integer.valueOf(intValue);
/*      */       case SQL_VARIANT:
/*      */       case DATE:
/*   57 */         return Short.valueOf((short)intValue);
/*      */       case TIME:
/*      */       case TIMESTAMP:
/*   60 */         return Boolean.valueOf((0 != intValue));
/*      */       case DATETIMEOFFSET:
/*   62 */         return Long.valueOf(intValue);
/*      */       case CHARACTER:
/*      */       case null:
/*      */       case null:
/*      */       case null:
/*   67 */         return new BigDecimal(Integer.toString(intValue));
/*      */       case null:
/*      */       case null:
/*   70 */         return Double.valueOf(intValue);
/*      */       case null:
/*   72 */         return Float.valueOf(intValue);
/*      */       case null:
/*   74 */         return convertIntToBytes(intValue, valueLength);
/*      */ 
/*      */ 
/*      */       
/*      */       case null:
/*   79 */         if (valueLength == 1)
/*   80 */           return Boolean.valueOf((0 != intValue)); 
/*   81 */         if (valueLength == 3 || valueLength == 4) {
/*   82 */           return Short.valueOf((short)intValue);
/*      */         }
/*   84 */         return Integer.valueOf(intValue);
/*      */     } 
/*      */     
/*   87 */     return Integer.toString(intValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final Object convertLongToObject(long longVal, JDBCType jdbcType, SSType baseSSType, StreamType streamType) {
/*      */     byte[] convertedBytes;
/*      */     int bytesToReturnLength;
/*      */     byte[] bytesToReturn;
/*  105 */     switch (jdbcType) {
/*      */       case DATETIMEOFFSET:
/*      */       case null:
/*  108 */         return Long.valueOf(longVal);
/*      */       case BINARY:
/*  110 */         return Integer.valueOf((int)longVal);
/*      */       case SQL_VARIANT:
/*      */       case DATE:
/*  113 */         return Short.valueOf((short)(int)longVal);
/*      */       case TIME:
/*      */       case TIMESTAMP:
/*  116 */         return Boolean.valueOf((0L != longVal));
/*      */       case CHARACTER:
/*      */       case null:
/*      */       case null:
/*      */       case null:
/*  121 */         return new BigDecimal(Long.toString(longVal));
/*      */       case null:
/*      */       case null:
/*  124 */         return Double.valueOf(longVal);
/*      */       case null:
/*  126 */         return Float.valueOf((float)longVal);
/*      */       case null:
/*  128 */         convertedBytes = convertLongToBytes(longVal);
/*      */ 
/*      */ 
/*      */         
/*  132 */         switch (baseSSType) {
/*      */           case BINARY:
/*      */           case SQL_VARIANT:
/*  135 */             bytesToReturnLength = 1;
/*  136 */             bytesToReturn = new byte[bytesToReturnLength];
/*  137 */             System.arraycopy(convertedBytes, convertedBytes.length - bytesToReturnLength, bytesToReturn, 0, bytesToReturnLength);
/*      */             
/*  139 */             return bytesToReturn;
/*      */           case DATE:
/*  141 */             bytesToReturnLength = 2;
/*  142 */             bytesToReturn = new byte[bytesToReturnLength];
/*  143 */             System.arraycopy(convertedBytes, convertedBytes.length - bytesToReturnLength, bytesToReturn, 0, bytesToReturnLength);
/*      */             
/*  145 */             return bytesToReturn;
/*      */           case TIME:
/*  147 */             bytesToReturnLength = 4;
/*  148 */             bytesToReturn = new byte[bytesToReturnLength];
/*  149 */             System.arraycopy(convertedBytes, convertedBytes.length - bytesToReturnLength, bytesToReturn, 0, bytesToReturnLength);
/*      */             
/*  151 */             return bytesToReturn;
/*      */           case TIMESTAMP:
/*  153 */             bytesToReturnLength = 8;
/*  154 */             bytesToReturn = new byte[bytesToReturnLength];
/*  155 */             System.arraycopy(convertedBytes, convertedBytes.length - bytesToReturnLength, bytesToReturn, 0, bytesToReturnLength);
/*      */             
/*  157 */             return bytesToReturn;
/*      */         } 
/*  159 */         return convertedBytes;
/*      */ 
/*      */       
/*      */       case null:
/*  163 */         switch (baseSSType) {
/*      */           case TIMESTAMP:
/*  165 */             return Long.valueOf(longVal);
/*      */           case TIME:
/*  167 */             return Integer.valueOf((int)longVal);
/*      */           case SQL_VARIANT:
/*      */           case DATE:
/*  170 */             return Short.valueOf((short)(int)longVal);
/*      */           case BINARY:
/*  172 */             return Boolean.valueOf((0L != longVal));
/*      */           case DATETIMEOFFSET:
/*      */           case CHARACTER:
/*      */           case null:
/*      */           case null:
/*  177 */             return new BigDecimal(Long.toString(longVal));
/*      */           case null:
/*  179 */             return Double.valueOf(longVal);
/*      */           case null:
/*  181 */             return Float.valueOf((float)longVal);
/*      */           case null:
/*  183 */             return convertLongToBytes(longVal);
/*      */         } 
/*  185 */         return Long.toString(longVal);
/*      */     } 
/*      */     
/*  188 */     return Long.toString(longVal);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final byte[] convertIntToBytes(int intValue, int valueLength) {
/*  202 */     byte[] bytes = new byte[valueLength];
/*  203 */     for (int i = valueLength; i-- > 0; ) {
/*  204 */       bytes[i] = (byte)(intValue & 0xFF);
/*  205 */       intValue >>= 8;
/*      */     } 
/*  207 */     return bytes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final Object convertFloatToObject(float floatVal, JDBCType jdbcType, StreamType streamType) {
/*  222 */     switch (jdbcType) {
/*      */       case null:
/*      */       case null:
/*  225 */         return Float.valueOf(floatVal);
/*      */       case BINARY:
/*  227 */         return Integer.valueOf((int)floatVal);
/*      */       case SQL_VARIANT:
/*      */       case DATE:
/*  230 */         return Short.valueOf((short)(int)floatVal);
/*      */       case TIME:
/*      */       case TIMESTAMP:
/*  233 */         return Boolean.valueOf((0 != Float.compare(0.0F, floatVal)));
/*      */       case DATETIMEOFFSET:
/*  235 */         return Long.valueOf((long)floatVal);
/*      */       case CHARACTER:
/*      */       case null:
/*      */       case null:
/*      */       case null:
/*  240 */         return new BigDecimal(Float.toString(floatVal));
/*      */       case null:
/*      */       case null:
/*  243 */         return Double.valueOf(Float.valueOf(floatVal).doubleValue());
/*      */       case null:
/*  245 */         return convertIntToBytes(Float.floatToRawIntBits(floatVal), 4);
/*      */     } 
/*  247 */     return Float.toString(floatVal);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final byte[] convertLongToBytes(long longValue) {
/*  259 */     byte[] bytes = new byte[8];
/*  260 */     for (int i = 8; i-- > 0; ) {
/*  261 */       bytes[i] = (byte)(int)(longValue & 0xFFL);
/*  262 */       longValue >>= 8L;
/*      */     } 
/*  264 */     return bytes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final Object convertDoubleToObject(double doubleVal, JDBCType jdbcType, StreamType streamType) {
/*  279 */     switch (jdbcType) {
/*      */       case null:
/*      */       case null:
/*      */       case null:
/*  283 */         return Double.valueOf(doubleVal);
/*      */       case null:
/*  285 */         return Float.valueOf(Double.valueOf(doubleVal).floatValue());
/*      */       case BINARY:
/*  287 */         return Integer.valueOf((int)doubleVal);
/*      */       case SQL_VARIANT:
/*      */       case DATE:
/*  290 */         return Short.valueOf((short)(int)doubleVal);
/*      */       case TIME:
/*      */       case TIMESTAMP:
/*  293 */         return Boolean.valueOf((0 != Double.compare(0.0D, doubleVal)));
/*      */       case DATETIMEOFFSET:
/*  295 */         return Long.valueOf((long)doubleVal);
/*      */       case CHARACTER:
/*      */       case null:
/*      */       case null:
/*      */       case null:
/*  300 */         return new BigDecimal(Double.toString(doubleVal));
/*      */       case null:
/*  302 */         return convertLongToBytes(Double.doubleToRawLongBits(doubleVal));
/*      */     } 
/*  304 */     return Double.toString(doubleVal);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static final byte[] convertBigDecimalToBytes(BigDecimal bigDecimalVal, int scale) {
/*      */     byte[] valueBytes;
/*  311 */     if (bigDecimalVal == null) {
/*  312 */       valueBytes = new byte[2];
/*  313 */       valueBytes[0] = (byte)scale;
/*  314 */       valueBytes[1] = 0;
/*      */     } else {
/*  316 */       boolean isNegative = (bigDecimalVal.signum() < 0);
/*      */ 
/*      */       
/*  319 */       if (bigDecimalVal.scale() < 0) {
/*  320 */         bigDecimalVal = bigDecimalVal.setScale(0);
/*      */       }
/*  322 */       BigInteger bi = bigDecimalVal.unscaledValue();
/*      */       
/*  324 */       if (isNegative) {
/*  325 */         bi = bi.negate();
/*      */       }
/*  327 */       byte[] unscaledBytes = bi.toByteArray();
/*      */       
/*  329 */       valueBytes = new byte[unscaledBytes.length + 3];
/*  330 */       int j = 0;
/*  331 */       valueBytes[j++] = (byte)bigDecimalVal.scale();
/*  332 */       valueBytes[j++] = (byte)(unscaledBytes.length + 1);
/*  333 */       valueBytes[j++] = (byte)(isNegative ? 0 : 1);
/*  334 */       for (int i = unscaledBytes.length - 1; i >= 0; i--) {
/*  335 */         valueBytes[j++] = unscaledBytes[i];
/*      */       }
/*      */     } 
/*  338 */     return valueBytes;
/*      */   }
/*      */   
/*      */   static final byte[] convertMoneyToBytes(BigDecimal bigDecimalVal, int bLength) {
/*  342 */     byte[] valueBytes = new byte[bLength];
/*      */     
/*  344 */     BigInteger bi = bigDecimalVal.unscaledValue();
/*      */     
/*  346 */     if (bLength == 8) {
/*      */       
/*  348 */       byte[] longbArray = new byte[bLength];
/*  349 */       Util.writeLong(bi.longValue(), longbArray, 0);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  355 */       System.arraycopy(longbArray, 0, valueBytes, 4, 4);
/*  356 */       System.arraycopy(longbArray, 4, valueBytes, 0, 4);
/*      */     } else {
/*      */       
/*  359 */       Util.writeInt(bi.intValue(), valueBytes, 0);
/*      */     } 
/*      */     
/*  362 */     return valueBytes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final Object convertBigDecimalToObject(BigDecimal bigDecimalVal, JDBCType jdbcType, StreamType streamType) {
/*  377 */     switch (jdbcType) {
/*      */       case CHARACTER:
/*      */       case null:
/*      */       case null:
/*      */       case null:
/*      */       case null:
/*  383 */         return bigDecimalVal;
/*      */       case null:
/*      */       case null:
/*  386 */         return Double.valueOf(bigDecimalVal.doubleValue());
/*      */       case null:
/*  388 */         return Float.valueOf(bigDecimalVal.floatValue());
/*      */       case BINARY:
/*  390 */         return Integer.valueOf(bigDecimalVal.intValue());
/*      */       case SQL_VARIANT:
/*      */       case DATE:
/*  393 */         return Short.valueOf(bigDecimalVal.shortValue());
/*      */       case TIME:
/*      */       case TIMESTAMP:
/*  396 */         return Boolean.valueOf((0 != bigDecimalVal.compareTo(BigDecimal.valueOf(0L))));
/*      */       case DATETIMEOFFSET:
/*  398 */         return Long.valueOf(bigDecimalVal.longValue());
/*      */       case null:
/*  400 */         return convertBigDecimalToBytes(bigDecimalVal, bigDecimalVal.scale());
/*      */     } 
/*  402 */     return bigDecimalVal.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final Object convertMoneyToObject(BigDecimal bigDecimalVal, JDBCType jdbcType, StreamType streamType, int numberOfBytes) {
/*  421 */     switch (jdbcType) {
/*      */       case CHARACTER:
/*      */       case null:
/*      */       case null:
/*      */       case null:
/*  426 */         return bigDecimalVal;
/*      */       case null:
/*      */       case null:
/*  429 */         return Double.valueOf(bigDecimalVal.doubleValue());
/*      */       case null:
/*  431 */         return Float.valueOf(bigDecimalVal.floatValue());
/*      */       case BINARY:
/*  433 */         return Integer.valueOf(bigDecimalVal.intValue());
/*      */       case SQL_VARIANT:
/*      */       case DATE:
/*  436 */         return Short.valueOf(bigDecimalVal.shortValue());
/*      */       case TIME:
/*      */       case TIMESTAMP:
/*  439 */         return Boolean.valueOf((0 != bigDecimalVal.compareTo(BigDecimal.valueOf(0L))));
/*      */       case DATETIMEOFFSET:
/*  441 */         return Long.valueOf(bigDecimalVal.longValue());
/*      */       case null:
/*  443 */         return convertToBytes(bigDecimalVal, bigDecimalVal.scale(), numberOfBytes);
/*      */     } 
/*  445 */     return bigDecimalVal.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static byte[] convertToBytes(BigDecimal value, int scale, int numBytes) {
/*  451 */     boolean isNeg = (value.signum() < 0);
/*      */     
/*  453 */     value = value.setScale(scale);
/*      */     
/*  455 */     BigInteger bigInt = value.unscaledValue();
/*      */     
/*  457 */     byte[] unscaledBytes = bigInt.toByteArray();
/*      */     
/*  459 */     byte[] ret = new byte[numBytes];
/*  460 */     if (unscaledBytes.length < numBytes) {
/*  461 */       for (int i = 0; i < numBytes - unscaledBytes.length; i++) {
/*  462 */         ret[i] = (byte)(isNeg ? -1 : 0);
/*      */       }
/*      */     }
/*  465 */     int offset = numBytes - unscaledBytes.length;
/*  466 */     System.arraycopy(unscaledBytes, 0, ret, offset, numBytes - offset);
/*  467 */     return ret;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final Object convertBytesToObject(byte[] bytesValue, JDBCType jdbcType, TypeInfo baseTypeInfo) throws SQLServerException {
/*      */     String str;
/*  485 */     switch (jdbcType) {
/*      */       case null:
/*  487 */         str = Util.bytesToHexString(bytesValue, bytesValue.length);
/*      */         
/*  489 */         if (SSType.BINARY == baseTypeInfo.getSSType() && str.length() < baseTypeInfo.getPrecision() * 2) {
/*      */           
/*  491 */           StringBuilder strbuf = new StringBuilder(str);
/*      */           
/*  493 */           while (strbuf.length() < baseTypeInfo.getPrecision() * 2) {
/*  494 */             strbuf.append('0');
/*      */           }
/*  496 */           return strbuf.toString();
/*      */         } 
/*  498 */         return str;
/*      */       
/*      */       case null:
/*      */       case null:
/*      */       case null:
/*  503 */         if (SSType.BINARY == baseTypeInfo.getSSType() && bytesValue.length < baseTypeInfo.getPrecision()) {
/*      */           
/*  505 */           byte[] newBytes = new byte[baseTypeInfo.getPrecision()];
/*  506 */           System.arraycopy(bytesValue, 0, newBytes, 0, bytesValue.length);
/*  507 */           return newBytes;
/*      */         } 
/*      */         
/*  510 */         return bytesValue;
/*      */     } 
/*      */ 
/*      */     
/*  514 */     MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_unsupportedConversionFromTo"));
/*  515 */     throw new SQLServerException(form.format(new Object[] { baseTypeInfo.getSSType().name(), jdbcType }, ), null, 0, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final Object convertStringToObject(String stringVal, Charset charset, JDBCType jdbcType, StreamType streamType) throws UnsupportedEncodingException, IllegalArgumentException {
/*      */     String trimmedString;
/*      */     Timestamp ts;
/*      */     GregorianCalendar cal;
/*  533 */     switch (jdbcType) {
/*      */       
/*      */       case CHARACTER:
/*      */       case null:
/*      */       case null:
/*      */       case null:
/*  539 */         return new BigDecimal(stringVal.trim());
/*      */       case null:
/*      */       case null:
/*  542 */         return Double.valueOf(stringVal.trim());
/*      */       case null:
/*  544 */         return Float.valueOf(stringVal.trim());
/*      */       case BINARY:
/*  546 */         return Integer.valueOf(stringVal.trim());
/*      */       case SQL_VARIANT:
/*      */       case DATE:
/*  549 */         return Short.valueOf(stringVal.trim());
/*      */       case TIME:
/*      */       case TIMESTAMP:
/*  552 */         trimmedString = stringVal.trim();
/*  553 */         return (1 == trimmedString.length()) ? Boolean.valueOf(('1' == trimmedString.charAt(0))) : 
/*  554 */           Boolean.valueOf(trimmedString);
/*      */       case DATETIMEOFFSET:
/*  556 */         return Long.valueOf(stringVal.trim());
/*      */ 
/*      */       
/*      */       case null:
/*  560 */         return Timestamp.valueOf(stringVal.trim());
/*      */       case null:
/*  562 */         return parseStringIntoLDT(stringVal.trim());
/*      */       case null:
/*  564 */         return Date.valueOf(getDatePart(stringVal.trim()));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case null:
/*  575 */         ts = Timestamp.valueOf("1970-01-01 " + getTimePart(stringVal.trim()));
/*  576 */         cal = new GregorianCalendar(Locale.US);
/*  577 */         cal.clear();
/*  578 */         cal.setTimeInMillis(ts.getTime());
/*  579 */         if (ts.getNanos() % 1000000 >= 500000)
/*  580 */           cal.add(14, 1); 
/*  581 */         cal.set(1970, 0, 1);
/*  582 */         return new Time(cal.getTimeInMillis());
/*      */ 
/*      */       
/*      */       case null:
/*  586 */         return stringVal.getBytes(charset);
/*      */     } 
/*      */ 
/*      */     
/*  590 */     switch (streamType) {
/*      */       case BINARY:
/*  592 */         return new StringReader(stringVal);
/*      */       case SQL_VARIANT:
/*  594 */         return new ByteArrayInputStream(stringVal.getBytes(StandardCharsets.US_ASCII));
/*      */       case DATE:
/*  596 */         return new ByteArrayInputStream(stringVal.getBytes());
/*      */     } 
/*      */     
/*  599 */     return stringVal;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static LocalDateTime parseStringIntoLDT(String s) {
/*  612 */     int hour, minute, second, YEAR_LENGTH = 4;
/*  613 */     int MONTH_LENGTH = 2;
/*  614 */     int DAY_LENGTH = 2;
/*  615 */     int MAX_MONTH = 12;
/*  616 */     int MAX_DAY = 31;
/*  617 */     int year = 0;
/*  618 */     int month = 0;
/*  619 */     int day = 0;
/*      */ 
/*      */ 
/*      */     
/*  623 */     int a_nanos = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  630 */     String formatError = "Timestamp format must be yyyy-mm-dd hh:mm:ss[.fffffffff]";
/*      */     
/*  632 */     if (s == null) {
/*  633 */       throw new IllegalArgumentException("null string");
/*      */     }
/*      */     
/*  636 */     s = s.trim();
/*  637 */     int dividingSpace = s.indexOf(' ');
/*  638 */     if (dividingSpace < 0) {
/*  639 */       throw new IllegalArgumentException(formatError);
/*      */     }
/*      */ 
/*      */     
/*  643 */     int firstDash = s.indexOf('-');
/*  644 */     int secondDash = s.indexOf('-', firstDash + 1);
/*      */ 
/*      */     
/*  647 */     int firstColon = s.indexOf(':', dividingSpace + 1);
/*  648 */     int secondColon = s.indexOf(':', firstColon + 1);
/*  649 */     int period = s.indexOf('.', secondColon + 1);
/*      */ 
/*      */     
/*  652 */     boolean parsedDate = false;
/*  653 */     if (firstDash > 0 && secondDash > 0 && secondDash < dividingSpace - 1 && 
/*  654 */       firstDash == 4 && secondDash - firstDash > 1 && secondDash - firstDash <= 3 && dividingSpace - secondDash > 1 && dividingSpace - secondDash <= 3) {
/*      */       
/*  656 */       year = Integer.parseInt(s.substring(0, firstDash));
/*  657 */       month = Integer.parseInt(s.substring(firstDash + 1, secondDash));
/*  658 */       day = Integer.parseInt(s.substring(secondDash + 1, dividingSpace));
/*      */       
/*  660 */       if (month >= 1 && month <= 12 && day >= 1 && day <= 31) {
/*  661 */         parsedDate = true;
/*      */       }
/*      */     } 
/*      */     
/*  665 */     if (!parsedDate) {
/*  666 */       throw new IllegalArgumentException(formatError);
/*      */     }
/*      */ 
/*      */     
/*  670 */     int len = s.length();
/*  671 */     if (firstColon > 0 && secondColon > 0 && secondColon < len - 1) {
/*  672 */       hour = Integer.parseInt(s.substring(dividingSpace + 1, firstColon));
/*  673 */       minute = Integer.parseInt(s.substring(firstColon + 1, secondColon));
/*  674 */       if (period > 0 && period < len - 1)
/*  675 */       { second = Integer.parseInt(s.substring(secondColon + 1, period));
/*  676 */         int nanoPrecision = len - period + 1;
/*  677 */         if (nanoPrecision > 9)
/*  678 */           throw new IllegalArgumentException(formatError); 
/*  679 */         if (!Character.isDigit(s.charAt(period + 1)))
/*  680 */           throw new IllegalArgumentException(formatError); 
/*  681 */         int tmpNanos = Integer.parseInt(s.substring(period + 1, len));
/*  682 */         while (nanoPrecision < 9) {
/*  683 */           tmpNanos *= 10;
/*  684 */           nanoPrecision++;
/*      */         } 
/*  686 */         a_nanos = tmpNanos; }
/*  687 */       else { if (period > 0) {
/*  688 */           throw new IllegalArgumentException(formatError);
/*      */         }
/*  690 */         second = Integer.parseInt(s.substring(secondColon + 1, len)); }
/*      */     
/*      */     } else {
/*  693 */       throw new IllegalArgumentException(formatError);
/*      */     } 
/*  695 */     return LocalDateTime.of(year, month, day, hour, minute, second, a_nanos);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final Object convertStreamToObject(BaseInputStream stream, TypeInfo typeInfo, JDBCType jdbcType, InputStreamGetterArgs getterArgs) throws SQLServerException {
/*  702 */     if (null == stream) {
/*  703 */       return null;
/*      */     }
/*  705 */     assert null != typeInfo;
/*  706 */     assert null != getterArgs;
/*      */     
/*  708 */     SSType ssType = typeInfo.getSSType();
/*      */     
/*      */     try {
/*  711 */       switch (jdbcType) {
/*      */         case null:
/*  713 */           return new SQLServerClob(stream, typeInfo);
/*      */         case null:
/*  715 */           return new SQLServerNClob(stream, typeInfo);
/*      */         case null:
/*  717 */           return new SQLServerSQLXML(stream, getterArgs, typeInfo);
/*      */         
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*  723 */           if (StreamType.BINARY == getterArgs.streamType)
/*  724 */             return stream; 
/*  725 */           if (JDBCType.BLOB == jdbcType)
/*  726 */             return new SQLServerBlob(stream); 
/*  727 */           return stream.getBytes();
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  738 */       if (SSType.BINARY == ssType || SSType.VARBINARY == ssType || SSType.VARBINARYMAX == ssType || SSType.TIMESTAMP == ssType || SSType.IMAGE == ssType || SSType.UDT == ssType) {
/*      */         
/*  740 */         if (StreamType.ASCII == getterArgs.streamType) {
/*  741 */           return stream;
/*      */         }
/*  743 */         assert StreamType.CHARACTER == getterArgs.streamType || StreamType.NONE == getterArgs.streamType;
/*      */ 
/*      */         
/*  746 */         byte[] byteValue = stream.getBytes();
/*  747 */         if (JDBCType.GUID == jdbcType)
/*  748 */           return Util.readGUID(byteValue); 
/*  749 */         if (JDBCType.GEOMETRY == jdbcType) {
/*  750 */           if (!typeInfo.getSSTypeName().equalsIgnoreCase(jdbcType.toString())) {
/*  751 */             DataTypes.throwConversionError(typeInfo.getSSTypeName().toUpperCase(), jdbcType
/*  752 */                 .toString());
/*      */           }
/*  754 */           return Geometry.STGeomFromWKB(byteValue);
/*  755 */         }  if (JDBCType.GEOGRAPHY == jdbcType) {
/*  756 */           if (!typeInfo.getSSTypeName().equalsIgnoreCase(jdbcType.toString())) {
/*  757 */             DataTypes.throwConversionError(typeInfo.getSSTypeName().toUpperCase(), jdbcType
/*  758 */                 .toString());
/*      */           }
/*  760 */           return Geography.STGeomFromWKB(byteValue);
/*      */         } 
/*  762 */         String hexString = Util.bytesToHexString(byteValue, byteValue.length);
/*      */         
/*  764 */         if (StreamType.NONE == getterArgs.streamType) {
/*  765 */           return hexString;
/*      */         }
/*  767 */         return new StringReader(hexString);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  773 */       if (StreamType.ASCII == getterArgs.streamType) {
/*      */         
/*  775 */         if (typeInfo.supportsFastAsciiConversion()) {
/*  776 */           return new AsciiFilteredInputStream(stream);
/*      */         }
/*      */         
/*  779 */         if (getterArgs.isAdaptive) {
/*  780 */           return AsciiFilteredUnicodeInputStream.MakeAsciiFilteredUnicodeInputStream(stream, new BufferedReader(new InputStreamReader(stream, typeInfo
/*  781 */                   .getCharset())));
/*      */         }
/*  783 */         return new ByteArrayInputStream((new String(stream
/*  784 */               .getBytes(), typeInfo.getCharset())).getBytes(StandardCharsets.US_ASCII));
/*      */       } 
/*  786 */       if (StreamType.CHARACTER == getterArgs.streamType || StreamType.NCHARACTER == getterArgs.streamType) {
/*      */         
/*  788 */         if (getterArgs.isAdaptive) {
/*  789 */           return new BufferedReader(new InputStreamReader(stream, typeInfo.getCharset()));
/*      */         }
/*  791 */         return new StringReader(new String(stream.getBytes(), typeInfo.getCharset()));
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  796 */       return convertStringToObject(new String(stream.getBytes(), typeInfo.getCharset()), typeInfo
/*  797 */           .getCharset(), jdbcType, getterArgs.streamType);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*  809 */     catch (IllegalArgumentException e) {
/*  810 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_errorConvertingValue"));
/*  811 */       throw new SQLServerException(form.format(new Object[] { typeInfo.getSSType(), jdbcType }, ), null, 0, e);
/*  812 */     } catch (UnsupportedEncodingException e) {
/*  813 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_errorConvertingValue"));
/*  814 */       throw new SQLServerException(form.format(new Object[] { typeInfo.getSSType(), jdbcType }, ), null, 0, e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static String getDatePart(String s) {
/*  821 */     int sp = s.indexOf(' ');
/*  822 */     if (-1 == sp)
/*  823 */       return s; 
/*  824 */     return s.substring(0, sp);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static String getTimePart(String s) {
/*  830 */     int sp = s.indexOf(' ');
/*  831 */     if (-1 == sp)
/*  832 */       return s; 
/*  833 */     return s.substring(sp + 1);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static String fractionalSecondsString(long subSecondNanos, int scale) {
/*  839 */     assert 0L <= subSecondNanos && subSecondNanos < 1000000000L;
/*  840 */     assert 0 <= scale && scale <= 7;
/*      */ 
/*      */ 
/*      */     
/*  844 */     if (0 == scale) {
/*  845 */       return "";
/*      */     }
/*  847 */     return BigDecimal.valueOf(subSecondNanos % 1000000000L, 9).setScale(scale).toPlainString()
/*  848 */       .substring(1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final Object convertTemporalToObject(JDBCType jdbcType, SSType ssType, Calendar timeZoneCalendar, int daysSinceBaseDate, long ticksSinceMidnight, int fractionalSecondsScale) {
/*      */     int subSecondNanos;
/*      */     Timestamp ts;
/*      */     int unsignedMinutesOffset;
/*  896 */     if (null == timeZoneCalendar) {
/*  897 */       return convertTemporalToObject(jdbcType, ssType, daysSinceBaseDate, ticksSinceMidnight, fractionalSecondsScale);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  903 */     TimeZone localTimeZone = timeZoneCalendar.getTimeZone();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  909 */     TimeZone componentTimeZone = (SSType.DATETIMEOFFSET == ssType) ? UTC.timeZone : localTimeZone;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  915 */     GregorianCalendar cal = new GregorianCalendar(componentTimeZone, Locale.US);
/*      */ 
/*      */ 
/*      */     
/*  919 */     cal.setLenient(true);
/*      */ 
/*      */ 
/*      */     
/*  923 */     cal.clear();
/*      */ 
/*      */ 
/*      */     
/*  927 */     switch (ssType) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case null:
/*  939 */         cal.set(1900, 0, 1, 0, 0, 0);
/*  940 */         cal.set(14, (int)(ticksSinceMidnight / 1000000L));
/*      */         
/*  942 */         subSecondNanos = (int)(ticksSinceMidnight % 1000000000L);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case null:
/*      */       case null:
/*      */       case null:
/*  955 */         if (daysSinceBaseDate >= GregorianChange.DAYS_SINCE_BASE_DATE_HINT) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  961 */           cal.set(1, 0, 1 + daysSinceBaseDate + GregorianChange.EXTRA_DAYS_TO_BE_ADDED, 0, 0, 0);
/*      */           
/*  963 */           cal.set(14, (int)(ticksSinceMidnight / 1000000L));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         }
/*      */         else {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  976 */           cal.setGregorianChange(GregorianChange.PURE_CHANGE_DATE);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  982 */           cal.set(1, 0, 1 + daysSinceBaseDate, 0, 0, 0);
/*  983 */           cal.set(14, (int)(ticksSinceMidnight / 1000000L));
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  988 */           int year = cal.get(1);
/*  989 */           int month = cal.get(2);
/*  990 */           int date = cal.get(5);
/*  991 */           int hour = cal.get(11);
/*  992 */           int minute = cal.get(12);
/*  993 */           int second = cal.get(13);
/*  994 */           int millis = cal.get(14);
/*      */           
/*  996 */           cal.setGregorianChange(GregorianChange.STANDARD_CHANGE_DATE);
/*  997 */           cal.set(year, month, date, hour, minute, second);
/*  998 */           cal.set(14, millis);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1007 */         if (SSType.DATETIMEOFFSET == ssType && !componentTimeZone.hasSameRules(localTimeZone)) {
/* 1008 */           GregorianCalendar localCalendar = new GregorianCalendar(localTimeZone, Locale.US);
/* 1009 */           localCalendar.clear();
/* 1010 */           localCalendar.setTimeInMillis(cal.getTimeInMillis());
/* 1011 */           cal = localCalendar;
/*      */         } 
/*      */         
/* 1014 */         subSecondNanos = (int)(ticksSinceMidnight % 1000000000L);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case null:
/* 1029 */         cal.set(1900, 0, 1 + daysSinceBaseDate, 0, 0, 0);
/* 1030 */         cal.set(14, (int)ticksSinceMidnight);
/*      */         
/* 1032 */         subSecondNanos = (int)(ticksSinceMidnight * 1000000L % 1000000000L);
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 1037 */         throw new AssertionError("Unexpected SSType: " + ssType);
/*      */     } 
/*      */     
/* 1040 */     int localMillisOffset = timeZoneCalendar.get(15);
/*      */ 
/*      */     
/* 1043 */     switch (jdbcType.category) {
/*      */       case BINARY:
/*      */       case SQL_VARIANT:
/* 1046 */         switch (ssType) {
/*      */ 
/*      */           
/*      */           case null:
/* 1050 */             cal.set(11, 0);
/* 1051 */             cal.set(12, 0);
/* 1052 */             cal.set(13, 0);
/* 1053 */             cal.set(14, 0);
/* 1054 */             return new Date(cal.getTimeInMillis());
/*      */ 
/*      */           
/*      */           case null:
/*      */           case null:
/* 1059 */             ts = new Timestamp(cal.getTimeInMillis());
/* 1060 */             ts.setNanos(subSecondNanos);
/* 1061 */             return ts;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case null:
/* 1067 */             assert SSType.DATETIMEOFFSET == ssType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1074 */             assert 0 == localMillisOffset % 60000;
/*      */             
/* 1076 */             ts = new Timestamp(cal.getTimeInMillis());
/* 1077 */             ts.setNanos(subSecondNanos);
/* 1078 */             return DateTimeOffset.valueOf(ts, localMillisOffset / 60000);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case null:
/* 1086 */             if (subSecondNanos % 1000000 >= 500000) {
/* 1087 */               cal.add(14, 1);
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1093 */             cal.set(1970, 0, 1);
/*      */             
/* 1095 */             return new Time(cal.getTimeInMillis());
/*      */         } 
/*      */ 
/*      */         
/* 1099 */         throw new AssertionError("Unexpected SSType: " + ssType);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case DATE:
/* 1106 */         cal.set(11, 0);
/* 1107 */         cal.set(12, 0);
/* 1108 */         cal.set(13, 0);
/* 1109 */         cal.set(14, 0);
/* 1110 */         return new Date(cal.getTimeInMillis());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case TIME:
/* 1118 */         if (subSecondNanos % 1000000 >= 500000) {
/* 1119 */           cal.add(14, 1);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1125 */         cal.set(1970, 0, 1);
/*      */         
/* 1127 */         return new Time(cal.getTimeInMillis());
/*      */ 
/*      */       
/*      */       case TIMESTAMP:
/* 1131 */         ts = new Timestamp(cal.getTimeInMillis());
/* 1132 */         ts.setNanos(subSecondNanos);
/* 1133 */         if (jdbcType == JDBCType.LOCALDATETIME) {
/* 1134 */           return ts.toLocalDateTime();
/*      */         }
/* 1136 */         return ts;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case DATETIMEOFFSET:
/* 1142 */         assert SSType.DATETIMEOFFSET == ssType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1149 */         assert 0 == localMillisOffset % 60000;
/*      */         
/* 1151 */         ts = new Timestamp(cal.getTimeInMillis());
/* 1152 */         ts.setNanos(subSecondNanos);
/* 1153 */         return DateTimeOffset.valueOf(ts, localMillisOffset / 60000);
/*      */ 
/*      */       
/*      */       case CHARACTER:
/* 1157 */         switch (ssType) {
/*      */           case null:
/* 1159 */             return String.format(Locale.US, "%1$tF", new Object[] { cal });
/*      */ 
/*      */ 
/*      */           
/*      */           case null:
/* 1164 */             return String.format(Locale.US, "%1$tT%2$s", new Object[] { cal, 
/* 1165 */                   fractionalSecondsString(subSecondNanos, fractionalSecondsScale) });
/*      */ 
/*      */           
/*      */           case null:
/* 1169 */             return String.format(Locale.US, "%1$tF %1$tT%2$s", new Object[] { cal, 
/* 1170 */                   fractionalSecondsString(subSecondNanos, fractionalSecondsScale) });
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case null:
/* 1176 */             assert 0 == localMillisOffset % 60000;
/*      */             
/* 1178 */             unsignedMinutesOffset = Math.abs(localMillisOffset / 60000);
/* 1179 */             return String.format(Locale.US, "%1$tF %1$tT%2$s %3$c%4$02d:%5$02d", new Object[] { cal, 
/*      */ 
/*      */                   
/* 1182 */                   fractionalSecondsString(subSecondNanos, fractionalSecondsScale), 
/* 1183 */                   Character.valueOf((localMillisOffset >= 0) ? 43 : 45), Integer.valueOf(unsignedMinutesOffset / 60), 
/* 1184 */                   Integer.valueOf(unsignedMinutesOffset % 60) });
/*      */ 
/*      */ 
/*      */           
/*      */           case null:
/* 1189 */             return (new Timestamp(cal.getTimeInMillis())).toString();
/*      */         } 
/*      */ 
/*      */         
/* 1193 */         throw new AssertionError("Unexpected SSType: " + ssType);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1198 */     throw new AssertionError("Unexpected JDBCType: " + jdbcType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Object convertTemporalToObject(JDBCType jdbcType, SSType ssType, int daysSinceBaseDate, long ticksSinceMidnight, int fractionalSecondsScale) {
/*      */     int subSecondNanos;
/*      */     Timestamp timestamp1;
/*      */     Time t;
/*      */     Timestamp ts;
/* 1210 */     LocalDateTime ldt = null;
/*      */     
/* 1212 */     switch (ssType) {
/*      */       case null:
/* 1214 */         ldt = LocalDateTime.of(1900, 1, 1, 0, 0, 0).plusNanos(ticksSinceMidnight);
/*      */         
/* 1216 */         subSecondNanos = (int)(ticksSinceMidnight % 1000000000L);
/*      */         break;
/*      */ 
/*      */       
/*      */       case null:
/*      */       case null:
/*      */       case null:
/* 1223 */         ldt = LocalDateTime.of(1, 1, 1, 0, 0, 0);
/* 1224 */         ldt = ldt.plusDays(daysSinceBaseDate);
/*      */         
/* 1226 */         if (jdbcType.category != JDBCType.Category.DATE) {
/* 1227 */           ldt = ldt.plusNanos(ticksSinceMidnight);
/*      */         }
/* 1229 */         subSecondNanos = (int)(ticksSinceMidnight % 1000000000L);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case null:
/* 1235 */         ldt = LocalDateTime.of(1900, 1, 1, 0, 0, 0);
/* 1236 */         ldt = ldt.plusDays(daysSinceBaseDate);
/*      */         
/* 1238 */         if (jdbcType.category != JDBCType.Category.DATE) {
/* 1239 */           ldt = ldt.plusNanos(ticksSinceMidnight * 1000000L);
/*      */         }
/*      */         
/* 1242 */         subSecondNanos = (int)(ticksSinceMidnight * 1000000L % 1000000000L);
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 1247 */         throw new AssertionError("Unexpected SSType: " + ssType);
/*      */     } 
/*      */     
/* 1250 */     switch (jdbcType.category) {
/*      */       case BINARY:
/*      */       case SQL_VARIANT:
/* 1253 */         switch (ssType) {
/*      */           case null:
/* 1255 */             return Date.valueOf(ldt.toLocalDate());
/*      */ 
/*      */           
/*      */           case null:
/*      */           case null:
/* 1260 */             timestamp1 = Timestamp.valueOf(ldt);
/* 1261 */             timestamp1.setNanos(subSecondNanos);
/* 1262 */             return timestamp1;
/*      */ 
/*      */           
/*      */           case null:
/* 1266 */             if (subSecondNanos % 1000000 >= 500000) {
/* 1267 */               ldt = ldt.plusNanos(1000000L);
/*      */             }
/* 1269 */             t = Time.valueOf(ldt.toLocalTime());
/* 1270 */             t.setTime(t.getTime() + (ldt.getNano() / 1000000));
/* 1271 */             return t;
/*      */         } 
/*      */ 
/*      */         
/* 1275 */         throw new AssertionError("Unexpected SSType: " + ssType);
/*      */ 
/*      */ 
/*      */       
/*      */       case DATE:
/* 1280 */         return Date.valueOf(ldt.toLocalDate());
/*      */ 
/*      */       
/*      */       case TIME:
/* 1284 */         if (subSecondNanos % 1000000 >= 500000) {
/* 1285 */           ldt = ldt.plusNanos(1000000L);
/*      */         }
/* 1287 */         t = Time.valueOf(ldt.toLocalTime());
/* 1288 */         t.setTime(t.getTime() + (ldt.getNano() / 1000000));
/* 1289 */         return t;
/*      */ 
/*      */       
/*      */       case TIMESTAMP:
/* 1293 */         if (jdbcType == JDBCType.LOCALDATETIME) {
/* 1294 */           return ldt;
/*      */         }
/*      */         
/* 1297 */         ts = Timestamp.valueOf(ldt);
/* 1298 */         ts.setNanos(subSecondNanos);
/* 1299 */         return ts;
/*      */ 
/*      */       
/*      */       case CHARACTER:
/* 1303 */         switch (ssType) {
/*      */           case null:
/* 1305 */             return String.format(Locale.US, "%1$tF", new Object[] {
/* 1306 */                   Timestamp.valueOf(ldt)
/*      */                 });
/*      */           
/*      */           case null:
/* 1310 */             return String.format(Locale.US, "%1$tT%2$s", new Object[] { ldt, 
/* 1311 */                   fractionalSecondsString(subSecondNanos, fractionalSecondsScale) });
/*      */ 
/*      */           
/*      */           case null:
/* 1315 */             return String.format(Locale.US, "%1$tF %1$tT%2$s", new Object[] {
/* 1316 */                   Timestamp.valueOf(ldt), 
/* 1317 */                   fractionalSecondsString(subSecondNanos, fractionalSecondsScale)
/*      */                 });
/*      */ 
/*      */           
/*      */           case null:
/* 1322 */             return Timestamp.valueOf(ldt).toString();
/*      */         } 
/*      */ 
/*      */         
/* 1326 */         throw new AssertionError("Unexpected SSType: " + ssType);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1331 */     throw new AssertionError("Unexpected JDBCType: " + jdbcType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static int daysSinceBaseDate(int year, int dayOfYear, int baseYear) {
/* 1340 */     assert year >= 1;
/* 1341 */     assert baseYear >= 1;
/* 1342 */     assert dayOfYear >= 1;
/*      */     
/* 1344 */     return dayOfYear - 1 + (year - baseYear) * 365 + 
/*      */       
/* 1346 */       leapDaysBeforeYear(year) - 
/* 1347 */       leapDaysBeforeYear(baseYear);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int leapDaysBeforeYear(int year) {
/* 1355 */     assert year >= 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1366 */     return (year - 1) / 4 - (year - 1) / 100 + (year - 1) / 400;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 1371 */   private static final BigInteger maxRPCDecimalValue = new BigInteger("99999999999999999999999999999999999999");
/*      */ 
/*      */ 
/*      */   
/*      */   static final boolean exceedsMaxRPCDecimalPrecisionOrScale(BigDecimal bigDecimalValue) {
/* 1376 */     if (null == bigDecimalValue) {
/* 1377 */       return false;
/*      */     }
/*      */     
/* 1380 */     if (bigDecimalValue.scale() > 38) {
/* 1381 */       return true;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1386 */     BigInteger bi = (bigDecimalValue.scale() < 0) ? bigDecimalValue.setScale(0).unscaledValue() : bigDecimalValue.unscaledValue();
/* 1387 */     if (bigDecimalValue.signum() < 0)
/* 1388 */       bi = bi.negate(); 
/* 1389 */     return (bi.compareTo(maxRPCDecimalValue) > 0);
/*      */   }
/*      */ 
/*      */   
/*      */   static String convertReaderToString(Reader reader, int readerLength) throws SQLServerException {
/* 1394 */     assert -1 == readerLength || readerLength >= 0;
/*      */ 
/*      */     
/* 1397 */     if (null == reader)
/* 1398 */       return null; 
/* 1399 */     if (0 == readerLength) {
/* 1400 */       return "";
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 1407 */       StringBuilder sb = new StringBuilder((-1 != readerLength) ? readerLength : 4000);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1413 */       char[] charArray = new char[(-1 != readerLength && readerLength < 4000) ? readerLength : 4000];
/*      */ 
/*      */       
/*      */       int readChars;
/*      */       
/* 1418 */       while ((readChars = reader.read(charArray, 0, charArray.length)) > 0) {
/*      */         
/* 1420 */         if (readChars > charArray.length) {
/* 1421 */           MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_errorReadingStream"));
/* 1422 */           Object[] msgArgs = { SQLServerException.getErrString("R_streamReadReturnedInvalidValue") };
/* 1423 */           SQLServerException.makeFromDriverError(null, null, form.format(msgArgs), "", true);
/*      */         } 
/*      */         
/* 1426 */         sb.append(charArray, 0, readChars);
/*      */       } 
/*      */       
/* 1429 */       return sb.toString();
/* 1430 */     } catch (IOException ioEx) {
/* 1431 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_errorReadingStream"));
/* 1432 */       Object[] msgArgs = { ioEx.toString() };
/* 1433 */       SQLServerException.makeFromDriverError(null, null, form.format(msgArgs), "", true);
/*      */ 
/*      */ 
/*      */       
/* 1437 */       return null;
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\DDC.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */