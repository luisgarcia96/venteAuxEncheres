/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.URL;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.ThreadLocalRandom;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.crypto.Mac;
/*     */ import javax.crypto.spec.SecretKeySpec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SQLServerSecurityUtility
/*     */ {
/*  39 */   private static final Logger connectionlogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerConnection");
/*     */ 
/*     */ 
/*     */   
/*     */   static final int GONE = 410;
/*     */ 
/*     */   
/*     */   static final int TOO_MANY_RESQUESTS = 429;
/*     */ 
/*     */   
/*     */   static final int NOT_FOUND = 404;
/*     */ 
/*     */   
/*     */   static final int INTERNAL_SERVER_ERROR = 500;
/*     */ 
/*     */   
/*     */   static final int NETWORK_CONNECT_TIMEOUT_ERROR = 599;
/*     */ 
/*     */ 
/*     */   
/*     */   static byte[] getHMACWithSHA256(byte[] plainText, byte[] key, int length) throws NoSuchAlgorithmException, InvalidKeyException {
/*  60 */     byte[] hash = new byte[length];
/*  61 */     Mac mac = Mac.getInstance("HmacSHA256");
/*  62 */     SecretKeySpec ivkeySpec = new SecretKeySpec(key, "HmacSHA256");
/*  63 */     mac.init(ivkeySpec);
/*  64 */     byte[] computedHash = mac.doFinal(plainText);
/*     */     
/*  66 */     System.arraycopy(computedHash, 0, hash, 0, hash.length);
/*  67 */     return hash;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean compareBytes(byte[] buffer1, byte[] buffer2, int buffer2Index, int lengthToCompare) {
/*  82 */     if (null == buffer1 || null == buffer2) {
/*  83 */       return false;
/*     */     }
/*     */     
/*  86 */     if (buffer2.length - buffer2Index < lengthToCompare) {
/*  87 */       return false;
/*     */     }
/*     */     
/*  90 */     for (int index = 0; index < buffer1.length && index < lengthToCompare; index++) {
/*  91 */       if (buffer1[index] != buffer2[buffer2Index + index]) {
/*  92 */         return false;
/*     */       }
/*     */     } 
/*  95 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static byte[] encryptWithKey(byte[] plainText, CryptoMetadata md, SQLServerConnection connection) throws SQLServerException {
/* 104 */     String serverName = connection.getTrustedServerNameAE();
/* 105 */     assert serverName != null : "Server name should npt be null in EncryptWithKey";
/*     */ 
/*     */     
/* 108 */     if (!md.IsAlgorithmInitialized()) {
/* 109 */       decryptSymmetricKey(md, connection);
/*     */     }
/*     */     
/* 112 */     assert md.IsAlgorithmInitialized();
/* 113 */     byte[] cipherText = md.cipherAlgorithm.encryptData(plainText);
/* 114 */     if (null == cipherText || 0 == cipherText.length) {
/* 115 */       throw new SQLServerException(null, SQLServerException.getErrString("R_NullCipherTextAE"), null, 0, false);
/*     */     }
/* 117 */     return cipherText;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String ValidateAndGetEncryptionAlgorithmName(byte cipherAlgorithmId, String cipherAlgorithmName) throws SQLServerException {
/* 132 */     if (2 != cipherAlgorithmId) {
/* 133 */       throw new SQLServerException(null, SQLServerException.getErrString("R_CustomCipherAlgorithmNotSupportedAE"), null, 0, false);
/*     */     }
/*     */     
/* 136 */     return "AEAD_AES_256_CBC_HMAC_SHA256";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void decryptSymmetricKey(CryptoMetadata md, SQLServerConnection connection) throws SQLServerException {
/* 149 */     assert null != md : "md should not be null in DecryptSymmetricKey.";
/* 150 */     assert null != md.cekTableEntry : "md.EncryptionInfo should not be null in DecryptSymmetricKey.";
/* 151 */     assert null != md.cekTableEntry.columnEncryptionKeyValues : "md.EncryptionInfo.ColumnEncryptionKeyValues should not be null in DecryptSymmetricKey.";
/*     */     
/* 153 */     SQLServerSymmetricKey symKey = null;
/* 154 */     EncryptionKeyInfo encryptionkeyInfoChosen = null;
/* 155 */     SQLServerSymmetricKeyCache cache = SQLServerSymmetricKeyCache.getInstance();
/* 156 */     Iterator<EncryptionKeyInfo> it = md.cekTableEntry.columnEncryptionKeyValues.iterator();
/* 157 */     SQLServerException lastException = null;
/* 158 */     while (it.hasNext()) {
/* 159 */       EncryptionKeyInfo keyInfo = it.next();
/*     */       try {
/* 161 */         symKey = cache.getKey(keyInfo, connection);
/* 162 */         if (null != symKey) {
/* 163 */           encryptionkeyInfoChosen = keyInfo;
/*     */           break;
/*     */         } 
/* 166 */       } catch (SQLServerException e) {
/* 167 */         lastException = e;
/*     */       } 
/*     */     } 
/*     */     
/* 171 */     if (null == symKey) {
/* 172 */       if (null != lastException) {
/* 173 */         throw lastException;
/*     */       }
/* 175 */       throw new SQLServerException(null, SQLServerException.getErrString("R_CEKDecryptionFailed"), null, 0, false);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 181 */     md.cipherAlgorithm = null;
/* 182 */     SQLServerEncryptionAlgorithm cipherAlgorithm = null;
/* 183 */     String algorithmName = ValidateAndGetEncryptionAlgorithmName(md.cipherAlgorithmId, md.cipherAlgorithmName);
/*     */     
/* 185 */     cipherAlgorithm = SQLServerEncryptionAlgorithmFactoryList.getInstance().getAlgorithm(symKey, md.encryptionType, algorithmName);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 191 */     assert null != cipherAlgorithm : "Cipher algorithm cannot be null in DecryptSymmetricKey";
/* 192 */     md.cipherAlgorithm = cipherAlgorithm;
/* 193 */     md.encryptionKeyInfo = encryptionkeyInfoChosen;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static byte[] decryptWithKey(byte[] cipherText, CryptoMetadata md, SQLServerConnection connection) throws SQLServerException {
/* 201 */     String serverName = connection.getTrustedServerNameAE();
/* 202 */     assert null != serverName : "serverName should not be null in DecryptWithKey.";
/*     */ 
/*     */     
/* 205 */     if (!md.IsAlgorithmInitialized()) {
/* 206 */       decryptSymmetricKey(md, connection);
/*     */     }
/*     */     
/* 209 */     assert md.IsAlgorithmInitialized() : "Decryption Algorithm is not initialized";
/* 210 */     byte[] plainText = md.cipherAlgorithm.decryptData(cipherText);
/* 211 */     if (null == plainText) {
/* 212 */       throw new SQLServerException(null, SQLServerException.getErrString("R_PlainTextNullAE"), null, 0, false);
/*     */     }
/*     */     
/* 215 */     return plainText;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void verifyColumnMasterKeyMetadata(SQLServerConnection connection, String keyStoreName, String keyPath, String serverName, boolean isEnclaveEnabled, byte[] CMKSignature) throws SQLServerException {
/* 225 */     Boolean[] hasEntry = new Boolean[1];
/* 226 */     List<String> trustedKeyPaths = SQLServerConnection.getColumnEncryptionTrustedMasterKeyPaths(serverName, hasEntry);
/*     */     
/* 228 */     if (hasEntry[0].booleanValue() && (
/* 229 */       null == trustedKeyPaths || 0 == trustedKeyPaths.size() || !trustedKeyPaths.contains(keyPath))) {
/* 230 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_UntrustedKeyPath"));
/* 231 */       Object[] msgArgs = { keyPath, serverName };
/* 232 */       throw new SQLServerException(form.format(msgArgs), null);
/*     */     } 
/*     */ 
/*     */     
/* 236 */     if (!connection.getColumnEncryptionKeyStoreProvider(keyStoreName).verifyColumnMasterKeyMetadata(keyPath, isEnclaveEnabled, CMKSignature))
/*     */     {
/* 238 */       throw new SQLServerException(SQLServerException.getErrString("R_VerifySignature"), null);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static SqlFedAuthToken getMSIAuthToken(String resource, String msiClientId) throws SQLServerException {
/* 254 */     int imdsUpgradeTimeInMs = 70000;
/* 255 */     List<Integer> retrySlots = new ArrayList<>();
/*     */     
/* 257 */     StringBuilder urlString = new StringBuilder();
/* 258 */     int retry = 1, maxRetry = 1;
/*     */ 
/*     */     
/* 261 */     String identityEndpoint = System.getenv("IDENTITY_ENDPOINT");
/* 262 */     if (null == identityEndpoint || identityEndpoint.trim().isEmpty()) {
/* 263 */       identityEndpoint = System.getenv("MSI_ENDPOINT");
/*     */     }
/*     */     
/* 266 */     String identityHeader = System.getenv("IDENTITY_HEADER");
/* 267 */     if (null == identityHeader || identityHeader.trim().isEmpty()) {
/* 268 */       identityHeader = System.getenv("MSI_SECRET");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 277 */     boolean isAzureFunction = (null != identityEndpoint && !identityEndpoint.isEmpty() && null != identityHeader && !identityHeader.isEmpty());
/*     */     
/* 279 */     if (isAzureFunction) {
/* 280 */       urlString.append(identityEndpoint).append("?api-version=2019-08-01&resource=").append(resource);
/*     */     } else {
/* 282 */       urlString.append("http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01").append("&resource=").append(resource);
/*     */       
/* 284 */       maxRetry = 20;
/*     */       
/* 286 */       for (int x = 0; x < maxRetry; x++) {
/* 287 */         retrySlots.add(Integer.valueOf(1));
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 292 */     if (null != msiClientId && !msiClientId.isEmpty()) {
/* 293 */       urlString.append("&client_id=").append(msiClientId);
/*     */     }
/*     */ 
/*     */     
/* 297 */     while (retry <= maxRetry) {
/* 298 */       HttpURLConnection connection = null;
/*     */ 
/*     */       
/* 301 */       try { connection = (HttpURLConnection)(new URL(urlString.toString())).openConnection();
/* 302 */         connection.setRequestMethod("GET");
/*     */         
/* 304 */         if (isAzureFunction) {
/* 305 */           connection.setRequestProperty("X-IDENTITY-HEADER", identityHeader);
/* 306 */           if (connectionlogger.isLoggable(Level.FINER)) {
/* 307 */             connectionlogger.finer("Using Azure Function/App Service Managed Identity auth: " + urlString);
/*     */           }
/*     */         } else {
/* 310 */           connection.setRequestProperty("Metadata", "true");
/* 311 */           if (connectionlogger.isLoggable(Level.FINER)) {
/* 312 */             connectionlogger.finer("Using Azure Managed Identity auth: " + urlString);
/*     */           }
/*     */         } 
/*     */         
/* 316 */         connection.connect();
/*     */         
/* 318 */         InputStream stream = connection.getInputStream();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */          }
/*     */       
/* 349 */       catch (Exception e)
/* 350 */       { retry++;
/*     */         
/* 352 */         if (retry > maxRetry)
/*     */         
/*     */         { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 389 */           if (connection != null)
/* 390 */             connection.disconnect();  break; }  try { int responseCode = connection.getResponseCode(); if (410 == responseCode || 429 == responseCode || 404 == responseCode || (500 <= responseCode && 599 >= responseCode)) { try { int retryTimeoutInMs = ((Integer)retrySlots.get(ThreadLocalRandom.current().nextInt(retry - 1))).intValue(); retryTimeoutInMs = (responseCode == 410 && retryTimeoutInMs < 70000) ? 70000 : retryTimeoutInMs; Thread.sleep(retryTimeoutInMs); } catch (InterruptedException ex) { throw new RuntimeException(ex); }  } else { if (null != msiClientId && !msiClientId.isEmpty()) throw new SQLServerException(SQLServerException.getErrString("R_MSITokenFailureImdsClientId"), null);  throw new SQLServerException(SQLServerException.getErrString("R_MSITokenFailureImds"), null); }  } catch (IOException io) { throw new SQLServerException(SQLServerException.getErrString("R_MSITokenFailureUnexpected"), null); }  } finally { if (connection != null) connection.disconnect();
/*     */          }
/*     */     
/*     */     } 
/* 394 */     if (retry > maxRetry) {
/* 395 */       throw new SQLServerException(
/* 396 */           SQLServerException.getErrString(isAzureFunction ? "R_MSITokenFailureEndpoint" : "R_MSITokenFailureImds"), null);
/*     */     }
/* 398 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerSecurityUtility.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */