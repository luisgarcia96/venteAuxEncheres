/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.EnumSet;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SQLCollation
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 6748833280721312349L;
/*     */   private final int info;
/*     */   private final int sortId;
/*     */   private final Encoding encoding;
/*     */   private static final int UTF8_IN_TDSCOLLATION = 67108864;
/*     */   
/*     */   private int langID() {
/*  36 */     return this.info & 0xFFFF;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final Charset getCharset() throws SQLServerException {
/*  45 */     return this.encoding.charset();
/*     */   }
/*     */   
/*     */   final boolean supportsAsciiConversion() {
/*  49 */     return this.encoding.supportsAsciiConversion();
/*     */   }
/*     */   
/*     */   final boolean hasAsciiCompatibleSBCS() {
/*  53 */     return this.encoding.hasAsciiCompatibleSBCS();
/*     */   }
/*     */   
/*     */   static final int tdsLength() {
/*  57 */     return 5;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getCollationInfo() {
/*  66 */     return this.info;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getCollationSortID() {
/*  75 */     return this.sortId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SQLCollation(TDSReader tdsReader) throws UnsupportedEncodingException, SQLServerException {
/*  87 */     this.info = tdsReader.readInt();
/*  88 */     this.sortId = tdsReader.readUnsignedByte();
/*  89 */     if (67108864 == (this.info & 0x4000000)) {
/*  90 */       this.encoding = Encoding.UTF8;
/*     */     } else {
/*     */       
/*  93 */       this.encoding = (0 == this.sortId) ? encodingFromLCID() : encodingFromSortId();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void writeCollation(TDSWriter tdsWriter) throws SQLServerException {
/* 104 */     tdsWriter.writeInt(this.info);
/* 105 */     tdsWriter.writeByte((byte)(this.sortId & 0xFF));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   enum WindowsLocale
/*     */   {
/* 124 */     ar_SA(1025, Encoding.CP1256),
/* 125 */     bg_BG(1026, Encoding.CP1251),
/* 126 */     ca_ES(1027, Encoding.CP1252),
/* 127 */     zh_TW(1028, Encoding.CP950),
/* 128 */     cs_CZ(1029, Encoding.CP1250),
/* 129 */     da_DK(1030, Encoding.CP1252),
/* 130 */     de_DE(1031, Encoding.CP1252),
/* 131 */     el_GR(1032, Encoding.CP1253),
/* 132 */     en_US(1033, Encoding.CP1252),
/* 133 */     es_ES_tradnl(1034, Encoding.CP1252),
/* 134 */     fi_FI(1035, Encoding.CP1252),
/* 135 */     fr_FR(1036, Encoding.CP1252),
/* 136 */     he_IL(1037, Encoding.CP1255),
/* 137 */     hu_HU(1038, Encoding.CP1250),
/* 138 */     is_IS(1039, Encoding.CP1252),
/* 139 */     it_IT(1040, Encoding.CP1252),
/* 140 */     ja_JP(1041, Encoding.CP932),
/* 141 */     ko_KR(1042, Encoding.CP949),
/* 142 */     nl_NL(1043, Encoding.CP1252),
/* 143 */     nb_NO(1044, Encoding.CP1252),
/* 144 */     pl_PL(1045, Encoding.CP1250),
/* 145 */     pt_BR(1046, Encoding.CP1252),
/* 146 */     rm_CH(1047, Encoding.CP1252),
/* 147 */     ro_RO(1048, Encoding.CP1250),
/* 148 */     ru_RU(1049, Encoding.CP1251),
/* 149 */     hr_HR(1050, Encoding.CP1250),
/* 150 */     sk_SK(1051, Encoding.CP1250),
/* 151 */     sq_AL(1052, Encoding.CP1250),
/* 152 */     sv_SE(1053, Encoding.CP1252),
/* 153 */     th_TH(1054, Encoding.CP874),
/* 154 */     tr_TR(1055, Encoding.CP1254),
/* 155 */     ur_PK(1056, Encoding.CP1256),
/* 156 */     id_ID(1057, Encoding.CP1252),
/* 157 */     uk_UA(1058, Encoding.CP1251),
/* 158 */     be_BY(1059, Encoding.CP1251),
/* 159 */     sl_SI(1060, Encoding.CP1250),
/* 160 */     et_EE(1061, Encoding.CP1257),
/* 161 */     lv_LV(1062, Encoding.CP1257),
/* 162 */     lt_LT(1063, Encoding.CP1257),
/* 163 */     tg_Cyrl_TJ(1064, Encoding.CP1251),
/* 164 */     fa_IR(1065, Encoding.CP1256),
/* 165 */     vi_VN(1066, Encoding.CP1258),
/* 166 */     hy_AM(1067, Encoding.CP1252),
/* 167 */     az_Latn_AZ(1068, Encoding.CP1254),
/* 168 */     eu_ES(1069, Encoding.CP1252),
/* 169 */     wen_DE(1070, Encoding.CP1252),
/* 170 */     mk_MK(1071, Encoding.CP1251),
/* 171 */     tn_ZA(1074, Encoding.CP1252),
/* 172 */     xh_ZA(1076, Encoding.CP1252),
/* 173 */     zu_ZA(1077, Encoding.CP1252),
/* 174 */     Af_ZA(1078, Encoding.CP1252),
/* 175 */     ka_GE(1079, Encoding.CP1252),
/* 176 */     fo_FO(1080, Encoding.CP1252),
/* 177 */     hi_IN(1081, Encoding.UNICODE),
/* 178 */     mt_MT(1082, Encoding.UNICODE),
/* 179 */     se_NO(1083, Encoding.CP1252),
/* 180 */     ms_MY(1086, Encoding.CP1252),
/* 181 */     kk_KZ(1087, Encoding.CP1251),
/* 182 */     ky_KG(1088, Encoding.CP1251),
/* 183 */     sw_KE(1089, Encoding.CP1252),
/* 184 */     tk_TM(1090, Encoding.CP1250),
/* 185 */     uz_Latn_UZ(1091, Encoding.CP1254),
/* 186 */     tt_RU(1092, Encoding.CP1251),
/* 187 */     bn_IN(1093, Encoding.UNICODE),
/* 188 */     pa_IN(1094, Encoding.UNICODE),
/* 189 */     gu_IN(1095, Encoding.UNICODE),
/* 190 */     or_IN(1096, Encoding.UNICODE),
/* 191 */     ta_IN(1097, Encoding.UNICODE),
/* 192 */     te_IN(1098, Encoding.UNICODE),
/* 193 */     kn_IN(1099, Encoding.UNICODE),
/* 194 */     ml_IN(1100, Encoding.UNICODE),
/* 195 */     as_IN(1101, Encoding.UNICODE),
/* 196 */     mr_IN(1102, Encoding.UNICODE),
/* 197 */     sa_IN(1103, Encoding.UNICODE),
/* 198 */     mn_MN(1104, Encoding.CP1251),
/* 199 */     bo_CN(1105, Encoding.UNICODE),
/* 200 */     cy_GB(1106, Encoding.CP1252),
/* 201 */     km_KH(1107, Encoding.UNICODE),
/* 202 */     lo_LA(1108, Encoding.UNICODE),
/* 203 */     gl_ES(1110, Encoding.CP1252),
/* 204 */     kok_IN(1111, Encoding.UNICODE),
/* 205 */     syr_SY(1114, Encoding.UNICODE),
/* 206 */     si_LK(1115, Encoding.UNICODE),
/* 207 */     iu_Cans_CA(1117, Encoding.CP1252),
/* 208 */     am_ET(1118, Encoding.CP1252),
/* 209 */     ne_NP(1121, Encoding.UNICODE),
/* 210 */     fy_NL(1122, Encoding.CP1252),
/* 211 */     ps_AF(1123, Encoding.UNICODE),
/* 212 */     fil_PH(1124, Encoding.CP1252),
/* 213 */     dv_MV(1125, Encoding.UNICODE),
/* 214 */     ha_Latn_NG(1128, Encoding.CP1252),
/* 215 */     yo_NG(1130, Encoding.CP1252),
/* 216 */     quz_BO(1131, Encoding.CP1252),
/* 217 */     nso_ZA(1132, Encoding.CP1252),
/* 218 */     ba_RU(1133, Encoding.CP1251),
/* 219 */     lb_LU(1134, Encoding.CP1252),
/* 220 */     kl_GL(1135, Encoding.CP1252),
/* 221 */     ig_NG(1136, Encoding.CP1252),
/* 222 */     ii_CN(1144, Encoding.CP1252),
/* 223 */     arn_CL(1146, Encoding.CP1252),
/* 224 */     moh_CA(1148, Encoding.CP1252),
/* 225 */     br_FR(1150, Encoding.CP1252),
/* 226 */     ug_CN(1152, Encoding.CP1256),
/* 227 */     mi_NZ(1153, Encoding.UNICODE),
/* 228 */     oc_FR(1154, Encoding.CP1252),
/* 229 */     co_FR(1155, Encoding.CP1252),
/* 230 */     gsw_FR(1156, Encoding.CP1252),
/* 231 */     sah_RU(1157, Encoding.CP1251),
/* 232 */     qut_GT(1158, Encoding.CP1252),
/* 233 */     rw_RW(1159, Encoding.CP1252),
/* 234 */     wo_SN(1160, Encoding.CP1252),
/* 235 */     prs_AF(1164, Encoding.CP1256),
/* 236 */     ar_IQ(2049, Encoding.CP1256),
/* 237 */     zh_CN(2052, Encoding.CP936),
/* 238 */     de_CH(2055, Encoding.CP1252),
/* 239 */     en_GB(2057, Encoding.CP1252),
/* 240 */     es_MX(2058, Encoding.CP1252),
/* 241 */     fr_BE(2060, Encoding.CP1252),
/* 242 */     it_CH(2064, Encoding.CP1252),
/* 243 */     nl_BE(2067, Encoding.CP1252),
/* 244 */     nn_NO(2068, Encoding.CP1252),
/* 245 */     pt_PT(2070, Encoding.CP1252),
/* 246 */     sr_Latn_CS(2074, Encoding.CP1250),
/* 247 */     sv_FI(2077, Encoding.CP1252),
/* 248 */     Lithuanian_Classic(2087, Encoding.CP1257),
/* 249 */     az_Cyrl_AZ(2092, Encoding.CP1251),
/* 250 */     dsb_DE(2094, Encoding.CP1252),
/* 251 */     se_SE(2107, Encoding.CP1252),
/* 252 */     ga_IE(2108, Encoding.CP1252),
/* 253 */     ms_BN(2110, Encoding.CP1252),
/* 254 */     uz_Cyrl_UZ(2115, Encoding.CP1251),
/* 255 */     bn_BD(2117, Encoding.UNICODE),
/* 256 */     mn_Mong_CN(2128, Encoding.CP1251),
/* 257 */     iu_Latn_CA(2141, Encoding.CP1252),
/* 258 */     tzm_Latn_DZ(2143, Encoding.CP1252),
/* 259 */     quz_EC(2155, Encoding.CP1252),
/* 260 */     ar_EG(3073, Encoding.CP1256),
/* 261 */     zh_HK(3076, Encoding.CP950),
/* 262 */     de_AT(3079, Encoding.CP1252),
/* 263 */     en_AU(3081, Encoding.CP1252),
/* 264 */     es_ES(3082, Encoding.CP1252),
/* 265 */     fr_CA(3084, Encoding.CP1252),
/* 266 */     sr_Cyrl_CS(3098, Encoding.CP1251),
/* 267 */     se_FI(3131, Encoding.CP1252),
/* 268 */     quz_PE(3179, Encoding.CP1252),
/* 269 */     ar_LY(4097, Encoding.CP1256),
/* 270 */     zh_SG(4100, Encoding.CP936),
/* 271 */     de_LU(4103, Encoding.CP1252),
/* 272 */     en_CA(4105, Encoding.CP1252),
/* 273 */     es_GT(4106, Encoding.CP1252),
/* 274 */     fr_CH(4108, Encoding.CP1252),
/* 275 */     hr_BA(4122, Encoding.CP1250),
/* 276 */     smj_NO(4155, Encoding.CP1252),
/* 277 */     ar_DZ(5121, Encoding.CP1256),
/* 278 */     zh_MO(5124, Encoding.CP950),
/* 279 */     de_LI(5127, Encoding.CP1252),
/* 280 */     en_NZ(5129, Encoding.CP1252),
/* 281 */     es_CR(5130, Encoding.CP1252),
/* 282 */     fr_LU(5132, Encoding.CP1252),
/* 283 */     bs_Latn_BA(5146, Encoding.CP1250),
/* 284 */     smj_SE(5179, Encoding.CP1252),
/* 285 */     ar_MA(6145, Encoding.CP1256),
/* 286 */     en_IE(6153, Encoding.CP1252),
/* 287 */     es_PA(6154, Encoding.CP1252),
/* 288 */     fr_MC(6156, Encoding.CP1252),
/* 289 */     sr_Latn_BA(6170, Encoding.CP1250),
/* 290 */     sma_NO(6203, Encoding.CP1252),
/* 291 */     ar_TN(7169, Encoding.CP1256),
/* 292 */     en_ZA(7177, Encoding.CP1252),
/* 293 */     es_DO(7178, Encoding.CP1252),
/* 294 */     sr_Cyrl_BA(7194, Encoding.CP1251),
/* 295 */     sma_SB(7227, Encoding.CP1252),
/* 296 */     ar_OM(8193, Encoding.CP1256),
/* 297 */     en_JM(8201, Encoding.CP1252),
/* 298 */     es_VE(8202, Encoding.CP1252),
/* 299 */     bs_Cyrl_BA(8218, Encoding.CP1251),
/* 300 */     sms_FI(8251, Encoding.CP1252),
/* 301 */     ar_YE(9217, Encoding.CP1256),
/* 302 */     en_CB(9225, Encoding.CP1252),
/* 303 */     es_CO(9226, Encoding.CP1252),
/* 304 */     smn_FI(9275, Encoding.CP1252),
/* 305 */     ar_SY(10241, Encoding.CP1256),
/* 306 */     en_BZ(10249, Encoding.CP1252),
/* 307 */     es_PE(10250, Encoding.CP1252),
/* 308 */     ar_JO(11265, Encoding.CP1256),
/* 309 */     en_TT(11273, Encoding.CP1252),
/* 310 */     es_AR(11274, Encoding.CP1252),
/* 311 */     ar_LB(12289, Encoding.CP1256),
/* 312 */     en_ZW(12297, Encoding.CP1252),
/* 313 */     es_EC(12298, Encoding.CP1252),
/* 314 */     ar_KW(13313, Encoding.CP1256),
/* 315 */     en_PH(13321, Encoding.CP1252),
/* 316 */     es_CL(13322, Encoding.CP1252),
/* 317 */     ar_AE(14337, Encoding.CP1256),
/* 318 */     es_UY(14346, Encoding.CP1252),
/* 319 */     ar_BH(15361, Encoding.CP1256),
/* 320 */     es_PY(15370, Encoding.CP1252),
/* 321 */     ar_QA(16385, Encoding.CP1256),
/* 322 */     en_IN(16393, Encoding.CP1252),
/* 323 */     es_BO(16394, Encoding.CP1252),
/* 324 */     en_MY(17417, Encoding.CP1252),
/* 325 */     es_SV(17418, Encoding.CP1252),
/* 326 */     en_SG(18441, Encoding.CP1252),
/* 327 */     es_HN(18442, Encoding.CP1252),
/* 328 */     es_NI(19466, Encoding.CP1252),
/* 329 */     es_PR(20490, Encoding.CP1252),
/* 330 */     es_US(21514, Encoding.CP1252);
/*     */     
/*     */     private final int langID;
/*     */     private final Encoding encoding;
/*     */     
/*     */     WindowsLocale(int langID, Encoding encoding) {
/* 336 */       this.langID = langID;
/* 337 */       this.encoding = encoding;
/*     */     }
/*     */     
/*     */     final Encoding getEncoding() throws UnsupportedEncodingException {
/* 341 */       return this.encoding.checkSupported();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Encoding encodingFromLCID() throws UnsupportedEncodingException {
/* 350 */     WindowsLocale locale = localeIndex.get(Integer.valueOf(langID()));
/*     */     
/* 352 */     if (null == locale) {
/* 353 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_unknownLCID"));
/* 354 */       Object[] msgArgs = { Integer.toHexString(langID()).toUpperCase() };
/* 355 */       throw new UnsupportedEncodingException(form.format(msgArgs));
/*     */     } 
/*     */     
/*     */     try {
/* 359 */       return locale.getEncoding();
/* 360 */     } catch (UnsupportedEncodingException inner) {
/* 361 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_unknownLCID"));
/* 362 */       Object[] msgArgs = { locale };
/* 363 */       UnsupportedEncodingException e = new UnsupportedEncodingException(form.format(msgArgs));
/* 364 */       e.initCause(inner);
/* 365 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   enum SortOrder
/*     */   {
/* 376 */     BIN_CP437(30, "SQL_Latin1_General_CP437_BIN", Encoding.CP437),
/* 377 */     DICTIONARY_437(31, "SQL_Latin1_General_CP437_CS_AS", Encoding.CP437),
/* 378 */     NOCASE_437(32, "SQL_Latin1_General_CP437_CI_AS", Encoding.CP437),
/* 379 */     NOCASEPREF_437(33, "SQL_Latin1_General_Pref_CP437_CI_AS", Encoding.CP437),
/* 380 */     NOACCENTS_437(34, "SQL_Latin1_General_CP437_CI_AI", Encoding.CP437),
/* 381 */     BIN2_CP437(35, "SQL_Latin1_General_CP437_BIN2", Encoding.CP437),
/*     */     
/* 383 */     BIN_CP850(40, "SQL_Latin1_General_CP850_BIN", Encoding.CP850),
/* 384 */     DICTIONARY_850(41, "SQL_Latin1_General_CP850_CS_AS", Encoding.CP850),
/* 385 */     NOCASE_850(42, "SQL_Latin1_General_CP850_CI_AS", Encoding.CP850),
/* 386 */     NOCASEPREF_850(43, "SQL_Latin1_General_Pref_CP850_CI_AS", Encoding.CP850),
/* 387 */     NOACCENTS_850(44, "SQL_Latin1_General_CP850_CI_AI", Encoding.CP850),
/* 388 */     BIN2_CP850(45, "SQL_Latin1_General_CP850_BIN2", Encoding.CP850),
/*     */     
/* 390 */     CASELESS_34(49, "SQL_1xCompat_CP850_CI_AS", Encoding.CP850),
/* 391 */     BIN_ISO_1(50, "bin_iso_1", Encoding.CP1252),
/* 392 */     DICTIONARY_ISO(51, "SQL_Latin1_General_CP1_CS_AS", Encoding.CP1252),
/* 393 */     NOCASE_ISO(52, "SQL_Latin1_General_CP1_CI_AS", Encoding.CP1252),
/* 394 */     NOCASEPREF_ISO(53, "SQL_Latin1_General_Pref_CP1_CI_AS", Encoding.CP1252),
/* 395 */     NOACCENTS_ISO(54, "SQL_Latin1_General_CP1_CI_AI", Encoding.CP1252),
/* 396 */     ALT_DICTIONARY(55, "SQL_AltDiction_CP850_CS_AS", Encoding.CP850),
/* 397 */     ALT_NOCASEPREF(56, "SQL_AltDiction_Pref_CP850_CI_AS", Encoding.CP850),
/* 398 */     ALT_NOACCENTS(57, "SQL_AltDiction_CP850_CI_AI", Encoding.CP850),
/* 399 */     SCAND_NOCASEPREF(58, "SQL_Scandinavian_Pref_CP850_CI_AS", Encoding.CP850),
/* 400 */     SCAND_DICTIONARY(59, "SQL_Scandinavian_CP850_CS_AS", Encoding.CP850),
/* 401 */     SCAND_NOCASE(60, "SQL_Scandinavian_CP850_CI_AS", Encoding.CP850),
/* 402 */     ALT_NOCASE(61, "SQL_AltDiction_CP850_CI_AS", Encoding.CP850),
/*     */     
/* 404 */     DICTIONARY_1252(71, "dictionary_1252", Encoding.CP1252),
/* 405 */     NOCASE_1252(72, "nocase_1252", Encoding.CP1252),
/* 406 */     DNK_NOR_DICTIONARY(73, "dnk_nor_dictionary", Encoding.CP1252),
/* 407 */     FIN_SWE_DICTIONARY(74, "fin_swe_dictionary", Encoding.CP1252),
/* 408 */     ISL_DICTIONARY(75, "isl_dictionary", Encoding.CP1252),
/*     */     
/* 410 */     BIN_CP1250(80, "bin_cp1250", Encoding.CP1250),
/* 411 */     DICTIONARY_1250(81, "SQL_Latin1_General_CP1250_CS_AS", Encoding.CP1250),
/* 412 */     NOCASE_1250(82, "SQL_Latin1_General_CP1250_CI_AS", Encoding.CP1250),
/* 413 */     CSYDIC(83, "SQL_Czech_CP1250_CS_AS", Encoding.CP1250),
/* 414 */     CSYNC(84, "SQL_Czech_CP1250_CI_AS", Encoding.CP1250),
/* 415 */     HUNDIC(85, "SQL_Hungarian_CP1250_CS_AS", Encoding.CP1250),
/* 416 */     HUNNC(86, "SQL_Hungarian_CP1250_CI_AS", Encoding.CP1250),
/* 417 */     PLKDIC(87, "SQL_Polish_CP1250_CS_AS", Encoding.CP1250),
/* 418 */     PLKNC(88, "SQL_Polish_CP1250_CI_AS", Encoding.CP1250),
/* 419 */     ROMDIC(89, "SQL_Romanian_CP1250_CS_AS", Encoding.CP1250),
/* 420 */     ROMNC(90, "SQL_Romanian_CP1250_CI_AS", Encoding.CP1250),
/* 421 */     SHLDIC(91, "SQL_Croatian_CP1250_CS_AS", Encoding.CP1250),
/* 422 */     SHLNC(92, "SQL_Croatian_CP1250_CI_AS", Encoding.CP1250),
/* 423 */     SKYDIC(93, "SQL_Slovak_CP1250_CS_AS", Encoding.CP1250),
/* 424 */     SKYNC(94, "SQL_Slovak_CP1250_CI_AS", Encoding.CP1250),
/* 425 */     SLVDIC(95, "SQL_Slovenian_CP1250_CS_AS", Encoding.CP1250),
/* 426 */     SLVNC(96, "SQL_Slovenian_CP1250_CI_AS", Encoding.CP1250),
/* 427 */     POLISH_CS(97, "polish_cs", Encoding.CP1250),
/* 428 */     POLISH_CI(98, "polish_ci", Encoding.CP1250),
/*     */     
/* 430 */     BIN_CP1251(104, "bin_cp1251", Encoding.CP1251),
/* 431 */     DICTIONARY_1251(105, "SQL_Latin1_General_CP1251_CS_AS", Encoding.CP1251),
/* 432 */     NOCASE_1251(106, "SQL_Latin1_General_CP1251_CI_AS", Encoding.CP1251),
/* 433 */     UKRDIC(107, "SQL_Ukrainian_CP1251_CS_AS", Encoding.CP1251),
/* 434 */     UKRNC(108, "SQL_Ukrainian_CP1251_CI_AS", Encoding.CP1251),
/*     */     
/* 436 */     BIN_CP1253(112, "bin_cp1253", Encoding.CP1253),
/* 437 */     DICTIONARY_1253(113, "SQL_Latin1_General_CP1253_CS_AS", Encoding.CP1253),
/* 438 */     NOCASE_1253(114, "SQL_Latin1_General_CP1253_CI_AS", Encoding.CP1253),
/*     */     
/* 440 */     GREEK_MIXEDDICTIONARY(120, "SQL_MixDiction_CP1253_CS_AS", Encoding.CP1253),
/* 441 */     GREEK_ALTDICTIONARY(121, "SQL_AltDiction_CP1253_CS_AS", Encoding.CP1253),
/* 442 */     GREEK_ALTDICTIONARY2(122, "SQL_AltDiction2_CP1253_CS_AS", Encoding.CP1253),
/* 443 */     GREEK_NOCASEDICT(124, "SQL_Latin1_General_CP1253_CI_AI", Encoding.CP1253),
/* 444 */     BIN_CP1254(128, "bin_cp1254", Encoding.CP1254),
/* 445 */     DICTIONARY_1254(129, "SQL_Latin1_General_CP1254_CS_AS", Encoding.CP1254),
/* 446 */     NOCASE_1254(130, "SQL_Latin1_General_CP1254_CI_AS", Encoding.CP1254),
/*     */     
/* 448 */     BIN_CP1255(136, "bin_cp1255", Encoding.CP1255),
/* 449 */     DICTIONARY_1255(137, "SQL_Latin1_General_CP1255_CS_AS", Encoding.CP1255),
/* 450 */     NOCASE_1255(138, "SQL_Latin1_General_CP1255_CI_AS", Encoding.CP1255),
/*     */     
/* 452 */     BIN_CP1256(144, "bin_cp1256", Encoding.CP1256),
/* 453 */     DICTIONARY_1256(145, "SQL_Latin1_General_CP1256_CS_AS", Encoding.CP1256),
/* 454 */     NOCASE_1256(146, "SQL_Latin1_General_CP1256_CI_AS", Encoding.CP1256),
/*     */     
/* 456 */     BIN_CP1257(152, "bin_cp1257", Encoding.CP1257),
/* 457 */     DICTIONARY_1257(153, "SQL_Latin1_General_CP1257_CS_AS", Encoding.CP1257),
/* 458 */     NOCASE_1257(154, "SQL_Latin1_General_CP1257_CI_AS", Encoding.CP1257),
/* 459 */     ETIDIC(155, "SQL_Estonian_CP1257_CS_AS", Encoding.CP1257),
/* 460 */     ETINC(156, "SQL_Estonian_CP1257_CI_AS", Encoding.CP1257),
/* 461 */     LVIDIC(157, "SQL_Latvian_CP1257_CS_AS", Encoding.CP1257),
/* 462 */     LVINC(158, "SQL_Latvian_CP1257_CI_AS", Encoding.CP1257),
/* 463 */     LTHDIC(159, "SQL_Lithuanian_CP1257_CS_AS", Encoding.CP1257),
/* 464 */     LTHNC(160, "SQL_Lithuanian_CP1257_CI_AS", Encoding.CP1257),
/*     */     
/* 466 */     DANNO_NOCASEPREF(183, "SQL_Danish_Pref_CP1_CI_AS", Encoding.CP1252),
/* 467 */     SVFI1_NOCASEPREF(184, "SQL_SwedishPhone_Pref_CP1_CI_AS", Encoding.CP1252),
/* 468 */     SVFI2_NOCASEPREF(185, "SQL_SwedishStd_Pref_CP1_CI_AS", Encoding.CP1252),
/* 469 */     ISLAN_NOCASEPREF(186, "SQL_Icelandic_Pref_CP1_CI_AS", Encoding.CP1252),
/*     */     
/* 471 */     BIN_CP932(192, "bin_cp932", Encoding.CP932),
/* 472 */     NLS_CP932(193, "nls_cp932", Encoding.CP932),
/* 473 */     BIN_CP949(194, "bin_cp949", Encoding.CP949),
/* 474 */     NLS_CP949(195, "nls_cp949", Encoding.CP949),
/* 475 */     BIN_CP950(196, "bin_cp950", Encoding.CP950),
/* 476 */     NLS_CP950(197, "nls_cp950", Encoding.CP950),
/* 477 */     BIN_CP936(198, "bin_cp936", Encoding.CP936),
/* 478 */     NLS_CP936(199, "nls_cp936", Encoding.CP936),
/* 479 */     NLS_CP932_CS(200, "nls_cp932_cs", Encoding.CP932),
/* 480 */     NLS_CP949_CS(201, "nls_cp949_cs", Encoding.CP949),
/* 481 */     NLS_CP950_CS(202, "nls_cp950_cs", Encoding.CP950),
/* 482 */     NLS_CP936_CS(203, "nls_cp936_cs", Encoding.CP936),
/* 483 */     BIN_CP874(204, "bin_cp874", Encoding.CP874),
/* 484 */     NLS_CP874(205, "nls_cp874", Encoding.CP874),
/* 485 */     NLS_CP874_CS(206, "nls_cp874_cs", Encoding.CP874),
/*     */     
/* 487 */     EBCDIC_037(210, "SQL_EBCDIC037_CP1_CS_AS", Encoding.CP1252),
/* 488 */     EBCDIC_273(211, "SQL_EBCDIC273_CP1_CS_AS", Encoding.CP1252),
/* 489 */     EBCDIC_277(212, "SQL_EBCDIC277_CP1_CS_AS", Encoding.CP1252),
/* 490 */     EBCDIC_278(213, "SQL_EBCDIC278_CP1_CS_AS", Encoding.CP1252),
/* 491 */     EBCDIC_280(214, "SQL_EBCDIC280_CP1_CS_AS", Encoding.CP1252),
/* 492 */     EBCDIC_284(215, "SQL_EBCDIC284_CP1_CS_AS", Encoding.CP1252),
/* 493 */     EBCDIC_285(216, "SQL_EBCDIC285_CP1_CS_AS", Encoding.CP1252),
/* 494 */     EBCDIC_297(217, "SQL_EBCDIC297_CP1_CS_AS", Encoding.CP1252);
/*     */     
/*     */     private final int sortId;
/*     */     private final String name;
/*     */     private final Encoding encoding;
/*     */     
/*     */     final Encoding getEncoding() throws UnsupportedEncodingException {
/* 501 */       return this.encoding.checkSupported();
/*     */     }
/*     */     
/*     */     SortOrder(int sortId, String name, Encoding encoding) {
/* 505 */       this.sortId = sortId;
/* 506 */       this.name = name;
/* 507 */       this.encoding = encoding;
/*     */     }
/*     */     
/*     */     public final String toString() {
/* 511 */       return this.name;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Encoding encodingFromSortId() throws UnsupportedEncodingException {
/* 518 */     SortOrder sortOrder = sortOrderIndex.get(Integer.valueOf(this.sortId));
/*     */     
/* 520 */     if (null == sortOrder) {
/* 521 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_unknownSortId"));
/* 522 */       Object[] msgArgs = { Integer.valueOf(this.sortId) };
/* 523 */       throw new UnsupportedEncodingException(form.format(msgArgs));
/*     */     } 
/*     */     
/*     */     try {
/* 527 */       return sortOrder.getEncoding();
/* 528 */     } catch (UnsupportedEncodingException inner) {
/* 529 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_unknownSortId"));
/* 530 */       Object[] msgArgs = { sortOrder };
/* 531 */       UnsupportedEncodingException e = new UnsupportedEncodingException(form.format(msgArgs));
/* 532 */       e.initCause(inner);
/* 533 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 540 */   private static final Map<Integer, WindowsLocale> localeIndex = new HashMap<>(); static {
/* 541 */     for (WindowsLocale locale : EnumSet.<WindowsLocale>allOf(WindowsLocale.class))
/* 542 */       localeIndex.put(Integer.valueOf(locale.langID), locale); 
/*     */   }
/* 544 */   private static final HashMap<Integer, SortOrder> sortOrderIndex = new HashMap<>(); static {
/* 545 */     for (SortOrder sortOrder : EnumSet.<SortOrder>allOf(SortOrder.class))
/* 546 */       sortOrderIndex.put(Integer.valueOf(sortOrder.sortId), sortOrder); 
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLCollation.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */