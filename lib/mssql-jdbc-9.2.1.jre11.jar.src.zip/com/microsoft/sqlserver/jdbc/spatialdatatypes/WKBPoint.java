/*    */ package com.microsoft.sqlserver.jdbc.spatialdatatypes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WKBPoint
/*    */ {
/*    */   private final double x;
/*    */   private final double y;
/*    */   
/*    */   public WKBPoint(double x, double y) {
/* 17 */     this.x = x;
/* 18 */     this.y = y;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public double getX() {
/* 27 */     return this.x;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public double getY() {
/* 36 */     return this.y;
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\spatialdatatypes\WKBPoint.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */