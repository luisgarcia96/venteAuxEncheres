/*    */ package com.microsoft.sqlserver.jdbc.spatialdatatypes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Point
/*    */ {
/*    */   private final double x;
/*    */   private final double y;
/*    */   private final double z;
/*    */   private final double m;
/*    */   
/*    */   public Point(double x, double y, double z, double m) {
/* 19 */     this.x = x;
/* 20 */     this.y = y;
/* 21 */     this.z = z;
/* 22 */     this.m = m;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public double getX() {
/* 31 */     return this.x;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public double getY() {
/* 40 */     return this.y;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public double getZ() {
/* 49 */     return this.z;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public double getM() {
/* 58 */     return this.m;
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\spatialdatatypes\Point.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */