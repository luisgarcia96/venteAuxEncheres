/*    */ package com.microsoft.sqlserver.jdbc.spatialdatatypes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Shape
/*    */ {
/*    */   private int parentOffset;
/*    */   private int figureOffset;
/*    */   private byte openGISType;
/*    */   
/*    */   public Shape(int parentOffset, int figureOffset, byte openGISType) {
/* 18 */     this.parentOffset = parentOffset;
/* 19 */     this.figureOffset = figureOffset;
/* 20 */     this.openGISType = openGISType;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getParentOffset() {
/* 29 */     return this.parentOffset;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getFigureOffset() {
/* 38 */     return this.figureOffset;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte getOpenGISType() {
/* 47 */     return this.openGISType;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setFigureOffset(int fo) {
/* 57 */     this.figureOffset = fo;
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\spatialdatatypes\Shape.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */