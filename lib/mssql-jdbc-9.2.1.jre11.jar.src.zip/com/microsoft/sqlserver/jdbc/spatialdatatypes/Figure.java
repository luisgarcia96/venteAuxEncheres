/*    */ package com.microsoft.sqlserver.jdbc.spatialdatatypes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Figure
/*    */ {
/*    */   private byte figuresAttribute;
/*    */   private int pointOffset;
/*    */   
/*    */   public Figure(byte figuresAttribute, int pointOffset) {
/* 17 */     this.figuresAttribute = figuresAttribute;
/* 18 */     this.pointOffset = pointOffset;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte getFiguresAttribute() {
/* 27 */     return this.figuresAttribute;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getPointOffset() {
/* 36 */     return this.pointOffset;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setFiguresAttribute(byte fa) {
/* 46 */     this.figuresAttribute = fa;
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\spatialdatatypes\Figure.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */