/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class StreamTabName
/*    */   extends StreamPacket
/*    */ {
/*    */   private TDSReader tdsReader;
/*    */   private TDSReaderMark tableNamesMark;
/*    */   
/*    */   StreamTabName() {
/* 18 */     super(164);
/*    */   }
/*    */   
/*    */   void setFromTDS(TDSReader tdsReader) throws SQLServerException {
/* 22 */     if (164 != tdsReader.readUnsignedByte() && 
/* 23 */       !$assertionsDisabled) throw new AssertionError("Not a TABNAME token");
/*    */     
/* 25 */     this.tdsReader = tdsReader;
/* 26 */     int tokenLength = tdsReader.readUnsignedShort();
/* 27 */     this.tableNamesMark = tdsReader.mark();
/* 28 */     tdsReader.skip(tokenLength);
/*    */   }
/*    */   
/*    */   void applyTo(Column[] columns, int numTables) throws SQLServerException {
/* 32 */     TDSReaderMark currentMark = this.tdsReader.mark();
/* 33 */     this.tdsReader.reset(this.tableNamesMark);
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 38 */     SQLIdentifier[] tableNames = new SQLIdentifier[numTables];
/* 39 */     for (int i = 0; i < numTables; i++) {
/* 40 */       tableNames[i] = this.tdsReader.readSQLIdentifier();
/*    */     }
/*    */     
/* 43 */     for (Column col : columns) {
/* 44 */       if (col.getTableNum() > 0) {
/* 45 */         col.setTableName(tableNames[col.getTableNum() - 1]);
/*    */       }
/*    */     } 
/* 48 */     this.tdsReader.reset(currentMark);
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\StreamTabName.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */