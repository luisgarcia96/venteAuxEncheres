/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.sql.Array;
/*     */ import java.sql.Blob;
/*     */ import java.sql.CallableStatement;
/*     */ import java.sql.Clob;
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.sql.NClob;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLClientInfoException;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLPermission;
/*     */ import java.sql.SQLWarning;
/*     */ import java.sql.SQLXML;
/*     */ import java.sql.Savepoint;
/*     */ import java.sql.Statement;
/*     */ import java.sql.Struct;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.UUID;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.logging.Level;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SQLServerConnectionPoolProxy
/*     */   implements ISQLServerConnection, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 5752599482349578127L;
/*     */   private SQLServerConnection wrappedConnection;
/*     */   private boolean bIsOpen;
/*  36 */   private static final AtomicInteger baseConnectionID = new AtomicInteger(0);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String traceID;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String callAbortPerm = "callAbort";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int nextConnectionID() {
/*  52 */     return baseConnectionID.incrementAndGet();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  57 */     return this.traceID;
/*     */   }
/*     */   
/*     */   SQLServerConnectionPoolProxy(SQLServerConnection con) {
/*  61 */     this.traceID = " ProxyConnectionID:" + nextConnectionID();
/*  62 */     this.wrappedConnection = con;
/*     */     
/*  64 */     con.setAssociatedProxy(this);
/*  65 */     this.bIsOpen = true;
/*     */   }
/*     */   
/*     */   SQLServerConnection getWrappedConnection() {
/*  69 */     return this.wrappedConnection;
/*     */   }
/*     */   
/*     */   void checkClosed() throws SQLServerException {
/*  73 */     if (!this.bIsOpen) {
/*  74 */       SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_connectionIsClosed"), "08006", false);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Statement createStatement() throws SQLServerException {
/*  81 */     checkClosed();
/*  82 */     return this.wrappedConnection.createStatement();
/*     */   }
/*     */ 
/*     */   
/*     */   public PreparedStatement prepareStatement(String sql) throws SQLServerException {
/*  87 */     checkClosed();
/*  88 */     return this.wrappedConnection.prepareStatement(sql);
/*     */   }
/*     */ 
/*     */   
/*     */   public CallableStatement prepareCall(String sql) throws SQLServerException {
/*  93 */     checkClosed();
/*  94 */     return this.wrappedConnection.prepareCall(sql);
/*     */   }
/*     */ 
/*     */   
/*     */   public String nativeSQL(String sql) throws SQLServerException {
/*  99 */     checkClosed();
/* 100 */     return this.wrappedConnection.nativeSQL(sql);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAutoCommit(boolean newAutoCommitMode) throws SQLServerException {
/* 105 */     checkClosed();
/* 106 */     this.wrappedConnection.setAutoCommit(newAutoCommitMode);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getAutoCommit() throws SQLServerException {
/* 111 */     checkClosed();
/* 112 */     return this.wrappedConnection.getAutoCommit();
/*     */   }
/*     */ 
/*     */   
/*     */   public void commit() throws SQLServerException {
/* 117 */     checkClosed();
/* 118 */     this.wrappedConnection.commit();
/*     */   }
/*     */ 
/*     */   
/*     */   public void rollback() throws SQLServerException {
/* 123 */     checkClosed();
/* 124 */     this.wrappedConnection.rollback();
/*     */   }
/*     */ 
/*     */   
/*     */   public void abort(Executor executor) throws SQLException {
/* 129 */     if (!this.bIsOpen || null == this.wrappedConnection) {
/*     */       return;
/*     */     }
/* 132 */     if (null == executor) {
/* 133 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidArgument"));
/* 134 */       Object[] msgArgs = { "executor" };
/* 135 */       SQLServerException.makeFromDriverError(null, null, form.format(msgArgs), null, false);
/*     */     } 
/*     */ 
/*     */     
/* 139 */     SecurityManager secMgr = System.getSecurityManager();
/* 140 */     if (secMgr != null) {
/*     */       try {
/* 142 */         SQLPermission perm = new SQLPermission("callAbort");
/* 143 */         secMgr.checkPermission(perm);
/* 144 */       } catch (SecurityException ex) {
/* 145 */         MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_permissionDenied"));
/* 146 */         Object[] msgArgs = { "callAbort" };
/* 147 */         throw new SQLServerException(form.format(msgArgs), null, 0, ex);
/*     */       } 
/*     */     }
/*     */     
/* 151 */     this.bIsOpen = false;
/*     */     
/* 153 */     executor.execute(new Runnable() {
/*     */           public void run() {
/* 155 */             if (SQLServerConnectionPoolProxy.this.wrappedConnection.getConnectionLogger().isLoggable(Level.FINER))
/* 156 */               SQLServerConnectionPoolProxy.this.wrappedConnection.getConnectionLogger().finer(toString() + " Connection proxy aborted "); 
/*     */             try {
/* 158 */               SQLServerConnectionPoolProxy.this.wrappedConnection.poolCloseEventNotify();
/* 159 */               SQLServerConnectionPoolProxy.this.wrappedConnection = null;
/* 160 */             } catch (SQLException e) {
/* 161 */               throw new RuntimeException(e);
/*     */             } 
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() throws SQLServerException {
/* 169 */     if (this.bIsOpen && null != this.wrappedConnection) {
/* 170 */       if (this.wrappedConnection.getConnectionLogger().isLoggable(Level.FINER)) {
/* 171 */         this.wrappedConnection.getConnectionLogger().finer(toString() + " Connection proxy closed ");
/*     */       }
/* 173 */       this.wrappedConnection.poolCloseEventNotify();
/* 174 */       this.wrappedConnection = null;
/*     */     } 
/* 176 */     this.bIsOpen = false;
/*     */   }
/*     */   
/*     */   void internalClose() {
/* 180 */     this.bIsOpen = false;
/* 181 */     this.wrappedConnection = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isClosed() throws SQLServerException {
/* 186 */     return !this.bIsOpen;
/*     */   }
/*     */ 
/*     */   
/*     */   public DatabaseMetaData getMetaData() throws SQLServerException {
/* 191 */     checkClosed();
/* 192 */     return this.wrappedConnection.getMetaData();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setReadOnly(boolean readOnly) throws SQLServerException {
/* 197 */     checkClosed();
/* 198 */     this.wrappedConnection.setReadOnly(readOnly);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isReadOnly() throws SQLServerException {
/* 203 */     checkClosed();
/* 204 */     return this.wrappedConnection.isReadOnly();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCatalog(String catalog) throws SQLServerException {
/* 209 */     checkClosed();
/* 210 */     this.wrappedConnection.setCatalog(catalog);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getCatalog() throws SQLServerException {
/* 215 */     checkClosed();
/* 216 */     return this.wrappedConnection.getCatalog();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTransactionIsolation(int level) throws SQLServerException {
/* 221 */     checkClosed();
/* 222 */     this.wrappedConnection.setTransactionIsolation(level);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getTransactionIsolation() throws SQLServerException {
/* 227 */     checkClosed();
/* 228 */     return this.wrappedConnection.getTransactionIsolation();
/*     */   }
/*     */ 
/*     */   
/*     */   public SQLWarning getWarnings() throws SQLServerException {
/* 233 */     checkClosed();
/* 234 */     return this.wrappedConnection.getWarnings();
/*     */   }
/*     */ 
/*     */   
/*     */   public void clearWarnings() throws SQLServerException {
/* 239 */     checkClosed();
/* 240 */     this.wrappedConnection.clearWarnings();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Statement createStatement(int resultSetType, int resultSetConcurrency) throws SQLException {
/* 247 */     checkClosed();
/* 248 */     return this.wrappedConnection.createStatement(resultSetType, resultSetConcurrency);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public PreparedStatement prepareStatement(String sSql, int resultSetType, int resultSetConcurrency) throws SQLException {
/* 254 */     checkClosed();
/* 255 */     return this.wrappedConnection.prepareStatement(sSql, resultSetType, resultSetConcurrency);
/*     */   }
/*     */ 
/*     */   
/*     */   public CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
/* 260 */     checkClosed();
/* 261 */     return this.wrappedConnection.prepareCall(sql, resultSetType, resultSetConcurrency);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTypeMap(Map<String, Class<?>> map) throws SQLException {
/* 266 */     checkClosed();
/* 267 */     this.wrappedConnection.setTypeMap(map);
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, Class<?>> getTypeMap() throws SQLServerException {
/* 272 */     checkClosed();
/* 273 */     return this.wrappedConnection.getTypeMap();
/*     */   }
/*     */ 
/*     */   
/*     */   public Statement createStatement(int nType, int nConcur, int nHold) throws SQLServerException {
/* 278 */     checkClosed();
/* 279 */     return this.wrappedConnection.createStatement(nType, nConcur, nHold);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Statement createStatement(int nType, int nConcur, int nHold, SQLServerStatementColumnEncryptionSetting stmtColEncSetting) throws SQLServerException {
/* 285 */     checkClosed();
/* 286 */     return this.wrappedConnection.createStatement(nType, nConcur, nHold, stmtColEncSetting);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public PreparedStatement prepareStatement(String sql, int nType, int nConcur, int nHold) throws SQLServerException {
/* 292 */     checkClosed();
/* 293 */     return this.wrappedConnection.prepareStatement(sql, nType, nConcur, nHold);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public PreparedStatement prepareStatement(String sql, int nType, int nConcur, int nHold, SQLServerStatementColumnEncryptionSetting stmtColEncSetting) throws SQLServerException {
/* 299 */     checkClosed();
/* 300 */     return this.wrappedConnection.prepareStatement(sql, nType, nConcur, nHold, stmtColEncSetting);
/*     */   }
/*     */ 
/*     */   
/*     */   public CallableStatement prepareCall(String sql, int nType, int nConcur, int nHold) throws SQLServerException {
/* 305 */     checkClosed();
/* 306 */     return this.wrappedConnection.prepareCall(sql, nType, nConcur, nHold);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CallableStatement prepareCall(String sql, int nType, int nConcur, int nHold, SQLServerStatementColumnEncryptionSetting stmtColEncSetiing) throws SQLServerException {
/* 312 */     checkClosed();
/* 313 */     return this.wrappedConnection.prepareCall(sql, nType, nConcur, nHold, stmtColEncSetiing);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PreparedStatement prepareStatement(String sql, int flag) throws SQLServerException {
/* 320 */     checkClosed();
/* 321 */     return this.wrappedConnection.prepareStatement(sql, flag);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public PreparedStatement prepareStatement(String sql, int flag, SQLServerStatementColumnEncryptionSetting stmtColEncSetting) throws SQLServerException {
/* 327 */     checkClosed();
/* 328 */     return this.wrappedConnection.prepareStatement(sql, flag, stmtColEncSetting);
/*     */   }
/*     */ 
/*     */   
/*     */   public PreparedStatement prepareStatement(String sql, int[] columnIndexes) throws SQLServerException {
/* 333 */     checkClosed();
/* 334 */     return this.wrappedConnection.prepareStatement(sql, columnIndexes);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public PreparedStatement prepareStatement(String sql, int[] columnIndexes, SQLServerStatementColumnEncryptionSetting stmtColEncSetting) throws SQLServerException {
/* 340 */     checkClosed();
/* 341 */     return this.wrappedConnection.prepareStatement(sql, columnIndexes, stmtColEncSetting);
/*     */   }
/*     */ 
/*     */   
/*     */   public PreparedStatement prepareStatement(String sql, String[] columnNames) throws SQLServerException {
/* 346 */     checkClosed();
/* 347 */     return this.wrappedConnection.prepareStatement(sql, columnNames);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public PreparedStatement prepareStatement(String sql, String[] columnNames, SQLServerStatementColumnEncryptionSetting stmtColEncSetting) throws SQLServerException {
/* 353 */     checkClosed();
/* 354 */     return this.wrappedConnection.prepareStatement(sql, columnNames, stmtColEncSetting);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void releaseSavepoint(Savepoint savepoint) throws SQLException {
/* 361 */     checkClosed();
/* 362 */     this.wrappedConnection.releaseSavepoint(savepoint);
/*     */   }
/*     */ 
/*     */   
/*     */   public Savepoint setSavepoint(String sName) throws SQLServerException {
/* 367 */     checkClosed();
/* 368 */     return this.wrappedConnection.setSavepoint(sName);
/*     */   }
/*     */ 
/*     */   
/*     */   public Savepoint setSavepoint() throws SQLServerException {
/* 373 */     checkClosed();
/* 374 */     return this.wrappedConnection.setSavepoint();
/*     */   }
/*     */ 
/*     */   
/*     */   public void rollback(Savepoint s) throws SQLServerException {
/* 379 */     checkClosed();
/* 380 */     this.wrappedConnection.rollback(s);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getHoldability() throws SQLServerException {
/* 385 */     checkClosed();
/* 386 */     return this.wrappedConnection.getHoldability();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setHoldability(int nNewHold) throws SQLServerException {
/* 391 */     checkClosed();
/* 392 */     this.wrappedConnection.setHoldability(nNewHold);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getNetworkTimeout() throws SQLException {
/* 397 */     checkClosed();
/* 398 */     return this.wrappedConnection.getNetworkTimeout();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setNetworkTimeout(Executor executor, int timeout) throws SQLException {
/* 403 */     checkClosed();
/* 404 */     this.wrappedConnection.setNetworkTimeout(executor, timeout);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSchema() throws SQLException {
/* 409 */     checkClosed();
/* 410 */     return this.wrappedConnection.getSchema();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSchema(String schema) throws SQLException {
/* 415 */     checkClosed();
/* 416 */     this.wrappedConnection.setSchema(schema);
/*     */   }
/*     */ 
/*     */   
/*     */   public Array createArrayOf(String typeName, Object[] elements) throws SQLException {
/* 421 */     checkClosed();
/* 422 */     return this.wrappedConnection.createArrayOf(typeName, elements);
/*     */   }
/*     */ 
/*     */   
/*     */   public Blob createBlob() throws SQLException {
/* 427 */     checkClosed();
/* 428 */     return this.wrappedConnection.createBlob();
/*     */   }
/*     */ 
/*     */   
/*     */   public Clob createClob() throws SQLException {
/* 433 */     checkClosed();
/* 434 */     return this.wrappedConnection.createClob();
/*     */   }
/*     */ 
/*     */   
/*     */   public NClob createNClob() throws SQLException {
/* 439 */     checkClosed();
/* 440 */     return this.wrappedConnection.createNClob();
/*     */   }
/*     */ 
/*     */   
/*     */   public SQLXML createSQLXML() throws SQLException {
/* 445 */     checkClosed();
/* 446 */     return this.wrappedConnection.createSQLXML();
/*     */   }
/*     */ 
/*     */   
/*     */   public Struct createStruct(String typeName, Object[] attributes) throws SQLException {
/* 451 */     checkClosed();
/* 452 */     return this.wrappedConnection.createStruct(typeName, attributes);
/*     */   }
/*     */ 
/*     */   
/*     */   public Properties getClientInfo() throws SQLException {
/* 457 */     checkClosed();
/* 458 */     return this.wrappedConnection.getClientInfo();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getClientInfo(String name) throws SQLException {
/* 463 */     checkClosed();
/* 464 */     return this.wrappedConnection.getClientInfo(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setClientInfo(Properties properties) throws SQLClientInfoException {
/* 471 */     this.wrappedConnection.setClientInfo(properties);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setClientInfo(String name, String value) throws SQLClientInfoException {
/* 478 */     this.wrappedConnection.setClientInfo(name, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isValid(int timeout) throws SQLException {
/* 483 */     checkClosed();
/* 484 */     return this.wrappedConnection.isValid(timeout);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isWrapperFor(Class<?> iface) throws SQLException {
/* 489 */     this.wrappedConnection.getConnectionLogger().entering(toString(), "isWrapperFor", iface);
/* 490 */     boolean f = iface.isInstance(this);
/* 491 */     this.wrappedConnection.getConnectionLogger().exiting(toString(), "isWrapperFor", Boolean.valueOf(f));
/* 492 */     return f;
/*     */   }
/*     */   
/*     */   public <T> T unwrap(Class<T> iface) throws SQLException {
/*     */     T t;
/* 497 */     this.wrappedConnection.getConnectionLogger().entering(toString(), "unwrap", iface);
/*     */     
/*     */     try {
/* 500 */       t = iface.cast(this);
/* 501 */     } catch (ClassCastException e) {
/* 502 */       SQLServerException newe = new SQLServerException(e.getMessage(), e);
/* 503 */       throw newe;
/*     */     } 
/* 505 */     this.wrappedConnection.getConnectionLogger().exiting(toString(), "unwrap", t);
/* 506 */     return t;
/*     */   }
/*     */ 
/*     */   
/*     */   public UUID getClientConnectionId() throws SQLServerException {
/* 511 */     checkClosed();
/* 512 */     return this.wrappedConnection.getClientConnectionId();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSendTimeAsDatetime(boolean sendTimeAsDateTimeValue) throws SQLServerException {
/* 517 */     checkClosed();
/* 518 */     this.wrappedConnection.setSendTimeAsDatetime(sendTimeAsDateTimeValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getSendTimeAsDatetime() throws SQLServerException {
/* 523 */     checkClosed();
/* 524 */     return this.wrappedConnection.getSendTimeAsDatetime();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getDiscardedServerPreparedStatementCount() {
/* 529 */     return this.wrappedConnection.getDiscardedServerPreparedStatementCount();
/*     */   }
/*     */ 
/*     */   
/*     */   public void closeUnreferencedPreparedStatementHandles() {
/* 534 */     this.wrappedConnection.closeUnreferencedPreparedStatementHandles();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getEnablePrepareOnFirstPreparedStatementCall() {
/* 539 */     return this.wrappedConnection.getEnablePrepareOnFirstPreparedStatementCall();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setEnablePrepareOnFirstPreparedStatementCall(boolean value) {
/* 544 */     this.wrappedConnection.setEnablePrepareOnFirstPreparedStatementCall(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getServerPreparedStatementDiscardThreshold() {
/* 549 */     return this.wrappedConnection.getServerPreparedStatementDiscardThreshold();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setServerPreparedStatementDiscardThreshold(int value) {
/* 554 */     this.wrappedConnection.setServerPreparedStatementDiscardThreshold(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setStatementPoolingCacheSize(int value) {
/* 559 */     this.wrappedConnection.setStatementPoolingCacheSize(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getStatementPoolingCacheSize() {
/* 564 */     return this.wrappedConnection.getStatementPoolingCacheSize();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isStatementPoolingEnabled() {
/* 569 */     return this.wrappedConnection.isStatementPoolingEnabled();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getStatementHandleCacheEntryCount() {
/* 574 */     return this.wrappedConnection.getStatementHandleCacheEntryCount();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDisableStatementPooling(boolean value) {
/* 579 */     this.wrappedConnection.setDisableStatementPooling(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getDisableStatementPooling() {
/* 584 */     return this.wrappedConnection.getDisableStatementPooling();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setUseFmtOnly(boolean useFmtOnly) {
/* 589 */     this.wrappedConnection.setUseFmtOnly(useFmtOnly);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getUseFmtOnly() {
/* 594 */     return this.wrappedConnection.getUseFmtOnly();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getDelayLoadingLobs() {
/* 599 */     return this.wrappedConnection.getDelayLoadingLobs();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDelayLoadingLobs(boolean delayLoadingLobs) {
/* 604 */     this.wrappedConnection.setDelayLoadingLobs(delayLoadingLobs);
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerConnectionPoolProxy.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */