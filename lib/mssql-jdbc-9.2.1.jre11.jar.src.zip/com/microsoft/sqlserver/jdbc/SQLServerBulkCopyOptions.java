/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.text.MessageFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SQLServerBulkCopyOptions
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 711570696894155194L;
/*  93 */   private int batchSize = 0;
/*  94 */   private int bulkCopyTimeout = 60;
/*     */   
/*     */   private boolean checkConstraints = false;
/*     */   
/*     */   private boolean fireTriggers = false;
/*     */   
/*     */   private boolean keepIdentity = false;
/*     */   
/*     */   private boolean keepNulls = false;
/*     */   
/*     */   private boolean tableLock = false;
/*     */   
/*     */   private boolean useInternalTransaction = false;
/*     */   private boolean allowEncryptedValueModifications = false;
/*     */   
/*     */   public int getBatchSize() {
/* 110 */     return this.batchSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBatchSize(int batchSize) throws SQLServerException {
/* 122 */     if (batchSize >= 0) {
/* 123 */       this.batchSize = batchSize;
/*     */     } else {
/* 125 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidNegativeArg"));
/* 126 */       Object[] msgArgs = { "batchSize" };
/* 127 */       SQLServerException.makeFromDriverError(null, null, form.format(msgArgs), null, false);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getBulkCopyTimeout() {
/* 137 */     return this.bulkCopyTimeout;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBulkCopyTimeout(int timeout) throws SQLServerException {
/* 149 */     if (timeout >= 0) {
/* 150 */       this.bulkCopyTimeout = timeout;
/*     */     } else {
/* 152 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidNegativeArg"));
/* 153 */       Object[] msgArgs = { "timeout" };
/* 154 */       SQLServerException.makeFromDriverError(null, null, form.format(msgArgs), null, false);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isKeepIdentity() {
/* 164 */     return this.keepIdentity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setKeepIdentity(boolean keepIdentity) {
/* 174 */     this.keepIdentity = keepIdentity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isKeepNulls() {
/* 185 */     return this.keepNulls;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setKeepNulls(boolean keepNulls) {
/* 197 */     this.keepNulls = keepNulls;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTableLock() {
/* 206 */     return this.tableLock;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTableLock(boolean tableLock) {
/* 216 */     this.tableLock = tableLock;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isUseInternalTransaction() {
/* 225 */     return this.useInternalTransaction;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUseInternalTransaction(boolean useInternalTransaction) {
/* 235 */     this.useInternalTransaction = useInternalTransaction;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCheckConstraints() {
/* 244 */     return this.checkConstraints;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCheckConstraints(boolean checkConstraints) {
/* 254 */     this.checkConstraints = checkConstraints;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFireTriggers() {
/* 263 */     return this.fireTriggers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFireTriggers(boolean fireTriggers) {
/* 273 */     this.fireTriggers = fireTriggers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAllowEncryptedValueModifications() {
/* 282 */     return this.allowEncryptedValueModifications;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowEncryptedValueModifications(boolean allowEncryptedValueModifications) {
/* 300 */     this.allowEncryptedValueModifications = allowEncryptedValueModifications;
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerBulkCopyOptions.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */