package com.microsoft.sqlserver.jdbc;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.UUID;

public interface ISQLServerConnection extends Connection {
  public static final int TRANSACTION_SNAPSHOT = 4096;
  
  UUID getClientConnectionId() throws SQLServerException;
  
  Statement createStatement(int paramInt1, int paramInt2, int paramInt3, SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting) throws SQLServerException;
  
  PreparedStatement prepareStatement(String paramString, int paramInt, SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting) throws SQLServerException;
  
  PreparedStatement prepareStatement(String paramString, int[] paramArrayOfint, SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting) throws SQLServerException;
  
  PreparedStatement prepareStatement(String paramString, String[] paramArrayOfString, SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting) throws SQLServerException;
  
  PreparedStatement prepareStatement(String paramString, int paramInt1, int paramInt2, int paramInt3, SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting) throws SQLServerException;
  
  CallableStatement prepareCall(String paramString, int paramInt1, int paramInt2, int paramInt3, SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting) throws SQLServerException;
  
  void setSendTimeAsDatetime(boolean paramBoolean) throws SQLServerException;
  
  boolean getSendTimeAsDatetime() throws SQLServerException;
  
  int getDiscardedServerPreparedStatementCount();
  
  void closeUnreferencedPreparedStatementHandles();
  
  boolean getEnablePrepareOnFirstPreparedStatementCall();
  
  void setEnablePrepareOnFirstPreparedStatementCall(boolean paramBoolean);
  
  int getServerPreparedStatementDiscardThreshold();
  
  void setServerPreparedStatementDiscardThreshold(int paramInt);
  
  void setStatementPoolingCacheSize(int paramInt);
  
  int getStatementPoolingCacheSize();
  
  boolean isStatementPoolingEnabled();
  
  int getStatementHandleCacheEntryCount();
  
  void setDisableStatementPooling(boolean paramBoolean);
  
  boolean getDisableStatementPooling();
  
  boolean getUseFmtOnly();
  
  void setUseFmtOnly(boolean paramBoolean);
  
  boolean getDelayLoadingLobs();
  
  void setDelayLoadingLobs(boolean paramBoolean);
}


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\ISQLServerConnection.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */