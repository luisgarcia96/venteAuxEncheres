/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import java.text.MessageFormat;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SQLServerSavepoint
/*    */   implements ISQLServerSavepoint
/*    */ {
/*    */   private static final long serialVersionUID = 1857415943191289598L;
/*    */   private final String sName;
/*    */   private final int nId;
/*    */   private final SQLServerConnection con;
/*    */   
/*    */   public SQLServerSavepoint(SQLServerConnection con, String sName) {
/* 38 */     this.con = con;
/* 39 */     if (sName == null) {
/* 40 */       this.nId = con.getNextSavepointId();
/* 41 */       this.sName = null;
/*    */     } else {
/* 43 */       this.sName = sName;
/* 44 */       this.nId = 0;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public String getSavepointName() throws SQLServerException {
/* 50 */     if (this.sName == null) {
/* 51 */       SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_savepointNotNamed"), null, false);
/*    */     }
/* 53 */     return this.sName;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getLabel() {
/* 58 */     if (this.sName == null) {
/* 59 */       return "S" + this.nId;
/*    */     }
/* 61 */     return this.sName;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isNamed() {
/* 66 */     return (this.sName != null);
/*    */   }
/*    */ 
/*    */   
/*    */   public int getSavepointId() throws SQLServerException {
/* 71 */     if (this.sName != null) {
/* 72 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_savepointNamed"));
/* 73 */       Object[] msgArgs = { this.sName };
/* 74 */       SQLServerException.makeFromDriverError(this.con, null, form.format(msgArgs), null, false);
/*    */     } 
/* 76 */     return this.nId;
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerSavepoint.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */