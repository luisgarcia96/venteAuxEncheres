/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import java.util.Properties;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.sql.XAConnection;
/*     */ import javax.transaction.xa.XAResource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SQLServerXAConnection
/*     */   extends SQLServerPooledConnection
/*     */   implements XAConnection
/*     */ {
/*     */   private static final long serialVersionUID = -8154621218821899459L;
/*     */   private SQLServerXAResource XAResource;
/*     */   private SQLServerConnection physicalControlConnection;
/*     */   private Logger xaLogger;
/*     */   
/*     */   SQLServerXAConnection(SQLServerDataSource ds, String user, String pwd) throws SQLException {
/*  36 */     super(ds, user, pwd);
/*     */     
/*  38 */     this.xaLogger = SQLServerXADataSource.xaLogger;
/*  39 */     SQLServerConnection con = getPhysicalConnection();
/*     */     
/*  41 */     Properties controlConnectionProperties = (Properties)con.activeConnectionProperties.clone();
/*     */ 
/*     */     
/*  44 */     controlConnectionProperties
/*  45 */       .setProperty(SQLServerDriverBooleanProperty.SEND_STRING_PARAMETERS_AS_UNICODE.toString(), "true");
/*  46 */     controlConnectionProperties.remove(SQLServerDriverStringProperty.SELECT_METHOD.toString());
/*     */ 
/*     */ 
/*     */     
/*  50 */     String auth = controlConnectionProperties.getProperty(SQLServerDriverStringProperty.AUTHENTICATION_SCHEME.toString());
/*  51 */     if (null != auth && AuthenticationScheme.ntlm == AuthenticationScheme.valueOfString(auth)) {
/*  52 */       controlConnectionProperties.setProperty(SQLServerDriverStringProperty.PASSWORD.toString(), pwd);
/*     */     }
/*     */ 
/*     */     
/*  56 */     String trustStorePassword = ds.getTrustStorePassword();
/*  57 */     if (null == trustStorePassword) {
/*     */ 
/*     */ 
/*     */       
/*  61 */       Properties urlProps = Util.parseUrl(ds.getURL(), this.xaLogger);
/*  62 */       trustStorePassword = urlProps.getProperty(SQLServerDriverStringProperty.TRUST_STORE_PASSWORD.toString());
/*     */     } 
/*     */ 
/*     */     
/*  66 */     if (null != trustStorePassword) {
/*  67 */       controlConnectionProperties.setProperty(SQLServerDriverStringProperty.TRUST_STORE_PASSWORD.toString(), trustStorePassword);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  73 */     String clientCertificate = ds.getClientCertificate();
/*  74 */     if (null != clientCertificate && clientCertificate.length() > 0) {
/*  75 */       Properties urlProps = Util.parseUrl(ds.getURL(), this.xaLogger);
/*     */       
/*  77 */       String clientKeyPassword = urlProps.getProperty(SQLServerDriverStringProperty.CLIENT_KEY_PASSWORD.toString());
/*     */       
/*  79 */       if (null != clientKeyPassword) {
/*  80 */         controlConnectionProperties.setProperty(SQLServerDriverStringProperty.CLIENT_KEY_PASSWORD.toString(), clientKeyPassword);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  85 */     if (this.xaLogger.isLoggable(Level.FINER))
/*  86 */       this.xaLogger.finer("Creating an internal control connection for" + toString()); 
/*  87 */     this.physicalControlConnection = null;
/*  88 */     if (Util.use43Wrapper()) {
/*  89 */       this.physicalControlConnection = new SQLServerConnection43(toString());
/*     */     } else {
/*  91 */       this.physicalControlConnection = new SQLServerConnection(toString());
/*     */     } 
/*  93 */     this.physicalControlConnection.connect(controlConnectionProperties, null);
/*  94 */     if (this.xaLogger.isLoggable(Level.FINER)) {
/*  95 */       this.xaLogger.finer("Created an internal control connection" + this.physicalControlConnection.toString() + " for " + 
/*  96 */           toString() + " Physical connection:" + getPhysicalConnection().toString());
/*     */     }
/*  98 */     if (this.xaLogger.isLoggable(Level.FINER)) {
/*  99 */       this.xaLogger.finer(ds.toString() + " user:" + ds.toString());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized XAResource getXAResource() throws SQLException {
/* 107 */     if (this.XAResource == null)
/* 108 */       this.XAResource = new SQLServerXAResource(getPhysicalConnection(), this.physicalControlConnection, toString()); 
/* 109 */     return this.XAResource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws SQLException {
/* 117 */     synchronized (this) {
/* 118 */       if (this.XAResource != null) {
/* 119 */         this.XAResource.close();
/* 120 */         this.XAResource = null;
/*     */       } 
/* 122 */       if (null != this.physicalControlConnection) {
/* 123 */         this.physicalControlConnection.close();
/* 124 */         this.physicalControlConnection = null;
/*     */       } 
/*     */     } 
/* 127 */     super.close();
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerXAConnection.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */