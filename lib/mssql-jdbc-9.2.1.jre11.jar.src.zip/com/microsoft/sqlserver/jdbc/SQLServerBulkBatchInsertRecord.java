/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.RoundingMode;
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.MessageFormat;
/*     */ import java.time.OffsetDateTime;
/*     */ import java.time.OffsetTime;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.logging.Level;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SQLServerBulkBatchInsertRecord
/*     */   extends SQLServerBulkRecord
/*     */ {
/*     */   private static final long serialVersionUID = -955998113956445541L;
/*     */   private List<Parameter[]> batchParam;
/*  34 */   private int batchParamIndex = -1;
/*     */ 
/*     */   
/*     */   private List<String> columnList;
/*     */ 
/*     */   
/*     */   private List<String> valueList;
/*     */ 
/*     */   
/*     */   private static final String loggerClassName = "SQLServerBulkBatchInsertRecord";
/*     */ 
/*     */ 
/*     */   
/*     */   SQLServerBulkBatchInsertRecord(ArrayList<Parameter[]> batchParam, ArrayList<String> columnList, ArrayList<String> valueList, String encoding) throws SQLServerException {
/*  48 */     initLoggerResources();
/*  49 */     if (loggerExternal.isLoggable(Level.FINER)) {
/*  50 */       loggerExternal.entering(this.loggerPackageName, "SQLServerBulkBatchInsertRecord", new Object[] { batchParam, encoding });
/*     */     }
/*     */ 
/*     */     
/*  54 */     if (null == batchParam) {
/*  55 */       throwInvalidArgument("batchParam");
/*     */     }
/*     */     
/*  58 */     if (null == valueList) {
/*  59 */       throwInvalidArgument("valueList");
/*     */     }
/*     */     
/*  62 */     this.batchParam = (List<Parameter[]>)batchParam;
/*  63 */     this.columnList = columnList;
/*  64 */     this.valueList = valueList;
/*  65 */     this.columnMetadata = new HashMap<>();
/*     */     
/*  67 */     loggerExternal.exiting(this.loggerPackageName, "SQLServerBulkBatchInsertRecord");
/*     */   }
/*     */   
/*     */   private void initLoggerResources() {
/*  71 */     this.loggerPackageName = "com.microsoft.sqlserver.jdbc.SQLServerBulkBatchInsertRecord"; } private Object convertValue(SQLServerBulkRecord.ColumnMetadata cm, Object data) throws SQLServerException { DecimalFormat decimalFormatter; BigDecimal bd; String binData;
/*     */     OffsetTime offsetTimeValue;
/*     */     OffsetDateTime offsetDateTimeValue;
/*     */     String formatedfInput;
/*  75 */     switch (cm.columnType) {
/*     */ 
/*     */       
/*     */       case 4:
/*  79 */         decimalFormatter = new DecimalFormat("#");
/*  80 */         decimalFormatter.setRoundingMode(RoundingMode.DOWN);
/*  81 */         formatedfInput = decimalFormatter.format(Double.parseDouble(data.toString()));
/*  82 */         return Integer.valueOf(formatedfInput);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case -6:
/*     */       case 5:
/*  89 */         decimalFormatter = new DecimalFormat("#");
/*  90 */         decimalFormatter.setRoundingMode(RoundingMode.DOWN);
/*  91 */         formatedfInput = decimalFormatter.format(Double.parseDouble(data.toString()));
/*  92 */         return Short.valueOf(formatedfInput);
/*     */ 
/*     */       
/*     */       case -5:
/*  96 */         bd = new BigDecimal(data.toString().trim());
/*     */         try {
/*  98 */           return Long.valueOf(bd.setScale(0, RoundingMode.DOWN).longValueExact());
/*  99 */         } catch (ArithmeticException ex) {
/* 100 */           String value = "'" + data + "'";
/* 101 */           MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_errorConvertingValue"));
/* 102 */           throw new SQLServerException(form.format(new Object[] { value, JDBCType.of(cm.columnType) }, ), null, 0, ex);
/*     */         } 
/*     */ 
/*     */ 
/*     */       
/*     */       case 2:
/*     */       case 3:
/* 109 */         bd = new BigDecimal(data.toString().trim());
/* 110 */         return bd.setScale(cm.scale, RoundingMode.HALF_UP);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case -7:
/*     */         try {
/* 117 */           return (0.0D == Double.parseDouble(data.toString())) ? Boolean.FALSE : Boolean.TRUE;
/* 118 */         } catch (NumberFormatException e) {
/* 119 */           return Boolean.valueOf(Boolean.parseBoolean(data.toString()));
/*     */         } 
/*     */ 
/*     */       
/*     */       case 7:
/* 124 */         return Float.valueOf(Float.parseFloat(data.toString()));
/*     */ 
/*     */       
/*     */       case 8:
/* 128 */         return Double.valueOf(Double.parseDouble(data.toString()));
/*     */ 
/*     */       
/*     */       case -4:
/*     */       case -3:
/*     */       case -2:
/*     */       case 2004:
/* 135 */         if (data instanceof byte[])
/*     */         {
/*     */ 
/*     */ 
/*     */           
/* 140 */           return data;
/*     */         }
/*     */         
/* 143 */         binData = data.toString().trim();
/* 144 */         if (binData.startsWith("0x") || binData.startsWith("0X")) {
/* 145 */           return binData.substring(2);
/*     */         }
/* 147 */         return binData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 2013:
/* 156 */         if (null != cm.dateTimeFormatter) {
/* 157 */           offsetTimeValue = OffsetTime.parse(data.toString(), cm.dateTimeFormatter);
/* 158 */         } else if (this.timeFormatter != null) {
/* 159 */           offsetTimeValue = OffsetTime.parse(data.toString(), this.timeFormatter);
/*     */         } else {
/* 161 */           offsetTimeValue = OffsetTime.parse(data.toString());
/*     */         } 
/* 163 */         return offsetTimeValue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 2014:
/* 170 */         if (null != cm.dateTimeFormatter) {
/* 171 */           offsetDateTimeValue = OffsetDateTime.parse(data.toString(), cm.dateTimeFormatter);
/* 172 */         } else if (this.dateTimeFormatter != null) {
/* 173 */           offsetDateTimeValue = OffsetDateTime.parse(data.toString(), this.dateTimeFormatter);
/*     */         } else {
/* 175 */           offsetDateTimeValue = OffsetDateTime.parse(data.toString());
/*     */         } 
/* 177 */         return offsetDateTimeValue;
/*     */ 
/*     */       
/*     */       case 0:
/* 181 */         return null;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 194 */     return data; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String removeSingleQuote(String s) {
/* 200 */     int len = s.length();
/* 201 */     return (s.charAt(0) == '\'' && s.charAt(len - 1) == '\'') ? s.substring(1, len - 1) : s;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object[] getRowData() throws SQLServerException {
/* 206 */     Object[] data = new Object[this.columnMetadata.size()];
/* 207 */     int valueIndex = 0;
/*     */ 
/*     */     
/* 210 */     int columnListIndex = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 215 */     if (null != this.columnList && this.columnList.size() != this.valueList.size()) {
/* 216 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_DataSchemaMismatch"));
/* 217 */       Object[] msgArgs = new Object[0];
/* 218 */       throw new SQLServerException(form.format(msgArgs), SQLState.COL_NOT_FOUND, DriverError.NOT_SET, null);
/*     */     } 
/*     */     
/* 221 */     for (Map.Entry<Integer, SQLServerBulkRecord.ColumnMetadata> pair : this.columnMetadata.entrySet()) {
/* 222 */       Object rowData; int index = ((Integer)pair.getKey()).intValue() - 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 234 */       if (null == this.columnList || this.columnList.size() == 0) {
/* 235 */         String valueData = this.valueList.get(index);
/*     */ 
/*     */ 
/*     */         
/* 239 */         if ("?".equalsIgnoreCase(valueData)) {
/* 240 */           rowData = ((Parameter[])this.batchParam.get(this.batchParamIndex))[valueIndex++].getSetterValue();
/* 241 */         } else if ("null".equalsIgnoreCase(valueData)) {
/* 242 */           rowData = null;
/*     */ 
/*     */         
/*     */         }
/*     */         else {
/*     */ 
/*     */           
/* 249 */           rowData = removeSingleQuote(valueData);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 261 */       else if (this.columnList.size() > columnListIndex && ((String)this.columnList
/* 262 */         .get(columnListIndex)).equalsIgnoreCase(((SQLServerBulkRecord.ColumnMetadata)this.columnMetadata.get(Integer.valueOf(index + 1))).columnName)) {
/* 263 */         String valueData = this.valueList.get(columnListIndex);
/* 264 */         if ("?".equalsIgnoreCase(valueData)) {
/* 265 */           rowData = ((Parameter[])this.batchParam.get(this.batchParamIndex))[valueIndex++].getSetterValue();
/* 266 */         } else if ("null".equalsIgnoreCase(valueData)) {
/* 267 */           rowData = null;
/*     */         } else {
/* 269 */           rowData = removeSingleQuote(valueData);
/*     */         } 
/* 271 */         columnListIndex++;
/*     */       } else {
/* 273 */         rowData = null;
/*     */       } 
/*     */ 
/*     */       
/*     */       try {
/* 278 */         if (null == rowData) {
/* 279 */           data[index] = null; continue;
/*     */         } 
/* 281 */         if (0 == rowData.toString().length()) {
/* 282 */           data[index] = "";
/*     */           continue;
/*     */         } 
/* 285 */         data[index] = convertValue(pair.getValue(), rowData);
/* 286 */       } catch (IllegalArgumentException e) {
/* 287 */         String value = "'" + rowData + "'";
/* 288 */         MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_errorConvertingValue"));
/* 289 */         throw new SQLServerException(form.format(new Object[] { value, JDBCType.of(((SQLServerBulkRecord.ColumnMetadata)pair.getValue()).columnType) }, ), null, 0, e);
/*     */       }
/* 291 */       catch (ArrayIndexOutOfBoundsException e) {
/* 292 */         throw new SQLServerException(SQLServerException.getErrString("R_DataSchemaMismatch"), e);
/*     */       } 
/*     */     } 
/* 295 */     return data;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void addColumnMetadataInternal(int positionInSource, String name, int jdbcType, int precision, int scale, DateTimeFormatter dateTimeFormatter) throws SQLServerException {
/* 301 */     if (loggerExternal.isLoggable(Level.FINER))
/* 302 */       loggerExternal.entering(this.loggerPackageName, "addColumnMetadata", new Object[] {
/* 303 */             Integer.valueOf(positionInSource), name, Integer.valueOf(jdbcType), Integer.valueOf(precision), Integer.valueOf(scale)
/*     */           }); 
/* 305 */     String colName = "";
/*     */     
/* 307 */     if (0 >= positionInSource) {
/* 308 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidColumnOrdinal"));
/* 309 */       Object[] msgArgs = { Integer.valueOf(positionInSource) };
/* 310 */       throw new SQLServerException(form.format(msgArgs), SQLState.COL_NOT_FOUND, DriverError.NOT_SET, null);
/*     */     } 
/*     */     
/* 313 */     if (null != name) {
/* 314 */       colName = name.trim();
/* 315 */     } else if (null != this.columnNames && this.columnNames.length >= positionInSource) {
/* 316 */       colName = this.columnNames[positionInSource - 1];
/*     */     } 
/* 318 */     if (null != this.columnNames && positionInSource > this.columnNames.length) {
/* 319 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidColumn"));
/* 320 */       Object[] msgArgs = { Integer.valueOf(positionInSource) };
/* 321 */       throw new SQLServerException(form.format(msgArgs), SQLState.COL_NOT_FOUND, DriverError.NOT_SET, null);
/*     */     } 
/*     */     
/* 324 */     checkDuplicateColumnName(positionInSource, name);
/* 325 */     switch (jdbcType) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case -155:
/*     */       case 91:
/*     */       case 92:
/*     */       case 93:
/* 335 */         this.columnMetadata.put(Integer.valueOf(positionInSource), new SQLServerBulkRecord.ColumnMetadata(this, colName, jdbcType, precision, scale, dateTimeFormatter));
/*     */         break;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 2009:
/* 342 */         this.columnMetadata.put(Integer.valueOf(positionInSource), new SQLServerBulkRecord.ColumnMetadata(this, colName, -16, precision, scale, dateTimeFormatter));
/*     */         break;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 6:
/* 349 */         this.columnMetadata.put(Integer.valueOf(positionInSource), new SQLServerBulkRecord.ColumnMetadata(this, colName, 8, precision, scale, dateTimeFormatter));
/*     */         break;
/*     */ 
/*     */ 
/*     */       
/*     */       case 16:
/* 355 */         this.columnMetadata.put(Integer.valueOf(positionInSource), new SQLServerBulkRecord.ColumnMetadata(this, colName, -7, precision, scale, dateTimeFormatter));
/*     */         break;
/*     */ 
/*     */       
/*     */       default:
/* 360 */         this.columnMetadata.put(Integer.valueOf(positionInSource), new SQLServerBulkRecord.ColumnMetadata(this, colName, jdbcType, precision, scale, dateTimeFormatter));
/*     */         break;
/*     */     } 
/*     */     
/* 364 */     loggerExternal.exiting(this.loggerPackageName, "addColumnMetadata");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean next() throws SQLServerException {
/* 369 */     this.batchParamIndex++;
/* 370 */     return (this.batchParamIndex < this.batchParam.size());
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerBulkBatchInsertRecord.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */