package com.microsoft.sqlserver.jdbc;

import com.microsoft.sqlserver.jdbc.dataclassification.SensitivityClassification;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLType;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import microsoft.sql.DateTimeOffset;

public interface ISQLServerResultSet extends ResultSet {
  public static final int TYPE_SS_DIRECT_FORWARD_ONLY = 2003;
  
  public static final int TYPE_SS_SERVER_CURSOR_FORWARD_ONLY = 2004;
  
  public static final int TYPE_SS_SCROLL_STATIC = 1004;
  
  public static final int TYPE_SS_SCROLL_KEYSET = 1005;
  
  public static final int TYPE_SS_SCROLL_DYNAMIC = 1006;
  
  public static final int CONCUR_SS_OPTIMISTIC_CC = 1008;
  
  public static final int CONCUR_SS_SCROLL_LOCKS = 1009;
  
  public static final int CONCUR_SS_OPTIMISTIC_CCVAL = 1010;
  
  Geometry getGeometry(int paramInt) throws SQLServerException;
  
  Geometry getGeometry(String paramString) throws SQLServerException;
  
  Geography getGeography(int paramInt) throws SQLServerException;
  
  Geography getGeography(String paramString) throws SQLServerException;
  
  String getUniqueIdentifier(int paramInt) throws SQLServerException;
  
  String getUniqueIdentifier(String paramString) throws SQLServerException;
  
  Timestamp getDateTime(int paramInt) throws SQLServerException;
  
  Timestamp getDateTime(String paramString) throws SQLServerException;
  
  Timestamp getDateTime(int paramInt, Calendar paramCalendar) throws SQLServerException;
  
  Timestamp getDateTime(String paramString, Calendar paramCalendar) throws SQLServerException;
  
  Timestamp getSmallDateTime(int paramInt) throws SQLServerException;
  
  Timestamp getSmallDateTime(String paramString) throws SQLServerException;
  
  Timestamp getSmallDateTime(int paramInt, Calendar paramCalendar) throws SQLServerException;
  
  Timestamp getSmallDateTime(String paramString, Calendar paramCalendar) throws SQLServerException;
  
  DateTimeOffset getDateTimeOffset(int paramInt) throws SQLServerException;
  
  DateTimeOffset getDateTimeOffset(String paramString) throws SQLServerException;
  
  BigDecimal getMoney(int paramInt) throws SQLServerException;
  
  BigDecimal getMoney(String paramString) throws SQLServerException;
  
  BigDecimal getSmallMoney(int paramInt) throws SQLServerException;
  
  BigDecimal getSmallMoney(String paramString) throws SQLServerException;
  
  void updateDateTimeOffset(int paramInt, DateTimeOffset paramDateTimeOffset) throws SQLServerException;
  
  void updateDateTimeOffset(String paramString, DateTimeOffset paramDateTimeOffset) throws SQLServerException;
  
  void updateObject(int paramInt1, Object paramObject, int paramInt2, int paramInt3) throws SQLServerException;
  
  void updateObject(int paramInt1, Object paramObject, SQLType paramSQLType, int paramInt2, boolean paramBoolean) throws SQLServerException;
  
  void updateObject(String paramString, Object paramObject, SQLType paramSQLType, int paramInt, boolean paramBoolean) throws SQLServerException;
  
  void updateBoolean(int paramInt, boolean paramBoolean1, boolean paramBoolean2) throws SQLServerException;
  
  void updateByte(int paramInt, byte paramByte, boolean paramBoolean) throws SQLServerException;
  
  void updateShort(int paramInt, short paramShort, boolean paramBoolean) throws SQLServerException;
  
  void updateInt(int paramInt1, int paramInt2, boolean paramBoolean) throws SQLServerException;
  
  void updateLong(int paramInt, long paramLong, boolean paramBoolean) throws SQLServerException;
  
  void updateFloat(int paramInt, float paramFloat, boolean paramBoolean) throws SQLServerException;
  
  void updateDouble(int paramInt, double paramDouble, boolean paramBoolean) throws SQLServerException;
  
  void updateMoney(int paramInt, BigDecimal paramBigDecimal) throws SQLServerException;
  
  void updateMoney(int paramInt, BigDecimal paramBigDecimal, boolean paramBoolean) throws SQLServerException;
  
  void updateMoney(String paramString, BigDecimal paramBigDecimal) throws SQLServerException;
  
  void updateMoney(String paramString, BigDecimal paramBigDecimal, boolean paramBoolean) throws SQLServerException;
  
  void updateSmallMoney(int paramInt, BigDecimal paramBigDecimal) throws SQLServerException;
  
  void updateSmallMoney(int paramInt, BigDecimal paramBigDecimal, boolean paramBoolean) throws SQLServerException;
  
  void updateSmallMoney(String paramString, BigDecimal paramBigDecimal) throws SQLServerException;
  
  void updateSmallMoney(String paramString, BigDecimal paramBigDecimal, boolean paramBoolean) throws SQLServerException;
  
  void updateBigDecimal(int paramInt, BigDecimal paramBigDecimal, Integer paramInteger1, Integer paramInteger2) throws SQLServerException;
  
  void updateBigDecimal(int paramInt, BigDecimal paramBigDecimal, Integer paramInteger1, Integer paramInteger2, boolean paramBoolean) throws SQLServerException;
  
  void updateString(int paramInt, String paramString, boolean paramBoolean) throws SQLServerException;
  
  void updateNString(int paramInt, String paramString, boolean paramBoolean) throws SQLServerException;
  
  void updateNString(String paramString1, String paramString2, boolean paramBoolean) throws SQLServerException;
  
  void updateBytes(int paramInt, byte[] paramArrayOfbyte, boolean paramBoolean) throws SQLServerException;
  
  void updateDate(int paramInt, Date paramDate, boolean paramBoolean) throws SQLServerException;
  
  void updateTime(int paramInt, Time paramTime, Integer paramInteger) throws SQLServerException;
  
  void updateTime(int paramInt, Time paramTime, Integer paramInteger, boolean paramBoolean) throws SQLServerException;
  
  void updateTimestamp(int paramInt1, Timestamp paramTimestamp, int paramInt2) throws SQLServerException;
  
  void updateTimestamp(int paramInt1, Timestamp paramTimestamp, int paramInt2, boolean paramBoolean) throws SQLServerException;
  
  void updateDateTime(int paramInt, Timestamp paramTimestamp) throws SQLServerException;
  
  void updateDateTime(int paramInt, Timestamp paramTimestamp, Integer paramInteger) throws SQLServerException;
  
  void updateDateTime(int paramInt, Timestamp paramTimestamp, Integer paramInteger, boolean paramBoolean) throws SQLServerException;
  
  void updateSmallDateTime(int paramInt, Timestamp paramTimestamp) throws SQLServerException;
  
  void updateSmallDateTime(int paramInt, Timestamp paramTimestamp, Integer paramInteger) throws SQLServerException;
  
  void updateSmallDateTime(int paramInt, Timestamp paramTimestamp, Integer paramInteger, boolean paramBoolean) throws SQLServerException;
  
  void updateDateTimeOffset(int paramInt, DateTimeOffset paramDateTimeOffset, Integer paramInteger) throws SQLServerException;
  
  void updateDateTimeOffset(int paramInt, DateTimeOffset paramDateTimeOffset, Integer paramInteger, boolean paramBoolean) throws SQLServerException;
  
  void updateUniqueIdentifier(int paramInt, String paramString) throws SQLServerException;
  
  void updateUniqueIdentifier(int paramInt, String paramString, boolean paramBoolean) throws SQLServerException;
  
  void updateObject(int paramInt1, Object paramObject, int paramInt2, int paramInt3, boolean paramBoolean) throws SQLServerException;
  
  void updateBoolean(String paramString, boolean paramBoolean1, boolean paramBoolean2) throws SQLServerException;
  
  void updateByte(String paramString, byte paramByte, boolean paramBoolean) throws SQLServerException;
  
  void updateShort(String paramString, short paramShort, boolean paramBoolean) throws SQLServerException;
  
  void updateInt(String paramString, int paramInt, boolean paramBoolean) throws SQLServerException;
  
  void updateLong(String paramString, long paramLong, boolean paramBoolean) throws SQLServerException;
  
  void updateFloat(String paramString, float paramFloat, boolean paramBoolean) throws SQLServerException;
  
  void updateDouble(String paramString, double paramDouble, boolean paramBoolean) throws SQLServerException;
  
  void updateBigDecimal(String paramString, BigDecimal paramBigDecimal, boolean paramBoolean) throws SQLServerException;
  
  void updateBigDecimal(String paramString, BigDecimal paramBigDecimal, Integer paramInteger1, Integer paramInteger2) throws SQLServerException;
  
  void updateBigDecimal(String paramString, BigDecimal paramBigDecimal, Integer paramInteger1, Integer paramInteger2, boolean paramBoolean) throws SQLServerException;
  
  void updateString(String paramString1, String paramString2, boolean paramBoolean) throws SQLServerException;
  
  void updateBytes(String paramString, byte[] paramArrayOfbyte, boolean paramBoolean) throws SQLServerException;
  
  void updateDate(String paramString, Date paramDate, boolean paramBoolean) throws SQLServerException;
  
  void updateTime(String paramString, Time paramTime, int paramInt) throws SQLServerException;
  
  void updateTime(String paramString, Time paramTime, int paramInt, boolean paramBoolean) throws SQLServerException;
  
  void updateTimestamp(String paramString, Timestamp paramTimestamp, int paramInt) throws SQLServerException;
  
  void updateTimestamp(String paramString, Timestamp paramTimestamp, int paramInt, boolean paramBoolean) throws SQLServerException;
  
  void updateDateTime(String paramString, Timestamp paramTimestamp) throws SQLServerException;
  
  void updateDateTime(String paramString, Timestamp paramTimestamp, int paramInt) throws SQLServerException;
  
  void updateDateTime(String paramString, Timestamp paramTimestamp, int paramInt, boolean paramBoolean) throws SQLServerException;
  
  void updateSmallDateTime(String paramString, Timestamp paramTimestamp) throws SQLServerException;
  
  void updateSmallDateTime(String paramString, Timestamp paramTimestamp, int paramInt) throws SQLServerException;
  
  void updateSmallDateTime(String paramString, Timestamp paramTimestamp, int paramInt, boolean paramBoolean) throws SQLServerException;
  
  void updateDateTimeOffset(String paramString, DateTimeOffset paramDateTimeOffset, int paramInt) throws SQLServerException;
  
  void updateDateTimeOffset(String paramString, DateTimeOffset paramDateTimeOffset, int paramInt, boolean paramBoolean) throws SQLServerException;
  
  void updateUniqueIdentifier(String paramString1, String paramString2) throws SQLServerException;
  
  void updateUniqueIdentifier(String paramString1, String paramString2, boolean paramBoolean) throws SQLServerException;
  
  void updateObject(String paramString, Object paramObject, int paramInt1, int paramInt2) throws SQLServerException;
  
  void updateObject(String paramString, Object paramObject, int paramInt1, int paramInt2, boolean paramBoolean) throws SQLServerException;
  
  SensitivityClassification getSensitivityClassification();
}


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\ISQLServerResultSet.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */