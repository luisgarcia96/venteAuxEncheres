/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.security.AccessControlContext;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.security.auth.Subject;
/*     */ import javax.security.auth.login.Configuration;
/*     */ import javax.security.auth.login.LoginContext;
/*     */ import javax.security.auth.login.LoginException;
/*     */ import org.ietf.jgss.GSSContext;
/*     */ import org.ietf.jgss.GSSCredential;
/*     */ import org.ietf.jgss.GSSException;
/*     */ import org.ietf.jgss.GSSManager;
/*     */ import org.ietf.jgss.GSSName;
/*     */ import org.ietf.jgss.Oid;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class KerbAuthentication
/*     */   extends SSPIAuthentication
/*     */ {
/*  33 */   private static final Logger authLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.KerbAuthentication");
/*     */   
/*     */   private final SQLServerConnection con;
/*     */   
/*     */   private final String spn;
/*  38 */   private final GSSManager manager = GSSManager.getInstance();
/*  39 */   private LoginContext lc = null;
/*     */   private boolean isUserCreatedCredential = false;
/*  41 */   private GSSCredential peerCredentials = null;
/*  42 */   private GSSContext peerContext = null;
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  47 */     Configuration.setConfiguration(new JaasConfiguration(Configuration.getConfiguration()));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void intAuthInit() throws SQLServerException {
/*     */     try {
/*  54 */       Oid kerberos = new Oid("1.2.840.113554.1.2.2");
/*     */ 
/*     */ 
/*     */       
/*  58 */       GSSName remotePeerName = this.manager.createName(this.spn, (Oid)null);
/*     */       
/*  60 */       if (null != this.peerCredentials) {
/*  61 */         this.peerContext = this.manager.createContext(remotePeerName, kerberos, this.peerCredentials, 0);
/*     */         
/*  63 */         this.peerContext.requestCredDeleg(false);
/*  64 */         this.peerContext.requestMutualAuth(true);
/*  65 */         this.peerContext.requestInteg(true);
/*     */       } else {
/*  67 */         Subject currentSubject; String configName = this.con.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.JAAS_CONFIG_NAME
/*  68 */             .toString(), SQLServerDriverStringProperty.JAAS_CONFIG_NAME
/*  69 */             .getDefaultValue());
/*     */         
/*  71 */         KerbCallback callback = new KerbCallback(this.con);
/*     */         try {
/*  73 */           AccessControlContext context = AccessController.getContext();
/*  74 */           currentSubject = Subject.getSubject(context);
/*  75 */           if (null == currentSubject) {
/*  76 */             this.lc = new LoginContext(configName, callback);
/*  77 */             this.lc.login();
/*     */             
/*  79 */             currentSubject = this.lc.getSubject();
/*     */           } 
/*  81 */         } catch (LoginException le) {
/*  82 */           if (authLogger.isLoggable(Level.FINE)) {
/*  83 */             authLogger.fine(toString() + "Failed to login using Kerberos due to " + toString() + ":" + le.getClass().getName());
/*     */           }
/*     */ 
/*     */           
/*     */           try {
/*  88 */             this.con.terminate(0, 
/*  89 */                 SQLServerException.getErrString("R_integratedAuthenticationFailed"), le);
/*  90 */           } catch (SQLServerException alwaysTriggered) {
/*  91 */             String message = MessageFormat.format(SQLServerException.getErrString("R_kerberosLoginFailed"), new Object[] { alwaysTriggered
/*  92 */                   .getMessage(), le.getClass().getName(), le.getMessage() });
/*  93 */             if (callback.getUsernameRequested() != null) {
/*  94 */               message = MessageFormat.format(
/*  95 */                   SQLServerException.getErrString("R_kerberosLoginFailedForUsername"), new Object[] { callback
/*  96 */                     .getUsernameRequested(), message });
/*     */             }
/*     */ 
/*     */             
/* 100 */             throw new SQLServerException(message, alwaysTriggered.getSQLState(), 18456, le);
/*     */           } 
/*     */           
/*     */           return;
/*     */         } 
/*     */         
/* 106 */         if (authLogger.isLoggable(Level.FINER)) {
/* 107 */           authLogger.finer(toString() + " Getting client credentials");
/*     */         }
/* 109 */         this.peerCredentials = getClientCredential(currentSubject, this.manager, kerberos);
/* 110 */         if (authLogger.isLoggable(Level.FINER)) {
/* 111 */           authLogger.finer(toString() + " creating security context");
/*     */         }
/*     */         
/* 114 */         this.peerContext = this.manager.createContext(remotePeerName, kerberos, this.peerCredentials, 0);
/*     */ 
/*     */         
/* 117 */         this.peerContext.requestCredDeleg(true);
/* 118 */         this.peerContext.requestMutualAuth(true);
/* 119 */         this.peerContext.requestInteg(true);
/*     */       } 
/* 121 */     } catch (GSSException ge) {
/* 122 */       if (authLogger.isLoggable(Level.FINER)) {
/* 123 */         authLogger.finer(toString() + "initAuthInit failed GSSException:-" + toString());
/*     */       }
/* 125 */       this.con.terminate(0, 
/* 126 */           SQLServerException.getErrString("R_integratedAuthenticationFailed"), ge);
/* 127 */     } catch (PrivilegedActionException ge) {
/* 128 */       if (authLogger.isLoggable(Level.FINER)) {
/* 129 */         authLogger.finer(toString() + "initAuthInit failed privileged exception:-" + toString());
/*     */       }
/* 131 */       this.con.terminate(0, 
/* 132 */           SQLServerException.getErrString("R_integratedAuthenticationFailed"), ge);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static GSSCredential getClientCredential(Subject subject, final GSSManager gssManager, final Oid kerboid) throws PrivilegedActionException {
/* 140 */     PrivilegedExceptionAction<GSSCredential> action = new PrivilegedExceptionAction<GSSCredential>() {
/*     */         public GSSCredential run() throws GSSException {
/* 142 */           return gssManager.createCredential((GSSName)null, 0, kerboid, 1);
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 149 */     Object credential = Subject.doAs(subject, action);
/* 150 */     return (GSSCredential)credential;
/*     */   }
/*     */   
/*     */   private byte[] intAuthHandShake(byte[] pin, boolean[] done) throws SQLServerException {
/*     */     try {
/* 155 */       if (authLogger.isLoggable(Level.FINER)) {
/* 156 */         authLogger.finer(toString() + " Sending token to server over secure context");
/*     */       }
/* 158 */       byte[] byteToken = this.peerContext.initSecContext(pin, 0, pin.length);
/*     */       
/* 160 */       if (this.peerContext.isEstablished()) {
/* 161 */         done[0] = true;
/* 162 */         if (authLogger.isLoggable(Level.FINER)) {
/* 163 */           authLogger.finer(toString() + "Authentication done.");
/*     */         }
/* 165 */       } else if (null == byteToken) {
/*     */         
/* 167 */         if (authLogger.isLoggable(Level.INFO)) {
/* 168 */           authLogger.info(toString() + "byteToken is null in initSecContext.");
/*     */         }
/* 170 */         this.con.terminate(0, 
/* 171 */             SQLServerException.getErrString("R_integratedAuthenticationFailed"));
/*     */       } 
/* 173 */       return byteToken;
/* 174 */     } catch (GSSException ge) {
/* 175 */       if (authLogger.isLoggable(Level.FINER)) {
/* 176 */         authLogger.finer(toString() + "initSecContext Failed :-" + toString());
/*     */       }
/* 178 */       this.con.terminate(0, 
/* 179 */           SQLServerException.getErrString("R_integratedAuthenticationFailed"), ge);
/*     */ 
/*     */       
/* 182 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   KerbAuthentication(SQLServerConnection con, String address, int port) {
/* 187 */     this.con = con;
/* 188 */     this.spn = (null != con) ? getSpn(con) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   KerbAuthentication(SQLServerConnection con, String address, int port, GSSCredential impersonatedUserCred, boolean isUserCreated) {
/* 200 */     this(con, address, port);
/* 201 */     this.peerCredentials = impersonatedUserCred;
/* 202 */     this.isUserCreatedCredential = isUserCreated;
/*     */   }
/*     */   
/*     */   byte[] generateClientContext(byte[] pin, boolean[] done) throws SQLServerException {
/* 206 */     if (null == this.peerContext) {
/* 207 */       intAuthInit();
/*     */     }
/* 209 */     return intAuthHandShake(pin, done);
/*     */   }
/*     */   
/*     */   void releaseClientContext() {
/*     */     try {
/* 214 */       if (null != this.peerCredentials && !this.isUserCreatedCredential) {
/* 215 */         this.peerCredentials.dispose();
/* 216 */       } else if (null != this.peerCredentials && this.isUserCreatedCredential) {
/* 217 */         this.peerCredentials = null;
/*     */       } 
/* 219 */       if (null != this.peerContext) {
/* 220 */         this.peerContext.dispose();
/*     */       }
/* 222 */       if (null != this.lc) {
/* 223 */         this.lc.logout();
/*     */       }
/* 225 */     } catch (LoginException e) {
/*     */ 
/*     */       
/* 228 */       if (authLogger.isLoggable(Level.FINE)) {
/* 229 */         authLogger.fine(toString() + " Release of the credentials failed LoginException: " + toString());
/*     */       }
/* 231 */     } catch (GSSException e) {
/*     */ 
/*     */       
/* 234 */       if (authLogger.isLoggable(Level.FINE))
/* 235 */         authLogger.fine(toString() + " Release of the credentials failed GSSException: " + toString()); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\KerbAuthentication.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */