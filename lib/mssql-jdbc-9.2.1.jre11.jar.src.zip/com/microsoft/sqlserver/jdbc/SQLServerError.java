/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SQLServerError
/*     */   extends StreamPacket
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -7304033613218700719L;
/*  18 */   private String errorMessage = "";
/*     */   
/*     */   private int errorNumber;
/*     */   
/*     */   private int errorState;
/*     */   
/*     */   private int errorSeverity;
/*     */   
/*     */   private String serverName;
/*     */   
/*     */   private String procName;
/*     */   private long lineNumber;
/*     */   
/*     */   public String getErrorMessage() {
/*  32 */     return this.errorMessage;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getErrorNumber() {
/*  41 */     return this.errorNumber;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getErrorState() {
/*  50 */     return this.errorState;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getErrorSeverity() {
/*  59 */     return this.errorSeverity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getServerName() {
/*  68 */     return this.serverName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getProcedureName() {
/*  77 */     return this.procName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getLineNumber() {
/*  87 */     return this.lineNumber;
/*     */   }
/*     */   
/*     */   SQLServerError() {
/*  91 */     super(170);
/*     */   }
/*     */   
/*     */   void setFromTDS(TDSReader tdsReader) throws SQLServerException {
/*  95 */     if (170 != tdsReader.readUnsignedByte() && 
/*  96 */       !$assertionsDisabled) throw new AssertionError(); 
/*  97 */     setContentsFromTDS(tdsReader);
/*     */   }
/*     */   
/*     */   void setContentsFromTDS(TDSReader tdsReader) throws SQLServerException {
/* 101 */     tdsReader.readUnsignedShort();
/* 102 */     this.errorNumber = tdsReader.readInt();
/* 103 */     this.errorState = tdsReader.readUnsignedByte();
/* 104 */     this.errorSeverity = tdsReader.readUnsignedByte();
/* 105 */     this.errorMessage = tdsReader.readUnicodeString(tdsReader.readUnsignedShort());
/* 106 */     this.serverName = tdsReader.readUnicodeString(tdsReader.readUnsignedByte());
/* 107 */     this.procName = tdsReader.readUnicodeString(tdsReader.readUnsignedByte());
/* 108 */     this.lineNumber = tdsReader.readUnsignedInt();
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerError.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */