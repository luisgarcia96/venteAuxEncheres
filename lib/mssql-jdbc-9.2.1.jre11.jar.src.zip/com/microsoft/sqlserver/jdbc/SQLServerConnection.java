/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.Serializable;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.net.DatagramPacket;
/*      */ import java.net.DatagramSocket;
/*      */ import java.net.IDN;
/*      */ import java.net.InetAddress;
/*      */ import java.net.InetSocketAddress;
/*      */ import java.net.SocketException;
/*      */ import java.net.UnknownHostException;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.charset.StandardCharsets;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.CallableStatement;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Connection;
/*      */ import java.sql.DatabaseMetaData;
/*      */ import java.sql.NClob;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLClientInfoException;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLPermission;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.SQLXML;
/*      */ import java.sql.Savepoint;
/*      */ import java.sql.Statement;
/*      */ import java.sql.Struct;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.UUID;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.ConcurrentLinkedQueue;
/*      */ import java.util.concurrent.Executor;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import java.util.concurrent.atomic.AtomicInteger;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ import mssql.googlecode.cityhash.CityHash;
/*      */ import mssql.googlecode.concurrentlinkedhashmap.ConcurrentLinkedHashMap;
/*      */ import mssql.googlecode.concurrentlinkedhashmap.EvictionListener;
/*      */ import org.ietf.jgss.GSSCredential;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class SQLServerConnection
/*      */   implements ISQLServerConnection, Serializable
/*      */ {
/*      */   private static final long serialVersionUID = 1965647556064751510L;
/*      */   long timerExpire;
/*      */   boolean attemptRefreshTokenLocked = false;
/*      */   static final int DEFAULT_SERVER_PREPARED_STATEMENT_DISCARD_THRESHOLD = 10;
/*  102 */   private int serverPreparedStatementDiscardThreshold = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final boolean DEFAULT_ENABLE_PREPARE_ON_FIRST_PREPARED_STATEMENT_CALL = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  113 */   private Boolean enablePrepareOnFirstPreparedStatementCall = null;
/*      */ 
/*      */   
/*  116 */   private ConcurrentLinkedQueue<PreparedStatementHandle> discardedPreparedStatementHandles = new ConcurrentLinkedQueue<>();
/*  117 */   private AtomicInteger discardedPreparedStatementHandleCount = new AtomicInteger(0);
/*      */   
/*  119 */   private SQLServerColumnEncryptionKeyStoreProvider keystoreProvider = null;
/*      */   
/*      */   private boolean fedAuthRequiredByUser = false;
/*      */   
/*      */   private boolean fedAuthRequiredPreLoginResponse = false;
/*      */   
/*      */   private boolean federatedAuthenticationRequested = false;
/*      */   
/*      */   private boolean federatedAuthenticationInfoRequested = false;
/*      */   
/*  129 */   private FederatedAuthenticationFeatureExtensionData fedAuthFeatureExtensionData = null;
/*  130 */   private String authenticationString = null;
/*  131 */   private byte[] accessTokenInByte = null;
/*      */   
/*  133 */   private SqlFedAuthToken fedAuthToken = null;
/*      */   
/*  135 */   private String originalHostNameInCertificate = null;
/*      */   
/*  137 */   private String clientCertificate = null;
/*  138 */   private String clientKey = null;
/*  139 */   private String clientKeyPassword = "";
/*  140 */   private String aadPrincipalID = "";
/*  141 */   private String aadPrincipalSecret = "";
/*      */   
/*      */   private boolean sendTemporalDataTypesAsStringForBulkCopy = true;
/*      */   
/*  145 */   final int ENGINE_EDITION_FOR_SQL_AZURE = 5;
/*  146 */   final int ENGINE_EDITION_FOR_SQL_AZURE_DW = 6;
/*  147 */   final int ENGINE_EDITION_FOR_SQL_AZURE_MI = 8;
/*  148 */   private Boolean isAzure = null;
/*  149 */   private Boolean isAzureDW = null;
/*  150 */   private Boolean isAzureMI = null;
/*      */ 
/*      */ 
/*      */   
/*      */   private SharedTimer sharedTimer;
/*      */ 
/*      */   
/*      */   private static final int PARSED_SQL_CACHE_SIZE = 100;
/*      */ 
/*      */ 
/*      */   
/*      */   SharedTimer getSharedTimer() throws SQLServerException {
/*  162 */     if (this.state == State.Closed) {
/*  163 */       SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, SQLServerException.getErrString("R_connectionIsClosed"), "08006", false);
/*      */     }
/*      */     
/*  166 */     if (null == this.sharedTimer) {
/*  167 */       this.sharedTimer = SharedTimer.getTimer();
/*      */     }
/*  169 */     return this.sharedTimer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String getServerNameString(String serverName) {
/*  180 */     String serverNameFromConnectionStr = this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.SERVER_NAME.toString());
/*  181 */     if (null == serverName || serverName.equals(serverNameFromConnectionStr)) {
/*  182 */       return serverName;
/*      */     }
/*      */ 
/*      */     
/*  186 */     MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_redirectedFrom"));
/*  187 */     Object[] msgArgs = { serverName, serverNameFromConnectionStr };
/*  188 */     return form.format(msgArgs);
/*      */   }
/*      */ 
/*      */   
/*      */   static class CityHash128Key
/*      */     implements Serializable
/*      */   {
/*      */     private static final long serialVersionUID = 166788428640603097L;
/*      */     
/*      */     String unhashedString;
/*      */     private long[] segments;
/*      */     private int hashCode;
/*      */     
/*      */     CityHash128Key(String sql, String parametersDefinition) {
/*  202 */       this(sql + sql);
/*      */     }
/*      */ 
/*      */     
/*      */     CityHash128Key(String s) {
/*  207 */       this.unhashedString = s;
/*  208 */       byte[] bytes = new byte[s.length()];
/*  209 */       s.getBytes(0, s.length(), bytes, 0);
/*  210 */       this.segments = CityHash.cityHash128(bytes, 0, bytes.length);
/*      */     }
/*      */     
/*      */     public boolean equals(Object obj) {
/*  214 */       if (!(obj instanceof CityHash128Key)) {
/*  215 */         return false;
/*      */       }
/*  217 */       return (Arrays.equals(this.segments, ((CityHash128Key)obj).segments) && this.unhashedString
/*      */         
/*  219 */         .equals(((CityHash128Key)obj).unhashedString));
/*      */     }
/*      */     
/*      */     public int hashCode() {
/*  223 */       if (0 == this.hashCode) {
/*  224 */         this.hashCode = Arrays.hashCode(this.segments);
/*      */       }
/*  226 */       return this.hashCode;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   class PreparedStatementHandle
/*      */   {
/*  234 */     private int handle = 0;
/*  235 */     private final AtomicInteger handleRefCount = new AtomicInteger();
/*      */     private boolean isDirectSql;
/*      */     private volatile boolean evictedFromCache;
/*      */     private volatile boolean explicitlyDiscarded;
/*      */     private SQLServerConnection.CityHash128Key key;
/*      */     
/*      */     PreparedStatementHandle(SQLServerConnection.CityHash128Key key, int handle, boolean isDirectSql, boolean isEvictedFromCache) {
/*  242 */       this.key = key;
/*  243 */       this.handle = handle;
/*  244 */       this.isDirectSql = isDirectSql;
/*  245 */       setIsEvictedFromCache(isEvictedFromCache);
/*  246 */       this.handleRefCount.set(1);
/*      */     }
/*      */ 
/*      */     
/*      */     private boolean isEvictedFromCache() {
/*  251 */       return this.evictedFromCache;
/*      */     }
/*      */ 
/*      */     
/*      */     private void setIsEvictedFromCache(boolean isEvictedFromCache) {
/*  256 */       this.evictedFromCache = isEvictedFromCache;
/*      */     }
/*      */ 
/*      */     
/*      */     void setIsExplicitlyDiscarded() {
/*  261 */       this.explicitlyDiscarded = true;
/*      */       
/*  263 */       SQLServerConnection.this.evictCachedPreparedStatementHandle(this);
/*      */     }
/*      */ 
/*      */     
/*      */     private boolean isExplicitlyDiscarded() {
/*  268 */       return this.explicitlyDiscarded;
/*      */     }
/*      */ 
/*      */     
/*      */     int getHandle() {
/*  273 */       return this.handle;
/*      */     }
/*      */ 
/*      */     
/*      */     SQLServerConnection.CityHash128Key getKey() {
/*  278 */       return this.key;
/*      */     }
/*      */     
/*      */     boolean isDirectSql() {
/*  282 */       return this.isDirectSql;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean tryDiscardHandle() {
/*  292 */       return this.handleRefCount.compareAndSet(0, -999);
/*      */     }
/*      */ 
/*      */     
/*      */     private boolean isDiscarded() {
/*  297 */       return (0 > this.handleRefCount.intValue());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     boolean tryAddReference() {
/*  307 */       return (isDiscarded() || isExplicitlyDiscarded()) ? false : ((this.handleRefCount.incrementAndGet() > 0));
/*      */     }
/*      */ 
/*      */     
/*      */     void removeReference() {
/*  312 */       this.handleRefCount.decrementAndGet();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  323 */   private static ConcurrentLinkedHashMap<CityHash128Key, ParsedSQLCacheItem> parsedSQLCache = (new ConcurrentLinkedHashMap.Builder())
/*  324 */     .maximumWeightedCapacity(100L).build();
/*      */   
/*      */   static final int DEFAULT_STATEMENT_POOLING_CACHE_SIZE = 0;
/*      */   
/*      */   static ParsedSQLCacheItem getCachedParsedSQL(CityHash128Key key) {
/*  329 */     return (ParsedSQLCacheItem)parsedSQLCache.get(key);
/*      */   }
/*      */ 
/*      */   
/*      */   static ParsedSQLCacheItem parseAndCacheSQL(CityHash128Key key, String sql) throws SQLServerException {
/*  334 */     JDBCSyntaxTranslator translator = new JDBCSyntaxTranslator();
/*      */     
/*  336 */     String parsedSql = translator.translate(sql);
/*  337 */     String procName = translator.getProcedureName();
/*  338 */     boolean returnValueSyntax = translator.hasReturnValueSyntax();
/*  339 */     int[] parameterPositions = locateParams(parsedSql);
/*      */     
/*  341 */     ParsedSQLCacheItem cacheItem = new ParsedSQLCacheItem(parsedSql, parameterPositions, procName, returnValueSyntax);
/*      */     
/*  343 */     parsedSQLCache.putIfAbsent(key, cacheItem);
/*  344 */     return cacheItem;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  351 */   private int statementPoolingCacheSize = 0;
/*      */   
/*      */   private ConcurrentLinkedHashMap<CityHash128Key, PreparedStatementHandle> preparedStatementHandleCache;
/*      */   
/*      */   private ConcurrentLinkedHashMap<CityHash128Key, SQLServerParameterMetaData> parameterMetadataCache;
/*      */   
/*      */   private boolean disableStatementPooling = true;
/*      */   
/*      */   private static final float TIMEOUTSTEP = 0.08F;
/*      */   
/*      */   private static final float TIMEOUTSTEP_TNIR = 0.125F;
/*      */   
/*      */   static final int TnirFirstAttemptTimeoutMs = 500;
/*      */   
/*      */   private static final int INTERMITTENT_TLS_MAX_RETRY = 5;
/*      */ 
/*      */   
/*      */   private static int[] locateParams(String sql) {
/*  369 */     LinkedList<Integer> parameterPositions = new LinkedList<>();
/*      */ 
/*      */     
/*  372 */     int offset = -1;
/*  373 */     while ((offset = ParameterUtils.scanSQLForChar('?', sql, ++offset)) < sql.length()) {
/*  374 */       parameterPositions.add(Integer.valueOf(offset));
/*      */     }
/*      */ 
/*      */     
/*  378 */     return parameterPositions.stream().mapToInt(Integer::valueOf).toArray();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   class FederatedAuthenticationFeatureExtensionData
/*      */     implements Serializable
/*      */   {
/*      */     private static final long serialVersionUID = -6709861741957202475L;
/*      */     
/*      */     boolean fedAuthRequiredPreLoginResponse;
/*      */     
/*  390 */     int libraryType = -1;
/*  391 */     byte[] accessToken = null;
/*  392 */     SqlAuthentication authentication = null;
/*      */ 
/*      */     
/*      */     FederatedAuthenticationFeatureExtensionData(int libraryType, String authenticationString, boolean fedAuthRequiredPreLoginResponse) throws SQLServerException {
/*  396 */       this.libraryType = libraryType;
/*  397 */       this.fedAuthRequiredPreLoginResponse = fedAuthRequiredPreLoginResponse;
/*      */       
/*  399 */       switch (authenticationString.toUpperCase(Locale.ENGLISH)) {
/*      */         case "ACTIVEDIRECTORYPASSWORD":
/*  401 */           this.authentication = SqlAuthentication.ActiveDirectoryPassword;
/*      */           return;
/*      */         case "ACTIVEDIRECTORYINTEGRATED":
/*  404 */           this.authentication = SqlAuthentication.ActiveDirectoryIntegrated;
/*      */           return;
/*      */         case "ACTIVEDIRECTORYMSI":
/*  407 */           this.authentication = SqlAuthentication.ActiveDirectoryMSI;
/*      */           return;
/*      */         case "ACTIVEDIRECTORYSERVICEPRINCIPAL":
/*  410 */           this.authentication = SqlAuthentication.ActiveDirectoryServicePrincipal;
/*      */           return;
/*      */         case "ACTIVEDIRECTORYINTERACTIVE":
/*  413 */           this.authentication = SqlAuthentication.ActiveDirectoryInteractive;
/*      */           return;
/*      */       } 
/*      */       
/*      */       assert false;
/*  418 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_InvalidConnectionSetting"));
/*  419 */       Object[] msgArgs = { "authentication", authenticationString };
/*  420 */       throw new SQLServerException(null, form.format(msgArgs), null, 0, false);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     FederatedAuthenticationFeatureExtensionData(int libraryType, boolean fedAuthRequiredPreLoginResponse, byte[] accessToken) {
/*  426 */       this.libraryType = libraryType;
/*  427 */       this.fedAuthRequiredPreLoginResponse = fedAuthRequiredPreLoginResponse;
/*  428 */       this.accessToken = accessToken;
/*      */     }
/*      */   }
/*      */   
/*      */   class SqlFedAuthInfo
/*      */   {
/*      */     String spn;
/*      */     String stsurl;
/*      */     
/*      */     public String toString() {
/*  438 */       return "STSURL: " + this.stsurl + ", SPN: " + this.spn;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   class ActiveDirectoryAuthentication
/*      */   {
/*      */     static final String JDBC_FEDAUTH_CLIENT_ID = "7f98cb04-cd1e-40df-9140-3bf7e2cea4db";
/*      */     static final String AZURE_REST_MSI_URL = "http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01";
/*      */     static final String ACCESS_TOKEN_IDENTIFIER = "\"access_token\":\"";
/*      */     static final String ACCESS_TOKEN_EXPIRES_IN_IDENTIFIER = "\"expires_in\":\"";
/*      */     static final String ACCESS_TOKEN_EXPIRES_ON_IDENTIFIER = "\"expires_on\":\"";
/*      */     static final String ACCESS_TOKEN_EXPIRES_ON_DATE_FORMAT = "M/d/yyyy h:mm:ss a X";
/*      */     static final int GET_ACCESS_TOKEN_SUCCESS = 0;
/*      */     static final int GET_ACCESS_TOKEN_INVALID_GRANT = 1;
/*      */     static final int GET_ACCESS_TOKEN_TANSISENT_ERROR = 2;
/*      */     static final int GET_ACCESS_TOKEN_OTHER_ERROR = 3;
/*      */   }
/*      */   
/*      */   private enum State
/*      */   {
/*  459 */     Initialized,
/*  460 */     Connected,
/*  461 */     Opened,
/*      */     
/*  463 */     Closed;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isRoutedInCurrentAttempt = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  481 */   private ServerPortPlaceHolder routingInfo = null; private static final String callAbortPerm = "callAbort"; private static final String SET_NETWORK_TIMEOUT_PERM = "setNetworkTimeout";
/*      */   
/*      */   ServerPortPlaceHolder getRoutingInfo() {
/*  484 */     return this.routingInfo;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  493 */   private boolean sendStringParametersAsUnicode = SQLServerDriverBooleanProperty.SEND_STRING_PARAMETERS_AS_UNICODE
/*  494 */     .getDefaultValue();
/*      */   
/*  496 */   private String hostName = null; private boolean lastUpdateCount;
/*      */   
/*      */   boolean sendStringParametersAsUnicode() {
/*  499 */     return this.sendStringParametersAsUnicode;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   final boolean useLastUpdateCount() {
/*  505 */     return this.lastUpdateCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  512 */   private boolean serverNameAsACE = SQLServerDriverBooleanProperty.SERVER_NAME_AS_ACE.getDefaultValue(); private boolean multiSubnetFailover; private boolean transparentNetworkIPResolution;
/*      */   
/*      */   boolean serverNameAsACE() {
/*  515 */     return this.serverNameAsACE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final boolean getMultiSubnetFailover() {
/*  522 */     return this.multiSubnetFailover;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   final boolean getTransparentNetworkIPResolution() {
/*  528 */     return this.transparentNetworkIPResolution;
/*      */   }
/*      */   
/*  531 */   private ApplicationIntent applicationIntent = null; private int nLockTimeout; private String selectMethod; private String responseBuffering; private int queryTimeoutSeconds; private int cancelQueryTimeoutSeconds; private int socketTimeoutMilliseconds; private boolean useBulkCopyForBatchInsert;
/*      */   
/*      */   final ApplicationIntent getApplicationIntent() {
/*  534 */     return this.applicationIntent;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final String getSelectMethod() {
/*  541 */     return this.selectMethod;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   final String getResponseBuffering() {
/*  547 */     return this.responseBuffering;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   final int getQueryTimeoutSeconds() {
/*  553 */     return this.queryTimeoutSeconds;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final int getCancelQueryTimeoutSeconds() {
/*  567 */     return this.cancelQueryTimeoutSeconds;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   final int getSocketTimeoutMilliseconds() {
/*  573 */     return this.socketTimeoutMilliseconds;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getUseBulkCopyForBatchInsert() {
/*  587 */     return this.useBulkCopyForBatchInsert;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUseBulkCopyForBatchInsert(boolean useBulkCopyForBatchInsert) {
/*  597 */     this.useBulkCopyForBatchInsert = useBulkCopyForBatchInsert;
/*      */   }
/*      */ 
/*      */   
/*      */   boolean userSetTNIR = true;
/*  602 */   private boolean sendTimeAsDatetime = SQLServerDriverBooleanProperty.SEND_TIME_AS_DATETIME.getDefaultValue();
/*  603 */   private boolean useFmtOnly = SQLServerDriverBooleanProperty.USE_FMT_ONLY.getDefaultValue();
/*      */ 
/*      */   
/*      */   public final boolean getSendTimeAsDatetime() {
/*  607 */     return (!isKatmaiOrLater() || this.sendTimeAsDatetime);
/*      */   }
/*      */   
/*      */   final int baseYear() {
/*  611 */     return getSendTimeAsDatetime() ? 1970 : 1900;
/*      */   }
/*      */   
/*  614 */   private byte requestedEncryptionLevel = -1; private boolean trustServerCertificate;
/*      */   
/*      */   final byte getRequestedEncryptionLevel() {
/*  617 */     assert -1 != this.requestedEncryptionLevel;
/*  618 */     return this.requestedEncryptionLevel;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   final boolean trustServerCertificate() {
/*  624 */     return this.trustServerCertificate;
/*      */   }
/*      */   
/*  627 */   private byte negotiatedEncryptionLevel = -1;
/*      */   
/*      */   final byte getNegotiatedEncryptionLevel() {
/*  630 */     assert -1 != this.negotiatedEncryptionLevel;
/*  631 */     return this.negotiatedEncryptionLevel;
/*      */   }
/*      */   
/*  634 */   private String socketFactoryClass = null;
/*      */   
/*      */   final String getSocketFactoryClass() {
/*  637 */     return this.socketFactoryClass;
/*      */   }
/*      */   
/*  640 */   private String socketFactoryConstructorArg = null;
/*      */   
/*      */   final String getSocketFactoryConstructorArg() {
/*  643 */     return this.socketFactoryConstructorArg;
/*      */   }
/*      */   
/*  646 */   private String trustManagerClass = null;
/*      */   
/*      */   final String getTrustManagerClass() {
/*  649 */     assert -1 != this.requestedEncryptionLevel;
/*  650 */     return this.trustManagerClass;
/*      */   }
/*      */   
/*  653 */   private String trustManagerConstructorArg = null; static final String RESERVED_PROVIDER_NAME_PREFIX = "MSSQL_";
/*      */   
/*      */   final String getTrustManagerConstructorArg() {
/*  656 */     assert -1 != this.requestedEncryptionLevel;
/*  657 */     return this.trustManagerConstructorArg;
/*      */   }
/*      */ 
/*      */   
/*  661 */   String columnEncryptionSetting = null;
/*      */   
/*      */   boolean isColumnEncryptionSettingEnabled() {
/*  664 */     return this.columnEncryptionSetting.equalsIgnoreCase(ColumnEncryptionSetting.Enabled.toString());
/*      */   }
/*      */   
/*      */   boolean getSendTemporalDataTypesAsStringForBulkCopy() {
/*  668 */     return this.sendTemporalDataTypesAsStringForBulkCopy;
/*      */   }
/*      */   
/*  671 */   String enclaveAttestationUrl = null;
/*  672 */   String enclaveAttestationProtocol = null;
/*      */   
/*  674 */   String keyStoreAuthentication = null;
/*  675 */   String keyStoreSecret = null;
/*  676 */   String keyStoreLocation = null;
/*  677 */   String keyStorePrincipalId = null;
/*      */   
/*  679 */   private ColumnEncryptionVersion serverColumnEncryptionVersion = ColumnEncryptionVersion.AE_NotSupported;
/*      */   
/*  681 */   private String enclaveType = null;
/*      */   
/*      */   boolean getServerSupportsColumnEncryption() {
/*  684 */     return (this.serverColumnEncryptionVersion.value() > ColumnEncryptionVersion.AE_NotSupported.value());
/*      */   }
/*      */   
/*      */   ColumnEncryptionVersion getServerColumnEncryptionVersion() {
/*  688 */     return this.serverColumnEncryptionVersion;
/*      */   }
/*      */   
/*      */   private boolean serverSupportsDataClassification = false;
/*  692 */   private byte serverSupportedDataClassificationVersion = 0;
/*      */   
/*      */   boolean getServerSupportsDataClassification() {
/*  695 */     return this.serverSupportsDataClassification;
/*      */   }
/*      */   
/*      */   private boolean serverSupportsDNSCaching = false;
/*  699 */   private static ConcurrentHashMap<String, InetSocketAddress> dnsCache = null;
/*      */   
/*      */   static InetSocketAddress getDNSEntry(String key) {
/*  702 */     return (null != dnsCache) ? dnsCache.get(key) : null;
/*      */   }
/*      */   
/*      */   byte getServerSupportedDataClassificationVersion() {
/*  706 */     return this.serverSupportedDataClassificationVersion;
/*      */   }
/*      */ 
/*      */   
/*  710 */   private boolean delayLoadingLobs = SQLServerDriverBooleanProperty.DELAY_LOADING_LOBS.getDefaultValue();
/*      */ 
/*      */   
/*      */   public boolean getDelayLoadingLobs() {
/*  714 */     return this.delayLoadingLobs;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setDelayLoadingLobs(boolean b) {
/*  719 */     this.delayLoadingLobs = b;
/*      */   }
/*      */   
/*  722 */   static Map<String, SQLServerColumnEncryptionKeyStoreProvider> globalSystemColumnEncryptionKeyStoreProviders = new HashMap<>();
/*      */   static {
/*  724 */     if (System.getProperty("os.name").toLowerCase(Locale.ENGLISH).startsWith("windows")) {
/*  725 */       SQLServerColumnEncryptionCertificateStoreProvider provider = new SQLServerColumnEncryptionCertificateStoreProvider();
/*  726 */       globalSystemColumnEncryptionKeyStoreProviders.put(provider.getName(), provider);
/*      */     } 
/*      */   }
/*  729 */   static Map<String, SQLServerColumnEncryptionKeyStoreProvider> globalCustomColumnEncryptionKeyStoreProviders = null;
/*      */   
/*  731 */   Map<String, SQLServerColumnEncryptionKeyStoreProvider> systemColumnEncryptionKeyStoreProvider = new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized void registerColumnEncryptionKeyStoreProviders(Map<String, SQLServerColumnEncryptionKeyStoreProvider> clientKeyStoreProviders) throws SQLServerException {
/*  743 */     loggerExternal.entering(loggingClassName, "registerColumnEncryptionKeyStoreProviders", "Registering Column Encryption Key Store Providers");
/*      */ 
/*      */     
/*  746 */     if (null == clientKeyStoreProviders) {
/*  747 */       throw new SQLServerException(null, SQLServerException.getErrString("R_CustomKeyStoreProviderMapNull"), null, 0, false);
/*      */     }
/*      */ 
/*      */     
/*  751 */     if (null != globalCustomColumnEncryptionKeyStoreProviders && 
/*  752 */       !globalCustomColumnEncryptionKeyStoreProviders.isEmpty()) {
/*  753 */       throw new SQLServerException(null, SQLServerException.getErrString("R_CustomKeyStoreProviderSetOnce"), null, 0, false);
/*      */     }
/*      */ 
/*      */     
/*  757 */     globalCustomColumnEncryptionKeyStoreProviders = new HashMap<>();
/*      */     
/*  759 */     for (Map.Entry<String, SQLServerColumnEncryptionKeyStoreProvider> entry : clientKeyStoreProviders.entrySet()) {
/*  760 */       String providerName = entry.getKey();
/*  761 */       if (null == providerName || 0 == providerName.length()) {
/*  762 */         throw new SQLServerException(null, SQLServerException.getErrString("R_EmptyCustomKeyStoreProviderName"), null, 0, false);
/*      */       }
/*      */       
/*  765 */       if (providerName.substring(0, 6).equalsIgnoreCase("MSSQL_")) {
/*      */         
/*  767 */         MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_InvalidCustomKeyStoreProviderName"));
/*  768 */         Object[] msgArgs = { providerName, "MSSQL_" };
/*  769 */         throw new SQLServerException(null, form.format(msgArgs), null, 0, false);
/*      */       } 
/*  771 */       if (null == entry.getValue()) {
/*      */         
/*  773 */         MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_CustomKeyStoreProviderValueNull"));
/*  774 */         Object[] msgArgs = { providerName, "MSSQL_" };
/*  775 */         throw new SQLServerException(null, form.format(msgArgs), null, 0, false);
/*      */       } 
/*  777 */       globalCustomColumnEncryptionKeyStoreProviders.put(entry.getKey(), entry.getValue());
/*      */     } 
/*      */     
/*  780 */     loggerExternal.exiting(loggingClassName, "registerColumnEncryptionKeyStoreProviders", "Number of Key store providers that are registered:" + globalCustomColumnEncryptionKeyStoreProviders
/*      */         
/*  782 */         .size());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized void unregisterColumnEncryptionKeyStoreProviders() {
/*  790 */     loggerExternal.entering(loggingClassName, "unregisterColumnEncryptionKeyStoreProviders", "Removing Column Encryption Key Store Provider");
/*      */ 
/*      */     
/*  793 */     if (null != globalCustomColumnEncryptionKeyStoreProviders) {
/*  794 */       globalCustomColumnEncryptionKeyStoreProviders.clear();
/*  795 */       globalCustomColumnEncryptionKeyStoreProviders = null;
/*      */     } 
/*      */     
/*  798 */     loggerExternal.exiting(loggingClassName, "unregisterColumnEncryptionKeyStoreProviders", "Number of Key store providers that are registered: 0");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized SQLServerColumnEncryptionKeyStoreProvider getGlobalSystemColumnEncryptionKeyStoreProvider(String providerName) {
/*  804 */     return (null != globalSystemColumnEncryptionKeyStoreProviders && globalSystemColumnEncryptionKeyStoreProviders
/*  805 */       .containsKey(providerName)) ? globalSystemColumnEncryptionKeyStoreProviders.get(providerName) : null;
/*      */   }
/*      */   
/*      */   synchronized String getAllGlobalCustomSystemColumnEncryptionKeyStoreProviders() {
/*  809 */     return (null != globalCustomColumnEncryptionKeyStoreProviders) ? 
/*  810 */       globalCustomColumnEncryptionKeyStoreProviders.keySet().toString() : null;
/*      */   }
/*      */   
/*      */   synchronized String getAllSystemColumnEncryptionKeyStoreProviders() {
/*  814 */     String keyStores = "";
/*  815 */     if (0 != this.systemColumnEncryptionKeyStoreProvider.size())
/*  816 */       keyStores = this.systemColumnEncryptionKeyStoreProvider.keySet().toString(); 
/*  817 */     if (0 != globalSystemColumnEncryptionKeyStoreProviders.size())
/*  818 */       keyStores = keyStores + "," + keyStores; 
/*  819 */     return keyStores;
/*      */   }
/*      */ 
/*      */   
/*      */   synchronized SQLServerColumnEncryptionKeyStoreProvider getGlobalCustomColumnEncryptionKeyStoreProvider(String providerName) {
/*  824 */     return (null != globalCustomColumnEncryptionKeyStoreProviders && globalCustomColumnEncryptionKeyStoreProviders
/*  825 */       .containsKey(providerName)) ? globalCustomColumnEncryptionKeyStoreProviders.get(providerName) : null;
/*      */   }
/*      */ 
/*      */   
/*      */   synchronized SQLServerColumnEncryptionKeyStoreProvider getSystemColumnEncryptionKeyStoreProvider(String providerName) {
/*  830 */     return (null != this.systemColumnEncryptionKeyStoreProvider && this.systemColumnEncryptionKeyStoreProvider
/*  831 */       .containsKey(providerName)) ? this.systemColumnEncryptionKeyStoreProvider.get(providerName) : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized SQLServerColumnEncryptionKeyStoreProvider getColumnEncryptionKeyStoreProvider(String providerName) throws SQLServerException {
/*  838 */     this.keystoreProvider = getSystemColumnEncryptionKeyStoreProvider(providerName);
/*      */ 
/*      */     
/*  841 */     if (null == this.keystoreProvider) {
/*  842 */       this.keystoreProvider = getGlobalSystemColumnEncryptionKeyStoreProvider(providerName);
/*      */     }
/*      */ 
/*      */     
/*  846 */     if (null == this.keystoreProvider) {
/*  847 */       this.keystoreProvider = getGlobalCustomColumnEncryptionKeyStoreProvider(providerName);
/*      */     }
/*      */ 
/*      */     
/*  851 */     if (null == this.keystoreProvider) {
/*  852 */       String systemProviders = getAllSystemColumnEncryptionKeyStoreProviders();
/*  853 */       String customProviders = getAllGlobalCustomSystemColumnEncryptionKeyStoreProviders();
/*      */       
/*  855 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_UnrecognizedKeyStoreProviderName"));
/*  856 */       Object[] msgArgs = { providerName, systemProviders, customProviders };
/*  857 */       throw new SQLServerException(form.format(msgArgs), null);
/*      */     } 
/*      */     
/*  860 */     return this.keystoreProvider;
/*      */   }
/*      */   
/*  863 */   private String trustedServerNameAE = null;
/*  864 */   private static Map<String, List<String>> columnEncryptionTrustedMasterKeyPaths = new HashMap<>();
/*      */ 
/*      */ 
/*      */   
/*      */   Properties activeConnectionProperties;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized void setColumnEncryptionTrustedMasterKeyPaths(Map<String, List<String>> trustedKeyPaths) {
/*  874 */     loggerExternal.entering(loggingClassName, "setColumnEncryptionTrustedMasterKeyPaths", "Setting Trusted Master Key Paths");
/*      */ 
/*      */ 
/*      */     
/*  878 */     columnEncryptionTrustedMasterKeyPaths.clear();
/*  879 */     for (Map.Entry<String, List<String>> entry : trustedKeyPaths.entrySet()) {
/*  880 */       columnEncryptionTrustedMasterKeyPaths.put(((String)entry.getKey()).toUpperCase(), entry.getValue());
/*      */     }
/*      */     
/*  883 */     loggerExternal.exiting(loggingClassName, "setColumnEncryptionTrustedMasterKeyPaths", "Number of Trusted Master Key Paths: " + columnEncryptionTrustedMasterKeyPaths
/*  884 */         .size());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized void updateColumnEncryptionTrustedMasterKeyPaths(String server, List<String> trustedKeyPaths) {
/*  897 */     loggerExternal.entering(loggingClassName, "updateColumnEncryptionTrustedMasterKeyPaths", "Updating Trusted Master Key Paths");
/*      */ 
/*      */ 
/*      */     
/*  901 */     columnEncryptionTrustedMasterKeyPaths.put(server.toUpperCase(), trustedKeyPaths);
/*      */     
/*  903 */     loggerExternal.exiting(loggingClassName, "updateColumnEncryptionTrustedMasterKeyPaths", "Number of Trusted Master Key Paths: " + columnEncryptionTrustedMasterKeyPaths
/*  904 */         .size());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized void removeColumnEncryptionTrustedMasterKeyPaths(String server) {
/*  914 */     loggerExternal.entering(loggingClassName, "removeColumnEncryptionTrustedMasterKeyPaths", "Removing Trusted Master Key Paths");
/*      */ 
/*      */ 
/*      */     
/*  918 */     columnEncryptionTrustedMasterKeyPaths.remove(server.toUpperCase());
/*      */     
/*  920 */     loggerExternal.exiting(loggingClassName, "removeColumnEncryptionTrustedMasterKeyPaths", "Number of Trusted Master Key Paths: " + columnEncryptionTrustedMasterKeyPaths
/*  921 */         .size());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized Map<String, List<String>> getColumnEncryptionTrustedMasterKeyPaths() {
/*  930 */     loggerExternal.entering(loggingClassName, "getColumnEncryptionTrustedMasterKeyPaths", "Getting Trusted Master Key Paths");
/*      */ 
/*      */     
/*  933 */     Map<String, List<String>> masterKeyPathCopy = new HashMap<>();
/*      */     
/*  935 */     for (Map.Entry<String, List<String>> entry : columnEncryptionTrustedMasterKeyPaths.entrySet()) {
/*  936 */       masterKeyPathCopy.put(entry.getKey(), entry.getValue());
/*      */     }
/*      */     
/*  939 */     loggerExternal.exiting(loggingClassName, "getColumnEncryptionTrustedMasterKeyPaths", "Number of Trusted Master Key Paths: " + masterKeyPathCopy
/*  940 */         .size());
/*      */     
/*  942 */     return masterKeyPathCopy;
/*      */   }
/*      */   
/*      */   static synchronized List<String> getColumnEncryptionTrustedMasterKeyPaths(String server, Boolean[] hasEntry) {
/*  946 */     if (columnEncryptionTrustedMasterKeyPaths.containsKey(server)) {
/*  947 */       hasEntry[0] = Boolean.valueOf(true);
/*  948 */       return columnEncryptionTrustedMasterKeyPaths.get(server);
/*      */     } 
/*  950 */     hasEntry[0] = Boolean.valueOf(false);
/*  951 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized void clearUserTokenCache() {
/*  960 */     PersistentTokenCacheAccessAspect.clearUserTokenCache();
/*      */   }
/*      */ 
/*      */   
/*  964 */   private boolean integratedSecurity = SQLServerDriverBooleanProperty.INTEGRATED_SECURITY.getDefaultValue();
/*      */   private boolean ntlmAuthentication = false;
/*  966 */   private byte[] ntlmPasswordHash = null;
/*      */   
/*  968 */   private AuthenticationScheme intAuthScheme = AuthenticationScheme.nativeAuthentication;
/*      */   
/*      */   private GSSCredential impersonatedUserCred;
/*      */   private boolean isUserCreatedCredential;
/*  972 */   ServerPortPlaceHolder currentConnectPlaceHolder = null;
/*      */   
/*      */   String sqlServerVersion;
/*      */   boolean xopenStates;
/*      */   private boolean databaseAutoCommitMode;
/*      */   private boolean inXATransaction = false;
/*  978 */   private byte[] transactionDescriptor = new byte[8];
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean rolledBackTransaction;
/*      */ 
/*      */ 
/*      */   
/*      */   final boolean rolledBackTransaction() {
/*  987 */     return this.rolledBackTransaction;
/*      */   }
/*      */   
/*  990 */   private volatile State state = State.Initialized; static final int maxDecimalPrecision = 38; static final int defaultDecimalPrecision = 18; final String traceID; private int maxFieldSize; private int maxRows; private SQLCollation databaseCollation;
/*      */   
/*      */   private void setState(State state) {
/*  993 */     this.state = state;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final boolean isSessionUnAvailable() {
/* 1001 */     return !this.state.equals(State.Opened);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void setMaxFieldSize(int limit) throws SQLServerException {
/* 1013 */     if (this.maxFieldSize != limit) {
/* 1014 */       if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) {
/* 1015 */         loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */       }
/*      */       
/* 1018 */       connectionCommand("SET TEXTSIZE " + ((0 == limit) ? Integer.MAX_VALUE : limit), "setMaxFieldSize");
/* 1019 */       this.maxFieldSize = limit;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void initResettableValues() {
/* 1028 */     this.rolledBackTransaction = false;
/* 1029 */     this.transactionIsolationLevel = 2;
/* 1030 */     this.maxFieldSize = 0;
/* 1031 */     this.maxRows = 0;
/* 1032 */     this.nLockTimeout = -1;
/* 1033 */     this.databaseAutoCommitMode = true;
/* 1034 */     this.holdability = 1;
/* 1035 */     this.sqlWarnings = null;
/* 1036 */     this.sCatalog = this.originalCatalog;
/* 1037 */     this.databaseMetaData = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void setMaxRows(int limit) throws SQLServerException {
/* 1045 */     if (this.maxRows != limit) {
/* 1046 */       if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) {
/* 1047 */         loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */       }
/* 1049 */       connectionCommand("SET ROWCOUNT " + limit, "setMaxRows");
/* 1050 */       this.maxRows = limit;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   final SQLCollation getDatabaseCollation() {
/* 1057 */     return this.databaseCollation;
/*      */   }
/*      */   
/* 1060 */   private static final AtomicInteger baseConnectionID = new AtomicInteger(0);
/*      */   
/* 1062 */   private String sCatalog = "master";
/*      */   
/* 1064 */   private String originalCatalog = "master";
/*      */   
/*      */   private int transactionIsolationLevel;
/*      */   private SQLServerPooledConnection pooledConnectionParent;
/*      */   private SQLServerDatabaseMetaData databaseMetaData;
/* 1069 */   private int nNextSavePointId = 10000;
/*      */ 
/*      */   
/* 1072 */   private static final Logger connectionlogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerConnection");
/*      */   
/* 1074 */   private static final Logger loggerExternal = Logger.getLogger("com.microsoft.sqlserver.jdbc.Connection");
/* 1075 */   private static String loggingClassName = "com.microsoft.sqlserver.jdbc.SQLServerConnection:";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1081 */   private String failoverPartnerServerProvided = null;
/*      */   
/*      */   private int holdability;
/*      */   
/*      */   final int getHoldabilityInternal() {
/* 1086 */     return this.holdability;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1093 */   private int tdsPacketSize = 4096;
/* 1094 */   private int requestedPacketSize = 8000; private TDSChannel tdsChannel;
/*      */   
/*      */   final int getTDSPacketSize() {
/* 1097 */     return this.tdsPacketSize;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 1102 */   private TDSCommand currentCommand = null;
/*      */   
/* 1104 */   private int tdsVersion = 0; private int serverMajorVersion; private SQLServerConnectionPoolProxy proxy;
/*      */   
/*      */   final boolean isKatmaiOrLater() {
/* 1107 */     assert 0 != this.tdsVersion;
/* 1108 */     assert this.tdsVersion >= 1913192450;
/* 1109 */     return (this.tdsVersion >= 1930100739);
/*      */   }
/*      */   
/*      */   final boolean isDenaliOrLater() {
/* 1113 */     return (this.tdsVersion >= 1946157060);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   int getServerMajorVersion() {
/* 1119 */     return this.serverMajorVersion;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 1124 */   private UUID clientConnectionId = null;
/*      */   
/*      */   static final int MAX_SQL_LOGIN_NAME_WCHARS = 128;
/*      */ 
/*      */   
/*      */   public UUID getClientConnectionId() throws SQLServerException {
/* 1130 */     checkClosed();
/* 1131 */     return this.clientConnectionId;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final UUID getClientConIdInternal() {
/* 1139 */     return this.clientConnectionId;
/*      */   }
/*      */   
/*      */   final boolean attachConnId() {
/* 1143 */     return this.state.equals(State.Connected);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setFailoverPartnerServerProvided(String partner) {
/* 1161 */     this.failoverPartnerServerProvided = partner;
/*      */   }
/*      */ 
/*      */   
/*      */   final void setAssociatedProxy(SQLServerConnectionPoolProxy proxy) {
/* 1166 */     this.proxy = proxy;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final Connection getConnection() {
/* 1175 */     if (null != this.proxy) {
/* 1176 */       return this.proxy;
/*      */     }
/* 1178 */     return this;
/*      */   }
/*      */   
/*      */   final void resetPooledConnection() {
/* 1182 */     this.tdsChannel.resetPooledConnection();
/* 1183 */     initResettableValues();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int nextConnectionID() {
/* 1192 */     return baseConnectionID.incrementAndGet();
/*      */   }
/*      */   
/*      */   Logger getConnectionLogger() {
/* 1196 */     return connectionlogger;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1204 */     if (null != this.clientConnectionId) {
/* 1205 */       return this.traceID + " ClientConnectionId: " + this.traceID;
/*      */     }
/* 1207 */     return this.traceID;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void checkClosed() throws SQLServerException {
/* 1216 */     if (isSessionUnAvailable()) {
/* 1217 */       SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, SQLServerException.getErrString("R_connectionIsClosed"), "08006", false);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean needsReconnect() {
/* 1228 */     return (null != this.fedAuthToken && Util.checkIfNeedNewAccessToken(this, this.fedAuthToken.expiresOn));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isBooleanPropertyOn(String propName, String propValue) throws SQLServerException {
/* 1246 */     if (null == propValue) {
/* 1247 */       return false;
/*      */     }
/* 1249 */     if ("true".equalsIgnoreCase(propValue))
/* 1250 */       return true; 
/* 1251 */     if ("false".equalsIgnoreCase(propValue)) {
/* 1252 */       return false;
/*      */     }
/* 1254 */     MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidBooleanValue"));
/* 1255 */     Object[] msgArgs = { propName };
/* 1256 */     SQLServerException.makeFromDriverError(this, this, form.format(msgArgs), (String)null, false);
/* 1257 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void validateMaxSQLLoginName(String propName, String propValue) throws SQLServerException {
/* 1278 */     if (propValue != null && propValue.length() > 128) {
/* 1279 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_propertyMaximumExceedsChars"));
/* 1280 */       Object[] msgArgs = { propName, Integer.toString(128) };
/* 1281 */       SQLServerException.makeFromDriverError(this, this, form.format(msgArgs), (String)null, false);
/*      */     } 
/*      */   }
/*      */   
/*      */   Connection connect(Properties propsIn, SQLServerPooledConnection pooledConnection) throws SQLServerException {
/* 1286 */     int loginTimeoutSeconds = 0;
/* 1287 */     long start = System.currentTimeMillis();
/*      */     
/* 1289 */     int retryAttempt = 0; while (true) {
/*      */       try {
/* 1291 */         return connectInternal(propsIn, pooledConnection);
/* 1292 */       } catch (SQLServerException e) {
/*      */         
/* 1294 */         if (7 != e.getDriverErrorCode())
/*      */         {
/* 1296 */           throw e;
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 1301 */         if (0 == retryAttempt) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1306 */           loginTimeoutSeconds = SQLServerDriverIntProperty.LOGIN_TIMEOUT.getDefaultValue();
/*      */           
/* 1308 */           String sPropValue = propsIn.getProperty(SQLServerDriverIntProperty.LOGIN_TIMEOUT.toString());
/* 1309 */           if (null != sPropValue && sPropValue.length() > 0) {
/* 1310 */             int sPropValueInt = Integer.parseInt(sPropValue);
/* 1311 */             if (0 != sPropValueInt) {
/* 1312 */               loginTimeoutSeconds = sPropValueInt;
/*      */             }
/*      */           } 
/*      */         } 
/*      */         
/* 1317 */         retryAttempt++;
/* 1318 */         long elapsedSeconds = (System.currentTimeMillis() - start) / 1000L;
/*      */         
/* 1320 */         if (5 < retryAttempt) {
/*      */           
/* 1322 */           if (connectionlogger.isLoggable(Level.FINE)) {
/* 1323 */             connectionlogger.fine("Connection failed during SSL handshake. Maximum retry attempt (5) reached.  ");
/*      */           }
/*      */           
/* 1326 */           throw e;
/* 1327 */         }  if (elapsedSeconds >= loginTimeoutSeconds) {
/*      */           
/* 1329 */           if (connectionlogger.isLoggable(Level.FINE)) {
/* 1330 */             connectionlogger
/* 1331 */               .fine("Connection failed during SSL handshake. Not retrying as timeout expired.");
/*      */           }
/* 1333 */           throw e;
/*      */         } 
/*      */         
/* 1336 */         if (connectionlogger.isLoggable(Level.FINE)) {
/* 1337 */           connectionlogger.fine("Connection failed during SSL handshake. Retrying due to an intermittent TLS 1.2 failure issue. Retry attempt = " + retryAttempt + ".");
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void registerKeyStoreProviderOnConnection(String keyStoreAuth, String keyStoreSecret, String keyStoreLocation) throws SQLServerException {
/* 1349 */     if (null == keyStoreAuth) {
/*      */       
/* 1351 */       if (null != keyStoreSecret) {
/*      */         
/* 1353 */         MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_keyStoreAuthenticationNotSet"));
/* 1354 */         Object[] msgArgs = { "keyStoreSecret" };
/* 1355 */         throw new SQLServerException(form.format(msgArgs), null);
/*      */       } 
/* 1357 */       if (null != keyStoreLocation) {
/*      */         
/* 1359 */         MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_keyStoreAuthenticationNotSet"));
/* 1360 */         Object[] msgArgs = { "keyStoreLocation" };
/* 1361 */         throw new SQLServerException(form.format(msgArgs), null);
/*      */       } 
/* 1363 */       if (null != this.keyStorePrincipalId) {
/*      */         
/* 1365 */         MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_keyStoreAuthenticationNotSet"));
/* 1366 */         Object[] msgArgs = { "keyStorePrincipalId" };
/* 1367 */         throw new SQLServerException(form.format(msgArgs), null);
/*      */       } 
/*      */     } else {
/* 1370 */       SQLServerColumnEncryptionJavaKeyStoreProvider sQLServerColumnEncryptionJavaKeyStoreProvider; SQLServerColumnEncryptionAzureKeyVaultProvider provider; Map<String, SQLServerColumnEncryptionKeyStoreProvider> keyStoreMap; KeyStoreAuthentication keyStoreAuthentication = KeyStoreAuthentication.valueOfString(keyStoreAuth);
/* 1371 */       switch (keyStoreAuthentication) {
/*      */         
/*      */         case ActiveDirectoryPassword:
/* 1374 */           if (null == keyStoreSecret || null == keyStoreLocation) {
/* 1375 */             throw new SQLServerException(
/* 1376 */                 SQLServerException.getErrString("R_keyStoreSecretOrLocationNotSet"), null);
/*      */           }
/*      */           
/* 1379 */           sQLServerColumnEncryptionJavaKeyStoreProvider = new SQLServerColumnEncryptionJavaKeyStoreProvider(keyStoreLocation, keyStoreSecret.toCharArray());
/* 1380 */           this.systemColumnEncryptionKeyStoreProvider.put(sQLServerColumnEncryptionJavaKeyStoreProvider.getName(), sQLServerColumnEncryptionJavaKeyStoreProvider);
/*      */           break;
/*      */ 
/*      */         
/*      */         case ActiveDirectoryIntegrated:
/* 1385 */           if (null == keyStoreSecret) {
/* 1386 */             throw new SQLServerException(SQLServerException.getErrString("R_keyStoreSecretNotSet"), null);
/*      */           }
/* 1388 */           registerKeyVaultProvider(this.keyStorePrincipalId, keyStoreSecret);
/*      */           break;
/*      */         
/*      */         case ActiveDirectoryMSI:
/* 1392 */           if (null != this.keyStorePrincipalId) {
/* 1393 */             provider = new SQLServerColumnEncryptionAzureKeyVaultProvider(this.keyStorePrincipalId);
/*      */           } else {
/* 1395 */             provider = new SQLServerColumnEncryptionAzureKeyVaultProvider();
/*      */           } 
/* 1397 */           keyStoreMap = new HashMap<>();
/* 1398 */           keyStoreMap.put(provider.getName(), provider);
/* 1399 */           registerColumnEncryptionKeyStoreProviders(keyStoreMap);
/*      */           break;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void registerKeyVaultProvider(String clientId, String clientKey) throws SQLServerException {
/* 1410 */     SQLServerColumnEncryptionAzureKeyVaultProvider provider = new SQLServerColumnEncryptionAzureKeyVaultProvider(clientId, clientKey);
/*      */     
/* 1412 */     Map<String, SQLServerColumnEncryptionKeyStoreProvider> keyStoreMap = new HashMap<>();
/* 1413 */     keyStoreMap.put(provider.getName(), provider);
/* 1414 */     registerColumnEncryptionKeyStoreProviders(keyStoreMap);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Connection connectInternal(Properties propsIn, SQLServerPooledConnection pooledConnection) throws SQLServerException {
/*      */     try {
/* 1431 */       this.activeConnectionProperties = (Properties)propsIn.clone();
/*      */       
/* 1433 */       this.pooledConnectionParent = pooledConnection;
/*      */ 
/*      */       
/* 1436 */       String hostNameInCertificate = this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.HOSTNAME_IN_CERTIFICATE.toString());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1442 */       if (null == this.originalHostNameInCertificate && null != hostNameInCertificate && 
/* 1443 */         !hostNameInCertificate.isEmpty()) {
/* 1444 */         this
/* 1445 */           .originalHostNameInCertificate = this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.HOSTNAME_IN_CERTIFICATE.toString());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1452 */       if (null != this.originalHostNameInCertificate && !this.originalHostNameInCertificate.isEmpty()) {
/* 1453 */         this.activeConnectionProperties.setProperty(SQLServerDriverStringProperty.HOSTNAME_IN_CERTIFICATE.toString(), this.originalHostNameInCertificate);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1460 */       String sPropKey = SQLServerDriverStringProperty.USER.toString();
/* 1461 */       String sPropValue = this.activeConnectionProperties.getProperty(sPropKey);
/* 1462 */       if (null == sPropValue) {
/* 1463 */         sPropValue = SQLServerDriverStringProperty.USER.getDefaultValue();
/* 1464 */         this.activeConnectionProperties.setProperty(sPropKey, sPropValue);
/*      */       } 
/* 1466 */       validateMaxSQLLoginName(sPropKey, sPropValue);
/*      */       
/* 1468 */       sPropKey = SQLServerDriverStringProperty.PASSWORD.toString();
/* 1469 */       sPropValue = this.activeConnectionProperties.getProperty(sPropKey);
/* 1470 */       if (null == sPropValue) {
/* 1471 */         sPropValue = SQLServerDriverStringProperty.PASSWORD.getDefaultValue();
/* 1472 */         this.activeConnectionProperties.setProperty(sPropKey, sPropValue);
/*      */       } 
/* 1474 */       validateMaxSQLLoginName(sPropKey, sPropValue);
/*      */       
/* 1476 */       sPropKey = SQLServerDriverStringProperty.DATABASE_NAME.toString();
/* 1477 */       sPropValue = this.activeConnectionProperties.getProperty(sPropKey);
/* 1478 */       validateMaxSQLLoginName(sPropKey, sPropValue);
/*      */ 
/*      */       
/* 1481 */       int loginTimeoutSeconds = SQLServerDriverIntProperty.LOGIN_TIMEOUT.getDefaultValue();
/* 1482 */       sPropValue = this.activeConnectionProperties.getProperty(SQLServerDriverIntProperty.LOGIN_TIMEOUT.toString());
/* 1483 */       if (null != sPropValue && sPropValue.length() > 0) {
/*      */         try {
/* 1485 */           loginTimeoutSeconds = Integer.parseInt(sPropValue);
/* 1486 */         } catch (NumberFormatException e) {
/* 1487 */           MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidTimeOut"));
/* 1488 */           Object[] msgArgs = { sPropValue };
/* 1489 */           SQLServerException.makeFromDriverError(this, this, form.format(msgArgs), (String)null, false);
/*      */         } 
/*      */         
/* 1492 */         if (loginTimeoutSeconds < 0 || loginTimeoutSeconds > 65535) {
/* 1493 */           MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidTimeOut"));
/* 1494 */           Object[] msgArgs = { sPropValue };
/* 1495 */           SQLServerException.makeFromDriverError(this, this, form.format(msgArgs), (String)null, false);
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1501 */       sPropKey = SQLServerDriverBooleanProperty.SERVER_NAME_AS_ACE.toString();
/* 1502 */       sPropValue = this.activeConnectionProperties.getProperty(sPropKey);
/* 1503 */       if (null == sPropValue) {
/* 1504 */         sPropValue = Boolean.toString(SQLServerDriverBooleanProperty.SERVER_NAME_AS_ACE.getDefaultValue());
/* 1505 */         this.activeConnectionProperties.setProperty(sPropKey, sPropValue);
/*      */       } 
/* 1507 */       this.serverNameAsACE = isBooleanPropertyOn(sPropKey, sPropValue);
/*      */ 
/*      */ 
/*      */       
/* 1511 */       sPropKey = SQLServerDriverStringProperty.SERVER_NAME.toString();
/* 1512 */       sPropValue = this.activeConnectionProperties.getProperty(sPropKey);
/*      */       
/* 1514 */       if (null == sPropValue) {
/* 1515 */         sPropValue = "localhost";
/*      */       }
/*      */       
/* 1518 */       String sPropKeyPort = SQLServerDriverIntProperty.PORT_NUMBER.toString();
/* 1519 */       String sPropValuePort = this.activeConnectionProperties.getProperty(sPropKeyPort);
/*      */       
/* 1521 */       int px = sPropValue.indexOf('\\');
/*      */       
/* 1523 */       String instanceValue = null;
/*      */       
/* 1525 */       String instanceNameProperty = SQLServerDriverStringProperty.INSTANCE_NAME.toString();
/*      */       
/* 1527 */       if (px >= 0) {
/* 1528 */         instanceValue = sPropValue.substring(px + 1, sPropValue.length());
/* 1529 */         validateMaxSQLLoginName(instanceNameProperty, instanceValue);
/* 1530 */         sPropValue = sPropValue.substring(0, px);
/*      */       } 
/* 1532 */       this.trustedServerNameAE = sPropValue;
/*      */       
/* 1534 */       if (this.serverNameAsACE) {
/*      */         try {
/* 1536 */           sPropValue = IDN.toASCII(sPropValue);
/* 1537 */         } catch (IllegalArgumentException ex) {
/*      */           
/* 1539 */           MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_InvalidConnectionSetting"));
/* 1540 */           Object[] msgArgs = { "serverNameAsACE", sPropValue };
/* 1541 */           throw new SQLServerException(form.format(msgArgs), ex);
/*      */         } 
/*      */       }
/* 1544 */       this.activeConnectionProperties.setProperty(sPropKey, sPropValue);
/*      */       
/* 1546 */       String instanceValueFromProp = this.activeConnectionProperties.getProperty(instanceNameProperty);
/*      */       
/* 1548 */       if (null != instanceValueFromProp) {
/* 1549 */         instanceValue = instanceValueFromProp;
/*      */       }
/* 1551 */       if (instanceValue != null) {
/* 1552 */         validateMaxSQLLoginName(instanceNameProperty, instanceValue);
/*      */         
/* 1554 */         this.activeConnectionProperties.setProperty(instanceNameProperty, instanceValue);
/* 1555 */         this.trustedServerNameAE = this.trustedServerNameAE + "\\" + this.trustedServerNameAE;
/*      */       } 
/*      */       
/* 1558 */       if (null != sPropValuePort) {
/* 1559 */         this.trustedServerNameAE = this.trustedServerNameAE + ":" + this.trustedServerNameAE;
/*      */       }
/*      */       
/* 1562 */       sPropKey = SQLServerDriverStringProperty.APPLICATION_NAME.toString();
/* 1563 */       sPropValue = this.activeConnectionProperties.getProperty(sPropKey);
/* 1564 */       if (null != sPropValue) {
/* 1565 */         validateMaxSQLLoginName(sPropKey, sPropValue);
/*      */       } else {
/* 1567 */         this.activeConnectionProperties.setProperty(sPropKey, "Microsoft JDBC Driver for SQL Server");
/*      */       } 
/* 1569 */       sPropKey = SQLServerDriverBooleanProperty.LAST_UPDATE_COUNT.toString();
/* 1570 */       sPropValue = this.activeConnectionProperties.getProperty(sPropKey);
/* 1571 */       if (null == sPropValue) {
/* 1572 */         sPropValue = Boolean.toString(SQLServerDriverBooleanProperty.LAST_UPDATE_COUNT.getDefaultValue());
/* 1573 */         this.activeConnectionProperties.setProperty(sPropKey, sPropValue);
/*      */       } 
/*      */       
/* 1576 */       sPropKey = SQLServerDriverStringProperty.COLUMN_ENCRYPTION.toString();
/* 1577 */       sPropValue = this.activeConnectionProperties.getProperty(sPropKey);
/* 1578 */       if (null == sPropValue) {
/* 1579 */         sPropValue = SQLServerDriverStringProperty.COLUMN_ENCRYPTION.getDefaultValue();
/* 1580 */         this.activeConnectionProperties.setProperty(sPropKey, sPropValue);
/*      */       } 
/* 1582 */       this.columnEncryptionSetting = ColumnEncryptionSetting.valueOfString(sPropValue).toString();
/*      */       
/* 1584 */       sPropKey = SQLServerDriverStringProperty.ENCLAVE_ATTESTATION_URL.toString();
/* 1585 */       sPropValue = this.activeConnectionProperties.getProperty(sPropKey);
/* 1586 */       if (null != sPropValue) {
/* 1587 */         this.enclaveAttestationUrl = sPropValue;
/*      */       }
/*      */       
/* 1590 */       sPropKey = SQLServerDriverStringProperty.ENCLAVE_ATTESTATION_PROTOCOL.toString();
/* 1591 */       sPropValue = this.activeConnectionProperties.getProperty(sPropKey);
/* 1592 */       if (null != sPropValue) {
/* 1593 */         this.enclaveAttestationProtocol = sPropValue;
/* 1594 */         if (!AttestationProtocol.isValidAttestationProtocol(this.enclaveAttestationProtocol)) {
/* 1595 */           throw new SQLServerException(SQLServerException.getErrString("R_enclaveInvalidAttestationProtocol"), null);
/*      */         }
/*      */ 
/*      */         
/* 1599 */         if (this.enclaveAttestationProtocol.equalsIgnoreCase(AttestationProtocol.HGS.toString())) {
/* 1600 */           this.enclaveProvider = new SQLServerVSMEnclaveProvider();
/*      */         } else {
/*      */           
/* 1603 */           this.enclaveProvider = new SQLServerAASEnclaveProvider();
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 1608 */       if ((null != this.enclaveAttestationUrl && !this.enclaveAttestationUrl.isEmpty() && (null == this.enclaveAttestationProtocol || this.enclaveAttestationProtocol
/* 1609 */         .isEmpty())) || (null != this.enclaveAttestationProtocol && 
/* 1610 */         !this.enclaveAttestationProtocol.isEmpty() && (null == this.enclaveAttestationUrl || this.enclaveAttestationUrl
/* 1611 */         .isEmpty())) || (null != this.enclaveAttestationUrl && 
/* 1612 */         !this.enclaveAttestationUrl.isEmpty() && (null != this.enclaveAttestationProtocol || 
/* 1613 */         !this.enclaveAttestationProtocol.isEmpty()) && (null == this.columnEncryptionSetting || 
/* 1614 */         !isColumnEncryptionSettingEnabled()))) {
/* 1615 */         throw new SQLServerException(SQLServerException.getErrString("R_enclavePropertiesError"), null);
/*      */       }
/*      */       
/* 1618 */       sPropKey = SQLServerDriverStringProperty.KEY_STORE_AUTHENTICATION.toString();
/* 1619 */       sPropValue = this.activeConnectionProperties.getProperty(sPropKey);
/* 1620 */       if (null != sPropValue) {
/* 1621 */         this.keyStoreAuthentication = KeyStoreAuthentication.valueOfString(sPropValue).toString();
/*      */       }
/*      */       
/* 1624 */       sPropKey = SQLServerDriverStringProperty.KEY_STORE_SECRET.toString();
/* 1625 */       sPropValue = this.activeConnectionProperties.getProperty(sPropKey);
/* 1626 */       if (null != sPropValue) {
/* 1627 */         this.keyStoreSecret = sPropValue;
/*      */       }
/*      */       
/* 1630 */       sPropKey = SQLServerDriverStringProperty.KEY_STORE_LOCATION.toString();
/* 1631 */       sPropValue = this.activeConnectionProperties.getProperty(sPropKey);
/* 1632 */       if (null != sPropValue) {
/* 1633 */         this.keyStoreLocation = sPropValue;
/*      */       }
/*      */       
/* 1636 */       sPropKey = SQLServerDriverStringProperty.KEY_STORE_PRINCIPAL_ID.toString();
/* 1637 */       sPropValue = this.activeConnectionProperties.getProperty(sPropKey);
/* 1638 */       if (null != sPropValue) {
/* 1639 */         this.keyStorePrincipalId = sPropValue;
/*      */       }
/*      */       
/* 1642 */       registerKeyStoreProviderOnConnection(this.keyStoreAuthentication, this.keyStoreSecret, this.keyStoreLocation);
/*      */       
/* 1644 */       if (null == globalCustomColumnEncryptionKeyStoreProviders) {
/* 1645 */         sPropKey = SQLServerDriverStringProperty.KEY_VAULT_PROVIDER_CLIENT_ID.toString();
/* 1646 */         sPropValue = this.activeConnectionProperties.getProperty(sPropKey);
/* 1647 */         if (null != sPropValue) {
/* 1648 */           String keyVaultColumnEncryptionProviderClientId = sPropValue;
/* 1649 */           sPropKey = SQLServerDriverStringProperty.KEY_VAULT_PROVIDER_CLIENT_KEY.toString();
/* 1650 */           sPropValue = this.activeConnectionProperties.getProperty(sPropKey);
/* 1651 */           if (null != sPropValue) {
/* 1652 */             String keyVaultColumnEncryptionProviderClientKey = sPropValue;
/*      */             
/* 1654 */             registerKeyVaultProvider(keyVaultColumnEncryptionProviderClientId, keyVaultColumnEncryptionProviderClientKey);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 1660 */       sPropKey = SQLServerDriverBooleanProperty.MULTI_SUBNET_FAILOVER.toString();
/* 1661 */       sPropValue = this.activeConnectionProperties.getProperty(sPropKey);
/* 1662 */       if (null == sPropValue) {
/* 1663 */         sPropValue = Boolean.toString(SQLServerDriverBooleanProperty.MULTI_SUBNET_FAILOVER.getDefaultValue());
/* 1664 */         this.activeConnectionProperties.setProperty(sPropKey, sPropValue);
/*      */       } 
/* 1666 */       this.multiSubnetFailover = isBooleanPropertyOn(sPropKey, sPropValue);
/*      */       
/* 1668 */       sPropKey = SQLServerDriverBooleanProperty.TRANSPARENT_NETWORK_IP_RESOLUTION.toString();
/* 1669 */       sPropValue = this.activeConnectionProperties.getProperty(sPropKey);
/* 1670 */       if (null == sPropValue) {
/* 1671 */         this.userSetTNIR = false;
/*      */         
/* 1673 */         sPropValue = Boolean.toString(SQLServerDriverBooleanProperty.TRANSPARENT_NETWORK_IP_RESOLUTION.getDefaultValue());
/* 1674 */         this.activeConnectionProperties.setProperty(sPropKey, sPropValue);
/*      */       } 
/* 1676 */       this.transparentNetworkIPResolution = isBooleanPropertyOn(sPropKey, sPropValue);
/*      */       
/* 1678 */       sPropKey = SQLServerDriverBooleanProperty.ENCRYPT.toString();
/* 1679 */       sPropValue = this.activeConnectionProperties.getProperty(sPropKey);
/* 1680 */       if (null == sPropValue) {
/* 1681 */         sPropValue = Boolean.toString(SQLServerDriverBooleanProperty.ENCRYPT.getDefaultValue());
/* 1682 */         this.activeConnectionProperties.setProperty(sPropKey, sPropValue);
/*      */       } 
/*      */       
/* 1685 */       this
/* 1686 */         .socketFactoryClass = this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.SOCKET_FACTORY_CLASS.toString());
/* 1687 */       this
/* 1688 */         .socketFactoryConstructorArg = this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.SOCKET_FACTORY_CONSTRUCTOR_ARG.toString());
/*      */ 
/*      */       
/* 1691 */       this.requestedEncryptionLevel = isBooleanPropertyOn(sPropKey, sPropValue) ? 1 : 0;
/*      */       
/* 1693 */       sPropKey = SQLServerDriverBooleanProperty.TRUST_SERVER_CERTIFICATE.toString();
/* 1694 */       sPropValue = this.activeConnectionProperties.getProperty(sPropKey);
/* 1695 */       if (null == sPropValue) {
/*      */         
/* 1697 */         sPropValue = Boolean.toString(SQLServerDriverBooleanProperty.TRUST_SERVER_CERTIFICATE.getDefaultValue());
/* 1698 */         this.activeConnectionProperties.setProperty(sPropKey, sPropValue);
/*      */       } 
/*      */       
/* 1701 */       this.trustServerCertificate = isBooleanPropertyOn(sPropKey, sPropValue);
/*      */       
/* 1703 */       this
/* 1704 */         .trustManagerClass = this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.TRUST_MANAGER_CLASS.toString());
/* 1705 */       this
/* 1706 */         .trustManagerConstructorArg = this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.TRUST_MANAGER_CONSTRUCTOR_ARG.toString());
/*      */       
/* 1708 */       sPropKey = SQLServerDriverStringProperty.SELECT_METHOD.toString();
/* 1709 */       sPropValue = this.activeConnectionProperties.getProperty(sPropKey);
/* 1710 */       if (null == sPropValue) {
/* 1711 */         sPropValue = SQLServerDriverStringProperty.SELECT_METHOD.getDefaultValue();
/*      */       }
/*      */       
/* 1714 */       if ("cursor".equalsIgnoreCase(sPropValue) || "direct".equalsIgnoreCase(sPropValue)) {
/* 1715 */         sPropValue = sPropValue.toLowerCase(Locale.ENGLISH);
/* 1716 */         this.activeConnectionProperties.setProperty(sPropKey, sPropValue);
/* 1717 */         this.selectMethod = sPropValue;
/*      */       } else {
/* 1719 */         MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidselectMethod"));
/* 1720 */         Object[] msgArgs = { sPropValue };
/* 1721 */         SQLServerException.makeFromDriverError(this, this, form.format(msgArgs), (String)null, false);
/*      */       } 
/*      */       
/* 1724 */       sPropKey = SQLServerDriverStringProperty.RESPONSE_BUFFERING.toString();
/* 1725 */       sPropValue = this.activeConnectionProperties.getProperty(sPropKey);
/* 1726 */       if (null == sPropValue) {
/* 1727 */         sPropValue = SQLServerDriverStringProperty.RESPONSE_BUFFERING.getDefaultValue();
/*      */       }
/*      */       
/* 1730 */       if ("full".equalsIgnoreCase(sPropValue) || "adaptive".equalsIgnoreCase(sPropValue)) {
/* 1731 */         this.activeConnectionProperties.setProperty(sPropKey, sPropValue.toLowerCase(Locale.ENGLISH));
/*      */       } else {
/* 1733 */         MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidresponseBuffering"));
/* 1734 */         Object[] msgArgs = { sPropValue };
/* 1735 */         SQLServerException.makeFromDriverError(this, this, form.format(msgArgs), (String)null, false);
/*      */       } 
/*      */       
/* 1738 */       sPropKey = SQLServerDriverStringProperty.APPLICATION_INTENT.toString();
/* 1739 */       sPropValue = this.activeConnectionProperties.getProperty(sPropKey);
/* 1740 */       if (null == sPropValue) {
/* 1741 */         sPropValue = SQLServerDriverStringProperty.APPLICATION_INTENT.getDefaultValue();
/*      */       }
/*      */       
/* 1744 */       this.applicationIntent = ApplicationIntent.valueOfString(sPropValue);
/* 1745 */       this.activeConnectionProperties.setProperty(sPropKey, this.applicationIntent.toString());
/*      */       
/* 1747 */       sPropKey = SQLServerDriverBooleanProperty.SEND_TIME_AS_DATETIME.toString();
/* 1748 */       sPropValue = this.activeConnectionProperties.getProperty(sPropKey);
/* 1749 */       if (null == sPropValue) {
/* 1750 */         sPropValue = Boolean.toString(SQLServerDriverBooleanProperty.SEND_TIME_AS_DATETIME.getDefaultValue());
/* 1751 */         this.activeConnectionProperties.setProperty(sPropKey, sPropValue);
/*      */       } 
/*      */       
/* 1754 */       this.sendTimeAsDatetime = isBooleanPropertyOn(sPropKey, sPropValue);
/*      */       
/* 1756 */       sPropKey = SQLServerDriverBooleanProperty.USE_FMT_ONLY.toString();
/* 1757 */       sPropValue = this.activeConnectionProperties.getProperty(sPropKey);
/* 1758 */       if (null == sPropValue) {
/* 1759 */         sPropValue = Boolean.toString(SQLServerDriverBooleanProperty.USE_FMT_ONLY.getDefaultValue());
/* 1760 */         this.activeConnectionProperties.setProperty(sPropKey, sPropValue);
/*      */       } 
/* 1762 */       this.useFmtOnly = isBooleanPropertyOn(sPropKey, sPropValue);
/*      */ 
/*      */       
/* 1765 */       sPropKey = SQLServerDriverIntProperty.STATEMENT_POOLING_CACHE_SIZE.toString();
/* 1766 */       if (this.activeConnectionProperties.getProperty(sPropKey) != null && this.activeConnectionProperties
/* 1767 */         .getProperty(sPropKey).length() > 0) {
/*      */         try {
/* 1769 */           int n = Integer.parseInt(this.activeConnectionProperties.getProperty(sPropKey));
/* 1770 */           setStatementPoolingCacheSize(n);
/* 1771 */         } catch (NumberFormatException e) {
/*      */           
/* 1773 */           MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_statementPoolingCacheSize"));
/* 1774 */           Object[] msgArgs = { this.activeConnectionProperties.getProperty(sPropKey) };
/* 1775 */           SQLServerException.makeFromDriverError(this, this, form.format(msgArgs), (String)null, false);
/*      */         } 
/*      */       }
/*      */       
/* 1779 */       sPropKey = SQLServerDriverStringProperty.AAD_SECURE_PRINCIPAL_ID.toString();
/* 1780 */       sPropValue = this.activeConnectionProperties.getProperty(sPropKey);
/* 1781 */       if (null == sPropValue) {
/* 1782 */         sPropValue = SQLServerDriverStringProperty.AAD_SECURE_PRINCIPAL_ID.getDefaultValue();
/* 1783 */         this.activeConnectionProperties.setProperty(sPropKey, sPropValue);
/*      */       } 
/* 1785 */       this.aadPrincipalID = sPropValue;
/*      */       
/* 1787 */       sPropKey = SQLServerDriverStringProperty.AAD_SECURE_PRINCIPAL_SECRET.toString();
/* 1788 */       sPropValue = this.activeConnectionProperties.getProperty(sPropKey);
/* 1789 */       if (null == sPropValue) {
/* 1790 */         sPropValue = SQLServerDriverStringProperty.AAD_SECURE_PRINCIPAL_SECRET.getDefaultValue();
/* 1791 */         this.activeConnectionProperties.setProperty(sPropKey, sPropValue);
/*      */       } 
/* 1793 */       this.aadPrincipalSecret = sPropValue;
/*      */ 
/*      */       
/* 1796 */       sPropKey = SQLServerDriverBooleanProperty.DISABLE_STATEMENT_POOLING.toString();
/* 1797 */       sPropValue = this.activeConnectionProperties.getProperty(sPropKey);
/* 1798 */       if (null != sPropValue) {
/* 1799 */         setDisableStatementPooling(isBooleanPropertyOn(sPropKey, sPropValue));
/*      */       }
/*      */       
/* 1802 */       sPropKey = SQLServerDriverBooleanProperty.INTEGRATED_SECURITY.toString();
/* 1803 */       sPropValue = this.activeConnectionProperties.getProperty(sPropKey);
/* 1804 */       if (null != sPropValue) {
/* 1805 */         this.integratedSecurity = isBooleanPropertyOn(sPropKey, sPropValue);
/*      */       }
/*      */ 
/*      */       
/* 1809 */       if (this.integratedSecurity) {
/* 1810 */         sPropKey = SQLServerDriverStringProperty.AUTHENTICATION_SCHEME.toString();
/* 1811 */         sPropValue = this.activeConnectionProperties.getProperty(sPropKey);
/* 1812 */         if (null != sPropValue) {
/* 1813 */           this.intAuthScheme = AuthenticationScheme.valueOfString(sPropValue);
/*      */         }
/*      */       } 
/*      */       
/* 1817 */       if (this.intAuthScheme == AuthenticationScheme.javaKerberos) {
/* 1818 */         sPropKey = SQLServerDriverObjectProperty.GSS_CREDENTIAL.toString();
/* 1819 */         if (this.activeConnectionProperties.containsKey(sPropKey)) {
/* 1820 */           this.impersonatedUserCred = (GSSCredential)this.activeConnectionProperties.get(sPropKey);
/* 1821 */           this.isUserCreatedCredential = true;
/*      */         } 
/* 1823 */       } else if (this.intAuthScheme == AuthenticationScheme.ntlm) {
/* 1824 */         String sPropKeyDomain = SQLServerDriverStringProperty.DOMAIN.toString();
/* 1825 */         String sPropValueDomain = this.activeConnectionProperties.getProperty(sPropKeyDomain);
/* 1826 */         if (null == sPropValueDomain) {
/* 1827 */           this.activeConnectionProperties.setProperty(sPropKeyDomain, SQLServerDriverStringProperty.DOMAIN
/* 1828 */               .getDefaultValue());
/*      */         }
/*      */ 
/*      */         
/* 1832 */         if (this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.USER.toString()).isEmpty() || this.activeConnectionProperties
/* 1833 */           .getProperty(SQLServerDriverStringProperty.PASSWORD.toString())
/* 1834 */           .isEmpty()) {
/*      */           
/* 1836 */           if (connectionlogger.isLoggable(Level.SEVERE)) {
/* 1837 */             connectionlogger.severe(
/* 1838 */                 toString() + " " + toString());
/*      */           }
/* 1840 */           throw new SQLServerException(SQLServerException.getErrString("R_NtlmNoUserPasswordDomain"), null);
/*      */         } 
/* 1842 */         this.ntlmAuthentication = true;
/*      */       } 
/*      */       
/* 1845 */       sPropKey = SQLServerDriverStringProperty.AUTHENTICATION.toString();
/* 1846 */       sPropValue = this.activeConnectionProperties.getProperty(sPropKey);
/* 1847 */       if (null == sPropValue) {
/* 1848 */         sPropValue = SQLServerDriverStringProperty.AUTHENTICATION.getDefaultValue();
/*      */       }
/* 1850 */       this.authenticationString = SqlAuthentication.valueOfString(sPropValue).toString().trim();
/*      */       
/* 1852 */       if (this.integratedSecurity && 
/* 1853 */         !this.authenticationString.equalsIgnoreCase(SqlAuthentication.NotSpecified.toString())) {
/* 1854 */         if (connectionlogger.isLoggable(Level.SEVERE)) {
/* 1855 */           connectionlogger.severe(toString() + " " + toString());
/*      */         }
/*      */         
/* 1858 */         throw new SQLServerException(
/* 1859 */             SQLServerException.getErrString("R_SetAuthenticationWhenIntegratedSecurityTrue"), null);
/*      */       } 
/*      */       
/* 1862 */       if (this.authenticationString.equalsIgnoreCase(SqlAuthentication.ActiveDirectoryIntegrated.toString()) && (
/*      */         
/* 1864 */         !this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.USER.toString()).isEmpty() || 
/*      */         
/* 1866 */         !this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.PASSWORD.toString()).isEmpty())) {
/* 1867 */         if (connectionlogger.isLoggable(Level.SEVERE)) {
/* 1868 */           connectionlogger.severe(toString() + " " + toString());
/*      */         }
/*      */         
/* 1871 */         throw new SQLServerException(
/* 1872 */             SQLServerException.getErrString("R_IntegratedAuthenticationWithUserPassword"), null);
/*      */       } 
/*      */       
/* 1875 */       if (this.authenticationString.equalsIgnoreCase(SqlAuthentication.ActiveDirectoryPassword.toString()) && (this.activeConnectionProperties
/* 1876 */         .getProperty(SQLServerDriverStringProperty.USER.toString())
/* 1877 */         .isEmpty() || this.activeConnectionProperties
/*      */         
/* 1879 */         .getProperty(SQLServerDriverStringProperty.PASSWORD.toString()).isEmpty())) {
/* 1880 */         if (connectionlogger.isLoggable(Level.SEVERE)) {
/* 1881 */           connectionlogger.severe(
/* 1882 */               toString() + " " + toString());
/*      */         }
/* 1884 */         throw new SQLServerException(SQLServerException.getErrString("R_NoUserPasswordForActivePassword"), null);
/*      */       } 
/*      */ 
/*      */       
/* 1888 */       if (this.authenticationString.equalsIgnoreCase(SqlAuthentication.ActiveDirectoryMSI.toString()) && (
/*      */         
/* 1890 */         !this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.USER.toString()).isEmpty() || 
/*      */         
/* 1892 */         !this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.PASSWORD.toString()).isEmpty())) {
/* 1893 */         if (connectionlogger.isLoggable(Level.SEVERE)) {
/* 1894 */           connectionlogger.severe(
/* 1895 */               toString() + " " + toString());
/*      */         }
/* 1897 */         throw new SQLServerException(SQLServerException.getErrString("R_MSIAuthenticationWithUserPassword"), null);
/*      */       } 
/*      */ 
/*      */       
/* 1901 */       if (this.authenticationString.equalsIgnoreCase(SqlAuthentication.ActiveDirectoryServicePrincipal.toString()) && (this.activeConnectionProperties
/*      */         
/* 1903 */         .getProperty(SQLServerDriverStringProperty.AAD_SECURE_PRINCIPAL_ID.toString()).isEmpty() || this.activeConnectionProperties
/*      */         
/* 1905 */         .getProperty(SQLServerDriverStringProperty.AAD_SECURE_PRINCIPAL_SECRET.toString())
/* 1906 */         .isEmpty())) {
/* 1907 */         if (connectionlogger.isLoggable(Level.SEVERE)) {
/* 1908 */           connectionlogger.severe(toString() + " " + toString());
/*      */         }
/*      */         
/* 1911 */         throw new SQLServerException(
/* 1912 */             SQLServerException.getErrString("R_NoUserPasswordForActiveServicePrincipal"), null);
/*      */       } 
/*      */       
/* 1915 */       if (this.authenticationString.equalsIgnoreCase(SqlAuthentication.SqlPassword.toString()) && (this.activeConnectionProperties
/* 1916 */         .getProperty(SQLServerDriverStringProperty.USER.toString())
/* 1917 */         .isEmpty() || this.activeConnectionProperties
/*      */         
/* 1919 */         .getProperty(SQLServerDriverStringProperty.PASSWORD.toString()).isEmpty())) {
/* 1920 */         if (connectionlogger.isLoggable(Level.SEVERE)) {
/* 1921 */           connectionlogger.severe(
/* 1922 */               toString() + " " + toString());
/*      */         }
/* 1924 */         throw new SQLServerException(SQLServerException.getErrString("R_NoUserPasswordForSqlPassword"), null);
/*      */       } 
/*      */       
/* 1927 */       sPropKey = SQLServerDriverStringProperty.ACCESS_TOKEN.toString();
/* 1928 */       sPropValue = this.activeConnectionProperties.getProperty(sPropKey);
/* 1929 */       if (null != sPropValue) {
/* 1930 */         this.accessTokenInByte = sPropValue.getBytes(StandardCharsets.UTF_16LE);
/*      */       }
/*      */       
/* 1933 */       if (null != this.accessTokenInByte && 0 == this.accessTokenInByte.length) {
/* 1934 */         if (connectionlogger.isLoggable(Level.SEVERE)) {
/* 1935 */           connectionlogger
/* 1936 */             .severe(toString() + " " + toString());
/*      */         }
/* 1938 */         throw new SQLServerException(SQLServerException.getErrString("R_AccessTokenCannotBeEmpty"), null);
/*      */       } 
/*      */       
/* 1941 */       if (this.integratedSecurity && null != this.accessTokenInByte) {
/* 1942 */         if (connectionlogger.isLoggable(Level.SEVERE)) {
/* 1943 */           connectionlogger.severe(toString() + " " + toString());
/*      */         }
/*      */         
/* 1946 */         throw new SQLServerException(
/* 1947 */             SQLServerException.getErrString("R_SetAccesstokenWhenIntegratedSecurityTrue"), null);
/*      */       } 
/*      */       
/* 1950 */       if (!this.authenticationString.equalsIgnoreCase(SqlAuthentication.NotSpecified.toString()) && null != this.accessTokenInByte) {
/*      */         
/* 1952 */         if (connectionlogger.isLoggable(Level.SEVERE)) {
/* 1953 */           connectionlogger.severe(toString() + " " + toString());
/*      */         }
/*      */         
/* 1956 */         throw new SQLServerException(SQLServerException.getErrString("R_SetBothAuthenticationAndAccessToken"), null);
/*      */       } 
/*      */ 
/*      */       
/* 1960 */       if (null != this.accessTokenInByte && (
/* 1961 */         !this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.USER.toString()).isEmpty() || 
/*      */         
/* 1963 */         !this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.PASSWORD.toString()).isEmpty())) {
/* 1964 */         if (connectionlogger.isLoggable(Level.SEVERE)) {
/* 1965 */           connectionlogger.severe(
/* 1966 */               toString() + " " + toString());
/*      */         }
/* 1968 */         throw new SQLServerException(SQLServerException.getErrString("R_AccessTokenWithUserPassword"), null);
/*      */       } 
/*      */ 
/*      */       
/* 1972 */       if (!this.userSetTNIR && (!this.authenticationString.equalsIgnoreCase(SqlAuthentication.NotSpecified.toString()) || null != this.accessTokenInByte))
/*      */       {
/* 1974 */         this.transparentNetworkIPResolution = false;
/*      */       }
/*      */       
/* 1977 */       sPropKey = SQLServerDriverStringProperty.WORKSTATION_ID.toString();
/* 1978 */       sPropValue = this.activeConnectionProperties.getProperty(sPropKey);
/* 1979 */       validateMaxSQLLoginName(sPropKey, sPropValue);
/*      */       
/* 1981 */       int nPort = 0;
/* 1982 */       sPropKey = SQLServerDriverIntProperty.PORT_NUMBER.toString();
/*      */       try {
/* 1984 */         String strPort = this.activeConnectionProperties.getProperty(sPropKey);
/* 1985 */         if (null != strPort) {
/* 1986 */           nPort = Integer.parseInt(strPort);
/*      */           
/* 1988 */           if (nPort < 0 || nPort > 65535) {
/* 1989 */             MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidPortNumber"));
/* 1990 */             Object[] msgArgs = { Integer.toString(nPort) };
/* 1991 */             SQLServerException.makeFromDriverError(this, this, form.format(msgArgs), (String)null, false);
/*      */           } 
/*      */         } 
/* 1994 */       } catch (NumberFormatException e) {
/* 1995 */         MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidPortNumber"));
/* 1996 */         Object[] msgArgs = { this.activeConnectionProperties.getProperty(sPropKey) };
/* 1997 */         SQLServerException.makeFromDriverError(this, this, form.format(msgArgs), (String)null, false);
/*      */       } 
/*      */ 
/*      */       
/* 2001 */       sPropKey = SQLServerDriverIntProperty.PACKET_SIZE.toString();
/* 2002 */       sPropValue = this.activeConnectionProperties.getProperty(sPropKey);
/* 2003 */       if (null != sPropValue && sPropValue.length() > 0) {
/*      */         try {
/* 2005 */           this.requestedPacketSize = Integer.parseInt(sPropValue);
/*      */ 
/*      */           
/* 2008 */           if (-1 == this.requestedPacketSize)
/* 2009 */           { this.requestedPacketSize = 0;
/*      */              }
/*      */           
/* 2012 */           else if (0 == this.requestedPacketSize)
/* 2013 */           { this.requestedPacketSize = 32767; } 
/* 2014 */         } catch (NumberFormatException e) {
/*      */ 
/*      */           
/* 2017 */           this.requestedPacketSize = -1;
/*      */         } 
/*      */         
/* 2020 */         if (0 != this.requestedPacketSize)
/*      */         {
/* 2022 */           if (this.requestedPacketSize < 512 || this.requestedPacketSize > 32767) {
/* 2023 */             MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidPacketSize"));
/* 2024 */             Object[] msgArgs = { sPropValue };
/* 2025 */             SQLServerException.makeFromDriverError(this, this, form.format(msgArgs), (String)null, false);
/*      */           } 
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2034 */       sPropKey = SQLServerDriverBooleanProperty.SEND_STRING_PARAMETERS_AS_UNICODE.toString();
/* 2035 */       this
/*      */         
/* 2037 */         .sendStringParametersAsUnicode = (null == this.activeConnectionProperties.getProperty(sPropKey)) ? SQLServerDriverBooleanProperty.SEND_STRING_PARAMETERS_AS_UNICODE.getDefaultValue() : isBooleanPropertyOn(sPropKey, this.activeConnectionProperties.getProperty(sPropKey));
/*      */       
/* 2039 */       sPropKey = SQLServerDriverBooleanProperty.LAST_UPDATE_COUNT.toString();
/* 2040 */       this.lastUpdateCount = isBooleanPropertyOn(sPropKey, this.activeConnectionProperties.getProperty(sPropKey));
/* 2041 */       sPropKey = SQLServerDriverBooleanProperty.XOPEN_STATES.toString();
/* 2042 */       this.xopenStates = isBooleanPropertyOn(sPropKey, this.activeConnectionProperties.getProperty(sPropKey));
/*      */       
/* 2044 */       sPropKey = SQLServerDriverStringProperty.RESPONSE_BUFFERING.toString();
/* 2045 */       this
/*      */ 
/*      */ 
/*      */         
/* 2049 */         .responseBuffering = (null != this.activeConnectionProperties.getProperty(sPropKey) && this.activeConnectionProperties.getProperty(sPropKey).length() > 0) ? this.activeConnectionProperties.getProperty(sPropKey) : null;
/*      */       
/* 2051 */       sPropKey = SQLServerDriverIntProperty.LOCK_TIMEOUT.toString();
/* 2052 */       int defaultLockTimeOut = SQLServerDriverIntProperty.LOCK_TIMEOUT.getDefaultValue();
/* 2053 */       this.nLockTimeout = defaultLockTimeOut;
/* 2054 */       if (this.activeConnectionProperties.getProperty(sPropKey) != null && this.activeConnectionProperties
/* 2055 */         .getProperty(sPropKey).length() > 0) {
/*      */         try {
/* 2057 */           int n = Integer.parseInt(this.activeConnectionProperties.getProperty(sPropKey));
/* 2058 */           if (n >= defaultLockTimeOut) {
/* 2059 */             this.nLockTimeout = n;
/*      */           } else {
/* 2061 */             MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidLockTimeOut"));
/* 2062 */             Object[] msgArgs = { this.activeConnectionProperties.getProperty(sPropKey) };
/* 2063 */             SQLServerException.makeFromDriverError(this, this, form.format(msgArgs), (String)null, false);
/*      */           } 
/* 2065 */         } catch (NumberFormatException e) {
/* 2066 */           MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidLockTimeOut"));
/* 2067 */           Object[] msgArgs = { this.activeConnectionProperties.getProperty(sPropKey) };
/* 2068 */           SQLServerException.makeFromDriverError(this, this, form.format(msgArgs), (String)null, false);
/*      */         } 
/*      */       }
/*      */       
/* 2072 */       sPropKey = SQLServerDriverIntProperty.QUERY_TIMEOUT.toString();
/* 2073 */       int defaultQueryTimeout = SQLServerDriverIntProperty.QUERY_TIMEOUT.getDefaultValue();
/* 2074 */       this.queryTimeoutSeconds = defaultQueryTimeout;
/* 2075 */       if (this.activeConnectionProperties.getProperty(sPropKey) != null && this.activeConnectionProperties
/* 2076 */         .getProperty(sPropKey).length() > 0) {
/*      */         try {
/* 2078 */           int n = Integer.parseInt(this.activeConnectionProperties.getProperty(sPropKey));
/* 2079 */           if (n >= defaultQueryTimeout) {
/* 2080 */             this.queryTimeoutSeconds = n;
/*      */           } else {
/*      */             
/* 2083 */             MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidQueryTimeout"));
/* 2084 */             Object[] msgArgs = { this.activeConnectionProperties.getProperty(sPropKey) };
/* 2085 */             SQLServerException.makeFromDriverError(this, this, form.format(msgArgs), (String)null, false);
/*      */           } 
/* 2087 */         } catch (NumberFormatException e) {
/* 2088 */           MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidQueryTimeout"));
/* 2089 */           Object[] msgArgs = { this.activeConnectionProperties.getProperty(sPropKey) };
/* 2090 */           SQLServerException.makeFromDriverError(this, this, form.format(msgArgs), (String)null, false);
/*      */         } 
/*      */       }
/*      */       
/* 2094 */       sPropKey = SQLServerDriverIntProperty.SOCKET_TIMEOUT.toString();
/* 2095 */       int defaultSocketTimeout = SQLServerDriverIntProperty.SOCKET_TIMEOUT.getDefaultValue();
/* 2096 */       this.socketTimeoutMilliseconds = defaultSocketTimeout;
/* 2097 */       if (this.activeConnectionProperties.getProperty(sPropKey) != null && this.activeConnectionProperties
/* 2098 */         .getProperty(sPropKey).length() > 0) {
/*      */         try {
/* 2100 */           int n = Integer.parseInt(this.activeConnectionProperties.getProperty(sPropKey));
/* 2101 */           if (n >= defaultSocketTimeout) {
/* 2102 */             this.socketTimeoutMilliseconds = n;
/*      */           } else {
/*      */             
/* 2105 */             MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidSocketTimeout"));
/* 2106 */             Object[] msgArgs = { this.activeConnectionProperties.getProperty(sPropKey) };
/* 2107 */             SQLServerException.makeFromDriverError(this, this, form.format(msgArgs), (String)null, false);
/*      */           } 
/* 2109 */         } catch (NumberFormatException e) {
/* 2110 */           MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidSocketTimeout"));
/* 2111 */           Object[] msgArgs = { this.activeConnectionProperties.getProperty(sPropKey) };
/* 2112 */           SQLServerException.makeFromDriverError(this, this, form.format(msgArgs), (String)null, false);
/*      */         } 
/*      */       }
/*      */       
/* 2116 */       sPropKey = SQLServerDriverIntProperty.CANCEL_QUERY_TIMEOUT.toString();
/* 2117 */       int cancelQueryTimeout = SQLServerDriverIntProperty.CANCEL_QUERY_TIMEOUT.getDefaultValue();
/*      */       
/* 2119 */       if (this.activeConnectionProperties.getProperty(sPropKey) != null && this.activeConnectionProperties
/* 2120 */         .getProperty(sPropKey).length() > 0) {
/*      */         try {
/* 2122 */           int n = Integer.parseInt(this.activeConnectionProperties.getProperty(sPropKey));
/* 2123 */           if (n >= cancelQueryTimeout) {
/*      */             
/* 2125 */             if (this.queryTimeoutSeconds > defaultQueryTimeout) {
/* 2126 */               this.cancelQueryTimeoutSeconds = n;
/*      */             }
/*      */           } else {
/*      */             
/* 2130 */             MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidCancelQueryTimeout"));
/* 2131 */             Object[] msgArgs = { this.activeConnectionProperties.getProperty(sPropKey) };
/* 2132 */             SQLServerException.makeFromDriverError(this, this, form.format(msgArgs), (String)null, false);
/*      */           } 
/* 2134 */         } catch (NumberFormatException e) {
/*      */           
/* 2136 */           MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidCancelQueryTimeout"));
/* 2137 */           Object[] msgArgs = { this.activeConnectionProperties.getProperty(sPropKey) };
/* 2138 */           SQLServerException.makeFromDriverError(this, this, form.format(msgArgs), (String)null, false);
/*      */         } 
/*      */       }
/*      */       
/* 2142 */       sPropKey = SQLServerDriverIntProperty.SERVER_PREPARED_STATEMENT_DISCARD_THRESHOLD.toString();
/* 2143 */       if (this.activeConnectionProperties.getProperty(sPropKey) != null && this.activeConnectionProperties
/* 2144 */         .getProperty(sPropKey).length() > 0) {
/*      */         try {
/* 2146 */           int n = Integer.parseInt(this.activeConnectionProperties.getProperty(sPropKey));
/* 2147 */           setServerPreparedStatementDiscardThreshold(n);
/* 2148 */         } catch (NumberFormatException e) {
/*      */           
/* 2150 */           MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_serverPreparedStatementDiscardThreshold"));
/* 2151 */           Object[] msgArgs = { this.activeConnectionProperties.getProperty(sPropKey) };
/* 2152 */           SQLServerException.makeFromDriverError(this, this, form.format(msgArgs), (String)null, false);
/*      */         } 
/*      */       }
/*      */       
/* 2156 */       sPropKey = SQLServerDriverBooleanProperty.ENABLE_PREPARE_ON_FIRST_PREPARED_STATEMENT.toString();
/* 2157 */       sPropValue = this.activeConnectionProperties.getProperty(sPropKey);
/* 2158 */       if (null != sPropValue) {
/* 2159 */         setEnablePrepareOnFirstPreparedStatementCall(isBooleanPropertyOn(sPropKey, sPropValue));
/*      */       }
/*      */       
/* 2162 */       sPropKey = SQLServerDriverBooleanProperty.USE_BULK_COPY_FOR_BATCH_INSERT.toString();
/* 2163 */       sPropValue = this.activeConnectionProperties.getProperty(sPropKey);
/* 2164 */       if (null != sPropValue) {
/* 2165 */         this.useBulkCopyForBatchInsert = isBooleanPropertyOn(sPropKey, sPropValue);
/*      */       }
/*      */       
/* 2168 */       sPropKey = SQLServerDriverStringProperty.SSL_PROTOCOL.toString();
/* 2169 */       sPropValue = this.activeConnectionProperties.getProperty(sPropKey);
/* 2170 */       if (null == sPropValue) {
/* 2171 */         sPropValue = SQLServerDriverStringProperty.SSL_PROTOCOL.getDefaultValue();
/* 2172 */         this.activeConnectionProperties.setProperty(sPropKey, sPropValue);
/*      */       } else {
/* 2174 */         this.activeConnectionProperties.setProperty(sPropKey, SSLProtocol.valueOfString(sPropValue).toString());
/*      */       } 
/*      */       
/* 2177 */       sPropKey = SQLServerDriverStringProperty.MSI_CLIENT_ID.toString();
/* 2178 */       sPropValue = this.activeConnectionProperties.getProperty(sPropKey);
/* 2179 */       if (null != sPropValue) {
/* 2180 */         this.activeConnectionProperties.setProperty(sPropKey, sPropValue);
/*      */       }
/*      */       
/* 2183 */       sPropKey = SQLServerDriverStringProperty.CLIENT_CERTIFICATE.toString();
/* 2184 */       sPropValue = this.activeConnectionProperties.getProperty(sPropKey);
/* 2185 */       if (null != sPropValue) {
/* 2186 */         this.activeConnectionProperties.setProperty(sPropKey, sPropValue);
/* 2187 */         this.clientCertificate = sPropValue;
/*      */       } 
/*      */       
/* 2190 */       sPropKey = SQLServerDriverStringProperty.CLIENT_KEY.toString();
/* 2191 */       sPropValue = this.activeConnectionProperties.getProperty(sPropKey);
/* 2192 */       if (null != sPropValue) {
/* 2193 */         this.activeConnectionProperties.setProperty(sPropKey, sPropValue);
/* 2194 */         this.clientKey = sPropValue;
/*      */       } 
/*      */       
/* 2197 */       sPropKey = SQLServerDriverStringProperty.CLIENT_KEY_PASSWORD.toString();
/* 2198 */       sPropValue = this.activeConnectionProperties.getProperty(sPropKey);
/* 2199 */       if (null != sPropValue) {
/* 2200 */         this.activeConnectionProperties.setProperty(sPropKey, sPropValue);
/* 2201 */         this.clientKeyPassword = sPropValue;
/*      */       } 
/*      */       
/* 2204 */       sPropKey = SQLServerDriverBooleanProperty.SEND_TEMPORAL_DATATYPES_AS_STRING_FOR_BULK_COPY.toString();
/* 2205 */       sPropValue = this.activeConnectionProperties.getProperty(sPropKey);
/* 2206 */       if (null != sPropValue) {
/* 2207 */         this.sendTemporalDataTypesAsStringForBulkCopy = isBooleanPropertyOn(sPropKey, sPropValue);
/*      */       }
/*      */       
/* 2210 */       sPropKey = SQLServerDriverStringProperty.MAX_RESULT_BUFFER.toString();
/* 2211 */       sPropValue = this.activeConnectionProperties.getProperty(sPropKey);
/* 2212 */       this.activeConnectionProperties.setProperty(sPropKey, 
/* 2213 */           String.valueOf(MaxResultBufferParser.validateMaxResultBuffer(sPropValue)));
/*      */       
/* 2215 */       sPropKey = SQLServerDriverBooleanProperty.DELAY_LOADING_LOBS.toString();
/* 2216 */       sPropValue = this.activeConnectionProperties.getProperty(sPropKey);
/* 2217 */       if (null == sPropValue) {
/* 2218 */         sPropValue = Boolean.toString(SQLServerDriverBooleanProperty.DELAY_LOADING_LOBS.getDefaultValue());
/* 2219 */         this.activeConnectionProperties.setProperty(sPropKey, sPropValue);
/*      */       } 
/* 2221 */       this.delayLoadingLobs = isBooleanPropertyOn(sPropKey, sPropValue);
/*      */       
/* 2223 */       FailoverInfo fo = null;
/* 2224 */       String databaseNameProperty = SQLServerDriverStringProperty.DATABASE_NAME.toString();
/* 2225 */       String serverNameProperty = SQLServerDriverStringProperty.SERVER_NAME.toString();
/* 2226 */       String failOverPartnerProperty = SQLServerDriverStringProperty.FAILOVER_PARTNER.toString();
/* 2227 */       String failOverPartnerPropertyValue = this.activeConnectionProperties.getProperty(failOverPartnerProperty);
/*      */ 
/*      */       
/* 2230 */       if (this.multiSubnetFailover && failOverPartnerPropertyValue != null) {
/* 2231 */         SQLServerException.makeFromDriverError(this, this, 
/* 2232 */             SQLServerException.getErrString("R_dbMirroringWithMultiSubnetFailover"), (String)null, false);
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 2237 */       if ((this.multiSubnetFailover || null != failOverPartnerPropertyValue) && !this.userSetTNIR) {
/* 2238 */         this.transparentNetworkIPResolution = false;
/*      */       }
/*      */ 
/*      */       
/* 2242 */       if (this.applicationIntent != null && this.applicationIntent.equals(ApplicationIntent.READ_ONLY) && failOverPartnerPropertyValue != null)
/*      */       {
/* 2244 */         SQLServerException.makeFromDriverError(this, this, 
/* 2245 */             SQLServerException.getErrString("R_dbMirroringWithReadOnlyIntent"), (String)null, false);
/*      */       }
/*      */ 
/*      */       
/* 2249 */       if (null != this.activeConnectionProperties.getProperty(databaseNameProperty)) {
/*      */         
/* 2251 */         fo = FailoverMapSingleton.getFailoverInfo(this, this.activeConnectionProperties
/* 2252 */             .getProperty(serverNameProperty), this.activeConnectionProperties
/* 2253 */             .getProperty(instanceNameProperty), this.activeConnectionProperties
/* 2254 */             .getProperty(databaseNameProperty));
/*      */       
/*      */       }
/* 2257 */       else if (null != failOverPartnerPropertyValue) {
/* 2258 */         SQLServerException.makeFromDriverError(this, this, 
/* 2259 */             SQLServerException.getErrString("R_failoverPartnerWithoutDB"), (String)null, true);
/*      */       } 
/*      */       
/* 2262 */       String mirror = (null == fo) ? failOverPartnerPropertyValue : null;
/*      */       
/* 2264 */       long startTime = System.currentTimeMillis();
/* 2265 */       login(this.activeConnectionProperties.getProperty(serverNameProperty), instanceValue, nPort, mirror, fo, loginTimeoutSeconds, startTime);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2270 */       if (1 == this.negotiatedEncryptionLevel || 3 == this.negotiatedEncryptionLevel) {
/*      */         
/* 2272 */         int sslRecordSize = Util.isIBM() ? 8192 : 16384;
/*      */         
/* 2274 */         if (this.tdsPacketSize > sslRecordSize) {
/* 2275 */           if (connectionlogger.isLoggable(Level.FINER)) {
/* 2276 */             connectionlogger.finer(toString() + " Negotiated tdsPacketSize " + toString() + " is too large for SSL with JRE " + this.tdsPacketSize + " (max size is " + Util.SYSTEM_JRE + ")");
/*      */           }
/*      */ 
/*      */           
/* 2280 */           MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_packetSizeTooBigForSSL"));
/* 2281 */           Object[] msgArgs = { Integer.toString(sslRecordSize) };
/* 2282 */           terminate(6, form.format(msgArgs));
/*      */         } 
/*      */       } 
/*      */       
/* 2286 */       this.state = State.Opened;
/*      */       
/* 2288 */       if (connectionlogger.isLoggable(Level.FINER)) {
/* 2289 */         connectionlogger.finer(toString() + " End of connect");
/*      */       }
/*      */     }
/*      */     finally {
/*      */       
/* 2294 */       if (!this.state.equals(State.Opened))
/*      */       {
/* 2296 */         if (!this.state.equals(State.Closed)) {
/* 2297 */           close();
/*      */         }
/*      */       }
/*      */     } 
/* 2301 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void login(String primary, String primaryInstanceName, int primaryPortNumber, String mirror, FailoverInfo foActual, int timeout, long timerStart) throws SQLServerException {
/*      */     long timeoutUnitInterval;
/* 2314 */     boolean isDBMirroring = (null != mirror || null != foActual);
/* 2315 */     int sleepInterval = 100;
/*      */ 
/*      */     
/* 2318 */     boolean useFailoverHost = false;
/* 2319 */     FailoverInfo tempFailover = null;
/*      */     
/* 2321 */     ServerPortPlaceHolder currentFOPlaceHolder = null;
/*      */     
/* 2323 */     ServerPortPlaceHolder currentPrimaryPlaceHolder = null;
/*      */     
/* 2325 */     if (null != foActual) {
/* 2326 */       tempFailover = foActual;
/* 2327 */       useFailoverHost = foActual.getUseFailoverPartner();
/*      */     }
/* 2329 */     else if (isDBMirroring) {
/*      */       
/* 2331 */       tempFailover = new FailoverInfo(mirror, this, false);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2338 */     boolean useParallel = getMultiSubnetFailover();
/* 2339 */     boolean useTnir = getTransparentNetworkIPResolution();
/*      */ 
/*      */ 
/*      */     
/* 2343 */     if (0 == timeout) {
/* 2344 */       timeout = SQLServerDriverIntProperty.LOGIN_TIMEOUT.getDefaultValue();
/*      */     }
/* 2346 */     long timerTimeout = timeout * 1000L;
/* 2347 */     this.timerExpire = timerStart + timerTimeout;
/*      */ 
/*      */ 
/*      */     
/* 2351 */     if (isDBMirroring || useParallel) {
/* 2352 */       timeoutUnitInterval = (long)(0.08F * (float)timerTimeout);
/* 2353 */     } else if (useTnir) {
/* 2354 */       timeoutUnitInterval = (long)(0.125F * (float)timerTimeout);
/*      */     } else {
/* 2356 */       timeoutUnitInterval = timerTimeout;
/*      */     } 
/* 2358 */     long intervalExpire = timerStart + timeoutUnitInterval;
/*      */ 
/*      */ 
/*      */     
/* 2362 */     long intervalExpireFullTimeout = timerStart + timerTimeout;
/*      */     
/* 2364 */     if (connectionlogger.isLoggable(Level.FINER)) {
/* 2365 */       connectionlogger.finer(toString() + " Start time: " + toString() + " Time out time: " + timerStart + " Timeout Unit Interval: " + this.timerExpire);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2371 */     boolean isInteractive = SqlAuthentication.ActiveDirectoryInteractive.toString().equalsIgnoreCase(this.authenticationString);
/*      */ 
/*      */     
/* 2374 */     int attemptNumber = 0;
/*      */ 
/*      */     
/* 2377 */     int noOfRedirections = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 2387 */       this.clientConnectionId = null;
/* 2388 */       this.state = State.Initialized;
/*      */       
/*      */       try {
/* 2391 */         if (isDBMirroring && useFailoverHost) {
/* 2392 */           if (null == currentFOPlaceHolder)
/*      */           {
/* 2394 */             currentFOPlaceHolder = tempFailover.failoverPermissionCheck(this, this.integratedSecurity);
/*      */           }
/* 2396 */           this.currentConnectPlaceHolder = currentFOPlaceHolder;
/*      */         } else {
/* 2398 */           if (this.routingInfo != null) {
/* 2399 */             currentPrimaryPlaceHolder = this.routingInfo;
/* 2400 */             this.routingInfo = null;
/* 2401 */           } else if (null == currentPrimaryPlaceHolder) {
/* 2402 */             currentPrimaryPlaceHolder = primaryPermissionCheck(primary, primaryInstanceName, primaryPortNumber);
/*      */           } 
/*      */           
/* 2405 */           this.currentConnectPlaceHolder = currentPrimaryPlaceHolder;
/*      */         } 
/*      */         
/* 2408 */         if (connectionlogger.isLoggable(Level.FINE)) {
/* 2409 */           connectionlogger
/* 2410 */             .fine(toString() + " This attempt server name: " + toString() + " port: " + this.currentConnectPlaceHolder.getServerName() + " InstanceName: " + this.currentConnectPlaceHolder
/* 2411 */               .getPortNumber() + " useParallel: " + this.currentConnectPlaceHolder
/* 2412 */               .getInstanceName());
/* 2413 */           connectionlogger.fine(toString() + " This attempt endtime: " + toString());
/* 2414 */           connectionlogger.fine(toString() + " This attempt No: " + toString());
/*      */         } 
/*      */ 
/*      */         
/* 2418 */         InetSocketAddress inetSocketAddress = connectHelper(this.currentConnectPlaceHolder, 
/* 2419 */             timerRemaining(intervalExpire), timeout, useParallel, useTnir, (0 == attemptNumber), 
/*      */ 
/*      */             
/* 2422 */             timerRemaining(intervalExpireFullTimeout));
/*      */         
/* 2424 */         if (this.serverSupportsDNSCaching) {
/* 2425 */           dnsCache.put(this.currentConnectPlaceHolder.getServerName(), inetSocketAddress);
/*      */         }
/*      */         
/* 2428 */         if (this.isRoutedInCurrentAttempt) {
/*      */           
/* 2430 */           if (isDBMirroring) {
/* 2431 */             String msg = SQLServerException.getErrString("R_invalidRoutingInfo");
/* 2432 */             terminate(6, msg);
/*      */           } 
/*      */           
/* 2435 */           noOfRedirections++;
/*      */           
/* 2437 */           if (noOfRedirections > 1) {
/* 2438 */             String msg = SQLServerException.getErrString("R_multipleRedirections");
/* 2439 */             terminate(6, msg);
/*      */           } 
/*      */ 
/*      */           
/* 2443 */           if (this.tdsChannel != null) {
/* 2444 */             this.tdsChannel.close();
/*      */           }
/* 2446 */           initResettableValues();
/*      */ 
/*      */ 
/*      */           
/* 2450 */           resetNonRoutingEnvchangeValues();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2456 */           attemptNumber++;
/*      */ 
/*      */           
/* 2459 */           useParallel = false;
/* 2460 */           useTnir = false;
/*      */ 
/*      */ 
/*      */           
/* 2464 */           intervalExpire = this.timerExpire;
/*      */ 
/*      */           
/* 2467 */           if (timerHasExpired(this.timerExpire)) {
/*      */             
/* 2469 */             MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_tcpipConnectionFailed"));
/*      */ 
/*      */             
/* 2472 */             Object[] msgArgs = { getServerNameString(this.currentConnectPlaceHolder.getServerName()), Integer.toString(this.currentConnectPlaceHolder.getPortNumber()), SQLServerException.getErrString("R_timedOutBeforeRouting") };
/* 2473 */             String msg = form.format(msgArgs);
/* 2474 */             terminate(6, msg);
/*      */           } else {
/*      */             
/* 2477 */             this.isRoutedInCurrentAttempt = false;
/*      */             continue;
/*      */           } 
/*      */         } else {
/*      */           break;
/*      */         } 
/* 2483 */       } catch (SQLServerException sqlex) {
/* 2484 */         int errorCode = sqlex.getErrorCode();
/* 2485 */         int driverErrorCode = sqlex.getDriverErrorCode();
/* 2486 */         if (18456 == errorCode || 18488 == errorCode || 18486 == errorCode || 4 == driverErrorCode || 5 == driverErrorCode || 7 == driverErrorCode || 6 == driverErrorCode || 8 == driverErrorCode || (
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2496 */           timerHasExpired(this.timerExpire) && !isInteractive) || (this.state
/*      */           
/* 2498 */           .equals(State.Connected) && !isDBMirroring)) {
/*      */           
/* 2500 */           close();
/* 2501 */           throw sqlex;
/*      */         } 
/*      */ 
/*      */         
/* 2505 */         if (null != this.tdsChannel) {
/* 2506 */           this.tdsChannel.close();
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2512 */         if (!isDBMirroring || 1 == attemptNumber % 2) {
/*      */ 
/*      */           
/* 2515 */           long remainingMilliseconds = timerRemaining(this.timerExpire);
/* 2516 */           if (remainingMilliseconds <= sleepInterval && !isInteractive) {
/* 2517 */             throw sqlex;
/*      */           }
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2527 */       if (!isDBMirroring || 1 == attemptNumber % 2) {
/* 2528 */         if (connectionlogger.isLoggable(Level.FINE)) {
/* 2529 */           connectionlogger.fine(toString() + " sleeping milisec: " + toString());
/*      */         }
/*      */         try {
/* 2532 */           Thread.sleep(sleepInterval);
/* 2533 */         } catch (InterruptedException e) {
/*      */           
/* 2535 */           Thread.currentThread().interrupt();
/*      */         } 
/* 2537 */         sleepInterval = (sleepInterval < 500) ? (sleepInterval * 2) : 1000;
/*      */       } 
/*      */ 
/*      */       
/* 2541 */       attemptNumber++;
/*      */       
/* 2543 */       if (useParallel) {
/* 2544 */         intervalExpire = System.currentTimeMillis() + timeoutUnitInterval * (attemptNumber + 1);
/* 2545 */       } else if (isDBMirroring) {
/* 2546 */         intervalExpire = System.currentTimeMillis() + timeoutUnitInterval * (attemptNumber / 2 + 1);
/* 2547 */       } else if (isInteractive) {
/*      */         
/* 2549 */         timerStart = System.currentTimeMillis();
/* 2550 */         timeout = SQLServerDriverIntProperty.LOGIN_TIMEOUT.getDefaultValue();
/* 2551 */         timerTimeout = timeout * 1000L;
/* 2552 */         this.timerExpire = timerStart + timerTimeout;
/* 2553 */         intervalExpire = timerStart + timeoutUnitInterval;
/* 2554 */         intervalExpireFullTimeout = timerStart + timerTimeout;
/* 2555 */       } else if (useTnir) {
/* 2556 */         long timeSlice = timeoutUnitInterval * (1 << attemptNumber);
/*      */ 
/*      */         
/* 2559 */         if (1 == attemptNumber && 500L > timeSlice) {
/* 2560 */           timeSlice = 500L;
/*      */         }
/*      */         
/* 2563 */         intervalExpire = System.currentTimeMillis() + timeSlice;
/*      */       } else {
/* 2565 */         intervalExpire = this.timerExpire;
/*      */       } 
/*      */ 
/*      */       
/* 2569 */       if (intervalExpire > this.timerExpire) {
/* 2570 */         intervalExpire = this.timerExpire;
/*      */       }
/*      */ 
/*      */       
/* 2574 */       if (isDBMirroring) {
/* 2575 */         useFailoverHost = !useFailoverHost;
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2581 */     if (useFailoverHost && null == this.failoverPartnerServerProvided) {
/* 2582 */       String curserverinfo = this.currentConnectPlaceHolder.getServerName();
/* 2583 */       if (null != currentFOPlaceHolder.getInstanceName()) {
/* 2584 */         curserverinfo = curserverinfo + "\\";
/* 2585 */         curserverinfo = curserverinfo + curserverinfo;
/*      */       } 
/* 2587 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidPartnerConfiguration"));
/*      */       
/* 2589 */       Object[] msgArgs = { this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.DATABASE_NAME.toString()), curserverinfo };
/*      */       
/* 2591 */       terminate(6, form.format(msgArgs));
/*      */     } 
/*      */     
/* 2594 */     if (null != this.failoverPartnerServerProvided) {
/*      */       
/* 2596 */       if (this.multiSubnetFailover) {
/* 2597 */         String msg = SQLServerException.getErrString("R_dbMirroringWithMultiSubnetFailover");
/* 2598 */         terminate(6, msg);
/*      */       } 
/*      */ 
/*      */       
/* 2602 */       if (this.applicationIntent != null && this.applicationIntent.equals(ApplicationIntent.READ_ONLY)) {
/* 2603 */         String msg = SQLServerException.getErrString("R_dbMirroringWithReadOnlyIntent");
/* 2604 */         terminate(6, msg);
/*      */       } 
/*      */       
/* 2607 */       if (null == tempFailover) {
/* 2608 */         tempFailover = new FailoverInfo(this.failoverPartnerServerProvided, this, false);
/*      */       }
/*      */       
/* 2611 */       if (null != foActual) {
/*      */ 
/*      */ 
/*      */         
/* 2615 */         foActual.failoverAdd(this, useFailoverHost, this.failoverPartnerServerProvided);
/*      */       } else {
/* 2617 */         String databaseNameProperty = SQLServerDriverStringProperty.DATABASE_NAME.toString();
/* 2618 */         String instanceNameProperty = SQLServerDriverStringProperty.INSTANCE_NAME.toString();
/* 2619 */         String serverNameProperty = SQLServerDriverStringProperty.SERVER_NAME.toString();
/*      */         
/* 2621 */         if (connectionlogger.isLoggable(Level.FINE)) {
/* 2622 */           connectionlogger.fine(toString() + " adding new failover info server: " + toString() + " instance: " + this.activeConnectionProperties
/* 2623 */               .getProperty(serverNameProperty) + " database: " + this.activeConnectionProperties
/* 2624 */               .getProperty(instanceNameProperty) + " server provided failover: " + this.activeConnectionProperties
/* 2625 */               .getProperty(databaseNameProperty));
/*      */         }
/*      */ 
/*      */         
/* 2629 */         tempFailover.failoverAdd(this, useFailoverHost, this.failoverPartnerServerProvided);
/* 2630 */         FailoverMapSingleton.putFailoverInfo(this, primary, this.activeConnectionProperties
/* 2631 */             .getProperty(instanceNameProperty), this.activeConnectionProperties
/* 2632 */             .getProperty(databaseNameProperty), tempFailover, useFailoverHost, this.failoverPartnerServerProvided);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void resetNonRoutingEnvchangeValues() {
/* 2641 */     this.tdsPacketSize = 4096;
/* 2642 */     this.databaseCollation = null;
/* 2643 */     this.rolledBackTransaction = false;
/* 2644 */     Arrays.fill(getTransactionDescriptor(), (byte)0);
/* 2645 */     this.sCatalog = this.originalCatalog;
/* 2646 */     this.failoverPartnerServerProvided = null;
/*      */   }
/*      */   
/* 2649 */   static final int DEFAULTPORT = SQLServerDriverIntProperty.PORT_NUMBER.getDefaultValue(); private final transient Object schedulerLock; volatile SQLWarning sqlWarnings; private final Object warningSynchronization; private static final int ENVCHANGE_DATABASE = 1; private static final int ENVCHANGE_LANGUAGE = 2; private static final int ENVCHANGE_CHARSET = 3; private static final int ENVCHANGE_PACKETSIZE = 4; private static final int ENVCHANGE_SORTLOCALEID = 5; private static final int ENVCHANGE_SORTFLAGS = 6; private static final int ENVCHANGE_SQLCOLLATION = 7; private static final int ENVCHANGE_XACT_BEGIN = 8; private static final int ENVCHANGE_XACT_COMMIT = 9; private static final int ENVCHANGE_XACT_ROLLBACK = 10; private static final int ENVCHANGE_DTC_ENLIST = 11; private static final int ENVCHANGE_DTC_DEFECT = 12; private static final int ENVCHANGE_CHANGE_MIRROR = 13; private static final int ENVCHANGE_UNUSED_14 = 14; private static final int ENVCHANGE_DTC_PROMOTE = 15; private static final int ENVCHANGE_DTC_MGR_ADDR = 16; private static final int ENVCHANGE_XACT_ENDED = 17; private static final int ENVCHANGE_RESET_COMPLETE = 18; private static final int ENVCHANGE_USER_INFO = 19; private static final int ENVCHANGE_ROUTING = 20; private boolean requestStarted; private boolean originalDatabaseAutoCommitMode; private int originalTransactionIsolationLevel; private int originalNetworkTimeout; private int originalHoldability; private boolean originalSendTimeAsDatetime; private int originalStatementPoolingCacheSize; private boolean originalDisableStatementPooling; private int originalServerPreparedStatementDiscardThreshold; private Boolean originalEnablePrepareOnFirstPreparedStatementCall;
/*      */   private String originalSCatalog;
/*      */   private boolean originalUseBulkCopyForBatchInsert;
/*      */   private volatile SQLWarning originalSqlWarnings;
/*      */   private List<ISQLServerStatement> openStatements;
/*      */   private boolean originalUseFmtOnly;
/*      */   private boolean originalDelayLoadingLobs;
/*      */   int aeVersion;
/*      */   
/*      */   ServerPortPlaceHolder primaryPermissionCheck(String primary, String primaryInstanceName, int primaryPortNumber) throws SQLServerException {
/* 2659 */     if (0 == primaryPortNumber) {
/* 2660 */       if (null != primaryInstanceName) {
/* 2661 */         String instancePort = getInstancePort(primary, primaryInstanceName);
/* 2662 */         if (connectionlogger.isLoggable(Level.FINER))
/* 2663 */           connectionlogger.fine(toString() + " SQL Server port returned by SQL Browser: " + toString()); 
/*      */         try {
/* 2665 */           if (null != instancePort)
/* 2666 */           { primaryPortNumber = Integer.parseInt(instancePort);
/*      */             
/* 2668 */             if (primaryPortNumber < 0 || primaryPortNumber > 65535) {
/*      */               
/* 2670 */               MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidPortNumber"));
/* 2671 */               Object[] msgArgs = { Integer.toString(primaryPortNumber) };
/* 2672 */               SQLServerException.makeFromDriverError(this, this, form.format(msgArgs), (String)null, false);
/*      */             }  }
/*      */           else
/* 2675 */           { primaryPortNumber = DEFAULTPORT; } 
/* 2676 */         } catch (NumberFormatException e) {
/* 2677 */           MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidPortNumber"));
/* 2678 */           Object[] msgArgs = { Integer.valueOf(primaryPortNumber) };
/* 2679 */           SQLServerException.makeFromDriverError(this, this, form.format(msgArgs), (String)null, false);
/*      */         } 
/*      */       } else {
/* 2682 */         primaryPortNumber = DEFAULTPORT;
/*      */       } 
/*      */     }
/*      */     
/* 2686 */     this.activeConnectionProperties.setProperty(SQLServerDriverIntProperty.PORT_NUMBER.toString(), 
/* 2687 */         String.valueOf(primaryPortNumber));
/* 2688 */     return new ServerPortPlaceHolder(primary, primaryPortNumber, primaryInstanceName, this.integratedSecurity);
/*      */   }
/*      */   
/*      */   static boolean timerHasExpired(long timerExpire) {
/* 2692 */     return (System.currentTimeMillis() > timerExpire);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static int timerRemaining(long timerExpire) {
/* 2702 */     long remaining = timerExpire - System.currentTimeMillis();
/*      */     
/* 2704 */     return (int)((remaining > 2147483647L) ? 2147483647L : ((remaining <= 0L) ? 1L : remaining));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private InetSocketAddress connectHelper(ServerPortPlaceHolder serverInfo, int timeOutSliceInMillis, int timeOutFullInSeconds, boolean useParallel, boolean useTnir, boolean isTnirFirstAttempt, int timeOutsliceInMillisForFullTimeout) throws SQLServerException {
/* 2731 */     if (connectionlogger.isLoggable(Level.FINE)) {
/* 2732 */       connectionlogger.fine(toString() + " Connecting with server: " + toString() + " port: " + serverInfo.getServerName() + " Timeout slice: " + serverInfo
/* 2733 */           .getPortNumber() + " Timeout Full: " + timeOutSliceInMillis);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2740 */     this.hostName = this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.WORKSTATION_ID.toString());
/* 2741 */     if (StringUtils.isEmpty(this.hostName)) {
/* 2742 */       this.hostName = Util.lookupHostName();
/*      */     }
/*      */ 
/*      */     
/* 2746 */     this.tdsChannel = new TDSChannel(this);
/* 2747 */     InetSocketAddress inetSocketAddress = this.tdsChannel.open(serverInfo.getServerName(), serverInfo.getPortNumber(), 
/* 2748 */         (0 == timeOutFullInSeconds) ? 0 : timeOutSliceInMillis, useParallel, useTnir, isTnirFirstAttempt, timeOutsliceInMillisForFullTimeout);
/*      */ 
/*      */     
/* 2751 */     setState(State.Connected);
/*      */     
/* 2753 */     this.clientConnectionId = UUID.randomUUID();
/* 2754 */     assert null != this.clientConnectionId;
/*      */     
/* 2756 */     Prelogin(serverInfo.getServerName(), serverInfo.getPortNumber());
/*      */ 
/*      */     
/* 2759 */     if (2 != this.negotiatedEncryptionLevel) {
/* 2760 */       this.tdsChannel.enableSSL(serverInfo.getServerName(), serverInfo.getPortNumber(), this.clientCertificate, this.clientKey, this.clientKeyPassword);
/*      */       
/* 2762 */       this.clientKeyPassword = "";
/*      */     } 
/*      */     
/* 2765 */     this.activeConnectionProperties.remove(SQLServerDriverStringProperty.CLIENT_KEY_PASSWORD.toString());
/*      */ 
/*      */     
/* 2768 */     executeCommand(new LogonCommand());
/* 2769 */     return inetSocketAddress;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void Prelogin(String serverName, int portNumber) throws SQLServerException {
/*      */     byte messageLength, fedAuthOffset;
/*      */     int offset, bytesRead;
/* 2777 */     if (!this.authenticationString.equalsIgnoreCase(SqlAuthentication.NotSpecified.toString()) || null != this.accessTokenInByte)
/*      */     {
/* 2779 */       this.fedAuthRequiredByUser = true;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2785 */     if (this.fedAuthRequiredByUser) {
/* 2786 */       messageLength = 73;
/* 2787 */       this.requestedEncryptionLevel = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2792 */       fedAuthOffset = 5;
/*      */     } else {
/* 2794 */       messageLength = 67;
/* 2795 */       fedAuthOffset = 0;
/*      */     } 
/*      */     
/* 2798 */     byte[] preloginRequest = new byte[messageLength];
/*      */     
/* 2800 */     int preloginRequestOffset = 0;
/*      */     
/* 2802 */     byte[] bufferHeader = { 18, 1, 0, messageLength, 0, 0, 0, 0 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2810 */     System.arraycopy(bufferHeader, 0, preloginRequest, preloginRequestOffset, bufferHeader.length);
/* 2811 */     preloginRequestOffset += bufferHeader.length;
/*      */     
/* 2813 */     byte[] preloginOptionsBeforeFedAuth = { 0, 0, (byte)(16 + fedAuthOffset), 0, 6, 1, 0, (byte)(22 + fedAuthOffset), 0, 1, 5, 0, (byte)(23 + fedAuthOffset), 0, 36 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2819 */     System.arraycopy(preloginOptionsBeforeFedAuth, 0, preloginRequest, preloginRequestOffset, preloginOptionsBeforeFedAuth.length);
/*      */     
/* 2821 */     preloginRequestOffset += preloginOptionsBeforeFedAuth.length;
/*      */     
/* 2823 */     if (this.fedAuthRequiredByUser) {
/* 2824 */       byte[] preloginOptions2 = { 6, 0, 64, 0, 1 };
/* 2825 */       System.arraycopy(preloginOptions2, 0, preloginRequest, preloginRequestOffset, preloginOptions2.length);
/* 2826 */       preloginRequestOffset += preloginOptions2.length;
/*      */     } 
/*      */     
/* 2829 */     preloginRequest[preloginRequestOffset] = -1;
/* 2830 */     preloginRequestOffset++;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2840 */     byte[] preloginOptionData = { 0, 0, 0, 0, 0, 0, (null == this.clientCertificate) ? this.requestedEncryptionLevel : (byte)(this.requestedEncryptionLevel | Byte.MIN_VALUE), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2845 */     System.arraycopy(preloginOptionData, 0, preloginRequest, preloginRequestOffset, preloginOptionData.length);
/* 2846 */     preloginRequestOffset += preloginOptionData.length;
/*      */ 
/*      */ 
/*      */     
/* 2850 */     if (this.fedAuthRequiredByUser) {
/* 2851 */       preloginRequest[preloginRequestOffset] = 1;
/* 2852 */       preloginRequestOffset++;
/*      */     } 
/*      */     
/* 2855 */     byte[] preloginResponse = new byte[4096];
/* 2856 */     String preloginErrorLogString = " Prelogin error: host " + serverName + " port " + portNumber;
/*      */     
/* 2858 */     byte[] conIdByteArray = Util.asGuidByteArray(this.clientConnectionId);
/*      */ 
/*      */ 
/*      */     
/* 2862 */     if (this.fedAuthRequiredByUser) {
/* 2863 */       offset = preloginRequest.length - 36 - 1;
/*      */     } else {
/*      */       
/* 2866 */       offset = preloginRequest.length - 36;
/*      */     } 
/*      */ 
/*      */     
/* 2870 */     System.arraycopy(conIdByteArray, 0, preloginRequest, offset, conIdByteArray.length);
/* 2871 */     offset += conIdByteArray.length;
/*      */     
/* 2873 */     if (Util.isActivityTraceOn()) {
/* 2874 */       ActivityId activityId = ActivityCorrelator.getNext();
/* 2875 */       byte[] actIdByteArray = Util.asGuidByteArray(activityId.getId());
/* 2876 */       System.arraycopy(actIdByteArray, 0, preloginRequest, offset, actIdByteArray.length);
/* 2877 */       offset += actIdByteArray.length;
/* 2878 */       long seqNum = activityId.getSequence();
/* 2879 */       Util.writeInt((int)seqNum, preloginRequest, offset);
/* 2880 */       offset += 4;
/*      */       
/* 2882 */       if (connectionlogger.isLoggable(Level.FINER)) {
/* 2883 */         connectionlogger.finer(toString() + " ActivityId " + toString());
/*      */       }
/*      */     } 
/*      */     
/* 2887 */     if (connectionlogger.isLoggable(Level.FINER)) {
/* 2888 */       connectionlogger.finer(
/* 2889 */           toString() + " Requesting encryption level:" + toString());
/*      */     }
/*      */ 
/*      */     
/* 2893 */     if (this.tdsChannel.isLoggingPackets()) {
/* 2894 */       this.tdsChannel.logPacket(preloginRequest, 0, preloginRequest.length, toString() + " Prelogin request");
/*      */     }
/*      */     try {
/* 2897 */       this.tdsChannel.write(preloginRequest, 0, preloginRequest.length);
/* 2898 */       this.tdsChannel.flush();
/* 2899 */     } catch (SQLServerException e) {
/* 2900 */       connectionlogger.warning(
/* 2901 */           toString() + toString() + " Error sending prelogin request: " + preloginErrorLogString);
/* 2902 */       throw e;
/*      */     } 
/*      */     
/* 2905 */     if (Util.isActivityTraceOn()) {
/* 2906 */       ActivityCorrelator.setCurrentActivityIdSentFlag();
/*      */     }
/*      */ 
/*      */     
/* 2910 */     int responseLength = preloginResponse.length;
/* 2911 */     int responseBytesRead = 0;
/* 2912 */     boolean processedResponseHeader = false;
/* 2913 */     while (responseBytesRead < responseLength) {
/*      */ 
/*      */       
/*      */       try {
/* 2917 */         bytesRead = this.tdsChannel.read(preloginResponse, responseBytesRead, responseLength - responseBytesRead);
/* 2918 */       } catch (SQLServerException e) {
/* 2919 */         connectionlogger.warning(
/* 2920 */             toString() + toString() + " Error reading prelogin response: " + preloginErrorLogString);
/* 2921 */         throw e;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2929 */       if (-1 == bytesRead) {
/* 2930 */         if (connectionlogger.isLoggable(Level.WARNING)) {
/* 2931 */           connectionlogger.warning(toString() + toString() + " Unexpected end of prelogin response after " + preloginErrorLogString + " bytes read");
/*      */         }
/*      */         
/* 2934 */         MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_tcpipConnectionFailed"));
/*      */         
/* 2936 */         Object[] msgArgs = { getServerNameString(serverName), Integer.toString(portNumber), SQLServerException.getErrString("R_notSQLServer") };
/* 2937 */         terminate(3, form.format(msgArgs));
/*      */       } 
/*      */ 
/*      */       
/* 2941 */       assert bytesRead >= 0;
/* 2942 */       assert bytesRead <= responseLength - responseBytesRead;
/*      */       
/* 2944 */       if (this.tdsChannel.isLoggingPackets()) {
/* 2945 */         this.tdsChannel.logPacket(preloginResponse, responseBytesRead, bytesRead, toString() + " Prelogin response");
/*      */       }
/* 2947 */       responseBytesRead += bytesRead;
/*      */ 
/*      */ 
/*      */       
/* 2951 */       if (!processedResponseHeader && responseBytesRead >= 8) {
/*      */         
/* 2953 */         if (4 != preloginResponse[0]) {
/* 2954 */           if (connectionlogger.isLoggable(Level.WARNING)) {
/* 2955 */             connectionlogger.warning(toString() + toString() + " Unexpected response type:" + preloginErrorLogString);
/*      */           }
/*      */           
/* 2958 */           MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_tcpipConnectionFailed"));
/*      */           
/* 2960 */           Object[] msgArgs = { getServerNameString(serverName), Integer.toString(portNumber), SQLServerException.getErrString("R_notSQLServer") };
/* 2961 */           terminate(3, form.format(msgArgs));
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2967 */         if (1 != (0x1 & preloginResponse[1])) {
/* 2968 */           if (connectionlogger.isLoggable(Level.WARNING)) {
/* 2969 */             connectionlogger.warning(toString() + toString() + " Unexpected response status:" + preloginErrorLogString);
/*      */           }
/*      */           
/* 2972 */           MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_tcpipConnectionFailed"));
/*      */           
/* 2974 */           Object[] msgArgs = { getServerNameString(serverName), Integer.toString(portNumber), SQLServerException.getErrString("R_notSQLServer") };
/* 2975 */           terminate(3, form.format(msgArgs));
/*      */         } 
/*      */ 
/*      */         
/* 2979 */         responseLength = Util.readUnsignedShortBigEndian(preloginResponse, 2);
/* 2980 */         assert responseLength >= 0;
/*      */         
/* 2982 */         if (responseLength >= preloginResponse.length) {
/* 2983 */           if (connectionlogger.isLoggable(Level.WARNING)) {
/* 2984 */             connectionlogger.warning(toString() + toString() + " Response length:" + preloginErrorLogString + " is greater than allowed length:" + responseLength);
/*      */           }
/*      */           
/* 2987 */           MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_tcpipConnectionFailed"));
/*      */           
/* 2989 */           Object[] msgArgs = { getServerNameString(serverName), Integer.toString(portNumber), SQLServerException.getErrString("R_notSQLServer") };
/* 2990 */           terminate(3, form.format(msgArgs));
/*      */         } 
/*      */         
/* 2993 */         processedResponseHeader = true;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2999 */     boolean receivedVersionOption = false;
/* 3000 */     this.negotiatedEncryptionLevel = -1;
/*      */     
/* 3002 */     int responseIndex = 8;
/*      */     
/*      */     while (true) {
/* 3005 */       if (responseIndex >= responseLength) {
/* 3006 */         if (connectionlogger.isLoggable(Level.WARNING)) {
/* 3007 */           connectionlogger.warning(toString() + " Option token not found");
/*      */         }
/* 3009 */         throwInvalidTDS();
/*      */       } 
/* 3011 */       byte optionToken = preloginResponse[responseIndex++];
/*      */ 
/*      */       
/* 3014 */       if (-1 == optionToken) {
/*      */         break;
/*      */       }
/*      */       
/* 3018 */       if (responseIndex + 4 >= responseLength) {
/* 3019 */         if (connectionlogger.isLoggable(Level.WARNING)) {
/* 3020 */           connectionlogger.warning(toString() + " Offset/Length not found for option:" + toString());
/*      */         }
/* 3022 */         throwInvalidTDS();
/*      */       } 
/*      */       
/* 3025 */       int optionOffset = Util.readUnsignedShortBigEndian(preloginResponse, responseIndex) + 8;
/*      */       
/* 3027 */       responseIndex += 2;
/* 3028 */       assert optionOffset >= 0;
/*      */       
/* 3030 */       int optionLength = Util.readUnsignedShortBigEndian(preloginResponse, responseIndex);
/* 3031 */       responseIndex += 2;
/* 3032 */       assert optionLength >= 0;
/*      */       
/* 3034 */       if (optionOffset + optionLength > responseLength) {
/* 3035 */         if (connectionlogger.isLoggable(Level.WARNING)) {
/* 3036 */           connectionlogger.warning(toString() + " Offset:" + toString() + " and length:" + optionOffset + " exceed response length:" + optionLength);
/*      */         }
/*      */         
/* 3039 */         throwInvalidTDS();
/*      */       } 
/*      */       
/* 3042 */       switch (optionToken) {
/*      */         case 0:
/* 3044 */           if (receivedVersionOption) {
/* 3045 */             if (connectionlogger.isLoggable(Level.WARNING)) {
/* 3046 */               connectionlogger.warning(toString() + " Version option already received");
/*      */             }
/* 3048 */             throwInvalidTDS();
/*      */           } 
/*      */           
/* 3051 */           if (6 != optionLength) {
/* 3052 */             if (connectionlogger.isLoggable(Level.WARNING)) {
/* 3053 */               connectionlogger.warning(toString() + " Version option length:" + toString() + " is incorrect.  Correct value is 6.");
/*      */             }
/*      */             
/* 3056 */             throwInvalidTDS();
/*      */           } 
/*      */           
/* 3059 */           this.serverMajorVersion = preloginResponse[optionOffset];
/* 3060 */           if (this.serverMajorVersion < 9) {
/* 3061 */             if (connectionlogger.isLoggable(Level.WARNING)) {
/* 3062 */               connectionlogger.warning(toString() + " Server major version:" + toString() + " is not supported by this driver.");
/*      */             }
/*      */ 
/*      */             
/* 3066 */             MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_unsupportedServerVersion"));
/* 3067 */             Object[] msgArgs = { Integer.toString(preloginResponse[optionOffset]) };
/* 3068 */             terminate(6, form.format(msgArgs));
/*      */           } 
/*      */           
/* 3071 */           if (connectionlogger.isLoggable(Level.FINE)) {
/* 3072 */             connectionlogger
/* 3073 */               .fine(toString() + " Server returned major version:" + toString());
/*      */           }
/* 3075 */           bytesRead = 1;
/*      */           continue;
/*      */         
/*      */         case 1:
/* 3079 */           if (-1 != this.negotiatedEncryptionLevel) {
/* 3080 */             if (connectionlogger.isLoggable(Level.WARNING)) {
/* 3081 */               connectionlogger.warning(toString() + " Encryption option already received");
/*      */             }
/* 3083 */             throwInvalidTDS();
/*      */           } 
/*      */           
/* 3086 */           if (1 != optionLength) {
/* 3087 */             if (connectionlogger.isLoggable(Level.WARNING)) {
/* 3088 */               connectionlogger.warning(toString() + " Encryption option length:" + toString() + " is incorrect.  Correct value is 1.");
/*      */             }
/*      */             
/* 3091 */             throwInvalidTDS();
/*      */           } 
/*      */           
/* 3094 */           this.negotiatedEncryptionLevel = preloginResponse[optionOffset];
/*      */ 
/*      */           
/* 3097 */           if (0 != this.negotiatedEncryptionLevel && 1 != this.negotiatedEncryptionLevel && 3 != this.negotiatedEncryptionLevel && 2 != this.negotiatedEncryptionLevel) {
/*      */ 
/*      */             
/* 3100 */             if (connectionlogger.isLoggable(Level.WARNING)) {
/* 3101 */               connectionlogger.warning(toString() + " Server returned " + toString());
/*      */             }
/*      */             
/* 3104 */             throwInvalidTDS();
/*      */           } 
/*      */           
/* 3107 */           if (connectionlogger.isLoggable(Level.FINER)) {
/* 3108 */             connectionlogger.finer(toString() + " Negotiated encryption level:" + toString());
/*      */           }
/*      */ 
/*      */           
/* 3112 */           if (1 == this.requestedEncryptionLevel && 1 != this.negotiatedEncryptionLevel && 3 != this.negotiatedEncryptionLevel)
/*      */           {
/* 3114 */             terminate(5, 
/* 3115 */                 SQLServerException.getErrString("R_sslRequiredNoServerSupport"));
/*      */           }
/*      */ 
/*      */ 
/*      */           
/* 3120 */           if (2 == this.requestedEncryptionLevel && 2 != this.negotiatedEncryptionLevel) {
/*      */ 
/*      */             
/* 3123 */             if (3 == this.negotiatedEncryptionLevel) {
/* 3124 */               terminate(5, 
/* 3125 */                   SQLServerException.getErrString("R_sslRequiredByServer"));
/*      */             }
/* 3127 */             if (connectionlogger.isLoggable(Level.WARNING)) {
/* 3128 */               connectionlogger.warning(toString() + " Client requested encryption level: " + toString() + " Server returned unexpected encryption level: " + 
/* 3129 */                   TDS.getEncryptionLevel(this.requestedEncryptionLevel));
/*      */             }
/*      */ 
/*      */             
/* 3133 */             throwInvalidTDS();
/*      */           } 
/*      */           continue;
/*      */ 
/*      */         
/*      */         case 6:
/* 3139 */           if (0 != preloginResponse[optionOffset] && 1 != preloginResponse[optionOffset]) {
/* 3140 */             if (connectionlogger.isLoggable(Level.SEVERE)) {
/* 3141 */               connectionlogger.severe(toString() + " Server sent an unexpected value for FedAuthRequired PreLogin Option. Value was " + toString());
/*      */             }
/*      */ 
/*      */ 
/*      */             
/* 3146 */             MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_FedAuthRequiredPreLoginResponseInvalidValue"));
/* 3147 */             throw new SQLServerException(form.format(new Object[] { Byte.valueOf(preloginResponse[optionOffset]) }, ), null);
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 3154 */           if ((null != this.authenticationString && 
/* 3155 */             !this.authenticationString.equalsIgnoreCase(SqlAuthentication.NotSpecified.toString())) || null != this.accessTokenInByte)
/*      */           {
/* 3157 */             this.fedAuthRequiredPreLoginResponse = (preloginResponse[optionOffset] == 1);
/*      */           }
/*      */           continue;
/*      */       } 
/*      */       
/* 3162 */       if (connectionlogger.isLoggable(Level.FINER)) {
/* 3163 */         connectionlogger.finer(toString() + " Ignoring prelogin response option:" + toString());
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 3168 */     if (bytesRead == 0 || -1 == this.negotiatedEncryptionLevel) {
/* 3169 */       if (connectionlogger.isLoggable(Level.WARNING)) {
/* 3170 */         connectionlogger
/* 3171 */           .warning(toString() + " Prelogin response is missing version and/or encryption option.");
/*      */       }
/* 3173 */       throwInvalidTDS();
/*      */     } 
/*      */   }
/*      */   
/*      */   final void throwInvalidTDS() throws SQLServerException {
/* 3178 */     terminate(4, SQLServerException.getErrString("R_invalidTDS"));
/*      */   }
/*      */   
/*      */   final void throwInvalidTDSToken(String tokenName) throws SQLServerException {
/* 3182 */     MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_unexpectedToken"));
/* 3183 */     Object[] msgArgs = { tokenName };
/* 3184 */     String message = SQLServerException.getErrString("R_invalidTDS") + SQLServerException.getErrString("R_invalidTDS");
/* 3185 */     terminate(4, message);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void terminate(int driverErrorCode, String message) throws SQLServerException {
/* 3195 */     terminate(driverErrorCode, message, null);
/*      */   }
/*      */ 
/*      */   
/*      */   final void terminate(int driverErrorCode, String message, Throwable throwable) throws SQLServerException {
/* 3200 */     String state = this.state.equals(State.Opened) ? "08006" : "08001";
/*      */     
/* 3202 */     if (!this.xopenStates) {
/* 3203 */       state = SQLServerException.mapFromXopen(state);
/*      */     }
/*      */     
/* 3206 */     SQLServerException ex = new SQLServerException(this, SQLServerException.checkAndAppendClientConnId(message, this), state, 0, true);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3211 */     if (null != throwable) {
/* 3212 */       ex.initCause(throwable);
/*      */     }
/* 3214 */     ex.setDriverErrorCode(driverErrorCode);
/*      */     
/* 3216 */     notifyPooledConnection(ex);
/*      */     
/* 3218 */     close();
/*      */     
/* 3220 */     throw ex; }
/*      */   boolean executeCommand(TDSCommand newCommand) throws SQLServerException { synchronized (this.schedulerLock) { ICounter previousCounter = null; if (null != this.currentCommand) try { this.currentCommand.getCounter().resetCounter(); this.currentCommand.detach(); } catch (SQLServerException e) { if (connectionlogger.isLoggable(Level.FINE)) connectionlogger.fine("Failed to detach current command : " + e.getMessage());  } finally { previousCounter = this.currentCommand.getCounter(); this.currentCommand = null; }   newCommand.createCounter(previousCounter, this.activeConnectionProperties); boolean commandComplete = false; try { commandComplete = newCommand.execute(this.tdsChannel.getWriter(), this.tdsChannel.getReader(newCommand)); } finally { if (!commandComplete && !isSessionUnAvailable()) this.currentCommand = newCommand;  }  return commandComplete; }  }
/*      */   void resetCurrentCommand() throws SQLServerException { if (null != this.currentCommand) { this.currentCommand.detach(); this.currentCommand = null; }  } private void connectionCommand(String sql, String logContext) throws SQLServerException { final class ConnectionCommand extends UninterruptableTDSCommand {
/* 3223 */       private static final long serialVersionUID = 1L; final String sql; ConnectionCommand(String sql, String logContext) { super(logContext); this.sql = sql; } final boolean doExecute() throws SQLServerException { TDSWriter tdsWriter = startRequest((byte)1); tdsWriter.sendEnclavePackage(null, null); tdsWriter.writeString(this.sql); TDSParser.parse(startResponse(), getLogContext()); return true; } }; executeCommand(new ConnectionCommand(sql, logContext)); } private String sqlStatementToInitialize() { String s = null; if (this.nLockTimeout > -1) s = " set lock_timeout " + this.nLockTimeout;  return s; } void setCatalogName(String sDB) { if (sDB != null && sDB.length() > 0) this.sCatalog = sDB;  } String sqlStatementToSetTransactionIsolationLevel() throws SQLServerException { String sql = "set transaction isolation level "; switch (this.transactionIsolationLevel) { case 1: sql = sql + " read uncommitted "; return sql;case 2: sql = sql + " read committed "; return sql;case 4: sql = sql + " repeatable read "; return sql;case 8: sql = sql + " serializable "; return sql;case 4096: sql = sql + " snapshot "; return sql; }  MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidTransactionLevel")); Object[] msgArgs = { Integer.toString(this.transactionIsolationLevel) }; SQLServerException.makeFromDriverError(this, this, form.format(msgArgs), (String)null, false); return sql; } static String sqlStatementToSetCommit(boolean autoCommit) { return autoCommit ? "set implicit_transactions off " : "set implicit_transactions on "; } public Statement createStatement() throws SQLServerException { loggerExternal.entering(loggingClassName, "createStatement"); Statement st = createStatement(1003, 1007); loggerExternal.exiting(loggingClassName, "createStatement", st); return st; } public PreparedStatement prepareStatement(String sql) throws SQLServerException { loggerExternal.entering(loggingClassName, "prepareStatement", sql); PreparedStatement pst = prepareStatement(sql, 1003, 1007); loggerExternal.exiting(loggingClassName, "prepareStatement", pst); return pst; } public CallableStatement prepareCall(String sql) throws SQLServerException { loggerExternal.entering(loggingClassName, "prepareCall", sql); CallableStatement st = prepareCall(sql, 1003, 1007); loggerExternal.exiting(loggingClassName, "prepareCall", st); return st; } public String nativeSQL(String sql) throws SQLServerException { loggerExternal.entering(loggingClassName, "nativeSQL", sql); checkClosed(); loggerExternal.exiting(loggingClassName, "nativeSQL", sql); return sql; } public void setAutoCommit(boolean newAutoCommitMode) throws SQLServerException { if (loggerExternal.isLoggable(Level.FINER)) { loggerExternal.entering(loggingClassName, "setAutoCommit", Boolean.valueOf(newAutoCommitMode)); if (Util.isActivityTraceOn()) loggerExternal.finer(toString() + " ActivityId: " + toString());  }  String commitPendingTransaction = ""; checkClosed(); if (newAutoCommitMode == this.databaseAutoCommitMode) return;  if (newAutoCommitMode) commitPendingTransaction = "IF @@TRANCOUNT > 0 COMMIT TRAN ";  if (connectionlogger.isLoggable(Level.FINER)) connectionlogger.finer(toString() + " Autocommitmode current :" + toString() + " new: " + this.databaseAutoCommitMode);  this.rolledBackTransaction = false; connectionCommand(sqlStatementToSetCommit(newAutoCommitMode) + sqlStatementToSetCommit(newAutoCommitMode), "setAutoCommit"); this.databaseAutoCommitMode = newAutoCommitMode; loggerExternal.exiting(loggingClassName, "setAutoCommit"); } public boolean getAutoCommit() throws SQLServerException { loggerExternal.entering(loggingClassName, "getAutoCommit"); checkClosed(); boolean res = (!this.inXATransaction && this.databaseAutoCommitMode); if (loggerExternal.isLoggable(Level.FINER)) loggerExternal.exiting(loggingClassName, "getAutoCommit", Boolean.valueOf(res));  return res; } final byte[] getTransactionDescriptor() { return this.transactionDescriptor; } public void commit() throws SQLServerException { commit(false); } public void commit(boolean delayedDurability) throws SQLServerException { loggerExternal.entering(loggingClassName, "commit"); if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) loggerExternal.finer(toString() + " ActivityId: " + toString());  checkClosed(); if (!this.databaseAutoCommitMode) if (!delayedDurability) { connectionCommand("IF @@TRANCOUNT > 0 COMMIT TRAN", "Connection.commit"); } else { connectionCommand("IF @@TRANCOUNT > 0 COMMIT TRAN WITH ( DELAYED_DURABILITY =  ON )", "Connection.commit"); }   loggerExternal.exiting(loggingClassName, "commit"); } public void rollback() throws SQLServerException { loggerExternal.entering(loggingClassName, "rollback"); if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) loggerExternal.finer(toString() + " ActivityId: " + toString());  checkClosed(); if (this.databaseAutoCommitMode) { SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_cantInvokeRollback"), (String)null, true); } else { connectionCommand("IF @@TRANCOUNT > 0 ROLLBACK TRAN", "Connection.rollback"); }  loggerExternal.exiting(loggingClassName, "rollback"); } public void abort(Executor executor) throws SQLException { loggerExternal.entering(loggingClassName, "abort", executor); if (isClosed()) return;  SecurityManager secMgr = System.getSecurityManager(); if (secMgr != null) try { SQLPermission perm = new SQLPermission("callAbort"); secMgr.checkPermission(perm); } catch (SecurityException ex) { MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_permissionDenied")); Object[] msgArgs = { "callAbort" }; SQLServerException.makeFromDriverError(this, this, form.format(msgArgs), (String)null, true); }   if (null == executor) { MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidArgument")); Object[] msgArgs = { "executor" }; SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, form.format(msgArgs), (String)null, false); } else { setState(State.Closed); executor.execute(() -> clearConnectionResources()); }  loggerExternal.exiting(loggingClassName, "abort"); } public void close() throws SQLServerException { loggerExternal.entering(loggingClassName, "close"); setState(State.Closed); clearConnectionResources(); loggerExternal.exiting(loggingClassName, "close"); } private void clearConnectionResources() { if (this.sharedTimer != null) { this.sharedTimer.removeRef(); this.sharedTimer = null; }  if (null != this.tdsChannel) this.tdsChannel.close();  if (null != this.preparedStatementHandleCache) this.preparedStatementHandleCache.clear();  if (null != this.parameterMetadataCache) this.parameterMetadataCache.clear();  cleanupPreparedStatementDiscardActions(); if (Util.isActivityTraceOn()) ActivityCorrelator.cleanupActivityId();  } final void poolCloseEventNotify() throws SQLServerException { if (this.state.equals(State.Opened) && null != this.pooledConnectionParent) { if (!this.databaseAutoCommitMode && !(this.pooledConnectionParent instanceof javax.sql.XAConnection)) connectionCommand("IF @@TRANCOUNT > 0 ROLLBACK TRAN", "close connection");  notifyPooledConnection(null); if (Util.isActivityTraceOn()) ActivityCorrelator.cleanupActivityId();  if (connectionlogger.isLoggable(Level.FINER)) connectionlogger.finer(toString() + " Connection closed and returned to connection pool");  }  } public boolean isClosed() throws SQLServerException { loggerExternal.entering(loggingClassName, "isClosed"); loggerExternal.exiting(loggingClassName, "isClosed", Boolean.valueOf(isSessionUnAvailable())); return isSessionUnAvailable(); } public DatabaseMetaData getMetaData() throws SQLServerException { loggerExternal.entering(loggingClassName, "getMetaData"); checkClosed(); if (this.databaseMetaData == null) this.databaseMetaData = new SQLServerDatabaseMetaData(this);  loggerExternal.exiting(loggingClassName, "getMetaData", this.databaseMetaData); return this.databaseMetaData; } public void setReadOnly(boolean readOnly) throws SQLServerException { if (loggerExternal.isLoggable(Level.FINER)) loggerExternal.entering(loggingClassName, "setReadOnly", Boolean.valueOf(readOnly));  checkClosed(); loggerExternal.exiting(loggingClassName, "setReadOnly"); } public boolean isReadOnly() throws SQLServerException { loggerExternal.entering(loggingClassName, "isReadOnly"); checkClosed(); if (loggerExternal.isLoggable(Level.FINER)) loggerExternal.exiting(loggingClassName, "isReadOnly", Boolean.FALSE);  return false; } public void setCatalog(String catalog) throws SQLServerException { loggerExternal.entering(loggingClassName, "setCatalog", catalog); if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) loggerExternal.finer(toString() + " ActivityId: " + toString());  checkClosed(); if (catalog != null) { connectionCommand("use " + Util.escapeSQLId(catalog), "setCatalog"); this.sCatalog = catalog; }  loggerExternal.exiting(loggingClassName, "setCatalog"); } SQLServerConnection(String parentInfo) throws SQLServerException { this.schedulerLock = new Object();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3713 */     this.warningSynchronization = new Object();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5932 */     this.requestStarted = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5949 */     this.aeVersion = 0; int connectionID = nextConnectionID(); this.traceID = "ConnectionID:" + connectionID; loggingClassName += loggingClassName; if (connectionlogger.isLoggable(Level.FINE)) connectionlogger.fine(toString() + " created by (" + toString() + ")");  initResettableValues(); if (!getDisableStatementPooling() && 0 < getStatementPoolingCacheSize()) prepareCache();  }
/*      */   public String getCatalog() throws SQLServerException { loggerExternal.entering(loggingClassName, "getCatalog"); checkClosed(); loggerExternal.exiting(loggingClassName, "getCatalog", this.sCatalog); return this.sCatalog; } public void setTransactionIsolation(int level) throws SQLServerException { if (loggerExternal.isLoggable(Level.FINER)) { loggerExternal.entering(loggingClassName, "setTransactionIsolation", Integer.valueOf(level)); if (Util.isActivityTraceOn()) loggerExternal.finer(toString() + " ActivityId: " + toString());  }  checkClosed(); if (level == 0) return;  this.transactionIsolationLevel = level; String sql = sqlStatementToSetTransactionIsolationLevel(); connectionCommand(sql, "setTransactionIsolation"); loggerExternal.exiting(loggingClassName, "setTransactionIsolation"); } public int getTransactionIsolation() throws SQLServerException { loggerExternal.entering(loggingClassName, "getTransactionIsolation"); checkClosed(); if (loggerExternal.isLoggable(Level.FINER)) loggerExternal.exiting(loggingClassName, "getTransactionIsolation", Integer.valueOf(this.transactionIsolationLevel));  return this.transactionIsolationLevel; } public SQLWarning getWarnings() throws SQLServerException { loggerExternal.entering(loggingClassName, "getWarnings"); checkClosed(); loggerExternal.exiting(loggingClassName, "getWarnings", this.sqlWarnings); return this.sqlWarnings; } void addWarning(String warningString) { synchronized (this.warningSynchronization) { SQLWarning warning = new SQLWarning(warningString); if (null == this.sqlWarnings) { this.sqlWarnings = warning; } else { this.sqlWarnings.setNextWarning(warning); }  }  } public void clearWarnings() throws SQLServerException { synchronized (this.warningSynchronization) { loggerExternal.entering(loggingClassName, "clearWarnings"); checkClosed(); this.sqlWarnings = null; loggerExternal.exiting(loggingClassName, "clearWarnings"); }  } public Statement createStatement(int resultSetType, int resultSetConcurrency) throws SQLServerException { if (loggerExternal.isLoggable(Level.FINER)) loggerExternal.entering(loggingClassName, "createStatement", new Object[] { Integer.valueOf(resultSetType), Integer.valueOf(resultSetConcurrency) });  checkClosed(); SQLServerStatement st = new SQLServerStatement(this, resultSetType, resultSetConcurrency, SQLServerStatementColumnEncryptionSetting.UseConnectionSetting); if (this.requestStarted) addOpenStatement(st);  loggerExternal.exiting(loggingClassName, "createStatement", st); return st; } public PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency) throws SQLServerException { if (loggerExternal.isLoggable(Level.FINER)) loggerExternal.entering(loggingClassName, "prepareStatement", new Object[] { sql, Integer.valueOf(resultSetType), Integer.valueOf(resultSetConcurrency) });  checkClosed(); SQLServerPreparedStatement st = new SQLServerPreparedStatement(this, sql, resultSetType, resultSetConcurrency, SQLServerStatementColumnEncryptionSetting.UseConnectionSetting); if (this.requestStarted) addOpenStatement(st);  loggerExternal.exiting(loggingClassName, "prepareStatement", st); return st; } private PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency, SQLServerStatementColumnEncryptionSetting stmtColEncSetting) throws SQLServerException { if (loggerExternal.isLoggable(Level.FINER)) loggerExternal.entering(loggingClassName, "prepareStatement", new Object[] { sql, Integer.valueOf(resultSetType), Integer.valueOf(resultSetConcurrency), stmtColEncSetting });  checkClosed(); SQLServerPreparedStatement st = new SQLServerPreparedStatement(this, sql, resultSetType, resultSetConcurrency, stmtColEncSetting); if (this.requestStarted) addOpenStatement(st);  loggerExternal.exiting(loggingClassName, "prepareStatement", st); return st; } public CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency) throws SQLServerException { if (loggerExternal.isLoggable(Level.FINER)) loggerExternal.entering(loggingClassName, "prepareCall", new Object[] { sql, Integer.valueOf(resultSetType), Integer.valueOf(resultSetConcurrency) });  checkClosed(); SQLServerCallableStatement st = new SQLServerCallableStatement(this, sql, resultSetType, resultSetConcurrency, SQLServerStatementColumnEncryptionSetting.UseConnectionSetting); if (this.requestStarted) addOpenStatement(st);  loggerExternal.exiting(loggingClassName, "prepareCall", st); return st; } public void setTypeMap(Map<String, Class<?>> map) throws SQLException { loggerExternal.entering(loggingClassName, "setTypeMap", map); checkClosed(); if (map != null && map instanceof HashMap) if (map.isEmpty()) { loggerExternal.exiting(loggingClassName, "setTypeMap"); return; }   SQLServerException.throwNotSupportedException(this, (Object)null); } public Map<String, Class<?>> getTypeMap() throws SQLServerException { loggerExternal.entering(loggingClassName, "getTypeMap"); checkClosed(); Map<String, Class<?>> mp = new HashMap<>(); loggerExternal.exiting(loggingClassName, "getTypeMap", mp); return mp; } int writeAEFeatureRequest(boolean write, TDSWriter tdsWriter) throws SQLServerException { int len = 6; if (write) { tdsWriter.writeByte((byte)4); tdsWriter.writeInt(1); if (null == this.enclaveAttestationUrl || this.enclaveAttestationUrl.isEmpty()) { tdsWriter.writeByte((byte)1); } else { tdsWriter.writeByte((byte)2); }  }  return len; } int writeFedAuthFeatureRequest(boolean write, TDSWriter tdsWriter, FederatedAuthenticationFeatureExtensionData fedAuthFeatureExtensionData) throws SQLServerException { assert fedAuthFeatureExtensionData.libraryType == 2 || fedAuthFeatureExtensionData.libraryType == 1; int dataLen = 0; switch (fedAuthFeatureExtensionData.libraryType) { case 2: dataLen = 2; break;case 1: assert null != fedAuthFeatureExtensionData.accessToken; dataLen = 5 + fedAuthFeatureExtensionData.accessToken.length; break;default: assert false; break; }  int totalLen = dataLen + 5; if (write) { byte workflow; tdsWriter.writeByte((byte)2); byte options = 0; switch (fedAuthFeatureExtensionData.libraryType) { case 2: assert this.federatedAuthenticationInfoRequested; options = (byte)(options | 0x4); break;case 1: assert this.federatedAuthenticationRequested; options = (byte)(options | 0x2); break;default: assert false; break; }  options = (byte)(options | (byte)(fedAuthFeatureExtensionData.fedAuthRequiredPreLoginResponse ? 1 : 0)); tdsWriter.writeInt(dataLen); tdsWriter.writeByte(options); switch (fedAuthFeatureExtensionData.libraryType) { case 2: workflow = 0; switch (fedAuthFeatureExtensionData.authentication) { case ActiveDirectoryPassword: workflow = 1; break;case ActiveDirectoryIntegrated: workflow = 2; break;case ActiveDirectoryMSI: workflow = 3; break;case ActiveDirectoryInteractive: workflow = 3; break;case ActiveDirectoryServicePrincipal: workflow = 1; break;default: assert false; break; }  tdsWriter.writeByte(workflow); return totalLen;case 1: tdsWriter.writeInt(fedAuthFeatureExtensionData.accessToken.length); tdsWriter.writeBytes(fedAuthFeatureExtensionData.accessToken, 0, fedAuthFeatureExtensionData.accessToken.length); return totalLen; }  assert false; }  return totalLen; } int writeDataClassificationFeatureRequest(boolean write, TDSWriter tdsWriter) throws SQLServerException { int len = 6; if (write) { tdsWriter.writeByte((byte)9); tdsWriter.writeInt(1); tdsWriter.writeByte((byte)2); }  return len; } int writeUTF8SupportFeatureRequest(boolean write, TDSWriter tdsWriter) throws SQLServerException { int len = 5; if (write) { tdsWriter.writeByte((byte)10); tdsWriter.writeInt(0); }  return len; } int writeDNSCacheFeatureRequest(boolean write, TDSWriter tdsWriter) throws SQLServerException { int len = 5; if (write) { tdsWriter.writeByte((byte)11); tdsWriter.writeInt(0); }  return len; } private final class LogonCommand extends UninterruptableTDSCommand {
/*      */     private static final long serialVersionUID = 1L; LogonCommand() { super("logon"); } final boolean doExecute() throws SQLServerException { SQLServerConnection.this.logon(this); return true; } } private void logon(LogonCommand command) throws SQLServerException { SSPIAuthentication authentication = null; if (this.integratedSecurity) if (AuthenticationScheme.nativeAuthentication == this.intAuthScheme) { authentication = new AuthenticationJNI(this, this.currentConnectPlaceHolder.getServerName(), this.currentConnectPlaceHolder.getPortNumber()); } else if (AuthenticationScheme.javaKerberos == this.intAuthScheme) { if (null != this.impersonatedUserCred) { authentication = new KerbAuthentication(this, this.currentConnectPlaceHolder.getServerName(), this.currentConnectPlaceHolder.getPortNumber(), this.impersonatedUserCred, this.isUserCreatedCredential); } else { authentication = new KerbAuthentication(this, this.currentConnectPlaceHolder.getServerName(), this.currentConnectPlaceHolder.getPortNumber()); }  } else if (this.ntlmAuthentication) { if (null == this.ntlmPasswordHash) { this.ntlmPasswordHash = NTLMAuthentication.getNtlmPasswordHash(this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.PASSWORD.toString())); this.activeConnectionProperties.remove(SQLServerDriverStringProperty.PASSWORD.toString()); }  authentication = new NTLMAuthentication(this, this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.DOMAIN.toString()), this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.USER.toString()), this.ntlmPasswordHash, this.hostName); }   if (this.authenticationString.equalsIgnoreCase(SqlAuthentication.ActiveDirectoryPassword.toString()) || ((this.authenticationString.equalsIgnoreCase(SqlAuthentication.ActiveDirectoryIntegrated.toString()) || this.authenticationString.equalsIgnoreCase(SqlAuthentication.ActiveDirectoryMSI.toString()) || this.authenticationString.equalsIgnoreCase(SqlAuthentication.ActiveDirectoryServicePrincipal.toString()) || this.authenticationString.equalsIgnoreCase(SqlAuthentication.ActiveDirectoryInteractive.toString())) && this.fedAuthRequiredPreLoginResponse)) { this.federatedAuthenticationInfoRequested = true; this.fedAuthFeatureExtensionData = new FederatedAuthenticationFeatureExtensionData(2, this.authenticationString, this.fedAuthRequiredPreLoginResponse); }  if (null != this.accessTokenInByte) { this.fedAuthFeatureExtensionData = new FederatedAuthenticationFeatureExtensionData(1, this.fedAuthRequiredPreLoginResponse, this.accessTokenInByte); this.federatedAuthenticationRequested = true; }  try { sendLogon(command, authentication, this.fedAuthFeatureExtensionData); if (!this.isRoutedInCurrentAttempt) { this.originalCatalog = this.sCatalog; String sqlStmt = sqlStatementToInitialize(); if (sqlStmt != null) connectionCommand(sqlStmt, "Change Settings");  }  } finally { if (this.integratedSecurity) { if (null != authentication) { authentication.releaseClientContext(); authentication = null; }  if (null != this.impersonatedUserCred) this.impersonatedUserCred = null;  }  }  } final void processEnvChange(TDSReader tdsReader) throws SQLServerException { byte[] transactionDescriptor; int routingDataValueLength, routingProtocol, routingPortNumber, routingServerNameLength; String routingServerName, currentHostName; tdsReader.readUnsignedByte(); int envValueLength = tdsReader.readUnsignedShort(); TDSReaderMark mark = tdsReader.mark(); int envchange = tdsReader.readUnsignedByte(); switch (envchange) { case 4: try { this.tdsPacketSize = Integer.parseInt(tdsReader.readUnicodeString(tdsReader.readUnsignedByte())); } catch (NumberFormatException e) { tdsReader.throwInvalidTDS(); }  if (connectionlogger.isLoggable(Level.FINER)) connectionlogger.finer(toString() + " Network packet size is " + toString() + " bytes");  break;case 7: if (SQLCollation.tdsLength() != tdsReader.readUnsignedByte()) tdsReader.throwInvalidTDS();  try { this.databaseCollation = new SQLCollation(tdsReader); } catch (UnsupportedEncodingException e) { terminate(4, e.getMessage(), e); }  break;case 8: case 11: this.rolledBackTransaction = false; transactionDescriptor = getTransactionDescriptor(); if (transactionDescriptor.length != tdsReader.readUnsignedByte()) tdsReader.throwInvalidTDS();  tdsReader.readBytes(transactionDescriptor, 0, transactionDescriptor.length); if (connectionlogger.isLoggable(Level.FINER)) { String op; if (8 == envchange) { op = " started"; } else { op = " enlisted"; }  connectionlogger.finer(toString() + toString()); }  break;case 10: this.rolledBackTransaction = true; if (this.inXATransaction) { if (connectionlogger.isLoggable(Level.FINER)) connectionlogger.finer(toString() + " rolled back. (DTC)");  break; }  if (connectionlogger.isLoggable(Level.FINER)) connectionlogger.finer(toString() + " rolled back");  Arrays.fill(getTransactionDescriptor(), (byte)0); break;case 9: if (connectionlogger.isLoggable(Level.FINER)) connectionlogger.finer(toString() + " committed");  Arrays.fill(getTransactionDescriptor(), (byte)0); break;case 12: if (connectionlogger.isLoggable(Level.FINER)) connectionlogger.finer(toString() + " defected");  Arrays.fill(getTransactionDescriptor(), (byte)0); break;case 1: setCatalogName(tdsReader.readUnicodeString(tdsReader.readUnsignedByte())); break;case 13: setFailoverPartnerServerProvided(tdsReader.readUnicodeString(tdsReader.readUnsignedByte())); break;case 2: case 3: case 5: case 6: case 15: case 16: case 17: case 18: case 19: if (connectionlogger.isLoggable(Level.FINER)) connectionlogger.finer(toString() + " Ignored env change: " + toString());  break;case 20: routingDataValueLength = routingProtocol = routingPortNumber = routingServerNameLength = -1; routingServerName = null; try { routingDataValueLength = tdsReader.readUnsignedShort(); if (routingDataValueLength <= 5) throwInvalidTDS();  routingProtocol = tdsReader.readUnsignedByte(); if (routingProtocol != 0) throwInvalidTDS();  routingPortNumber = tdsReader.readUnsignedShort(); if (routingPortNumber <= 0 || routingPortNumber > 65535) throwInvalidTDS();  routingServerNameLength = tdsReader.readUnsignedShort(); if (routingServerNameLength <= 0 || routingServerNameLength > 1024) throwInvalidTDS();  routingServerName = tdsReader.readUnicodeString(routingServerNameLength); assert routingServerName != null; } finally { if (connectionlogger.isLoggable(Level.FINER)) connectionlogger.finer(toString() + " Received routing ENVCHANGE with the following values. routingDataValueLength:" + toString() + " protocol:" + routingDataValueLength + " portNumber:" + routingProtocol + " serverNameLength:" + routingPortNumber + " serverName:" + routingServerNameLength);  }  currentHostName = this.activeConnectionProperties.getProperty("hostNameInCertificate"); if (null != currentHostName && currentHostName.startsWith("*") && null != routingServerName && routingServerName.indexOf('.') != -1) { char[] currentHostNameCharArray = currentHostName.toCharArray(); char[] routingServerNameCharArray = routingServerName.toCharArray(); boolean hostNameNeedsUpdate = true; for (int i = currentHostName.length() - 1, j = routingServerName.length() - 1; i > 0 && j > 0; i--, j--) { if (routingServerNameCharArray[j] != currentHostNameCharArray[i]) { hostNameNeedsUpdate = false; break; }  }  if (hostNameNeedsUpdate) { String newHostName = "*" + routingServerName.substring(routingServerName.indexOf('.')); this.activeConnectionProperties.setProperty("hostNameInCertificate", newHostName); if (connectionlogger.isLoggable(Level.FINER)) connectionlogger.finer(toString() + "Using new host to validate the SSL certificate");  }  }  this.isRoutedInCurrentAttempt = true; this.routingInfo = new ServerPortPlaceHolder(routingServerName, routingPortNumber, null, this.integratedSecurity); break;default: if (connectionlogger.isLoggable(Level.WARNING)) connectionlogger.warning(toString() + " Unknown environment change: " + toString());  throwInvalidTDS(); break; }  tdsReader.reset(mark); tdsReader.readBytes(new byte[envValueLength], 0, envValueLength); } final void processFedAuthInfo(TDSReader tdsReader, TDSTokenHandler tdsTokenHandler) throws SQLServerException { SqlFedAuthInfo sqlFedAuthInfo = new SqlFedAuthInfo(); tdsReader.readUnsignedByte(); int tokenLen = tdsReader.readInt(); if (connectionlogger.isLoggable(Level.FINER)) connectionlogger.fine(toString() + " FEDAUTHINFO token stream length = " + toString());  if (tokenLen < 4) { if (connectionlogger.isLoggable(Level.SEVERE)) connectionlogger.severe(toString() + "FEDAUTHINFO token stream length too short for CountOfInfoIDs.");  throw new SQLServerException(SQLServerException.getErrString("R_FedAuthInfoLengthTooShortForCountOfInfoIds"), null); }  int optionsCount = tdsReader.readInt(); tokenLen -= 4; if (connectionlogger.isLoggable(Level.FINER)) connectionlogger.fine(toString() + " CountOfInfoIDs = " + toString());  if (tokenLen > 0) { byte[] tokenData = new byte[tokenLen]; tdsReader.readBytes(tokenData, 0, tokenLen); if (connectionlogger.isLoggable(Level.FINER)) connectionlogger.fine(toString() + " Read rest of FEDAUTHINFO token stream: " + toString());  int optionSize = 9; int totalOptionsSize = optionsCount * 9; for (int i = 0; i < optionsCount; i++) { int currentOptionOffset = i * 9; byte id = tokenData[currentOptionOffset]; byte[] buffer = new byte[4]; buffer[3] = tokenData[currentOptionOffset + 1]; buffer[2] = tokenData[currentOptionOffset + 2]; buffer[1] = tokenData[currentOptionOffset + 3]; buffer[0] = tokenData[currentOptionOffset + 4]; ByteBuffer wrapped = ByteBuffer.wrap(buffer); int dataLen = wrapped.getInt(); buffer = new byte[4]; buffer[3] = tokenData[currentOptionOffset + 5]; buffer[2] = tokenData[currentOptionOffset + 6]; buffer[1] = tokenData[currentOptionOffset + 7]; buffer[0] = tokenData[currentOptionOffset + 8]; wrapped = ByteBuffer.wrap(buffer); int dataOffset = wrapped.getInt(); if (connectionlogger.isLoggable(Level.FINER)) connectionlogger.fine(toString() + " FedAuthInfoOpt: ID=" + toString() + ", DataLen=" + id + ", Offset=" + dataLen);  dataOffset -= 4; if (dataOffset < totalOptionsSize || dataOffset >= tokenLen) { if (connectionlogger.isLoggable(Level.SEVERE)) connectionlogger.severe(toString() + "FedAuthInfoDataOffset points to an invalid location.");  MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_FedAuthInfoInvalidOffset")); throw new SQLServerException(form.format(new Object[] { Integer.valueOf(dataOffset) }, ), null); }  String data = null; try { byte[] dataArray = new byte[dataLen]; System.arraycopy(tokenData, dataOffset, dataArray, 0, dataLen); data = new String(dataArray, StandardCharsets.UTF_16LE); } catch (Exception e) { connectionlogger.severe(toString() + "Failed to read FedAuthInfoData."); throw new SQLServerException(SQLServerException.getErrString("R_FedAuthInfoFailedToReadData"), e); }  if (connectionlogger.isLoggable(Level.FINER)) connectionlogger.fine(toString() + " FedAuthInfoData: " + toString());  switch (id) { case 2: sqlFedAuthInfo.spn = data; break;case 1: sqlFedAuthInfo.stsurl = data; break;default: if (connectionlogger.isLoggable(Level.FINER)) connectionlogger.fine(toString() + " Ignoring unknown federated authentication info option: " + toString());  break; }  }  } else { if (connectionlogger.isLoggable(Level.SEVERE)) connectionlogger.severe(toString() + "FEDAUTHINFO token stream is not long enough to contain the data it claims to.");  MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_FedAuthInfoLengthTooShortForData")); throw new SQLServerException(form.format(new Object[] { Integer.valueOf(tokenLen) }, ), null); }  if (null == sqlFedAuthInfo.spn || null == sqlFedAuthInfo.stsurl || sqlFedAuthInfo.spn.trim().isEmpty() || sqlFedAuthInfo.stsurl.trim().isEmpty()) { if (connectionlogger.isLoggable(Level.SEVERE)) connectionlogger.severe(toString() + "FEDAUTHINFO token stream does not contain both STSURL and SPN.");  throw new SQLServerException(SQLServerException.getErrString("R_FedAuthInfoDoesNotContainStsurlAndSpn"), null); }  onFedAuthInfo(sqlFedAuthInfo, tdsTokenHandler); this.aadPrincipalSecret = ""; this.activeConnectionProperties.remove(SQLServerDriverStringProperty.AAD_SECURE_PRINCIPAL_SECRET.toString()); } final class FedAuthTokenCommand extends UninterruptableTDSCommand {
/* 5952 */     private static final long serialVersionUID = 1L; TDSTokenHandler tdsTokenHandler = null; SqlFedAuthToken sqlFedAuthToken = null; FedAuthTokenCommand(SqlFedAuthToken sqlFedAuthToken, TDSTokenHandler tdsTokenHandler) { super("FedAuth"); this.tdsTokenHandler = tdsTokenHandler; this.sqlFedAuthToken = sqlFedAuthToken; } final boolean doExecute() throws SQLServerException { SQLServerConnection.this.sendFedAuthToken(this, this.sqlFedAuthToken, this.tdsTokenHandler); return true; } } void onFedAuthInfo(SqlFedAuthInfo fedAuthInfo, TDSTokenHandler tdsTokenHandler) throws SQLServerException { assert this.authenticationString.equalsIgnoreCase(SqlAuthentication.ActiveDirectoryIntegrated.toString()) || this.authenticationString.equalsIgnoreCase(SqlAuthentication.ActiveDirectoryMSI.toString()) || (this.authenticationString.equalsIgnoreCase(SqlAuthentication.ActiveDirectoryInteractive.toString()) && this.fedAuthRequiredPreLoginResponse); assert null != fedAuthInfo; this.attemptRefreshTokenLocked = true; this.fedAuthToken = getFedAuthToken(fedAuthInfo); this.attemptRefreshTokenLocked = false; assert null != this.fedAuthToken; TDSCommand fedAuthCommand = new FedAuthTokenCommand(this.fedAuthToken, tdsTokenHandler); fedAuthCommand.execute(this.tdsChannel.getWriter(), this.tdsChannel.getReader(fedAuthCommand)); } private SqlFedAuthToken getFedAuthToken(SqlFedAuthInfo fedAuthInfo) throws SQLServerException { SqlFedAuthToken fedAuthToken = null; assert null != fedAuthInfo; String user = this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.USER.toString()); int sleepInterval = 100; while (true) { if (this.authenticationString.equalsIgnoreCase(SqlAuthentication.ActiveDirectoryPassword.toString())) { if (!msalContextExists()) { MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_MSALMissing")); throw new SQLServerException(form.format(new Object[] { this.authenticationString }, ), null, 0, null); }  fedAuthToken = SQLServerMSAL4JUtils.getSqlFedAuthToken(fedAuthInfo, user, this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.PASSWORD.toString()), this.authenticationString); break; }  if (this.authenticationString.equalsIgnoreCase(SqlAuthentication.ActiveDirectoryMSI.toString())) { fedAuthToken = SQLServerSecurityUtility.getMSIAuthToken(fedAuthInfo.spn, this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.MSI_CLIENT_ID.toString())); break; }  if (this.authenticationString.equalsIgnoreCase(SqlAuthentication.ActiveDirectoryServicePrincipal.toString())) { fedAuthToken = SQLServerMSAL4JUtils.getSqlFedAuthTokenPrincipal(fedAuthInfo, this.aadPrincipalID, this.aadPrincipalSecret, this.authenticationString); break; }  if (this.authenticationString.equalsIgnoreCase(SqlAuthentication.ActiveDirectoryIntegrated.toString())) { if (System.getProperty("os.name").toLowerCase(Locale.ENGLISH).startsWith("windows") && AuthenticationJNI.isDllLoaded()) { try { FedAuthDllInfo dllInfo = AuthenticationJNI.getAccessTokenForWindowsIntegrated(fedAuthInfo.stsurl, fedAuthInfo.spn, this.clientConnectionId.toString(), "7f98cb04-cd1e-40df-9140-3bf7e2cea4db", 0L); assert null != dllInfo.accessTokenBytes; byte[] accessTokenFromDLL = dllInfo.accessTokenBytes; String accessToken = new String(accessTokenFromDLL, StandardCharsets.UTF_16LE); fedAuthToken = new SqlFedAuthToken(accessToken, dllInfo.expiresIn); } catch (DLLException adalException) { int errorCategory = adalException.GetCategory(); if (-1 == errorCategory) { MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_UnableLoadADALSqlDll")); Object[] msgArgs = { Integer.toHexString(adalException.GetState()) }; throw new SQLServerException(form.format(msgArgs), null); }  int millisecondsRemaining = timerRemaining(this.timerExpire); if (2 != errorCategory || timerHasExpired(this.timerExpire) || sleepInterval >= millisecondsRemaining) { String errorStatus = Integer.toHexString(adalException.GetStatus()); if (connectionlogger.isLoggable(Level.FINER)) connectionlogger.fine(toString() + " SQLServerConnection.getFedAuthToken.AdalException category:" + toString() + " error: " + errorCategory);  MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_ADALAuthenticationMiddleErrorMessage")); String errorCode = Integer.toHexString(adalException.GetStatus()).toUpperCase(); Object[] msgArgs1 = { errorCode, Integer.valueOf(adalException.GetState()) }; SQLServerException middleException = new SQLServerException(form.format(msgArgs1), adalException); form = new MessageFormat(SQLServerException.getErrString("R_MSALExecution")); Object[] msgArgs = { user, this.authenticationString }; throw new SQLServerException(form.format(msgArgs), null, 0, middleException); }  if (connectionlogger.isLoggable(Level.FINER)) { connectionlogger.fine(toString() + " SQLServerConnection.getFedAuthToken sleeping: " + toString() + " milliseconds."); connectionlogger.fine(toString() + " SQLServerConnection.getFedAuthToken remaining: " + toString() + " milliseconds."); }  try { Thread.sleep(sleepInterval); } catch (InterruptedException e1) { Thread.currentThread().interrupt(); }  sleepInterval *= 2; }  break; }  if (!msalContextExists()) { MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_DLLandMSALMissing")); Object[] msgArgs = { SQLServerDriver.AUTH_DLL_NAME, this.authenticationString }; throw new SQLServerException(form.format(msgArgs), null, 0, null); }  fedAuthToken = SQLServerMSAL4JUtils.getSqlFedAuthTokenIntegrated(fedAuthInfo, this.authenticationString); break; }  if (this.authenticationString.equalsIgnoreCase(SqlAuthentication.ActiveDirectoryInteractive.toString())) { if (!msalContextExists()) { MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_MSALMissing")); throw new SQLServerException(form.format(new Object[] { this.authenticationString }, ), null, 0, null); }  fedAuthToken = SQLServerMSAL4JUtils.getSqlFedAuthTokenInteractive(fedAuthInfo, user, this.authenticationString); break; }  }  return fedAuthToken; } private boolean msalContextExists() { try { Class.forName("com.microsoft.aad.msal4j.PublicClientApplication"); } catch (ClassNotFoundException e) { return false; }  return true; } protected void beginRequestInternal() throws SQLException { loggerExternal.entering(loggingClassName, "beginRequest", this);
/* 5953 */     synchronized (this) {
/* 5954 */       if (!this.requestStarted) {
/* 5955 */         this.originalDatabaseAutoCommitMode = this.databaseAutoCommitMode;
/* 5956 */         this.originalTransactionIsolationLevel = this.transactionIsolationLevel;
/* 5957 */         this.originalNetworkTimeout = getNetworkTimeout();
/* 5958 */         this.originalHoldability = this.holdability;
/* 5959 */         this.originalSendTimeAsDatetime = this.sendTimeAsDatetime;
/* 5960 */         this.originalStatementPoolingCacheSize = this.statementPoolingCacheSize;
/* 5961 */         this.originalDisableStatementPooling = this.disableStatementPooling;
/* 5962 */         this.originalServerPreparedStatementDiscardThreshold = getServerPreparedStatementDiscardThreshold();
/* 5963 */         this.originalEnablePrepareOnFirstPreparedStatementCall = Boolean.valueOf(getEnablePrepareOnFirstPreparedStatementCall());
/* 5964 */         this.originalSCatalog = this.sCatalog;
/* 5965 */         this.originalUseBulkCopyForBatchInsert = getUseBulkCopyForBatchInsert();
/* 5966 */         this.originalSqlWarnings = this.sqlWarnings;
/* 5967 */         this.openStatements = new LinkedList<>();
/* 5968 */         this.originalUseFmtOnly = this.useFmtOnly;
/* 5969 */         this.originalDelayLoadingLobs = this.delayLoadingLobs;
/* 5970 */         this.requestStarted = true;
/*      */       } 
/*      */     } 
/* 5973 */     loggerExternal.exiting(loggingClassName, "beginRequest", this); } private void sendFedAuthToken(FedAuthTokenCommand fedAuthCommand, SqlFedAuthToken fedAuthToken, TDSTokenHandler tdsTokenHandler) throws SQLServerException { assert null != fedAuthToken; assert null != fedAuthToken.accessToken; if (connectionlogger.isLoggable(Level.FINER)) connectionlogger.fine(toString() + " Sending federated authentication token.");  TDSWriter tdsWriter = fedAuthCommand.startRequest((byte)8); byte[] accessToken = fedAuthToken.accessToken.getBytes(StandardCharsets.UTF_16LE); tdsWriter.writeInt(accessToken.length + 4); tdsWriter.writeInt(accessToken.length); tdsWriter.writeBytes(accessToken, 0, accessToken.length); TDSReader tdsReader = fedAuthCommand.startResponse(); this.federatedAuthenticationRequested = true; TDSParser.parse(tdsReader, tdsTokenHandler); } final void processFeatureExtAck(TDSReader tdsReader) throws SQLServerException { byte featureId; tdsReader.readUnsignedByte(); do { featureId = (byte)tdsReader.readUnsignedByte(); if (featureId == -1) continue;  int dataLen = tdsReader.readInt(); byte[] data = new byte[dataLen]; if (dataLen > 0) tdsReader.readBytes(data, 0, dataLen);  onFeatureExtAck(featureId, data); } while (featureId != -1); } private void onFeatureExtAck(byte featureId, byte[] data) throws SQLServerException { MessageFormat form; byte enabled; Object[] msgArgs; if (null != this.routingInfo && 11 != featureId) return;  switch (featureId) { case 2: if (connectionlogger.isLoggable(Level.FINER)) connectionlogger.fine(toString() + " Received feature extension acknowledgement for federated authentication.");  if (!this.federatedAuthenticationRequested) { if (connectionlogger.isLoggable(Level.SEVERE)) connectionlogger.severe(toString() + " Did not request federated authentication.");  MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_UnrequestedFeatureAckReceived")); Object[] arrayOfObject = { Byte.valueOf(featureId) }; throw new SQLServerException(messageFormat.format(arrayOfObject), null); }  assert null != this.fedAuthFeatureExtensionData; switch (this.fedAuthFeatureExtensionData.libraryType) { case 1: case 2: if (0 != data.length) { if (connectionlogger.isLoggable(Level.SEVERE)) connectionlogger.severe(toString() + " Federated authentication feature extension ack for ADAL and Security Token includes extra data.");  throw new SQLServerException(SQLServerException.getErrString("R_FedAuthFeatureAckContainsExtraData"), null); }  return; }  assert false; if (connectionlogger.isLoggable(Level.SEVERE)) connectionlogger.severe(toString() + " Attempting to use unknown federated authentication library.");  form = new MessageFormat(SQLServerException.getErrString("R_FedAuthFeatureAckUnknownLibraryType")); msgArgs = new Object[] { Integer.valueOf(this.fedAuthFeatureExtensionData.libraryType) }; throw new SQLServerException(form.format(msgArgs), null);case 4: if (connectionlogger.isLoggable(Level.FINER)) connectionlogger.fine(toString() + " Received feature extension acknowledgement for AE.");  if (1 > data.length) throw new SQLServerException(SQLServerException.getErrString("R_InvalidAEVersionNumber"), null);  this.aeVersion = data[0]; if (0 == this.aeVersion || this.aeVersion > 2) throw new SQLServerException(SQLServerException.getErrString("R_InvalidAEVersionNumber"), null);  this.serverColumnEncryptionVersion = ColumnEncryptionVersion.AE_v1; if (null != this.enclaveAttestationUrl) { if (this.aeVersion < 2) throw new SQLServerException(SQLServerException.getErrString("R_enclaveNotSupported"), null);  this.serverColumnEncryptionVersion = ColumnEncryptionVersion.AE_v2; this.enclaveType = new String(data, 2, data.length - 2, StandardCharsets.UTF_16LE); if (!EnclaveType.isValidEnclaveType(this.enclaveType)) { form = new MessageFormat(SQLServerException.getErrString("R_enclaveTypeInvalid")); msgArgs = new Object[] { this.enclaveType }; throw new SQLServerException(null, form.format(msgArgs), null, 0, false); }  }  return;case 9: if (connectionlogger.isLoggable(Level.FINER)) connectionlogger.fine(toString() + " Received feature extension acknowledgement for Data Classification.");  if (2 != data.length) throw new SQLServerException(SQLServerException.getErrString("R_UnknownDataClsTokenNumber"), null);  this.serverSupportedDataClassificationVersion = data[0]; if (0 == this.serverSupportedDataClassificationVersion || this.serverSupportedDataClassificationVersion > 2) throw new SQLServerException(SQLServerException.getErrString("R_InvalidDataClsVersionNumber"), null);  enabled = data[1]; this.serverSupportsDataClassification = (enabled != 0); return;case 10: if (connectionlogger.isLoggable(Level.FINER)) connectionlogger.fine(toString() + " Received feature extension acknowledgement for UTF8 support.");  if (1 > data.length) throw new SQLServerException(SQLServerException.getErrString("R_unknownUTF8SupportValue"), null);  return;case 11: if (connectionlogger.isLoggable(Level.FINER)) connectionlogger.fine(toString() + " Received feature extension acknowledgement for Azure SQL DNS Caching.");  if (1 > data.length) throw new SQLServerException(SQLServerException.getErrString("R_unknownAzureSQLDNSCachingValue"), null);  if (1 == data[0]) { this.serverSupportsDNSCaching = true; if (null == dnsCache) dnsCache = new ConcurrentHashMap<>();  } else { this.serverSupportsDNSCaching = false; if (null != dnsCache) dnsCache.remove(this.currentConnectPlaceHolder.getServerName());  }  return; }  throw new SQLServerException(SQLServerException.getErrString("R_UnknownFeatureAck"), null); } private void executeDTCCommand(int requestType, byte[] payload, String logContext) throws SQLServerException { final class DTCCommand extends UninterruptableTDSCommand {
/*      */       private static final long serialVersionUID = 1L; private final int requestType; private final byte[] payload; DTCCommand(int requestType, byte[] payload, String logContext) { super(logContext); this.requestType = requestType; this.payload = payload; } final boolean doExecute() throws SQLServerException { TDSWriter tdsWriter = startRequest((byte)14); tdsWriter.sendEnclavePackage(null, null); tdsWriter.writeShort((short)this.requestType); if (null == this.payload) { tdsWriter.writeShort((short)0); } else { assert this.payload.length <= 32767; tdsWriter.writeShort((short)this.payload.length); tdsWriter.writeBytes(this.payload); }  TDSParser.parse(startResponse(), getLogContext()); return true; } }; executeCommand(new DTCCommand(requestType, payload, logContext)); } final void JTAUnenlistConnection() throws SQLServerException { executeDTCCommand(1, null, "MS_DTC delist connection"); this.inXATransaction = false; } final void JTAEnlistConnection(byte[] cookie) throws SQLServerException { executeDTCCommand(1, cookie, "MS_DTC enlist connection"); connectionCommand(sqlStatementToSetTransactionIsolationLevel(), "JTAEnlistConnection"); this.inXATransaction = true; } private byte[] toUCS16(String s) { if (s == null) return new byte[0];  int l = s.length(); byte[] data = new byte[l * 2]; int offset = 0; for (int i = 0; i < l; i++) { int c = s.charAt(i); byte b1 = (byte)(c & 0xFF); data[offset++] = b1; data[offset++] = (byte)(c >> 8 & 0xFF); }  return data; } private byte[] encryptPassword(String pwd) { if (pwd == null) pwd = "";  int len = pwd.length(); byte[] data = new byte[len * 2]; for (int i1 = 0; i1 < len; i1++) { int j1 = pwd.charAt(i1) ^ 0x5A5A; j1 = (j1 & 0xF) << 4 | (j1 & 0xF0) >> 4 | (j1 & 0xF00) << 4 | (j1 & 0xF000) >> 4; byte b1 = (byte)((j1 & 0xFF00) >> 8); data[i1 * 2 + 1] = b1; byte b2 = (byte)(j1 & 0xFF); data[i1 * 2 + 0] = b2; }  return data; } private void sendLogon(LogonCommand logonCommand, SSPIAuthentication authentication, FederatedAuthenticationFeatureExtensionData fedAuthFeatureExtensionData) throws SQLServerException { TDSReader tdsReader; final class LogonProcessor extends TDSTokenHandler {
/*      */       private final SSPIAuthentication auth; private byte[] secBlobOut = null; StreamLoginAck loginAckToken; LogonProcessor(SSPIAuthentication auth) { super("logon"); this.auth = auth; this.loginAckToken = null; } boolean onSSPI(TDSReader tdsReader) throws SQLServerException { StreamSSPI ack = new StreamSSPI(); ack.setFromTDS(tdsReader); boolean[] done = { false }; this.secBlobOut = this.auth.generateClientContext(ack.sspiBlob, done); return true; } boolean onLoginAck(TDSReader tdsReader) throws SQLServerException { this.loginAckToken = new StreamLoginAck(); this.loginAckToken.setFromTDS(tdsReader); SQLServerConnection.this.sqlServerVersion = this.loginAckToken.sSQLServerVersion; SQLServerConnection.this.tdsVersion = this.loginAckToken.tdsVersion; return true; } final boolean complete(SQLServerConnection.LogonCommand logonCommand, TDSReader tdsReader) throws SQLServerException { if (null != this.loginAckToken) return true;  if (null != this.secBlobOut && 0 != this.secBlobOut.length) { logonCommand.startRequest((byte)17).writeBytes(this.secBlobOut, 0, this.secBlobOut.length); return false; }  logonCommand.startRequest((byte)17); logonCommand.onRequestComplete(); SQLServerConnection.this.tdsChannel.numMsgsSent++; TDSParser.parse(tdsReader, this); return true; } }; assert !this.integratedSecurity || !this.fedAuthRequiredPreLoginResponse; assert !this.integratedSecurity || (!this.federatedAuthenticationInfoRequested && !this.federatedAuthenticationRequested); assert null == fedAuthFeatureExtensionData || this.federatedAuthenticationInfoRequested || this.federatedAuthenticationRequested; assert null != fedAuthFeatureExtensionData || (!this.federatedAuthenticationInfoRequested && !this.federatedAuthenticationRequested); String sUser = this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.USER.toString()); String sPwd = this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.PASSWORD.toString()); String appName = this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.APPLICATION_NAME.toString()); String interfaceLibName = "Microsoft JDBC Driver 9.2"; String databaseName = this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.DATABASE_NAME.toString()); String serverName = (null != this.currentConnectPlaceHolder) ? this.currentConnectPlaceHolder.getServerName() : this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.SERVER_NAME.toString()); if (null != serverName && serverName.length() > 128) serverName = serverName.substring(0, 128);  byte[] secBlob = new byte[0]; boolean[] done = { false }; if (null != authentication) { secBlob = authentication.generateClientContext(secBlob, done); sUser = null; sPwd = null; }  byte[] hostnameBytes = toUCS16(this.hostName); byte[] userBytes = toUCS16(sUser); byte[] passwordBytes = encryptPassword(sPwd); int passwordLen = (null != passwordBytes) ? passwordBytes.length : 0; byte[] appNameBytes = toUCS16(appName); byte[] serverNameBytes = toUCS16(serverName); byte[] interfaceLibNameBytes = toUCS16(interfaceLibName); byte[] interfaceLibVersionBytes = { 0, 1, 2, 9 }; byte[] databaseNameBytes = toUCS16(databaseName); byte[] netAddress = new byte[6]; int dataLen = 0; if (this.serverMajorVersion >= 11) { this.tdsVersion = 1946157060; } else if (this.serverMajorVersion >= 10) { this.tdsVersion = 1930100739; } else if (this.serverMajorVersion >= 9) { this.tdsVersion = 1913192450; } else { assert false : "prelogin did not disconnect for the old version: " + this.serverMajorVersion; }  int tdsLoginRequestBaseLength = 94; TDSWriter tdsWriter = logonCommand.startRequest((byte)16); int len = 94 + hostnameBytes.length + appNameBytes.length + serverNameBytes.length + interfaceLibNameBytes.length + databaseNameBytes.length + ((secBlob != null) ? secBlob.length : 0) + 4; if (!this.integratedSecurity && !this.federatedAuthenticationInfoRequested && !this.federatedAuthenticationRequested && null == this.clientCertificate) len = len + passwordLen + userBytes.length;  int aeOffset = len; len += writeAEFeatureRequest(false, tdsWriter); if (this.federatedAuthenticationInfoRequested || this.federatedAuthenticationRequested) len += writeFedAuthFeatureRequest(false, tdsWriter, fedAuthFeatureExtensionData);  len += writeDataClassificationFeatureRequest(false, tdsWriter); len += writeUTF8SupportFeatureRequest(false, tdsWriter); len += writeDNSCacheFeatureRequest(false, tdsWriter); len++; tdsWriter.writeInt(len); tdsWriter.writeInt(this.tdsVersion); tdsWriter.writeInt(this.requestedPacketSize); tdsWriter.writeBytes(interfaceLibVersionBytes); tdsWriter.writeInt(0); tdsWriter.writeInt(0); tdsWriter.writeByte((byte)-32); tdsWriter.writeByte((byte)(0x3 | (this.integratedSecurity ? Byte.MIN_VALUE : 0))); tdsWriter.writeByte((byte)(0x0 | ((this.applicationIntent != null && this.applicationIntent.equals(ApplicationIntent.READ_ONLY)) ? 32 : 0))); byte colEncSetting = 16; tdsWriter.writeByte((byte)(0x0 | colEncSetting | ((this.serverMajorVersion >= 10) ? 8 : 0))); tdsWriter.writeInt(0); tdsWriter.writeInt(0); tdsWriter.writeShort((short)94); tdsWriter.writeShort((short)((this.hostName != null && !this.hostName.isEmpty()) ? this.hostName.length() : 0)); dataLen += hostnameBytes.length; if (this.ntlmAuthentication) { tdsWriter.writeShort((short)(94 + dataLen)); tdsWriter.writeShort((short)0); tdsWriter.writeShort((short)(94 + dataLen)); tdsWriter.writeShort((short)0); } else if (!this.integratedSecurity && !this.federatedAuthenticationInfoRequested && !this.federatedAuthenticationRequested && null == this.clientCertificate) { tdsWriter.writeShort((short)(94 + dataLen)); tdsWriter.writeShort((short)((sUser == null) ? 0 : sUser.length())); dataLen += userBytes.length; tdsWriter.writeShort((short)(94 + dataLen)); tdsWriter.writeShort((short)((sPwd == null) ? 0 : sPwd.length())); dataLen += passwordLen; } else { tdsWriter.writeShort((short)0); tdsWriter.writeShort((short)0); tdsWriter.writeShort((short)0); tdsWriter.writeShort((short)0); }  tdsWriter.writeShort((short)(94 + dataLen)); tdsWriter.writeShort((short)((appName == null) ? 0 : appName.length())); dataLen += appNameBytes.length; tdsWriter.writeShort((short)(94 + dataLen)); tdsWriter.writeShort((short)((serverName == null) ? 0 : serverName.length())); dataLen += serverNameBytes.length; tdsWriter.writeShort((short)(94 + dataLen)); tdsWriter.writeShort((short)4); dataLen += 4; assert null != interfaceLibName; tdsWriter.writeShort((short)(94 + dataLen)); tdsWriter.writeShort((short)interfaceLibName.length()); dataLen += interfaceLibNameBytes.length; tdsWriter.writeShort((short)0); tdsWriter.writeShort((short)0); tdsWriter.writeShort((short)(94 + dataLen)); tdsWriter.writeShort((short)((databaseName == null) ? 0 : databaseName.length())); dataLen += databaseNameBytes.length; tdsWriter.writeBytes(netAddress); int uShortMax = 65535; if (!this.integratedSecurity) { tdsWriter.writeShort((short)0); tdsWriter.writeShort((short)0); } else { tdsWriter.writeShort((short)(94 + dataLen)); if (65535 <= secBlob.length) { tdsWriter.writeShort((short)-1); } else { tdsWriter.writeShort((short)secBlob.length); }  }  tdsWriter.writeShort((short)0); tdsWriter.writeShort((short)0); if (this.tdsVersion >= 1913192450) { tdsWriter.writeShort((short)0); tdsWriter.writeShort((short)0); if (null != secBlob && 65535 <= secBlob.length) { tdsWriter.writeInt(secBlob.length); } else { tdsWriter.writeInt(0); }  }  tdsWriter.writeBytes(hostnameBytes); tdsWriter.setDataLoggable(false); if (!this.integratedSecurity && !this.federatedAuthenticationInfoRequested && !this.federatedAuthenticationRequested && null == this.clientCertificate) { tdsWriter.writeBytes(userBytes); tdsWriter.writeBytes(passwordBytes); }  tdsWriter.setDataLoggable(true); tdsWriter.writeBytes(appNameBytes); tdsWriter.writeBytes(serverNameBytes); tdsWriter.writeInt(aeOffset); tdsWriter.writeBytes(interfaceLibNameBytes); tdsWriter.writeBytes(databaseNameBytes); tdsWriter.setDataLoggable(false); if (this.integratedSecurity) tdsWriter.writeBytes(secBlob, 0, secBlob.length);  writeAEFeatureRequest(true, tdsWriter); if (this.federatedAuthenticationInfoRequested || this.federatedAuthenticationRequested) writeFedAuthFeatureRequest(true, tdsWriter, fedAuthFeatureExtensionData);  writeDataClassificationFeatureRequest(true, tdsWriter); writeUTF8SupportFeatureRequest(true, tdsWriter); writeDNSCacheFeatureRequest(true, tdsWriter); tdsWriter.writeByte((byte)-1); tdsWriter.setDataLoggable(true); LogonProcessor logonProcessor = new LogonProcessor(authentication); do { tdsReader = logonCommand.startResponse(); TDSParser.parse(tdsReader, logonProcessor); } while (!logonProcessor.complete(logonCommand, tdsReader)); } private void checkValidHoldability(int holdability) throws SQLServerException { if (holdability != 1 && holdability != 2) { MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidHoldability")); SQLServerException.makeFromDriverError(this, this, form.format(new Object[] { Integer.valueOf(holdability) }, ), (String)null, true); }  } private void checkMatchesCurrentHoldability(int resultSetHoldability) throws SQLServerException { if (resultSetHoldability != this.holdability) SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_sqlServerHoldability"), (String)null, false);  } public Statement createStatement(int nType, int nConcur, int resultSetHoldability) throws SQLServerException { loggerExternal.entering(loggingClassName, "createStatement", new Object[] { Integer.valueOf(nType), Integer.valueOf(nConcur), Integer.valueOf(resultSetHoldability) }); Statement st = createStatement(nType, nConcur, resultSetHoldability, SQLServerStatementColumnEncryptionSetting.UseConnectionSetting); loggerExternal.exiting(loggingClassName, "createStatement", st); return st; } public Statement createStatement(int nType, int nConcur, int resultSetHoldability, SQLServerStatementColumnEncryptionSetting stmtColEncSetting) throws SQLServerException { loggerExternal.entering(loggingClassName, "createStatement", new Object[] { Integer.valueOf(nType), Integer.valueOf(nConcur), Integer.valueOf(resultSetHoldability), stmtColEncSetting }); checkClosed(); checkValidHoldability(resultSetHoldability); checkMatchesCurrentHoldability(resultSetHoldability); Statement st = new SQLServerStatement(this, nType, nConcur, stmtColEncSetting); if (this.requestStarted) addOpenStatement((ISQLServerStatement)st);  loggerExternal.exiting(loggingClassName, "createStatement", st); return st; } public PreparedStatement prepareStatement(String sql, int nType, int nConcur, int resultSetHoldability) throws SQLServerException { loggerExternal.entering(loggingClassName, "prepareStatement", new Object[] { Integer.valueOf(nType), Integer.valueOf(nConcur), Integer.valueOf(resultSetHoldability) }); PreparedStatement st = prepareStatement(sql, nType, nConcur, resultSetHoldability, SQLServerStatementColumnEncryptionSetting.UseConnectionSetting); loggerExternal.exiting(loggingClassName, "prepareStatement", st); return st; } public PreparedStatement prepareStatement(String sql, int nType, int nConcur, int resultSetHoldability, SQLServerStatementColumnEncryptionSetting stmtColEncSetting) throws SQLServerException { loggerExternal.entering(loggingClassName, "prepareStatement", new Object[] { Integer.valueOf(nType), Integer.valueOf(nConcur), Integer.valueOf(resultSetHoldability), stmtColEncSetting }); checkClosed(); checkValidHoldability(resultSetHoldability); checkMatchesCurrentHoldability(resultSetHoldability); PreparedStatement st = new SQLServerPreparedStatement(this, sql, nType, nConcur, stmtColEncSetting); if (this.requestStarted) addOpenStatement((ISQLServerStatement)st);  loggerExternal.exiting(loggingClassName, "prepareStatement", st); return st; } public CallableStatement prepareCall(String sql, int nType, int nConcur, int resultSetHoldability) throws SQLServerException { loggerExternal.entering(loggingClassName, "prepareStatement", new Object[] { Integer.valueOf(nType), Integer.valueOf(nConcur), Integer.valueOf(resultSetHoldability) }); CallableStatement st = prepareCall(sql, nType, nConcur, resultSetHoldability, SQLServerStatementColumnEncryptionSetting.UseConnectionSetting); loggerExternal.exiting(loggingClassName, "prepareCall", st); return st; } public CallableStatement prepareCall(String sql, int nType, int nConcur, int resultSetHoldability, SQLServerStatementColumnEncryptionSetting stmtColEncSetiing) throws SQLServerException { loggerExternal.entering(loggingClassName, "prepareStatement", new Object[] { Integer.valueOf(nType), Integer.valueOf(nConcur), Integer.valueOf(resultSetHoldability), stmtColEncSetiing }); checkClosed(); checkValidHoldability(resultSetHoldability); checkMatchesCurrentHoldability(resultSetHoldability); CallableStatement st = new SQLServerCallableStatement(this, sql, nType, nConcur, stmtColEncSetiing); if (this.requestStarted) addOpenStatement((ISQLServerStatement)st);  loggerExternal.exiting(loggingClassName, "prepareCall", st); return st; } public PreparedStatement prepareStatement(String sql, int flag) throws SQLServerException { if (loggerExternal.isLoggable(Level.FINER)) loggerExternal.entering(loggingClassName, "prepareStatement", new Object[] { sql, Integer.valueOf(flag) });  SQLServerPreparedStatement ps = (SQLServerPreparedStatement)prepareStatement(sql, flag, SQLServerStatementColumnEncryptionSetting.UseConnectionSetting); loggerExternal.exiting(loggingClassName, "prepareStatement", ps); return ps; } public PreparedStatement prepareStatement(String sql, int flag, SQLServerStatementColumnEncryptionSetting stmtColEncSetting) throws SQLServerException { if (loggerExternal.isLoggable(Level.FINER)) loggerExternal.entering(loggingClassName, "prepareStatement", new Object[] { sql, Integer.valueOf(flag), stmtColEncSetting });  checkClosed(); SQLServerPreparedStatement ps = (SQLServerPreparedStatement)prepareStatement(sql, 1003, 1007, stmtColEncSetting); ps.bRequestedGeneratedKeys = (flag == 1); loggerExternal.exiting(loggingClassName, "prepareStatement", ps); return ps; } public PreparedStatement prepareStatement(String sql, int[] columnIndexes) throws SQLServerException { if (loggerExternal.isLoggable(Level.FINER)) loggerExternal.entering(loggingClassName, "prepareStatement", new Object[] { sql, columnIndexes });  SQLServerPreparedStatement ps = (SQLServerPreparedStatement)prepareStatement(sql, columnIndexes, SQLServerStatementColumnEncryptionSetting.UseConnectionSetting); loggerExternal.exiting(loggingClassName, "prepareStatement", ps); return ps; } public PreparedStatement prepareStatement(String sql, int[] columnIndexes, SQLServerStatementColumnEncryptionSetting stmtColEncSetting) throws SQLServerException { loggerExternal.entering(loggingClassName, "prepareStatement", new Object[] { sql, columnIndexes, stmtColEncSetting }); checkClosed(); if (columnIndexes == null || columnIndexes.length != 1) SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_invalidColumnArrayLength"), (String)null, false);  SQLServerPreparedStatement ps = (SQLServerPreparedStatement)prepareStatement(sql, 1003, 1007, stmtColEncSetting); ps.bRequestedGeneratedKeys = true; loggerExternal.exiting(loggingClassName, "prepareStatement", ps); return ps; } public PreparedStatement prepareStatement(String sql, String[] columnNames) throws SQLServerException { if (loggerExternal.isLoggable(Level.FINER)) loggerExternal.entering(loggingClassName, "prepareStatement", new Object[] { sql, columnNames });  SQLServerPreparedStatement ps = (SQLServerPreparedStatement)prepareStatement(sql, columnNames, SQLServerStatementColumnEncryptionSetting.UseConnectionSetting); loggerExternal.exiting(loggingClassName, "prepareStatement", ps); return ps; } public PreparedStatement prepareStatement(String sql, String[] columnNames, SQLServerStatementColumnEncryptionSetting stmtColEncSetting) throws SQLServerException { loggerExternal.entering(loggingClassName, "prepareStatement", new Object[] { sql, columnNames, stmtColEncSetting }); checkClosed(); if (columnNames == null || columnNames.length != 1) SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_invalidColumnArrayLength"), (String)null, false);  SQLServerPreparedStatement ps = (SQLServerPreparedStatement)prepareStatement(sql, 1003, 1007, stmtColEncSetting); ps.bRequestedGeneratedKeys = true; loggerExternal.exiting(loggingClassName, "prepareStatement", ps); return ps; } public void releaseSavepoint(Savepoint savepoint) throws SQLException { loggerExternal.entering(loggingClassName, "releaseSavepoint", savepoint); SQLServerException.throwNotSupportedException(this, (Object)null); } private final Savepoint setNamedSavepoint(String sName) throws SQLServerException { if (this.databaseAutoCommitMode) SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_cantSetSavepoint"), (String)null, false);  SQLServerSavepoint s = new SQLServerSavepoint(this, sName); connectionCommand("IF @@TRANCOUNT = 0 BEGIN BEGIN TRAN IF @@TRANCOUNT = 2 COMMIT TRAN END SAVE TRAN " + Util.escapeSQLId(s.getLabel()), "setSavepoint"); return s; } public Savepoint setSavepoint(String sName) throws SQLServerException { loggerExternal.entering(loggingClassName, "setSavepoint", sName); if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) loggerExternal.finer(toString() + " ActivityId: " + toString());  checkClosed(); Savepoint pt = setNamedSavepoint(sName); loggerExternal.exiting(loggingClassName, "setSavepoint", pt); return pt; } public Savepoint setSavepoint() throws SQLServerException { loggerExternal.entering(loggingClassName, "setSavepoint"); if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) loggerExternal.finer(toString() + " ActivityId: " + toString());  checkClosed(); Savepoint pt = setNamedSavepoint(null); loggerExternal.exiting(loggingClassName, "setSavepoint", pt); return pt; } public void rollback(Savepoint s) throws SQLServerException { loggerExternal.entering(loggingClassName, "rollback", s); if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) loggerExternal.finer(toString() + " ActivityId: " + toString());  checkClosed(); if (this.databaseAutoCommitMode) SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_cantInvokeRollback"), (String)null, false);  connectionCommand("IF @@TRANCOUNT > 0 ROLLBACK TRAN " + Util.escapeSQLId(((SQLServerSavepoint)s).getLabel()), "rollbackSavepoint"); loggerExternal.exiting(loggingClassName, "rollback"); } public int getHoldability() throws SQLServerException { loggerExternal.entering(loggingClassName, "getHoldability"); if (loggerExternal.isLoggable(Level.FINER)) loggerExternal.exiting(loggingClassName, "getHoldability", Integer.valueOf(this.holdability));  return this.holdability; } public void setHoldability(int holdability) throws SQLServerException { loggerExternal.entering(loggingClassName, "setHoldability", Integer.valueOf(holdability)); if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) loggerExternal.finer(toString() + " ActivityId: " + toString());  checkValidHoldability(holdability); checkClosed(); if (this.holdability != holdability) { assert 1 == holdability || 2 == holdability : "invalid holdability " + holdability; connectionCommand((holdability == 2) ? "SET CURSOR_CLOSE_ON_COMMIT ON" : "SET CURSOR_CLOSE_ON_COMMIT OFF", "setHoldability"); this.holdability = holdability; }  loggerExternal.exiting(loggingClassName, "setHoldability"); } public int getNetworkTimeout() throws SQLException { loggerExternal.entering(loggingClassName, "getNetworkTimeout"); checkClosed(); int timeout = 0; try { timeout = this.tdsChannel.getNetworkTimeout(); } catch (IOException ioe) { terminate(3, ioe.getMessage(), ioe); }  loggerExternal.exiting(loggingClassName, "getNetworkTimeout"); return timeout; } public void setNetworkTimeout(Executor executor, int timeout) throws SQLException { loggerExternal.entering(loggingClassName, "setNetworkTimeout", Integer.valueOf(timeout)); if (timeout < 0) { MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidSocketTimeout")); Object[] msgArgs = { Integer.valueOf(timeout) }; SQLServerException.makeFromDriverError(this, this, form.format(msgArgs), (String)null, false); }  checkClosed(); SecurityManager secMgr = System.getSecurityManager(); if (secMgr != null) try { SQLPermission perm = new SQLPermission("setNetworkTimeout"); secMgr.checkPermission(perm); } catch (SecurityException ex) { MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_permissionDenied")); Object[] msgArgs = { "setNetworkTimeout" }; SQLServerException.makeFromDriverError(this, this, form.format(msgArgs), (String)null, true); }   try { this.tdsChannel.setNetworkTimeout(timeout); } catch (IOException ioe) { terminate(3, ioe.getMessage(), ioe); }  loggerExternal.exiting(loggingClassName, "setNetworkTimeout"); } public String getSchema() throws SQLException { loggerExternal.entering(loggingClassName, "getSchema"); checkClosed(); try { SQLServerStatement stmt = (SQLServerStatement)createStatement(); try { SQLServerResultSet resultSet = stmt.executeQueryInternal("SELECT SCHEMA_NAME()"); try { if (resultSet != null) { resultSet.next(); String str = resultSet.getString(1); if (resultSet != null) resultSet.close();  if (stmt != null) stmt.close();  return str; }  SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_getSchemaError"), (String)null, true); if (resultSet != null) resultSet.close();  } catch (Throwable throwable) { if (resultSet != null) try { resultSet.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  if (stmt != null) stmt.close();  } catch (Throwable throwable) { if (stmt != null) try { stmt.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException e) { if (isSessionUnAvailable()) throw e;  SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_getSchemaError"), (String)null, true); }  loggerExternal.exiting(loggingClassName, "getSchema"); return null; } public void setSchema(String schema) throws SQLException { loggerExternal.entering(loggingClassName, "setSchema", schema); checkClosed(); addWarning(SQLServerException.getErrString("R_setSchemaWarning")); loggerExternal.exiting(loggingClassName, "setSchema"); } public void setSendTimeAsDatetime(boolean sendTimeAsDateTimeValue) { this.sendTimeAsDatetime = sendTimeAsDateTimeValue; } public void setUseFmtOnly(boolean useFmtOnly) { this.useFmtOnly = useFmtOnly; } public final boolean getUseFmtOnly() { return this.useFmtOnly; } public Array createArrayOf(String typeName, Object[] elements) throws SQLException { SQLServerException.throwNotSupportedException(this, (Object)null); return null; } public Blob createBlob() throws SQLException { checkClosed(); return new SQLServerBlob(this); } public Clob createClob() throws SQLException { checkClosed(); return new SQLServerClob(this); } public NClob createNClob() throws SQLException { checkClosed(); return new SQLServerNClob(this); } public SQLXML createSQLXML() throws SQLException { loggerExternal.entering(loggingClassName, "createSQLXML"); SQLXML sqlxml = new SQLServerSQLXML(this); if (loggerExternal.isLoggable(Level.FINER)) loggerExternal.exiting(loggingClassName, "createSQLXML", sqlxml);  return sqlxml; } public Struct createStruct(String typeName, Object[] attributes) throws SQLException { SQLServerException.throwNotSupportedException(this, (Object)null); return null; } String getTrustedServerNameAE() throws SQLServerException { return this.trustedServerNameAE.toUpperCase(); } public Properties getClientInfo() throws SQLException { loggerExternal.entering(loggingClassName, "getClientInfo"); checkClosed(); Properties p = new Properties(); loggerExternal.exiting(loggingClassName, "getClientInfo", p); return p; } public String getClientInfo(String name) throws SQLException { loggerExternal.entering(loggingClassName, "getClientInfo", name); checkClosed(); loggerExternal.exiting(loggingClassName, "getClientInfo", null); return null; } public void setClientInfo(Properties properties) throws SQLClientInfoException { loggerExternal.entering(loggingClassName, "setClientInfo", properties); try { checkClosed(); } catch (SQLServerException ex) { SQLClientInfoException info = new SQLClientInfoException(); info.initCause(ex); throw info; }  if (!properties.isEmpty()) { Enumeration<?> e = properties.keys(); while (e.hasMoreElements()) { MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidProperty")); Object[] msgArgs = { e.nextElement() }; addWarning(form.format(msgArgs)); }  }  loggerExternal.exiting(loggingClassName, "setClientInfo"); } public void setClientInfo(String name, String value) throws SQLClientInfoException { if (loggerExternal.isLoggable(Level.FINER)) loggerExternal.entering(loggingClassName, "setClientInfo", new Object[] { name, value });  try { checkClosed(); } catch (SQLServerException ex) { SQLClientInfoException info = new SQLClientInfoException(); info.initCause(ex); throw info; }  MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidProperty")); Object[] msgArgs = { name }; addWarning(form.format(msgArgs)); loggerExternal.exiting(loggingClassName, "setClientInfo"); } public boolean isValid(int timeout) throws SQLException { loggerExternal.entering(loggingClassName, "isValid", Integer.valueOf(timeout)); if (timeout < 0) { MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidQueryTimeOutValue")); Object[] msgArgs = { Integer.valueOf(timeout) }; SQLServerException.makeFromDriverError(this, this, form.format(msgArgs), (String)null, true); }  if (isSessionUnAvailable()) return false;  boolean isValid = true; try { SQLServerStatement stmt = new SQLServerStatement(this, 1003, 1007, SQLServerStatementColumnEncryptionSetting.UseConnectionSetting); try { if (0 != timeout) stmt.setQueryTimeout(timeout);  stmt.executeQueryInternal("SELECT 1"); stmt.close(); } catch (Throwable throwable) { try { stmt.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } catch (SQLException e) { isValid = false; connectionlogger.fine(toString() + " Exception checking connection validity: " + toString()); }  loggerExternal.exiting(loggingClassName, "isValid", Boolean.valueOf(isValid)); return isValid; } public boolean isWrapperFor(Class<?> iface) throws SQLException { loggerExternal.entering(loggingClassName, "isWrapperFor", iface); boolean f = iface.isInstance(this); loggerExternal.exiting(loggingClassName, "isWrapperFor", Boolean.valueOf(f)); return f; }
/*      */   public <T> T unwrap(Class<T> iface) throws SQLException { T t; loggerExternal.entering(loggingClassName, "unwrap", iface); try { t = iface.cast(this); } catch (ClassCastException e) { SQLServerException newe = new SQLServerException(e.getMessage(), e); throw newe; }  loggerExternal.exiting(loggingClassName, "unwrap", t); return t; }
/* 5977 */   protected void endRequestInternal() throws SQLException { loggerExternal.entering(loggingClassName, "endRequest", this);
/* 5978 */     synchronized (this) {
/* 5979 */       if (this.requestStarted) {
/* 5980 */         if (!this.databaseAutoCommitMode) {
/* 5981 */           rollback();
/*      */         }
/* 5983 */         if (this.databaseAutoCommitMode != this.originalDatabaseAutoCommitMode) {
/* 5984 */           setAutoCommit(this.originalDatabaseAutoCommitMode);
/*      */         }
/* 5986 */         if (this.transactionIsolationLevel != this.originalTransactionIsolationLevel) {
/* 5987 */           setTransactionIsolation(this.originalTransactionIsolationLevel);
/*      */         }
/* 5989 */         if (getNetworkTimeout() != this.originalNetworkTimeout) {
/* 5990 */           setNetworkTimeout(null, this.originalNetworkTimeout);
/*      */         }
/* 5992 */         if (this.holdability != this.originalHoldability) {
/* 5993 */           setHoldability(this.originalHoldability);
/*      */         }
/* 5995 */         if (this.sendTimeAsDatetime != this.originalSendTimeAsDatetime) {
/* 5996 */           setSendTimeAsDatetime(this.originalSendTimeAsDatetime);
/*      */         }
/* 5998 */         if (this.useFmtOnly != this.originalUseFmtOnly) {
/* 5999 */           setUseFmtOnly(this.originalUseFmtOnly);
/*      */         }
/* 6001 */         if (this.statementPoolingCacheSize != this.originalStatementPoolingCacheSize) {
/* 6002 */           setStatementPoolingCacheSize(this.originalStatementPoolingCacheSize);
/*      */         }
/* 6004 */         if (this.disableStatementPooling != this.originalDisableStatementPooling) {
/* 6005 */           setDisableStatementPooling(this.originalDisableStatementPooling);
/*      */         }
/* 6007 */         if (getServerPreparedStatementDiscardThreshold() != this.originalServerPreparedStatementDiscardThreshold) {
/* 6008 */           setServerPreparedStatementDiscardThreshold(this.originalServerPreparedStatementDiscardThreshold);
/*      */         }
/* 6010 */         if (getEnablePrepareOnFirstPreparedStatementCall() != this.originalEnablePrepareOnFirstPreparedStatementCall.booleanValue()) {
/* 6011 */           setEnablePrepareOnFirstPreparedStatementCall(this.originalEnablePrepareOnFirstPreparedStatementCall.booleanValue());
/*      */         }
/* 6013 */         if (!this.sCatalog.equals(this.originalSCatalog)) {
/* 6014 */           setCatalog(this.originalSCatalog);
/*      */         }
/* 6016 */         if (getUseBulkCopyForBatchInsert() != this.originalUseBulkCopyForBatchInsert) {
/* 6017 */           setUseBulkCopyForBatchInsert(this.originalUseBulkCopyForBatchInsert);
/*      */         }
/* 6019 */         if (this.delayLoadingLobs != this.originalDelayLoadingLobs) {
/* 6020 */           setDelayLoadingLobs(this.originalDelayLoadingLobs);
/*      */         }
/* 6022 */         this.sqlWarnings = this.originalSqlWarnings;
/* 6023 */         if (null != this.openStatements) {
/* 6024 */           while (!this.openStatements.isEmpty()) {
/* 6025 */             Statement st = this.openStatements.get(0); if (st != null) st.close(); 
/*      */           } 
/* 6027 */           this.openStatements.clear();
/*      */         } 
/* 6029 */         this.requestStarted = false;
/*      */       } 
/*      */     } 
/* 6032 */     loggerExternal.exiting(loggingClassName, "endRequest", this); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 6043 */   static final char[] OUT = new char[] { ' ', 'O', 'U', 'T' };
/*      */   private static final int BROWSER_PORT = 1434;
/*      */   
/*      */   String replaceParameterMarkers(String sqlSrc, int[] paramPositions, Parameter[] params, boolean isReturnValueSyntax) throws SQLServerException {
/* 6047 */     int MAX_PARAM_NAME_LEN = 6;
/* 6048 */     char[] sqlDst = new char[sqlSrc.length() + params.length * (6 + OUT.length)];
/* 6049 */     int dstBegin = 0;
/* 6050 */     int srcBegin = 0;
/* 6051 */     int nParam = 0;
/*      */     
/* 6053 */     int paramIndex = 0;
/*      */     while (true) {
/* 6055 */       int srcEnd = (paramIndex >= paramPositions.length) ? sqlSrc.length() : paramPositions[paramIndex];
/* 6056 */       sqlSrc.getChars(srcBegin, srcEnd, sqlDst, dstBegin);
/* 6057 */       dstBegin += srcEnd - srcBegin;
/*      */       
/* 6059 */       if (sqlSrc.length() == srcEnd) {
/*      */         break;
/*      */       }
/* 6062 */       dstBegin += makeParamName(nParam++, sqlDst, dstBegin);
/* 6063 */       srcBegin = srcEnd + 1;
/*      */       
/* 6065 */       if (params[paramIndex++].isOutput() && (
/* 6066 */         !isReturnValueSyntax || paramIndex > 1)) {
/* 6067 */         System.arraycopy(OUT, 0, sqlDst, dstBegin, OUT.length);
/* 6068 */         dstBegin += OUT.length;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 6073 */     return new String(sqlDst, 0, dstBegin);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static int makeParamName(int nParam, char[] name, int offset) {
/* 6087 */     name[offset + 0] = '@';
/* 6088 */     name[offset + 1] = 'P';
/* 6089 */     if (nParam < 10) {
/* 6090 */       name[offset + 2] = (char)(48 + nParam);
/* 6091 */       return 3;
/*      */     } 
/* 6093 */     if (nParam < 100) {
/* 6094 */       int nBase = 2;
/*      */       while (true) {
/* 6096 */         if (nParam < nBase * 10) {
/* 6097 */           name[offset + 2] = (char)(48 + nBase - 1);
/* 6098 */           name[offset + 3] = (char)(48 + nParam - (nBase - 1) * 10);
/* 6099 */           return 4;
/*      */         } 
/* 6101 */         nBase++;
/*      */       } 
/*      */     } 
/* 6104 */     String sParam = "" + nParam;
/* 6105 */     sParam.getChars(0, sParam.length(), name, offset + 2);
/* 6106 */     return 2 + sParam.length();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void notifyPooledConnection(SQLServerException e) {
/* 6118 */     synchronized (this) {
/* 6119 */       if (null != this.pooledConnectionParent) {
/* 6120 */         this.pooledConnectionParent.notifyEvent(e);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void DetachFromPool() {
/* 6128 */     synchronized (this) {
/* 6129 */       this.pooledConnectionParent = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String getInstancePort(String server, String instanceName) throws SQLServerException {
/* 6146 */     String browserResult = null;
/* 6147 */     DatagramSocket datagramSocket = null;
/* 6148 */     String lastErrorMessage = null;
/*      */     
/*      */     try {
/* 6151 */       lastErrorMessage = "Failed to determine instance for the : " + server + " instance:" + instanceName;
/*      */ 
/*      */       
/*      */       try {
/* 6155 */         datagramSocket = new DatagramSocket();
/* 6156 */         datagramSocket.setSoTimeout(1000);
/* 6157 */       } catch (SocketException socketException) {
/*      */ 
/*      */         
/* 6160 */         lastErrorMessage = "Unable to create local datagram socket";
/* 6161 */         throw socketException;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 6169 */       assert null != datagramSocket;
/*      */       try {
/* 6171 */         if (this.multiSubnetFailover) {
/*      */ 
/*      */           
/* 6174 */           InetAddress[] inetAddrs = InetAddress.getAllByName(server);
/* 6175 */           assert null != inetAddrs;
/* 6176 */           for (InetAddress inetAddr : inetAddrs) {
/*      */             
/*      */             try {
/* 6179 */               byte[] sendBuffer = (" " + instanceName).getBytes();
/* 6180 */               sendBuffer[0] = 4;
/* 6181 */               DatagramPacket udpRequest = new DatagramPacket(sendBuffer, sendBuffer.length, inetAddr, 1434);
/*      */               
/* 6183 */               datagramSocket.send(udpRequest);
/* 6184 */             } catch (IOException ioException) {
/* 6185 */               lastErrorMessage = "Error sending SQL Server Browser Service UDP request to address: " + inetAddr + ", port: 1434";
/*      */               
/* 6187 */               throw ioException;
/*      */             }
/*      */           
/*      */           } 
/*      */         } else {
/*      */           
/* 6193 */           InetAddress inetAddr = InetAddress.getByName(server);
/*      */           
/* 6195 */           assert null != inetAddr;
/*      */           
/*      */           try {
/* 6198 */             byte[] sendBuffer = (" " + instanceName).getBytes();
/* 6199 */             sendBuffer[0] = 4;
/* 6200 */             DatagramPacket udpRequest = new DatagramPacket(sendBuffer, sendBuffer.length, inetAddr, 1434);
/*      */             
/* 6202 */             datagramSocket.send(udpRequest);
/* 6203 */           } catch (IOException ioException) {
/* 6204 */             lastErrorMessage = "Error sending SQL Server Browser Service UDP request to address: " + inetAddr + ", port: 1434";
/*      */             
/* 6206 */             throw ioException;
/*      */           } 
/*      */         } 
/* 6209 */       } catch (UnknownHostException unknownHostException) {
/* 6210 */         lastErrorMessage = "Unable to determine IP address of host: " + server;
/* 6211 */         throw unknownHostException;
/*      */       } 
/*      */ 
/*      */       
/*      */       try {
/* 6216 */         byte[] receiveBuffer = new byte[4096];
/* 6217 */         DatagramPacket udpResponse = new DatagramPacket(receiveBuffer, receiveBuffer.length);
/* 6218 */         datagramSocket.receive(udpResponse);
/* 6219 */         browserResult = new String(receiveBuffer, 3, receiveBuffer.length - 3);
/* 6220 */         if (connectionlogger.isLoggable(Level.FINER)) {
/* 6221 */           connectionlogger.fine(toString() + " Received SSRP UDP response from IP address: " + toString());
/*      */         }
/* 6223 */       } catch (IOException ioException) {
/*      */         
/* 6225 */         lastErrorMessage = "Error receiving SQL Server Browser Service UDP response from server: " + server;
/* 6226 */         throw ioException;
/*      */       } 
/* 6228 */     } catch (IOException ioException) {
/* 6229 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_sqlBrowserFailed"));
/* 6230 */       Object[] msgArgs = { server, instanceName, ioException.toString() };
/* 6231 */       connectionlogger.log(Level.FINE, toString() + " " + toString(), ioException);
/* 6232 */       SQLServerException.makeFromDriverError(this, this, form.format(msgArgs), "08001", false);
/*      */     } finally {
/*      */       
/* 6235 */       if (null != datagramSocket)
/* 6236 */         datagramSocket.close(); 
/*      */     } 
/* 6238 */     assert null != browserResult;
/*      */     
/* 6240 */     int p = browserResult.indexOf("tcp;");
/* 6241 */     if (-1 == p) {
/* 6242 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_notConfiguredToListentcpip"));
/* 6243 */       Object[] msgArgs = { instanceName };
/* 6244 */       SQLServerException.makeFromDriverError(this, this, form.format(msgArgs), "08001", false);
/*      */     } 
/*      */ 
/*      */     
/* 6248 */     int p1 = p + 4;
/* 6249 */     int p2 = browserResult.indexOf(';', p1);
/* 6250 */     return browserResult.substring(p1, p2);
/*      */   }
/*      */   
/*      */   int getNextSavepointId() {
/* 6254 */     this.nNextSavePointId++;
/* 6255 */     return this.nNextSavePointId;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doSecurityCheck() {
/* 6263 */     assert null != this.currentConnectPlaceHolder;
/* 6264 */     this.currentConnectPlaceHolder.doSecurityCheck();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 6271 */   private static long columnEncryptionKeyCacheTtl = TimeUnit.SECONDS.convert(2L, TimeUnit.HOURS);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ISQLServerEnclaveProvider enclaveProvider;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized void setColumnEncryptionKeyCacheTtl(int columnEncryptionKeyCacheTTL, TimeUnit unit) throws SQLServerException {
/* 6286 */     if (columnEncryptionKeyCacheTTL < 0 || unit.equals(TimeUnit.MILLISECONDS) || unit.equals(TimeUnit.MICROSECONDS) || unit
/* 6287 */       .equals(TimeUnit.NANOSECONDS)) {
/* 6288 */       throw new SQLServerException(null, SQLServerException.getErrString("R_invalidCEKCacheTtl"), null, 0, false);
/*      */     }
/*      */     
/* 6291 */     columnEncryptionKeyCacheTtl = TimeUnit.SECONDS.convert(columnEncryptionKeyCacheTTL, unit);
/*      */   }
/*      */   
/*      */   static synchronized long getColumnEncryptionKeyCacheTtl() {
/* 6295 */     return columnEncryptionKeyCacheTtl;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void enqueueUnprepareStatementHandle(PreparedStatementHandle statementHandle) {
/* 6305 */     if (null == statementHandle) {
/*      */       return;
/*      */     }
/* 6308 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 6309 */       loggerExternal
/* 6310 */         .finer("" + this + ": Adding PreparedHandle to queue for un-prepare:" + this);
/*      */     }
/*      */     
/* 6313 */     this.discardedPreparedStatementHandles.add(statementHandle);
/* 6314 */     this.discardedPreparedStatementHandleCount.incrementAndGet();
/*      */   }
/*      */ 
/*      */   
/*      */   public int getDiscardedServerPreparedStatementCount() {
/* 6319 */     return this.discardedPreparedStatementHandleCount.get();
/*      */   }
/*      */ 
/*      */   
/*      */   public void closeUnreferencedPreparedStatementHandles() {
/* 6324 */     unprepareUnreferencedPreparedStatementHandles(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void cleanupPreparedStatementDiscardActions() {
/* 6331 */     this.discardedPreparedStatementHandles.clear();
/* 6332 */     this.discardedPreparedStatementHandleCount.set(0);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean getEnablePrepareOnFirstPreparedStatementCall() {
/* 6337 */     if (null == this.enablePrepareOnFirstPreparedStatementCall) {
/* 6338 */       return false;
/*      */     }
/* 6340 */     return this.enablePrepareOnFirstPreparedStatementCall.booleanValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public void setEnablePrepareOnFirstPreparedStatementCall(boolean value) {
/* 6345 */     this.enablePrepareOnFirstPreparedStatementCall = Boolean.valueOf(value);
/*      */   }
/*      */ 
/*      */   
/*      */   public int getServerPreparedStatementDiscardThreshold() {
/* 6350 */     if (0 > this.serverPreparedStatementDiscardThreshold) {
/* 6351 */       return 10;
/*      */     }
/* 6353 */     return this.serverPreparedStatementDiscardThreshold;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setServerPreparedStatementDiscardThreshold(int value) {
/* 6358 */     this.serverPreparedStatementDiscardThreshold = Math.max(0, value);
/*      */   }
/*      */   
/*      */   final boolean isPreparedStatementUnprepareBatchingEnabled() {
/* 6362 */     return (1 < getServerPreparedStatementDiscardThreshold());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void unprepareUnreferencedPreparedStatementHandles(boolean force) {
/* 6375 */     if (isSessionUnAvailable()) {
/*      */       return;
/*      */     }
/* 6378 */     int threshold = getServerPreparedStatementDiscardThreshold();
/*      */ 
/*      */     
/* 6381 */     if (force || threshold < getDiscardedServerPreparedStatementCount()) {
/*      */ 
/*      */       
/* 6384 */       StringBuilder sql = new StringBuilder(threshold * 32);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 6390 */       int handlesRemoved = 0;
/* 6391 */       PreparedStatementHandle statementHandle = null;
/*      */       
/* 6393 */       while (null != (statementHandle = this.discardedPreparedStatementHandles.poll())) {
/* 6394 */         handlesRemoved++;
/*      */         
/* 6396 */         sql.append(statementHandle.isDirectSql() ? "EXEC sp_unprepare " : "EXEC sp_cursorunprepare ")
/* 6397 */           .append(statementHandle.getHandle()).append(';');
/*      */       } 
/*      */ 
/*      */       
/*      */       try {
/* 6402 */         SQLServerStatement stmt = (SQLServerStatement)createStatement(); 
/* 6403 */         try { stmt.isInternalEncryptionQuery = true;
/* 6404 */           stmt.execute(sql.toString());
/* 6405 */           if (stmt != null) stmt.close();  } catch (Throwable throwable) { if (stmt != null)
/*      */             try { stmt.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }
/* 6407 */          if (loggerExternal.isLoggable(Level.FINER))
/* 6408 */           loggerExternal.finer("" + this + ": Finished un-preparing handle count:" + this); 
/* 6409 */       } catch (SQLException e) {
/* 6410 */         if (loggerExternal.isLoggable(Level.FINER)) {
/* 6411 */           loggerExternal.log(Level.FINER, "" + this + ": Error batch-closing at least one prepared handle", e);
/*      */         }
/*      */       } 
/*      */       
/* 6415 */       this.discardedPreparedStatementHandleCount.addAndGet(-handlesRemoved);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean getDisableStatementPooling() {
/* 6421 */     return this.disableStatementPooling;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setDisableStatementPooling(boolean value) {
/* 6426 */     this.disableStatementPooling = value;
/* 6427 */     if (!value && 0 < getStatementPoolingCacheSize()) {
/* 6428 */       prepareCache();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public int getStatementPoolingCacheSize() {
/* 6434 */     return this.statementPoolingCacheSize;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getStatementHandleCacheEntryCount() {
/* 6439 */     if (!isStatementPoolingEnabled()) {
/* 6440 */       return 0;
/*      */     }
/* 6442 */     return this.preparedStatementHandleCache.size();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isStatementPoolingEnabled() {
/* 6447 */     return (null != this.preparedStatementHandleCache && 0 < getStatementPoolingCacheSize() && 
/* 6448 */       !getDisableStatementPooling());
/*      */   }
/*      */ 
/*      */   
/*      */   public void setStatementPoolingCacheSize(int value) {
/* 6453 */     value = Math.max(0, value);
/* 6454 */     this.statementPoolingCacheSize = value;
/*      */     
/* 6456 */     if (!this.disableStatementPooling && value > 0) {
/* 6457 */       prepareCache();
/*      */     }
/* 6459 */     if (null != this.preparedStatementHandleCache) {
/* 6460 */       this.preparedStatementHandleCache.setCapacity(value);
/*      */     }
/* 6462 */     if (null != this.parameterMetadataCache) {
/* 6463 */       this.parameterMetadataCache.setCapacity(value);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void prepareCache() {
/* 6470 */     this
/*      */       
/* 6472 */       .preparedStatementHandleCache = (new ConcurrentLinkedHashMap.Builder()).maximumWeightedCapacity(getStatementPoolingCacheSize()).listener(new PreparedStatementCacheEvictionListener()).build();
/*      */     
/* 6474 */     this
/* 6475 */       .parameterMetadataCache = (new ConcurrentLinkedHashMap.Builder()).maximumWeightedCapacity(getStatementPoolingCacheSize()).build();
/*      */   }
/*      */ 
/*      */   
/*      */   final SQLServerParameterMetaData getCachedParameterMetadata(CityHash128Key key) {
/* 6480 */     if (!isStatementPoolingEnabled()) {
/* 6481 */       return null;
/*      */     }
/* 6483 */     return (SQLServerParameterMetaData)this.parameterMetadataCache.get(key);
/*      */   }
/*      */ 
/*      */   
/*      */   final void registerCachedParameterMetadata(CityHash128Key key, SQLServerParameterMetaData pmd) {
/* 6488 */     if (!isStatementPoolingEnabled() || null == pmd) {
/*      */       return;
/*      */     }
/* 6491 */     this.parameterMetadataCache.put(key, pmd);
/*      */   }
/*      */ 
/*      */   
/*      */   final PreparedStatementHandle getCachedPreparedStatementHandle(CityHash128Key key) {
/* 6496 */     if (!isStatementPoolingEnabled()) {
/* 6497 */       return null;
/*      */     }
/* 6499 */     return (PreparedStatementHandle)this.preparedStatementHandleCache.get(key);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   final PreparedStatementHandle registerCachedPreparedStatementHandle(CityHash128Key key, int handle, boolean isDirectSql) {
/* 6505 */     if (!isStatementPoolingEnabled() || null == key) {
/* 6506 */       return null;
/*      */     }
/* 6508 */     PreparedStatementHandle cacheItem = new PreparedStatementHandle(key, handle, isDirectSql, false);
/* 6509 */     this.preparedStatementHandleCache.putIfAbsent(key, cacheItem);
/* 6510 */     return cacheItem;
/*      */   }
/*      */ 
/*      */   
/*      */   final void returnCachedPreparedStatementHandle(PreparedStatementHandle handle) {
/* 6515 */     handle.removeReference();
/*      */     
/* 6517 */     if (handle.isEvictedFromCache() && handle.tryDiscardHandle()) {
/* 6518 */       enqueueUnprepareStatementHandle(handle);
/*      */     }
/*      */   }
/*      */   
/*      */   final void evictCachedPreparedStatementHandle(PreparedStatementHandle handle) {
/* 6523 */     if (null == handle || null == handle.getKey()) {
/*      */       return;
/*      */     }
/* 6526 */     this.preparedStatementHandleCache.remove(handle.getKey());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   final class PreparedStatementCacheEvictionListener
/*      */     implements EvictionListener<CityHash128Key, PreparedStatementHandle>
/*      */   {
/*      */     public void onEviction(SQLServerConnection.CityHash128Key key, SQLServerConnection.PreparedStatementHandle handle) {
/* 6535 */       if (null != handle) {
/* 6536 */         handle.setIsEvictedFromCache(true);
/*      */ 
/*      */         
/* 6539 */         if (handle.tryDiscardHandle()) {
/* 6540 */           SQLServerConnection.this.enqueueUnprepareStatementHandle(handle);
/*      */         }
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isAzure() {
/* 6572 */     if (null == this.isAzure) { 
/* 6573 */       try { Statement stmt = createStatement(); 
/* 6574 */         try { ResultSet rs = stmt.executeQuery("SELECT CAST(SERVERPROPERTY('EngineEdition') as INT)"); 
/* 6575 */           try { rs.next();
/*      */             
/* 6577 */             int engineEdition = rs.getInt(1);
/* 6578 */             this.isAzure = Boolean.valueOf((engineEdition == 5 || engineEdition == 6 || engineEdition == 8));
/*      */ 
/*      */             
/* 6581 */             this.isAzureDW = Boolean.valueOf((engineEdition == 6));
/* 6582 */             this.isAzureMI = Boolean.valueOf((engineEdition == 8));
/*      */             
/* 6584 */             if (rs != null) rs.close();  } catch (Throwable throwable) { if (rs != null) try { rs.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  if (stmt != null) stmt.close();  } catch (Throwable throwable) { if (stmt != null) try { stmt.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException e)
/* 6585 */       { if (loggerExternal.isLoggable(Level.FINER))
/* 6586 */           loggerExternal.log(Level.FINER, "" + this + ": Error retrieving server type", e); 
/* 6587 */         this.isAzure = Boolean.valueOf(false);
/* 6588 */         this.isAzureDW = Boolean.valueOf(false);
/* 6589 */         this.isAzureMI = Boolean.valueOf(false); }
/*      */       
/* 6591 */       return this.isAzure.booleanValue(); }
/*      */     
/* 6593 */     return this.isAzure.booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isAzureDW() {
/* 6603 */     isAzure();
/* 6604 */     return this.isAzureDW.booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isAzureMI() {
/* 6613 */     isAzure();
/* 6614 */     return this.isAzureMI.booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final synchronized void addOpenStatement(ISQLServerStatement st) {
/* 6624 */     if (null != this.openStatements) {
/* 6625 */       this.openStatements.add(st);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final synchronized void removeOpenStatement(ISQLServerStatement st) {
/* 6636 */     if (null != this.openStatements) {
/* 6637 */       this.openStatements.remove(st);
/*      */     }
/*      */   }
/*      */   
/*      */   boolean isAEv2() {
/* 6642 */     return (this.aeVersion >= 2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ArrayList<byte[]> initEnclaveParameters(String userSql, String preparedTypeDefinitions, Parameter[] params, ArrayList<String> parameterNames) throws SQLServerException {
/* 6649 */     if (!enclaveEstablished()) {
/* 6650 */       this.enclaveProvider.getAttestationParameters(this.enclaveAttestationUrl);
/*      */     }
/* 6652 */     return this.enclaveProvider.createEnclaveSession(this, userSql, preparedTypeDefinitions, params, parameterNames);
/*      */   }
/*      */   
/*      */   boolean enclaveEstablished() {
/* 6656 */     return (null != this.enclaveProvider.getEnclaveSession());
/*      */   }
/*      */   
/*      */   byte[] generateEnclavePackage(String userSQL, ArrayList<byte[]> enclaveCEKs) throws SQLServerException {
/* 6660 */     return (enclaveCEKs.size() > 0) ? this.enclaveProvider.getEnclavePackage(userSQL, enclaveCEKs) : null;
/*      */   }
/*      */   
/*      */   String getServerName() {
/* 6664 */     return this.trustedServerNameAE;
/*      */   }
/*      */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerConnection.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */