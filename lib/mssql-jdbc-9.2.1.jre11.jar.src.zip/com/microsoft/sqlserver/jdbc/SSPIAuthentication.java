/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import com.microsoft.sqlserver.jdbc.dns.DNSKerberosLocator;
/*     */ import java.net.IDN;
/*     */ import java.net.InetAddress;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.Locale;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.naming.NamingException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class SSPIAuthentication
/*     */ {
/*  32 */   private static final Pattern SPN_PATTERN = Pattern.compile("MSSQLSvc/(.*):([^:@]+)(@.+)?", 2);
/*     */ 
/*     */   
/*     */   private RealmValidator validator;
/*     */ 
/*     */ 
/*     */   
/*     */   abstract byte[] generateClientContext(byte[] paramArrayOfbyte, boolean[] paramArrayOfboolean) throws SQLServerException;
/*     */ 
/*     */ 
/*     */   
/*     */   abstract void releaseClientContext();
/*     */ 
/*     */   
/*     */   private String makeSpn(SQLServerConnection con, String server, int port) {
/*  47 */     StringBuilder spn = new StringBuilder("MSSQLSvc/");
/*     */     
/*  49 */     if (con.serverNameAsACE()) {
/*  50 */       spn.append(IDN.toASCII(server));
/*     */     } else {
/*  52 */       spn.append(server);
/*     */     } 
/*  54 */     spn.append(":");
/*  55 */     spn.append(port);
/*  56 */     return spn.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private RealmValidator getRealmValidator() {
/*  74 */     if (null != this.validator) {
/*  75 */       return this.validator;
/*     */     }
/*     */     
/*  78 */     this.validator = new RealmValidator()
/*     */       {
/*     */         public boolean isRealmValid(String realm) {
/*     */           try {
/*  82 */             return DNSKerberosLocator.isRealmValid(realm);
/*  83 */           } catch (NamingException err) {
/*  84 */             return false;
/*     */           } 
/*     */         }
/*     */       };
/*  88 */     return this.validator;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static interface RealmValidator
/*     */   {
/*     */     boolean isRealmValid(String param1String);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private String findRealmFromHostname(RealmValidator realmValidator, String hostname) {
/* 101 */     if (hostname == null) {
/* 102 */       return null;
/*     */     }
/* 104 */     int index = 0;
/* 105 */     while (index != -1 && index < hostname.length() - 2) {
/* 106 */       String realm = hostname.substring(index);
/* 107 */       if (realmValidator.isRealmValid(realm)) {
/* 108 */         return realm.toUpperCase();
/*     */       }
/* 110 */       index = hostname.indexOf(".", index + 1);
/* 111 */       if (-1 != index) {
/* 112 */         index++;
/*     */       }
/*     */     } 
/* 115 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String enrichSpnWithRealm(String spn, boolean allowHostnameCanonicalization) {
/* 128 */     if (spn == null) {
/* 129 */       return spn;
/*     */     }
/* 131 */     Matcher m = SPN_PATTERN.matcher(spn);
/* 132 */     if (!m.matches()) {
/* 133 */       return spn;
/*     */     }
/* 135 */     if (m.group(3) != null)
/*     */     {
/* 137 */       return spn;
/*     */     }
/* 139 */     String dnsName = m.group(1);
/* 140 */     String portOrInstance = m.group(2);
/* 141 */     RealmValidator realmValidator = getRealmValidator();
/* 142 */     String realm = findRealmFromHostname(realmValidator, dnsName);
/* 143 */     if (realm == null && allowHostnameCanonicalization) {
/*     */       
/*     */       try {
/* 146 */         String canonicalHostName = InetAddress.getByName(dnsName).getCanonicalHostName();
/* 147 */         realm = findRealmFromHostname(realmValidator, canonicalHostName);
/*     */         
/* 149 */         dnsName = canonicalHostName;
/* 150 */       } catch (UnknownHostException unknownHostException) {}
/*     */     }
/*     */ 
/*     */     
/* 154 */     if (realm == null) {
/* 155 */       return spn;
/*     */     }
/* 157 */     StringBuilder sb = new StringBuilder("MSSQLSvc/");
/* 158 */     sb.append(dnsName).append(":").append(portOrInstance).append("@").append(realm.toUpperCase(Locale.ENGLISH));
/* 159 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getSpn(SQLServerConnection con) {
/*     */     String spn;
/* 171 */     if (null == con || null == con.activeConnectionProperties) {
/* 172 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 177 */     String userSuppliedServerSpn = con.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.SERVER_SPN.toString());
/* 178 */     if (null != userSuppliedServerSpn) {
/*     */       
/* 180 */       if (con.serverNameAsACE()) {
/* 181 */         int slashPos = userSuppliedServerSpn.indexOf("/");
/*     */         
/* 183 */         spn = userSuppliedServerSpn.substring(0, slashPos + 1) + userSuppliedServerSpn.substring(0, slashPos + 1);
/*     */       } else {
/* 185 */         spn = userSuppliedServerSpn;
/*     */       } 
/*     */     } else {
/* 188 */       spn = makeSpn(con, con.currentConnectPlaceHolder.getServerName(), con.currentConnectPlaceHolder
/* 189 */           .getPortNumber());
/*     */     } 
/* 191 */     return enrichSpnWithRealm(spn, (null == userSuppliedServerSpn));
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SSPIAuthentication.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */