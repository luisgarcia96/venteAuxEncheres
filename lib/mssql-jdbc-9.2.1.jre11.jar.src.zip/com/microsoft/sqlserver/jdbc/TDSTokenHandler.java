/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class TDSTokenHandler
/*     */ {
/*     */   final String logContext;
/*     */   private SQLServerError databaseError;
/* 186 */   private static Logger logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.TDS.TOKEN");
/*     */   
/*     */   final SQLServerError getDatabaseError() {
/* 189 */     return this.databaseError;
/*     */   }
/*     */   
/*     */   TDSTokenHandler(String logContext) {
/* 193 */     this.logContext = logContext;
/*     */   }
/*     */   
/*     */   boolean onSSPI(TDSReader tdsReader) throws SQLServerException {
/* 197 */     TDSParser.throwUnexpectedTokenException(tdsReader, this.logContext);
/* 198 */     return false;
/*     */   }
/*     */   
/*     */   boolean onLoginAck(TDSReader tdsReader) throws SQLServerException {
/* 202 */     TDSParser.throwUnexpectedTokenException(tdsReader, this.logContext);
/* 203 */     return false;
/*     */   }
/*     */   
/*     */   boolean onFeatureExtensionAck(TDSReader tdsReader) throws SQLServerException {
/* 207 */     TDSParser.throwUnexpectedTokenException(tdsReader, this.logContext);
/* 208 */     return false;
/*     */   }
/*     */   
/*     */   boolean onEnvChange(TDSReader tdsReader) throws SQLServerException {
/* 212 */     tdsReader.getConnection().processEnvChange(tdsReader);
/* 213 */     return true;
/*     */   }
/*     */   
/*     */   boolean onRetStatus(TDSReader tdsReader) throws SQLServerException {
/* 217 */     (new StreamRetStatus()).setFromTDS(tdsReader);
/* 218 */     return true;
/*     */   }
/*     */   
/*     */   boolean onRetValue(TDSReader tdsReader) throws SQLServerException {
/* 222 */     TDSParser.throwUnexpectedTokenException(tdsReader, this.logContext);
/* 223 */     return false;
/*     */   }
/*     */   
/*     */   boolean onDone(TDSReader tdsReader) throws SQLServerException {
/* 227 */     StreamDone doneToken = new StreamDone();
/* 228 */     doneToken.setFromTDS(tdsReader);
/* 229 */     return true;
/*     */   }
/*     */   
/*     */   boolean onError(TDSReader tdsReader) throws SQLServerException {
/* 233 */     if (null == this.databaseError) {
/* 234 */       this.databaseError = new SQLServerError();
/* 235 */       this.databaseError.setFromTDS(tdsReader);
/*     */     } else {
/* 237 */       (new SQLServerError()).setFromTDS(tdsReader);
/*     */     } 
/*     */     
/* 240 */     return true;
/*     */   }
/*     */   
/*     */   boolean onInfo(TDSReader tdsReader) throws SQLServerException {
/* 244 */     TDSParser.ignoreLengthPrefixedToken(tdsReader);
/* 245 */     return true;
/*     */   }
/*     */   
/*     */   boolean onOrder(TDSReader tdsReader) throws SQLServerException {
/* 249 */     TDSParser.ignoreLengthPrefixedToken(tdsReader);
/* 250 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean onColMetaData(TDSReader tdsReader) throws SQLServerException {
/* 255 */     if (logger.isLoggable(Level.SEVERE)) {
/* 256 */       logger.severe(tdsReader.toString() + ": " + tdsReader.toString() + ": Encountered " + this.logContext + ". SHOWPLAN is ON, ignoring.");
/*     */     }
/* 258 */     return false;
/*     */   }
/*     */   
/*     */   boolean onRow(TDSReader tdsReader) throws SQLServerException {
/* 262 */     TDSParser.throwUnexpectedTokenException(tdsReader, this.logContext);
/* 263 */     return false;
/*     */   }
/*     */   
/*     */   boolean onNBCRow(TDSReader tdsReader) throws SQLServerException {
/* 267 */     TDSParser.throwUnexpectedTokenException(tdsReader, this.logContext);
/* 268 */     return false;
/*     */   }
/*     */   
/*     */   boolean onColInfo(TDSReader tdsReader) throws SQLServerException {
/* 272 */     TDSParser.ignoreLengthPrefixedToken(tdsReader);
/* 273 */     return true;
/*     */   }
/*     */   
/*     */   boolean onTabName(TDSReader tdsReader) throws SQLServerException {
/* 277 */     TDSParser.ignoreLengthPrefixedToken(tdsReader);
/* 278 */     return true;
/*     */   }
/*     */   
/*     */   void onEOF(TDSReader tdsReader) throws SQLServerException {
/* 282 */     if (null != getDatabaseError()) {
/* 283 */       SQLServerException.makeFromDatabaseError(tdsReader.getConnection(), null, 
/* 284 */           getDatabaseError().getErrorMessage(), getDatabaseError(), false);
/*     */     }
/*     */   }
/*     */   
/*     */   boolean onFedAuthInfo(TDSReader tdsReader) throws SQLServerException {
/* 289 */     tdsReader.getConnection().processFedAuthInfo(tdsReader, this);
/* 290 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\TDSTokenHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */