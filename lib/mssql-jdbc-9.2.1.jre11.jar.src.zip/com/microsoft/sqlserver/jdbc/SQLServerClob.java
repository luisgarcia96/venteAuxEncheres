/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import java.io.Reader;
/*    */ import java.io.UnsupportedEncodingException;
/*    */ import java.io.Writer;
/*    */ import java.sql.Clob;
/*    */ import java.sql.SQLException;
/*    */ import java.util.logging.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SQLServerClob
/*    */   extends SQLServerClobBase
/*    */   implements Clob
/*    */ {
/*    */   private static final long serialVersionUID = 2872035282200133865L;
/* 40 */   private static final Logger logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerClob");
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   public SQLServerClob(SQLServerConnection connection, String data) {
/* 53 */     super(connection, data, (null == connection) ? null : connection.getDatabaseCollation(), logger, null);
/*    */     
/* 55 */     if (null == data)
/* 56 */       throw new NullPointerException(SQLServerException.getErrString("R_cantSetNull")); 
/*    */   }
/*    */   
/*    */   SQLServerClob(SQLServerConnection connection) {
/* 60 */     super(connection, "", connection.getDatabaseCollation(), logger, null);
/*    */   }
/*    */   
/*    */   SQLServerClob(BaseInputStream stream, TypeInfo typeInfo) throws SQLServerException, UnsupportedEncodingException {
/* 64 */     super(null, stream, typeInfo.getSQLCollation(), logger, typeInfo);
/*    */   }
/*    */ 
/*    */   
/*    */   final JDBCType getJdbcType() {
/* 69 */     return JDBCType.CLOB;
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerClob.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */