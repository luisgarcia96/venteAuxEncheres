/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLFeatureNotSupportedException;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.UUID;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SQLServerException
/*     */   extends SQLException
/*     */ {
/*     */   private static final long serialVersionUID = -2195310557661496761L;
/*     */   static final String EXCEPTION_XOPEN_CONNECTION_CANT_ESTABLISH = "08001";
/*     */   static final String EXCEPTION_XOPEN_CONNECTION_DOES_NOT_EXIST = "08003";
/*     */   static final String EXCEPTION_XOPEN_CONNECTION_FAILURE = "08006";
/*     */   static final String LOG_CLIENT_CONNECTION_ID_PREFIX = " ClientConnectionId:";
/*     */   static final int LOGON_FAILED = 18456;
/*     */   static final int PASSWORD_EXPIRED = 18488;
/*     */   static final int USER_ACCOUNT_LOCKED = 18486;
/*  69 */   static Logger exLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerException");
/*     */   
/*     */   static final int DRIVER_ERROR_NONE = 0;
/*     */   
/*     */   static final int DRIVER_ERROR_FROM_DATABASE = 2;
/*     */   
/*     */   static final int DRIVER_ERROR_IO_FAILED = 3;
/*     */   static final int DRIVER_ERROR_INVALID_TDS = 4;
/*     */   static final int DRIVER_ERROR_SSL_FAILED = 5;
/*     */   static final int DRIVER_ERROR_UNSUPPORTED_CONFIG = 6;
/*     */   static final int DRIVER_ERROR_INTERMITTENT_TLS_FAILED = 7;
/*     */   static final int ERROR_SOCKET_TIMEOUT = 8;
/*     */   static final int ERROR_QUERY_TIMEOUT = 9;
/*     */   static final int DATA_CLASSIFICATION_INVALID_VERSION = 10;
/*     */   static final int DATA_CLASSIFICATION_NOT_EXPECTED = 11;
/*     */   static final int DATA_CLASSIFICATION_INVALID_LABEL_INDEX = 12;
/*     */   static final int DATA_CLASSIFICATION_INVALID_INFORMATION_TYPE_INDEX = 13;
/*  86 */   private int driverErrorCode = 0;
/*     */   private SQLServerError sqlServerError;
/*     */   
/*     */   final int getDriverErrorCode() {
/*  90 */     return this.driverErrorCode;
/*     */   }
/*     */   
/*     */   final void setDriverErrorCode(int value) {
/*  94 */     this.driverErrorCode = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void logException(Object o, String errText, boolean bStack) {
/* 108 */     String id = "";
/* 109 */     if (o != null) {
/* 110 */       id = o.toString();
/*     */     }
/* 112 */     if (exLogger.isLoggable(Level.FINE))
/* 113 */       exLogger.fine("*** SQLException:" + id + " " + toString() + " " + errText); 
/* 114 */     if (bStack && 
/* 115 */       exLogger.isLoggable(Level.FINE)) {
/* 116 */       StringBuilder sb = new StringBuilder(100);
/* 117 */       StackTraceElement[] st = getStackTrace();
/* 118 */       for (StackTraceElement aSt : st)
/* 119 */         sb.append(aSt.toString()); 
/* 120 */       Throwable t = getCause();
/* 121 */       if (t != null) {
/* 122 */         sb.append("\n caused by ").append(t).append("\n");
/* 123 */         StackTraceElement[] tst = t.getStackTrace();
/* 124 */         for (StackTraceElement aTst : tst)
/* 125 */           sb.append(aTst.toString()); 
/*     */       } 
/* 127 */       exLogger.fine(sb.toString());
/*     */     } 
/*     */     
/* 130 */     if (getErrString("R_queryTimedOut").equals(errText)) {
/* 131 */       setDriverErrorCode(9);
/*     */     }
/*     */   }
/*     */   
/*     */   static String getErrString(String errCode) {
/* 136 */     return SQLServerResource.getResource(errCode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SQLServerException(String errText, SQLState sqlState, DriverError driverError, Throwable cause) {
/* 152 */     this(errText, sqlState.getSQLStateCode(), driverError.getErrorCode(), cause);
/*     */   }
/*     */   
/*     */   SQLServerException(String errText, String errState, int errNum, Throwable cause) {
/* 156 */     super(errText, errState, errNum);
/* 157 */     initCause(cause);
/* 158 */     logException((Object)null, errText, true);
/* 159 */     if (Util.isActivityTraceOn())
/*     */     {
/* 161 */       ActivityCorrelator.setCurrentActivityIdSentFlag();
/*     */     }
/*     */   }
/*     */   
/*     */   SQLServerException(String errText, Throwable cause) {
/* 166 */     super(errText);
/* 167 */     initCause(cause);
/* 168 */     logException((Object)null, errText, true);
/* 169 */     if (Util.isActivityTraceOn()) {
/* 170 */       ActivityCorrelator.setCurrentActivityIdSentFlag();
/*     */     }
/*     */   }
/*     */   
/*     */   SQLServerException(Object obj, String errText, String errState, int errNum, boolean bStack) {
/* 175 */     super(errText, errState, errNum);
/* 176 */     logException(obj, errText, bStack);
/* 177 */     if (Util.isActivityTraceOn()) {
/* 178 */       ActivityCorrelator.setCurrentActivityIdSentFlag();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SQLServerException(Object obj, String errText, String errState, SQLServerError sqlServerError, boolean bStack) {
/* 197 */     super(errText, errState, sqlServerError.getErrorNumber());
/* 198 */     this.sqlServerError = sqlServerError;
/*     */ 
/*     */     
/* 201 */     errText = "Msg " + sqlServerError.getErrorNumber() + ", Level " + sqlServerError.getErrorSeverity() + ", State " + sqlServerError.getErrorState() + ", " + errText;
/* 202 */     logException(obj, errText, bStack);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void makeFromDriverError(SQLServerConnection con, Object obj, String errText, String state, boolean bStack) throws SQLServerException {
/* 225 */     String stateCode = "";
/*     */ 
/*     */     
/* 228 */     if (state != null)
/* 229 */       stateCode = state; 
/* 230 */     if (con == null || !con.xopenStates) {
/* 231 */       stateCode = mapFromXopen(state);
/*     */     }
/*     */     
/* 234 */     SQLServerException theException = new SQLServerException(obj, checkAndAppendClientConnId(errText, con), stateCode, 0, bStack);
/* 235 */     if (null != state && state.equals("08006") && null != con) {
/* 236 */       con.notifyPooledConnection(theException);
/*     */       
/* 238 */       con.close();
/*     */     } 
/*     */     
/* 241 */     throw theException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void makeFromDatabaseError(SQLServerConnection con, Object obj, String errText, SQLServerError sqlServerError, boolean bStack) throws SQLServerException {
/* 259 */     String state = generateStateCode(con, sqlServerError.getErrorNumber(), Integer.valueOf(sqlServerError.getErrorState()));
/*     */ 
/*     */     
/* 262 */     SQLServerException theException = new SQLServerException(obj, checkAndAppendClientConnId(errText, con), state, sqlServerError, bStack);
/* 263 */     theException.setDriverErrorCode(2);
/*     */ 
/*     */     
/* 266 */     if (sqlServerError.getErrorSeverity() >= 20 && null != con) {
/* 267 */       con.notifyPooledConnection(theException);
/* 268 */       con.close();
/*     */     } 
/*     */     
/* 271 */     throw theException;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static void ConvertConnectExceptionToSQLServerException(String hostName, int portNumber, SQLServerConnection conn, Exception ex) throws SQLServerException {
/* 277 */     Exception connectException = ex;
/*     */     
/* 279 */     if (connectException != null) {
/* 280 */       MessageFormat formDetail = new MessageFormat(getErrString("R_tcpOpenFailed"));
/* 281 */       Object[] msgArgsDetail = { connectException.getMessage() };
/* 282 */       MessageFormat form = new MessageFormat(getErrString("R_tcpipConnectionFailed"));
/*     */       
/* 284 */       Object[] msgArgs = { conn.getServerNameString(hostName), Integer.toString(portNumber), formDetail.format(msgArgsDetail) };
/* 285 */       makeFromDriverError(conn, conn, form.format(msgArgs), "08001", false);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String mapFromXopen(String state) {
/* 302 */     if (null != state) {
/* 303 */       switch (state) {
/*     */         case "07009":
/* 305 */           return "S1093";
/*     */ 
/*     */         
/*     */         case "08001":
/* 309 */           return "08S01";
/*     */         case "08006":
/* 311 */           return "08S01";
/*     */       } 
/* 313 */       return "";
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 318 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String generateStateCode(SQLServerConnection con, int errNum, Integer databaseState) {
/* 334 */     boolean xopenStates = (con != null && con.xopenStates);
/* 335 */     if (xopenStates) {
/* 336 */       switch (errNum) {
/*     */         case 4060:
/* 338 */           return "08001";
/*     */         case 18456:
/* 340 */           return "08001";
/*     */         case 2714:
/* 342 */           return "42S01";
/*     */         case 208:
/* 344 */           return "42S02";
/*     */         case 207:
/* 346 */           return "42S22";
/*     */       } 
/* 348 */       return "42000";
/*     */     } 
/*     */ 
/*     */     
/* 352 */     switch (errNum) {
/*     */       
/*     */       case 8152:
/* 355 */         return "22001";
/*     */       case 515:
/*     */       case 547:
/* 358 */         return "23000";
/*     */       case 2601:
/* 360 */         return "23000";
/*     */       case 2714:
/* 362 */         return "S0001";
/*     */       case 208:
/* 364 */         return "S0002";
/*     */       case 1205:
/* 366 */         return "40001";
/*     */       case 2627:
/* 368 */         return "23000";
/*     */     } 
/* 370 */     String dbState = databaseState.toString();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 376 */     StringBuilder trailingZeroes = new StringBuilder("S");
/* 377 */     for (int i = 0; i < 4 - dbState.length(); i++) {
/* 378 */       trailingZeroes.append("0");
/*     */     }
/* 380 */     return trailingZeroes.append(dbState).toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String checkAndAppendClientConnId(String errMsg, SQLServerConnection conn) throws SQLServerException {
/* 397 */     if (null != conn && conn.attachConnId()) {
/* 398 */       UUID clientConnId = conn.getClientConIdInternal();
/* 399 */       assert null != clientConnId;
/* 400 */       StringBuilder sb = new StringBuilder(errMsg);
/*     */ 
/*     */       
/* 403 */       sb.append(" ClientConnectionId:");
/* 404 */       sb.append(clientConnId.toString());
/* 405 */       return sb.toString();
/*     */     } 
/* 407 */     return errMsg;
/*     */   }
/*     */ 
/*     */   
/*     */   static void throwNotSupportedException(SQLServerConnection con, Object obj) throws SQLServerException {
/* 412 */     makeFromDriverError(con, obj, getErrString("R_notSupported"), (String)null, false);
/*     */   }
/*     */ 
/*     */   
/*     */   static void throwFeatureNotSupportedException() throws SQLFeatureNotSupportedException {
/* 417 */     throw new SQLFeatureNotSupportedException(getErrString("R_notSupported"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SQLServerError getSQLServerError() {
/* 427 */     return this.sqlServerError;
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerException.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */