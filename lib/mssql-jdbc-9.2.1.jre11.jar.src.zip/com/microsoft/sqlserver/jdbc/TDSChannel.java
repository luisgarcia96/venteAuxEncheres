/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.Serializable;
/*      */ import java.net.InetAddress;
/*      */ import java.net.InetSocketAddress;
/*      */ import java.net.Socket;
/*      */ import java.net.SocketAddress;
/*      */ import java.net.SocketException;
/*      */ import java.nio.channels.SocketChannel;
/*      */ import java.security.KeyStore;
/*      */ import java.security.Provider;
/*      */ import java.security.Security;
/*      */ import java.security.cert.CertificateException;
/*      */ import java.security.cert.X509Certificate;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ import javax.net.ssl.KeyManager;
/*      */ import javax.net.ssl.SSLContext;
/*      */ import javax.net.ssl.SSLSocket;
/*      */ import javax.net.ssl.TrustManager;
/*      */ import javax.net.ssl.TrustManagerFactory;
/*      */ import javax.net.ssl.X509TrustManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class TDSChannel
/*      */   implements Serializable
/*      */ {
/*      */   private static final long serialVersionUID = -866497813437384090L;
/*  567 */   private static final Logger logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.TDS.Channel"); private final String traceID; private final SQLServerConnection con; private final TDSWriter tdsWriter; private Socket tcpSocket; private SSLSocket sslSocket; private Socket channelSocket;
/*      */   
/*      */   final Logger getLogger() {
/*  570 */     return logger;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final String toString() {
/*  576 */     return this.traceID;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final TDSWriter getWriter() {
/*  584 */     return this.tdsWriter;
/*      */   }
/*      */   
/*      */   final TDSReader getReader(TDSCommand command) {
/*  588 */     return new TDSReader(this, this.con, command);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  607 */   ProxySocket proxySocket = null;
/*      */ 
/*      */   
/*      */   private InputStream tcpInputStream;
/*      */ 
/*      */   
/*      */   private OutputStream tcpOutputStream;
/*      */ 
/*      */   
/*      */   private InputStream inputStream;
/*      */ 
/*      */   
/*      */   private OutputStream outputStream;
/*      */   
/*  621 */   private static Logger packetLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.TDS.DATA");
/*  622 */   private final boolean isLoggingPackets = packetLogger.isLoggable(Level.FINEST);
/*      */   
/*      */   final boolean isLoggingPackets() {
/*  625 */     return this.isLoggingPackets;
/*      */   }
/*      */ 
/*      */   
/*  629 */   int numMsgsSent = 0;
/*  630 */   int numMsgsRcvd = 0;
/*      */ 
/*      */ 
/*      */   
/*  634 */   private int spid = 0;
/*      */   
/*      */   void setSPID(int spid) {
/*  637 */     this.spid = spid;
/*      */   }
/*      */   
/*      */   int getSPID() {
/*  641 */     return this.spid;
/*      */   }
/*      */   
/*      */   void resetPooledConnection() {
/*  645 */     this.tdsWriter.resetPooledConnection();
/*      */   }
/*      */   
/*      */   TDSChannel(SQLServerConnection con) {
/*  649 */     this.con = con;
/*  650 */     this.traceID = "TDSChannel (" + con.toString() + ")";
/*  651 */     this.tcpSocket = null;
/*  652 */     this.sslSocket = null;
/*  653 */     this.channelSocket = null;
/*  654 */     this.tcpInputStream = null;
/*  655 */     this.tcpOutputStream = null;
/*  656 */     this.inputStream = null;
/*  657 */     this.outputStream = null;
/*  658 */     this.tdsWriter = new TDSWriter(this, con);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final InetSocketAddress open(String host, int port, int timeoutMillis, boolean useParallel, boolean useTnir, boolean isTnirFirstAttempt, int timeoutMillisForFullTimeout) throws SQLServerException {
/*  668 */     if (logger.isLoggable(Level.FINER)) {
/*  669 */       logger.finer(toString() + ": Opening TCP socket...");
/*      */     }
/*  671 */     SocketFinder socketFinder = new SocketFinder(this.traceID, this.con);
/*  672 */     this.channelSocket = this.tcpSocket = socketFinder.findSocket(host, port, timeoutMillis, useParallel, useTnir, isTnirFirstAttempt, timeoutMillisForFullTimeout);
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  677 */       this.tcpSocket.setTcpNoDelay(true);
/*  678 */       this.tcpSocket.setKeepAlive(true);
/*      */ 
/*      */       
/*  681 */       int socketTimeout = this.con.getSocketTimeoutMilliseconds();
/*  682 */       this.tcpSocket.setSoTimeout(socketTimeout);
/*      */       
/*  684 */       this.inputStream = this.tcpInputStream = this.tcpSocket.getInputStream();
/*  685 */       this.outputStream = this.tcpOutputStream = this.tcpSocket.getOutputStream();
/*  686 */     } catch (IOException ex) {
/*  687 */       SQLServerException.ConvertConnectExceptionToSQLServerException(host, port, this.con, ex);
/*      */     } 
/*  689 */     return (InetSocketAddress)this.channelSocket.getRemoteSocketAddress();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void disableSSL() {
/*  696 */     if (logger.isLoggable(Level.FINER)) {
/*  697 */       logger.finer(toString() + " Disabling SSL...");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  709 */     InputStream is = new ByteArrayInputStream(new byte[0]);
/*      */     try {
/*  711 */       is.close();
/*  712 */     } catch (IOException e) {
/*      */ 
/*      */       
/*  715 */       logger.fine("Ignored error closing InputStream: " + e.getMessage());
/*      */     } 
/*      */     
/*  718 */     OutputStream os = new ByteArrayOutputStream();
/*      */     try {
/*  720 */       os.close();
/*  721 */     } catch (IOException e) {
/*      */ 
/*      */       
/*  724 */       logger.fine("Ignored error closing OutputStream: " + e.getMessage());
/*      */     } 
/*      */ 
/*      */     
/*  728 */     if (logger.isLoggable(Level.FINEST))
/*  729 */       logger.finest(toString() + " Rewiring proxy streams for SSL socket close"); 
/*  730 */     this.proxySocket.setStreams(is, os);
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  735 */       if (logger.isLoggable(Level.FINER)) {
/*  736 */         logger.finer(toString() + " Closing SSL socket");
/*      */       }
/*  738 */       this.sslSocket.close();
/*  739 */     } catch (IOException e) {
/*      */       
/*  741 */       logger.fine("Ignored error closing SSLSocket: " + e.getMessage());
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  747 */     this.proxySocket = null;
/*      */ 
/*      */ 
/*      */     
/*  751 */     this.inputStream = this.tcpInputStream;
/*  752 */     this.outputStream = this.tcpOutputStream;
/*  753 */     this.channelSocket = this.tcpSocket;
/*  754 */     this.sslSocket = null;
/*      */     
/*  756 */     if (logger.isLoggable(Level.FINER)) {
/*  757 */       logger.finer(toString() + " SSL disabled");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private class SSLHandshakeInputStream
/*      */     extends InputStream
/*      */   {
/*      */     private final TDSReader tdsReader;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final TDSChannel.SSLHandshakeOutputStream sslHandshakeOutputStream;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final Logger logger;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final String logContext;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final byte[] oneByte;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     SSLHandshakeInputStream(TDSChannel tdsChannel, TDSChannel.SSLHandshakeOutputStream sslHandshakeOutputStream) {
/*  833 */       this.oneByte = new byte[1]; this.tdsReader = tdsChannel.getReader(null); this.sslHandshakeOutputStream = sslHandshakeOutputStream; this.logger = tdsChannel.getLogger(); this.logContext = tdsChannel.toString() + " (SSLHandshakeInputStream):";
/*      */     } private void ensureSSLPayload() throws IOException { if (0 == this.tdsReader.available()) { if (this.logger.isLoggable(Level.FINEST))
/*      */           this.logger.finest(this.logContext + " No handshake response bytes available. Flushing SSL handshake output stream.");  try { this.sslHandshakeOutputStream.endMessage(); } catch (SQLServerException e) { this.logger.finer(this.logContext + " Ending TDS message threw exception:" + this.logContext); throw new IOException(e.getMessage()); }  if (this.logger.isLoggable(Level.FINEST))
/*      */           this.logger.finest(this.logContext + " Reading first packet of SSL handshake response");  try { this.tdsReader.readPacket(); } catch (SQLServerException e) { this.logger.finer(this.logContext + " Reading response packet threw exception:" + this.logContext); throw new IOException(e.getMessage()); }
/*      */          }
/*  838 */        } public int read() throws IOException { int bytesRead; while (0 == (bytesRead = readInternal(this.oneByte, 0, this.oneByte.length)));
/*      */       
/*  840 */       assert 1 == bytesRead || -1 == bytesRead;
/*  841 */       return (1 == bytesRead) ? this.oneByte[0] : -1; }
/*      */     public long skip(long n) throws IOException { if (this.logger.isLoggable(Level.FINEST))
/*      */         this.logger.finest(this.logContext + " Skipping " + this.logContext + " bytes...");  if (n <= 0L)
/*      */         return 0L;  if (n > 2147483647L)
/*  845 */         n = 2147483647L;  ensureSSLPayload(); try { this.tdsReader.skip((int)n); } catch (SQLServerException e) { this.logger.finer(this.logContext + " Skipping bytes threw exception:" + this.logContext); throw new IOException(e.getMessage()); }  return n; } public int read(byte[] b) throws IOException { return readInternal(b, 0, b.length); }
/*      */ 
/*      */     
/*      */     public int read(byte[] b, int offset, int maxBytes) throws IOException {
/*  849 */       return readInternal(b, offset, maxBytes);
/*      */     }
/*      */     
/*      */     private int readInternal(byte[] b, int offset, int maxBytes) throws IOException {
/*  853 */       if (this.logger.isLoggable(Level.FINEST)) {
/*  854 */         this.logger.finest(this.logContext + " Reading " + this.logContext + " bytes...");
/*      */       }
/*  856 */       ensureSSLPayload();
/*      */       
/*      */       try {
/*  859 */         this.tdsReader.readBytes(b, offset, maxBytes);
/*  860 */       } catch (SQLServerException e) {
/*  861 */         this.logger.finer(this.logContext + " Reading bytes threw exception:" + this.logContext);
/*  862 */         throw new IOException(e.getMessage());
/*      */       } 
/*      */       
/*  865 */       return maxBytes;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private class SSLHandshakeOutputStream
/*      */     extends OutputStream
/*      */   {
/*      */     private final TDSWriter tdsWriter;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean messageStarted;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final Logger logger;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final String logContext;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final byte[] singleByte;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     SSLHandshakeOutputStream(TDSChannel tdsChannel) {
/*  915 */       this.singleByte = new byte[1]; this.tdsWriter = tdsChannel.getWriter(); this.messageStarted = false; this.logger = tdsChannel.getLogger(); this.logContext = tdsChannel.toString() + " (SSLHandshakeOutputStream):";
/*      */     } public void flush() throws IOException { if (this.logger.isLoggable(Level.FINEST)) this.logger.finest(this.logContext + " Ignored a request to flush the stream");  } void endMessage() throws SQLServerException { assert this.messageStarted; if (this.logger.isLoggable(Level.FINEST))
/*      */         this.logger.finest(this.logContext + " Finishing TDS message");  this.tdsWriter.endMessage(); this.messageStarted = false; }
/*  918 */     public void write(int b) throws IOException { this.singleByte[0] = (byte)(b & 0xFF);
/*  919 */       writeInternal(this.singleByte, 0, this.singleByte.length); }
/*      */ 
/*      */     
/*      */     public void write(byte[] b) throws IOException {
/*  923 */       writeInternal(b, 0, b.length);
/*      */     }
/*      */     
/*      */     public void write(byte[] b, int off, int len) throws IOException {
/*  927 */       writeInternal(b, off, len);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private void writeInternal(byte[] b, int off, int len) throws IOException {
/*      */       try {
/*  934 */         if (!this.messageStarted) {
/*  935 */           if (this.logger.isLoggable(Level.FINEST)) {
/*  936 */             this.logger.finest(this.logContext + " Starting new TDS packet...");
/*      */           }
/*  938 */           this.tdsWriter.startMessage(null, (byte)18);
/*  939 */           this.messageStarted = true;
/*      */         } 
/*      */         
/*  942 */         if (this.logger.isLoggable(Level.FINEST)) {
/*  943 */           this.logger.finest(this.logContext + " Writing " + this.logContext + " bytes...");
/*      */         }
/*  945 */         this.tdsWriter.writeBytes(b, off, len);
/*  946 */       } catch (SQLServerException e) {
/*  947 */         this.logger.finer(this.logContext + " Writing bytes threw exception:" + this.logContext);
/*  948 */         throw new IOException(e.getMessage());
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final class ProxyInputStream
/*      */     extends InputStream
/*      */   {
/*      */     private InputStream filteredStream;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final byte[] oneByte;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     ProxyInputStream(InputStream is) {
/*  993 */       this.oneByte = new byte[1]; this.filteredStream = is;
/*      */     } final void setFilteredStream(InputStream is) { this.filteredStream = is; } public long skip(long n) throws IOException { if (TDSChannel.logger.isLoggable(Level.FINEST)) TDSChannel.logger.finest(toString() + " Skipping " + toString() + " bytes");  long bytesSkipped = this.filteredStream.skip(n); if (TDSChannel.logger.isLoggable(Level.FINEST))
/*      */         TDSChannel.logger.finest(toString() + " Skipped " + toString() + " bytes");  return bytesSkipped; }
/*      */     public int available() throws IOException { int bytesAvailable = this.filteredStream.available(); if (TDSChannel.logger.isLoggable(Level.FINEST))
/*      */         TDSChannel.logger.finest(toString() + " " + toString() + " bytes available");  return bytesAvailable; }
/*  998 */     public int read() throws IOException { int bytesRead; while (0 == (bytesRead = readInternal(this.oneByte, 0, this.oneByte.length)));
/*      */       
/* 1000 */       assert 1 == bytesRead || -1 == bytesRead;
/* 1001 */       return (1 == bytesRead) ? this.oneByte[0] : -1; }
/*      */ 
/*      */     
/*      */     public int read(byte[] b) throws IOException {
/* 1005 */       return readInternal(b, 0, b.length);
/*      */     }
/*      */     
/*      */     public int read(byte[] b, int offset, int maxBytes) throws IOException {
/* 1009 */       return readInternal(b, offset, maxBytes);
/*      */     }
/*      */ 
/*      */     
/*      */     private int readInternal(byte[] b, int offset, int maxBytes) throws IOException {
/*      */       int bytesRead;
/* 1015 */       if (TDSChannel.logger.isLoggable(Level.FINEST)) {
/* 1016 */         TDSChannel.logger.finest(toString() + " Reading " + toString() + " bytes");
/*      */       }
/*      */       try {
/* 1019 */         bytesRead = this.filteredStream.read(b, offset, maxBytes);
/* 1020 */       } catch (IOException e) {
/* 1021 */         if (TDSChannel.logger.isLoggable(Level.FINER)) {
/* 1022 */           TDSChannel.logger.finer(toString() + " " + toString());
/*      */         }
/* 1024 */         TDSChannel.logger.finer(toString() + " Reading bytes threw exception:" + toString());
/* 1025 */         throw e;
/*      */       } 
/*      */       
/* 1028 */       if (TDSChannel.logger.isLoggable(Level.FINEST)) {
/* 1029 */         TDSChannel.logger.finest(toString() + " Read " + toString() + " bytes");
/*      */       }
/* 1031 */       return bytesRead;
/*      */     }
/*      */     
/*      */     public boolean markSupported() {
/* 1035 */       boolean markSupported = this.filteredStream.markSupported();
/*      */       
/* 1037 */       if (TDSChannel.logger.isLoggable(Level.FINEST)) {
/* 1038 */         TDSChannel.logger.finest(toString() + " Returning markSupported: " + toString());
/*      */       }
/* 1040 */       return markSupported;
/*      */     }
/*      */     
/*      */     public void mark(int readLimit) {
/* 1044 */       if (TDSChannel.logger.isLoggable(Level.FINEST)) {
/* 1045 */         TDSChannel.logger.finest(toString() + " Marking next " + toString() + " bytes");
/*      */       }
/* 1047 */       this.filteredStream.mark(readLimit);
/*      */     }
/*      */     
/*      */     public void reset() throws IOException {
/* 1051 */       if (TDSChannel.logger.isLoggable(Level.FINEST)) {
/* 1052 */         TDSChannel.logger.finest(toString() + " Resetting to previous mark");
/*      */       }
/* 1054 */       this.filteredStream.reset();
/*      */     }
/*      */     
/*      */     public void close() throws IOException {
/* 1058 */       if (TDSChannel.logger.isLoggable(Level.FINEST)) {
/* 1059 */         TDSChannel.logger.finest(toString() + " Closing");
/*      */       }
/* 1061 */       this.filteredStream.close();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final class ProxyOutputStream
/*      */     extends OutputStream
/*      */   {
/*      */     private OutputStream filteredStream;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final byte[] singleByte;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     ProxyOutputStream(OutputStream os) {
/* 1096 */       this.singleByte = new byte[1]; this.filteredStream = os;
/*      */     } final void setFilteredStream(OutputStream os) { this.filteredStream = os; } public void close() throws IOException { if (TDSChannel.logger.isLoggable(Level.FINEST)) TDSChannel.logger.finest(toString() + " Closing");  this.filteredStream.close(); }
/*      */     public void flush() throws IOException { if (TDSChannel.logger.isLoggable(Level.FINEST)) TDSChannel.logger.finest(toString() + " Flushing");  this.filteredStream.flush(); }
/* 1099 */     public void write(int b) throws IOException { this.singleByte[0] = (byte)(b & 0xFF);
/* 1100 */       writeInternal(this.singleByte, 0, this.singleByte.length); }
/*      */ 
/*      */     
/*      */     public void write(byte[] b) throws IOException {
/* 1104 */       writeInternal(b, 0, b.length);
/*      */     }
/*      */     
/*      */     public void write(byte[] b, int off, int len) throws IOException {
/* 1108 */       writeInternal(b, off, len);
/*      */     }
/*      */     
/*      */     private void writeInternal(byte[] b, int off, int len) throws IOException {
/* 1112 */       if (TDSChannel.logger.isLoggable(Level.FINEST)) {
/* 1113 */         TDSChannel.logger.finest(toString() + " Writing " + toString() + " bytes");
/*      */       }
/* 1115 */       this.filteredStream.write(b, off, len);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private class ProxySocket
/*      */     extends Socket
/*      */   {
/*      */     private final TDSChannel tdsChannel;
/*      */ 
/*      */     
/*      */     private final Logger logger;
/*      */ 
/*      */     
/*      */     private final String logContext;
/*      */     
/*      */     private final TDSChannel.ProxyInputStream proxyInputStream;
/*      */     
/*      */     private final TDSChannel.ProxyOutputStream proxyOutputStream;
/*      */ 
/*      */     
/*      */     ProxySocket(TDSChannel tdsChannel) {
/* 1138 */       this.tdsChannel = tdsChannel;
/* 1139 */       this.logger = tdsChannel.getLogger();
/* 1140 */       this.logContext = tdsChannel.toString() + " (ProxySocket):";
/*      */ 
/*      */       
/* 1143 */       TDSChannel.SSLHandshakeOutputStream sslHandshakeOutputStream = new TDSChannel.SSLHandshakeOutputStream(tdsChannel);
/* 1144 */       TDSChannel.SSLHandshakeInputStream sslHandshakeInputStream = new TDSChannel.SSLHandshakeInputStream(tdsChannel, sslHandshakeOutputStream);
/*      */       
/* 1146 */       this.proxyOutputStream = new TDSChannel.ProxyOutputStream(sslHandshakeOutputStream);
/* 1147 */       this.proxyInputStream = new TDSChannel.ProxyInputStream(sslHandshakeInputStream);
/*      */     }
/*      */     
/*      */     void setStreams(InputStream is, OutputStream os) {
/* 1151 */       this.proxyInputStream.setFilteredStream(is);
/* 1152 */       this.proxyOutputStream.setFilteredStream(os);
/*      */     }
/*      */     
/*      */     public InputStream getInputStream() throws IOException {
/* 1156 */       if (this.logger.isLoggable(Level.FINEST)) {
/* 1157 */         this.logger.finest(this.logContext + " Getting input stream");
/*      */       }
/* 1159 */       return this.proxyInputStream;
/*      */     }
/*      */     
/*      */     public OutputStream getOutputStream() throws IOException {
/* 1163 */       if (this.logger.isLoggable(Level.FINEST)) {
/* 1164 */         this.logger.finest(this.logContext + " Getting output stream");
/*      */       }
/* 1166 */       return this.proxyOutputStream;
/*      */     }
/*      */ 
/*      */     
/*      */     public InetAddress getInetAddress() {
/* 1171 */       return this.tdsChannel.tcpSocket.getInetAddress();
/*      */     }
/*      */     
/*      */     public boolean getKeepAlive() throws SocketException {
/* 1175 */       return this.tdsChannel.tcpSocket.getKeepAlive();
/*      */     }
/*      */     
/*      */     public InetAddress getLocalAddress() {
/* 1179 */       return this.tdsChannel.tcpSocket.getLocalAddress();
/*      */     }
/*      */     
/*      */     public int getLocalPort() {
/* 1183 */       return this.tdsChannel.tcpSocket.getLocalPort();
/*      */     }
/*      */     
/*      */     public SocketAddress getLocalSocketAddress() {
/* 1187 */       return this.tdsChannel.tcpSocket.getLocalSocketAddress();
/*      */     }
/*      */     
/*      */     public boolean getOOBInline() throws SocketException {
/* 1191 */       return this.tdsChannel.tcpSocket.getOOBInline();
/*      */     }
/*      */     
/*      */     public int getPort() {
/* 1195 */       return this.tdsChannel.tcpSocket.getPort();
/*      */     }
/*      */     
/*      */     public int getReceiveBufferSize() throws SocketException {
/* 1199 */       return this.tdsChannel.tcpSocket.getReceiveBufferSize();
/*      */     }
/*      */     
/*      */     public SocketAddress getRemoteSocketAddress() {
/* 1203 */       return this.tdsChannel.tcpSocket.getRemoteSocketAddress();
/*      */     }
/*      */     
/*      */     public boolean getReuseAddress() throws SocketException {
/* 1207 */       return this.tdsChannel.tcpSocket.getReuseAddress();
/*      */     }
/*      */     
/*      */     public int getSendBufferSize() throws SocketException {
/* 1211 */       return this.tdsChannel.tcpSocket.getSendBufferSize();
/*      */     }
/*      */     
/*      */     public int getSoLinger() throws SocketException {
/* 1215 */       return this.tdsChannel.tcpSocket.getSoLinger();
/*      */     }
/*      */     
/*      */     public int getSoTimeout() throws SocketException {
/* 1219 */       return this.tdsChannel.tcpSocket.getSoTimeout();
/*      */     }
/*      */     
/*      */     public boolean getTcpNoDelay() throws SocketException {
/* 1223 */       return this.tdsChannel.tcpSocket.getTcpNoDelay();
/*      */     }
/*      */     
/*      */     public int getTrafficClass() throws SocketException {
/* 1227 */       return this.tdsChannel.tcpSocket.getTrafficClass();
/*      */     }
/*      */     
/*      */     public boolean isBound() {
/* 1231 */       return true;
/*      */     }
/*      */     
/*      */     public boolean isClosed() {
/* 1235 */       return false;
/*      */     }
/*      */     
/*      */     public boolean isConnected() {
/* 1239 */       return true;
/*      */     }
/*      */     
/*      */     public boolean isInputShutdown() {
/* 1243 */       return false;
/*      */     }
/*      */     
/*      */     public boolean isOutputShutdown() {
/* 1247 */       return false;
/*      */     }
/*      */     
/*      */     public String toString() {
/* 1251 */       return this.tdsChannel.tcpSocket.toString();
/*      */     }
/*      */     
/*      */     public SocketChannel getChannel() {
/* 1255 */       return null;
/*      */     }
/*      */ 
/*      */     
/*      */     public void bind(SocketAddress bindPoint) throws IOException {
/* 1260 */       this.logger.finer(this.logContext + " Disallowed call to bind.  Throwing IOException.");
/* 1261 */       throw new IOException();
/*      */     }
/*      */     
/*      */     public void connect(SocketAddress endpoint) throws IOException {
/* 1265 */       this.logger.finer(this.logContext + " Disallowed call to connect (without timeout).  Throwing IOException.");
/* 1266 */       throw new IOException();
/*      */     }
/*      */     
/*      */     public void connect(SocketAddress endpoint, int timeout) throws IOException {
/* 1270 */       this.logger.finer(this.logContext + " Disallowed call to connect (with timeout).  Throwing IOException.");
/* 1271 */       throw new IOException();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void close() throws IOException {
/* 1277 */       if (this.logger.isLoggable(Level.FINER))
/* 1278 */         this.logger.finer(this.logContext + " Ignoring close"); 
/*      */     }
/*      */     
/*      */     public void setReceiveBufferSize(int size) throws SocketException {
/* 1282 */       if (this.logger.isLoggable(Level.FINER))
/* 1283 */         this.logger.finer(toString() + " Ignoring setReceiveBufferSize size:" + toString()); 
/*      */     }
/*      */     
/*      */     public void setSendBufferSize(int size) throws SocketException {
/* 1287 */       if (this.logger.isLoggable(Level.FINER))
/* 1288 */         this.logger.finer(toString() + " Ignoring setSendBufferSize size:" + toString()); 
/*      */     }
/*      */     
/*      */     public void setReuseAddress(boolean on) throws SocketException {
/* 1292 */       if (this.logger.isLoggable(Level.FINER))
/* 1293 */         this.logger.finer(toString() + " Ignoring setReuseAddress"); 
/*      */     }
/*      */     
/*      */     public void setSoLinger(boolean on, int linger) throws SocketException {
/* 1297 */       if (this.logger.isLoggable(Level.FINER))
/* 1298 */         this.logger.finer(toString() + " Ignoring setSoLinger"); 
/*      */     }
/*      */     
/*      */     public void setSoTimeout(int timeout) throws SocketException {
/* 1302 */       if (this.logger.isLoggable(Level.FINER))
/* 1303 */         this.logger.finer(toString() + " Ignoring setSoTimeout"); 
/*      */     }
/*      */     
/*      */     public void setTcpNoDelay(boolean on) throws SocketException {
/* 1307 */       if (this.logger.isLoggable(Level.FINER))
/* 1308 */         this.logger.finer(toString() + " Ignoring setTcpNoDelay"); 
/*      */     }
/*      */     
/*      */     public void setTrafficClass(int tc) throws SocketException {
/* 1312 */       if (this.logger.isLoggable(Level.FINER))
/* 1313 */         this.logger.finer(toString() + " Ignoring setTrafficClass"); 
/*      */     }
/*      */     
/*      */     public void shutdownInput() throws IOException {
/* 1317 */       if (this.logger.isLoggable(Level.FINER))
/* 1318 */         this.logger.finer(toString() + " Ignoring shutdownInput"); 
/*      */     }
/*      */     
/*      */     public void shutdownOutput() throws IOException {
/* 1322 */       if (this.logger.isLoggable(Level.FINER))
/* 1323 */         this.logger.finer(toString() + " Ignoring shutdownOutput"); 
/*      */     }
/*      */     
/*      */     public void sendUrgentData(int data) throws IOException {
/* 1327 */       if (this.logger.isLoggable(Level.FINER))
/* 1328 */         this.logger.finer(toString() + " Ignoring sendUrgentData"); 
/*      */     }
/*      */     
/*      */     public void setKeepAlive(boolean on) throws SocketException {
/* 1332 */       if (this.logger.isLoggable(Level.FINER))
/* 1333 */         this.logger.finer(toString() + " Ignoring setKeepAlive"); 
/*      */     }
/*      */     
/*      */     public void setOOBInline(boolean on) throws SocketException {
/* 1337 */       if (this.logger.isLoggable(Level.FINER)) {
/* 1338 */         this.logger.finer(toString() + " Ignoring setOOBInline");
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private final class PermissiveX509TrustManager
/*      */     implements X509TrustManager
/*      */   {
/*      */     private final TDSChannel tdsChannel;
/*      */     
/*      */     private final Logger logger;
/*      */     
/*      */     private final String logContext;
/*      */     
/*      */     PermissiveX509TrustManager(TDSChannel tdsChannel) {
/* 1354 */       this.tdsChannel = tdsChannel;
/* 1355 */       this.logger = tdsChannel.getLogger();
/* 1356 */       this.logContext = tdsChannel.toString() + " (PermissiveX509TrustManager):";
/*      */     }
/*      */     
/*      */     public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
/* 1360 */       if (this.logger.isLoggable(Level.FINER))
/* 1361 */         this.logger.finer(this.logContext + " Trusting client certificate (!)"); 
/*      */     }
/*      */     
/*      */     public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
/* 1365 */       if (this.logger.isLoggable(Level.FINER))
/* 1366 */         this.logger.finer(this.logContext + " Trusting server certificate"); 
/*      */     }
/*      */     
/*      */     public X509Certificate[] getAcceptedIssuers() {
/* 1370 */       return new X509Certificate[0];
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private final class HostNameOverrideX509TrustManager
/*      */     implements X509TrustManager
/*      */   {
/*      */     private final Logger logger;
/*      */     
/*      */     private final String logContext;
/*      */     
/*      */     private final X509TrustManager defaultTrustManager;
/*      */     private String hostName;
/*      */     
/*      */     HostNameOverrideX509TrustManager(TDSChannel tdsChannel, X509TrustManager tm, String hostName) {
/* 1386 */       this.logger = tdsChannel.getLogger();
/* 1387 */       this.logContext = tdsChannel.toString() + " (HostNameOverrideX509TrustManager):";
/* 1388 */       this.defaultTrustManager = tm;
/*      */       
/* 1390 */       this.hostName = hostName.toLowerCase(Locale.ENGLISH);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String parseCommonName(String distinguishedName) {
/* 1399 */       int index = distinguishedName.indexOf("cn=");
/* 1400 */       if (index == -1) {
/* 1401 */         return null;
/*      */       }
/* 1403 */       distinguishedName = distinguishedName.substring(index + 3);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1409 */       for (index = 0; index < distinguishedName.length() && 
/* 1410 */         distinguishedName.charAt(index) != ','; index++);
/*      */ 
/*      */ 
/*      */       
/* 1414 */       String commonName = distinguishedName.substring(0, index);
/*      */       
/* 1416 */       if (commonName.length() > 1 && '"' == commonName.charAt(0)) {
/* 1417 */         if ('"' == commonName.charAt(commonName.length() - 1)) {
/* 1418 */           commonName = commonName.substring(1, commonName.length() - 1);
/*      */         } else {
/*      */           
/* 1421 */           commonName = null;
/*      */         } 
/*      */       }
/* 1424 */       return commonName;
/*      */     }
/*      */ 
/*      */     
/*      */     private boolean validateServerName(String nameInCert) {
/* 1429 */       if (null == nameInCert) {
/* 1430 */         if (this.logger.isLoggable(Level.FINER)) {
/* 1431 */           this.logger.finer(this.logContext + " Failed to parse the name from the certificate or name is empty.");
/*      */         }
/* 1433 */         return false;
/*      */       } 
/*      */       
/* 1436 */       if (!nameInCert.startsWith("xn--") && nameInCert.contains("*")) {
/* 1437 */         int hostIndex = 0, certIndex = 0, match = 0, startIndex = -1, periodCount = 0;
/* 1438 */         while (hostIndex < this.hostName.length()) {
/* 1439 */           if ('.' == this.hostName.charAt(hostIndex)) {
/* 1440 */             periodCount++;
/*      */           }
/* 1442 */           if (certIndex < nameInCert.length() && this.hostName.charAt(hostIndex) == nameInCert.charAt(certIndex)) {
/* 1443 */             hostIndex++;
/* 1444 */             certIndex++; continue;
/* 1445 */           }  if (certIndex < nameInCert.length() && '*' == nameInCert.charAt(certIndex)) {
/* 1446 */             startIndex = certIndex;
/* 1447 */             match = hostIndex;
/* 1448 */             certIndex++; continue;
/* 1449 */           }  if (startIndex != -1 && 0 == periodCount) {
/* 1450 */             certIndex = startIndex + 1;
/*      */             
/* 1452 */             hostIndex = ++match; continue;
/*      */           } 
/* 1454 */           logFailMessage(nameInCert);
/* 1455 */           return false;
/*      */         } 
/*      */         
/* 1458 */         if (nameInCert.length() == certIndex && periodCount > 1) {
/* 1459 */           logSuccessMessage(nameInCert);
/* 1460 */           return true;
/*      */         } 
/* 1462 */         logFailMessage(nameInCert);
/* 1463 */         return false;
/*      */       } 
/*      */ 
/*      */       
/* 1467 */       if (!nameInCert.equals(this.hostName)) {
/* 1468 */         logFailMessage(nameInCert);
/* 1469 */         return false;
/*      */       } 
/* 1471 */       logSuccessMessage(nameInCert);
/* 1472 */       return true;
/*      */     }
/*      */     
/*      */     private void logFailMessage(String nameInCert) {
/* 1476 */       if (this.logger.isLoggable(Level.FINER)) {
/* 1477 */         this.logger.finer(this.logContext + " The name in certificate " + this.logContext + " does not match with the server name " + nameInCert + ".");
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     private void logSuccessMessage(String nameInCert) {
/* 1483 */       if (this.logger.isLoggable(Level.FINER)) {
/* 1484 */         this.logger.finer(this.logContext + " The name in certificate:" + this.logContext + " validated against server name " + nameInCert + ".");
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
/* 1490 */       if (this.logger.isLoggable(Level.FINEST))
/* 1491 */         this.logger.finest(this.logContext + " Forwarding ClientTrusted."); 
/* 1492 */       this.defaultTrustManager.checkClientTrusted(chain, authType);
/*      */       
/* 1494 */       for (X509Certificate cert : chain) {
/* 1495 */         cert.checkValidity();
/*      */       }
/*      */     }
/*      */     
/*      */     public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
/* 1500 */       if (this.logger.isLoggable(Level.FINEST))
/* 1501 */         this.logger.finest(this.logContext + " Forwarding Trusting server certificate"); 
/* 1502 */       this.defaultTrustManager.checkServerTrusted(chain, authType);
/*      */       
/* 1504 */       for (X509Certificate cert : chain) {
/* 1505 */         cert.checkValidity();
/*      */       }
/* 1507 */       if (this.logger.isLoggable(Level.FINEST)) {
/* 1508 */         this.logger.finest(this.logContext + " default serverTrusted succeeded proceeding with server name validation");
/*      */       }
/* 1510 */       validateServerNameInCertificate(chain[0]);
/*      */     }
/*      */     
/*      */     private void validateServerNameInCertificate(X509Certificate cert) throws CertificateException {
/* 1514 */       String nameInCertDN = cert.getSubjectX500Principal().getName("canonical");
/* 1515 */       if (this.logger.isLoggable(Level.FINER)) {
/* 1516 */         this.logger.finer(this.logContext + " Validating the server name:" + this.logContext);
/* 1517 */         this.logger.finer(this.logContext + " The DN name in certificate:" + this.logContext);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1523 */       String subjectCN = parseCommonName(nameInCertDN);
/*      */       
/* 1525 */       boolean isServerNameValidated = validateServerName(subjectCN);
/*      */       
/* 1527 */       if (!isServerNameValidated) {
/*      */         
/* 1529 */         Collection<List<?>> sanCollection = cert.getSubjectAlternativeNames();
/*      */         
/* 1531 */         if (sanCollection != null)
/*      */         {
/* 1533 */           for (List<?> sanEntry : sanCollection) {
/*      */             
/* 1535 */             if (sanEntry != null && sanEntry.size() >= 2) {
/* 1536 */               Object key = sanEntry.get(0);
/* 1537 */               Object value = sanEntry.get(1);
/*      */               
/* 1539 */               if (this.logger.isLoggable(Level.FINER)) {
/* 1540 */                 this.logger.finer(this.logContext + "Key: " + this.logContext + "; KeyClass:" + key + ";value: " + (
/* 1541 */                     (key != null) ? (String)key.getClass() : null) + "; valueClass:" + value);
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1553 */               if (key != null && key instanceof Integer && ((Integer)key).intValue() == 2) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/* 1560 */                 if (value != null && value instanceof String) {
/* 1561 */                   String dnsNameInSANCert = (String)value;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                   
/* 1567 */                   dnsNameInSANCert = dnsNameInSANCert.toLowerCase(Locale.ENGLISH);
/*      */                   
/* 1569 */                   isServerNameValidated = validateServerName(dnsNameInSANCert);
/*      */                   
/* 1571 */                   if (isServerNameValidated) {
/* 1572 */                     if (this.logger.isLoggable(Level.FINER)) {
/* 1573 */                       this.logger.finer(this.logContext + " found a valid name in certificate: " + this.logContext);
/*      */                     }
/*      */                     
/*      */                     break;
/*      */                   } 
/*      */                 } 
/*      */                 
/* 1580 */                 if (this.logger.isLoggable(Level.FINER)) {
/* 1581 */                   this.logger.finer(this.logContext + " the following name in certificate does not match the serverName: " + this.logContext);
/*      */                 }
/*      */               } 
/*      */               
/*      */               continue;
/*      */             } 
/*      */             
/* 1588 */             if (this.logger.isLoggable(Level.FINER)) {
/* 1589 */               this.logger.finer(this.logContext + " found an invalid san entry: " + this.logContext);
/*      */             }
/*      */           } 
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1597 */       if (!isServerNameValidated) {
/* 1598 */         String msg = SQLServerException.getErrString("R_certNameFailed");
/* 1599 */         throw new CertificateException(msg);
/*      */       } 
/*      */     }
/*      */     
/*      */     public X509Certificate[] getAcceptedIssuers() {
/* 1604 */       return this.defaultTrustManager.getAcceptedIssuers();
/*      */     }
/*      */   }
/*      */   
/*      */   enum SSLHandhsakeState {
/* 1609 */     SSL_HANDHSAKE_NOT_STARTED,
/* 1610 */     SSL_HANDHSAKE_STARTED,
/* 1611 */     SSL_HANDHSAKE_COMPLETE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void enableSSL(String host, int port, String clientCertificate, String clientKey, String clientKeyPassword) throws SQLServerException {
/* 1633 */     Provider tmfProvider = null;
/* 1634 */     Provider sslContextProvider = null;
/* 1635 */     Provider ksProvider = null;
/* 1636 */     String tmfDefaultAlgorithm = null;
/* 1637 */     SSLHandhsakeState handshakeState = SSLHandhsakeState.SSL_HANDHSAKE_NOT_STARTED;
/*      */     
/* 1639 */     boolean isFips = false;
/* 1640 */     String trustStoreType = null;
/* 1641 */     String sslProtocol = null;
/*      */ 
/*      */     
/*      */     try {
/* 1645 */       if (logger.isLoggable(Level.FINER)) {
/* 1646 */         logger.finer(toString() + " Enabling SSL...");
/*      */       }
/*      */       
/* 1649 */       String trustStoreFileName = this.con.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.TRUST_STORE.toString());
/*      */       
/* 1651 */       String trustStorePassword = this.con.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.TRUST_STORE_PASSWORD.toString());
/*      */       
/* 1653 */       String hostNameInCertificate = this.con.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.HOSTNAME_IN_CERTIFICATE.toString());
/*      */ 
/*      */       
/* 1656 */       trustStoreType = this.con.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.TRUST_STORE_TYPE.toString());
/*      */       
/* 1658 */       if (StringUtils.isEmpty(trustStoreType)) {
/* 1659 */         trustStoreType = SQLServerDriverStringProperty.TRUST_STORE_TYPE.getDefaultValue();
/*      */       }
/*      */       
/* 1662 */       isFips = Boolean.valueOf(this.con.activeConnectionProperties
/* 1663 */           .getProperty(SQLServerDriverBooleanProperty.FIPS.toString())).booleanValue();
/*      */       
/* 1665 */       sslProtocol = this.con.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.SSL_PROTOCOL.toString());
/*      */       
/* 1667 */       if (isFips) {
/* 1668 */         validateFips(trustStoreType, trustStoreFileName);
/*      */       }
/*      */       
/* 1671 */       assert 0 == this.con.getRequestedEncryptionLevel() || 1 == this.con
/* 1672 */         .getRequestedEncryptionLevel();
/*      */       
/* 1674 */       assert 0 == this.con.getNegotiatedEncryptionLevel() || 1 == this.con
/* 1675 */         .getNegotiatedEncryptionLevel() || 3 == this.con
/* 1676 */         .getNegotiatedEncryptionLevel();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1681 */       TrustManager[] tm = null;
/* 1682 */       if (0 == this.con.getRequestedEncryptionLevel() || (1 == this.con
/* 1683 */         .getRequestedEncryptionLevel() && this.con.trustServerCertificate())) {
/* 1684 */         if (logger.isLoggable(Level.FINER)) {
/* 1685 */           logger.finer(toString() + " SSL handshake will trust any certificate");
/*      */         }
/* 1687 */         tm = new TrustManager[] { new PermissiveX509TrustManager(this) };
/*      */ 
/*      */       
/*      */       }
/* 1691 */       else if (this.con.getTrustManagerClass() != null) {
/* 1692 */         Object[] msgArgs = { "trustManagerClass", "javax.net.ssl.TrustManager" };
/* 1693 */         tm = new TrustManager[] { Util.<TrustManager>newInstance(TrustManager.class, this.con.getTrustManagerClass(), this.con
/* 1694 */               .getTrustManagerConstructorArg(), msgArgs) };
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 1699 */         if (logger.isLoggable(Level.FINER)) {
/* 1700 */           logger.finer(toString() + " SSL handshake will validate server certificate");
/*      */         }
/* 1702 */         KeyStore ks = null;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1707 */         if (null == trustStoreFileName && null == trustStorePassword) {
/* 1708 */           if (logger.isLoggable(Level.FINER)) {
/* 1709 */             logger.finer(toString() + " Using system default trust store and password");
/*      */           
/*      */           }
/*      */         
/*      */         }
/*      */         else {
/*      */ 
/*      */           
/* 1717 */           if (logger.isLoggable(Level.FINEST)) {
/* 1718 */             logger.finest(toString() + " Finding key store interface");
/*      */           }
/* 1720 */           ks = KeyStore.getInstance(trustStoreType);
/* 1721 */           ksProvider = ks.getProvider();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1727 */           InputStream is = loadTrustStore(trustStoreFileName);
/*      */ 
/*      */ 
/*      */           
/* 1731 */           if (logger.isLoggable(Level.FINEST)) {
/* 1732 */             logger.finest(toString() + " Loading key store");
/*      */           }
/*      */           try {
/* 1735 */             ks.load(is, (null == trustStorePassword) ? null : trustStorePassword.toCharArray());
/*      */           } finally {
/*      */             
/* 1738 */             this.con.activeConnectionProperties
/* 1739 */               .remove(SQLServerDriverStringProperty.TRUST_STORE_PASSWORD.toString());
/*      */ 
/*      */             
/* 1742 */             if (null != is) {
/*      */               try {
/* 1744 */                 is.close();
/* 1745 */               } catch (IOException e) {
/* 1746 */                 if (logger.isLoggable(Level.FINE)) {
/* 1747 */                   logger.fine(toString() + " Ignoring error closing trust material InputStream...");
/*      */                 }
/*      */               } 
/*      */             }
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1760 */         TrustManagerFactory tmf = null;
/*      */         
/* 1762 */         if (logger.isLoggable(Level.FINEST)) {
/* 1763 */           logger.finest(toString() + " Locating X.509 trust manager factory");
/*      */         }
/* 1765 */         tmfDefaultAlgorithm = TrustManagerFactory.getDefaultAlgorithm();
/* 1766 */         tmf = TrustManagerFactory.getInstance(tmfDefaultAlgorithm);
/* 1767 */         tmfProvider = tmf.getProvider();
/*      */ 
/*      */ 
/*      */         
/* 1771 */         if (logger.isLoggable(Level.FINEST)) {
/* 1772 */           logger.finest(toString() + " Getting trust manager");
/*      */         }
/* 1774 */         tmf.init(ks);
/* 1775 */         tm = tmf.getTrustManagers();
/*      */ 
/*      */         
/* 1778 */         if (!isFips) {
/* 1779 */           if (null != hostNameInCertificate) {
/* 1780 */             tm = new TrustManager[] { new HostNameOverrideX509TrustManager(this, (X509TrustManager)tm[0], hostNameInCertificate) };
/*      */           } else {
/*      */             
/* 1783 */             tm = new TrustManager[] { new HostNameOverrideX509TrustManager(this, (X509TrustManager)tm[0], host) };
/*      */           } 
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1791 */       SSLContext sslContext = null;
/*      */       
/* 1793 */       if (logger.isLoggable(Level.FINEST)) {
/* 1794 */         logger.finest(toString() + " Getting TLS or better SSL context");
/*      */       }
/*      */       
/* 1797 */       KeyManager[] km = (null != clientCertificate && clientCertificate.length() > 0) ? SQLServerCertificateUtils.getKeyManagerFromFile(clientCertificate, clientKey, clientKeyPassword) : null;
/*      */       
/* 1799 */       sslContext = SSLContext.getInstance(sslProtocol);
/* 1800 */       sslContextProvider = sslContext.getProvider();
/*      */       
/* 1802 */       if (logger.isLoggable(Level.FINEST)) {
/* 1803 */         logger.finest(toString() + " Initializing SSL context");
/*      */       }
/* 1805 */       sslContext.init(km, tm, null);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1810 */       this.proxySocket = new ProxySocket(this);
/*      */       
/* 1812 */       if (logger.isLoggable(Level.FINEST)) {
/* 1813 */         logger.finest(toString() + " Creating SSL socket");
/*      */       }
/*      */       
/* 1816 */       this.sslSocket = (SSLSocket)sslContext.getSocketFactory().createSocket(this.proxySocket, host, port, false);
/*      */ 
/*      */       
/* 1819 */       if (logger.isLoggable(Level.FINER)) {
/* 1820 */         logger.finer(toString() + " Starting SSL handshake");
/*      */       }
/*      */       
/* 1823 */       handshakeState = SSLHandhsakeState.SSL_HANDHSAKE_STARTED;
/* 1824 */       this.sslSocket.startHandshake();
/* 1825 */       handshakeState = SSLHandhsakeState.SSL_HANDHSAKE_COMPLETE;
/*      */ 
/*      */       
/* 1828 */       if (logger.isLoggable(Level.FINEST)) {
/* 1829 */         logger.finest(toString() + " Rewiring proxy streams after handshake");
/*      */       }
/* 1831 */       this.proxySocket.setStreams(this.inputStream, this.outputStream);
/*      */ 
/*      */       
/* 1834 */       if (logger.isLoggable(Level.FINEST)) {
/* 1835 */         logger.finest(toString() + " Getting SSL InputStream");
/*      */       }
/* 1837 */       this.inputStream = this.sslSocket.getInputStream();
/*      */       
/* 1839 */       if (logger.isLoggable(Level.FINEST)) {
/* 1840 */         logger.finest(toString() + " Getting SSL OutputStream");
/*      */       }
/* 1842 */       this.outputStream = this.sslSocket.getOutputStream();
/*      */ 
/*      */       
/* 1845 */       this.channelSocket = this.sslSocket;
/*      */ 
/*      */       
/* 1848 */       String tlsProtocol = this.sslSocket.getSession().getProtocol();
/* 1849 */       if (SSLProtocol.TLS_V10.toString().equalsIgnoreCase(tlsProtocol) || SSLProtocol.TLS_V11
/* 1850 */         .toString().equalsIgnoreCase(tlsProtocol)) {
/* 1851 */         String warningMsg = tlsProtocol + " was negotiated. Please update server and client to use TLSv1.2 at minimum.";
/*      */         
/* 1853 */         logger.warning(warningMsg);
/* 1854 */         this.con.addWarning(warningMsg);
/*      */       } 
/*      */       
/* 1857 */       if (logger.isLoggable(Level.FINER))
/* 1858 */         logger.finer(toString() + " SSL enabled"); 
/* 1859 */     } catch (Exception e) {
/*      */       
/* 1861 */       if (logger.isLoggable(Level.FINER)) {
/* 1862 */         logger.log(Level.FINER, e.getMessage(), e);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1868 */       if (logger.isLoggable(Level.FINER)) {
/* 1869 */         logger.log(Level.FINER, "java.security path: " + JAVA_SECURITY + "\nSecurity providers: " + 
/* 1870 */             Arrays.<Provider>asList(Security.getProviders()) + "\n" + (
/* 1871 */             (null != sslContextProvider) ? ("SSLContext provider info: " + sslContextProvider.getInfo() + "\nSSLContext provider services:\n" + sslContextProvider
/* 1872 */             .getServices() + "\n") : 
/* 1873 */             "") + (
/* 1874 */             (null != tmfProvider) ? ("TrustManagerFactory provider info: " + tmfProvider.getInfo() + "\n") : 
/* 1875 */             "") + (
/* 1876 */             (null != tmfDefaultAlgorithm) ? ("TrustManagerFactory default algorithm: " + tmfDefaultAlgorithm + "\n") : 
/* 1877 */             "") + (
/* 1878 */             (null != ksProvider) ? ("KeyStore provider info: " + ksProvider.getInfo() + "\n") : "") + "java.ext.dirs: " + 
/* 1879 */             System.getProperty("java.ext.dirs"));
/*      */       }
/* 1881 */       String localizedMessage = e.getLocalizedMessage();
/* 1882 */       String errMsg = (localizedMessage != null) ? localizedMessage : e.getMessage();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1887 */       String causeErrMsg = null;
/* 1888 */       Throwable cause = e.getCause();
/* 1889 */       if (cause != null) {
/* 1890 */         String causeLocalizedMessage = cause.getLocalizedMessage();
/* 1891 */         causeErrMsg = (causeLocalizedMessage != null) ? causeLocalizedMessage : cause.getMessage();
/*      */       } 
/*      */       
/* 1894 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_sslFailed"));
/* 1895 */       Object[] msgArgs = { errMsg };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1901 */       if (errMsg != null && errMsg.contains(" ClientConnectionId:")) {
/* 1902 */         errMsg = errMsg.substring(0, errMsg.indexOf(" ClientConnectionId:"));
/*      */       }
/*      */       
/* 1905 */       if (causeErrMsg != null && causeErrMsg.contains(" ClientConnectionId:")) {
/* 1906 */         causeErrMsg = causeErrMsg.substring(0, causeErrMsg
/* 1907 */             .indexOf(" ClientConnectionId:"));
/*      */       }
/*      */ 
/*      */       
/* 1911 */       if (e instanceof IOException && SSLHandhsakeState.SSL_HANDHSAKE_STARTED == handshakeState && (
/* 1912 */         SQLServerException.getErrString("R_truncatedServerResponse").equals(errMsg) || 
/* 1913 */         SQLServerException.getErrString("R_truncatedServerResponse").equals(causeErrMsg))) {
/* 1914 */         this.con.terminate(7, form.format(msgArgs), e);
/*      */       } else {
/* 1916 */         this.con.terminate(5, form.format(msgArgs), e);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void validateFips(String trustStoreType, String trustStoreFileName) throws SQLServerException {
/* 1935 */     boolean isValid = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1941 */     String strError = SQLServerException.getErrString("R_invalidFipsConfig");
/*      */     
/* 1943 */     boolean isEncryptOn = (1 == this.con.getRequestedEncryptionLevel());
/*      */     
/* 1945 */     boolean isValidTrustStoreType = !StringUtils.isEmpty(trustStoreType);
/* 1946 */     boolean isValidTrustStore = !StringUtils.isEmpty(trustStoreFileName);
/* 1947 */     boolean isTrustServerCertificate = this.con.trustServerCertificate();
/*      */     
/* 1949 */     if (isEncryptOn && !isTrustServerCertificate) {
/* 1950 */       isValid = true;
/* 1951 */       if (isValidTrustStore && !isValidTrustStoreType) {
/*      */         
/* 1953 */         isValid = false;
/* 1954 */         if (logger.isLoggable(Level.FINER)) {
/* 1955 */           logger.finer(toString() + "TrustStoreType is required alongside with TrustStore.");
/*      */         }
/*      */       } 
/*      */     } 
/* 1959 */     if (!isValid) {
/* 1960 */       throw new SQLServerException(strError, null, 0, null);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/* 1965 */   private static final String SEPARATOR = System.getProperty("file.separator");
/* 1966 */   private static final String JAVA_HOME = System.getProperty("java.home");
/* 1967 */   private static final String JAVA_SECURITY = JAVA_HOME + JAVA_HOME + "lib" + SEPARATOR + "security";
/* 1968 */   private static final String JSSECACERTS = JAVA_SECURITY + JAVA_SECURITY + "jssecacerts";
/* 1969 */   private static final String CACERTS = JAVA_SECURITY + JAVA_SECURITY + "cacerts";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final InputStream loadTrustStore(String trustStoreFileName) {
/* 1987 */     FileInputStream is = null;
/*      */ 
/*      */     
/* 1990 */     if (null != trustStoreFileName) {
/*      */       try {
/* 1992 */         if (logger.isLoggable(Level.FINEST)) {
/* 1993 */           logger.finest(toString() + " Opening specified trust store: " + toString());
/*      */         }
/* 1995 */         is = new FileInputStream(trustStoreFileName);
/* 1996 */       } catch (FileNotFoundException e) {
/* 1997 */         if (logger.isLoggable(Level.FINE)) {
/* 1998 */           logger.fine(toString() + " Trust store not found: " + toString());
/*      */ 
/*      */         
/*      */         }
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/* 2007 */     else if (null != (trustStoreFileName = System.getProperty("javax.net.ssl.trustStore"))) {
/*      */       try {
/* 2009 */         if (logger.isLoggable(Level.FINEST)) {
/* 2010 */           logger.finest(toString() + " Opening default trust store (from javax.net.ssl.trustStore): " + toString());
/*      */         }
/*      */         
/* 2013 */         is = new FileInputStream(trustStoreFileName);
/* 2014 */       } catch (FileNotFoundException e) {
/* 2015 */         if (logger.isLoggable(Level.FINE)) {
/* 2016 */           logger.fine(toString() + " Trust store not found: " + toString());
/*      */         }
/*      */       } 
/*      */     } else {
/*      */ 
/*      */       
/*      */       try {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2027 */         if (logger.isLoggable(Level.FINEST)) {
/* 2028 */           logger.finest(toString() + " Opening default trust store: " + toString());
/*      */         }
/* 2030 */         is = new FileInputStream(JSSECACERTS);
/* 2031 */       } catch (FileNotFoundException e) {
/* 2032 */         if (logger.isLoggable(Level.FINE)) {
/* 2033 */           logger.fine(toString() + " Trust store not found: " + toString());
/*      */         }
/*      */       } 
/*      */       
/* 2037 */       if (null == is) {
/*      */         try {
/* 2039 */           if (logger.isLoggable(Level.FINEST)) {
/* 2040 */             logger.finest(toString() + " Opening default trust store: " + toString());
/*      */           }
/* 2042 */           is = new FileInputStream(CACERTS);
/* 2043 */         } catch (FileNotFoundException e) {
/* 2044 */           if (logger.isLoggable(Level.FINE)) {
/* 2045 */             logger.fine(toString() + " Trust store not found: " + toString());
/*      */           }
/*      */         } 
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2053 */     return is;
/*      */   }
/*      */   
/*      */   final int read(byte[] data, int offset, int length) throws SQLServerException {
/*      */     try {
/* 2058 */       return this.inputStream.read(data, offset, length);
/* 2059 */     } catch (IOException e) {
/* 2060 */       if (logger.isLoggable(Level.FINE)) {
/* 2061 */         logger.fine(toString() + " read failed:" + toString());
/*      */       }
/* 2063 */       if (e instanceof java.net.SocketTimeoutException) {
/* 2064 */         this.con.terminate(8, e.getMessage(), e);
/*      */       } else {
/* 2066 */         this.con.terminate(3, e.getMessage(), e);
/*      */       } 
/*      */       
/* 2069 */       return 0;
/*      */     } 
/*      */   }
/*      */   
/*      */   final void write(byte[] data, int offset, int length) throws SQLServerException {
/*      */     try {
/* 2075 */       this.outputStream.write(data, offset, length);
/* 2076 */     } catch (IOException e) {
/* 2077 */       if (logger.isLoggable(Level.FINER)) {
/* 2078 */         logger.finer(toString() + " write failed:" + toString());
/*      */       }
/* 2080 */       this.con.terminate(3, e.getMessage(), e);
/*      */     } 
/*      */   }
/*      */   
/*      */   final void flush() throws SQLServerException {
/*      */     try {
/* 2086 */       this.outputStream.flush();
/* 2087 */     } catch (IOException e) {
/* 2088 */       if (logger.isLoggable(Level.FINER)) {
/* 2089 */         logger.finer(toString() + " flush failed:" + toString());
/*      */       }
/* 2091 */       this.con.terminate(3, e.getMessage(), e);
/*      */     } 
/*      */   }
/*      */   
/*      */   final void close() {
/* 2096 */     if (null != this.sslSocket) {
/* 2097 */       disableSSL();
/*      */     }
/* 2099 */     if (null != this.inputStream) {
/* 2100 */       if (logger.isLoggable(Level.FINEST)) {
/* 2101 */         logger.finest(toString() + ": Closing inputStream...");
/*      */       }
/*      */       try {
/* 2104 */         this.inputStream.close();
/* 2105 */       } catch (IOException e) {
/* 2106 */         if (logger.isLoggable(Level.FINE)) {
/* 2107 */           logger.log(Level.FINE, toString() + ": Ignored error closing inputStream", e);
/*      */         }
/*      */       } 
/*      */     } 
/* 2111 */     if (null != this.outputStream) {
/* 2112 */       if (logger.isLoggable(Level.FINEST)) {
/* 2113 */         logger.finest(toString() + ": Closing outputStream...");
/*      */       }
/*      */       try {
/* 2116 */         this.outputStream.close();
/* 2117 */       } catch (IOException e) {
/* 2118 */         if (logger.isLoggable(Level.FINE)) {
/* 2119 */           logger.log(Level.FINE, toString() + ": Ignored error closing outputStream", e);
/*      */         }
/*      */       } 
/*      */     } 
/* 2123 */     if (null != this.tcpSocket) {
/* 2124 */       if (logger.isLoggable(Level.FINER)) {
/* 2125 */         logger.finer(toString() + ": Closing TCP socket...");
/*      */       }
/*      */       try {
/* 2128 */         this.tcpSocket.close();
/* 2129 */       } catch (IOException e) {
/* 2130 */         if (logger.isLoggable(Level.FINE)) {
/* 2131 */           logger.log(Level.FINE, toString() + ": Ignored error closing socket", e);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void logPacket(byte[] data, int nStartOffset, int nLength, String messageDetail) {
/* 2149 */     assert 0 <= nLength && nLength <= data.length;
/* 2150 */     assert 0 <= nStartOffset && nStartOffset <= data.length;
/*      */     
/* 2152 */     char[] hexChars = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
/*      */     
/* 2154 */     char[] printableChars = { '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', ' ', '!', '"', '#', '$', '%', '&', '\'', '(', ')', '*', '+', ',', '-', '.', '/', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', ':', ';', '<', '=', '>', '?', '@', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '[', '\\', ']', '^', '_', '`', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '{', '|', '}', '~', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.' };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2174 */     char[] lineTemplate = { ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.' };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2182 */     char[] logLine = new char[lineTemplate.length];
/* 2183 */     System.arraycopy(lineTemplate, 0, logLine, 0, lineTemplate.length);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2188 */     StringBuilder logMsg = new StringBuilder(messageDetail.length() + 4 * nLength + 4 * (1 + nLength / 16) + 80);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2198 */     logMsg.append(this.tcpSocket.getLocalAddress().toString()).append(":").append(this.tcpSocket.getLocalPort())
/* 2199 */       .append(" SPID:").append(this.spid).append(" ").append(messageDetail).append("\r\n");
/*      */ 
/*      */     
/* 2202 */     int nBytesLogged = 0;
/*      */     
/*      */     while (true) {
/*      */       int nBytesThisLine;
/* 2206 */       for (nBytesThisLine = 0; nBytesThisLine < 16 && nBytesLogged < nLength; nBytesThisLine++, nBytesLogged++) {
/* 2207 */         int nUnsignedByteVal = (data[nStartOffset + nBytesLogged] + 256) % 256;
/* 2208 */         logLine[3 * nBytesThisLine] = hexChars[nUnsignedByteVal / 16];
/* 2209 */         logLine[3 * nBytesThisLine + 1] = hexChars[nUnsignedByteVal % 16];
/* 2210 */         logLine[50 + nBytesThisLine] = printableChars[nUnsignedByteVal];
/*      */       } 
/*      */ 
/*      */       
/* 2214 */       for (int nBytesJustified = nBytesThisLine; nBytesJustified < 16; nBytesJustified++) {
/* 2215 */         logLine[3 * nBytesJustified] = ' ';
/* 2216 */         logLine[3 * nBytesJustified + 1] = ' ';
/*      */       } 
/*      */       
/* 2219 */       logMsg.append(logLine, 0, 50 + nBytesThisLine);
/* 2220 */       if (nBytesLogged == nLength) {
/*      */         break;
/*      */       }
/* 2223 */       logMsg.append("\r\n");
/*      */     } 
/*      */     
/* 2226 */     if (packetLogger.isLoggable(Level.FINEST)) {
/* 2227 */       packetLogger.finest(logMsg.toString());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final int getNetworkTimeout() throws IOException {
/* 2239 */     return this.tcpSocket.getSoTimeout();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void setNetworkTimeout(int timeout) throws IOException {
/* 2251 */     this.tcpSocket.setSoTimeout(timeout);
/*      */   }
/*      */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\TDSChannel.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */