/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.logging.Level;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SimpleInputStream
/*     */   extends BaseInputStream
/*     */ {
/*     */   private byte[] bSingleByte;
/*     */   
/*     */   SimpleInputStream(TDSReader tdsReader, int payLoadLength, InputStreamGetterArgs getterArgs, ServerDTVImpl dtv) throws SQLServerException {
/* 139 */     super(tdsReader, getterArgs.isAdaptive, getterArgs.isStreaming, dtv);
/* 140 */     setLoggingInfo(getterArgs.logContext);
/* 141 */     this.payloadLength = payLoadLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 151 */     if (null == this.tdsReader)
/*     */       return; 
/* 153 */     if (logger.isLoggable(Level.FINER)) {
/* 154 */       logger.finer(toString() + "Enter Closing SimpleInputStream.");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 159 */     skip((this.payloadLength - this.streamPos));
/*     */     
/* 161 */     closeHelper();
/* 162 */     if (logger.isLoggable(Level.FINER)) {
/* 163 */       logger.finer(toString() + "Exit Closing SimpleInputStream.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isEOS() throws IOException {
/* 173 */     assert this.streamPos <= this.payloadLength;
/* 174 */     return (this.streamPos == this.payloadLength);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long skip(long n) throws IOException {
/*     */     int skipAmount;
/* 189 */     checkClosed();
/* 190 */     if (logger.isLoggable(Level.FINER))
/* 191 */       logger.finer(toString() + " Skipping :" + toString()); 
/* 192 */     if (n < 0L)
/* 193 */       return 0L; 
/* 194 */     if (isEOS()) {
/* 195 */       return 0L;
/*     */     }
/*     */     
/* 198 */     if (this.streamPos + n > this.payloadLength) {
/* 199 */       skipAmount = this.payloadLength - this.streamPos;
/*     */     } else {
/* 201 */       skipAmount = (int)n;
/*     */     } 
/*     */     try {
/* 204 */       this.tdsReader.skip(skipAmount);
/* 205 */     } catch (SQLServerException e) {
/* 206 */       throw new IOException(e.getMessage());
/*     */     } 
/* 208 */     this.streamPos += skipAmount;
/* 209 */     if (this.isReadLimitSet && this.streamPos - this.markedStreamPos > this.readLimit) {
/* 210 */       clearCurrentMark();
/*     */     }
/* 212 */     return skipAmount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int available() throws IOException {
/* 225 */     checkClosed();
/* 226 */     assert this.streamPos <= this.payloadLength;
/*     */     
/* 228 */     int available = this.payloadLength - this.streamPos;
/* 229 */     if (this.tdsReader.available() < available)
/* 230 */       available = this.tdsReader.available(); 
/* 231 */     return available;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read() throws IOException {
/* 244 */     checkClosed();
/* 245 */     if (null == this.bSingleByte)
/* 246 */       this.bSingleByte = new byte[1]; 
/* 247 */     if (isEOS())
/* 248 */       return -1; 
/* 249 */     int bytesRead = read(this.bSingleByte, 0, 1);
/* 250 */     return (0 == bytesRead) ? -1 : (this.bSingleByte[0] & 0xFF);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(byte[] b) throws IOException {
/* 263 */     checkClosed();
/* 264 */     return read(b, 0, b.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(byte[] b, int offset, int maxBytes) throws IOException {
/*     */     int readAmount;
/* 281 */     checkClosed();
/* 282 */     if (logger.isLoggable(Level.FINER)) {
/* 283 */       logger.finer(toString() + " Reading " + toString() + " from stream offset " + maxBytes + " payload length " + this.streamPos);
/*     */     }
/*     */     
/* 286 */     if (offset < 0 || maxBytes < 0 || offset + maxBytes > b.length) {
/* 287 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 289 */     if (0 == maxBytes)
/* 290 */       return 0; 
/* 291 */     if (isEOS()) {
/* 292 */       return -1;
/*     */     }
/*     */     
/* 295 */     if (this.streamPos + maxBytes > this.payloadLength) {
/* 296 */       readAmount = this.payloadLength - this.streamPos;
/*     */     } else {
/* 298 */       readAmount = maxBytes;
/*     */     } 
/*     */     
/*     */     try {
/* 302 */       this.tdsReader.readBytes(b, offset, readAmount);
/* 303 */     } catch (SQLServerException e) {
/* 304 */       throw new IOException(e.getMessage());
/*     */     } 
/* 306 */     this.streamPos += readAmount;
/*     */     
/* 308 */     if (this.isReadLimitSet && this.streamPos - this.markedStreamPos > this.readLimit) {
/* 309 */       clearCurrentMark();
/*     */     }
/* 311 */     return readAmount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mark(int readLimit) {
/* 321 */     if (null != this.tdsReader && readLimit > 0) {
/* 322 */       this.currentMark = this.tdsReader.mark();
/* 323 */       this.markedStreamPos = this.streamPos;
/* 324 */       setReadLimit(readLimit);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() throws IOException {
/* 335 */     resetHelper();
/* 336 */     this.streamPos = this.markedStreamPos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final byte[] getBytes() throws SQLServerException {
/* 345 */     assert 0 == this.streamPos;
/*     */     
/* 347 */     byte[] value = new byte[this.payloadLength];
/*     */     try {
/* 349 */       read(value);
/* 350 */       close();
/* 351 */     } catch (IOException e) {
/* 352 */       SQLServerException.makeFromDriverError(null, null, e.getMessage(), null, true);
/*     */     } 
/*     */     
/* 355 */     return value;
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SimpleInputStream.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */