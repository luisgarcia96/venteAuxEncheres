/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.logging.Level;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ScrollWindow
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 3028807583846251111L;
/*     */   private TDSReaderMark[] rowMark;
/*     */   private boolean[] updatedRow;
/*     */   private boolean[] deletedRow;
/*     */   private RowType[] rowType;
/*  38 */   private int size = 0;
/*     */ 
/*     */   
/*  41 */   private int maxRows = 0;
/*     */   
/*     */   final int getMaxRows() {
/*  44 */     return this.maxRows;
/*     */   }
/*     */ 
/*     */   
/*     */   private int currentRow;
/*     */   
/*     */   final int getRow() {
/*  51 */     return this.currentRow;
/*     */   }
/*     */   
/*     */   ScrollWindow(int size) {
/*  55 */     setSize(size);
/*  56 */     reset();
/*     */   }
/*     */   
/*     */   private void setSize(int size) {
/*  60 */     assert this.size != size;
/*  61 */     this.size = size;
/*  62 */     this.maxRows = size;
/*  63 */     this.rowMark = new TDSReaderMark[size];
/*  64 */     this.updatedRow = new boolean[size];
/*  65 */     this.deletedRow = new boolean[size];
/*  66 */     this.rowType = new RowType[size];
/*  67 */     for (int i = 0; i < size; i++) {
/*  68 */       this.rowType[i] = RowType.UNKNOWN;
/*     */     }
/*     */   }
/*     */   
/*     */   final void clear() {
/*  73 */     for (int i = 0; i < this.rowMark.length; i++) {
/*  74 */       this.rowMark[i] = null;
/*  75 */       this.updatedRow[i] = false;
/*  76 */       this.deletedRow[i] = false;
/*  77 */       this.rowType[i] = RowType.UNKNOWN;
/*     */     } 
/*     */     
/*  80 */     assert this.size > 0;
/*  81 */     this.maxRows = this.size;
/*  82 */     reset();
/*     */   }
/*     */   
/*     */   final void reset() {
/*  86 */     this.currentRow = 0;
/*     */   }
/*     */   
/*     */   final void resize(int newSize) {
/*  90 */     assert newSize > 0;
/*  91 */     if (newSize != this.size)
/*  92 */       setSize(newSize); 
/*     */   }
/*     */   
/*     */   final String logCursorState() {
/*  96 */     return " currentRow:" + this.currentRow + " maxRows:" + this.maxRows;
/*     */   }
/*     */   
/*     */   final boolean next(SQLServerResultSet rs) throws SQLServerException {
/* 100 */     if (SQLServerResultSet.logger.isLoggable(Level.FINER)) {
/* 101 */       SQLServerResultSet.logger.finer(rs.toString() + rs.toString());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 106 */     assert 0 <= this.currentRow && this.currentRow <= this.maxRows + 1;
/*     */ 
/*     */ 
/*     */     
/* 110 */     if (this.maxRows + 1 == this.currentRow) {
/* 111 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 117 */     if (this.currentRow >= 1) {
/* 118 */       this.updatedRow[this.currentRow - 1] = rs.getUpdatedCurrentRow();
/* 119 */       this.deletedRow[this.currentRow - 1] = rs.getDeletedCurrentRow();
/* 120 */       this.rowType[this.currentRow - 1] = rs.getCurrentRowType();
/*     */     } 
/*     */ 
/*     */     
/* 124 */     this.currentRow++;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 131 */     if (this.maxRows + 1 == this.currentRow) {
/* 132 */       rs.fetchBufferNext();
/* 133 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 140 */     if (null != this.rowMark[this.currentRow - 1]) {
/* 141 */       rs.fetchBufferReset(this.rowMark[this.currentRow - 1]);
/* 142 */       rs.setCurrentRowType(this.rowType[this.currentRow - 1]);
/* 143 */       rs.setUpdatedCurrentRow(this.updatedRow[this.currentRow - 1]);
/* 144 */       rs.setDeletedCurrentRow(this.deletedRow[this.currentRow - 1]);
/* 145 */       return true;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 153 */     if (rs.fetchBufferNext()) {
/* 154 */       this.rowMark[this.currentRow - 1] = rs.fetchBufferMark();
/* 155 */       this.rowType[this.currentRow - 1] = rs.getCurrentRowType();
/*     */       
/* 157 */       if (SQLServerResultSet.logger.isLoggable(Level.FINEST)) {
/* 158 */         SQLServerResultSet.logger.finest(rs.toString() + " Set mark " + rs.toString() + " for row " + this.rowMark[this.currentRow - 1] + " of type " + this.currentRow);
/*     */       }
/*     */       
/* 161 */       return true;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 167 */     this.maxRows = this.currentRow - 1;
/* 168 */     return false;
/*     */   }
/*     */   
/*     */   final void previous(SQLServerResultSet rs) throws SQLServerException {
/* 172 */     if (SQLServerResultSet.logger.isLoggable(Level.FINER)) {
/* 173 */       SQLServerResultSet.logger.finer(rs.toString() + rs.toString());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 178 */     assert 0 <= this.currentRow && this.currentRow <= this.maxRows + 1;
/*     */ 
/*     */ 
/*     */     
/* 182 */     if (0 == this.currentRow) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 189 */     if (this.currentRow <= this.maxRows) {
/* 190 */       assert this.currentRow >= 1;
/* 191 */       this.updatedRow[this.currentRow - 1] = rs.getUpdatedCurrentRow();
/* 192 */       this.deletedRow[this.currentRow - 1] = rs.getDeletedCurrentRow();
/* 193 */       this.rowType[this.currentRow - 1] = rs.getCurrentRowType();
/*     */     } 
/*     */ 
/*     */     
/* 197 */     this.currentRow--;
/*     */ 
/*     */ 
/*     */     
/* 201 */     if (0 == this.currentRow) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 208 */     assert null != this.rowMark[this.currentRow - 1];
/* 209 */     rs.fetchBufferReset(this.rowMark[this.currentRow - 1]);
/* 210 */     rs.setCurrentRowType(this.rowType[this.currentRow - 1]);
/* 211 */     rs.setUpdatedCurrentRow(this.updatedRow[this.currentRow - 1]);
/* 212 */     rs.setDeletedCurrentRow(this.deletedRow[this.currentRow - 1]);
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\ScrollWindow.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */