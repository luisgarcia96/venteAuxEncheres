/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Calendar;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class Column
/*     */ {
/*     */   private TypeInfo typeInfo;
/*     */   private CryptoMetadata cryptoMetadata;
/*     */   private SqlVariant internalVariant;
/*     */   private DTV updaterDTV;
/*     */   
/*     */   final void setInternalVariant(SqlVariant type) {
/*  22 */     this.internalVariant = type;
/*     */   }
/*     */   
/*     */   final SqlVariant getInternalVariant() {
/*  26 */     return this.internalVariant;
/*     */   }
/*     */   
/*     */   final TypeInfo getTypeInfo() {
/*  30 */     return this.typeInfo;
/*     */   }
/*     */ 
/*     */   
/*  34 */   private final DTV getterDTV = new DTV();
/*     */ 
/*     */   
/*  37 */   private JDBCType jdbcTypeSetByUser = null;
/*     */ 
/*     */   
/*  40 */   private int valueLength = 0;
/*     */   private String columnName;
/*     */   private String baseColumnName;
/*     */   private int tableNum;
/*     */   
/*     */   final void setColumnName(String name) {
/*  46 */     this.columnName = name;
/*     */   }
/*     */   private int infoStatus; private SQLIdentifier tableName; ColumnFilter filter;
/*     */   final String getColumnName() {
/*  50 */     return this.columnName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void setBaseColumnName(String name) {
/*  59 */     this.baseColumnName = name;
/*     */   }
/*     */   
/*     */   final String getBaseColumnName() {
/*  63 */     return this.baseColumnName;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final void setTableNum(int num) {
/*  69 */     this.tableNum = num;
/*     */   }
/*     */   
/*     */   final int getTableNum() {
/*  73 */     return this.tableNum;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final void setInfoStatus(int status) {
/*  79 */     this.infoStatus = status;
/*     */   }
/*     */   
/*     */   final boolean hasDifferentName() {
/*  83 */     return (0 != (this.infoStatus & 0x20));
/*     */   }
/*     */   
/*     */   final boolean isHidden() {
/*  87 */     return (0 != (this.infoStatus & 0x10));
/*     */   }
/*     */   
/*     */   final boolean isKey() {
/*  91 */     return (0 != (this.infoStatus & 0x8));
/*     */   }
/*     */   
/*     */   final boolean isExpression() {
/*  95 */     return (0 != (this.infoStatus & 0x4));
/*     */   }
/*     */   
/*     */   final boolean isUpdatable() {
/*  99 */     return (!isExpression() && !isHidden() && this.tableName.getObjectName().length() > 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final void setTableName(SQLIdentifier name) {
/* 105 */     this.tableName = name;
/*     */   }
/*     */   
/*     */   final SQLIdentifier getTableName() {
/* 109 */     return this.tableName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Column(TypeInfo typeInfo, String columnName, SQLIdentifier tableName, CryptoMetadata cryptoMeta) {
/* 127 */     this.typeInfo = typeInfo;
/* 128 */     this.columnName = columnName;
/* 129 */     this.baseColumnName = columnName;
/* 130 */     this.tableName = tableName;
/* 131 */     this.cryptoMetadata = cryptoMeta;
/*     */   }
/*     */   
/*     */   CryptoMetadata getCryptoMetadata() {
/* 135 */     return this.cryptoMetadata;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void clear() {
/* 142 */     this.getterDTV.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void skipValue(TDSReader tdsReader, boolean isDiscard) throws SQLServerException {
/* 152 */     this.getterDTV.skipValue(this.typeInfo, tdsReader, isDiscard);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void initFromCompressedNull() {
/* 159 */     this.getterDTV.initFromCompressedNull();
/*     */   }
/*     */   
/*     */   void setFilter(ColumnFilter filter) {
/* 163 */     this.filter = filter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean isNull() {
/* 172 */     return this.getterDTV.isNull();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean isInitialized() {
/* 180 */     return this.getterDTV.isInitialized();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object getValue(JDBCType jdbcType, InputStreamGetterArgs getterArgs, Calendar cal, TDSReader tdsReader) throws SQLServerException {
/* 190 */     Object value = this.getterDTV.getValue(jdbcType, this.typeInfo.getScale(), getterArgs, cal, this.typeInfo, this.cryptoMetadata, tdsReader);
/*     */     
/* 192 */     setInternalVariant(this.getterDTV.getInternalVariant());
/* 193 */     return (null != this.filter) ? this.filter.apply(value, jdbcType) : value;
/*     */   }
/*     */   
/*     */   int getInt(TDSReader tdsReader) throws SQLServerException {
/* 197 */     return ((Integer)getValue(JDBCType.INTEGER, null, null, tdsReader)).intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void updateValue(JDBCType jdbcType, Object value, JavaType javaType, StreamSetterArgs streamSetterArgs, Calendar cal, Integer scale, SQLServerConnection con, SQLServerStatementColumnEncryptionSetting stmtColumnEncriptionSetting, Integer precision, boolean forceEncrypt, int parameterIndex) throws SQLServerException {
/* 204 */     SSType ssType = this.typeInfo.getSSType();
/*     */     
/* 206 */     if (null != this.cryptoMetadata) {
/* 207 */       if (SSType.VARBINARYMAX == this.cryptoMetadata.baseTypeInfo.getSSType() && JDBCType.BINARY == jdbcType) {
/* 208 */         jdbcType = this.cryptoMetadata.baseTypeInfo.getSSType().getJDBCType();
/*     */       }
/*     */       
/* 211 */       if (null != value) {
/*     */ 
/*     */         
/* 214 */         if (JDBCType.TINYINT == this.cryptoMetadata.getBaseTypeInfo().getSSType().getJDBCType() && javaType == JavaType.SHORT)
/*     */         {
/* 216 */           if (value instanceof Boolean) {
/* 217 */             if (((Boolean)value).booleanValue()) {
/* 218 */               value = Integer.valueOf(1);
/*     */             } else {
/* 220 */               value = Integer.valueOf(0);
/*     */             } 
/*     */           }
/* 223 */           String stringValue = "" + value;
/* 224 */           Short shortValue = Short.valueOf(stringValue);
/*     */           
/* 226 */           if (shortValue.shortValue() >= 0 && shortValue.shortValue() <= 255) {
/* 227 */             value = Byte.valueOf(shortValue.byteValue());
/* 228 */             javaType = JavaType.BYTE;
/* 229 */             jdbcType = JDBCType.TINYINT;
/*     */           }
/*     */         
/*     */         }
/*     */       
/* 234 */       } else if (jdbcType.isBinary()) {
/* 235 */         jdbcType = this.cryptoMetadata.getBaseTypeInfo().getSSType().getJDBCType();
/*     */       } 
/*     */     } 
/*     */     
/* 239 */     if (null == scale && null != this.cryptoMetadata) {
/* 240 */       scale = Integer.valueOf(this.cryptoMetadata.getBaseTypeInfo().getScale());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 245 */     if (null != this.cryptoMetadata && (JDBCType.CHAR == jdbcType || JDBCType.VARCHAR == jdbcType) && (
/* 246 */       JDBCType.NVARCHAR == this.cryptoMetadata.getBaseTypeInfo().getSSType().getJDBCType() || JDBCType.NCHAR == this.cryptoMetadata
/* 247 */       .getBaseTypeInfo().getSSType().getJDBCType() || JDBCType.LONGNVARCHAR == this.cryptoMetadata
/* 248 */       .getBaseTypeInfo().getSSType().getJDBCType())) {
/* 249 */       jdbcType = this.cryptoMetadata.getBaseTypeInfo().getSSType().getJDBCType();
/*     */     }
/*     */ 
/*     */     
/* 253 */     if (Util.shouldHonorAEForParameters(stmtColumnEncriptionSetting, con)) {
/* 254 */       if (null == this.cryptoMetadata && forceEncrypt) {
/*     */         
/* 256 */         MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_ForceEncryptionTrue_HonorAETrue_UnencryptedColumnRS"));
/* 257 */         Object[] msgArgs = { Integer.valueOf(parameterIndex) };
/*     */         
/* 259 */         throw new SQLServerException(null, form.format(msgArgs), null, 0, false);
/*     */       } 
/* 261 */       setJdbcTypeSetByUser(jdbcType);
/*     */       
/* 263 */       this.valueLength = Util.getValueLengthBaseOnJavaType(value, javaType, precision, scale, jdbcType);
/*     */ 
/*     */ 
/*     */       
/* 267 */       if (null != this.cryptoMetadata && (
/* 268 */         JDBCType.NCHAR == this.cryptoMetadata.getBaseTypeInfo().getSSType().getJDBCType() || JDBCType.NVARCHAR == this.cryptoMetadata
/* 269 */         .getBaseTypeInfo().getSSType().getJDBCType() || JDBCType.LONGNVARCHAR == this.cryptoMetadata
/* 270 */         .getBaseTypeInfo().getSSType().getJDBCType())) {
/* 271 */         this.valueLength *= 2;
/*     */       
/*     */       }
/*     */     
/*     */     }
/* 276 */     else if (forceEncrypt) {
/*     */       
/* 278 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_ForceEncryptionTrue_HonorAEFalseRS"));
/* 279 */       Object[] msgArgs = { Integer.valueOf(parameterIndex) };
/*     */       
/* 281 */       throw new SQLServerException(null, form.format(msgArgs), null, 0, false);
/*     */     } 
/*     */ 
/*     */     
/* 285 */     if (null != streamSetterArgs) {
/* 286 */       if (!streamSetterArgs.streamType.convertsTo(this.typeInfo)) {
/* 287 */         DataTypes.throwConversionError(streamSetterArgs.streamType.toString(), ssType.toString());
/*     */       }
/* 289 */     } else if (null != this.cryptoMetadata) {
/*     */       
/* 291 */       if (JDBCType.UNKNOWN == jdbcType && value instanceof java.util.UUID) {
/* 292 */         javaType = JavaType.STRING;
/* 293 */         jdbcType = JDBCType.GUID;
/* 294 */         setJdbcTypeSetByUser(jdbcType);
/*     */       } 
/*     */       
/* 297 */       SSType basicSSType = this.cryptoMetadata.baseTypeInfo.getSSType();
/* 298 */       if (!jdbcType.convertsTo(basicSSType)) {
/* 299 */         DataTypes.throwConversionError(jdbcType.toString(), ssType.toString());
/*     */       }
/* 301 */       JDBCType jdbcTypeFromSSType = getJDBCTypeFromBaseSSType(basicSSType, jdbcType);
/*     */       
/* 303 */       if (jdbcTypeFromSSType != jdbcType) {
/* 304 */         setJdbcTypeSetByUser(jdbcTypeFromSSType);
/* 305 */         jdbcType = jdbcTypeFromSSType;
/* 306 */         this.valueLength = Util.getValueLengthBaseOnJavaType(value, javaType, precision, scale, jdbcType);
/*     */       }
/*     */     
/* 309 */     } else if (!jdbcType.convertsTo(ssType)) {
/* 310 */       DataTypes.throwConversionError(jdbcType.toString(), ssType.toString());
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 315 */     if ((JDBCType.DATETIMEOFFSET == jdbcType || JavaType.DATETIMEOFFSET == javaType) && !con.isKatmaiOrLater()) {
/* 316 */       throw new SQLServerException(SQLServerException.getErrString("R_notSupported"), SQLState.DATA_EXCEPTION_NOT_SPECIFIC, DriverError.NOT_SET, null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 324 */     if (null != this.cryptoMetadata && con.sendStringParametersAsUnicode() && (JavaType.STRING == javaType || JavaType.READER == javaType || JavaType.CLOB == javaType || JavaType.OBJECT == javaType))
/*     */     {
/* 326 */       jdbcType = getSSPAUJDBCType(jdbcType);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 339 */     if ((SSType.NCHAR == ssType || SSType.NVARCHAR == ssType || SSType.NVARCHARMAX == ssType || SSType.NTEXT == ssType || SSType.XML == ssType) && (JDBCType.CHAR == jdbcType || JDBCType.VARCHAR == jdbcType || JDBCType.LONGVARCHAR == jdbcType || JDBCType.CLOB == jdbcType)) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 344 */       jdbcType = (JDBCType.CLOB == jdbcType) ? JDBCType.NCLOB : JDBCType.NVARCHAR;
/*     */ 
/*     */     
/*     */     }
/* 348 */     else if ((SSType.BINARY == ssType || SSType.VARBINARY == ssType || SSType.VARBINARYMAX == ssType || SSType.IMAGE == ssType || SSType.UDT == ssType) && (JDBCType.CHAR == jdbcType || JDBCType.VARCHAR == jdbcType || JDBCType.LONGVARCHAR == jdbcType)) {
/*     */ 
/*     */ 
/*     */       
/* 352 */       jdbcType = JDBCType.VARBINARY;
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 357 */     else if ((JDBCType.TIMESTAMP == jdbcType || JDBCType.DATE == jdbcType || JDBCType.TIME == jdbcType || JDBCType.DATETIMEOFFSET == jdbcType) && (SSType.CHAR == ssType || SSType.VARCHAR == ssType || SSType.VARCHARMAX == ssType || SSType.TEXT == ssType || SSType.NCHAR == ssType || SSType.NVARCHAR == ssType || SSType.NVARCHARMAX == ssType || SSType.NTEXT == ssType)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 363 */       jdbcType = JDBCType.NCHAR;
/*     */     } 
/*     */ 
/*     */     
/* 367 */     if (null == this.updaterDTV) {
/* 368 */       this.updaterDTV = new DTV();
/*     */     }
/*     */ 
/*     */     
/* 372 */     this.updaterDTV.setValue(this.typeInfo.getSQLCollation(), jdbcType, value, javaType, streamSetterArgs, cal, scale, con, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static JDBCType getSSPAUJDBCType(JDBCType jdbcType) {
/* 381 */     switch (jdbcType) {
/*     */       case CHAR:
/* 383 */         return JDBCType.NCHAR;
/*     */       case VARCHAR:
/* 385 */         return JDBCType.NVARCHAR;
/*     */       case LONGVARCHAR:
/* 387 */         return JDBCType.LONGNVARCHAR;
/*     */       case CLOB:
/* 389 */         return JDBCType.NCLOB;
/*     */     } 
/* 391 */     return jdbcType;
/*     */   }
/*     */ 
/*     */   
/*     */   private static JDBCType getJDBCTypeFromBaseSSType(SSType basicSSType, JDBCType jdbcType) {
/* 396 */     switch (jdbcType) {
/*     */       case TIMESTAMP:
/* 398 */         if (SSType.DATETIME == basicSSType)
/* 399 */           return JDBCType.DATETIME; 
/* 400 */         if (SSType.SMALLDATETIME == basicSSType)
/* 401 */           return JDBCType.SMALLDATETIME; 
/* 402 */         return jdbcType;
/*     */       
/*     */       case NUMERIC:
/*     */       case DECIMAL:
/* 406 */         if (SSType.MONEY == basicSSType)
/* 407 */           return JDBCType.MONEY; 
/* 408 */         if (SSType.SMALLMONEY == basicSSType)
/* 409 */           return JDBCType.SMALLMONEY; 
/* 410 */         return jdbcType;
/*     */       
/*     */       case CHAR:
/* 413 */         if (SSType.GUID == basicSSType)
/* 414 */           return JDBCType.GUID; 
/* 415 */         if (SSType.VARCHARMAX == basicSSType)
/* 416 */           return JDBCType.LONGVARCHAR; 
/* 417 */         return jdbcType;
/*     */     } 
/*     */     
/* 420 */     return jdbcType;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean hasUpdates() {
/* 425 */     return (null != this.updaterDTV);
/*     */   }
/*     */   
/*     */   void cancelUpdates() {
/* 429 */     this.updaterDTV = null;
/*     */   }
/*     */ 
/*     */   
/*     */   void sendByRPC(TDSWriter tdsWriter, SQLServerConnection conn) throws SQLServerException {
/* 434 */     if (null == this.updaterDTV) {
/*     */       return;
/*     */     }
/*     */     try {
/* 438 */       this.updaterDTV.sendCryptoMetaData(this.cryptoMetadata, tdsWriter);
/* 439 */       this.updaterDTV.setJdbcTypeSetByUser(getJdbcTypeSetByUser(), getValueLength());
/*     */ 
/*     */       
/* 442 */       this.updaterDTV.sendByRPC(this.baseColumnName, this.typeInfo, 
/* 443 */           (null != this.cryptoMetadata) ? this.cryptoMetadata.getBaseTypeInfo().getSQLCollation() : 
/* 444 */           this.typeInfo.getSQLCollation(), 
/* 445 */           (null != this.cryptoMetadata) ? this.cryptoMetadata.getBaseTypeInfo().getPrecision() : this.typeInfo.getPrecision(), 
/* 446 */           (null != this.cryptoMetadata) ? this.cryptoMetadata.getBaseTypeInfo().getScale() : this.typeInfo.getScale(), false, tdsWriter, conn);
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     finally {
/*     */ 
/*     */ 
/*     */       
/* 455 */       this.updaterDTV.sendCryptoMetaData(null, tdsWriter);
/*     */     } 
/*     */   }
/*     */   
/*     */   JDBCType getJdbcTypeSetByUser() {
/* 460 */     return this.jdbcTypeSetByUser;
/*     */   }
/*     */   
/*     */   void setJdbcTypeSetByUser(JDBCType jdbcTypeSetByUser) {
/* 464 */     this.jdbcTypeSetByUser = jdbcTypeSetByUser;
/*     */   }
/*     */   
/*     */   int getValueLength() {
/* 468 */     return this.valueLength;
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\Column.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */