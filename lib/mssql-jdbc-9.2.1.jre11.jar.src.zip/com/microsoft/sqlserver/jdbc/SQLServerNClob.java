/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import java.io.Reader;
/*    */ import java.io.Writer;
/*    */ import java.nio.charset.StandardCharsets;
/*    */ import java.sql.Clob;
/*    */ import java.sql.NClob;
/*    */ import java.sql.SQLException;
/*    */ import java.util.logging.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SQLServerNClob
/*    */   extends SQLServerClobBase
/*    */   implements NClob
/*    */ {
/*    */   private static final long serialVersionUID = 3593610902551842327L;
/* 26 */   private static final Logger logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerNClob");
/*    */   
/*    */   SQLServerNClob(SQLServerConnection connection) {
/* 29 */     super(connection, "", connection.getDatabaseCollation(), logger, null);
/* 30 */     setDefaultCharset(StandardCharsets.UTF_16LE);
/*    */   }
/*    */   
/*    */   SQLServerNClob(BaseInputStream stream, TypeInfo typeInfo) {
/* 34 */     super(null, stream, typeInfo.getSQLCollation(), logger, typeInfo);
/* 35 */     setDefaultCharset(StandardCharsets.UTF_16LE);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public InputStream getAsciiStream() throws SQLException {
/* 42 */     fillFromStream();
/* 43 */     return super.getAsciiStream();
/*    */   }
/*    */ 
/*    */   
/*    */   final JDBCType getJdbcType() {
/* 48 */     return JDBCType.NCLOB;
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerNClob.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */