/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ enum DriverError
/*    */ {
/* 35 */   NOT_SET(0);
/*    */   
/*    */   private final int errorCode;
/*    */   
/*    */   final int getErrorCode() {
/* 40 */     return this.errorCode;
/*    */   }
/*    */   
/*    */   DriverError(int errorCode) {
/* 44 */     this.errorCode = errorCode;
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\DriverError.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */