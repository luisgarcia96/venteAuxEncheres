/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StringUtils
/*    */ {
/*    */   public static final String SPACE = " ";
/*    */   public static final String EMPTY = "";
/*    */   
/*    */   public static boolean isEmpty(CharSequence charSequence) {
/* 36 */     return (charSequence == null || charSequence.length() == 0);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean isNumeric(String str) {
/* 47 */     return (!isEmpty(str) && str.matches("\\d+(\\.\\d+)?"));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean isInteger(String str) {
/*    */     try {
/* 59 */       Integer.parseInt(str);
/* 60 */       return true;
/* 61 */     } catch (NumberFormatException numberFormatException) {
/*    */ 
/*    */       
/* 64 */       return false;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\StringUtils.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */