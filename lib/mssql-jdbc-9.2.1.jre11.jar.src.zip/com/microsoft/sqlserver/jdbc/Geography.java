/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Geography
/*     */   extends SQLServerSpatialDatatype
/*     */ {
/*     */   protected Geography() {}
/*     */   
/*     */   protected Geography(String wkt, int srid) throws SQLServerException {
/*  32 */     if (null == wkt || wkt.length() <= 0) {
/*  33 */       throwIllegalWKT();
/*     */     }
/*     */     
/*  36 */     this.wkt = wkt;
/*  37 */     this.srid = srid;
/*     */     
/*  39 */     parseWKTForSerialization(this, this.currentWktPos, -1, false);
/*     */     
/*  41 */     serializeToClr(false, this);
/*  42 */     this.isNull = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Geography(byte[] clr) throws SQLServerException {
/*  54 */     if (null == clr || clr.length <= 0) {
/*  55 */       throwIllegalByteArray();
/*     */     }
/*     */     
/*  58 */     this.clr = clr;
/*  59 */     this.buffer = ByteBuffer.wrap(clr);
/*  60 */     this.buffer.order(ByteOrder.LITTLE_ENDIAN);
/*     */     
/*  62 */     parseClr(this);
/*     */     
/*  64 */     this.WKTsb = new StringBuffer();
/*  65 */     this.WKTsbNoZM = new StringBuffer();
/*     */     
/*  67 */     constructWKT(this, this.internalType, this.numberOfPoints, this.numberOfFigures, this.numberOfSegments, this.numberOfShapes);
/*     */     
/*  69 */     this.wkt = this.WKTsb.toString();
/*  70 */     this.wktNoZM = this.WKTsbNoZM.toString();
/*  71 */     this.isNull = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Geography STGeomFromText(String wkt, int srid) throws SQLServerException {
/*  87 */     return new Geography(wkt, srid);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Geography STGeomFromWKB(byte[] wkb) throws SQLServerException {
/* 106 */     return new Geography(wkb);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Geography deserialize(byte[] clr) throws SQLServerException {
/* 119 */     return new Geography(clr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Geography parse(String wkt) throws SQLServerException {
/* 133 */     return new Geography(wkt, 4326);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Geography point(double lat, double lon, int srid) throws SQLServerException {
/* 151 */     return new Geography("POINT (" + lon + " " + lat + ")", srid);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String STAsText() throws SQLServerException {
/* 163 */     if (null == this.wktNoZM) {
/* 164 */       this.buffer = ByteBuffer.wrap(this.clr);
/* 165 */       this.buffer.order(ByteOrder.LITTLE_ENDIAN);
/*     */       
/* 167 */       parseClr(this);
/*     */       
/* 169 */       this.WKTsb = new StringBuffer();
/* 170 */       this.WKTsbNoZM = new StringBuffer();
/* 171 */       constructWKT(this, this.internalType, this.numberOfPoints, this.numberOfFigures, this.numberOfSegments, this.numberOfShapes);
/* 172 */       this.wktNoZM = this.WKTsbNoZM.toString();
/*     */     } 
/* 174 */     return this.wktNoZM;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] STAsBinary() {
/* 184 */     if (null == this.wkb) {
/* 185 */       serializeToWkb(this);
/*     */     }
/* 187 */     return this.wkb;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] serialize() {
/* 196 */     return this.clr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasM() {
/* 205 */     return this.hasMvalues;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasZ() {
/* 214 */     return this.hasZvalues;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Double getLatitude() {
/* 223 */     if (null != this.internalType && this.internalType == InternalSpatialDatatype.POINT && this.yValues.length == 1) {
/* 224 */       return Double.valueOf(this.yValues[0]);
/*     */     }
/* 226 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Double getLongitude() {
/* 235 */     if (null != this.internalType && this.internalType == InternalSpatialDatatype.POINT && this.xValues.length == 1) {
/* 236 */       return Double.valueOf(this.xValues[0]);
/*     */     }
/* 238 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Double getM() {
/* 247 */     if (null != this.internalType && this.internalType == InternalSpatialDatatype.POINT && hasM()) {
/* 248 */       return Double.valueOf(this.mValues[0]);
/*     */     }
/* 250 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Double getZ() {
/* 259 */     if (null != this.internalType && this.internalType == InternalSpatialDatatype.POINT && hasZ()) {
/* 260 */       return Double.valueOf(this.zValues[0]);
/*     */     }
/* 262 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSrid() {
/* 271 */     return this.srid;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNull() {
/* 280 */     return this.isNull;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int STNumPoints() {
/* 289 */     return this.numberOfPoints;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String STGeographyType() {
/* 298 */     if (null != this.internalType) {
/* 299 */       return this.internalType.getTypeName();
/*     */     }
/* 301 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String asTextZM() {
/* 310 */     return this.wkt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 320 */     return this.wkt;
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\Geography.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */