/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import java.text.MessageFormat;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class SQLServerEncryptionAlgorithmFactoryList
/*    */ {
/*    */   private ConcurrentHashMap<String, SQLServerEncryptionAlgorithmFactory> encryptionAlgoFactoryMap;
/* 19 */   private static final SQLServerEncryptionAlgorithmFactoryList instance = new SQLServerEncryptionAlgorithmFactoryList();
/*    */   
/*    */   private SQLServerEncryptionAlgorithmFactoryList() {
/* 22 */     this.encryptionAlgoFactoryMap = new ConcurrentHashMap<>();
/* 23 */     this.encryptionAlgoFactoryMap.putIfAbsent("AEAD_AES_256_CBC_HMAC_SHA256", new SQLServerAeadAes256CbcHmac256Factory());
/*    */   }
/*    */ 
/*    */   
/*    */   static SQLServerEncryptionAlgorithmFactoryList getInstance() {
/* 28 */     return instance;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   String getRegisteredCipherAlgorithmNames() {
/* 35 */     StringBuffer stringBuff = new StringBuffer();
/* 36 */     boolean first = true;
/* 37 */     for (String key : this.encryptionAlgoFactoryMap.keySet()) {
/* 38 */       if (first) {
/* 39 */         stringBuff.append("'");
/* 40 */         first = false;
/*    */       } else {
/* 42 */         stringBuff.append(", '");
/*    */       } 
/* 44 */       stringBuff.append(key);
/* 45 */       stringBuff.append("'");
/*    */     } 
/*    */     
/* 48 */     return stringBuff.toString();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   SQLServerEncryptionAlgorithm getAlgorithm(SQLServerSymmetricKey key, SQLServerEncryptionType encryptionType, String algorithmName) throws SQLServerException {
/* 62 */     SQLServerEncryptionAlgorithm encryptionAlgorithm = null;
/* 63 */     SQLServerEncryptionAlgorithmFactory factory = null;
/* 64 */     if (!this.encryptionAlgoFactoryMap.containsKey(algorithmName)) {
/*    */       
/* 66 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_UnknownColumnEncryptionAlgorithm"));
/*    */       
/* 68 */       Object[] msgArgs = { algorithmName, getInstance().getRegisteredCipherAlgorithmNames() };
/* 69 */       throw new SQLServerException(this, form.format(msgArgs), null, 0, false);
/*    */     } 
/*    */     
/* 72 */     factory = this.encryptionAlgoFactoryMap.get(algorithmName);
/* 73 */     assert null != factory : "Null Algorithm Factory class detected";
/* 74 */     encryptionAlgorithm = factory.create(key, encryptionType, algorithmName);
/* 75 */     return encryptionAlgorithm;
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerEncryptionAlgorithmFactoryList.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */