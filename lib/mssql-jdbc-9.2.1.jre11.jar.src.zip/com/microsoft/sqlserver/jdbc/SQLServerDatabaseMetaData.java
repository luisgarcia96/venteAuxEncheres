/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.io.Serializable;
/*      */ import java.sql.CallableStatement;
/*      */ import java.sql.Connection;
/*      */ import java.sql.DatabaseMetaData;
/*      */ import java.sql.DriverPropertyInfo;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.RowIdLifetime;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLTimeoutException;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.EnumMap;
/*      */ import java.util.HashMap;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.concurrent.atomic.AtomicInteger;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class SQLServerDatabaseMetaData
/*      */   implements DatabaseMetaData, Serializable
/*      */ {
/*      */   private static final long serialVersionUID = -116977606028371577L;
/*      */   private SQLServerConnection connection;
/*      */   static final String urlprefix = "jdbc:sqlserver://";
/*   46 */   private static final Logger logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerDatabaseMetaData");
/*      */ 
/*      */   
/*   49 */   private static final Logger loggerExternal = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.DatabaseMetaData");
/*      */   
/*   51 */   private static final AtomicInteger baseID = new AtomicInteger(0);
/*      */ 
/*      */ 
/*      */   
/*      */   private final String traceID;
/*      */ 
/*      */ 
/*      */   
/*      */   static final int MAXLOBSIZE = 2147483647;
/*      */ 
/*      */ 
/*      */   
/*      */   static final int uniqueidentifierSize = 36;
/*      */ 
/*      */ 
/*      */   
/*      */   enum CallableHandles
/*      */   {
/*   69 */     SP_COLUMNS("{ call sp_columns(?, ?, ?, ?, ?) }", "{ call sp_columns_100(?, ?, ?, ?, ?, ?) }"),
/*   70 */     SP_COLUMN_PRIVILEGES("{ call sp_column_privileges(?, ?, ?, ?)}", "{ call sp_column_privileges(?, ?, ?, ?)}"),
/*   71 */     SP_TABLES("{ call sp_tables(?, ?, ?, ?) }", "{ call sp_tables(?, ?, ?, ?) }"),
/*   72 */     SP_SPECIAL_COLUMNS("{ call sp_special_columns (?, ?, ?, ?, ?, ?, ?)}", "{ call sp_special_columns_100 (?, ?, ?, ?, ?, ?, ?)}"),
/*   73 */     SP_FKEYS("{ call sp_fkeys (?, ?, ?, ? , ? ,?)}", "{ call sp_fkeys (?, ?, ?, ? , ? ,?)}"),
/*   74 */     SP_STATISTICS("{ call sp_statistics(?,?,?,?,?, ?) }", "{ call sp_statistics_100(?,?,?,?,?, ?) }"),
/*   75 */     SP_SPROC_COLUMNS("{ call sp_sproc_columns(?, ?, ?,?,?) }", "{ call sp_sproc_columns_100(?, ?, ?,?,?) }"),
/*   76 */     SP_STORED_PROCEDURES("{call sp_stored_procedures(?, ?, ?) }", "{call sp_stored_procedures(?, ?, ?) }"),
/*   77 */     SP_TABLE_PRIVILEGES("{call sp_table_privileges(?,?,?) }", "{call sp_table_privileges(?,?,?) }"),
/*   78 */     SP_PKEYS("{ call sp_pkeys (?, ?, ?)}", "{ call sp_pkeys (?, ?, ?)}");
/*      */     
/*      */     private final String preKatProc;
/*      */     
/*      */     private final String katProc;
/*      */ 
/*      */     
/*      */     CallableHandles(String name, String katName) {
/*   86 */       this.preKatProc = name;
/*   87 */       this.katProc = katName;
/*      */     }
/*      */     
/*      */     CallableStatement prepare(SQLServerConnection conn) throws SQLServerException {
/*   91 */       return conn.prepareCall(conn.isKatmaiOrLater() ? this.katProc : this.preKatProc);
/*      */     }
/*      */   }
/*      */   
/*      */   final class HandleAssociation {
/*      */     Map<String, CallableStatement> statementMap;
/*      */     boolean nullCatalog = false;
/*      */     CallableStatement stmt;
/*      */     
/*      */     HandleAssociation() {
/*  101 */       if (null == this.statementMap) {
/*  102 */         this.statementMap = new HashMap<>();
/*      */       }
/*      */     }
/*      */     
/*      */     final void addToMap(String databaseName, CallableStatement stmt) {
/*  107 */       if (null != databaseName) {
/*  108 */         this.nullCatalog = false;
/*  109 */         this.statementMap.put(databaseName, stmt);
/*      */       } else {
/*  111 */         this.nullCatalog = true;
/*  112 */         this.stmt = stmt;
/*      */       } 
/*      */     }
/*      */     
/*      */     final CallableStatement getMappedStatement(String databaseName) {
/*  117 */       if (null != databaseName) {
/*  118 */         if (null != this.statementMap && this.statementMap.containsKey(databaseName)) {
/*  119 */           return this.statementMap.get(databaseName);
/*      */         }
/*  121 */         return null;
/*      */       } 
/*  123 */       return this.stmt;
/*      */     } } private static final String ASC_OR_DESC = "ASC_OR_DESC"; private static final String ATTR_NAME = "ATTR_NAME"; private static final String ATTR_TYPE_NAME = "ATTR_TYPE_NAME"; private static final String ATTR_SIZE = "ATTR_SIZE"; private static final String ATTR_DEF = "ATTR_DEF"; private static final String BASE_TYPE = "BASE_TYPE"; private static final String BUFFER_LENGTH = "BUFFER_LENGTH"; private static final String CARDINALITY = "CARDINALITY"; private static final String CHAR_OCTET_LENGTH = "CHAR_OCTET_LENGTH"; private static final String CLASS_NAME = "CLASS_NAME"; private static final String COLUMN_DEF = "COLUMN_DEF"; private static final String COLUMN_NAME = "COLUMN_NAME"; private static final String COLUMN_SIZE = "COLUMN_SIZE"; private static final String COLUMN_TYPE = "COLUMN_TYPE"; private static final String DATA_TYPE = "DATA_TYPE"; private static final String DECIMAL_DIGITS = "DECIMAL_DIGITS"; private static final String DEFERRABILITY = "DEFERRABILITY"; private static final String DELETE_RULE = "DELETE_RULE";
/*      */   private static final String FILTER_CONDITION = "FILTER_CONDITION";
/*      */   private static final String FK_NAME = "FK_NAME";
/*      */   private static final String FKCOLUMN_NAME = "FKCOLUMN_NAME";
/*  128 */   EnumMap<CallableHandles, HandleAssociation> handleMap = new EnumMap<>(CallableHandles.class); private static final String FKTABLE_CAT = "FKTABLE_CAT"; private static final String FKTABLE_NAME = "FKTABLE_NAME"; private static final String FKTABLE_SCHEM = "FKTABLE_SCHEM"; private static final String GRANTEE = "GRANTEE"; private static final String GRANTOR = "GRANTOR"; private static final String INDEX_NAME = "INDEX_NAME"; private static final String INDEX_QUALIFIER = "INDEX_QUALIFIER"; private static final String IS_GRANTABLE = "IS_GRANTABLE"; private static final String IS_NULLABLE = "IS_NULLABLE";
/*      */   private static final String KEY_SEQ = "KEY_SEQ";
/*      */   
/*      */   private static int nextInstanceID() {
/*  132 */     return baseID.incrementAndGet();
/*      */   }
/*      */   private static final String LENGTH = "LENGTH"; private static final String NON_UNIQUE = "NON_UNIQUE"; private static final String NULLABLE = "NULLABLE"; private static final String NUM_INPUT_PARAMS = "NUM_INPUT_PARAMS"; private static final String NUM_OUTPUT_PARAMS = "NUM_OUTPUT_PARAMS"; private static final String NUM_PREC_RADIX = "NUM_PREC_RADIX"; private static final String NUM_RESULT_SETS = "NUM_RESULT_SETS"; private static final String ORDINAL_POSITION = "ORDINAL_POSITION"; private static final String PAGES = "PAGES"; private static final String PK_NAME = "PK_NAME"; private static final String PKCOLUMN_NAME = "PKCOLUMN_NAME"; private static final String PKTABLE_CAT = "PKTABLE_CAT"; private static final String PKTABLE_NAME = "PKTABLE_NAME"; private static final String PKTABLE_SCHEM = "PKTABLE_SCHEM"; private static final String PRECISION = "PRECISION"; private static final String PRIVILEGE = "PRIVILEGE"; private static final String PROCEDURE_CAT = "PROCEDURE_CAT"; private static final String PROCEDURE_NAME = "PROCEDURE_NAME"; private static final String PROCEDURE_SCHEM = "PROCEDURE_SCHEM"; private static final String PROCEDURE_TYPE = "PROCEDURE_TYPE"; private static final String PSEUDO_COLUMN = "PSEUDO_COLUMN"; private static final String RADIX = "RADIX"; private static final String REMARKS = "REMARKS"; private static final String SCALE = "SCALE"; private static final String SCOPE = "SCOPE"; private static final String SCOPE_CATALOG = "SCOPE_CATALOG"; private static final String SCOPE_SCHEMA = "SCOPE_SCHEMA"; private static final String SCOPE_TABLE = "SCOPE_TABLE";
/*      */   private static final String SOURCE_DATA_TYPE = "SOURCE_DATA_TYPE";
/*      */   private static final String SQL_DATA_TYPE = "SQL_DATA_TYPE";
/*      */   private static final String SQL_DATETIME_SUB = "SQL_DATETIME_SUB";
/*      */   private static final String SS_DATA_TYPE = "SS_DATA_TYPE";
/*      */   
/*      */   public final String toString() {
/*  141 */     return this.traceID;
/*      */   }
/*      */   private static final String SUPERTABLE_NAME = "SUPERTABLE_NAME"; private static final String SUPERTYPE_CAT = "SUPERTYPE_CAT"; private static final String SUPERTYPE_NAME = "SUPERTYPE_NAME"; private static final String SUPERTYPE_SCHEM = "SUPERTYPE_SCHEM"; private static final String TABLE_CAT = "TABLE_CAT"; private static final String TABLE_NAME = "TABLE_NAME"; private static final String TABLE_SCHEM = "TABLE_SCHEM"; private static final String TABLE_TYPE = "TABLE_TYPE"; private static final String TYPE = "TYPE"; private static final String TYPE_CAT = "TYPE_CAT"; private static final String TYPE_NAME = "TYPE_NAME"; private static final String TYPE_SCHEM = "TYPE_SCHEM"; private static final String UPDATE_RULE = "UPDATE_RULE"; private static final String FUNCTION_CAT = "FUNCTION_CAT"; private static final String FUNCTION_NAME = "FUNCTION_NAME"; private static final String FUNCTION_SCHEM = "FUNCTION_SCHEM";
/*      */   private static final String FUNCTION_TYPE = "FUNCTION_TYPE";
/*      */   private static final String SS_IS_SPARSE = "SS_IS_SPARSE";
/*      */   private static final String SS_IS_COLUMN_SET = "SS_IS_COLUMN_SET";
/*      */   private static final String IS_GENERATEDCOLUMN = "IS_GENERATEDCOLUMN";
/*      */   private static final String IS_AUTOINCREMENT = "IS_AUTOINCREMENT";
/*      */   
/*      */   public SQLServerDatabaseMetaData(SQLServerConnection con) {
/*  151 */     this.traceID = " SQLServerDatabaseMetaData:" + nextInstanceID();
/*  152 */     this.connection = con;
/*  153 */     if (logger.isLoggable(Level.FINE)) {
/*  154 */       logger.fine(toString() + " created by (" + toString() + ")");
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isWrapperFor(Class<?> iface) throws SQLException {
/*  160 */     boolean f = iface.isInstance(this);
/*  161 */     return f;
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> T unwrap(Class<T> iface) throws SQLException {
/*      */     T t;
/*      */     try {
/*  168 */       t = iface.cast(this);
/*  169 */     } catch (ClassCastException e) {
/*  170 */       throw new SQLServerException(e.getMessage(), e);
/*      */     } 
/*  172 */     return t;
/*      */   }
/*      */   
/*      */   private void checkClosed() throws SQLServerException {
/*  176 */     if (this.connection.isClosed()) {
/*  177 */       SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_connectionIsClosed"), "08003", false);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  266 */   private static final String SQL_KEYWORDS = createSqlKeyWords();
/*      */ 
/*      */   
/*  269 */   private static LinkedHashMap<Integer, String> getColumnsDWColumns = null;
/*  270 */   private static LinkedHashMap<Integer, String> getImportedKeysDWColumns = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private SQLServerResultSet getResultSetFromInternalQueries(String catalog, String query) throws SQLException, SQLTimeoutException {
/*  284 */     checkClosed();
/*  285 */     String orgCat = null;
/*  286 */     orgCat = switchCatalogs(catalog);
/*  287 */     SQLServerResultSet rs = null;
/*      */     try {
/*  289 */       SQLServerStatement statement = (SQLServerStatement)this.connection.createStatement();
/*  290 */       statement.closeOnCompletion();
/*  291 */       rs = statement.executeQueryInternal(query);
/*      */     } finally {
/*  293 */       if (null != orgCat) {
/*  294 */         this.connection.setCatalog(orgCat);
/*      */       }
/*      */     } 
/*  297 */     return rs;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private CallableStatement getCallableStatementHandle(CallableHandles request, String catalog) throws SQLServerException {
/*  305 */     CallableStatement CS = null;
/*  306 */     HandleAssociation hassoc = this.handleMap.get(request);
/*      */     try {
/*  308 */       if (null == hassoc) {
/*  309 */         CS = request.prepare(this.connection);
/*  310 */         hassoc = new HandleAssociation();
/*  311 */         hassoc.addToMap(catalog, CS);
/*      */       } else {
/*  313 */         CS = hassoc.getMappedStatement(catalog);
/*      */         
/*  315 */         if (null == CS || CS.isClosed()) {
/*  316 */           CS = request.prepare(this.connection);
/*  317 */           hassoc.addToMap(catalog, CS);
/*      */         } 
/*      */       } 
/*  320 */       this.handleMap.put(request, hassoc);
/*  321 */     } catch (SQLException e) {
/*  322 */       SQLServerException.makeFromDriverError(this.connection, CS, e.toString(), null, false);
/*      */     } 
/*  324 */     return CS;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private SQLServerResultSet getResultSetFromStoredProc(String catalog, CallableHandles procedure, String[] arguments) throws SQLServerException, SQLTimeoutException {
/*  341 */     checkClosed();
/*  342 */     assert null != arguments;
/*  343 */     String orgCat = null;
/*  344 */     orgCat = switchCatalogs(catalog);
/*  345 */     SQLServerResultSet rs = null;
/*      */     try {
/*  347 */       SQLServerCallableStatement call = (SQLServerCallableStatement)getCallableStatementHandle(procedure, catalog);
/*      */ 
/*      */       
/*  350 */       for (int i = 1; i <= arguments.length; i++)
/*      */       {
/*  352 */         call.setString(i, arguments[i - 1]);
/*      */       }
/*  354 */       rs = (SQLServerResultSet)call.executeQueryInternal();
/*      */     } finally {
/*  356 */       if (null != orgCat) {
/*  357 */         this.connection.setCatalog(orgCat);
/*      */       }
/*      */     } 
/*  360 */     return rs;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private SQLServerResultSet getResultSetWithProvidedColumnNames(String catalog, CallableHandles procedure, String[] arguments, String[] columnNames) throws SQLServerException, SQLTimeoutException {
/*  366 */     SQLServerResultSet rs = getResultSetFromStoredProc(catalog, procedure, arguments);
/*      */ 
/*      */     
/*  369 */     for (int i = 0; i < columnNames.length; i++)
/*  370 */       rs.setColumnName(1 + i, columnNames[i]); 
/*  371 */     return rs;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String switchCatalogs(String catalog) throws SQLServerException {
/*  383 */     if (null == catalog)
/*  384 */       return null; 
/*  385 */     String sCurr = null;
/*  386 */     sCurr = this.connection.getCatalog().trim();
/*  387 */     String sNew = catalog.trim();
/*  388 */     if (sCurr.equals(sNew))
/*  389 */       return null; 
/*  390 */     this.connection.setCatalog(sNew);
/*  391 */     if (null == sCurr || sCurr.length() == 0)
/*  392 */       return null; 
/*  393 */     return sCurr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean allProceduresAreCallable() throws SQLServerException {
/*  400 */     checkClosed();
/*  401 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean allTablesAreSelectable() throws SQLServerException {
/*  406 */     checkClosed();
/*  407 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean autoCommitFailureClosesAllResultSets() throws SQLException {
/*  412 */     checkClosed();
/*  413 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean dataDefinitionCausesTransactionCommit() throws SQLServerException {
/*  418 */     checkClosed();
/*  419 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean dataDefinitionIgnoredInTransactions() throws SQLServerException {
/*  424 */     checkClosed();
/*  425 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean doesMaxRowSizeIncludeBlobs() throws SQLServerException {
/*  430 */     checkClosed();
/*  431 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean generatedKeyAlwaysReturned() throws SQLException {
/*  436 */     checkClosed();
/*      */     
/*  438 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public long getMaxLogicalLobSize() throws SQLException {
/*  443 */     checkClosed();
/*  444 */     return 2147483647L;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsRefCursors() throws SQLException {
/*  449 */     checkClosed();
/*  450 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsSharding() throws SQLException {
/*  455 */     DriverJDBCVersion.checkSupportsJDBC43();
/*  456 */     checkClosed();
/*  457 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public ResultSet getCatalogs() throws SQLException, SQLTimeoutException {
/*  462 */     if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) {
/*  463 */       loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */     }
/*  465 */     checkClosed();
/*      */     
/*  467 */     String s = "SELECT name AS TABLE_CAT FROM sys.databases order by name";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  473 */     return getResultSetFromInternalQueries(null, s);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getCatalogSeparator() throws SQLServerException {
/*  478 */     checkClosed();
/*  479 */     return ".";
/*      */   }
/*      */ 
/*      */   
/*      */   public String getCatalogTerm() throws SQLServerException {
/*  484 */     checkClosed();
/*  485 */     return "database";
/*      */   }
/*      */   
/*  488 */   private static final String[] getColumnPrivilegesColumnNames = new String[] { "TABLE_CAT", "TABLE_SCHEM", "TABLE_NAME", "COLUMN_NAME", "GRANTOR", "GRANTEE", "PRIVILEGE", "IS_GRANTABLE" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getColumnPrivileges(String catalog, String schema, String table, String col) throws SQLServerException, SQLTimeoutException {
/*  495 */     if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) {
/*  496 */       loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */     }
/*  498 */     checkClosed();
/*      */     
/*  500 */     col = EscapeIDName(col);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  506 */     String[] arguments = new String[4];
/*  507 */     arguments[0] = table;
/*  508 */     arguments[1] = schema;
/*  509 */     arguments[2] = catalog;
/*  510 */     arguments[3] = col;
/*  511 */     return getResultSetWithProvidedColumnNames(catalog, CallableHandles.SP_COLUMN_PRIVILEGES, arguments, getColumnPrivilegesColumnNames);
/*      */   }
/*      */ 
/*      */   
/*  515 */   private static final String[] getTablesColumnNames = new String[] { "TABLE_CAT", "TABLE_SCHEM", "TABLE_NAME", "TABLE_TYPE", "REMARKS" }; static final char LEFT_BRACKET = '['; static final char RIGHT_BRACKET = ']';
/*      */   static final char ESCAPE = '\\';
/*      */   static final char PERCENT = '%';
/*      */   static final char UNDERSCORE = '_';
/*      */   
/*      */   public ResultSet getTables(String catalog, String schema, String table, String[] types) throws SQLServerException, SQLTimeoutException {
/*  521 */     if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) {
/*  522 */       loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */     }
/*  524 */     checkClosed();
/*      */ 
/*      */     
/*  527 */     table = EscapeIDName(table);
/*  528 */     schema = EscapeIDName(schema);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  534 */     String[] arguments = new String[4];
/*  535 */     arguments[0] = table;
/*  536 */     arguments[1] = schema;
/*  537 */     arguments[2] = catalog;
/*      */     
/*  539 */     if (null != types) {
/*  540 */       StringBuilder tableTypes = new StringBuilder("'");
/*  541 */       for (int i = 0; i < types.length; i++) {
/*  542 */         if (i > 0)
/*  543 */           tableTypes.append(","); 
/*  544 */         tableTypes.append("''").append(types[i]).append("''");
/*      */       } 
/*  546 */       tableTypes.append("'");
/*  547 */       arguments[3] = tableTypes.toString();
/*      */     } 
/*  549 */     return getResultSetWithProvidedColumnNames(catalog, CallableHandles.SP_TABLES, arguments, getTablesColumnNames);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  557 */   static final char[] DOUBLE_RIGHT_BRACKET = new char[] { ']', ']' };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String EscapeIDName(String inID) throws SQLServerException {
/*  568 */     if (null == inID) {
/*  569 */       return inID;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  582 */     StringBuilder outID = new StringBuilder(inID.length() + 2);
/*      */     
/*  584 */     for (int i = 0; i < inID.length(); i++) {
/*  585 */       char ch = inID.charAt(i);
/*  586 */       if ('\\' == ch && ++i < inID.length()) {
/*  587 */         ch = inID.charAt(i);
/*  588 */         switch (ch) {
/*      */           case '%':
/*      */           case '[':
/*      */           case '_':
/*  592 */             outID.append('[');
/*  593 */             outID.append(ch);
/*  594 */             outID.append(']');
/*      */             break;
/*      */           case '\\':
/*      */           case ']':
/*  598 */             outID.append(ch);
/*      */             break;
/*      */           default:
/*  601 */             outID.append('\\');
/*  602 */             outID.append(ch);
/*      */             break;
/*      */         } 
/*      */       
/*      */       } else {
/*  607 */         outID.append(ch);
/*      */       } 
/*      */     } 
/*  610 */     return outID.toString();
/*      */   }
/*      */   
/*      */   public ResultSet getColumns(String catalog, String schema, String table, String col) throws SQLException
/*      */   {
/*  615 */     if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) {
/*  616 */       loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */     }
/*  618 */     checkClosed();
/*  619 */     String originalCatalog = switchCatalogs(catalog);
/*  620 */     if (!this.connection.isAzureDW()) {
/*  621 */       String spColumnsSql = "DECLARE @mssqljdbc_temp_sp_columns_result TABLE(TABLE_QUALIFIER SYSNAME, TABLE_OWNER SYSNAME,TABLE_NAME SYSNAME, COLUMN_NAME SYSNAME, DATA_TYPE SMALLINT, TYPE_NAME SYSNAME, PRECISION INT,LENGTH INT, SCALE SMALLINT, RADIX SMALLINT, NULLABLE SMALLINT, REMARKS VARCHAR(254), COLUMN_DEF NVARCHAR(4000),SQL_DATA_TYPE SMALLINT, SQL_DATETIME_SUB SMALLINT, CHAR_OCTET_LENGTH INT, ORDINAL_POSITION INT,IS_NULLABLE VARCHAR(254), SS_IS_SPARSE SMALLINT, SS_IS_COLUMN_SET SMALLINT, SS_IS_COMPUTED SMALLINT,SS_IS_IDENTITY SMALLINT, SS_UDT_CATALOG_NAME NVARCHAR(128), SS_UDT_SCHEMA_NAME NVARCHAR(128),SS_UDT_ASSEMBLY_TYPE_NAME NVARCHAR(max), SS_XML_SCHEMACOLLECTION_CATALOG_NAME NVARCHAR(128),SS_XML_SCHEMACOLLECTION_SCHEMA_NAME NVARCHAR(128), SS_XML_SCHEMACOLLECTION_NAME NVARCHAR(128),SS_DATA_TYPE TINYINT);INSERT INTO @mssqljdbc_temp_sp_columns_result EXEC sp_columns_100 ?,?,?,?,?,?;SELECT TABLE_QUALIFIER AS TABLE_CAT, TABLE_OWNER AS TABLE_SCHEM, TABLE_NAME, COLUMN_NAME, DATA_TYPE,TYPE_NAME, PRECISION AS COLUMN_SIZE, LENGTH AS BUFFER_LENGTH, SCALE AS DECIMAL_DIGITS, RADIX AS NUM_PREC_RADIX,NULLABLE, REMARKS, COLUMN_DEF, SQL_DATA_TYPE, SQL_DATETIME_SUB, CHAR_OCTET_LENGTH, ORDINAL_POSITION, IS_NULLABLE,NULL AS SCOPE_CATALOG, NULL AS SCOPE_SCHEMA, NULL AS SCOPE_TABLE, SS_DATA_TYPE AS SOURCE_DATA_TYPE,CASE SS_IS_IDENTITY WHEN 0 THEN 'NO' WHEN 1 THEN 'YES' WHEN '' THEN '' END AS IS_AUTOINCREMENT,CASE SS_IS_COMPUTED WHEN 0 THEN 'NO' WHEN 1 THEN 'YES' WHEN '' THEN '' END AS IS_GENERATEDCOLUMN, SS_IS_SPARSE, SS_IS_COLUMN_SET, SS_UDT_CATALOG_NAME, SS_UDT_SCHEMA_NAME, SS_UDT_ASSEMBLY_TYPE_NAME,SS_XML_SCHEMACOLLECTION_CATALOG_NAME, SS_XML_SCHEMACOLLECTION_SCHEMA_NAME, SS_XML_SCHEMACOLLECTION_NAME FROM @mssqljdbc_temp_sp_columns_result ORDER BY TABLE_CAT, TABLE_SCHEM, TABLE_NAME, ORDINAL_POSITION;";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  642 */       SQLServerResultSet rs = null;
/*  643 */       PreparedStatement pstmt = this.connection.prepareStatement(spColumnsSql);
/*  644 */       pstmt.closeOnCompletion();
/*      */       try {
/*  646 */         pstmt.setString(1, (null != table && !table.isEmpty()) ? EscapeIDName(table) : "%");
/*  647 */         pstmt.setString(2, (null != schema && !schema.isEmpty()) ? EscapeIDName(schema) : "%");
/*  648 */         pstmt.setString(3, (null != catalog && !catalog.isEmpty()) ? catalog : this.connection.getCatalog());
/*  649 */         pstmt.setString(4, (null != col && !col.isEmpty()) ? EscapeIDName(col) : "%");
/*  650 */         pstmt.setInt(5, 2);
/*  651 */         pstmt.setInt(6, 3);
/*      */         
/*  653 */         rs = (SQLServerResultSet)pstmt.executeQuery();
/*  654 */         rs.getColumn(5).setFilter(new DataTypeFilter());
/*  655 */         rs.getColumn(7).setFilter(new ZeroFixupFilter());
/*  656 */         rs.getColumn(8).setFilter(new ZeroFixupFilter());
/*  657 */         rs.getColumn(16).setFilter(new ZeroFixupFilter());
/*  658 */       } catch (SQLException e) {
/*  659 */         if (null != pstmt) {
/*      */           try {
/*  661 */             pstmt.close();
/*  662 */           } catch (SQLServerException ignore) {
/*  663 */             if (loggerExternal.isLoggable(Level.FINER)) {
/*  664 */               loggerExternal.finer("getColumns() threw an exception when attempting to close PreparedStatement");
/*      */             }
/*      */           } 
/*      */         }
/*      */         
/*  669 */         throw e;
/*      */       } finally {
/*  671 */         if (null != originalCatalog) {
/*  672 */           this.connection.setCatalog(originalCatalog);
/*      */         }
/*      */       } 
/*      */       
/*  676 */       return rs;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  683 */     synchronized (SQLServerDatabaseMetaData.class) {
/*  684 */       if (null == getColumnsDWColumns) {
/*  685 */         getColumnsDWColumns = new LinkedHashMap<>();
/*  686 */         getColumnsDWColumns.put(Integer.valueOf(1), "TABLE_CAT");
/*  687 */         getColumnsDWColumns.put(Integer.valueOf(2), "TABLE_SCHEM");
/*  688 */         getColumnsDWColumns.put(Integer.valueOf(3), "TABLE_NAME");
/*  689 */         getColumnsDWColumns.put(Integer.valueOf(4), "COLUMN_NAME");
/*  690 */         getColumnsDWColumns.put(Integer.valueOf(5), "DATA_TYPE");
/*  691 */         getColumnsDWColumns.put(Integer.valueOf(6), "TYPE_NAME");
/*  692 */         getColumnsDWColumns.put(Integer.valueOf(7), "COLUMN_SIZE");
/*  693 */         getColumnsDWColumns.put(Integer.valueOf(8), "BUFFER_LENGTH");
/*  694 */         getColumnsDWColumns.put(Integer.valueOf(9), "DECIMAL_DIGITS");
/*  695 */         getColumnsDWColumns.put(Integer.valueOf(10), "NUM_PREC_RADIX");
/*  696 */         getColumnsDWColumns.put(Integer.valueOf(11), "NULLABLE");
/*  697 */         getColumnsDWColumns.put(Integer.valueOf(12), "REMARKS");
/*  698 */         getColumnsDWColumns.put(Integer.valueOf(13), "COLUMN_DEF");
/*  699 */         getColumnsDWColumns.put(Integer.valueOf(14), "SQL_DATA_TYPE");
/*  700 */         getColumnsDWColumns.put(Integer.valueOf(15), "SQL_DATETIME_SUB");
/*  701 */         getColumnsDWColumns.put(Integer.valueOf(16), "CHAR_OCTET_LENGTH");
/*  702 */         getColumnsDWColumns.put(Integer.valueOf(17), "ORDINAL_POSITION");
/*  703 */         getColumnsDWColumns.put(Integer.valueOf(18), "IS_NULLABLE");
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  708 */         getColumnsDWColumns.put(Integer.valueOf(-1), "SCOPE_CATALOG");
/*  709 */         getColumnsDWColumns.put(Integer.valueOf(-2), "SCOPE_SCHEMA");
/*  710 */         getColumnsDWColumns.put(Integer.valueOf(-3), "SCOPE_TABLE");
/*  711 */         getColumnsDWColumns.put(Integer.valueOf(29), "SOURCE_DATA_TYPE");
/*  712 */         getColumnsDWColumns.put(Integer.valueOf(22), "IS_AUTOINCREMENT");
/*  713 */         getColumnsDWColumns.put(Integer.valueOf(21), "IS_GENERATEDCOLUMN");
/*  714 */         getColumnsDWColumns.put(Integer.valueOf(19), "SS_IS_SPARSE");
/*  715 */         getColumnsDWColumns.put(Integer.valueOf(20), "SS_IS_COLUMN_SET");
/*  716 */         getColumnsDWColumns.put(Integer.valueOf(23), "SS_UDT_CATALOG_NAME");
/*  717 */         getColumnsDWColumns.put(Integer.valueOf(24), "SS_UDT_SCHEMA_NAME");
/*  718 */         getColumnsDWColumns.put(Integer.valueOf(25), "SS_UDT_ASSEMBLY_TYPE_NAME");
/*  719 */         getColumnsDWColumns.put(Integer.valueOf(26), "SS_XML_SCHEMACOLLECTION_CATALOG_NAME");
/*  720 */         getColumnsDWColumns.put(Integer.valueOf(27), "SS_XML_SCHEMACOLLECTION_SCHEMA_NAME");
/*  721 */         getColumnsDWColumns.put(Integer.valueOf(28), "SS_XML_SCHEMACOLLECTION_NAME");
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  726 */     PreparedStatement storedProcPstmt = this.connection.prepareStatement("EXEC sp_columns_100 ?,?,?,?,?,?;"); 
/*  727 */     try { storedProcPstmt.setString(1, (null != table && !table.isEmpty()) ? EscapeIDName(table) : "%");
/*  728 */       storedProcPstmt.setString(2, (null != schema && !schema.isEmpty()) ? EscapeIDName(schema) : "%");
/*  729 */       storedProcPstmt.setString(3, (
/*  730 */           null != catalog && !catalog.isEmpty()) ? catalog : this.connection.getCatalog());
/*  731 */       storedProcPstmt.setString(4, (null != col && !col.isEmpty()) ? EscapeIDName(col) : "%");
/*  732 */       storedProcPstmt.setInt(5, 2);
/*  733 */       storedProcPstmt.setInt(6, 3);
/*      */       
/*  735 */       SQLServerResultSet userRs = null;
/*  736 */       PreparedStatement resultPstmt = null; 
/*  737 */       try { ResultSet rs = storedProcPstmt.executeQuery(); 
/*  738 */         try { StringBuilder azureDwSelectBuilder = new StringBuilder();
/*  739 */           boolean isFirstRow = true;
/*  740 */           while (rs.next()) {
/*  741 */             if (!isFirstRow) {
/*  742 */               azureDwSelectBuilder.append(" UNION ALL ");
/*      */             }
/*  744 */             azureDwSelectBuilder.append(generateAzureDWSelect(rs, getColumnsDWColumns));
/*  745 */             isFirstRow = false;
/*      */           } 
/*      */           
/*  748 */           if (0 == azureDwSelectBuilder.length()) {
/*  749 */             azureDwSelectBuilder.append(generateAzureDWEmptyRS(getColumnsDWColumns));
/*      */           } else {
/*  751 */             azureDwSelectBuilder.append(" ORDER BY TABLE_CAT, TABLE_SCHEM, TABLE_NAME, ORDINAL_POSITION ");
/*      */           } 
/*      */ 
/*      */           
/*  755 */           resultPstmt = this.connection.prepareStatement(azureDwSelectBuilder.toString());
/*  756 */           userRs = (SQLServerResultSet)resultPstmt.executeQuery();
/*  757 */           resultPstmt.closeOnCompletion();
/*  758 */           userRs.getColumn(5).setFilter(new DataTypeFilter());
/*  759 */           userRs.getColumn(7).setFilter(new ZeroFixupFilter());
/*  760 */           userRs.getColumn(8).setFilter(new ZeroFixupFilter());
/*  761 */           userRs.getColumn(16).setFilter(new ZeroFixupFilter());
/*  762 */           if (rs != null) rs.close();  } catch (Throwable throwable) { if (rs != null) try { rs.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException e)
/*  763 */       { if (null != resultPstmt) {
/*      */           try {
/*  765 */             resultPstmt.close();
/*  766 */           } catch (SQLServerException ignore) {
/*  767 */             if (loggerExternal.isLoggable(Level.FINER)) {
/*  768 */               loggerExternal.finer("getColumns() threw an exception when attempting to close PreparedStatement");
/*      */             }
/*      */           } 
/*      */         }
/*      */         
/*  773 */         throw e; }
/*      */       
/*  775 */       SQLServerResultSet sQLServerResultSet1 = userRs;
/*  776 */       if (storedProcPstmt != null) storedProcPstmt.close();  return sQLServerResultSet1; }
/*      */     catch (Throwable throwable) { if (storedProcPstmt != null)
/*      */         try { storedProcPstmt.close(); }
/*      */         catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*      */           throw throwable; }
/*  781 */      } private String generateAzureDWSelect(ResultSet rs, Map<Integer, String> columns) throws SQLException { StringBuilder sb = new StringBuilder("SELECT ");
/*  782 */     for (Map.Entry<Integer, String> p : columns.entrySet()) {
/*  783 */       if (((Integer)p.getKey()).intValue() < 0) {
/*  784 */         sb.append("NULL");
/*      */       } else {
/*  786 */         Object o = rs.getObject(((Integer)p.getKey()).intValue());
/*  787 */         if (null == o) {
/*  788 */           sb.append("NULL");
/*  789 */         } else if (o instanceof Number) {
/*  790 */           if ("IS_AUTOINCREMENT".equalsIgnoreCase(p.getValue()) || "IS_GENERATEDCOLUMN"
/*  791 */             .equalsIgnoreCase(p.getValue())) {
/*  792 */             sb.append("'").append(Util.escapeSingleQuotes(Util.zeroOneToYesNo(((Number)o).intValue())))
/*  793 */               .append("'");
/*      */           } else {
/*  795 */             sb.append(o.toString());
/*      */           } 
/*      */         } else {
/*  798 */           sb.append("'").append(Util.escapeSingleQuotes(o.toString())).append("'");
/*      */         } 
/*      */       } 
/*  801 */       sb.append(" AS ").append(p.getValue()).append(",");
/*      */     } 
/*  803 */     sb.setLength(sb.length() - 1);
/*  804 */     return sb.toString(); }
/*      */ 
/*      */   
/*      */   private String generateAzureDWEmptyRS(Map<Integer, String> columns) throws SQLException {
/*  808 */     StringBuilder sb = new StringBuilder("SELECT TOP 0 ");
/*  809 */     for (Map.Entry<Integer, String> p : columns.entrySet()) {
/*  810 */       sb.append("NULL AS ").append(p.getValue()).append(",");
/*      */     }
/*  812 */     sb.setLength(sb.length() - 1);
/*  813 */     return sb.toString();
/*      */   }
/*      */   
/*  816 */   private static final String[] getFunctionsColumnNames = new String[] { "FUNCTION_CAT", "FUNCTION_SCHEM", "FUNCTION_NAME", "NUM_INPUT_PARAMS", "NUM_OUTPUT_PARAMS", "NUM_RESULT_SETS", "REMARKS", "FUNCTION_TYPE" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getFunctions(String catalog, String schemaPattern, String functionNamePattern) throws SQLException {
/*  823 */     checkClosed();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  830 */     if (null != catalog && catalog.length() == 0) {
/*  831 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidArgument"));
/*  832 */       Object[] msgArgs = { "catalog" };
/*  833 */       SQLServerException.makeFromDriverError(null, null, form.format(msgArgs), null, false);
/*      */     } 
/*      */     
/*  836 */     String[] arguments = new String[3];
/*  837 */     arguments[0] = EscapeIDName(functionNamePattern);
/*  838 */     arguments[1] = EscapeIDName(schemaPattern);
/*  839 */     arguments[2] = catalog;
/*  840 */     return getResultSetWithProvidedColumnNames(catalog, CallableHandles.SP_STORED_PROCEDURES, arguments, getFunctionsColumnNames);
/*      */   }
/*      */ 
/*      */   
/*  844 */   private static final String[] getFunctionsColumnsColumnNames = new String[] { "FUNCTION_CAT", "FUNCTION_SCHEM", "FUNCTION_NAME", "COLUMN_NAME", "COLUMN_TYPE", "DATA_TYPE", "TYPE_NAME", "PRECISION", "LENGTH", "SCALE", "RADIX", "NULLABLE", "REMARKS", "COLUMN_DEF", "SQL_DATA_TYPE", "SQL_DATETIME_SUB", "CHAR_OCTET_LENGTH", "ORDINAL_POSITION", "IS_NULLABLE" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getFunctionColumns(String catalog, String schemaPattern, String functionNamePattern, String columnNamePattern) throws SQLException {
/*  853 */     checkClosed();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  860 */     if (null != catalog && catalog.length() == 0) {
/*  861 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidArgument"));
/*  862 */       Object[] msgArgs = { "catalog" };
/*  863 */       SQLServerException.makeFromDriverError(null, null, form.format(msgArgs), null, false);
/*      */     } 
/*      */     
/*  866 */     String[] arguments = new String[5];
/*      */ 
/*      */     
/*  869 */     arguments[0] = EscapeIDName(functionNamePattern);
/*      */     
/*  871 */     arguments[1] = EscapeIDName(schemaPattern);
/*  872 */     arguments[2] = catalog;
/*      */     
/*  874 */     arguments[3] = EscapeIDName(columnNamePattern);
/*  875 */     arguments[4] = "3";
/*  876 */     SQLServerResultSet rs = getResultSetWithProvidedColumnNames(catalog, CallableHandles.SP_SPROC_COLUMNS, arguments, getFunctionsColumnsColumnNames);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  882 */     rs.getColumn(6).setFilter(new DataTypeFilter());
/*      */     
/*  884 */     if (this.connection.isKatmaiOrLater()) {
/*  885 */       rs.getColumn(8).setFilter(new ZeroFixupFilter());
/*  886 */       rs.getColumn(9).setFilter(new ZeroFixupFilter());
/*  887 */       rs.getColumn(17).setFilter(new ZeroFixupFilter());
/*      */     } 
/*  889 */     return rs;
/*      */   }
/*      */ 
/*      */   
/*      */   public ResultSet getClientInfoProperties() throws SQLException {
/*  894 */     checkClosed();
/*  895 */     return getResultSetFromInternalQueries(null, "SELECT cast(NULL as char(1)) as NAME, cast(0 as int) as MAX_LEN, cast(NULL as char(1)) as DEFAULT_VALUE, cast(NULL as char(1)) as DESCRIPTION  where 0 = 1");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  902 */   private static final String[] getBestRowIdentifierColumnNames = new String[] { "SCOPE", "COLUMN_NAME", "DATA_TYPE", "TYPE_NAME", "COLUMN_SIZE", "BUFFER_LENGTH", "DECIMAL_DIGITS", "PSEUDO_COLUMN" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getBestRowIdentifier(String catalog, String schema, String table, int scope, boolean nullable) throws SQLServerException, SQLTimeoutException {
/*  909 */     if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) {
/*  910 */       loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */     }
/*  912 */     checkClosed();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  918 */     String[] arguments = new String[7];
/*  919 */     arguments[0] = table;
/*  920 */     arguments[1] = schema;
/*  921 */     arguments[2] = catalog;
/*  922 */     arguments[3] = "R";
/*  923 */     if (0 == scope) {
/*  924 */       arguments[4] = "C";
/*      */     } else {
/*  926 */       arguments[4] = "T";
/*  927 */     }  if (nullable) {
/*  928 */       arguments[5] = "U";
/*      */     } else {
/*  930 */       arguments[5] = "O";
/*  931 */     }  arguments[6] = "3";
/*  932 */     SQLServerResultSet rs = getResultSetWithProvidedColumnNames(catalog, CallableHandles.SP_SPECIAL_COLUMNS, arguments, getBestRowIdentifierColumnNames);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  938 */     rs.getColumn(3).setFilter(new DataTypeFilter());
/*  939 */     return rs;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getCrossReference(String cat1, String schem1, String tab1, String cat2, String schem2, String tab2) throws SQLException, SQLTimeoutException {
/*  945 */     if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) {
/*  946 */       loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */     }
/*  948 */     checkClosed();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  955 */     String[] arguments = { tab1, schem1, cat1, tab2, schem2, cat2 };
/*  956 */     return executeSPFkeys(arguments);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getDatabaseProductName() throws SQLServerException {
/*  961 */     checkClosed();
/*  962 */     return "Microsoft SQL Server";
/*      */   }
/*      */ 
/*      */   
/*      */   public String getDatabaseProductVersion() throws SQLServerException {
/*  967 */     checkClosed();
/*  968 */     return this.connection.sqlServerVersion;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getDefaultTransactionIsolation() throws SQLServerException {
/*  973 */     checkClosed();
/*  974 */     return 2;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getDriverMajorVersion() {
/*  979 */     return 9;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getDriverMinorVersion() {
/*  984 */     return 2;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getDriverName() throws SQLServerException {
/*  989 */     checkClosed();
/*  990 */     return "Microsoft JDBC Driver 9.2 for SQL Server";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getDriverVersion() throws SQLServerException {
/*  997 */     int n = getDriverMinorVersion();
/*  998 */     String s = "" + getDriverMajorVersion() + ".";
/*  999 */     s = s + s;
/* 1000 */     s = s + ".";
/* 1001 */     s = s + "1";
/* 1002 */     s = s + ".";
/* 1003 */     s = s + "0";
/* 1004 */     return s;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getExportedKeys(String cat, String schema, String table) throws SQLException, SQLTimeoutException {
/* 1010 */     return getCrossReference(cat, schema, table, null, null, null);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getExtraNameCharacters() throws SQLServerException {
/* 1015 */     checkClosed();
/* 1016 */     return "$#@";
/*      */   }
/*      */ 
/*      */   
/*      */   public String getIdentifierQuoteString() throws SQLServerException {
/* 1021 */     checkClosed();
/* 1022 */     return "\"";
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getImportedKeys(String cat, String schema, String table) throws SQLException, SQLTimeoutException {
/* 1028 */     return getCrossReference(null, null, null, cat, schema, table);
/*      */   }
/*      */   
/*      */   private ResultSet executeSPFkeys(String[] procParams) throws SQLException, SQLTimeoutException {
/* 1032 */     if (!this.connection.isAzureDW()) {
/* 1033 */       String tempTableName = "@jdbc_temp_fkeys_result";
/* 1034 */       String sql = "DECLARE " + tempTableName + " table (PKTABLE_QUALIFIER sysname, PKTABLE_OWNER sysname, PKTABLE_NAME sysname, PKCOLUMN_NAME sysname, FKTABLE_QUALIFIER sysname, FKTABLE_OWNER sysname, FKTABLE_NAME sysname, FKCOLUMN_NAME sysname, KEY_SEQ smallint, UPDATE_RULE smallint, DELETE_RULE smallint, FK_NAME sysname, PK_NAME sysname, DEFERRABILITY smallint);INSERT INTO " + tempTableName + " EXEC sp_fkeys ?,?,?,?,?,?;SELECT  t.PKTABLE_QUALIFIER AS PKTABLE_CAT, t.PKTABLE_OWNER AS PKTABLE_SCHEM, t.PKTABLE_NAME, t.PKCOLUMN_NAME, t.FKTABLE_QUALIFIER AS FKTABLE_CAT, t.FKTABLE_OWNER AS FKTABLE_SCHEM, t.FKTABLE_NAME, t.FKCOLUMN_NAME, t.KEY_SEQ, CASE s.update_referential_action WHEN 1 THEN 0 WHEN 0 THEN 3 WHEN 2 THEN 2 WHEN 3 THEN 4 END as UPDATE_RULE, CASE s.delete_referential_action WHEN 1 THEN 0 WHEN 0 THEN 3 WHEN 2 THEN 2 WHEN 3 THEN 4 END as DELETE_RULE, t.FK_NAME, t.PK_NAME, t.DEFERRABILITY FROM " + tempTableName + " t LEFT JOIN sys.foreign_keys s ON t.FK_NAME = s.name COLLATE database_default AND schema_id(t.FKTABLE_OWNER) = s.schema_id ORDER BY PKTABLE_CAT, PKTABLE_SCHEM, PKTABLE_NAME, KEY_SEQ";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1053 */       SQLServerCallableStatement cstmt = (SQLServerCallableStatement)this.connection.prepareCall(sql);
/* 1054 */       cstmt.closeOnCompletion();
/* 1055 */       for (int i = 0; i < 6; i++) {
/* 1056 */         cstmt.setString(i + 1, procParams[i]);
/*      */       }
/* 1058 */       String currentDB = null;
/* 1059 */       if (null != procParams[2] && !procParams[2].isEmpty()) {
/* 1060 */         currentDB = switchCatalogs(procParams[2]);
/* 1061 */       } else if (null != procParams[5] && !procParams[5].isEmpty()) {
/* 1062 */         currentDB = switchCatalogs(procParams[5]);
/*      */       } 
/* 1064 */       ResultSet rs = cstmt.executeQuery();
/* 1065 */       if (null != currentDB) {
/* 1066 */         switchCatalogs(currentDB);
/*      */       }
/* 1068 */       return rs;
/*      */     } 
/*      */     
/* 1071 */     ResultSet userRs = null;
/* 1072 */     PreparedStatement pstmt = null;
/* 1073 */     StringBuilder azureDwSelectBuilder = new StringBuilder();
/* 1074 */     synchronized (SQLServerDatabaseMetaData.class) {
/* 1075 */       if (null == getImportedKeysDWColumns) {
/* 1076 */         getImportedKeysDWColumns = new LinkedHashMap<>();
/* 1077 */         getImportedKeysDWColumns.put(Integer.valueOf(1), "PKTABLE_CAT");
/* 1078 */         getImportedKeysDWColumns.put(Integer.valueOf(2), "PKTABLE_SCHEM");
/* 1079 */         getImportedKeysDWColumns.put(Integer.valueOf(3), "PKTABLE_NAME");
/* 1080 */         getImportedKeysDWColumns.put(Integer.valueOf(4), "PKCOLUMN_NAME");
/* 1081 */         getImportedKeysDWColumns.put(Integer.valueOf(5), "FKTABLE_CAT");
/* 1082 */         getImportedKeysDWColumns.put(Integer.valueOf(6), "FKTABLE_SCHEM");
/* 1083 */         getImportedKeysDWColumns.put(Integer.valueOf(7), "FKTABLE_NAME");
/* 1084 */         getImportedKeysDWColumns.put(Integer.valueOf(8), "FKCOLUMN_NAME");
/* 1085 */         getImportedKeysDWColumns.put(Integer.valueOf(9), "KEY_SEQ");
/* 1086 */         getImportedKeysDWColumns.put(Integer.valueOf(10), "UPDATE_RULE");
/* 1087 */         getImportedKeysDWColumns.put(Integer.valueOf(11), "DELETE_RULE");
/* 1088 */         getImportedKeysDWColumns.put(Integer.valueOf(12), "FK_NAME");
/* 1089 */         getImportedKeysDWColumns.put(Integer.valueOf(13), "PK_NAME");
/* 1090 */         getImportedKeysDWColumns.put(Integer.valueOf(14), "DEFERRABILITY");
/*      */       } 
/*      */     } 
/* 1093 */     azureDwSelectBuilder.append(generateAzureDWEmptyRS(getImportedKeysDWColumns));
/*      */     try {
/* 1095 */       pstmt = this.connection.prepareStatement(azureDwSelectBuilder.toString());
/* 1096 */       userRs = pstmt.executeQuery();
/* 1097 */       pstmt.closeOnCompletion();
/* 1098 */       return userRs;
/* 1099 */     } catch (SQLException e) {
/* 1100 */       if (null != pstmt) {
/*      */         try {
/* 1102 */           pstmt.close();
/* 1103 */         } catch (SQLServerException ignore) {
/* 1104 */           if (loggerExternal.isLoggable(Level.FINER)) {
/* 1105 */             loggerExternal.finer("executeSPFkeys() threw an exception when attempting to close PreparedStatement");
/*      */           }
/*      */         } 
/*      */       }
/*      */       
/* 1110 */       throw e;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/* 1115 */   private static final String[] getIndexInfoColumnNames = new String[] { "TABLE_CAT", "TABLE_SCHEM", "TABLE_NAME", "NON_UNIQUE", "INDEX_QUALIFIER", "INDEX_NAME", "TYPE", "ORDINAL_POSITION", "COLUMN_NAME", "ASC_OR_DESC", "CARDINALITY", "PAGES", "FILTER_CONDITION" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getIndexInfo(String cat, String schema, String table, boolean unique, boolean approximate) throws SQLServerException, SQLTimeoutException {
/* 1123 */     if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) {
/* 1124 */       loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */     }
/* 1126 */     checkClosed();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1132 */     String[] arguments = new String[6];
/* 1133 */     arguments[0] = table;
/* 1134 */     arguments[1] = schema;
/* 1135 */     arguments[2] = cat;
/*      */     
/* 1137 */     arguments[3] = "%";
/* 1138 */     if (unique) {
/* 1139 */       arguments[4] = "Y";
/*      */     } else {
/* 1141 */       arguments[4] = "N";
/* 1142 */     }  if (approximate) {
/* 1143 */       arguments[5] = "Q";
/*      */     } else {
/* 1145 */       arguments[5] = "E";
/* 1146 */     }  return getResultSetWithProvidedColumnNames(cat, CallableHandles.SP_STATISTICS, arguments, getIndexInfoColumnNames);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxBinaryLiteralLength() throws SQLServerException {
/* 1152 */     checkClosed();
/* 1153 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getMaxCatalogNameLength() throws SQLServerException {
/* 1158 */     checkClosed();
/* 1159 */     return 128;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getMaxCharLiteralLength() throws SQLServerException {
/* 1164 */     checkClosed();
/* 1165 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getMaxColumnNameLength() throws SQLServerException {
/* 1170 */     checkClosed();
/* 1171 */     return 128;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getMaxColumnsInGroupBy() throws SQLServerException {
/* 1176 */     checkClosed();
/* 1177 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getMaxColumnsInIndex() throws SQLServerException {
/* 1182 */     checkClosed();
/* 1183 */     return 16;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getMaxColumnsInOrderBy() throws SQLServerException {
/* 1188 */     checkClosed();
/* 1189 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getMaxColumnsInSelect() throws SQLServerException {
/* 1194 */     checkClosed();
/* 1195 */     return 4096;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getMaxColumnsInTable() throws SQLServerException {
/* 1200 */     checkClosed();
/* 1201 */     return 1024;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getMaxConnections() throws SQLException, SQLTimeoutException {
/* 1206 */     checkClosed(); 
/* 1207 */     try { SQLServerResultSet rs = getResultSetFromInternalQueries(null, "select maximum from sys.configurations where name = 'user connections'");
/*      */       
/* 1209 */       try { if (!rs.next())
/* 1210 */         { boolean bool = false;
/*      */ 
/*      */           
/* 1213 */           if (rs != null) rs.close();  return bool; }  int i = rs.getInt("maximum"); if (rs != null) rs.close();  return i; } catch (Throwable throwable) { if (rs != null) try { rs.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLServerException e)
/*      */     { 
/* 1215 */       try { SQLServerResultSet rs1 = getResultSetFromInternalQueries(null, "sp_configure 'user connections'"); 
/* 1216 */         try { if (!rs1.next())
/* 1217 */           { boolean bool = false;
/*      */ 
/*      */             
/* 1220 */             if (rs1 != null) rs1.close();  return bool; }  int i = rs1.getInt("maximum"); if (rs1 != null) rs1.close();  return i; } catch (Throwable throwable) { if (rs1 != null) try { rs1.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLServerException e1)
/* 1221 */       { return 0; }
/*      */        }
/*      */   
/*      */   }
/*      */ 
/*      */   
/*      */   public int getMaxCursorNameLength() throws SQLServerException {
/* 1228 */     checkClosed();
/* 1229 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getMaxIndexLength() throws SQLServerException {
/* 1234 */     checkClosed();
/* 1235 */     return 900;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getMaxProcedureNameLength() throws SQLServerException {
/* 1240 */     checkClosed();
/* 1241 */     return 128;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getMaxRowSize() throws SQLServerException {
/* 1246 */     checkClosed();
/* 1247 */     return 8060;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getMaxSchemaNameLength() throws SQLServerException {
/* 1252 */     checkClosed();
/* 1253 */     return 128;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getMaxStatementLength() throws SQLServerException {
/* 1258 */     checkClosed();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1267 */     return 65536 * this.connection.getTDSPacketSize();
/*      */   }
/*      */ 
/*      */   
/*      */   public int getMaxStatements() throws SQLServerException {
/* 1272 */     checkClosed();
/* 1273 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getMaxTableNameLength() throws SQLServerException {
/* 1278 */     checkClosed();
/* 1279 */     return 128;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getMaxTablesInSelect() throws SQLServerException {
/* 1284 */     checkClosed();
/* 1285 */     return 256;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getMaxUserNameLength() throws SQLServerException {
/* 1290 */     checkClosed();
/* 1291 */     return 128;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getNumericFunctions() throws SQLServerException {
/* 1296 */     checkClosed();
/* 1297 */     return "ABS,ACOS,ASIN,ATAN,ATAN2,CEILING,COS,COT,DEGREES,EXP,FLOOR,LOG,LOG10,MOD,PI,POWER,RADIANS,RAND,ROUND,SIGN,SIN,SQRT,TAN,TRUNCATE";
/*      */   }
/*      */   
/* 1300 */   private static final String[] getPrimaryKeysColumnNames = new String[] { "TABLE_CAT", "TABLE_SCHEM", "TABLE_NAME", "COLUMN_NAME", "KEY_SEQ", "PK_NAME" };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getPrimaryKeys(String cat, String schema, String table) throws SQLServerException, SQLTimeoutException {
/* 1306 */     if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) {
/* 1307 */       loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */     }
/* 1309 */     checkClosed();
/*      */ 
/*      */ 
/*      */     
/* 1313 */     String[] arguments = new String[3];
/* 1314 */     arguments[0] = table;
/* 1315 */     arguments[1] = schema;
/* 1316 */     arguments[2] = cat;
/* 1317 */     return getResultSetWithProvidedColumnNames(cat, CallableHandles.SP_PKEYS, arguments, getPrimaryKeysColumnNames);
/*      */   }
/*      */   
/* 1320 */   private static final String[] getProcedureColumnsColumnNames = new String[] { "PROCEDURE_CAT", "PROCEDURE_SCHEM", "PROCEDURE_NAME", "COLUMN_NAME", "COLUMN_TYPE", "DATA_TYPE", "TYPE_NAME", "PRECISION", "LENGTH", "SCALE", "RADIX", "NULLABLE", "REMARKS", "COLUMN_DEF", "SQL_DATA_TYPE", "SQL_DATETIME_SUB", "CHAR_OCTET_LENGTH", "ORDINAL_POSITION", "IS_NULLABLE" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getProcedureColumns(String catalog, String schema, String proc, String col) throws SQLServerException, SQLTimeoutException {
/* 1329 */     if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) {
/* 1330 */       loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */     }
/* 1332 */     checkClosed();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1338 */     String[] arguments = new String[5];
/*      */ 
/*      */     
/* 1341 */     proc = EscapeIDName(proc);
/* 1342 */     arguments[0] = proc;
/* 1343 */     arguments[1] = schema;
/* 1344 */     arguments[2] = catalog;
/*      */     
/* 1346 */     col = EscapeIDName(col);
/* 1347 */     arguments[3] = col;
/* 1348 */     arguments[4] = "3";
/* 1349 */     SQLServerResultSet rs = getResultSetWithProvidedColumnNames(catalog, CallableHandles.SP_SPROC_COLUMNS, arguments, getProcedureColumnsColumnNames);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1355 */     rs.getColumn(6).setFilter(new DataTypeFilter());
/* 1356 */     if (this.connection.isKatmaiOrLater()) {
/* 1357 */       rs.getColumn(8).setFilter(new ZeroFixupFilter());
/* 1358 */       rs.getColumn(9).setFilter(new ZeroFixupFilter());
/* 1359 */       rs.getColumn(17).setFilter(new ZeroFixupFilter());
/*      */     } 
/*      */     
/* 1362 */     return rs;
/*      */   }
/*      */   
/* 1365 */   private static final String[] getProceduresColumnNames = new String[] { "PROCEDURE_CAT", "PROCEDURE_SCHEM", "PROCEDURE_NAME", "NUM_INPUT_PARAMS", "NUM_OUTPUT_PARAMS", "NUM_RESULT_SETS", "REMARKS", "PROCEDURE_TYPE" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getProcedures(String catalog, String schema, String proc) throws SQLServerException, SQLTimeoutException {
/* 1372 */     if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) {
/* 1373 */       loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */     }
/*      */     
/* 1376 */     checkClosed();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1381 */     String[] arguments = new String[3];
/* 1382 */     arguments[0] = EscapeIDName(proc);
/* 1383 */     arguments[1] = schema;
/* 1384 */     arguments[2] = catalog;
/* 1385 */     return getResultSetWithProvidedColumnNames(catalog, CallableHandles.SP_STORED_PROCEDURES, arguments, getProceduresColumnNames);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getProcedureTerm() throws SQLServerException {
/* 1391 */     checkClosed();
/* 1392 */     return "stored procedure";
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getPseudoColumns(String catalog, String schemaPattern, String tableNamePattern, String columnNamePattern) throws SQLException {
/* 1398 */     if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) {
/* 1399 */       loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */     }
/*      */     
/* 1402 */     checkClosed();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1408 */     return getResultSetFromInternalQueries(catalog, "SELECT cast(NULL as char(1)) as TABLE_CAT, cast(NULL as char(1)) as TABLE_SCHEM, cast(NULL as char(1)) as TABLE_NAME, cast(NULL as char(1)) as COLUMN_NAME, cast(0 as int) as DATA_TYPE, cast(0 as int) as COLUMN_SIZE, cast(0 as int) as DECIMAL_DIGITS, cast(0 as int) as NUM_PREC_RADIX, cast(NULL as char(1)) as COLUMN_USAGE, cast(NULL as char(1)) as REMARKS, cast(0 as int) as CHAR_OCTET_LENGTH, cast(NULL as char(1)) as IS_NULLABLE where 0 = 1");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getSchemas() throws SQLException, SQLTimeoutException {
/* 1425 */     if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) {
/* 1426 */       loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */     }
/* 1428 */     checkClosed();
/* 1429 */     return getSchemasInternal(null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ResultSet getSchemasInternal(String catalog, String schemaPattern) throws SQLException, SQLTimeoutException {
/*      */     SQLServerResultSet rs;
/* 1440 */     String constSchemas = " ('dbo', 'guest','INFORMATION_SCHEMA','sys','db_owner', 'db_accessadmin', 'db_securityadmin', 'db_ddladmin'  ,'db_backupoperator','db_datareader','db_datawriter','db_denydatareader','db_denydatawriter') ";
/*      */ 
/*      */     
/* 1443 */     String schema = "sys.schemas";
/* 1444 */     String schemaName = "sys.schemas.name";
/* 1445 */     if (null != catalog && catalog.length() != 0) {
/* 1446 */       String catalogId = Util.escapeSQLId(catalog);
/* 1447 */       schema = catalogId + "." + catalogId;
/* 1448 */       schemaName = catalogId + "." + catalogId;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1457 */     String s = "select " + schemaName + " 'TABLE_SCHEM',";
/* 1458 */     if (null != catalog && catalog.length() == 0) {
/* 1459 */       s = s + "null 'TABLE_CATALOG' ";
/*      */     } else {
/* 1461 */       s = s + " CASE WHEN " + s + "  IN " + schemaName + " THEN null ELSE ";
/* 1462 */       if (null != catalog && catalog.length() != 0) {
/* 1463 */         s = s + "'" + s + "' ";
/*      */       } else {
/* 1465 */         s = s + " DB_NAME() ";
/*      */       } 
/* 1467 */       s = s + " END 'TABLE_CATALOG' ";
/*      */     } 
/* 1469 */     s = s + "   from " + s;
/*      */ 
/*      */ 
/*      */     
/* 1473 */     if (null != catalog && catalog.length() == 0) {
/* 1474 */       if (null != schemaPattern) {
/* 1475 */         s = s + " where " + s + " like ?  and ";
/*      */       } else {
/* 1477 */         s = s + " where ";
/* 1478 */       }  s = s + s + " in " + schemaName;
/* 1479 */     } else if (null != schemaPattern) {
/* 1480 */       s = s + " where " + s + " like ?  ";
/*      */     } 
/* 1482 */     s = s + " order by 2, 1";
/* 1483 */     if (logger.isLoggable(Level.FINE)) {
/* 1484 */       logger.fine(toString() + " schema query (" + toString() + ")");
/*      */     }
/*      */     
/* 1487 */     if (null == schemaPattern) {
/* 1488 */       catalog = null;
/* 1489 */       rs = getResultSetFromInternalQueries(catalog, s);
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/* 1495 */       SQLServerPreparedStatement ps = (SQLServerPreparedStatement)this.connection.prepareStatement(s);
/* 1496 */       ps.closeOnCompletion();
/* 1497 */       ps.setString(1, schemaPattern);
/* 1498 */       rs = (SQLServerResultSet)ps.executeQueryInternal();
/*      */     } 
/* 1500 */     return rs;
/*      */   }
/*      */ 
/*      */   
/*      */   public ResultSet getSchemas(String catalog, String schemaPattern) throws SQLException {
/* 1505 */     if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) {
/* 1506 */       loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */     }
/* 1508 */     return getSchemasInternal(catalog, schemaPattern);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getSchemaTerm() throws SQLServerException {
/* 1513 */     checkClosed();
/* 1514 */     return "schema";
/*      */   }
/*      */ 
/*      */   
/*      */   public String getSearchStringEscape() throws SQLServerException {
/* 1519 */     checkClosed();
/* 1520 */     return "\\";
/*      */   }
/*      */ 
/*      */   
/*      */   public String getSQLKeywords() throws SQLServerException {
/* 1525 */     checkClosed();
/* 1526 */     return SQL_KEYWORDS;
/*      */   }
/*      */   
/*      */   private static String createSqlKeyWords() {
/* 1530 */     return "ADD,ALL,ALTER,AND,ANY,AS,ASC,AUTHORIZATION,BACKUP,BEGIN,BETWEEN,BREAK,BROWSE,BULK,BY,CASCADE,CASE,CHECK,CHECKPOINT,CLOSE,CLUSTERED,COALESCE,COLLATE,COLUMN,COMMIT,COMPUTE,CONSTRAINT,CONTAINS,CONTAINSTABLE,CONTINUE,CONVERT,CREATE,CROSS,CURRENT,CURRENT_DATE,CURRENT_TIME,CURRENT_TIMESTAMP,CURRENT_USER,CURSOR,DATABASE,DBCC,DEALLOCATE,DECLARE,DEFAULT,DELETE,DENY,DESC,DISK,DISTINCT,DISTRIBUTED,DOUBLE,DROP,DUMP,ELSE,END,ERRLVL,ESCAPE,EXCEPT,EXEC,EXECUTE,EXISTS,EXIT,EXTERNAL,FETCH,FILE,FILLFACTOR,FOR,FOREIGN,FREETEXT,FREETEXTTABLE,FROM,FULL,FUNCTION,GOTO,GRANT,GROUP,HAVING,HOLDLOCK,IDENTITY,IDENTITY_INSERT,IDENTITYCOL,IF,IN,INDEX,INNER,INSERT,INTERSECT,INTO,IS,JOIN,KEY,KILL,LEFT,LIKE,LINENO,LOAD,MERGE,NATIONAL,NOCHECK,NONCLUSTERED,NOT,NULL,NULLIF,OF,OFF,OFFSETS,ON,OPEN,OPENDATASOURCE,OPENQUERY,OPENROWSET,OPENXML,OPTION,OR,ORDER,OUTER,OVER,PERCENT,PIVOT,PLAN,PRECISION,PRIMARY,PRINT,PROC,PROCEDURE,PUBLIC,RAISERROR,READ,READTEXT,RECONFIGURE,REFERENCES,REPLICATION,RESTORE,RESTRICT,RETURN,REVERT,REVOKE,RIGHT,ROLLBACK,ROWCOUNT,ROWGUIDCOL,RULE,SAVE,SCHEMA,SECURITYAUDIT,SELECT,SEMANTICKEYPHRASETABLE,SEMANTICSIMILARITYDETAILSTABLE,SEMANTICSIMILARITYTABLE,SESSION_USER,SET,SETUSER,SHUTDOWN,SOME,STATISTICS,SYSTEM_USER,TABLE,TABLESAMPLE,TEXTSIZE,THEN,TO,TOP,TRAN,TRANSACTION,TRIGGER,TRUNCATE,TRY_CONVERT,TSEQUAL,UNION,UNIQUE,UNPIVOT,UPDATE,UPDATETEXT,USE,USER,VALUES,VARYING,VIEW,WAITFOR,WHEN,WHERE,WHILE,WITH,WITHIN GROUP,WRITETEXT";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getStringFunctions() throws SQLServerException {
/* 1554 */     checkClosed();
/* 1555 */     return "ASCII,CHAR,CONCAT,DIFFERENCE,INSERT,LCASE,LEFT,LENGTH,LOCATE,LTRIM,REPEAT,REPLACE,RIGHT,RTRIM,SOUNDEX,SPACE,SUBSTRING,UCASE";
/*      */   }
/*      */ 
/*      */   
/*      */   public String getSystemFunctions() throws SQLServerException {
/* 1560 */     checkClosed();
/* 1561 */     return "DATABASE,IFNULL,USER";
/*      */   }
/*      */ 
/*      */   
/* 1565 */   private static final String[] getTablePrivilegesColumnNames = new String[] { "TABLE_CAT", "TABLE_SCHEM", "TABLE_NAME", "GRANTOR", "GRANTEE", "PRIVILEGE", "IS_GRANTABLE" };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getTablePrivileges(String catalog, String schema, String table) throws SQLServerException, SQLTimeoutException {
/* 1571 */     if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) {
/* 1572 */       loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */     }
/* 1574 */     checkClosed();
/* 1575 */     table = EscapeIDName(table);
/* 1576 */     schema = EscapeIDName(schema);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1581 */     String[] arguments = new String[3];
/* 1582 */     arguments[0] = table;
/* 1583 */     arguments[1] = schema;
/* 1584 */     arguments[2] = catalog;
/*      */     
/* 1586 */     return getResultSetWithProvidedColumnNames(catalog, CallableHandles.SP_TABLE_PRIVILEGES, arguments, getTablePrivilegesColumnNames);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getTableTypes() throws SQLException, SQLTimeoutException {
/* 1592 */     if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) {
/* 1593 */       loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */     }
/* 1595 */     checkClosed();
/* 1596 */     String s = "SELECT 'VIEW' 'TABLE_TYPE' UNION SELECT 'TABLE' UNION SELECT 'SYSTEM TABLE'";
/* 1597 */     SQLServerResultSet rs = getResultSetFromInternalQueries(null, s);
/* 1598 */     return rs;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getTimeDateFunctions() throws SQLServerException {
/* 1603 */     checkClosed();
/* 1604 */     return "CURDATE,CURTIME,DAYNAME,DAYOFMONTH,DAYOFWEEK,DAYOFYEAR,HOUR,MINUTE,MONTH,MONTHNAME,NOW,QUARTER,SECOND,TIMESTAMPADD,TIMESTAMPDIFF,WEEK,YEAR";
/*      */   }
/*      */   
/*      */   public ResultSet getTypeInfo() throws SQLException, SQLTimeoutException {
/*      */     SQLServerResultSet rs;
/* 1609 */     if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) {
/* 1610 */       loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */     }
/* 1612 */     checkClosed();
/*      */ 
/*      */ 
/*      */     
/* 1616 */     if (this.connection.isKatmaiOrLater()) {
/* 1617 */       rs = getResultSetFromInternalQueries(null, "sp_datatype_info_100 @ODBCVer=3");
/*      */     } else {
/* 1619 */       rs = getResultSetFromInternalQueries(null, "sp_datatype_info @ODBCVer=3");
/*      */     } 
/* 1621 */     rs.setColumnName(11, "FIXED_PREC_SCALE");
/*      */ 
/*      */ 
/*      */     
/* 1625 */     rs.getColumn(2).setFilter(new DataTypeFilter());
/* 1626 */     return rs;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getURL() throws SQLServerException {
/* 1631 */     checkClosed();
/*      */ 
/*      */     
/* 1634 */     StringBuilder url = new StringBuilder();
/*      */     
/* 1636 */     Properties props = this.connection.activeConnectionProperties;
/* 1637 */     DriverPropertyInfo[] info = SQLServerDriver.getPropertyInfoFromProperties(props);
/* 1638 */     String serverName = null;
/* 1639 */     String portNumber = null;
/* 1640 */     String instanceName = null;
/*      */ 
/*      */ 
/*      */     
/* 1644 */     int index = info.length;
/* 1645 */     while (--index >= 0) {
/* 1646 */       String name = (info[index]).name;
/*      */ 
/*      */       
/* 1649 */       if (!name.equals(SQLServerDriverBooleanProperty.INTEGRATED_SECURITY.toString()) && 
/* 1650 */         !name.equals(SQLServerDriverStringProperty.USER.toString()) && 
/* 1651 */         !name.equals(SQLServerDriverStringProperty.PASSWORD.toString()) && 
/* 1652 */         !name.equals(SQLServerDriverStringProperty.KEY_STORE_SECRET.toString())) {
/* 1653 */         String val = (info[index]).value;
/*      */         
/* 1655 */         if (0 != val.length()) {
/*      */ 
/*      */           
/* 1658 */           if (name.equals(SQLServerDriverStringProperty.SERVER_NAME.toString())) {
/* 1659 */             serverName = val; continue;
/* 1660 */           }  if (name.equals(SQLServerDriverStringProperty.INSTANCE_NAME.toString())) {
/* 1661 */             instanceName = val; continue;
/* 1662 */           }  if (name.equals(SQLServerDriverIntProperty.PORT_NUMBER.toString())) {
/* 1663 */             portNumber = val;
/*      */             continue;
/*      */           } 
/* 1666 */           url.append(name);
/* 1667 */           url.append("=");
/* 1668 */           url.append(val);
/* 1669 */           url.append(";");
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1679 */     url.insert(0, ";");
/* 1680 */     url.insert(0, portNumber);
/* 1681 */     url.insert(0, ":");
/* 1682 */     if (null != instanceName) {
/* 1683 */       url.insert(0, instanceName);
/* 1684 */       url.insert(0, "\\");
/*      */     } 
/* 1686 */     url.insert(0, serverName);
/*      */     
/* 1688 */     url.insert(0, "jdbc:sqlserver://");
/* 1689 */     return url.toString();
/*      */   }
/*      */ 
/*      */   
/*      */   public String getUserName() throws SQLServerException, SQLTimeoutException {
/* 1694 */     if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) {
/* 1695 */       loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */     }
/* 1697 */     checkClosed();
/* 1698 */     String result = "";
/* 1699 */     SQLServerStatement s = (SQLServerStatement)this.connection.createStatement(); 
/* 1700 */     try { SQLServerResultSet rs = s.executeQueryInternal("select system_user");
/*      */       
/* 1702 */       try { boolean next = rs.next();
/* 1703 */         assert next;
/* 1704 */         result = rs.getString(1);
/* 1705 */         if (rs != null) rs.close();  } catch (Throwable throwable) { if (rs != null) try { rs.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  if (s != null) s.close();  } catch (Throwable throwable) { if (s != null)
/* 1706 */         try { s.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  return result;
/*      */   }
/*      */   
/* 1709 */   private static final String[] getVersionColumnsColumnNames = new String[] { "SCOPE", "COLUMN_NAME", "DATA_TYPE", "TYPE_NAME", "COLUMN_SIZE", "BUFFER_LENGTH", "DECIMAL_DIGITS", "PSEUDO_COLUMN" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getVersionColumns(String catalog, String schema, String table) throws SQLServerException, SQLTimeoutException {
/* 1716 */     if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) {
/* 1717 */       loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */     }
/* 1719 */     checkClosed();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1725 */     String[] arguments = new String[7];
/* 1726 */     arguments[0] = table;
/* 1727 */     arguments[1] = schema;
/* 1728 */     arguments[2] = catalog;
/* 1729 */     arguments[3] = "V";
/* 1730 */     arguments[4] = "T";
/* 1731 */     arguments[5] = "U";
/* 1732 */     arguments[6] = "3";
/* 1733 */     SQLServerResultSet rs = getResultSetWithProvidedColumnNames(catalog, CallableHandles.SP_SPECIAL_COLUMNS, arguments, getVersionColumnsColumnNames);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1739 */     rs.getColumn(3).setFilter(new DataTypeFilter());
/* 1740 */     return rs;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isCatalogAtStart() throws SQLServerException {
/* 1745 */     checkClosed();
/* 1746 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isReadOnly() throws SQLServerException {
/* 1751 */     checkClosed();
/* 1752 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean nullPlusNonNullIsNull() throws SQLServerException {
/* 1757 */     checkClosed();
/* 1758 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean nullsAreSortedAtEnd() throws SQLServerException {
/* 1763 */     checkClosed();
/* 1764 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean nullsAreSortedAtStart() throws SQLServerException {
/* 1769 */     checkClosed();
/* 1770 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean nullsAreSortedHigh() throws SQLServerException {
/* 1775 */     checkClosed();
/* 1776 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean nullsAreSortedLow() throws SQLServerException {
/* 1781 */     checkClosed();
/* 1782 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean storesLowerCaseIdentifiers() throws SQLServerException {
/* 1787 */     checkClosed();
/* 1788 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean storesLowerCaseQuotedIdentifiers() throws SQLServerException {
/* 1793 */     checkClosed();
/* 1794 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean storesMixedCaseIdentifiers() throws SQLServerException {
/* 1799 */     checkClosed();
/* 1800 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean storesMixedCaseQuotedIdentifiers() throws SQLServerException {
/* 1805 */     checkClosed();
/* 1806 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean storesUpperCaseIdentifiers() throws SQLServerException {
/* 1811 */     checkClosed();
/* 1812 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean storesUpperCaseQuotedIdentifiers() throws SQLServerException {
/* 1817 */     checkClosed();
/* 1818 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsAlterTableWithAddColumn() throws SQLServerException {
/* 1823 */     checkClosed();
/* 1824 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsAlterTableWithDropColumn() throws SQLServerException {
/* 1829 */     checkClosed();
/* 1830 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsANSI92EntryLevelSQL() throws SQLServerException {
/* 1835 */     checkClosed();
/* 1836 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsANSI92FullSQL() throws SQLServerException {
/* 1841 */     checkClosed();
/* 1842 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsANSI92IntermediateSQL() throws SQLServerException {
/* 1847 */     checkClosed();
/* 1848 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsCatalogsInDataManipulation() throws SQLServerException {
/* 1853 */     checkClosed();
/* 1854 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsCatalogsInIndexDefinitions() throws SQLServerException {
/* 1859 */     checkClosed();
/* 1860 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsCatalogsInPrivilegeDefinitions() throws SQLServerException {
/* 1865 */     checkClosed();
/* 1866 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsCatalogsInProcedureCalls() throws SQLServerException {
/* 1871 */     checkClosed();
/* 1872 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsCatalogsInTableDefinitions() throws SQLServerException {
/* 1877 */     checkClosed();
/* 1878 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsColumnAliasing() throws SQLServerException {
/* 1883 */     checkClosed();
/* 1884 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsConvert() throws SQLServerException {
/* 1889 */     checkClosed();
/* 1890 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsConvert(int fromType, int toType) throws SQLServerException {
/* 1895 */     checkClosed();
/* 1896 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsCoreSQLGrammar() throws SQLServerException {
/* 1901 */     checkClosed();
/* 1902 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsCorrelatedSubqueries() throws SQLServerException {
/* 1907 */     checkClosed();
/* 1908 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsDataDefinitionAndDataManipulationTransactions() throws SQLServerException {
/* 1913 */     checkClosed();
/* 1914 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsDataManipulationTransactionsOnly() throws SQLServerException {
/* 1919 */     checkClosed();
/* 1920 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsDifferentTableCorrelationNames() throws SQLServerException {
/* 1925 */     checkClosed();
/* 1926 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsExpressionsInOrderBy() throws SQLServerException {
/* 1931 */     checkClosed();
/* 1932 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsExtendedSQLGrammar() throws SQLServerException {
/* 1937 */     checkClosed();
/* 1938 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsFullOuterJoins() throws SQLServerException {
/* 1943 */     checkClosed();
/* 1944 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsGroupBy() throws SQLServerException {
/* 1949 */     checkClosed();
/* 1950 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsGroupByBeyondSelect() throws SQLServerException {
/* 1955 */     checkClosed();
/* 1956 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsGroupByUnrelated() throws SQLServerException {
/* 1961 */     checkClosed();
/* 1962 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsIntegrityEnhancementFacility() throws SQLServerException {
/* 1967 */     checkClosed();
/* 1968 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsLikeEscapeClause() throws SQLServerException {
/* 1973 */     checkClosed();
/* 1974 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsLimitedOuterJoins() throws SQLServerException {
/* 1979 */     checkClosed();
/* 1980 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsMinimumSQLGrammar() throws SQLServerException {
/* 1985 */     checkClosed();
/* 1986 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsMixedCaseIdentifiers() throws SQLServerException {
/* 1991 */     checkClosed();
/* 1992 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsMixedCaseQuotedIdentifiers() throws SQLServerException {
/* 1997 */     checkClosed();
/* 1998 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsMultipleResultSets() throws SQLServerException {
/* 2003 */     checkClosed();
/* 2004 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsMultipleTransactions() throws SQLServerException {
/* 2009 */     checkClosed();
/* 2010 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsNonNullableColumns() throws SQLServerException {
/* 2015 */     checkClosed();
/* 2016 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsOpenCursorsAcrossCommit() throws SQLServerException {
/* 2021 */     checkClosed();
/* 2022 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsOpenCursorsAcrossRollback() throws SQLServerException {
/* 2027 */     checkClosed();
/* 2028 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsOpenStatementsAcrossCommit() throws SQLServerException {
/* 2033 */     checkClosed();
/* 2034 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsOpenStatementsAcrossRollback() throws SQLServerException {
/* 2039 */     checkClosed();
/* 2040 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsOrderByUnrelated() throws SQLServerException {
/* 2045 */     checkClosed();
/* 2046 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsOuterJoins() throws SQLServerException {
/* 2051 */     checkClosed();
/* 2052 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsPositionedDelete() throws SQLServerException {
/* 2057 */     checkClosed();
/* 2058 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsPositionedUpdate() throws SQLServerException {
/* 2063 */     checkClosed();
/* 2064 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsSchemasInDataManipulation() throws SQLServerException {
/* 2069 */     checkClosed();
/* 2070 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsSchemasInIndexDefinitions() throws SQLServerException {
/* 2075 */     checkClosed();
/* 2076 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsSchemasInPrivilegeDefinitions() throws SQLServerException {
/* 2081 */     checkClosed();
/* 2082 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsSchemasInProcedureCalls() throws SQLServerException {
/* 2087 */     checkClosed();
/* 2088 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsSchemasInTableDefinitions() throws SQLServerException {
/* 2093 */     checkClosed();
/* 2094 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsSelectForUpdate() throws SQLServerException {
/* 2099 */     checkClosed();
/* 2100 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsStoredProcedures() throws SQLServerException {
/* 2105 */     checkClosed();
/* 2106 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsSubqueriesInComparisons() throws SQLServerException {
/* 2111 */     checkClosed();
/* 2112 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsSubqueriesInExists() throws SQLServerException {
/* 2117 */     checkClosed();
/* 2118 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsSubqueriesInIns() throws SQLServerException {
/* 2123 */     checkClosed();
/* 2124 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsSubqueriesInQuantifieds() throws SQLServerException {
/* 2129 */     checkClosed();
/* 2130 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsTableCorrelationNames() throws SQLServerException {
/* 2135 */     checkClosed();
/* 2136 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsTransactionIsolationLevel(int level) throws SQLServerException {
/* 2141 */     checkClosed();
/* 2142 */     switch (level) {
/*      */       case 1:
/*      */       case 2:
/*      */       case 4:
/*      */       case 8:
/*      */       case 4096:
/* 2148 */         return true;
/*      */     } 
/* 2150 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsTransactions() throws SQLServerException {
/* 2155 */     checkClosed();
/* 2156 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsUnion() throws SQLServerException {
/* 2161 */     checkClosed();
/* 2162 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsUnionAll() throws SQLServerException {
/* 2167 */     checkClosed();
/* 2168 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean usesLocalFilePerTable() throws SQLServerException {
/* 2173 */     checkClosed();
/* 2174 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean usesLocalFiles() throws SQLServerException {
/* 2179 */     checkClosed();
/* 2180 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsResultSetType(int type) throws SQLServerException {
/* 2185 */     checkClosed();
/* 2186 */     checkResultType(type);
/* 2187 */     switch (type) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 1003:
/*      */       case 1004:
/*      */       case 1005:
/*      */       case 1006:
/*      */       case 2003:
/*      */       case 2004:
/* 2198 */         return true;
/*      */     } 
/* 2200 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsResultSetConcurrency(int type, int concurrency) throws SQLServerException {
/* 2205 */     checkClosed();
/* 2206 */     checkResultType(type);
/* 2207 */     checkConcurrencyType(concurrency);
/* 2208 */     switch (type) {
/*      */ 
/*      */       
/*      */       case 1003:
/*      */       case 1005:
/*      */       case 1006:
/*      */       case 2004:
/* 2215 */         return true;
/*      */ 
/*      */       
/*      */       case 1004:
/*      */       case 2003:
/* 2220 */         return (1007 == concurrency);
/*      */     } 
/*      */     
/* 2223 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean ownUpdatesAreVisible(int type) throws SQLServerException {
/* 2228 */     checkClosed();
/* 2229 */     checkResultType(type);
/* 2230 */     return (type == 1006 || 1003 == type || 1005 == type || 1005 == type || 2004 == type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean ownDeletesAreVisible(int type) throws SQLServerException {
/* 2237 */     checkClosed();
/* 2238 */     checkResultType(type);
/* 2239 */     return (type == 1006 || 1003 == type || 1005 == type || 1005 == type || 2004 == type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean ownInsertsAreVisible(int type) throws SQLServerException {
/* 2246 */     checkClosed();
/* 2247 */     checkResultType(type);
/* 2248 */     return (type == 1006 || 1003 == type || 1005 == type || 1005 == type || 2004 == type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean othersUpdatesAreVisible(int type) throws SQLServerException {
/* 2255 */     checkClosed();
/* 2256 */     checkResultType(type);
/* 2257 */     return (type == 1006 || 1003 == type || 1005 == type || 1005 == type || 2004 == type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean othersDeletesAreVisible(int type) throws SQLServerException {
/* 2264 */     checkClosed();
/* 2265 */     checkResultType(type);
/* 2266 */     return (type == 1006 || 1003 == type || 1005 == type || 1005 == type || 2004 == type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean othersInsertsAreVisible(int type) throws SQLServerException {
/* 2273 */     checkClosed();
/* 2274 */     checkResultType(type);
/* 2275 */     return (type == 1006 || 1003 == type || 2004 == type);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean updatesAreDetected(int type) throws SQLServerException {
/* 2281 */     checkClosed();
/* 2282 */     checkResultType(type);
/* 2283 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean deletesAreDetected(int type) throws SQLServerException {
/* 2288 */     checkClosed();
/* 2289 */     checkResultType(type);
/* 2290 */     return (1005 == type);
/*      */   }
/*      */ 
/*      */   
/*      */   private void checkResultType(int type) throws SQLServerException {
/* 2295 */     switch (type) {
/*      */       case 1003:
/*      */       case 1004:
/*      */       case 1005:
/*      */       case 1006:
/*      */       case 2003:
/*      */       case 2004:
/*      */         return;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2309 */     MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidArgument"));
/* 2310 */     Object[] msgArgs = { Integer.valueOf(type) };
/* 2311 */     throw new SQLServerException(null, form.format(msgArgs), null, 0, true);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void checkConcurrencyType(int type) throws SQLServerException {
/* 2317 */     switch (type) {
/*      */       case 1007:
/*      */       case 1008:
/*      */       case 1009:
/*      */       case 1010:
/*      */         return;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2327 */     MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidArgument"));
/* 2328 */     Object[] msgArgs = { Integer.valueOf(type) };
/* 2329 */     throw new SQLServerException(null, form.format(msgArgs), null, 0, true);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean insertsAreDetected(int type) throws SQLServerException {
/* 2334 */     checkClosed();
/* 2335 */     checkResultType(type);
/* 2336 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsBatchUpdates() throws SQLServerException {
/* 2341 */     checkClosed();
/* 2342 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getUDTs(String catalog, String schemaPattern, String typeNamePattern, int[] types) throws SQLException, SQLTimeoutException {
/* 2348 */     if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) {
/* 2349 */       loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */     }
/* 2351 */     checkClosed();
/* 2352 */     return getResultSetFromInternalQueries(catalog, "SELECT cast(NULL as char(1)) as TYPE_CAT, cast(NULL as char(1)) as TYPE_SCHEM, cast(NULL as char(1)) as TYPE_NAME, cast(NULL as char(1)) as CLASS_NAME, cast(0 as int) as DATA_TYPE, cast(NULL as char(1)) as REMARKS, cast(0 as smallint) as BASE_TYPE where 0 = 1");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Connection getConnection() throws SQLServerException {
/* 2364 */     checkClosed();
/* 2365 */     return this.connection.getConnection();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getSQLStateType() throws SQLServerException {
/* 2372 */     checkClosed();
/* 2373 */     if (null != this.connection && this.connection.xopenStates) {
/* 2374 */       return 1;
/*      */     }
/* 2376 */     return 2;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getDatabaseMajorVersion() throws SQLServerException {
/* 2381 */     checkClosed();
/* 2382 */     String s = this.connection.sqlServerVersion;
/* 2383 */     int p = s.indexOf('.');
/* 2384 */     if (p > 0)
/* 2385 */       s = s.substring(0, p); 
/*      */     try {
/* 2387 */       return Integer.parseInt(s);
/* 2388 */     } catch (NumberFormatException e) {
/* 2389 */       return 0;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public int getDatabaseMinorVersion() throws SQLServerException {
/* 2395 */     checkClosed();
/* 2396 */     String s = this.connection.sqlServerVersion;
/* 2397 */     int p = s.indexOf('.');
/* 2398 */     int q = s.indexOf('.', p + 1);
/* 2399 */     if (p > 0 && q > 0)
/* 2400 */       s = s.substring(p + 1, q); 
/*      */     try {
/* 2402 */       return Integer.parseInt(s);
/* 2403 */     } catch (NumberFormatException e) {
/* 2404 */       return 0;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public int getJDBCMajorVersion() throws SQLServerException {
/* 2410 */     checkClosed();
/* 2411 */     return 4;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getJDBCMinorVersion() throws SQLServerException {
/* 2416 */     checkClosed();
/* 2417 */     return 3;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getResultSetHoldability() throws SQLServerException {
/* 2422 */     checkClosed();
/* 2423 */     return 1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public RowIdLifetime getRowIdLifetime() throws SQLException {
/* 2429 */     checkClosed();
/* 2430 */     return RowIdLifetime.ROWID_UNSUPPORTED;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsResultSetHoldability(int holdability) throws SQLServerException {
/* 2435 */     checkClosed();
/* 2436 */     if (1 == holdability || 2 == holdability) {
/* 2437 */       return true;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 2442 */     MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidArgument"));
/* 2443 */     Object[] msgArgs = { Integer.valueOf(holdability) };
/* 2444 */     throw new SQLServerException(null, form.format(msgArgs), null, 0, true);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getAttributes(String catalog, String schemaPattern, String typeNamePattern, String attributeNamePattern) throws SQLException, SQLTimeoutException {
/* 2450 */     if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) {
/* 2451 */       loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */     }
/* 2453 */     checkClosed();
/* 2454 */     return getResultSetFromInternalQueries(catalog, "SELECT cast(NULL as char(1)) as TYPE_CAT, cast(NULL as char(1)) as TYPE_SCHEM, cast(NULL as char(1)) as TYPE_NAME, cast(NULL as char(1)) as ATTR_NAME, cast(0 as int) as DATA_TYPE, cast(NULL as char(1)) as ATTR_TYPE_NAME, cast(0 as int) as ATTR_SIZE, cast(0 as int) as DECIMAL_DIGITS, cast(0 as int) as NUM_PREC_RADIX, cast(0 as int) as NULLABLE, cast(NULL as char(1)) as REMARKS, cast(NULL as char(1)) as ATTR_DEF, cast(0 as int) as SQL_DATA_TYPE, cast(0 as int) as SQL_DATETIME_SUB, cast(0 as int) as CHAR_OCTET_LENGTH, cast(0 as int) as ORDINAL_POSITION, cast(NULL as char(1)) as IS_NULLABLE, cast(NULL as char(1)) as SCOPE_CATALOG, cast(NULL as char(1)) as SCOPE_SCHEMA, cast(NULL as char(1)) as SCOPE_TABLE, cast(0 as smallint) as SOURCE_DATA_TYPE where 0 = 1");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getSuperTables(String catalog, String schemaPattern, String tableNamePattern) throws SQLException, SQLTimeoutException {
/* 2481 */     if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) {
/* 2482 */       loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */     }
/* 2484 */     checkClosed();
/* 2485 */     return getResultSetFromInternalQueries(catalog, "SELECT cast(NULL as char(1)) as TYPE_CAT, cast(NULL as char(1)) as TYPE_SCHEM, cast(NULL as char(1)) as TYPE_NAME, cast(NULL as char(1)) as SUPERTABLE_NAME where 0 = 1");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getSuperTypes(String catalog, String schemaPattern, String typeNamePattern) throws SQLException, SQLTimeoutException {
/* 2495 */     if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) {
/* 2496 */       loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */     }
/* 2498 */     checkClosed();
/* 2499 */     return getResultSetFromInternalQueries(catalog, "SELECT cast(NULL as char(1)) as TYPE_CAT, cast(NULL as char(1)) as TYPE_SCHEM, cast(NULL as char(1)) as TYPE_NAME, cast(NULL as char(1)) as SUPERTYPE_CAT, cast(NULL as char(1)) as SUPERTYPE_SCHEM, cast(NULL as char(1)) as SUPERTYPE_NAME where 0 = 1");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsGetGeneratedKeys() throws SQLServerException {
/* 2510 */     checkClosed();
/* 2511 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsMultipleOpenResults() throws SQLServerException {
/* 2516 */     checkClosed();
/* 2517 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsNamedParameters() throws SQLServerException {
/* 2522 */     checkClosed();
/* 2523 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsSavepoints() throws SQLServerException {
/* 2528 */     checkClosed();
/* 2529 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsStatementPooling() throws SQLException {
/* 2534 */     checkClosed();
/* 2535 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsStoredFunctionsUsingCallSyntax() throws SQLException {
/* 2540 */     checkClosed();
/* 2541 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean locatorsUpdateCopy() throws SQLException {
/* 2546 */     checkClosed();
/* 2547 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getDatabaseCompatibilityLevel() throws SQLException {
/* 2562 */     checkClosed();
/* 2563 */     String database = this.connection.getCatalog();
/* 2564 */     SQLServerResultSet rs = getResultSetFromInternalQueries(null, "select name, compatibility_level from sys.databases where name = '" + database + "'");
/*      */     
/* 2566 */     if (!rs.next()) {
/* 2567 */       return 0;
/*      */     }
/* 2569 */     return rs.getInt("compatibility_level");
/*      */   }
/*      */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerDatabaseMetaData.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */