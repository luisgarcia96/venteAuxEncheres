/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.security.GeneralSecurityException;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.SecureRandom;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface ISQLServerEnclaveProvider
/*     */ {
/*     */   public static final String SDPE1 = "EXEC sp_describe_parameter_encryption ?,?";
/*     */   public static final String SDPE2 = "EXEC sp_describe_parameter_encryption ?,?,?";
/*     */   
/*     */   default byte[] getEnclavePackage(String userSQL, ArrayList<byte[]> enclaveCEKs) throws SQLServerException {
/*  56 */     EnclaveSession enclaveSession = getEnclaveSession();
/*  57 */     if (null != enclaveSession) {
/*     */       try {
/*  59 */         ByteArrayOutputStream enclavePackage = new ByteArrayOutputStream();
/*  60 */         enclavePackage.write(enclaveSession.getSessionID());
/*  61 */         ByteArrayOutputStream keys = new ByteArrayOutputStream();
/*  62 */         byte[] randomGUID = new byte[16];
/*  63 */         SecureRandom.getInstanceStrong().nextBytes(randomGUID);
/*  64 */         keys.write(randomGUID);
/*  65 */         keys.write(ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(enclaveSession.getCounter())
/*  66 */             .array());
/*  67 */         keys.write(MessageDigest.getInstance("SHA-256").digest(userSQL.getBytes(StandardCharsets.UTF_16LE)));
/*  68 */         for (byte[] b : enclaveCEKs) {
/*  69 */           keys.write(b);
/*     */         }
/*  71 */         enclaveCEKs.clear();
/*     */         
/*  73 */         SQLServerAeadAes256CbcHmac256EncryptionKey encryptedKey = new SQLServerAeadAes256CbcHmac256EncryptionKey(enclaveSession.getSessionSecret(), "AEAD_AES_256_CBC_HMAC_SHA256");
/*  74 */         SQLServerAeadAes256CbcHmac256Algorithm algo = new SQLServerAeadAes256CbcHmac256Algorithm(encryptedKey, SQLServerEncryptionType.Randomized, (byte)1);
/*     */         
/*  76 */         enclavePackage.write(algo.encryptData(keys.toByteArray()));
/*  77 */         return enclavePackage.toByteArray();
/*  78 */       } catch (GeneralSecurityException|SQLServerException|IOException e) {
/*  79 */         SQLServerException.makeFromDriverError(null, this, e.getLocalizedMessage(), "0", false);
/*     */       } 
/*     */     }
/*  82 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   default ResultSet executeSDPEv2(PreparedStatement stmt, String userSql, String preparedTypeDefinitions, BaseAttestationRequest req) throws SQLException, IOException {
/*  87 */     ((SQLServerPreparedStatement)stmt).isInternalEncryptionQuery = true;
/*  88 */     stmt.setNString(1, userSql);
/*  89 */     if (preparedTypeDefinitions != null && preparedTypeDefinitions.length() != 0) {
/*  90 */       stmt.setNString(2, preparedTypeDefinitions);
/*     */     } else {
/*  92 */       stmt.setNString(2, "");
/*     */     } 
/*  94 */     stmt.setBytes(3, req.getBytes());
/*  95 */     return ((SQLServerPreparedStatement)stmt).executeQueryInternal();
/*     */   }
/*     */ 
/*     */   
/*     */   default ResultSet executeSDPEv1(PreparedStatement stmt, String userSql, String preparedTypeDefinitions) throws SQLException {
/* 100 */     ((SQLServerPreparedStatement)stmt).isInternalEncryptionQuery = true;
/* 101 */     stmt.setNString(1, userSql);
/* 102 */     if (preparedTypeDefinitions != null && preparedTypeDefinitions.length() != 0) {
/* 103 */       stmt.setNString(2, preparedTypeDefinitions);
/*     */     } else {
/* 105 */       stmt.setNString(2, "");
/*     */     } 
/* 107 */     return ((SQLServerPreparedStatement)stmt).executeQueryInternal();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   default void processSDPEv1(String userSql, String preparedTypeDefinitions, Parameter[] params, ArrayList<String> parameterNames, SQLServerConnection connection, PreparedStatement stmt, ResultSet rs, ArrayList<byte[]> enclaveRequestedCEKs) throws SQLException {
/* 113 */     Map<Integer, CekTableEntry> cekList = new HashMap<>();
/* 114 */     CekTableEntry cekEntry = null;
/* 115 */     boolean isRequestedByEnclave = false;
/* 116 */     while (rs.next()) {
/* 117 */       int currentOrdinal = rs.getInt(DescribeParameterEncryptionResultSet1.KeyOrdinal.value());
/* 118 */       if (!cekList.containsKey(Integer.valueOf(currentOrdinal))) {
/* 119 */         cekEntry = new CekTableEntry(currentOrdinal);
/* 120 */         cekList.put(Integer.valueOf(cekEntry.ordinal), cekEntry);
/*     */       } else {
/* 122 */         cekEntry = cekList.get(Integer.valueOf(currentOrdinal));
/*     */       } 
/*     */       
/* 125 */       String keyStoreName = rs.getString(DescribeParameterEncryptionResultSet1.ProviderName.value());
/* 126 */       String algo = rs.getString(DescribeParameterEncryptionResultSet1.KeyEncryptionAlgorithm.value());
/* 127 */       String keyPath = rs.getString(DescribeParameterEncryptionResultSet1.KeyPath.value());
/*     */       
/* 129 */       int dbID = rs.getInt(DescribeParameterEncryptionResultSet1.DbId.value());
/* 130 */       byte[] mdVer = rs.getBytes(DescribeParameterEncryptionResultSet1.KeyMdVersion.value());
/* 131 */       int keyID = rs.getInt(DescribeParameterEncryptionResultSet1.KeyId.value());
/* 132 */       byte[] encryptedKey = rs.getBytes(DescribeParameterEncryptionResultSet1.EncryptedKey.value());
/*     */       
/* 134 */       cekEntry.add(encryptedKey, dbID, keyID, rs.getInt(DescribeParameterEncryptionResultSet1.KeyVersion.value()), mdVer, keyPath, keyStoreName, algo);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 140 */       if (ColumnEncryptionVersion.AE_v2.value() <= connection.getServerColumnEncryptionVersion().value())
/*     */       {
/* 142 */         isRequestedByEnclave = rs.getBoolean(DescribeParameterEncryptionResultSet1.IsRequestedByEnclave.value());
/*     */       }
/*     */       
/* 145 */       if (isRequestedByEnclave) {
/* 146 */         byte[] keySignature = rs.getBytes(DescribeParameterEncryptionResultSet1.EnclaveCMKSignature.value());
/* 147 */         String serverName = connection.getTrustedServerNameAE();
/* 148 */         SQLServerSecurityUtility.verifyColumnMasterKeyMetadata(connection, keyStoreName, keyPath, serverName, isRequestedByEnclave, keySignature);
/*     */ 
/*     */ 
/*     */         
/* 152 */         ByteBuffer aev2CekEntry = ByteBuffer.allocate(46);
/* 153 */         aev2CekEntry.order(ByteOrder.LITTLE_ENDIAN).putInt(dbID);
/* 154 */         aev2CekEntry.put(mdVer);
/* 155 */         aev2CekEntry.putShort((short)keyID);
/* 156 */         aev2CekEntry.put(connection.getColumnEncryptionKeyStoreProvider(keyStoreName)
/* 157 */             .decryptColumnEncryptionKey(keyPath, algo, encryptedKey));
/* 158 */         enclaveRequestedCEKs.add(aev2CekEntry.array());
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 163 */     if (!stmt.getMoreResults()) {
/* 164 */       throw new SQLServerException(null, SQLServerException.getErrString("R_UnexpectedDescribeParamFormat"), null, 0, false);
/*     */     }
/*     */ 
/*     */     
/* 168 */     rs = stmt.getResultSet();
/* 169 */     while (rs.next() && null != params) {
/* 170 */       String paramName = rs.getString(DescribeParameterEncryptionResultSet2.ParameterName.value());
/* 171 */       int paramIndex = parameterNames.indexOf(paramName);
/* 172 */       int cekOrdinal = rs.getInt(DescribeParameterEncryptionResultSet2.ColumnEncryptionKeyOrdinal.value());
/* 173 */       cekEntry = cekList.get(Integer.valueOf(cekOrdinal));
/*     */ 
/*     */       
/* 176 */       if (null != cekEntry && cekList.size() < cekOrdinal) {
/*     */         
/* 178 */         MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_InvalidEncryptionKeyOrdinal"));
/* 179 */         Object[] msgArgs = { Integer.valueOf(cekOrdinal), Integer.valueOf(cekEntry.getSize()) };
/* 180 */         throw new SQLServerException(null, form.format(msgArgs), null, 0, false);
/*     */       } 
/*     */       
/* 183 */       SQLServerEncryptionType encType = SQLServerEncryptionType.of((byte)rs.getInt(DescribeParameterEncryptionResultSet2.ColumnEncrytionType.value()));
/* 184 */       if (SQLServerEncryptionType.PlainText != encType) {
/* 185 */         (params[paramIndex])
/*     */ 
/*     */           
/* 188 */           .cryptoMeta = new CryptoMetadata(cekEntry, (short)cekOrdinal, (byte)rs.getInt(DescribeParameterEncryptionResultSet2.ColumnEncryptionAlgorithm.value()), null, encType.value, (byte)rs.getInt(DescribeParameterEncryptionResultSet2.NormalizationRuleVersion.value()));
/*     */         
/* 190 */         SQLServerSecurityUtility.decryptSymmetricKey((params[paramIndex]).cryptoMeta, connection); continue;
/*     */       } 
/* 192 */       if (params[paramIndex].getForceEncryption()) {
/*     */         
/* 194 */         MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_ForceEncryptionTrue_HonorAETrue_UnencryptedColumn"));
/* 195 */         Object[] msgArgs = { userSql, Integer.valueOf(paramIndex + 1) };
/* 196 */         SQLServerException.makeFromDriverError(null, connection, form.format(msgArgs), "0", true);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   void getAttestationParameters(String paramString) throws SQLServerException;
/*     */   
/*     */   ArrayList<byte[]> createEnclaveSession(SQLServerConnection paramSQLServerConnection, String paramString1, String paramString2, Parameter[] paramArrayOfParameter, ArrayList<String> paramArrayList) throws SQLServerException;
/*     */   
/*     */   void invalidateEnclaveSession();
/*     */   
/*     */   EnclaveSession getEnclaveSession();
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\ISQLServerEnclaveProvider.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */