/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.text.MessageFormat;
/*     */ import java.time.Instant;
/*     */ import java.util.Arrays;
/*     */ import java.util.concurrent.ThreadLocalRandom;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.crypto.Mac;
/*     */ import javax.crypto.spec.SecretKeySpec;
/*     */ import mssql.security.provider.MD4;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class NTLMAuthentication
/*     */   extends SSPIAuthentication
/*     */ {
/*  34 */   private final Logger logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.NTLMAuthentication");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  45 */   private static final byte[] NTLM_HEADER_SIGNATURE = new byte[] { 78, 84, 76, 77, 83, 83, 80, 0 };
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int NTLM_MESSAGE_TYPE_NEGOTIATE = 1;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int NTLM_MESSAGE_TYPE_CHALLENGE = 2;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int NTLM_MESSAGE_TYPE_AUTHENTICATE = 3;
/*     */ 
/*     */   
/*  60 */   private static final byte[] NTLM_CLIENT_CHALLENGE_RESPONSE_TYPE = new byte[] { 1, 1 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   private static final byte[] NTLM_CLIENT_CHALLENGE_RESERVED1 = new byte[] { 0, 0 };
/*  72 */   private static final byte[] NTLM_CLIENT_CHALLENGE_RESERVED2 = new byte[] { 0, 0, 0, 0 };
/*  73 */   private static final byte[] NTLM_CLIENT_CHALLENGE_RESERVED3 = new byte[] { 0, 0, 0, 0 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  91 */   private static final byte[] NTLM_LMCHALLENAGERESPONSE = new byte[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 102 */   private static final byte[] NTLMSSP_VERSION = new byte[] { 0, 0, 0, 0, 0, 0, 0, 0 };
/*     */ 
/*     */ 
/*     */   
/*     */   private static final long NTLMSSP_NEGOTIATE_UNICODE = 1L;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final long NTLMSSP_REQUEST_TARGET = 4L;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final long NTLMSSP_NEGOTIATE_OEM_DOMAIN_SUPPLIED = 4096L;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final long NTLMSSP_NEGOTIATE_OEM_WORKSTATION_SUPPLIED = 8192L;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final long NTLMSSP_NEGOTIATE_TARGET_INFO = 8388608L;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final long NTLMSSP_NEGOTIATE_ALWAYS_SIGN = 32768L;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final long NTLMSSP_NEGOTIATE_EXTENDED_SESSIONSECURITY = 524288L;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final short NTLM_AVID_MSVAVEOL = 0;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final short NTLM_AVID_MSVAVNBCOMPUTERNAME = 1;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final short NTLM_AVID_MSVAVNBDOMAINNAME = 2;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final short NTLM_AVID_MSVAVDNSCOMPUTERNAME = 3;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final short NTLM_AVID_MSVAVDNSDOMAINNAME = 4;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final short NTLM_AVID_MSVAVDNSTREENAME = 5;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final short NTLM_AVID_MSVAVFLAGS = 6;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final short NTLM_AVID_MSVAVTIMESTAMP = 7;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final short NTLM_AVID_MSVAVSINGLEHOST = 8;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final short NTLM_AVID_MSVAVTARGETNAME = 9;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int NTLM_AVID_LENGTH = 2;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int NTLM_AVLEN_LENGTH = 2;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int NTLM_AVFLAG_VALUE_MIC = 2;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int NTLM_MIC_LENGTH = 16;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int NTLM_AVID_MSVAVFLAGS_LEN = 4;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int NTLM_NEGOTIATE_PAYLOAD_OFFSET = 32;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int NTLM_AUTHENTICATE_PAYLOAD_OFFSET = 88;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int NTLM_CLIENT_NONCE_LENGTH = 8;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int NTLM_SERVER_CHALLENGE_LENGTH = 8;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int NTLM_TIMESTAMP_LENGTH = 8;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final long WINDOWS_EPOCH_DIFF = 11644473600L;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class NTLMContext
/*     */   {
/*     */     private final String domainName;
/*     */ 
/*     */ 
/*     */     
/*     */     private final byte[] domainUbytes;
/*     */ 
/*     */ 
/*     */     
/*     */     private final String upperUserName;
/*     */ 
/*     */ 
/*     */     
/*     */     private final byte[] userNameUbytes;
/*     */ 
/*     */ 
/*     */     
/*     */     private final byte[] passwordHash;
/*     */ 
/*     */     
/*     */     private String workstation;
/*     */ 
/*     */     
/*     */     private final byte[] spnUbytes;
/*     */ 
/*     */     
/* 246 */     private Mac mac = null;
/*     */ 
/*     */     
/* 249 */     private long negotiateFlags = 0L;
/*     */ 
/*     */     
/* 252 */     private byte[] sessionBaseKey = null;
/*     */ 
/*     */     
/* 255 */     private byte[] timestamp = null;
/*     */ 
/*     */     
/* 258 */     private byte[] targetInfo = null;
/*     */ 
/*     */     
/* 261 */     private byte[] serverChallenge = new byte[8];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 268 */     private byte[] negotiateMsg = null;
/* 269 */     private byte[] challengeMsg = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     NTLMContext(SQLServerConnection con, String domainName, String userName, byte[] passwordHash, String workstation) throws SQLServerException {
/* 290 */       this.domainName = domainName.toUpperCase();
/* 291 */       this.domainUbytes = NTLMAuthentication.unicode(this.domainName);
/*     */       
/* 293 */       this.userNameUbytes = (null != userName) ? NTLMAuthentication.unicode(userName) : null;
/* 294 */       this.upperUserName = (null != userName) ? userName.toUpperCase() : null;
/*     */       
/* 296 */       this.passwordHash = passwordHash;
/*     */       
/* 298 */       this.workstation = workstation;
/*     */       
/* 300 */       String spn = (null != con) ? NTLMAuthentication.this.getSpn(con) : null;
/* 301 */       this.spnUbytes = (null != spn) ? NTLMAuthentication.unicode(spn) : null;
/*     */       
/* 303 */       if (NTLMAuthentication.this.logger.isLoggable(Level.FINEST)) {
/* 304 */         NTLMAuthentication.this.logger.finest(toString() + " SPN detected: " + toString());
/*     */       }
/*     */       
/*     */       try {
/* 308 */         this.mac = Mac.getInstance("HmacMD5");
/* 309 */       } catch (NoSuchAlgorithmException e) {
/* 310 */         MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_ntlmHmacMD5Error"));
/* 311 */         Object[] msgArgs = { domainName, e.getMessage() };
/* 312 */         throw new SQLServerException(form.format(msgArgs), e);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/* 318 */   private NTLMContext context = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   NTLMAuthentication(SQLServerConnection con, String domainName, String userName, byte[] passwordHash, String workstation) throws SQLServerException {
/* 338 */     if (null == this.context) {
/* 339 */       this.context = new NTLMContext(con, domainName, userName, passwordHash, workstation);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] generateClientContext(byte[] inToken, boolean[] done) throws SQLServerException {
/* 356 */     return initializeSecurityContext(inToken, done);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void releaseClientContext() {
/* 367 */     this.context = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseNtlmChallenge(byte[] inToken) throws SQLServerException {
/* 382 */     ByteBuffer token = ByteBuffer.wrap(inToken).order(ByteOrder.LITTLE_ENDIAN);
/*     */ 
/*     */     
/* 385 */     byte[] signature = new byte[NTLM_HEADER_SIGNATURE.length];
/* 386 */     token.get(signature);
/* 387 */     if (!Arrays.equals(signature, NTLM_HEADER_SIGNATURE)) {
/* 388 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_ntlmSignatureError"));
/* 389 */       Object[] msgArgs = { signature };
/* 390 */       throw new SQLServerException(form.format(msgArgs), null);
/*     */     } 
/*     */ 
/*     */     
/* 394 */     int messageType = token.getInt();
/* 395 */     if (messageType != 2) {
/* 396 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_ntlmMessageTypeError"));
/* 397 */       Object[] msgArgs = { Integer.valueOf(messageType) };
/* 398 */       throw new SQLServerException(form.format(msgArgs), null);
/*     */     } 
/*     */ 
/*     */     
/* 402 */     int targetNameLen = token.getShort();
/* 403 */     token.getShort();
/* 404 */     token.getInt();
/*     */ 
/*     */     
/* 407 */     token.getInt();
/*     */ 
/*     */     
/* 410 */     token.get(this.context.serverChallenge);
/*     */ 
/*     */     
/* 413 */     token.getLong();
/*     */ 
/*     */     
/* 416 */     int targetInfoLen = token.getShort();
/* 417 */     token.getShort();
/* 418 */     token.getInt();
/*     */     
/* 420 */     token.getLong();
/*     */ 
/*     */     
/* 423 */     byte[] targetName = new byte[targetNameLen];
/* 424 */     token.get(targetName);
/*     */ 
/*     */     
/* 427 */     this.context.targetInfo = new byte[targetInfoLen];
/* 428 */     token.get(this.context.targetInfo);
/* 429 */     if (0 == this.context.targetInfo.length) {
/* 430 */       throw new SQLServerException(SQLServerException.getErrString("R_ntlmNoTargetInfo"), null);
/*     */     }
/*     */ 
/*     */     
/* 434 */     ByteBuffer targetInfoBuf = ByteBuffer.wrap(this.context.targetInfo).order(ByteOrder.LITTLE_ENDIAN);
/* 435 */     boolean done = false;
/* 436 */     for (int i = 0; i < this.context.targetInfo.length && !done; ) {
/* 437 */       MessageFormat form; Object[] msgArgs; int id = targetInfoBuf.getShort();
/* 438 */       byte[] value = new byte[targetInfoBuf.getShort()];
/* 439 */       targetInfoBuf.get(value);
/* 440 */       switch (id) {
/*     */         case 7:
/* 442 */           if (value.length > 0) {
/* 443 */             this.context.timestamp = new byte[8];
/* 444 */             System.arraycopy(value, 0, this.context.timestamp, 0, 8);
/*     */           } 
/*     */           break;
/*     */         case 0:
/* 448 */           done = true;
/*     */           break;
/*     */         case 1:
/*     */         case 2:
/*     */         case 3:
/*     */         case 4:
/*     */         case 5:
/*     */         case 6:
/*     */         case 8:
/*     */         case 9:
/*     */           break;
/*     */         default:
/* 460 */           form = new MessageFormat(SQLServerException.getErrString("R_ntlmUnknownValue"));
/* 461 */           msgArgs = new Object[] { value };
/* 462 */           throw new SQLServerException(form.format(msgArgs), null);
/*     */       } 
/*     */       
/* 465 */       if (this.logger.isLoggable(Level.FINEST)) {
/* 466 */         this.logger.finest(toString() + " NTLM Challenge Message target info: AvId " + toString());
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 478 */     if (null == this.context.timestamp || 0 >= this.context.timestamp.length) {
/*     */       
/* 480 */       if (this.logger.isLoggable(Level.WARNING)) {
/* 481 */         this.logger.warning(toString() + " NTLM Challenge Message target info error: Missing timestamp.");
/*     */       }
/*     */     } else {
/*     */       
/* 485 */       this.context.challengeMsg = new byte[inToken.length];
/* 486 */       System.arraycopy(inToken, 0, this.context.challengeMsg, 0, inToken.length);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] initializeSecurityContext(byte[] inToken, boolean[] done) throws SQLServerException {
/* 502 */     if (null == inToken || 0 == inToken.length) {
/* 503 */       return generateNtlmNegotiate();
/*     */     }
/*     */     
/* 506 */     parseNtlmChallenge(inToken);
/*     */ 
/*     */     
/* 509 */     done[0] = true;
/* 510 */     return generateNtlmAuthenticate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] generateClientChallengeBlob(byte[] clientNonce) {
/* 537 */     ByteBuffer time = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN);
/* 538 */     time.putLong(TimeUnit.SECONDS.toNanos(Instant.now().getEpochSecond() + 11644473600L) / 100L);
/* 539 */     byte[] currentTime = time.array();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 548 */     ByteBuffer token = ByteBuffer.allocate(NTLM_CLIENT_CHALLENGE_RESPONSE_TYPE.length + NTLM_CLIENT_CHALLENGE_RESERVED1.length + NTLM_CLIENT_CHALLENGE_RESERVED2.length + currentTime.length + 8 + NTLM_CLIENT_CHALLENGE_RESERVED3.length + this.context.targetInfo.length + 2 + 2 + 4 + 2 + 2 + this.context.spnUbytes.length).order(ByteOrder.LITTLE_ENDIAN);
/*     */     
/* 550 */     token.put(NTLM_CLIENT_CHALLENGE_RESPONSE_TYPE);
/* 551 */     token.put(NTLM_CLIENT_CHALLENGE_RESERVED1);
/* 552 */     token.put(NTLM_CLIENT_CHALLENGE_RESERVED2);
/*     */     
/* 554 */     token.put(currentTime, 0, 8);
/* 555 */     token.put(clientNonce, 0, 8);
/* 556 */     token.put(NTLM_CLIENT_CHALLENGE_RESERVED3);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 563 */     if (null == this.context.timestamp || 0 >= this.context.timestamp.length) {
/* 564 */       token.put(this.context.targetInfo, 0, this.context.targetInfo.length);
/* 565 */       if (this.logger.isLoggable(Level.WARNING)) {
/* 566 */         this.logger.warning(toString() + " MsvAvTimestamp not recieved from SQL Server in Challenge Message. MIC field will not be set.");
/*     */       }
/*     */     }
/*     */     else {
/*     */       
/* 571 */       token.put(this.context.targetInfo, 0, this.context.targetInfo.length - 2 - 2);
/*     */ 
/*     */       
/* 574 */       token.putShort((short)6);
/* 575 */       token.putShort((short)4);
/* 576 */       token.putInt(2);
/*     */     } 
/*     */ 
/*     */     
/* 580 */     token.putShort((short)9);
/* 581 */     token.putShort((short)this.context.spnUbytes.length);
/* 582 */     token.put(this.context.spnUbytes, 0, this.context.spnUbytes.length);
/*     */ 
/*     */     
/* 585 */     token.putShort((short)0);
/* 586 */     token.putShort((short)0);
/*     */     
/* 588 */     return token.array();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] hmacMD5(byte[] key, byte[] data) throws InvalidKeyException {
/* 605 */     SecretKeySpec keySpec = new SecretKeySpec(key, "HmacMD5");
/* 606 */     this.context.mac.init(keySpec);
/* 607 */     return this.context.mac.doFinal(data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static byte[] md4(byte[] str) {
/* 618 */     MD4 md = new MD4();
/* 619 */     md.reset();
/* 620 */     md.update(str);
/* 621 */     return md.digest();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static byte[] unicode(String str) {
/* 632 */     return (null != str) ? str.getBytes(StandardCharsets.UTF_16LE) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] concat(byte[] arr1, byte[] arr2) {
/* 645 */     if (null == arr1 || null == arr2) {
/* 646 */       return null;
/*     */     }
/*     */     
/* 649 */     byte[] temp = new byte[arr1.length + arr2.length];
/* 650 */     System.arraycopy(arr1, 0, temp, 0, arr1.length);
/* 651 */     System.arraycopy(arr2, 0, temp, arr1.length, arr2.length);
/* 652 */     return temp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int getByteArrayLength(byte[] arr) {
/* 663 */     return (null == arr) ? 0 : arr.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] ntowfv2() throws InvalidKeyException {
/* 674 */     return hmacMD5(this.context.passwordHash, 
/* 675 */         (null != this.context.upperUserName) ? unicode(this.context.upperUserName + this.context.upperUserName) : 
/* 676 */         unicode(this.context.domainName));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] computeResponse(byte[] responseKeyNT) throws InvalidKeyException {
/* 703 */     byte[] clientNonce = new byte[8];
/* 704 */     ThreadLocalRandom.current().nextBytes(clientNonce);
/*     */ 
/*     */     
/* 707 */     byte[] temp = generateClientChallengeBlob(clientNonce);
/*     */     
/* 709 */     byte[] ntProofStr = hmacMD5(responseKeyNT, concat(this.context.serverChallenge, temp));
/*     */     
/* 711 */     this.context.sessionBaseKey = hmacMD5(responseKeyNT, ntProofStr);
/*     */     
/* 713 */     return concat(ntProofStr, temp);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] getNtChallengeResp() throws InvalidKeyException {
/* 726 */     byte[] responseKeyNT = ntowfv2();
/* 727 */     return computeResponse(responseKeyNT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] generateNtlmAuthenticate() throws SQLServerException {
/* 740 */     int domainNameLen = getByteArrayLength(this.context.domainUbytes);
/* 741 */     int userNameLen = getByteArrayLength(this.context.userNameUbytes);
/* 742 */     byte[] workstationBytes = unicode(this.context.workstation);
/* 743 */     int workstationLen = getByteArrayLength(workstationBytes);
/* 744 */     byte[] msg = null;
/*     */ 
/*     */     
/*     */     try {
/* 748 */       byte[] ntChallengeResp = getNtChallengeResp();
/* 749 */       int ntChallengeLen = getByteArrayLength(ntChallengeResp);
/*     */ 
/*     */ 
/*     */       
/* 753 */       ByteBuffer token = ByteBuffer.allocate(88 + NTLM_LMCHALLENAGERESPONSE.length + ntChallengeLen + domainNameLen + userNameLen + workstationLen).order(ByteOrder.LITTLE_ENDIAN);
/*     */ 
/*     */       
/* 756 */       token.put(NTLM_HEADER_SIGNATURE, 0, NTLM_HEADER_SIGNATURE.length);
/* 757 */       token.putInt(3);
/*     */ 
/*     */       
/* 760 */       int offset = 88;
/*     */ 
/*     */       
/* 763 */       token.putShort((short)0);
/* 764 */       token.putShort((short)0);
/* 765 */       token.putInt(offset);
/* 766 */       offset += NTLM_LMCHALLENAGERESPONSE.length;
/*     */ 
/*     */       
/* 769 */       token.putShort((short)ntChallengeLen);
/* 770 */       token.putShort((short)ntChallengeLen);
/* 771 */       token.putInt(offset);
/* 772 */       offset += ntChallengeLen;
/*     */ 
/*     */       
/* 775 */       token.putShort((short)domainNameLen);
/* 776 */       token.putShort((short)domainNameLen);
/* 777 */       token.putInt(offset);
/* 778 */       offset += domainNameLen;
/*     */ 
/*     */       
/* 781 */       token.putShort((short)userNameLen);
/* 782 */       token.putShort((short)userNameLen);
/* 783 */       token.putInt(offset);
/* 784 */       offset += userNameLen;
/*     */ 
/*     */       
/* 787 */       token.putShort((short)workstationLen);
/* 788 */       token.putShort((short)workstationLen);
/* 789 */       token.putInt(offset);
/* 790 */       offset += workstationLen;
/*     */ 
/*     */       
/* 793 */       token.putShort((short)0);
/* 794 */       token.putShort((short)0);
/* 795 */       token.putInt(offset);
/*     */ 
/*     */       
/* 798 */       token.putInt((int)this.context.negotiateFlags);
/*     */ 
/*     */       
/* 801 */       token.put(NTLMSSP_VERSION, 0, NTLMSSP_VERSION.length);
/*     */ 
/*     */       
/* 804 */       byte[] mic = new byte[16];
/* 805 */       int micPosition = token.position();
/* 806 */       token.put(mic, 0, 16);
/*     */ 
/*     */       
/* 809 */       token.put(NTLM_LMCHALLENAGERESPONSE, 0, NTLM_LMCHALLENAGERESPONSE.length);
/* 810 */       token.put(ntChallengeResp, 0, ntChallengeLen);
/* 811 */       token.put(this.context.domainUbytes, 0, domainNameLen);
/* 812 */       token.put(this.context.userNameUbytes, 0, userNameLen);
/* 813 */       token.put(workstationBytes, 0, workstationLen);
/*     */       
/* 815 */       msg = token.array();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 822 */       if (null != this.context.timestamp && 0 < this.context.timestamp.length) {
/* 823 */         SecretKeySpec keySpec = new SecretKeySpec(this.context.sessionBaseKey, "HmacMD5");
/* 824 */         this.context.mac.init(keySpec);
/* 825 */         this.context.mac.update(this.context.negotiateMsg);
/* 826 */         this.context.mac.update(this.context.challengeMsg);
/* 827 */         mic = this.context.mac.doFinal(msg);
/*     */ 
/*     */         
/* 830 */         System.arraycopy(mic, 0, msg, micPosition, 16);
/*     */       } 
/* 832 */     } catch (InvalidKeyException e) {
/* 833 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_ntlmAuthenticateError"));
/* 834 */       Object[] msgArgs = { e.getMessage() };
/* 835 */       throw new SQLServerException(form.format(msgArgs), e);
/*     */     } 
/*     */     
/* 838 */     return msg;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] generateNtlmNegotiate() {
/* 849 */     int domainNameLen = getByteArrayLength(this.context.domainUbytes);
/* 850 */     int workstationLen = getByteArrayLength(this.context.workstation.getBytes());
/*     */     
/* 852 */     ByteBuffer token = null;
/*     */     
/* 854 */     token = ByteBuffer.allocate(32 + domainNameLen + workstationLen).order(ByteOrder.LITTLE_ENDIAN);
/*     */ 
/*     */     
/* 857 */     token.put(NTLM_HEADER_SIGNATURE, 0, NTLM_HEADER_SIGNATURE.length);
/* 858 */     token.putInt(1);
/*     */ 
/*     */     
/* 861 */     this.context.negotiateFlags = 8957957L;
/*     */ 
/*     */     
/* 864 */     token.putInt((int)this.context.negotiateFlags);
/*     */     
/* 866 */     int offset = 32;
/*     */ 
/*     */     
/* 869 */     token.putShort((short)domainNameLen);
/* 870 */     token.putShort((short)domainNameLen);
/* 871 */     token.putInt(offset);
/* 872 */     offset += domainNameLen;
/*     */ 
/*     */     
/* 875 */     token.putShort((short)workstationLen);
/* 876 */     token.putShort((short)workstationLen);
/* 877 */     token.putInt(offset);
/* 878 */     offset += workstationLen;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 883 */     token.put(this.context.domainUbytes, 0, domainNameLen);
/* 884 */     token.put(this.context.workstation.getBytes(), 0, workstationLen);
/*     */ 
/*     */     
/* 887 */     byte[] msg = token.array();
/* 888 */     this.context.negotiateMsg = new byte[msg.length];
/* 889 */     System.arraycopy(msg, 0, this.context.negotiateMsg, 0, msg.length);
/*     */     
/* 891 */     return msg;
/*     */   }
/*     */   
/*     */   public static byte[] getNtlmPasswordHash(String password) throws SQLServerException {
/* 895 */     if (null == password) {
/* 896 */       throw new SQLServerException(SQLServerException.getErrString("R_NtlmNoUserPasswordDomain"), null);
/*     */     }
/*     */     
/* 899 */     return md4(unicode(password));
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\NTLMAuthentication.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */