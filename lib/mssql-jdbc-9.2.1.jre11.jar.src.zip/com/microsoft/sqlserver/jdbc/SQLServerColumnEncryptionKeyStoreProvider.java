package com.microsoft.sqlserver.jdbc;

public abstract class SQLServerColumnEncryptionKeyStoreProvider {
  public abstract void setName(String paramString);
  
  public abstract String getName();
  
  public abstract byte[] decryptColumnEncryptionKey(String paramString1, String paramString2, byte[] paramArrayOfbyte) throws SQLServerException;
  
  public abstract byte[] encryptColumnEncryptionKey(String paramString1, String paramString2, byte[] paramArrayOfbyte) throws SQLServerException;
  
  public abstract boolean verifyColumnMasterKeyMetadata(String paramString, boolean paramBoolean, byte[] paramArrayOfbyte) throws SQLServerException;
}


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerColumnEncryptionKeyStoreProvider.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */