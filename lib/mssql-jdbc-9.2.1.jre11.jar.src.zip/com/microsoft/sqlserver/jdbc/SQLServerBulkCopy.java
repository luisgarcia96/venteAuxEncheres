/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.Serializable;
/*      */ import java.io.StringReader;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.MathContext;
/*      */ import java.math.RoundingMode;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.ByteOrder;
/*      */ import java.nio.charset.StandardCharsets;
/*      */ import java.sql.Connection;
/*      */ import java.sql.Date;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.text.MessageFormat;
/*      */ import java.time.DateTimeException;
/*      */ import java.time.OffsetDateTime;
/*      */ import java.time.OffsetTime;
/*      */ import java.time.format.DateTimeFormatter;
/*      */ import java.time.temporal.ChronoField;
/*      */ import java.time.temporal.TemporalAccessor;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.Collections;
/*      */ import java.util.GregorianCalendar;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.SimpleTimeZone;
/*      */ import java.util.TimeZone;
/*      */ import java.util.UUID;
/*      */ import java.util.concurrent.ScheduledFuture;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ import javax.sql.RowSet;
/*      */ import microsoft.sql.DateTimeOffset;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class SQLServerBulkCopy
/*      */   implements AutoCloseable, Serializable
/*      */ {
/*      */   private static final long serialVersionUID = 1989903904654306244L;
/*      */   private static final String loggerClassName = "com.microsoft.sqlserver.jdbc.SQLServerBulkCopy";
/*      */   
/*      */   private class ColumnMapping
/*      */     implements Serializable
/*      */   {
/*      */     private static final long serialVersionUID = 6428337550654423919L;
/*   80 */     String sourceColumnName = null;
/*   81 */     int sourceColumnOrdinal = -1;
/*   82 */     String destinationColumnName = null;
/*   83 */     int destinationColumnOrdinal = -1;
/*      */     
/*      */     ColumnMapping(String source, String dest) {
/*   86 */       this.sourceColumnName = source;
/*   87 */       this.destinationColumnName = dest;
/*      */     }
/*      */     
/*      */     ColumnMapping(String source, int dest) {
/*   91 */       this.sourceColumnName = source;
/*   92 */       this.destinationColumnOrdinal = dest;
/*      */     }
/*      */     
/*      */     ColumnMapping(int source, String dest) {
/*   96 */       this.sourceColumnOrdinal = source;
/*   97 */       this.destinationColumnName = dest;
/*      */     }
/*      */     
/*      */     ColumnMapping(int source, int dest) {
/*  101 */       this.sourceColumnOrdinal = source;
/*  102 */       this.destinationColumnOrdinal = dest;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  114 */   private static final Logger loggerExternal = Logger.getLogger("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private SQLServerConnection connection;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private SQLServerBulkCopyOptions copyOptions;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private List<ColumnMapping> columnMappings;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean ownsConnection;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String destinationTableName;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ISQLServerBulkData serverBulkData;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ResultSet sourceResultSet;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ResultSetMetaData sourceResultSetMetaData;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  164 */   private CekTable destCekTable = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  169 */   private SQLServerStatementColumnEncryptionSetting stmtColumnEncriptionSetting = SQLServerStatementColumnEncryptionSetting.UseConnectionSetting; private ResultSet destinationTableMetadata;
/*      */   private Map<Integer, BulkColumnMetaData> destColumnMetadata;
/*      */   private Map<Integer, BulkColumnMetaData> srcColumnMetadata;
/*      */   private int destColumnCount;
/*      */   private int srcColumnCount;
/*      */   private ScheduledFuture<?> timeout;
/*      */   private static final int sourceBulkRecordTemporalMaxPrecision = 50;
/*      */   
/*      */   class BulkColumnMetaData { String columnName;
/*  178 */     SSType ssType = null; int jdbcType;
/*      */     int precision;
/*      */     int scale;
/*      */     SQLCollation collation;
/*  182 */     byte[] flags = new byte[2];
/*      */     boolean isIdentity = false;
/*      */     boolean isNullable;
/*      */     String collationName;
/*  186 */     CryptoMetadata cryptoMeta = null;
/*  187 */     DateTimeFormatter dateTimeFormatter = null;
/*      */ 
/*      */     
/*  190 */     String encryptionType = null;
/*      */     
/*      */     BulkColumnMetaData(Column column) throws SQLServerException {
/*  193 */       this.cryptoMeta = column.getCryptoMetadata();
/*  194 */       TypeInfo typeInfo = column.getTypeInfo();
/*  195 */       this.columnName = column.getColumnName();
/*  196 */       this.ssType = typeInfo.getSSType();
/*  197 */       this.flags = typeInfo.getFlags();
/*  198 */       this.isIdentity = typeInfo.isIdentity();
/*  199 */       this.isNullable = typeInfo.isNullable();
/*  200 */       this.precision = typeInfo.getPrecision();
/*  201 */       this.scale = typeInfo.getScale();
/*  202 */       this.collation = typeInfo.getSQLCollation();
/*  203 */       this.jdbcType = this.ssType.getJDBCType().getIntValue();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     BulkColumnMetaData(String colName, boolean isNullable, int precision, int scale, int jdbcType, DateTimeFormatter dateTimeFormatter) throws SQLServerException {
/*  209 */       this.columnName = colName;
/*  210 */       this.isNullable = isNullable;
/*  211 */       this.precision = precision;
/*  212 */       this.scale = scale;
/*  213 */       this.jdbcType = jdbcType;
/*  214 */       this.dateTimeFormatter = dateTimeFormatter;
/*      */     }
/*      */     
/*      */     BulkColumnMetaData(Column column, String collationName, String encryptionType) throws SQLServerException {
/*  218 */       this(column);
/*  219 */       this.collationName = collationName;
/*  220 */       this.encryptionType = encryptionType;
/*      */     }
/*      */ 
/*      */     
/*      */     BulkColumnMetaData(BulkColumnMetaData bulkColumnMetaData, CryptoMetadata cryptoMeta) {
/*  225 */       this.columnName = bulkColumnMetaData.columnName;
/*  226 */       this.isNullable = bulkColumnMetaData.isNullable;
/*  227 */       this.precision = bulkColumnMetaData.precision;
/*  228 */       this.scale = bulkColumnMetaData.scale;
/*  229 */       this.jdbcType = bulkColumnMetaData.jdbcType;
/*  230 */       this.cryptoMeta = cryptoMeta;
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SQLServerBulkCopy(Connection connection) throws SQLServerException {
/*  271 */     loggerExternal.entering("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "SQLServerBulkCopy", connection);
/*      */     
/*  273 */     if (null == connection || !(connection instanceof ISQLServerConnection)) {
/*  274 */       SQLServerException.makeFromDriverError(null, null, 
/*  275 */           SQLServerException.getErrString("R_invalidDestConnection"), null, false);
/*      */     }
/*      */     
/*  278 */     if (connection instanceof SQLServerConnection) {
/*  279 */       this.connection = (SQLServerConnection)connection;
/*  280 */     } else if (connection instanceof SQLServerConnectionPoolProxy) {
/*  281 */       this.connection = ((SQLServerConnectionPoolProxy)connection).getWrappedConnection();
/*      */     } else {
/*  283 */       SQLServerException.makeFromDriverError(null, null, 
/*  284 */           SQLServerException.getErrString("R_invalidDestConnection"), null, false);
/*      */     } 
/*  286 */     this.ownsConnection = false;
/*      */ 
/*      */ 
/*      */     
/*  290 */     this.copyOptions = new SQLServerBulkCopyOptions();
/*      */     
/*  292 */     initializeDefaults();
/*      */     
/*  294 */     loggerExternal.exiting("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "SQLServerBulkCopy");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SQLServerBulkCopy(String connectionUrl) throws SQLServerException {
/*  306 */     loggerExternal.entering("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "SQLServerBulkCopy", "connectionUrl not traced.");
/*  307 */     if (connectionUrl == null || "".equals(connectionUrl.trim())) {
/*  308 */       throw new SQLServerException(null, SQLServerException.getErrString("R_nullConnection"), null, 0, false);
/*      */     }
/*      */     
/*  311 */     this.ownsConnection = true;
/*  312 */     SQLServerDriver driver = new SQLServerDriver();
/*  313 */     this.connection = (SQLServerConnection)driver.connect(connectionUrl, null);
/*  314 */     if (null == this.connection) {
/*  315 */       throw new SQLServerException(null, SQLServerException.getErrString("R_invalidConnection"), null, 0, false);
/*      */     }
/*      */     
/*  318 */     this.copyOptions = new SQLServerBulkCopyOptions();
/*      */     
/*  320 */     initializeDefaults();
/*      */     
/*  322 */     loggerExternal.exiting("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "SQLServerBulkCopy");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addColumnMapping(int sourceColumn, int destinationColumn) throws SQLServerException {
/*  336 */     if (loggerExternal.isLoggable(Level.FINER)) {
/*  337 */       loggerExternal.entering("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "addColumnMapping", new Object[] {
/*  338 */             Integer.valueOf(sourceColumn), Integer.valueOf(destinationColumn)
/*      */           });
/*      */     }
/*  341 */     if (0 >= sourceColumn) {
/*  342 */       throwInvalidArgument("sourceColumn");
/*  343 */     } else if (0 >= destinationColumn) {
/*  344 */       throwInvalidArgument("destinationColumn");
/*      */     } 
/*  346 */     this.columnMappings.add(new ColumnMapping(sourceColumn, destinationColumn));
/*      */     
/*  348 */     loggerExternal.exiting("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "addColumnMapping");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addColumnMapping(int sourceColumn, String destinationColumn) throws SQLServerException {
/*  362 */     if (loggerExternal.isLoggable(Level.FINER)) {
/*  363 */       loggerExternal.entering("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "addColumnMapping", new Object[] {
/*  364 */             Integer.valueOf(sourceColumn), destinationColumn
/*      */           });
/*      */     }
/*  367 */     if (0 >= sourceColumn) {
/*  368 */       throwInvalidArgument("sourceColumn");
/*  369 */     } else if (null == destinationColumn || destinationColumn.isEmpty()) {
/*  370 */       throwInvalidArgument("destinationColumn");
/*      */     } 
/*  372 */     this.columnMappings.add(new ColumnMapping(sourceColumn, destinationColumn));
/*      */     
/*  374 */     loggerExternal.exiting("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "addColumnMapping");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addColumnMapping(String sourceColumn, int destinationColumn) throws SQLServerException {
/*  389 */     if (loggerExternal.isLoggable(Level.FINER)) {
/*  390 */       loggerExternal.entering("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "addColumnMapping", new Object[] { sourceColumn, 
/*  391 */             Integer.valueOf(destinationColumn) });
/*      */     }
/*      */     
/*  394 */     if (0 >= destinationColumn) {
/*  395 */       throwInvalidArgument("destinationColumn");
/*  396 */     } else if (null == sourceColumn || sourceColumn.isEmpty()) {
/*  397 */       throwInvalidArgument("sourceColumn");
/*      */     } 
/*  399 */     this.columnMappings.add(new ColumnMapping(sourceColumn, destinationColumn));
/*      */     
/*  401 */     loggerExternal.exiting("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "addColumnMapping");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addColumnMapping(String sourceColumn, String destinationColumn) throws SQLServerException {
/*  415 */     if (loggerExternal.isLoggable(Level.FINER)) {
/*  416 */       loggerExternal.entering("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "addColumnMapping", new Object[] { sourceColumn, destinationColumn });
/*      */     }
/*      */ 
/*      */     
/*  420 */     if (null == sourceColumn || sourceColumn.isEmpty()) {
/*  421 */       throwInvalidArgument("sourceColumn");
/*  422 */     } else if (null == destinationColumn || destinationColumn.isEmpty()) {
/*  423 */       throwInvalidArgument("destinationColumn");
/*      */     } 
/*  425 */     this.columnMappings.add(new ColumnMapping(sourceColumn, destinationColumn));
/*      */     
/*  427 */     loggerExternal.exiting("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "addColumnMapping");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearColumnMappings() {
/*  434 */     loggerExternal.entering("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "clearColumnMappings");
/*      */     
/*  436 */     this.columnMappings.clear();
/*      */     
/*  438 */     loggerExternal.exiting("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "clearColumnMappings");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void close() {
/*  445 */     loggerExternal.entering("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "close");
/*      */     
/*  447 */     if (this.ownsConnection) {
/*      */       try {
/*  449 */         this.connection.close();
/*  450 */       } catch (SQLException sQLException) {}
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  455 */     loggerExternal.exiting("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "close");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getDestinationTableName() {
/*  464 */     return this.destinationTableName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDestinationTableName(String tableName) throws SQLServerException {
/*  476 */     loggerExternal.entering("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "setDestinationTableName", tableName);
/*      */     
/*  478 */     if (null == tableName || 0 == tableName.trim().length()) {
/*  479 */       throwInvalidArgument("tableName");
/*      */     }
/*      */     
/*  482 */     this.destinationTableName = tableName.trim();
/*      */     
/*  484 */     loggerExternal.exiting("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "setDestinationTableName");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SQLServerBulkCopyOptions getBulkCopyOptions() {
/*  493 */     return this.copyOptions;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBulkCopyOptions(SQLServerBulkCopyOptions copyOptions) throws SQLServerException {
/*  507 */     loggerExternal.entering("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "updateBulkCopyOptions", copyOptions);
/*      */     
/*  509 */     if (null != copyOptions) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  514 */       if (!this.ownsConnection && copyOptions.isUseInternalTransaction()) {
/*  515 */         SQLServerException.makeFromDriverError(null, null, 
/*  516 */             SQLServerException.getErrString("R_invalidTransactionOption"), null, false);
/*      */       }
/*      */       
/*  519 */       this.copyOptions = copyOptions;
/*      */     } 
/*  521 */     loggerExternal.exiting("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "updateBulkCopyOptions");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeToServer(ResultSet sourceData) throws SQLServerException {
/*  534 */     writeResultSet(sourceData, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeToServer(RowSet sourceData) throws SQLServerException {
/*  547 */     writeResultSet(sourceData, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeResultSet(ResultSet sourceData, boolean isRowSet) throws SQLServerException {
/*  561 */     loggerExternal.entering("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "writeToServer");
/*      */     
/*  563 */     if (null == sourceData) {
/*  564 */       throwInvalidArgument("sourceData");
/*      */     }
/*      */     
/*      */     try {
/*  568 */       if (isRowSet) {
/*      */ 
/*      */         
/*  571 */         if (!sourceData.isBeforeFirst()) {
/*  572 */           sourceData.beforeFirst();
/*      */         }
/*      */       }
/*  575 */       else if (sourceData.isClosed()) {
/*  576 */         SQLServerException.makeFromDriverError(null, null, 
/*  577 */             SQLServerException.getErrString("R_resultsetClosed"), null, false);
/*      */       }
/*      */     
/*  580 */     } catch (SQLException e) {
/*      */       
/*  582 */       throw new SQLServerException(null, e.getMessage(), null, 0, false);
/*      */     } 
/*      */     
/*  585 */     this.sourceResultSet = sourceData;
/*      */     
/*  587 */     this.serverBulkData = null;
/*      */ 
/*      */     
/*      */     try {
/*  591 */       this.sourceResultSetMetaData = this.sourceResultSet.getMetaData();
/*  592 */     } catch (SQLException e) {
/*  593 */       throw new SQLServerException(SQLServerException.getErrString("R_unableRetrieveColMeta"), e);
/*      */     } 
/*      */     
/*  596 */     writeToServer();
/*      */     
/*  598 */     loggerExternal.exiting("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "writeToServer");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeToServer(ISQLServerBulkData sourceData) throws SQLServerException {
/*  611 */     loggerExternal.entering("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "writeToServer");
/*      */     
/*  613 */     if (null == sourceData) {
/*  614 */       throwInvalidArgument("sourceData");
/*      */     }
/*      */     
/*  617 */     this.serverBulkData = sourceData;
/*  618 */     this.sourceResultSet = null;
/*      */     
/*  620 */     writeToServer();
/*      */     
/*  622 */     loggerExternal.exiting("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "writeToServer");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void initializeDefaults() {
/*  629 */     this.columnMappings = new ArrayList<>();
/*  630 */     this.destinationTableName = null;
/*  631 */     this.serverBulkData = null;
/*  632 */     this.sourceResultSet = null;
/*  633 */     this.sourceResultSetMetaData = null;
/*  634 */     this.srcColumnCount = 0;
/*  635 */     this.srcColumnMetadata = null;
/*  636 */     this.destColumnMetadata = null;
/*  637 */     this.destColumnCount = 0;
/*      */   }
/*      */ 
/*      */   
/*      */   private void sendBulkLoadBCP() throws SQLServerException {
/*      */     final class InsertBulk
/*      */       extends TDSCommand
/*      */     {
/*      */       private static final long serialVersionUID = 6714118105257791547L;
/*      */       
/*      */       InsertBulk() {
/*  648 */         super("InsertBulk", 0, 0);
/*      */       }
/*      */       
/*      */       final boolean doExecute() throws SQLServerException {
/*  652 */         int timeoutSeconds = SQLServerBulkCopy.this.copyOptions.getBulkCopyTimeout();
/*  653 */         if (timeoutSeconds > 0) {
/*  654 */           SQLServerBulkCopy.this.connection.checkClosed();
/*  655 */           SQLServerBulkCopy.this.timeout = SQLServerBulkCopy.this.connection.getSharedTimer().schedule(new TDSTimeoutTask(this, SQLServerBulkCopy.this.connection), timeoutSeconds);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         try {
/*  663 */           while (SQLServerBulkCopy.this.doInsertBulk(this));
/*  664 */         } catch (SQLServerException topLevelException) {
/*      */           
/*  666 */           Throwable rootCause = topLevelException;
/*  667 */           while (null != rootCause.getCause()) {
/*  668 */             rootCause = rootCause.getCause();
/*      */           }
/*      */ 
/*      */           
/*  672 */           if (rootCause instanceof SQLException && SQLServerBulkCopy.this.timeout != null && SQLServerBulkCopy.this.timeout.isDone()) {
/*  673 */             SQLException sqlEx = (SQLException)rootCause;
/*  674 */             if (sqlEx.getSQLState() != null && sqlEx
/*  675 */               .getSQLState().equals(SQLState.STATEMENT_CANCELED.getSQLStateCode())) {
/*      */               
/*  677 */               if (SQLServerBulkCopy.this.copyOptions.isUseInternalTransaction()) {
/*  678 */                 SQLServerBulkCopy.this.connection.rollback();
/*      */               }
/*  680 */               throw new SQLServerException(SQLServerException.getErrString("R_queryTimedOut"), SQLState.STATEMENT_CANCELED, DriverError.NOT_SET, sqlEx);
/*      */             } 
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/*  686 */           throw topLevelException;
/*      */         } 
/*      */         
/*  689 */         if (SQLServerBulkCopy.this.timeout != null) {
/*  690 */           SQLServerBulkCopy.this.timeout.cancel(true);
/*  691 */           SQLServerBulkCopy.this.timeout = null;
/*      */         } 
/*  693 */         return true;
/*      */       }
/*      */     };
/*      */     
/*  697 */     this.connection.executeCommand(new InsertBulk());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeColumnMetaDataColumnData(TDSWriter tdsWriter, int idx) throws SQLServerException {
/*      */     boolean isStreaming;
/*  714 */     byte[] userType = new byte[4];
/*  715 */     userType[0] = 0;
/*  716 */     userType[1] = 0;
/*  717 */     userType[2] = 0;
/*  718 */     userType[3] = 0;
/*  719 */     tdsWriter.writeBytes(userType);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  725 */     int destColumnIndex = ((ColumnMapping)this.columnMappings.get(idx)).destinationColumnOrdinal;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  730 */     int srcColumnIndex = ((ColumnMapping)this.columnMappings.get(idx)).sourceColumnOrdinal;
/*      */     
/*  732 */     byte[] flags = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(destColumnIndex))).flags;
/*      */ 
/*      */     
/*  735 */     if (null == ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(srcColumnIndex))).cryptoMeta && null == ((BulkColumnMetaData)this.destColumnMetadata
/*  736 */       .get(Integer.valueOf(destColumnIndex))).cryptoMeta && this.copyOptions
/*  737 */       .isAllowEncryptedValueModifications())
/*      */     {
/*      */ 
/*      */       
/*  741 */       if (1 == (flags[1] >> 3 & 0x1)) {
/*  742 */         flags[1] = (byte)(flags[1] - 8);
/*      */       }
/*      */     }
/*  745 */     tdsWriter.writeBytes(flags);
/*      */     
/*  747 */     int bulkJdbcType = ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(srcColumnIndex))).jdbcType;
/*  748 */     int bulkPrecision = ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(srcColumnIndex))).precision;
/*  749 */     int bulkScale = ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(srcColumnIndex))).scale;
/*  750 */     boolean srcNullable = ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(srcColumnIndex))).isNullable;
/*      */     
/*  752 */     SSType destSSType = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(destColumnIndex))).ssType;
/*  753 */     int destPrecision = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(destColumnIndex))).precision;
/*      */     
/*  755 */     bulkPrecision = validateSourcePrecision(bulkPrecision, bulkJdbcType, destPrecision);
/*      */     
/*  757 */     SQLCollation collation = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(destColumnIndex))).collation;
/*  758 */     if (null == collation) {
/*  759 */       collation = this.connection.getDatabaseCollation();
/*      */     }
/*  761 */     if (-15 == bulkJdbcType || -9 == bulkJdbcType || -16 == bulkJdbcType) {
/*      */       
/*  763 */       isStreaming = (4000 < bulkPrecision || 4000 < destPrecision);
/*      */     } else {
/*      */       
/*  766 */       isStreaming = (8000 < bulkPrecision || 8000 < destPrecision);
/*      */     } 
/*      */ 
/*      */     
/*  770 */     CryptoMetadata destCryptoMeta = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(destColumnIndex))).cryptoMeta;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  777 */     if (this.sourceResultSet instanceof SQLServerResultSet && this.connection.isColumnEncryptionSettingEnabled() && null != destCryptoMeta) {
/*      */       
/*  779 */       bulkJdbcType = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(destColumnIndex))).jdbcType;
/*  780 */       bulkPrecision = destPrecision;
/*  781 */       bulkScale = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(destColumnIndex))).scale;
/*      */     } 
/*      */ 
/*      */     
/*  785 */     if ((null != ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(destColumnIndex))).encryptionType && this.copyOptions
/*  786 */       .isAllowEncryptedValueModifications()) || null != ((BulkColumnMetaData)this.destColumnMetadata
/*  787 */       .get(Integer.valueOf(destColumnIndex))).cryptoMeta) {
/*  788 */       tdsWriter.writeByte((byte)-91);
/*      */       
/*  790 */       if (isStreaming) {
/*  791 */         tdsWriter.writeShort((short)-1);
/*      */       } else {
/*  793 */         tdsWriter.writeShort((short)bulkPrecision);
/*      */       
/*      */       }
/*      */     
/*      */     }
/*  798 */     else if ((1 == bulkJdbcType || 12 == bulkJdbcType || -1 == bulkJdbcType) && (SSType.BINARY == destSSType || SSType.VARBINARY == destSSType || SSType.VARBINARYMAX == destSSType || SSType.IMAGE == destSSType)) {
/*      */ 
/*      */ 
/*      */       
/*  802 */       if (isStreaming) {
/*      */         
/*  804 */         tdsWriter.writeByte((byte)-91);
/*      */       } else {
/*  806 */         tdsWriter.writeByte((byte)((SSType.BINARY == destSSType) ? 173 : 165));
/*      */       } 
/*  808 */       tdsWriter.writeShort((short)bulkPrecision);
/*      */     } else {
/*  810 */       writeTypeInfo(tdsWriter, bulkJdbcType, bulkScale, bulkPrecision, destSSType, collation, isStreaming, srcNullable, false);
/*      */     } 
/*      */ 
/*      */     
/*  814 */     if (null != destCryptoMeta) {
/*  815 */       int baseDestJDBCType = destCryptoMeta.baseTypeInfo.getSSType().getJDBCType().asJavaSqlType();
/*  816 */       int baseDestPrecision = destCryptoMeta.baseTypeInfo.getPrecision();
/*      */       
/*  818 */       if (-15 == baseDestJDBCType || -9 == baseDestJDBCType || -16 == baseDestJDBCType) {
/*      */         
/*  820 */         isStreaming = (4000 < baseDestPrecision);
/*      */       } else {
/*  822 */         isStreaming = (8000 < baseDestPrecision);
/*      */       } 
/*      */       
/*  825 */       tdsWriter.writeShort(destCryptoMeta.getOrdinal());
/*  826 */       tdsWriter.writeBytes(userType);
/*      */       
/*  828 */       writeTypeInfo(tdsWriter, baseDestJDBCType, destCryptoMeta.baseTypeInfo.getScale(), baseDestPrecision, destCryptoMeta.baseTypeInfo
/*  829 */           .getSSType(), collation, isStreaming, srcNullable, true);
/*  830 */       tdsWriter.writeByte(destCryptoMeta.cipherAlgorithmId);
/*  831 */       tdsWriter.writeByte(destCryptoMeta.encryptionType.getValue());
/*  832 */       tdsWriter.writeByte(destCryptoMeta.normalizationRuleVersion);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  839 */     int destColNameLen = ((ColumnMapping)this.columnMappings.get(idx)).destinationColumnName.length();
/*  840 */     String destColName = ((ColumnMapping)this.columnMappings.get(idx)).destinationColumnName;
/*  841 */     byte[] colName = new byte[2 * destColNameLen];
/*      */     
/*  843 */     for (int i = 0; i < destColNameLen; i++) {
/*  844 */       int c = destColName.charAt(i);
/*  845 */       colName[2 * i] = (byte)(c & 0xFF);
/*  846 */       colName[2 * i + 1] = (byte)(c >> 8 & 0xFF);
/*      */     } 
/*      */     
/*  849 */     tdsWriter.writeByte((byte)destColNameLen);
/*  850 */     tdsWriter.writeBytes(colName);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeTypeInfo(TDSWriter tdsWriter, int srcJdbcType, int srcScale, int srcPrecision, SSType destSSType, SQLCollation collation, boolean isStreaming, boolean srcNullable, boolean isBaseType) throws SQLServerException {
/*  856 */     switch (srcJdbcType) {
/*      */       case 4:
/*  858 */         if (!srcNullable) {
/*  859 */           tdsWriter.writeByte(TDSType.INT4.byteValue());
/*      */         } else {
/*  861 */           tdsWriter.writeByte(TDSType.INTN.byteValue());
/*  862 */           tdsWriter.writeByte((byte)4);
/*      */         } 
/*      */         return;
/*      */       
/*      */       case -5:
/*  867 */         if (!srcNullable) {
/*  868 */           tdsWriter.writeByte(TDSType.INT8.byteValue());
/*      */         } else {
/*  870 */           tdsWriter.writeByte(TDSType.INTN.byteValue());
/*  871 */           tdsWriter.writeByte((byte)8);
/*      */         } 
/*      */         return;
/*      */       
/*      */       case -7:
/*  876 */         if (!srcNullable) {
/*  877 */           tdsWriter.writeByte(TDSType.BIT1.byteValue());
/*      */         } else {
/*  879 */           tdsWriter.writeByte(TDSType.BITN.byteValue());
/*  880 */           tdsWriter.writeByte((byte)1);
/*      */         } 
/*      */         return;
/*      */       
/*      */       case 5:
/*  885 */         if (!srcNullable) {
/*  886 */           tdsWriter.writeByte(TDSType.INT2.byteValue());
/*      */         } else {
/*  888 */           tdsWriter.writeByte(TDSType.INTN.byteValue());
/*  889 */           tdsWriter.writeByte((byte)2);
/*      */         } 
/*      */         return;
/*      */       
/*      */       case -6:
/*  894 */         if (!srcNullable) {
/*  895 */           tdsWriter.writeByte(TDSType.INT1.byteValue());
/*      */         } else {
/*  897 */           tdsWriter.writeByte(TDSType.INTN.byteValue());
/*  898 */           tdsWriter.writeByte((byte)1);
/*      */         } 
/*      */         return;
/*      */       
/*      */       case 6:
/*      */       case 8:
/*  904 */         if (!srcNullable) {
/*  905 */           tdsWriter.writeByte(TDSType.FLOAT8.byteValue());
/*      */         } else {
/*  907 */           tdsWriter.writeByte(TDSType.FLOATN.byteValue());
/*  908 */           tdsWriter.writeByte((byte)8);
/*      */         } 
/*      */         return;
/*      */       
/*      */       case 7:
/*  913 */         if (!srcNullable) {
/*  914 */           tdsWriter.writeByte(TDSType.FLOAT4.byteValue());
/*      */         } else {
/*  916 */           tdsWriter.writeByte(TDSType.FLOATN.byteValue());
/*  917 */           tdsWriter.writeByte((byte)4);
/*      */         } 
/*      */         return;
/*      */       
/*      */       case -148:
/*      */       case -146:
/*  923 */         tdsWriter.writeByte(TDSType.MONEYN.byteValue());
/*  924 */         if (SSType.MONEY == destSSType) {
/*  925 */           tdsWriter.writeByte((byte)8);
/*      */         } else {
/*  927 */           tdsWriter.writeByte((byte)4);
/*      */         } 
/*      */         return;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 2:
/*      */       case 3:
/*  937 */         if (destSSType == SSType.MONEY) {
/*  938 */           tdsWriter.writeByte(TDSType.MONEYN.byteValue());
/*  939 */           tdsWriter.writeByte((byte)8);
/*      */         }
/*  941 */         else if (destSSType == SSType.SMALLMONEY) {
/*  942 */           tdsWriter.writeByte(TDSType.MONEYN.byteValue());
/*  943 */           tdsWriter.writeByte((byte)4);
/*      */         }
/*      */         else {
/*      */           
/*  947 */           byte byteType = (3 == srcJdbcType) ? TDSType.DECIMALN.byteValue() : TDSType.NUMERICN.byteValue();
/*  948 */           tdsWriter.writeByte(byteType);
/*  949 */           tdsWriter.writeByte((byte)17);
/*  950 */           tdsWriter.writeByte((byte)srcPrecision);
/*  951 */           tdsWriter.writeByte((byte)srcScale);
/*      */         } 
/*      */         return;
/*      */       case -145:
/*      */       case 1:
/*  956 */         if (isBaseType && SSType.GUID == destSSType) {
/*  957 */           tdsWriter.writeByte(TDSType.GUID.byteValue());
/*  958 */           tdsWriter.writeByte((byte)16);
/*      */         } else {
/*  960 */           if (unicodeConversionRequired(srcJdbcType, destSSType)) {
/*  961 */             tdsWriter.writeByte(TDSType.NCHAR.byteValue());
/*  962 */             tdsWriter.writeShort(isBaseType ? (short)srcPrecision : (short)(2 * srcPrecision));
/*      */           } else {
/*  964 */             tdsWriter.writeByte(TDSType.BIGCHAR.byteValue());
/*  965 */             tdsWriter.writeShort((short)srcPrecision);
/*      */           } 
/*  967 */           collation.writeCollation(tdsWriter);
/*      */         } 
/*      */         return;
/*      */       
/*      */       case -15:
/*  972 */         tdsWriter.writeByte(TDSType.NCHAR.byteValue());
/*  973 */         tdsWriter.writeShort(isBaseType ? (short)srcPrecision : (short)(2 * srcPrecision));
/*  974 */         collation.writeCollation(tdsWriter);
/*      */         return;
/*      */       
/*      */       case -1:
/*      */       case 12:
/*  979 */         if (unicodeConversionRequired(srcJdbcType, destSSType)) {
/*  980 */           tdsWriter.writeByte(TDSType.NVARCHAR.byteValue());
/*  981 */           if (isStreaming) {
/*  982 */             tdsWriter.writeShort((short)-1);
/*      */           } else {
/*  984 */             tdsWriter.writeShort(isBaseType ? (short)srcPrecision : (short)(2 * srcPrecision));
/*      */           } 
/*      */         } else {
/*  987 */           tdsWriter.writeByte(TDSType.BIGVARCHAR.byteValue());
/*  988 */           if (isStreaming) {
/*  989 */             tdsWriter.writeShort((short)-1);
/*      */           } else {
/*  991 */             tdsWriter.writeShort((short)srcPrecision);
/*      */           } 
/*      */         } 
/*  994 */         collation.writeCollation(tdsWriter);
/*      */         return;
/*      */       
/*      */       case -16:
/*      */       case -9:
/*  999 */         tdsWriter.writeByte(TDSType.NVARCHAR.byteValue());
/* 1000 */         if (isStreaming) {
/* 1001 */           tdsWriter.writeShort((short)-1);
/*      */         } else {
/* 1003 */           tdsWriter.writeShort(isBaseType ? (short)srcPrecision : (short)(2 * srcPrecision));
/*      */         } 
/* 1005 */         collation.writeCollation(tdsWriter);
/*      */         return;
/*      */       
/*      */       case -2:
/* 1009 */         tdsWriter.writeByte(TDSType.BIGBINARY.byteValue());
/* 1010 */         tdsWriter.writeShort((short)srcPrecision);
/*      */         return;
/*      */ 
/*      */       
/*      */       case -4:
/*      */       case -3:
/* 1016 */         tdsWriter.writeByte(TDSType.BIGVARBINARY.byteValue());
/* 1017 */         if (isStreaming) {
/* 1018 */           tdsWriter.writeShort((short)-1);
/*      */         } else {
/* 1020 */           tdsWriter.writeShort((short)srcPrecision);
/*      */         } 
/*      */         return;
/*      */       
/*      */       case -151:
/*      */       case -150:
/*      */       case 93:
/* 1027 */         if (!isBaseType && null != this.serverBulkData && this.connection
/* 1028 */           .getSendTemporalDataTypesAsStringForBulkCopy()) {
/* 1029 */           tdsWriter.writeByte(TDSType.BIGVARCHAR.byteValue());
/* 1030 */           tdsWriter.writeShort((short)srcPrecision);
/* 1031 */           collation.writeCollation(tdsWriter);
/*      */         } else {
/* 1033 */           switch (destSSType) {
/*      */             case DATE:
/* 1035 */               if (!srcNullable) {
/* 1036 */                 tdsWriter.writeByte(TDSType.DATETIME4.byteValue());
/*      */               } else {
/* 1038 */                 tdsWriter.writeByte(TDSType.DATETIMEN.byteValue());
/* 1039 */                 tdsWriter.writeByte((byte)4);
/*      */               } 
/*      */               return;
/*      */             case TIME:
/* 1043 */               if (!srcNullable) {
/* 1044 */                 tdsWriter.writeByte(TDSType.DATETIME8.byteValue());
/*      */               } else {
/* 1046 */                 tdsWriter.writeByte(TDSType.DATETIMEN.byteValue());
/* 1047 */                 tdsWriter.writeByte((byte)8);
/*      */               } 
/*      */               return;
/*      */           } 
/*      */           
/* 1052 */           tdsWriter.writeByte(TDSType.DATETIME2N.byteValue());
/* 1053 */           tdsWriter.writeByte((byte)srcScale);
/*      */         } 
/*      */         return;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 91:
/* 1066 */         if (!isBaseType && null != this.serverBulkData && this.connection
/* 1067 */           .getSendTemporalDataTypesAsStringForBulkCopy()) {
/* 1068 */           tdsWriter.writeByte(TDSType.BIGVARCHAR.byteValue());
/* 1069 */           tdsWriter.writeShort((short)srcPrecision);
/* 1070 */           collation.writeCollation(tdsWriter);
/*      */         } else {
/* 1072 */           tdsWriter.writeByte(TDSType.DATEN.byteValue());
/*      */         } 
/*      */         return;
/*      */       
/*      */       case 92:
/* 1077 */         if (!isBaseType && null != this.serverBulkData && this.connection
/* 1078 */           .getSendTemporalDataTypesAsStringForBulkCopy()) {
/* 1079 */           tdsWriter.writeByte(TDSType.BIGVARCHAR.byteValue());
/* 1080 */           tdsWriter.writeShort((short)srcPrecision);
/* 1081 */           collation.writeCollation(tdsWriter);
/*      */         } else {
/* 1083 */           tdsWriter.writeByte(TDSType.TIMEN.byteValue());
/* 1084 */           tdsWriter.writeByte((byte)srcScale);
/*      */         } 
/*      */         return;
/*      */ 
/*      */       
/*      */       case 2013:
/*      */       case 2014:
/* 1091 */         tdsWriter.writeByte(TDSType.DATETIMEOFFSETN.byteValue());
/* 1092 */         tdsWriter.writeByte((byte)srcScale);
/*      */         return;
/*      */       
/*      */       case -155:
/* 1096 */         if (!isBaseType && null != this.serverBulkData && this.connection
/* 1097 */           .getSendTemporalDataTypesAsStringForBulkCopy()) {
/* 1098 */           tdsWriter.writeByte(TDSType.BIGVARCHAR.byteValue());
/* 1099 */           tdsWriter.writeShort((short)srcPrecision);
/* 1100 */           collation.writeCollation(tdsWriter);
/*      */         } else {
/* 1102 */           tdsWriter.writeByte(TDSType.DATETIMEOFFSETN.byteValue());
/* 1103 */           tdsWriter.writeByte((byte)srcScale);
/*      */         } 
/*      */         return;
/*      */       case -156:
/* 1107 */         tdsWriter.writeByte(TDSType.SQL_VARIANT.byteValue());
/* 1108 */         tdsWriter.writeInt(8009);
/*      */         return;
/*      */     } 
/* 1111 */     MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_BulkTypeNotSupported"));
/* 1112 */     String unsupportedDataType = JDBCType.of(srcJdbcType).toString().toLowerCase(Locale.ENGLISH);
/* 1113 */     throw new SQLServerException(form.format(new Object[] { unsupportedDataType }, ), null, 0, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeCekTable(TDSWriter tdsWriter) throws SQLServerException {
/* 1122 */     if (this.connection.getServerSupportsColumnEncryption()) {
/* 1123 */       if (null != this.destCekTable && 0 < this.destCekTable.getSize()) {
/* 1124 */         tdsWriter.writeShort((short)this.destCekTable.getSize());
/* 1125 */         for (int cekIndx = 0; cekIndx < this.destCekTable.getSize(); cekIndx++) {
/* 1126 */           tdsWriter.writeInt(((EncryptionKeyInfo)this.destCekTable
/* 1127 */               .getCekTableEntry(cekIndx).getColumnEncryptionKeyValues().get(0)).databaseId);
/* 1128 */           tdsWriter.writeInt(((EncryptionKeyInfo)this.destCekTable
/* 1129 */               .getCekTableEntry(cekIndx).getColumnEncryptionKeyValues().get(0)).cekId);
/* 1130 */           tdsWriter.writeInt(((EncryptionKeyInfo)this.destCekTable
/* 1131 */               .getCekTableEntry(cekIndx).getColumnEncryptionKeyValues().get(0)).cekVersion);
/* 1132 */           tdsWriter.writeBytes(((EncryptionKeyInfo)this.destCekTable
/* 1133 */               .getCekTableEntry(cekIndx).getColumnEncryptionKeyValues().get(0)).cekMdVersion);
/*      */ 
/*      */           
/* 1136 */           tdsWriter.writeByte((byte)0);
/*      */         } 
/*      */       } else {
/*      */         
/* 1140 */         tdsWriter.writeShort((short)0);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeColumnMetaData(TDSWriter tdsWriter) throws SQLServerException {
/* 1158 */     tdsWriter.writeByte((byte)-127);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1164 */     byte[] count = new byte[2];
/* 1165 */     count[0] = (byte)(this.columnMappings.size() & 0xFF);
/* 1166 */     count[1] = (byte)(this.columnMappings.size() >> 8 & 0xFF);
/* 1167 */     tdsWriter.writeBytes(count);
/*      */     
/* 1169 */     writeCekTable(tdsWriter);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1174 */     for (int i = 0; i < this.columnMappings.size(); i++) {
/* 1175 */       writeColumnMetaDataColumnData(tdsWriter, i);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void validateDataTypeConversions(int srcColOrdinal, int destColOrdinal) throws SQLServerException {
/* 1187 */     CryptoMetadata sourceCryptoMeta = ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(srcColOrdinal))).cryptoMeta;
/* 1188 */     CryptoMetadata destCryptoMeta = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(destColOrdinal))).cryptoMeta;
/*      */ 
/*      */     
/* 1191 */     JDBCType srcJdbcType = (null != sourceCryptoMeta) ? sourceCryptoMeta.baseTypeInfo.getSSType().getJDBCType() : JDBCType.of(((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(srcColOrdinal))).jdbcType);
/*      */ 
/*      */     
/* 1194 */     SSType destSSType = (null != destCryptoMeta) ? destCryptoMeta.baseTypeInfo.getSSType() : ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(destColOrdinal))).ssType;
/*      */ 
/*      */     
/* 1197 */     if (!srcJdbcType.convertsTo(destSSType)) {
/* 1198 */       DataTypes.throwConversionError(srcJdbcType.toString(), destSSType.toString());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String getDestTypeFromSrcType(int srcColIndx, int destColIndx, TDSWriter tdsWriter) throws SQLServerException {
/*      */     boolean isStreaming;
/* 1207 */     SSType destSSType = (null != ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(destColIndx))).cryptoMeta) ? ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(destColIndx))).cryptoMeta.baseTypeInfo.getSSType() : ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(destColIndx))).ssType;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1212 */     int bulkJdbcType = ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(srcColIndx))).jdbcType;
/*      */ 
/*      */     
/* 1215 */     int srcPrecision = ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(srcColIndx))).precision, bulkPrecision = srcPrecision;
/* 1216 */     int destPrecision = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(destColIndx))).precision;
/* 1217 */     int bulkScale = ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(srcColIndx))).scale;
/*      */     
/* 1219 */     CryptoMetadata destCryptoMeta = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(destColIndx))).cryptoMeta;
/* 1220 */     if (null != destCryptoMeta || (null == destCryptoMeta && this.copyOptions.isAllowEncryptedValueModifications())) {
/*      */       
/* 1222 */       tdsWriter.setCryptoMetaData(((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(destColIndx))).cryptoMeta);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1229 */       if (this.sourceResultSet instanceof SQLServerResultSet && this.connection.isColumnEncryptionSettingEnabled() && null != destCryptoMeta) {
/*      */         
/* 1231 */         bulkJdbcType = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(destColIndx))).jdbcType;
/* 1232 */         bulkPrecision = destPrecision;
/* 1233 */         bulkScale = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(destColIndx))).scale;
/*      */       } 
/*      */ 
/*      */       
/* 1237 */       if (8000 < destPrecision) {
/* 1238 */         return "varbinary(max)";
/*      */       }
/* 1240 */       return "varbinary(" + ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(destColIndx))).precision + ")";
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1245 */     if (null != this.sourceResultSet && null != ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(destColIndx))).encryptionType && this.copyOptions
/* 1246 */       .isAllowEncryptedValueModifications()) {
/* 1247 */       return "varbinary(" + bulkPrecision + ")";
/*      */     }
/* 1249 */     bulkPrecision = validateSourcePrecision(srcPrecision, bulkJdbcType, destPrecision);
/*      */     
/* 1251 */     if (-15 == bulkJdbcType || -9 == bulkJdbcType || -16 == bulkJdbcType) {
/*      */       
/* 1253 */       isStreaming = (4000 < srcPrecision || 4000 < destPrecision);
/*      */     } else {
/*      */       
/* 1256 */       isStreaming = (8000 < srcPrecision || 8000 < destPrecision);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1261 */     if (Util.isCharType(bulkJdbcType) && Util.isBinaryType(destSSType).booleanValue()) {
/* 1262 */       if (isStreaming) {
/* 1263 */         return "varbinary(max)";
/*      */       }
/*      */       
/* 1266 */       return destSSType.toString() + "(" + destSSType.toString() + ")";
/*      */     } 
/*      */ 
/*      */     
/* 1270 */     switch (bulkJdbcType) {
/*      */       case 4:
/* 1272 */         return "int";
/*      */       
/*      */       case 5:
/* 1275 */         return "smallint";
/*      */       
/*      */       case -5:
/* 1278 */         return "bigint";
/*      */       
/*      */       case -7:
/* 1281 */         return "bit";
/*      */       
/*      */       case -6:
/* 1284 */         return "tinyint";
/*      */       
/*      */       case 6:
/*      */       case 8:
/* 1288 */         return "float";
/*      */       
/*      */       case 7:
/* 1291 */         return "real";
/*      */       
/*      */       case -148:
/* 1294 */         return "money";
/*      */       case -146:
/* 1296 */         return "smallmoney";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 3:
/* 1304 */         if (destSSType == SSType.MONEY)
/* 1305 */           return "money"; 
/* 1306 */         if (destSSType == SSType.SMALLMONEY) {
/* 1307 */           return "smallmoney";
/*      */         }
/* 1309 */         return "decimal(" + bulkPrecision + ", " + bulkScale + ")";
/*      */       
/*      */       case 2:
/* 1312 */         if (destSSType == SSType.MONEY)
/* 1313 */           return "money"; 
/* 1314 */         if (destSSType == SSType.SMALLMONEY) {
/* 1315 */           return "smallmoney";
/*      */         }
/* 1317 */         return "numeric(" + bulkPrecision + ", " + bulkScale + ")";
/*      */ 
/*      */       
/*      */       case -145:
/* 1321 */         return "char(" + bulkPrecision + ")";
/*      */       case 1:
/* 1323 */         return unicodeConversionRequired(bulkJdbcType, destSSType) ? ("nchar(" + 
/* 1324 */           bulkPrecision + ")") : ("char(" + 
/*      */           
/* 1326 */           bulkPrecision + ")");
/*      */       
/*      */       case -15:
/* 1329 */         return "NCHAR(" + bulkPrecision + ")";
/*      */ 
/*      */ 
/*      */       
/*      */       case -1:
/*      */       case 12:
/* 1335 */         if (unicodeConversionRequired(bulkJdbcType, destSSType)) {
/* 1336 */           if (isStreaming) {
/* 1337 */             return "nvarchar(max)";
/*      */           }
/* 1339 */           return "nvarchar(" + bulkPrecision + ")";
/*      */         } 
/*      */         
/* 1342 */         if (isStreaming) {
/* 1343 */           return "varchar(max)";
/*      */         }
/* 1345 */         return "varchar(" + bulkPrecision + ")";
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case -16:
/*      */       case -9:
/* 1352 */         if (isStreaming) {
/* 1353 */           return "NVARCHAR(MAX)";
/*      */         }
/* 1355 */         return "NVARCHAR(" + bulkPrecision + ")";
/*      */ 
/*      */ 
/*      */       
/*      */       case -2:
/* 1360 */         return "binary(" + bulkPrecision + ")";
/*      */       
/*      */       case -4:
/*      */       case -3:
/* 1364 */         if (isStreaming) {
/* 1365 */           return "varbinary(max)";
/*      */         }
/* 1367 */         return "varbinary(" + bulkPrecision + ")";
/*      */       
/*      */       case -151:
/*      */       case -150:
/*      */       case 93:
/* 1372 */         switch (destSSType) {
/*      */           case DATE:
/* 1374 */             if (null != this.serverBulkData && this.connection.getSendTemporalDataTypesAsStringForBulkCopy())
/*      */             {
/* 1376 */               return "varchar(" + ((0 == bulkPrecision) ? 50 : bulkPrecision) + ")";
/*      */             }
/*      */             
/* 1379 */             return "smalldatetime";
/*      */           
/*      */           case TIME:
/* 1382 */             if (null != this.serverBulkData && this.connection.getSendTemporalDataTypesAsStringForBulkCopy())
/*      */             {
/* 1384 */               return "varchar(" + ((0 == bulkPrecision) ? 50 : bulkPrecision) + ")";
/*      */             }
/*      */             
/* 1387 */             return "datetime";
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1397 */         return (null != this.serverBulkData && this.connection.getSendTemporalDataTypesAsStringForBulkCopy()) ? ("varchar(" + (
/* 1398 */           (0 == bulkPrecision) ? destPrecision : bulkPrecision) + ")") : ("datetime2(" + 
/*      */           
/* 1400 */           bulkScale + ")");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 91:
/* 1410 */         if (null != this.serverBulkData && this.connection.getSendTemporalDataTypesAsStringForBulkCopy()) {
/* 1411 */           return "varchar(" + ((0 == bulkPrecision) ? destPrecision : bulkPrecision) + ")";
/*      */         }
/* 1413 */         return "date";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 92:
/* 1422 */         return (null != this.serverBulkData && this.connection.getSendTemporalDataTypesAsStringForBulkCopy()) ? ("varchar(" + (
/* 1423 */           (0 == bulkPrecision) ? destPrecision : bulkPrecision) + ")") : ("time(" + 
/*      */           
/* 1425 */           bulkScale + ")");
/*      */ 
/*      */ 
/*      */       
/*      */       case 2013:
/*      */       case 2014:
/* 1431 */         return "datetimeoffset(" + bulkScale + ")";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case -155:
/* 1439 */         return (null != this.serverBulkData && this.connection.getSendTemporalDataTypesAsStringForBulkCopy()) ? ("varchar(" + (
/* 1440 */           (0 == bulkPrecision) ? destPrecision : bulkPrecision) + ")") : ("datetimeoffset(" + 
/*      */           
/* 1442 */           bulkScale + ")");
/*      */       
/*      */       case -156:
/* 1445 */         return "sql_variant";
/*      */     } 
/* 1447 */     MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_BulkTypeNotSupported"));
/* 1448 */     Object[] msgArgs = { JDBCType.of(bulkJdbcType).toString().toLowerCase(Locale.ENGLISH) };
/* 1449 */     SQLServerException.makeFromDriverError(null, null, form.format(msgArgs), null, true);
/*      */ 
/*      */     
/* 1452 */     return null;
/*      */   }
/*      */   
/*      */   private String createInsertBulkCommand(TDSWriter tdsWriter) throws SQLServerException {
/* 1456 */     StringBuilder bulkCmd = new StringBuilder();
/* 1457 */     List<String> bulkOptions = new ArrayList<>();
/* 1458 */     String endColumn = " , ";
/* 1459 */     bulkCmd.append("INSERT BULK ").append(this.destinationTableName).append(" (");
/*      */     
/* 1461 */     for (int i = 0; i < this.columnMappings.size(); i++) {
/* 1462 */       if (i == this.columnMappings.size() - 1) {
/* 1463 */         endColumn = " ) ";
/*      */       }
/* 1465 */       ColumnMapping colMapping = this.columnMappings.get(i);
/*      */       
/* 1467 */       String columnCollation = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(((ColumnMapping)this.columnMappings.get(i)).destinationColumnOrdinal))).collationName;
/* 1468 */       String addCollate = "";
/*      */ 
/*      */       
/* 1471 */       String destType = getDestTypeFromSrcType(colMapping.sourceColumnOrdinal, colMapping.destinationColumnOrdinal, tdsWriter).toUpperCase(Locale.ENGLISH);
/* 1472 */       if (null != columnCollation && columnCollation.trim().length() > 0)
/*      */       {
/* 1474 */         if (null != destType && (destType.toLowerCase(Locale.ENGLISH).trim().startsWith("char") || destType
/* 1475 */           .toLowerCase(Locale.ENGLISH).trim().startsWith("varchar")))
/* 1476 */           addCollate = " COLLATE " + columnCollation; 
/*      */       }
/* 1478 */       if (colMapping.destinationColumnName.contains("]")) {
/* 1479 */         String escapedColumnName = colMapping.destinationColumnName.replaceAll("]", "]]");
/* 1480 */         bulkCmd.append("[").append(escapedColumnName).append("] ").append(destType).append(addCollate)
/* 1481 */           .append(endColumn);
/*      */       } else {
/* 1483 */         bulkCmd.append("[").append(colMapping.destinationColumnName).append("] ").append(destType)
/* 1484 */           .append(addCollate).append(endColumn);
/*      */       } 
/*      */     } 
/*      */     
/* 1488 */     if (this.copyOptions.isCheckConstraints()) {
/* 1489 */       bulkOptions.add("CHECK_CONSTRAINTS");
/*      */     }
/*      */     
/* 1492 */     if (this.copyOptions.isFireTriggers()) {
/* 1493 */       bulkOptions.add("FIRE_TRIGGERS");
/*      */     }
/*      */     
/* 1496 */     if (this.copyOptions.isKeepNulls()) {
/* 1497 */       bulkOptions.add("KEEP_NULLS");
/*      */     }
/*      */     
/* 1500 */     if (this.copyOptions.getBatchSize() > 0) {
/* 1501 */       bulkOptions.add("ROWS_PER_BATCH = " + this.copyOptions.getBatchSize());
/*      */     }
/*      */     
/* 1504 */     if (this.copyOptions.isTableLock()) {
/* 1505 */       bulkOptions.add("TABLOCK");
/*      */     }
/*      */     
/* 1508 */     if (this.copyOptions.isAllowEncryptedValueModifications()) {
/* 1509 */       bulkOptions.add("ALLOW_ENCRYPTED_VALUE_MODIFICATIONS");
/*      */     }
/*      */     
/* 1512 */     Iterator<String> it = bulkOptions.iterator();
/* 1513 */     if (it.hasNext()) {
/* 1514 */       bulkCmd.append(" with (");
/* 1515 */       while (it.hasNext()) {
/* 1516 */         bulkCmd.append(it.next());
/* 1517 */         if (it.hasNext()) {
/* 1518 */           bulkCmd.append(", ");
/*      */         }
/*      */       } 
/* 1521 */       bulkCmd.append(")");
/*      */     } 
/*      */     
/* 1524 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 1525 */       loggerExternal.finer(toString() + " TDSCommand: " + toString());
/*      */     }
/* 1527 */     return bulkCmd.toString();
/*      */   }
/*      */   
/*      */   private boolean doInsertBulk(TDSCommand command) throws SQLServerException {
/* 1531 */     if (this.copyOptions.isUseInternalTransaction())
/*      */     {
/* 1533 */       this.connection.setAutoCommit(false);
/*      */     }
/*      */     
/* 1536 */     boolean insertRowByRow = false;
/*      */     
/* 1538 */     if (null != this.sourceResultSet && this.sourceResultSet instanceof SQLServerResultSet) {
/* 1539 */       SQLServerStatement src_stmt = (SQLServerStatement)((SQLServerResultSet)this.sourceResultSet).getStatement();
/* 1540 */       int resultSetServerCursorId = ((SQLServerResultSet)this.sourceResultSet).getServerCursorId();
/*      */       
/* 1542 */       if (this.connection.equals(src_stmt.getConnection()) && 0 != resultSetServerCursorId) {
/* 1543 */         insertRowByRow = true;
/*      */       }
/*      */       
/* 1546 */       if (((SQLServerResultSet)this.sourceResultSet).isForwardOnly()) {
/*      */         try {
/* 1548 */           this.sourceResultSet.setFetchSize(1);
/* 1549 */         } catch (SQLException e) {
/* 1550 */           SQLServerException.makeFromDriverError(this.connection, this.sourceResultSet, e.getMessage(), e.getSQLState(), true);
/*      */         } 
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1556 */     TDSWriter tdsWriter = null;
/* 1557 */     boolean moreDataAvailable = false;
/*      */     
/*      */     try {
/* 1560 */       if (!insertRowByRow) {
/* 1561 */         tdsWriter = sendBulkCopyCommand(command);
/*      */       }
/*      */ 
/*      */       
/*      */       try {
/* 1566 */         moreDataAvailable = writeBatchData(tdsWriter, command, insertRowByRow);
/*      */       } finally {
/* 1568 */         tdsWriter = command.getTDSWriter();
/*      */       } 
/*      */     } finally {
/* 1571 */       if (null == tdsWriter) {
/* 1572 */         tdsWriter = command.getTDSWriter();
/*      */       }
/*      */ 
/*      */       
/* 1576 */       tdsWriter.setCryptoMetaData(null);
/*      */     } 
/*      */     
/* 1579 */     if (!insertRowByRow) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1586 */       writePacketDataDone(tdsWriter);
/*      */ 
/*      */       
/* 1589 */       TDSParser.parse(command.startResponse(), command.getLogContext());
/*      */     } 
/*      */     
/* 1592 */     if (this.copyOptions.isUseInternalTransaction())
/*      */     {
/* 1594 */       this.connection.commit();
/*      */     }
/*      */     
/* 1597 */     return moreDataAvailable;
/*      */   }
/*      */ 
/*      */   
/*      */   private TDSWriter sendBulkCopyCommand(TDSCommand command) throws SQLServerException {
/* 1602 */     TDSWriter tdsWriter = command.startRequest((byte)1);
/* 1603 */     String bulkCmd = createInsertBulkCommand(tdsWriter);
/* 1604 */     tdsWriter.sendEnclavePackage(null, null);
/* 1605 */     tdsWriter.writeString(bulkCmd);
/* 1606 */     TDSParser.parse(command.startResponse(), command.getLogContext());
/*      */ 
/*      */     
/* 1609 */     tdsWriter = command.startRequest((byte)7);
/*      */ 
/*      */     
/* 1612 */     writeColumnMetaData(tdsWriter);
/*      */     
/* 1614 */     return tdsWriter;
/*      */   }
/*      */ 
/*      */   
/*      */   private void writePacketDataDone(TDSWriter tdsWriter) throws SQLServerException {
/* 1619 */     tdsWriter.writeByte((byte)-3);
/* 1620 */     tdsWriter.writeLong(0L);
/* 1621 */     tdsWriter.writeInt(0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void throwInvalidArgument(String argument) throws SQLServerException {
/* 1628 */     MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidArgument"));
/* 1629 */     Object[] msgArgs = { argument };
/* 1630 */     SQLServerException.makeFromDriverError(null, null, form.format(msgArgs), null, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeToServer() throws SQLServerException {
/* 1637 */     if (this.connection.isClosed()) {
/* 1638 */       SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_connectionIsClosed"), "08003", false);
/*      */     }
/*      */ 
/*      */     
/* 1642 */     long start = System.currentTimeMillis();
/* 1643 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 1644 */       loggerExternal.finer(toString() + " Start writeToServer: " + toString());
/*      */     }
/* 1646 */     getDestinationMetadata();
/*      */ 
/*      */ 
/*      */     
/* 1650 */     getSourceMetadata();
/*      */     
/* 1652 */     validateColumnMappings();
/*      */     
/* 1654 */     sendBulkLoadBCP();
/*      */     
/* 1656 */     long end = System.currentTimeMillis();
/* 1657 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 1658 */       loggerExternal.finer(toString() + " End writeToServer: " + toString());
/* 1659 */       int seconds = (int)((end - start) / 1000L);
/* 1660 */       loggerExternal.finer(toString() + "Time elapsed: " + toString() + " seconds");
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void validateStringBinaryLengths(Object colValue, int srcCol, int destCol) throws SQLServerException {
/* 1666 */     int destPrecision = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(destCol))).precision;
/* 1667 */     int srcJdbcType = ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(srcCol))).jdbcType;
/* 1668 */     SSType destSSType = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(destCol))).ssType;
/*      */     
/* 1670 */     if ((Util.isCharType(srcJdbcType) && Util.isCharType(destSSType).booleanValue()) || (
/* 1671 */       Util.isBinaryType(srcJdbcType).booleanValue() && Util.isBinaryType(destSSType).booleanValue())) {
/* 1672 */       int sourcePrecision; if (colValue instanceof String) {
/* 1673 */         if (Util.isBinaryType(destSSType).booleanValue())
/*      */         
/*      */         { 
/* 1676 */           sourcePrecision = (((String)colValue).getBytes()).length / 2; }
/*      */         else
/* 1678 */         { sourcePrecision = ((String)colValue).length(); } 
/* 1679 */       } else if (colValue instanceof byte[]) {
/* 1680 */         sourcePrecision = ((byte[])colValue).length;
/*      */       } else {
/*      */         return;
/*      */       } 
/*      */       
/* 1685 */       if (sourcePrecision > destPrecision) {
/* 1686 */         String srcType = "" + JDBCType.of(srcJdbcType) + "(" + JDBCType.of(srcJdbcType) + ")";
/* 1687 */         String destType = destSSType.toString() + "(" + destSSType.toString() + ")";
/* 1688 */         MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_InvalidDataForAE"));
/* 1689 */         Object[] msgArgs = { srcType, destType };
/* 1690 */         throw new SQLServerException(this, form.format(msgArgs), null, 0, false);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void getDestinationMetadata() throws SQLServerException {
/* 1699 */     if (null == this.destinationTableName) {
/* 1700 */       SQLServerException.makeFromDriverError(null, null, 
/* 1701 */           SQLServerException.getErrString("R_invalidDestinationTable"), null, false);
/*      */     }
/*      */     
/* 1704 */     String escapedDestinationTableName = Util.escapeSingleQuotes(this.destinationTableName);
/*      */     
/* 1706 */     SQLServerResultSet rs = null;
/* 1707 */     SQLServerStatement stmt = null;
/* 1708 */     String metaDataQuery = null;
/*      */ 
/*      */     
/* 1711 */     try { if (null != this.destinationTableMetadata) {
/* 1712 */         rs = (SQLServerResultSet)this.destinationTableMetadata;
/*      */       } else {
/* 1714 */         stmt = (SQLServerStatement)this.connection.createStatement(1003, 1007, this.connection
/* 1715 */             .getHoldability(), this.stmtColumnEncriptionSetting);
/*      */ 
/*      */         
/* 1718 */         rs = stmt.executeQueryInternal("sp_executesql N'SET FMTONLY ON SELECT * FROM " + escapedDestinationTableName + " '");
/*      */       } 
/*      */ 
/*      */       
/* 1722 */       this.destColumnCount = rs.getMetaData().getColumnCount();
/* 1723 */       this.destColumnMetadata = new HashMap<>();
/* 1724 */       this.destCekTable = rs.getCekTable();
/*      */       
/* 1726 */       if (!this.connection.getServerSupportsColumnEncryption()) {
/* 1727 */         metaDataQuery = "select collation_name from sys.columns where object_id=OBJECT_ID('" + escapedDestinationTableName + "') order by column_id ASC";
/*      */       } else {
/*      */         
/* 1730 */         metaDataQuery = "select collation_name, encryption_type from sys.columns where object_id=OBJECT_ID('" + escapedDestinationTableName + "') order by column_id ASC";
/*      */       } 
/*      */ 
/*      */       
/* 1734 */       SQLServerStatement statementMoreMetadata = (SQLServerStatement)this.connection.createStatement(); 
/* 1735 */       try { SQLServerResultSet rsMoreMetaData = statementMoreMetadata.executeQueryInternal(metaDataQuery); 
/* 1736 */         try { for (int i = 1; i <= this.destColumnCount; i++) {
/* 1737 */             if (rsMoreMetaData.next()) {
/* 1738 */               String bulkCopyEncryptionType = null;
/* 1739 */               if (this.connection.getServerSupportsColumnEncryption()) {
/* 1740 */                 bulkCopyEncryptionType = rsMoreMetaData.getString("encryption_type");
/*      */               }
/* 1742 */               this.destColumnMetadata.put(Integer.valueOf(i), new BulkColumnMetaData(rs.getColumn(i), rsMoreMetaData
/* 1743 */                     .getString("collation_name"), bulkCopyEncryptionType));
/*      */             } else {
/* 1745 */               this.destColumnMetadata.put(Integer.valueOf(i), new BulkColumnMetaData(rs.getColumn(i)));
/*      */             } 
/*      */           } 
/* 1748 */           if (rsMoreMetaData != null) rsMoreMetaData.close();  } catch (Throwable throwable) { if (rsMoreMetaData != null) try { rsMoreMetaData.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  if (statementMoreMetadata != null) statementMoreMetadata.close();  } catch (Throwable throwable) { if (statementMoreMetadata != null)
/* 1749 */           try { statementMoreMetadata.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException e)
/*      */     
/* 1751 */     { throw new SQLServerException(SQLServerException.getErrString("R_unableRetrieveColMeta"), e); }
/*      */     finally
/* 1753 */     { if (null != rs)
/* 1754 */         rs.close(); 
/* 1755 */       if (null != stmt) {
/* 1756 */         stmt.close();
/*      */       } }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void getSourceMetadata() throws SQLServerException {
/* 1765 */     this.srcColumnMetadata = new HashMap<>();
/*      */     
/* 1767 */     if (null != this.sourceResultSet) {
/*      */       try {
/* 1769 */         this.srcColumnCount = this.sourceResultSetMetaData.getColumnCount();
/* 1770 */         for (int i = 1; i <= this.srcColumnCount; i++) {
/* 1771 */           this.srcColumnMetadata.put(Integer.valueOf(i), new BulkColumnMetaData(this.sourceResultSetMetaData
/* 1772 */                 .getColumnName(i), 
/* 1773 */                 (0 != this.sourceResultSetMetaData.isNullable(i)), this.sourceResultSetMetaData
/* 1774 */                 .getPrecision(i), this.sourceResultSetMetaData.getScale(i), this.sourceResultSetMetaData
/* 1775 */                 .getColumnType(i), null));
/*      */         }
/* 1777 */       } catch (SQLException e) {
/*      */         
/* 1779 */         throw new SQLServerException(SQLServerException.getErrString("R_unableRetrieveColMeta"), e);
/*      */       } 
/* 1781 */     } else if (null != this.serverBulkData) {
/* 1782 */       Set<Integer> columnOrdinals = this.serverBulkData.getColumnOrdinals();
/* 1783 */       if (null == columnOrdinals || 0 == columnOrdinals.size()) {
/* 1784 */         throw new SQLServerException(SQLServerException.getErrString("R_unableRetrieveColMeta"), null);
/*      */       }
/* 1786 */       this.srcColumnCount = columnOrdinals.size();
/* 1787 */       for (Integer columnOrdinal : columnOrdinals) {
/* 1788 */         int currentColumn = columnOrdinal.intValue();
/* 1789 */         this.srcColumnMetadata.put(Integer.valueOf(currentColumn), new BulkColumnMetaData(this.serverBulkData
/* 1790 */               .getColumnName(currentColumn), true, this.serverBulkData
/* 1791 */               .getPrecision(currentColumn), this.serverBulkData.getScale(currentColumn), this.serverBulkData
/* 1792 */               .getColumnType(currentColumn), 
/* 1793 */               (this.serverBulkData instanceof SQLServerBulkCSVFileRecord) ? (
/* 1794 */               (SQLServerBulkCSVFileRecord)this.serverBulkData).getColumnDateTimeFormatter(currentColumn) : null));
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/* 1799 */       throw new SQLServerException(SQLServerException.getErrString("R_unableRetrieveColMeta"), null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int validateSourcePrecision(int srcPrecision, int srcJdbcType, int destPrecision) {
/* 1807 */     if (1 > srcPrecision && Util.isCharType(srcJdbcType)) {
/* 1808 */       srcPrecision = destPrecision;
/*      */     }
/* 1810 */     return srcPrecision;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void validateColumnMappings() throws SQLServerException {
/*      */     try {
/* 1818 */       if (this.columnMappings.isEmpty()) {
/*      */ 
/*      */         
/* 1821 */         if (this.destColumnCount != this.srcColumnCount) {
/* 1822 */           throw new SQLServerException(SQLServerException.getErrString("R_schemaMismatch"), SQLState.COL_NOT_FOUND, DriverError.NOT_SET, null);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1830 */         for (int i = 1; i <= this.srcColumnCount; i++) {
/*      */           
/* 1832 */           if (!((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(i))).isIdentity || this.copyOptions.isKeepIdentity()) {
/* 1833 */             ColumnMapping cm = new ColumnMapping(i, i);
/*      */             
/* 1835 */             cm.destinationColumnName = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(i))).columnName;
/* 1836 */             this.columnMappings.add(cm);
/*      */           } 
/*      */         } 
/*      */         
/* 1840 */         if (null != this.serverBulkData) {
/* 1841 */           Set<Integer> columnOrdinals = this.serverBulkData.getColumnOrdinals();
/* 1842 */           Iterator<Integer> columnsIterator = columnOrdinals.iterator();
/* 1843 */           int j = 1;
/* 1844 */           while (columnsIterator.hasNext()) {
/* 1845 */             int currentOrdinal = ((Integer)columnsIterator.next()).intValue();
/* 1846 */             if (j != currentOrdinal) {
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1851 */               List<Integer> sortedList = new ArrayList<>(columnOrdinals);
/* 1852 */               Collections.sort(sortedList);
/* 1853 */               columnsIterator = sortedList.iterator();
/* 1854 */               j = 1;
/* 1855 */               while (columnsIterator.hasNext()) {
/* 1856 */                 currentOrdinal = ((Integer)columnsIterator.next()).intValue();
/* 1857 */                 if (j != currentOrdinal) {
/*      */                   
/* 1859 */                   MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidColumn"));
/* 1860 */                   Object[] msgArgs = { Integer.valueOf(currentOrdinal) };
/* 1861 */                   throw new SQLServerException(form.format(msgArgs), SQLState.COL_NOT_FOUND, DriverError.NOT_SET, null);
/*      */                 } 
/*      */                 
/* 1864 */                 j++;
/*      */               } 
/*      */               
/*      */               break;
/*      */             } 
/* 1869 */             j++;
/*      */           } 
/*      */         } 
/*      */       } else {
/* 1873 */         int numMappings = this.columnMappings.size();
/*      */         
/*      */         int i;
/*      */         
/* 1877 */         for (i = 0; i < numMappings; i++) {
/* 1878 */           ColumnMapping cm = this.columnMappings.get(i);
/*      */ 
/*      */           
/* 1881 */           if (-1 == cm.destinationColumnOrdinal) {
/* 1882 */             boolean foundColumn = false;
/*      */             
/* 1884 */             for (int j = 1; j <= this.destColumnCount; j++) {
/* 1885 */               if (((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(j))).columnName.equals(cm.destinationColumnName)) {
/* 1886 */                 foundColumn = true;
/* 1887 */                 cm.destinationColumnOrdinal = j;
/*      */                 
/*      */                 break;
/*      */               } 
/*      */             } 
/* 1892 */             if (!foundColumn) {
/* 1893 */               MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidColumn"));
/* 1894 */               Object[] msgArgs = { cm.destinationColumnName };
/* 1895 */               throw new SQLServerException(form.format(msgArgs), SQLState.COL_NOT_FOUND, DriverError.NOT_SET, null);
/*      */             } 
/*      */           } else {
/* 1898 */             if (0 > cm.destinationColumnOrdinal || this.destColumnCount < cm.destinationColumnOrdinal) {
/* 1899 */               MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidColumn"));
/* 1900 */               Object[] msgArgs = { Integer.valueOf(cm.destinationColumnOrdinal) };
/* 1901 */               throw new SQLServerException(form.format(msgArgs), SQLState.COL_NOT_FOUND, DriverError.NOT_SET, null);
/*      */             } 
/*      */             
/* 1904 */             cm.destinationColumnName = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(cm.destinationColumnOrdinal))).columnName;
/*      */           } 
/*      */         } 
/*      */ 
/*      */         
/* 1909 */         for (i = 0; i < numMappings; i++) {
/* 1910 */           ColumnMapping cm = this.columnMappings.get(i);
/*      */ 
/*      */           
/* 1913 */           if (-1 == cm.sourceColumnOrdinal) {
/* 1914 */             boolean foundColumn = false;
/* 1915 */             if (null != this.sourceResultSet) {
/* 1916 */               int columns = this.sourceResultSetMetaData.getColumnCount();
/* 1917 */               for (int j = 1; j <= columns; j++) {
/* 1918 */                 if (this.sourceResultSetMetaData.getColumnName(j).equals(cm.sourceColumnName)) {
/* 1919 */                   foundColumn = true;
/* 1920 */                   cm.sourceColumnOrdinal = j;
/*      */                   break;
/*      */                 } 
/*      */               } 
/*      */             } else {
/* 1925 */               Set<Integer> columnOrdinals = this.serverBulkData.getColumnOrdinals();
/* 1926 */               for (Integer currentColumn : columnOrdinals) {
/* 1927 */                 if (this.serverBulkData.getColumnName(currentColumn.intValue()).equals(cm.sourceColumnName)) {
/* 1928 */                   foundColumn = true;
/* 1929 */                   cm.sourceColumnOrdinal = currentColumn.intValue();
/*      */                   
/*      */                   break;
/*      */                 } 
/*      */               } 
/*      */             } 
/* 1935 */             if (!foundColumn) {
/* 1936 */               MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidColumn"));
/* 1937 */               Object[] msgArgs = { cm.sourceColumnName };
/* 1938 */               throw new SQLServerException(form.format(msgArgs), SQLState.COL_NOT_FOUND, DriverError.NOT_SET, null);
/*      */             }
/*      */           
/*      */           } else {
/*      */             
/* 1943 */             boolean columnOutOfRange = true;
/* 1944 */             if (null != this.sourceResultSet) {
/* 1945 */               int columns = this.sourceResultSetMetaData.getColumnCount();
/* 1946 */               if (0 < cm.sourceColumnOrdinal && columns >= cm.sourceColumnOrdinal) {
/* 1947 */                 columnOutOfRange = false;
/*      */               
/*      */               }
/*      */             }
/* 1951 */             else if (this.srcColumnMetadata.containsKey(Integer.valueOf(cm.sourceColumnOrdinal))) {
/* 1952 */               columnOutOfRange = false;
/*      */             } 
/*      */ 
/*      */             
/* 1956 */             if (columnOutOfRange) {
/* 1957 */               MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidColumn"));
/* 1958 */               Object[] msgArgs = { Integer.valueOf(cm.sourceColumnOrdinal) };
/* 1959 */               throw new SQLServerException(form.format(msgArgs), SQLState.COL_NOT_FOUND, DriverError.NOT_SET, null);
/*      */             } 
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/* 1965 */           if (((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(cm.destinationColumnOrdinal))).isIdentity && 
/* 1966 */             !this.copyOptions.isKeepIdentity()) {
/* 1967 */             this.columnMappings.remove(i);
/* 1968 */             numMappings--;
/* 1969 */             i--;
/*      */           } 
/*      */         } 
/*      */       } 
/* 1973 */     } catch (SQLException e) {
/*      */       
/* 1975 */       if (e instanceof SQLServerException && null != e.getSQLState() && e
/* 1976 */         .getSQLState().equals(SQLState.COL_NOT_FOUND.getSQLStateCode())) {
/* 1977 */         throw (SQLServerException)e;
/*      */       }
/*      */ 
/*      */       
/* 1981 */       throw new SQLServerException(SQLServerException.getErrString("R_unableRetrieveColMeta"), e);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1986 */     if (this.columnMappings.isEmpty()) {
/* 1987 */       throw new SQLServerException(null, SQLServerException.getErrString("R_BulkColumnMappingsIsEmpty"), null, 0, false);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeNullToTdsWriter(TDSWriter tdsWriter, int srcJdbcType, boolean isStreaming) throws SQLServerException {
/* 1995 */     switch (srcJdbcType) {
/*      */       case -16:
/*      */       case -15:
/*      */       case -9:
/*      */       case -4:
/*      */       case -3:
/*      */       case -2:
/*      */       case -1:
/*      */       case 1:
/*      */       case 12:
/* 2005 */         if (isStreaming) {
/* 2006 */           tdsWriter.writeLong(-1L);
/*      */         } else {
/* 2008 */           tdsWriter.writeByte((byte)-1);
/* 2009 */           tdsWriter.writeByte((byte)-1);
/*      */         } 
/*      */         return;
/*      */       case -155:
/*      */       case -148:
/*      */       case -146:
/*      */       case -7:
/*      */       case -6:
/*      */       case -5:
/*      */       case 2:
/*      */       case 3:
/*      */       case 4:
/*      */       case 5:
/*      */       case 6:
/*      */       case 7:
/*      */       case 8:
/*      */       case 91:
/*      */       case 92:
/*      */       case 93:
/*      */       case 2013:
/*      */       case 2014:
/* 2030 */         tdsWriter.writeByte((byte)0);
/*      */         return;
/*      */       case -156:
/* 2033 */         tdsWriter.writeInt(0);
/*      */         return;
/*      */     } 
/* 2036 */     MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_BulkTypeNotSupported"));
/* 2037 */     Object[] msgArgs = { JDBCType.of(srcJdbcType).toString().toLowerCase(Locale.ENGLISH) };
/* 2038 */     SQLServerException.makeFromDriverError(null, null, form.format(msgArgs), null, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeColumnToTdsWriter(TDSWriter tdsWriter, int bulkPrecision, int bulkScale, int bulkJdbcType, boolean bulkNullable, int srcColOrdinal, int destColOrdinal, boolean isStreaming, Object colValue) throws SQLServerException {
/* 2045 */     SSType destSSType = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(destColOrdinal))).ssType;
/*      */     
/* 2047 */     bulkPrecision = validateSourcePrecision(bulkPrecision, bulkJdbcType, ((BulkColumnMetaData)this.destColumnMetadata
/* 2048 */         .get(Integer.valueOf(destColOrdinal))).precision);
/*      */     
/* 2050 */     CryptoMetadata sourceCryptoMeta = ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(srcColOrdinal))).cryptoMeta;
/* 2051 */     if ((null != ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(destColOrdinal))).encryptionType && this.copyOptions
/* 2052 */       .isAllowEncryptedValueModifications()) || null != ((BulkColumnMetaData)this.destColumnMetadata
/*      */       
/* 2054 */       .get(Integer.valueOf(destColOrdinal))).cryptoMeta) {
/* 2055 */       bulkJdbcType = -3;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 2062 */     else if (null != sourceCryptoMeta) {
/* 2063 */       bulkJdbcType = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(destColOrdinal))).jdbcType;
/* 2064 */       bulkScale = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(destColOrdinal))).scale;
/* 2065 */     } else if (null != this.serverBulkData && this.connection.getSendTemporalDataTypesAsStringForBulkCopy()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2071 */       switch (bulkJdbcType) {
/*      */         case -155:
/*      */         case 91:
/*      */         case 92:
/*      */         case 93:
/* 2076 */           bulkJdbcType = 12;
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     } 
/*      */     try {
/*      */       boolean isShiloh;
/* 2086 */       switch (bulkJdbcType) {
/*      */         case 4:
/* 2088 */           if (null == colValue) {
/* 2089 */             writeNullToTdsWriter(tdsWriter, bulkJdbcType, isStreaming);
/*      */           } else {
/* 2091 */             if (bulkNullable) {
/* 2092 */               tdsWriter.writeByte((byte)4);
/*      */             }
/* 2094 */             tdsWriter.writeInt(((Integer)colValue).intValue());
/*      */           } 
/*      */           return;
/*      */         
/*      */         case 5:
/* 2099 */           if (null == colValue) {
/* 2100 */             writeNullToTdsWriter(tdsWriter, bulkJdbcType, isStreaming);
/*      */           } else {
/* 2102 */             if (bulkNullable) {
/* 2103 */               tdsWriter.writeByte((byte)2);
/*      */             }
/* 2105 */             tdsWriter.writeShort(((Number)colValue).shortValue());
/*      */           } 
/*      */           return;
/*      */         
/*      */         case -5:
/* 2110 */           if (null == colValue) {
/* 2111 */             writeNullToTdsWriter(tdsWriter, bulkJdbcType, isStreaming);
/*      */           } else {
/* 2113 */             if (bulkNullable) {
/* 2114 */               tdsWriter.writeByte((byte)8);
/*      */             }
/* 2116 */             tdsWriter.writeLong(((Long)colValue).longValue());
/*      */           } 
/*      */           return;
/*      */         
/*      */         case -7:
/* 2121 */           if (null == colValue) {
/* 2122 */             writeNullToTdsWriter(tdsWriter, bulkJdbcType, isStreaming);
/*      */           } else {
/* 2124 */             if (bulkNullable) {
/* 2125 */               tdsWriter.writeByte((byte)1);
/*      */             }
/* 2127 */             tdsWriter.writeByte((byte)(((Boolean)colValue).booleanValue() ? 1 : 0));
/*      */           } 
/*      */           return;
/*      */         
/*      */         case -6:
/* 2132 */           if (null == colValue) {
/* 2133 */             writeNullToTdsWriter(tdsWriter, bulkJdbcType, isStreaming);
/*      */           } else {
/* 2135 */             if (bulkNullable) {
/* 2136 */               tdsWriter.writeByte((byte)1);
/*      */             }
/*      */ 
/*      */             
/* 2140 */             tdsWriter.writeByte((byte)(((Number)colValue).shortValue() & 0xFF));
/*      */           } 
/*      */           return;
/*      */ 
/*      */         
/*      */         case 6:
/* 2146 */           if (null == colValue) {
/* 2147 */             writeNullToTdsWriter(tdsWriter, bulkJdbcType, isStreaming);
/*      */           } else {
/* 2149 */             if (bulkNullable) {
/* 2150 */               tdsWriter.writeByte((byte)8);
/*      */             }
/* 2152 */             tdsWriter.writeDouble(((Float)colValue).floatValue());
/*      */           } 
/*      */           return;
/*      */         
/*      */         case 8:
/* 2157 */           if (null == colValue) {
/* 2158 */             writeNullToTdsWriter(tdsWriter, bulkJdbcType, isStreaming);
/*      */           } else {
/* 2160 */             if (bulkNullable) {
/* 2161 */               tdsWriter.writeByte((byte)8);
/*      */             }
/* 2163 */             tdsWriter.writeDouble(((Double)colValue).doubleValue());
/*      */           } 
/*      */           return;
/*      */         
/*      */         case 7:
/* 2168 */           if (null == colValue) {
/* 2169 */             writeNullToTdsWriter(tdsWriter, bulkJdbcType, isStreaming);
/*      */           } else {
/* 2171 */             if (bulkNullable) {
/* 2172 */               tdsWriter.writeByte((byte)4);
/*      */             }
/* 2174 */             tdsWriter.writeReal(((Float)colValue).floatValue());
/*      */           } 
/*      */           return;
/*      */         
/*      */         case -148:
/*      */         case -146:
/* 2180 */           if (null == colValue) {
/* 2181 */             writeNullToTdsWriter(tdsWriter, bulkJdbcType, isStreaming);
/*      */ 
/*      */           
/*      */           }
/*      */           else {
/*      */ 
/*      */             
/* 2188 */             if (bulkPrecision < Util.getValueLengthBaseOnJavaType(colValue, JavaType.of(colValue), null, null, 
/* 2189 */                 JDBCType.of(bulkJdbcType))) {
/*      */               
/* 2191 */               MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_valueOutOfRange"));
/* 2192 */               Object[] arrayOfObject = { destSSType };
/* 2193 */               throw new SQLServerException(messageFormat.format(arrayOfObject), SQLState.DATA_EXCEPTION_LENGTH_MISMATCH, DriverError.NOT_SET, null);
/*      */             } 
/*      */             
/* 2196 */             tdsWriter.writeMoney((BigDecimal)colValue, bulkJdbcType);
/*      */           } 
/*      */           return;
/*      */         case 2:
/*      */         case 3:
/* 2201 */           if (null == colValue) {
/* 2202 */             writeNullToTdsWriter(tdsWriter, bulkJdbcType, isStreaming);
/*      */ 
/*      */           
/*      */           }
/*      */           else {
/*      */ 
/*      */             
/* 2209 */             if (bulkPrecision < Util.getValueLengthBaseOnJavaType(colValue, JavaType.of(colValue), null, null, 
/* 2210 */                 JDBCType.of(bulkJdbcType))) {
/*      */               
/* 2212 */               MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_valueOutOfRange"));
/* 2213 */               Object[] arrayOfObject = { destSSType };
/* 2214 */               throw new SQLServerException(messageFormat.format(arrayOfObject), SQLState.DATA_EXCEPTION_LENGTH_MISMATCH, DriverError.NOT_SET, null);
/*      */             } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 2223 */             if (destSSType == SSType.MONEY) {
/* 2224 */               tdsWriter.writeMoney((BigDecimal)colValue, -148);
/* 2225 */             } else if (destSSType == SSType.SMALLMONEY) {
/* 2226 */               tdsWriter.writeMoney((BigDecimal)colValue, -146);
/*      */             } else {
/* 2228 */               tdsWriter.writeBigDecimal((BigDecimal)colValue, bulkJdbcType, bulkPrecision, bulkScale);
/*      */             } 
/*      */           } 
/*      */           return;
/*      */         
/*      */         case -145:
/*      */         case -1:
/*      */         case 1:
/*      */         case 12:
/* 2237 */           if (isStreaming) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 2244 */             if (null == colValue) {
/* 2245 */               writeNullToTdsWriter(tdsWriter, bulkJdbcType, isStreaming);
/*      */             } else {
/*      */               
/* 2248 */               tdsWriter.writeLong(-2L);
/*      */               
/*      */               try {
/*      */                 Reader reader;
/*      */                 
/* 2253 */                 if (colValue instanceof Reader) {
/* 2254 */                   reader = (Reader)colValue;
/*      */                 } else {
/* 2256 */                   reader = new StringReader(colValue.toString());
/*      */                 } 
/* 2258 */                 if (unicodeConversionRequired(bulkJdbcType, destSSType)) {
/*      */                   
/* 2260 */                   tdsWriter.writeReader(reader, -1L, true);
/*      */                 }
/* 2262 */                 else if (SSType.BINARY == destSSType || SSType.VARBINARY == destSSType || SSType.VARBINARYMAX == destSSType || SSType.IMAGE == destSSType) {
/*      */                   
/* 2264 */                   tdsWriter.writeNonUnicodeReader(reader, -1L, true, null);
/*      */                 } else {
/*      */                   
/* 2267 */                   SQLCollation destCollation = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(destColOrdinal))).collation;
/* 2268 */                   if (null != destCollation) {
/* 2269 */                     tdsWriter.writeNonUnicodeReader(reader, -1L, false, destCollation
/* 2270 */                         .getCharset());
/*      */                   } else {
/* 2272 */                     tdsWriter.writeNonUnicodeReader(reader, -1L, false, null);
/*      */                   } 
/*      */                 } 
/*      */ 
/*      */                 
/* 2277 */                 reader.close();
/* 2278 */               } catch (IOException e) {
/* 2279 */                 throw new SQLServerException(
/* 2280 */                     SQLServerException.getErrString("R_unableRetrieveSourceData"), e);
/*      */               }
/*      */             
/*      */             } 
/* 2284 */           } else if (null == colValue) {
/* 2285 */             writeNullToTdsWriter(tdsWriter, bulkJdbcType, isStreaming);
/*      */           } else {
/* 2287 */             String colValueStr = colValue.toString();
/* 2288 */             if (unicodeConversionRequired(bulkJdbcType, destSSType)) {
/* 2289 */               int stringLength = colValue.toString().length();
/* 2290 */               byte[] typevarlen = new byte[2];
/* 2291 */               typevarlen[0] = (byte)(2 * stringLength & 0xFF);
/* 2292 */               typevarlen[1] = (byte)(2 * stringLength >> 8 & 0xFF);
/* 2293 */               tdsWriter.writeBytes(typevarlen);
/* 2294 */               tdsWriter.writeString(colValue.toString());
/*      */             }
/* 2296 */             else if (SSType.BINARY == destSSType || SSType.VARBINARY == destSSType) {
/* 2297 */               byte[] bytes = null;
/*      */               try {
/* 2299 */                 bytes = ParameterUtils.HexToBin(colValueStr);
/* 2300 */               } catch (SQLServerException e) {
/* 2301 */                 throw new SQLServerException(
/* 2302 */                     SQLServerException.getErrString("R_unableRetrieveSourceData"), e);
/*      */               } 
/* 2304 */               tdsWriter.writeShort((short)bytes.length);
/* 2305 */               tdsWriter.writeBytes(bytes);
/*      */             } else {
/*      */               
/* 2308 */               SQLCollation destCollation = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(destColOrdinal))).collation;
/*      */               
/* 2310 */               if (null != destCollation) {
/* 2311 */                 byte[] value = colValueStr.getBytes(((BulkColumnMetaData)this.destColumnMetadata
/* 2312 */                     .get(Integer.valueOf(destColOrdinal))).collation.getCharset());
/* 2313 */                 tdsWriter.writeShort((short)value.length);
/* 2314 */                 tdsWriter.writeBytes(value);
/*      */               } else {
/* 2316 */                 tdsWriter.writeShort((short)colValueStr.length());
/* 2317 */                 tdsWriter.writeBytes(colValueStr.getBytes());
/*      */               } 
/*      */             } 
/*      */           } 
/*      */           return;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case -16:
/*      */         case -15:
/*      */         case -9:
/* 2334 */           if (isStreaming) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 2340 */             if (null == colValue) {
/* 2341 */               writeNullToTdsWriter(tdsWriter, bulkJdbcType, isStreaming);
/*      */             } else {
/*      */               
/* 2344 */               tdsWriter.writeLong(-2L);
/*      */               
/*      */               try {
/*      */                 Reader reader;
/* 2348 */                 if (colValue instanceof Reader) {
/* 2349 */                   reader = (Reader)colValue;
/*      */                 } else {
/* 2351 */                   reader = new StringReader(colValue.toString());
/*      */                 } 
/*      */ 
/*      */                 
/* 2355 */                 tdsWriter.writeReader(reader, -1L, true);
/* 2356 */                 reader.close();
/* 2357 */               } catch (IOException e) {
/* 2358 */                 throw new SQLServerException(
/* 2359 */                     SQLServerException.getErrString("R_unableRetrieveSourceData"), e);
/*      */               }
/*      */             
/*      */             } 
/* 2363 */           } else if (null == colValue) {
/* 2364 */             writeNullToTdsWriter(tdsWriter, bulkJdbcType, isStreaming);
/*      */           } else {
/* 2366 */             int stringLength = colValue.toString().length();
/* 2367 */             byte[] typevarlen = new byte[2];
/* 2368 */             typevarlen[0] = (byte)(2 * stringLength & 0xFF);
/* 2369 */             typevarlen[1] = (byte)(2 * stringLength >> 8 & 0xFF);
/* 2370 */             tdsWriter.writeBytes(typevarlen);
/* 2371 */             tdsWriter.writeString(colValue.toString());
/*      */           } 
/*      */           return;
/*      */ 
/*      */         
/*      */         case -4:
/*      */         case -3:
/*      */         case -2:
/* 2379 */           if (isStreaming) {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 2384 */             if (null == colValue) {
/* 2385 */               writeNullToTdsWriter(tdsWriter, bulkJdbcType, isStreaming);
/*      */             } else {
/*      */               
/* 2388 */               tdsWriter.writeLong(-2L);
/*      */               
/*      */               try {
/*      */                 InputStream iStream;
/* 2392 */                 if (colValue instanceof InputStream) {
/* 2393 */                   iStream = (InputStream)colValue;
/*      */                 }
/* 2395 */                 else if (colValue instanceof byte[]) {
/* 2396 */                   iStream = new ByteArrayInputStream((byte[])colValue);
/*      */                 } else {
/*      */                   
/* 2399 */                   iStream = new ByteArrayInputStream(ParameterUtils.HexToBin(colValue.toString()));
/*      */                 } 
/*      */                 
/* 2402 */                 tdsWriter.writeStream(iStream, -1L, true);
/* 2403 */                 iStream.close();
/* 2404 */               } catch (IOException e) {
/* 2405 */                 throw new SQLServerException(
/* 2406 */                     SQLServerException.getErrString("R_unableRetrieveSourceData"), e);
/*      */               }
/*      */             
/*      */             }
/*      */           
/* 2411 */           } else if (null == colValue) {
/* 2412 */             writeNullToTdsWriter(tdsWriter, bulkJdbcType, isStreaming);
/*      */           } else {
/*      */             byte[] srcBytes;
/* 2415 */             if (colValue instanceof byte[]) {
/* 2416 */               srcBytes = (byte[])colValue;
/*      */             } else {
/*      */               try {
/* 2419 */                 srcBytes = ParameterUtils.HexToBin(colValue.toString());
/* 2420 */               } catch (SQLServerException e) {
/* 2421 */                 throw new SQLServerException(
/* 2422 */                     SQLServerException.getErrString("R_unableRetrieveSourceData"), e);
/*      */               } 
/*      */             } 
/* 2425 */             tdsWriter.writeShort((short)srcBytes.length);
/* 2426 */             tdsWriter.writeBytes(srcBytes);
/*      */           } 
/*      */           return;
/*      */ 
/*      */         
/*      */         case -151:
/*      */         case -150:
/*      */         case 93:
/* 2434 */           if (null == colValue) {
/* 2435 */             writeNullToTdsWriter(tdsWriter, bulkJdbcType, isStreaming);
/*      */           } else {
/* 2437 */             switch (destSSType) {
/*      */               case DATE:
/* 2439 */                 if (bulkNullable)
/* 2440 */                   tdsWriter.writeByte((byte)4); 
/* 2441 */                 tdsWriter.writeSmalldatetime(colValue.toString());
/*      */                 return;
/*      */               case TIME:
/* 2444 */                 if (bulkNullable)
/* 2445 */                   tdsWriter.writeByte((byte)8); 
/* 2446 */                 tdsWriter.writeDatetime(colValue.toString());
/*      */                 return;
/*      */             } 
/* 2449 */             if (bulkNullable)
/* 2450 */               if (2 >= bulkScale) {
/* 2451 */                 tdsWriter.writeByte((byte)6);
/* 2452 */               } else if (4 >= bulkScale) {
/* 2453 */                 tdsWriter.writeByte((byte)7);
/*      */               } else {
/* 2455 */                 tdsWriter.writeByte((byte)8);
/*      */               }  
/* 2457 */             String timeStampValue = colValue.toString();
/* 2458 */             tdsWriter.writeTime(Timestamp.valueOf(timeStampValue), bulkScale);
/*      */             
/* 2460 */             tdsWriter.writeDate(timeStampValue.substring(0, timeStampValue.lastIndexOf(' ')));
/*      */           } 
/*      */           return;
/*      */ 
/*      */         
/*      */         case 91:
/* 2466 */           if (null == colValue) {
/* 2467 */             writeNullToTdsWriter(tdsWriter, bulkJdbcType, isStreaming);
/*      */           } else {
/* 2469 */             tdsWriter.writeByte((byte)3);
/* 2470 */             tdsWriter.writeDate(colValue.toString());
/*      */           } 
/*      */           return;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 92:
/* 2478 */           if (null == colValue) {
/* 2479 */             writeNullToTdsWriter(tdsWriter, bulkJdbcType, isStreaming);
/*      */           } else {
/* 2481 */             if (2 >= bulkScale) {
/* 2482 */               tdsWriter.writeByte((byte)3);
/* 2483 */             } else if (4 >= bulkScale) {
/* 2484 */               tdsWriter.writeByte((byte)4);
/*      */             } else {
/* 2486 */               tdsWriter.writeByte((byte)5);
/* 2487 */             }  if (colValue instanceof String) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 2496 */               Timestamp ts = new Timestamp(0L);
/* 2497 */               int nanos = 0;
/* 2498 */               int decimalIndex = ((String)colValue).indexOf('.');
/* 2499 */               if (decimalIndex != -1) {
/* 2500 */                 nanos = Integer.parseInt(((String)colValue).substring(decimalIndex + 1));
/* 2501 */                 colValue = ((String)colValue).substring(0, decimalIndex);
/*      */               } 
/* 2503 */               ts.setTime(Time.valueOf(colValue.toString()).getTime());
/* 2504 */               ts.setNanos(nanos);
/* 2505 */               tdsWriter.writeTime(ts, bulkScale);
/*      */             } else {
/* 2507 */               tdsWriter.writeTime((Timestamp)colValue, bulkScale);
/*      */             } 
/*      */           } 
/*      */           return;
/*      */         
/*      */         case 2013:
/* 2513 */           if (null == colValue) {
/* 2514 */             writeNullToTdsWriter(tdsWriter, bulkJdbcType, isStreaming);
/*      */           } else {
/* 2516 */             if (2 >= bulkScale) {
/* 2517 */               tdsWriter.writeByte((byte)8);
/* 2518 */             } else if (4 >= bulkScale) {
/* 2519 */               tdsWriter.writeByte((byte)9);
/*      */             } else {
/* 2521 */               tdsWriter.writeByte((byte)10);
/*      */             } 
/* 2523 */             tdsWriter.writeOffsetTimeWithTimezone((OffsetTime)colValue, bulkScale);
/*      */           } 
/*      */           return;
/*      */         
/*      */         case 2014:
/* 2528 */           if (null == colValue) {
/* 2529 */             writeNullToTdsWriter(tdsWriter, bulkJdbcType, isStreaming);
/*      */           } else {
/* 2531 */             if (2 >= bulkScale) {
/* 2532 */               tdsWriter.writeByte((byte)8);
/* 2533 */             } else if (4 >= bulkScale) {
/* 2534 */               tdsWriter.writeByte((byte)9);
/*      */             } else {
/* 2536 */               tdsWriter.writeByte((byte)10);
/*      */             } 
/* 2538 */             tdsWriter.writeOffsetDateTimeWithTimezone((OffsetDateTime)colValue, bulkScale);
/*      */           } 
/*      */           return;
/*      */ 
/*      */ 
/*      */         
/*      */         case -155:
/* 2545 */           if (null == colValue) {
/* 2546 */             writeNullToTdsWriter(tdsWriter, bulkJdbcType, isStreaming);
/*      */           } else {
/* 2548 */             if (2 >= bulkScale) {
/* 2549 */               tdsWriter.writeByte((byte)8);
/* 2550 */             } else if (4 >= bulkScale) {
/* 2551 */               tdsWriter.writeByte((byte)9);
/*      */             } else {
/* 2553 */               tdsWriter.writeByte((byte)10);
/*      */             } 
/* 2555 */             tdsWriter.writeDateTimeOffset(colValue, bulkScale, destSSType);
/*      */           } 
/*      */           return;
/*      */         case -156:
/* 2559 */           isShiloh = (8 >= this.connection.getServerMajorVersion());
/* 2560 */           if (isShiloh) {
/* 2561 */             MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_SQLVariantSupport"));
/* 2562 */             throw new SQLServerException(null, messageFormat.format(new Object[0]), null, 0, false);
/*      */           } 
/* 2564 */           writeSqlVariant(tdsWriter, colValue, this.sourceResultSet, srcColOrdinal, destColOrdinal, bulkJdbcType, bulkScale, isStreaming);
/*      */           return;
/*      */       } 
/*      */       
/* 2568 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_BulkTypeNotSupported"));
/* 2569 */       Object[] msgArgs = { JDBCType.of(bulkJdbcType).toString().toLowerCase(Locale.ENGLISH) };
/* 2570 */       SQLServerException.makeFromDriverError(null, null, form.format(msgArgs), null, true);
/*      */     
/*      */     }
/* 2573 */     catch (ClassCastException ex) {
/* 2574 */       byte[] srcBytes; if (null == colValue) {
/*      */ 
/*      */         
/* 2577 */         throwInvalidArgument("colValue");
/*      */       } else {
/* 2579 */         MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_errorConvertingValue"));
/* 2580 */         Object[] msgArgs = { colValue.getClass().getSimpleName(), JDBCType.of(bulkJdbcType) };
/* 2581 */         throw new SQLServerException(form.format(msgArgs), SQLState.DATA_EXCEPTION_NOT_SPECIFIC, DriverError.NOT_SET, srcBytes);
/*      */       } 
/*      */     } 
/*      */   } private void writeSqlVariant(TDSWriter tdsWriter, Object colValue, ResultSet sourceResultSet, int srcColOrdinal, int destColOrdinal, int bulkJdbcType, int bulkScale, boolean isStreaming) throws SQLServerException {
/*      */     byte[] srcBytes;
/*      */     int timeBulkScale, timeHeaderLength;
/*      */     String timeStampValue;
/*      */     int length;
/*      */     SQLCollation destCollation;
/*      */     int stringLength;
/*      */     byte[] typevarlen;
/*      */     SQLCollation collation;
/*      */     byte[] b;
/* 2594 */     if (null == colValue) {
/* 2595 */       writeNullToTdsWriter(tdsWriter, bulkJdbcType, isStreaming);
/*      */       return;
/*      */     } 
/* 2598 */     SqlVariant variantType = ((SQLServerResultSet)sourceResultSet).getVariantInternalType(srcColOrdinal);
/* 2599 */     int baseType = variantType.getBaseType();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2604 */     if (TDSType.TIMEN == TDSType.valueOf(baseType)) {
/* 2605 */       variantType.setIsBaseTypeTimeValue(true);
/* 2606 */       ((SQLServerResultSet)sourceResultSet).setInternalVariantType(srcColOrdinal, variantType);
/* 2607 */       colValue = ((SQLServerResultSet)sourceResultSet).getObject(srcColOrdinal);
/*      */     } 
/* 2609 */     switch (TDSType.valueOf(baseType)) {
/*      */       case DATE:
/* 2611 */         writeBulkCopySqlVariantHeader(10, TDSType.INT8.byteValue(), (byte)0, tdsWriter);
/* 2612 */         tdsWriter.writeLong(Long.valueOf(colValue.toString()).longValue());
/*      */         return;
/*      */       
/*      */       case TIME:
/* 2616 */         writeBulkCopySqlVariantHeader(6, TDSType.INT4.byteValue(), (byte)0, tdsWriter);
/* 2617 */         tdsWriter.writeInt(Integer.valueOf(colValue.toString()).intValue());
/*      */         return;
/*      */       
/*      */       case TIMESTAMP:
/* 2621 */         writeBulkCopySqlVariantHeader(4, TDSType.INT2.byteValue(), (byte)0, tdsWriter);
/* 2622 */         tdsWriter.writeShort(Short.valueOf(colValue.toString()).shortValue());
/*      */         return;
/*      */       
/*      */       case DATETIME:
/* 2626 */         writeBulkCopySqlVariantHeader(3, TDSType.INT1.byteValue(), (byte)0, tdsWriter);
/* 2627 */         tdsWriter.writeByte(Byte.valueOf(colValue.toString()).byteValue());
/*      */         return;
/*      */       
/*      */       case SMALLDATETIME:
/* 2631 */         writeBulkCopySqlVariantHeader(10, TDSType.FLOAT8.byteValue(), (byte)0, tdsWriter);
/* 2632 */         tdsWriter.writeDouble(Double.valueOf(colValue.toString()).doubleValue());
/*      */         return;
/*      */       
/*      */       case DATETIMEOFFSET:
/* 2636 */         writeBulkCopySqlVariantHeader(6, TDSType.FLOAT4.byteValue(), (byte)0, tdsWriter);
/* 2637 */         tdsWriter.writeReal(Float.valueOf(colValue.toString()).floatValue());
/*      */         return;
/*      */ 
/*      */ 
/*      */       
/*      */       case BIT:
/* 2643 */         writeBulkCopySqlVariantHeader(21, TDSType.DECIMALN.byteValue(), (byte)2, tdsWriter);
/* 2644 */         tdsWriter.writeByte((byte)38);
/* 2645 */         tdsWriter.writeByte((byte)4);
/* 2646 */         tdsWriter.writeSqlVariantInternalBigDecimal((BigDecimal)colValue, bulkJdbcType);
/*      */         return;
/*      */       
/*      */       case TINYINT:
/* 2650 */         writeBulkCopySqlVariantHeader(21, TDSType.DECIMALN.byteValue(), (byte)2, tdsWriter);
/* 2651 */         tdsWriter.writeByte((byte)38);
/* 2652 */         tdsWriter.writeByte((byte)4);
/* 2653 */         tdsWriter.writeSqlVariantInternalBigDecimal((BigDecimal)colValue, bulkJdbcType);
/*      */         return;
/*      */       
/*      */       case SMALLINT:
/* 2657 */         writeBulkCopySqlVariantHeader(3, TDSType.BIT1.byteValue(), (byte)0, tdsWriter);
/* 2658 */         tdsWriter.writeByte((byte)(((Boolean)colValue).booleanValue() ? 1 : 0));
/*      */         return;
/*      */       
/*      */       case INTEGER:
/* 2662 */         writeBulkCopySqlVariantHeader(5, TDSType.DATEN.byteValue(), (byte)0, tdsWriter);
/* 2663 */         tdsWriter.writeDate(colValue.toString());
/*      */         return;
/*      */       
/*      */       case BIGINT:
/* 2667 */         timeBulkScale = variantType.getScale();
/* 2668 */         timeHeaderLength = 8;
/* 2669 */         if (2 >= timeBulkScale) {
/* 2670 */           timeHeaderLength = 6;
/* 2671 */         } else if (4 >= timeBulkScale) {
/* 2672 */           timeHeaderLength = 7;
/*      */         } else {
/* 2674 */           timeHeaderLength = 8;
/*      */         } 
/* 2676 */         writeBulkCopySqlVariantHeader(timeHeaderLength, TDSType.TIMEN.byteValue(), (byte)1, tdsWriter);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2683 */         tdsWriter.writeByte((byte)timeBulkScale);
/* 2684 */         tdsWriter.writeTime((Timestamp)colValue, timeBulkScale);
/*      */         return;
/*      */       
/*      */       case BINARY:
/* 2688 */         writeBulkCopySqlVariantHeader(10, TDSType.DATETIME8.byteValue(), (byte)0, tdsWriter);
/* 2689 */         tdsWriter.writeDatetime(colValue.toString());
/*      */         return;
/*      */ 
/*      */       
/*      */       case VARBINARY:
/* 2694 */         writeBulkCopySqlVariantHeader(10, TDSType.DATETIME8.byteValue(), (byte)0, tdsWriter);
/* 2695 */         tdsWriter.writeDatetime(colValue.toString());
/*      */         return;
/*      */       
/*      */       case LONGVARBINARY:
/* 2699 */         writeBulkCopySqlVariantHeader(10, TDSType.DATETIME2N.byteValue(), (byte)1, tdsWriter);
/*      */ 
/*      */         
/* 2702 */         tdsWriter.writeByte((byte)3);
/* 2703 */         timeStampValue = colValue.toString();
/* 2704 */         tdsWriter.writeTime(Timestamp.valueOf(timeStampValue), 3);
/*      */ 
/*      */         
/* 2707 */         tdsWriter.writeDate(timeStampValue.substring(0, timeStampValue.lastIndexOf(' ')));
/*      */         return;
/*      */       
/*      */       case GUID:
/* 2711 */         length = colValue.toString().length();
/* 2712 */         writeBulkCopySqlVariantHeader(9 + length, TDSType.BIGCHAR.byteValue(), (byte)7, tdsWriter);
/* 2713 */         tdsWriter.writeCollationForSqlVariant(variantType);
/* 2714 */         tdsWriter.writeShort((short)length);
/* 2715 */         destCollation = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(destColOrdinal))).collation;
/* 2716 */         if (null != destCollation) {
/* 2717 */           tdsWriter.writeBytes(colValue.toString()
/* 2718 */               .getBytes(((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(destColOrdinal))).collation.getCharset()));
/*      */         } else {
/* 2720 */           tdsWriter.writeBytes(colValue.toString().getBytes());
/*      */         } 
/*      */         return;
/*      */       
/*      */       case CHAR:
/* 2725 */         length = colValue.toString().length();
/* 2726 */         writeBulkCopySqlVariantHeader(9 + length, TDSType.BIGVARCHAR.byteValue(), (byte)7, tdsWriter);
/* 2727 */         tdsWriter.writeCollationForSqlVariant(variantType);
/* 2728 */         tdsWriter.writeShort((short)length);
/*      */         
/* 2730 */         destCollation = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(destColOrdinal))).collation;
/* 2731 */         if (null != destCollation) {
/* 2732 */           tdsWriter.writeBytes(colValue.toString()
/* 2733 */               .getBytes(((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(destColOrdinal))).collation.getCharset()));
/*      */         } else {
/* 2735 */           tdsWriter.writeBytes(colValue.toString().getBytes());
/*      */         } 
/*      */         return;
/*      */       
/*      */       case VARCHAR:
/* 2740 */         length = colValue.toString().length() * 2;
/* 2741 */         writeBulkCopySqlVariantHeader(9 + length, TDSType.NCHAR.byteValue(), (byte)7, tdsWriter);
/* 2742 */         tdsWriter.writeCollationForSqlVariant(variantType);
/* 2743 */         stringLength = colValue.toString().length();
/* 2744 */         typevarlen = new byte[2];
/* 2745 */         typevarlen[0] = (byte)(2 * stringLength & 0xFF);
/* 2746 */         typevarlen[1] = (byte)(2 * stringLength >> 8 & 0xFF);
/* 2747 */         tdsWriter.writeBytes(typevarlen);
/* 2748 */         tdsWriter.writeString(colValue.toString());
/*      */         return;
/*      */       
/*      */       case LONGVARCHAR:
/* 2752 */         length = colValue.toString().length() * 2;
/* 2753 */         writeBulkCopySqlVariantHeader(9 + length, TDSType.NVARCHAR.byteValue(), (byte)7, tdsWriter);
/* 2754 */         tdsWriter.writeCollationForSqlVariant(variantType);
/* 2755 */         stringLength = colValue.toString().length();
/* 2756 */         typevarlen = new byte[2];
/* 2757 */         typevarlen[0] = (byte)(2 * stringLength & 0xFF);
/* 2758 */         typevarlen[1] = (byte)(2 * stringLength >> 8 & 0xFF);
/* 2759 */         tdsWriter.writeBytes(typevarlen);
/* 2760 */         tdsWriter.writeString(colValue.toString());
/*      */         return;
/*      */       
/*      */       case NCHAR:
/* 2764 */         length = colValue.toString().length();
/* 2765 */         writeBulkCopySqlVariantHeader(9 + length, TDSType.BIGCHAR.byteValue(), (byte)7, tdsWriter);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2770 */         collation = (null != ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(srcColOrdinal))).collation) ? ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(srcColOrdinal))).collation : this.connection.getDatabaseCollation();
/* 2771 */         variantType.setCollation(collation);
/* 2772 */         tdsWriter.writeCollationForSqlVariant(variantType);
/* 2773 */         tdsWriter.writeShort((short)length);
/*      */         
/* 2775 */         destCollation = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(destColOrdinal))).collation;
/* 2776 */         if (null != destCollation) {
/* 2777 */           tdsWriter.writeBytes(colValue.toString()
/* 2778 */               .getBytes(((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(destColOrdinal))).collation.getCharset()));
/*      */         } else {
/* 2780 */           tdsWriter.writeBytes(colValue.toString().getBytes());
/*      */         } 
/*      */         return;
/*      */       
/*      */       case NVARCHAR:
/* 2785 */         b = (byte[])colValue;
/* 2786 */         length = b.length;
/* 2787 */         writeBulkCopySqlVariantHeader(4 + length, TDSType.BIGVARBINARY.byteValue(), (byte)2, tdsWriter);
/* 2788 */         tdsWriter.writeShort((short)variantType.getMaxLength());
/* 2789 */         if (colValue instanceof byte[]) {
/* 2790 */           srcBytes = (byte[])colValue;
/*      */         } else {
/*      */           try {
/* 2793 */             srcBytes = ParameterUtils.HexToBin(colValue.toString());
/* 2794 */           } catch (SQLServerException e) {
/* 2795 */             throw new SQLServerException(SQLServerException.getErrString("R_unableRetrieveSourceData"), e);
/*      */           } 
/*      */         } 
/* 2798 */         tdsWriter.writeBytes(srcBytes);
/*      */         return;
/*      */       
/*      */       case LONGNVARCHAR:
/* 2802 */         b = (byte[])colValue;
/* 2803 */         length = b.length;
/* 2804 */         writeBulkCopySqlVariantHeader(4 + length, TDSType.BIGVARBINARY.byteValue(), (byte)2, tdsWriter);
/* 2805 */         tdsWriter.writeShort((short)variantType.getMaxLength());
/* 2806 */         if (colValue instanceof byte[]) {
/* 2807 */           srcBytes = (byte[])colValue;
/*      */         } else {
/*      */           try {
/* 2810 */             srcBytes = ParameterUtils.HexToBin(colValue.toString());
/* 2811 */           } catch (SQLServerException e) {
/* 2812 */             throw new SQLServerException(SQLServerException.getErrString("R_unableRetrieveSourceData"), e);
/*      */           } 
/*      */         } 
/* 2815 */         tdsWriter.writeBytes(srcBytes);
/*      */         return;
/*      */     } 
/*      */     
/* 2819 */     MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_BulkTypeNotSupported"));
/* 2820 */     Object[] msgArgs = { JDBCType.of(bulkJdbcType).toString().toLowerCase(Locale.ENGLISH) };
/* 2821 */     SQLServerException.makeFromDriverError(null, null, form.format(msgArgs), null, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeBulkCopySqlVariantHeader(int length, byte tdsType, byte probBytes, TDSWriter tdsWriter) throws SQLServerException {
/* 2838 */     tdsWriter.writeInt(length);
/* 2839 */     tdsWriter.writeByte(tdsType);
/* 2840 */     tdsWriter.writeByte(probBytes);
/*      */   }
/*      */ 
/*      */   
/*      */   private Object readColumnFromResultSet(int srcColOrdinal, int srcJdbcType, boolean isStreaming, boolean isDestEncrypted) throws SQLServerException {
/* 2845 */     CryptoMetadata srcCryptoMeta = null;
/*      */ 
/*      */     
/* 2848 */     if (this.sourceResultSet instanceof SQLServerResultSet && null != (
/*      */       
/* 2850 */       srcCryptoMeta = ((SQLServerResultSet)this.sourceResultSet).getterGetColumn(srcColOrdinal).getCryptoMetadata())) {
/* 2851 */       srcJdbcType = srcCryptoMeta.baseTypeInfo.getSSType().getJDBCType().asJavaSqlType();
/* 2852 */       BulkColumnMetaData temp = this.srcColumnMetadata.get(Integer.valueOf(srcColOrdinal));
/* 2853 */       this.srcColumnMetadata.put(Integer.valueOf(srcColOrdinal), new BulkColumnMetaData(temp, srcCryptoMeta));
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 2859 */       switch (srcJdbcType) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case -7:
/*      */         case -6:
/*      */         case -5:
/*      */         case 4:
/*      */         case 5:
/*      */         case 6:
/*      */         case 7:
/*      */         case 8:
/* 2872 */           return this.sourceResultSet.getObject(srcColOrdinal);
/*      */         
/*      */         case -148:
/*      */         case -146:
/*      */         case 2:
/*      */         case 3:
/* 2878 */           return this.sourceResultSet.getBigDecimal(srcColOrdinal);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case -145:
/*      */         case -1:
/*      */         case 1:
/*      */         case 12:
/* 2888 */           if (isStreaming && !isDestEncrypted && null == srcCryptoMeta)
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 2894 */             return this.sourceResultSet.getCharacterStream(srcColOrdinal);
/*      */           }
/*      */           
/* 2897 */           return this.sourceResultSet.getString(srcColOrdinal);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case -16:
/*      */         case -15:
/*      */         case -9:
/* 2906 */           if (isStreaming && !isDestEncrypted && null == srcCryptoMeta)
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 2912 */             return this.sourceResultSet.getNCharacterStream(srcColOrdinal);
/*      */           }
/* 2914 */           return this.sourceResultSet.getObject(srcColOrdinal);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case -4:
/*      */         case -3:
/*      */         case -2:
/* 2923 */           if (isStreaming && !isDestEncrypted && null == srcCryptoMeta)
/*      */           {
/* 2925 */             return this.sourceResultSet.getBinaryStream(srcColOrdinal);
/*      */           }
/*      */           
/* 2928 */           return this.sourceResultSet.getBytes(srcColOrdinal);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case -151:
/*      */         case -150:
/*      */         case 92:
/*      */         case 93:
/* 2938 */           return this.sourceResultSet.getTimestamp(srcColOrdinal);
/*      */         
/*      */         case 91:
/* 2941 */           return this.sourceResultSet.getDate(srcColOrdinal);
/*      */         
/*      */         case -155:
/* 2944 */           return this.sourceResultSet.getObject(srcColOrdinal, DateTimeOffset.class);
/*      */         
/*      */         case -156:
/* 2947 */           return this.sourceResultSet.getObject(srcColOrdinal);
/*      */       } 
/* 2949 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_BulkTypeNotSupported"));
/* 2950 */       Object[] msgArgs = { JDBCType.of(srcJdbcType).toString().toLowerCase(Locale.ENGLISH) };
/* 2951 */       SQLServerException.makeFromDriverError(null, null, form.format(msgArgs), null, true);
/*      */       
/* 2953 */       return null;
/*      */     }
/* 2955 */     catch (SQLException e) {
/* 2956 */       throw new SQLServerException(SQLServerException.getErrString("R_unableRetrieveSourceData"), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeColumn(TDSWriter tdsWriter, int srcColOrdinal, int destColOrdinal, Object colValue) throws SQLServerException {
/*      */     boolean isStreaming;
/* 2966 */     SSType destSSType = null;
/*      */     
/* 2968 */     int srcPrecision = ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(srcColOrdinal))).precision;
/* 2969 */     int srcScale = ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(srcColOrdinal))).scale;
/* 2970 */     int srcJdbcType = ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(srcColOrdinal))).jdbcType;
/* 2971 */     boolean srcNullable = ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(srcColOrdinal))).isNullable;
/*      */     
/* 2973 */     int destPrecision = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(destColOrdinal))).precision;
/*      */     
/* 2975 */     if (-15 == srcJdbcType || -9 == srcJdbcType || -16 == srcJdbcType) {
/*      */       
/* 2977 */       isStreaming = (4000 < srcPrecision || 4000 < destPrecision);
/*      */     } else {
/*      */       
/* 2980 */       isStreaming = (8000 < srcPrecision || 8000 < destPrecision);
/*      */     } 
/*      */ 
/*      */     
/* 2984 */     CryptoMetadata destCryptoMeta = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(destColOrdinal))).cryptoMeta;
/* 2985 */     if (null != destCryptoMeta) {
/* 2986 */       destSSType = destCryptoMeta.baseTypeInfo.getSSType();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 2991 */     if (null != this.sourceResultSet) {
/* 2992 */       colValue = readColumnFromResultSet(srcColOrdinal, srcJdbcType, isStreaming, (null != destCryptoMeta));
/* 2993 */       validateStringBinaryLengths(colValue, srcColOrdinal, destColOrdinal);
/*      */ 
/*      */ 
/*      */       
/* 2997 */       if (!this.copyOptions.isAllowEncryptedValueModifications() && (null == destCryptoMeta || null == colValue))
/*      */       {
/*      */         
/* 3000 */         validateDataTypeConversions(srcColOrdinal, destColOrdinal);
/*      */       
/*      */       }
/*      */     
/*      */     }
/* 3005 */     else if (null != this.serverBulkData && null == destCryptoMeta) {
/* 3006 */       validateStringBinaryLengths(colValue, srcColOrdinal, destColOrdinal);
/* 3007 */     } else if (null != this.serverBulkData && null != destCryptoMeta) {
/*      */       
/* 3009 */       if (91 == srcJdbcType || 92 == srcJdbcType || 93 == srcJdbcType || -155 == srcJdbcType || 2013 == srcJdbcType || 2014 == srcJdbcType) {
/*      */ 
/*      */         
/* 3012 */         colValue = getTemporalObjectFromCSV(colValue, srcJdbcType, srcColOrdinal);
/* 3013 */       } else if (2 == srcJdbcType || 3 == srcJdbcType) {
/* 3014 */         int baseDestPrecision = destCryptoMeta.baseTypeInfo.getPrecision();
/* 3015 */         int baseDestScale = destCryptoMeta.baseTypeInfo.getScale();
/* 3016 */         if (srcScale != baseDestScale || srcPrecision != baseDestPrecision) {
/* 3017 */           MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_InvalidDataForAE"));
/* 3018 */           String src = "" + JDBCType.of(srcJdbcType) + "(" + JDBCType.of(srcJdbcType) + "," + srcPrecision + ")";
/* 3019 */           String dest = "" + destSSType + "(" + destSSType + "," + baseDestPrecision + ")";
/* 3020 */           Object[] msgArgs = { src, dest };
/* 3021 */           throw new SQLServerException(this, form.format(msgArgs), null, 0, false);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 3026 */     CryptoMetadata srcCryptoMeta = ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(srcColOrdinal))).cryptoMeta;
/*      */     
/* 3028 */     if (null != destCryptoMeta && null != colValue) {
/*      */       
/* 3030 */       JDBCType baseSrcJdbcType = (null != srcCryptoMeta) ? ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(srcColOrdinal))).cryptoMeta.baseTypeInfo.getSSType().getJDBCType() : JDBCType.of(srcJdbcType);
/*      */       
/* 3032 */       if (JDBCType.TIMESTAMP == baseSrcJdbcType) {
/* 3033 */         if (SSType.DATETIME == destSSType) {
/* 3034 */           baseSrcJdbcType = JDBCType.DATETIME;
/* 3035 */         } else if (SSType.SMALLDATETIME == destSSType) {
/* 3036 */           baseSrcJdbcType = JDBCType.SMALLDATETIME;
/*      */         } 
/*      */       }
/*      */       
/* 3040 */       if ((SSType.MONEY != destSSType || JDBCType.DECIMAL != baseSrcJdbcType) && (SSType.SMALLMONEY != destSSType || JDBCType.DECIMAL != baseSrcJdbcType) && (SSType.GUID != destSSType || JDBCType.CHAR != baseSrcJdbcType))
/*      */       {
/*      */ 
/*      */         
/* 3044 */         if ((!Util.isCharType(destSSType).booleanValue() || !Util.isCharType(srcJdbcType)) && !(this.sourceResultSet instanceof SQLServerResultSet))
/*      */         {
/*      */           
/* 3047 */           if (!baseSrcJdbcType.normalizationCheck(destSSType)) {
/*      */             
/* 3049 */             MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_unsupportedConversionAE"));
/* 3050 */             Object[] msgArgs = { baseSrcJdbcType, destSSType };
/* 3051 */             throw new SQLServerException(this, form.format(msgArgs), null, 0, false);
/*      */           } 
/*      */         }
/*      */       }
/* 3055 */       if (baseSrcJdbcType == JDBCType.DATE || baseSrcJdbcType == JDBCType.TIMESTAMP || baseSrcJdbcType == JDBCType.TIME || baseSrcJdbcType == JDBCType.DATETIMEOFFSET || baseSrcJdbcType == JDBCType.DATETIME || baseSrcJdbcType == JDBCType.SMALLDATETIME) {
/*      */ 
/*      */         
/* 3058 */         colValue = getEncryptedTemporalBytes(tdsWriter, baseSrcJdbcType, colValue, srcColOrdinal, destCryptoMeta.baseTypeInfo
/* 3059 */             .getScale());
/*      */       } else {
/* 3061 */         TypeInfo destTypeInfo = destCryptoMeta.getBaseTypeInfo();
/* 3062 */         JDBCType destJdbcType = destTypeInfo.getSSType().getJDBCType();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3071 */         if (!Util.isBinaryType(destJdbcType.getIntValue()).booleanValue() && colValue instanceof byte[]) {
/*      */           
/* 3073 */           MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_InvalidDataForAE"));
/* 3074 */           Object[] msgArgs = { baseSrcJdbcType, destJdbcType };
/* 3075 */           throw new SQLServerException(this, form.format(msgArgs), null, 0, false);
/*      */         } 
/*      */         
/* 3078 */         colValue = SQLServerSecurityUtility.encryptWithKey(normalizedValue(destJdbcType, colValue, baseSrcJdbcType, destTypeInfo
/* 3079 */               .getPrecision(), destTypeInfo.getScale()), destCryptoMeta, this.connection);
/*      */       } 
/*      */     } 
/*      */     
/* 3083 */     writeColumnToTdsWriter(tdsWriter, srcPrecision, srcScale, srcJdbcType, srcNullable, srcColOrdinal, destColOrdinal, isStreaming, colValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object getTemporalObjectFromCSVWithFormatter(String valueStrUntrimmed, int srcJdbcType, int srcColOrdinal, DateTimeFormatter dateTimeFormatter) throws SQLServerException {
/*      */     try {
/* 3106 */       TemporalAccessor ta = dateTimeFormatter.parse(valueStrUntrimmed);
/*      */ 
/*      */       
/* 3109 */       int taOffsetSec = 0, taNano = taOffsetSec, taDay = taNano, taMonth = taDay, taYear = taMonth, taSec = taYear, taMin = taSec, taHour = taMin;
/* 3110 */       if (ta.isSupported(ChronoField.NANO_OF_SECOND))
/* 3111 */         taNano = ta.get(ChronoField.NANO_OF_SECOND); 
/* 3112 */       if (ta.isSupported(ChronoField.OFFSET_SECONDS))
/* 3113 */         taOffsetSec = ta.get(ChronoField.OFFSET_SECONDS); 
/* 3114 */       if (ta.isSupported(ChronoField.HOUR_OF_DAY))
/* 3115 */         taHour = ta.get(ChronoField.HOUR_OF_DAY); 
/* 3116 */       if (ta.isSupported(ChronoField.MINUTE_OF_HOUR))
/* 3117 */         taMin = ta.get(ChronoField.MINUTE_OF_HOUR); 
/* 3118 */       if (ta.isSupported(ChronoField.SECOND_OF_MINUTE))
/* 3119 */         taSec = ta.get(ChronoField.SECOND_OF_MINUTE); 
/* 3120 */       if (ta.isSupported(ChronoField.DAY_OF_MONTH))
/* 3121 */         taDay = ta.get(ChronoField.DAY_OF_MONTH); 
/* 3122 */       if (ta.isSupported(ChronoField.MONTH_OF_YEAR))
/* 3123 */         taMonth = ta.get(ChronoField.MONTH_OF_YEAR); 
/* 3124 */       if (ta.isSupported(ChronoField.YEAR)) {
/* 3125 */         taYear = ta.get(ChronoField.YEAR);
/*      */       }
/* 3127 */       Calendar cal = new GregorianCalendar(new SimpleTimeZone(taOffsetSec * 1000, ""));
/* 3128 */       cal.clear();
/* 3129 */       cal.set(11, taHour);
/* 3130 */       cal.set(12, taMin);
/* 3131 */       cal.set(13, taSec);
/* 3132 */       cal.set(5, taDay);
/* 3133 */       cal.set(2, taMonth - 1);
/* 3134 */       cal.set(1, taYear);
/* 3135 */       int fractionalSecondsLength = Integer.toString(taNano).length();
/* 3136 */       for (int i = 0; i < 9 - fractionalSecondsLength; i++)
/* 3137 */         taNano *= 10; 
/* 3138 */       Timestamp ts = new Timestamp(cal.getTimeInMillis());
/* 3139 */       ts.setNanos(taNano);
/*      */       
/* 3141 */       switch (srcJdbcType) {
/*      */         case 93:
/* 3143 */           return ts;
/*      */         
/*      */         case 92:
/* 3146 */           cal.set(this.connection.baseYear(), 0, 1);
/* 3147 */           ts = new Timestamp(cal.getTimeInMillis());
/* 3148 */           ts.setNanos(taNano);
/* 3149 */           return new Timestamp(ts.getTime());
/*      */         case 91:
/* 3151 */           return new Date(ts.getTime());
/*      */         case -155:
/* 3153 */           return DateTimeOffset.valueOf(ts, taOffsetSec / 60);
/*      */       } 
/* 3155 */       return valueStrUntrimmed;
/*      */     }
/* 3157 */     catch (DateTimeException|ArithmeticException e) {
/* 3158 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_ParsingError"));
/* 3159 */       Object[] msgArgs = { JDBCType.of(srcJdbcType) };
/* 3160 */       throw new SQLServerException(this, form.format(msgArgs), null, 0, false);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Object getTemporalObjectFromCSV(Object value, int srcJdbcType, int srcColOrdinal) throws SQLServerException {
/* 3167 */     if (2013 == srcJdbcType) {
/* 3168 */       MessageFormat form1 = new MessageFormat(SQLServerException.getErrString("R_UnsupportedDataTypeAE"));
/* 3169 */       Object[] msgArgs1 = { "TIME_WITH_TIMEZONE" };
/* 3170 */       throw new SQLServerException(this, form1.format(msgArgs1), null, 0, false);
/* 3171 */     }  if (2014 == srcJdbcType) {
/* 3172 */       MessageFormat form2 = new MessageFormat(SQLServerException.getErrString("R_UnsupportedDataTypeAE"));
/* 3173 */       Object[] msgArgs2 = { "TIMESTAMP_WITH_TIMEZONE" };
/* 3174 */       throw new SQLServerException(this, form2.format(msgArgs2), null, 0, false);
/*      */     } 
/*      */     
/* 3177 */     String valueStr = null;
/* 3178 */     String valueStrUntrimmed = null;
/*      */     
/* 3180 */     if (null != value && value instanceof String) {
/* 3181 */       valueStrUntrimmed = (String)value;
/* 3182 */       valueStr = valueStrUntrimmed.trim();
/*      */     } 
/*      */ 
/*      */     
/* 3186 */     if (null == valueStr) {
/* 3187 */       switch (srcJdbcType) {
/*      */         case -155:
/*      */         case 91:
/*      */         case 92:
/*      */         case 93:
/* 3192 */           return null;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 3202 */     DateTimeFormatter dateTimeFormatter = ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(srcColOrdinal))).dateTimeFormatter;
/* 3203 */     if (null != dateTimeFormatter)
/* 3204 */       return getTemporalObjectFromCSVWithFormatter(valueStrUntrimmed, srcJdbcType, srcColOrdinal, dateTimeFormatter);  try {
/*      */       Calendar cal; String time; int endIndx; Timestamp ts; int year; int startIndx; int month; int day; int hour; int minute; int seconds; int totalOffset; int fractionalSeconds; boolean isNegativeOffset;
/*      */       boolean hasTimeZone;
/*      */       int fractionalSecondsLength;
/*      */       int i;
/*      */       Timestamp timestamp1;
/* 3210 */       switch (srcJdbcType) {
/*      */         
/*      */         case 93:
/* 3213 */           return Timestamp.valueOf(valueStr);
/*      */         
/*      */         case 92:
/* 3216 */           time = "" + this.connection.baseYear() + "-01-01 " + this.connection.baseYear();
/* 3217 */           ts = Timestamp.valueOf(time);
/* 3218 */           return ts;
/*      */         
/*      */         case 91:
/* 3221 */           return Date.valueOf(valueStr);
/*      */         
/*      */         case -155:
/* 3224 */           endIndx = valueStr.indexOf('-', 0);
/* 3225 */           year = Integer.parseInt(valueStr.substring(0, endIndx));
/*      */           
/* 3227 */           startIndx = ++endIndx;
/* 3228 */           endIndx = valueStr.indexOf('-', startIndx);
/* 3229 */           month = Integer.parseInt(valueStr.substring(startIndx, endIndx));
/*      */           
/* 3231 */           startIndx = ++endIndx;
/* 3232 */           endIndx = valueStr.indexOf(' ', startIndx);
/* 3233 */           day = Integer.parseInt(valueStr.substring(startIndx, endIndx));
/*      */           
/* 3235 */           startIndx = ++endIndx;
/* 3236 */           endIndx = valueStr.indexOf(':', startIndx);
/* 3237 */           hour = Integer.parseInt(valueStr.substring(startIndx, endIndx));
/*      */           
/* 3239 */           startIndx = ++endIndx;
/* 3240 */           endIndx = valueStr.indexOf(':', startIndx);
/* 3241 */           minute = Integer.parseInt(valueStr.substring(startIndx, endIndx));
/*      */           
/* 3243 */           startIndx = ++endIndx;
/* 3244 */           endIndx = valueStr.indexOf('.', startIndx);
/* 3245 */           totalOffset = 0; fractionalSeconds = 0;
/* 3246 */           isNegativeOffset = false;
/* 3247 */           hasTimeZone = false;
/* 3248 */           fractionalSecondsLength = 0;
/* 3249 */           if (-1 != endIndx) {
/*      */             
/* 3251 */             seconds = Integer.parseInt(valueStr.substring(startIndx, endIndx));
/*      */             
/* 3253 */             startIndx = ++endIndx;
/* 3254 */             endIndx = valueStr.indexOf(' ', startIndx);
/* 3255 */             if (-1 != endIndx) {
/*      */               
/* 3257 */               fractionalSeconds = Integer.parseInt(valueStr.substring(startIndx, endIndx));
/* 3258 */               fractionalSecondsLength = endIndx - startIndx;
/* 3259 */               hasTimeZone = true;
/*      */             } else {
/*      */               
/* 3262 */               fractionalSeconds = Integer.parseInt(valueStr.substring(startIndx));
/* 3263 */               fractionalSecondsLength = valueStr.length() - startIndx;
/*      */             } 
/*      */           } else {
/* 3266 */             endIndx = valueStr.indexOf(' ', startIndx);
/* 3267 */             if (-1 != endIndx) {
/* 3268 */               hasTimeZone = true;
/* 3269 */               seconds = Integer.parseInt(valueStr.substring(startIndx, endIndx));
/*      */             } else {
/* 3271 */               seconds = Integer.parseInt(valueStr.substring(startIndx));
/* 3272 */               endIndx++;
/*      */             } 
/*      */           } 
/* 3275 */           if (hasTimeZone) {
/* 3276 */             startIndx = ++endIndx;
/* 3277 */             if ('+' == valueStr.charAt(startIndx)) {
/* 3278 */               startIndx++;
/* 3279 */             } else if ('-' == valueStr.charAt(startIndx)) {
/* 3280 */               isNegativeOffset = true;
/* 3281 */               startIndx++;
/*      */             } 
/* 3283 */             endIndx = valueStr.indexOf(':', startIndx);
/*      */             
/* 3285 */             int offsethour = Integer.parseInt(valueStr.substring(startIndx, endIndx));
/* 3286 */             startIndx = ++endIndx;
/* 3287 */             int offsetMinute = Integer.parseInt(valueStr.substring(startIndx));
/* 3288 */             totalOffset = offsethour * 60 + offsetMinute;
/* 3289 */             if (isNegativeOffset)
/* 3290 */               totalOffset = -totalOffset; 
/*      */           } 
/* 3292 */           cal = new GregorianCalendar(new SimpleTimeZone(totalOffset * 60 * 1000, ""), Locale.US);
/* 3293 */           cal.clear();
/* 3294 */           cal.set(11, hour);
/* 3295 */           cal.set(12, minute);
/* 3296 */           cal.set(13, seconds);
/* 3297 */           cal.set(5, day);
/* 3298 */           cal.set(2, month - 1);
/* 3299 */           cal.set(1, year);
/* 3300 */           for (i = 0; i < 9 - fractionalSecondsLength; i++) {
/* 3301 */             fractionalSeconds *= 10;
/*      */           }
/* 3303 */           timestamp1 = new Timestamp(cal.getTimeInMillis());
/* 3304 */           timestamp1.setNanos(fractionalSeconds);
/* 3305 */           return DateTimeOffset.valueOf(timestamp1, totalOffset);
/*      */       } 
/*      */ 
/*      */     
/* 3309 */     } catch (IndexOutOfBoundsException e) {
/* 3310 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_ParsingError"));
/* 3311 */       Object[] msgArgs = { JDBCType.of(srcJdbcType) };
/* 3312 */       throw new SQLServerException(this, form.format(msgArgs), null, 0, false);
/* 3313 */     } catch (NumberFormatException e) {
/* 3314 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_ParsingError"));
/* 3315 */       Object[] msgArgs = { JDBCType.of(srcJdbcType) };
/* 3316 */       throw new SQLServerException(this, form.format(msgArgs), null, 0, false);
/* 3317 */     } catch (IllegalArgumentException e) {
/* 3318 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_ParsingError"));
/* 3319 */       Object[] msgArgs = { JDBCType.of(srcJdbcType) };
/* 3320 */       throw new SQLServerException(this, form.format(msgArgs), null, 0, false);
/*      */     } 
/*      */     
/* 3323 */     return value;
/*      */   }
/*      */   private byte[] getEncryptedTemporalBytes(TDSWriter tdsWriter, JDBCType srcTemporalJdbcType, Object colValue, int srcColOrdinal, int scale) throws SQLServerException {
/*      */     long utcMillis;
/*      */     GregorianCalendar calendar;
/*      */     int subSecondNanos;
/*      */     DateTimeOffset dtoValue;
/*      */     int minutesOffset;
/* 3331 */     switch (srcTemporalJdbcType) {
/*      */       case DATE:
/* 3333 */         calendar = new GregorianCalendar(TimeZone.getDefault(), Locale.US);
/* 3334 */         calendar.setLenient(true);
/* 3335 */         calendar.clear();
/* 3336 */         calendar.setTimeInMillis(((Date)colValue).getTime());
/* 3337 */         return tdsWriter.writeEncryptedScaledTemporal(calendar, 0, 0, SSType.DATE, (short)0);
/*      */ 
/*      */ 
/*      */       
/*      */       case TIME:
/* 3342 */         calendar = new GregorianCalendar(TimeZone.getDefault(), Locale.US);
/* 3343 */         calendar.setLenient(true);
/* 3344 */         calendar.clear();
/* 3345 */         utcMillis = ((Timestamp)colValue).getTime();
/* 3346 */         calendar.setTimeInMillis(utcMillis);
/*      */         
/* 3348 */         if (colValue instanceof Timestamp) {
/* 3349 */           subSecondNanos = ((Timestamp)colValue).getNanos();
/*      */         } else {
/* 3351 */           subSecondNanos = 1000000 * (int)(utcMillis % 1000L);
/* 3352 */           if (subSecondNanos < 0)
/* 3353 */             subSecondNanos += 1000000000; 
/*      */         } 
/* 3355 */         return tdsWriter.writeEncryptedScaledTemporal(calendar, subSecondNanos, scale, SSType.TIME, (short)0);
/*      */       
/*      */       case TIMESTAMP:
/* 3358 */         calendar = new GregorianCalendar(TimeZone.getDefault(), Locale.US);
/* 3359 */         calendar.setLenient(true);
/* 3360 */         calendar.clear();
/* 3361 */         utcMillis = ((Timestamp)colValue).getTime();
/* 3362 */         calendar.setTimeInMillis(utcMillis);
/* 3363 */         subSecondNanos = ((Timestamp)colValue).getNanos();
/* 3364 */         return tdsWriter.writeEncryptedScaledTemporal(calendar, subSecondNanos, scale, SSType.DATETIME2, (short)0);
/*      */ 
/*      */       
/*      */       case DATETIME:
/*      */       case SMALLDATETIME:
/* 3369 */         calendar = new GregorianCalendar(TimeZone.getDefault(), Locale.US);
/* 3370 */         calendar.setLenient(true);
/* 3371 */         calendar.clear();
/* 3372 */         utcMillis = ((Timestamp)colValue).getTime();
/* 3373 */         calendar.setTimeInMillis(utcMillis);
/* 3374 */         subSecondNanos = ((Timestamp)colValue).getNanos();
/* 3375 */         return tdsWriter.getEncryptedDateTimeAsBytes(calendar, subSecondNanos, srcTemporalJdbcType);
/*      */       
/*      */       case DATETIMEOFFSET:
/* 3378 */         dtoValue = (DateTimeOffset)colValue;
/* 3379 */         utcMillis = dtoValue.getTimestamp().getTime();
/* 3380 */         subSecondNanos = dtoValue.getTimestamp().getNanos();
/* 3381 */         minutesOffset = dtoValue.getMinutesOffset();
/* 3382 */         calendar = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
/* 3383 */         calendar.setLenient(true);
/* 3384 */         calendar.clear();
/* 3385 */         calendar.setTimeInMillis(utcMillis);
/* 3386 */         return tdsWriter.writeEncryptedScaledTemporal(calendar, subSecondNanos, scale, SSType.DATETIMEOFFSET, (short)minutesOffset);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3391 */     MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_UnsupportedDataTypeAE"));
/* 3392 */     Object[] msgArgs = { srcTemporalJdbcType };
/* 3393 */     throw new SQLServerException(this, form.format(msgArgs), null, 0, false);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private byte[] normalizedValue(JDBCType destJdbcType, Object value, JDBCType srcJdbcType, int destPrecision, int destScale) throws SQLServerException {
/* 3399 */     Long longValue = null;
/* 3400 */     byte[] byteValue = null; try {
/*      */       int srcDataPrecision, srcDataScale; byte[] byteArrayValue; Float floatValue; Double doubleValue; BigDecimal bigDataValue; byte[] decimalbyteValue; BigDecimal bdValue; int digitCount;
/*      */       long moneyVal;
/*      */       ByteBuffer bbuf;
/* 3404 */       switch (destJdbcType) {
/*      */         case BIT:
/* 3406 */           longValue = Long.valueOf((((Boolean)value).booleanValue() ? 1L : 0L));
/* 3407 */           return ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(longValue.longValue())
/* 3408 */             .array();
/*      */         
/*      */         case TINYINT:
/*      */         case SMALLINT:
/* 3412 */           switch (srcJdbcType) {
/*      */             case BIT:
/* 3414 */               longValue = Long.valueOf((((Boolean)value).booleanValue() ? 1L : 0L));
/*      */               break;
/*      */             default:
/* 3417 */               if (value instanceof Integer) {
/* 3418 */                 int intValue = ((Integer)value).intValue();
/* 3419 */                 short shortValue = (short)intValue;
/* 3420 */                 longValue = Long.valueOf(shortValue); break;
/*      */               } 
/* 3422 */               longValue = Long.valueOf(((Short)value).shortValue());
/*      */               break;
/*      */           } 
/* 3425 */           return ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(longValue.longValue())
/* 3426 */             .array();
/*      */         
/*      */         case INTEGER:
/* 3429 */           switch (srcJdbcType) {
/*      */             case BIT:
/* 3431 */               longValue = Long.valueOf((((Boolean)value).booleanValue() ? 1L : 0L));
/*      */               break;
/*      */             case TINYINT:
/*      */             case SMALLINT:
/* 3435 */               longValue = Long.valueOf(((Short)value).shortValue());
/*      */               break;
/*      */             default:
/* 3438 */               longValue = Long.valueOf(((Integer)value).intValue()); break;
/*      */           } 
/* 3440 */           return ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(longValue.longValue())
/* 3441 */             .array();
/*      */         
/*      */         case BIGINT:
/* 3444 */           switch (srcJdbcType) {
/*      */             case BIT:
/* 3446 */               longValue = Long.valueOf((((Boolean)value).booleanValue() ? 1L : 0L));
/*      */               break;
/*      */             case TINYINT:
/*      */             case SMALLINT:
/* 3450 */               longValue = Long.valueOf(((Short)value).shortValue());
/*      */               break;
/*      */             case INTEGER:
/* 3453 */               longValue = Long.valueOf(((Integer)value).intValue());
/*      */               break;
/*      */             default:
/* 3456 */               longValue = Long.valueOf(((Long)value).longValue()); break;
/*      */           } 
/* 3458 */           return ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(longValue.longValue())
/* 3459 */             .array();
/*      */ 
/*      */         
/*      */         case BINARY:
/*      */         case VARBINARY:
/*      */         case LONGVARBINARY:
/* 3465 */           if (value instanceof String) {
/* 3466 */             byteArrayValue = ParameterUtils.HexToBin((String)value);
/*      */           } else {
/* 3468 */             byteArrayValue = (byte[])value;
/*      */           } 
/* 3470 */           if (byteArrayValue.length > destPrecision) {
/* 3471 */             MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_InvalidDataForAE"));
/* 3472 */             Object[] arrayOfObject = { srcJdbcType, destJdbcType };
/* 3473 */             throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*      */           } 
/* 3475 */           return byteArrayValue;
/*      */         case GUID:
/* 3477 */           return Util.asGuidByteArray(UUID.fromString((String)value));
/*      */ 
/*      */ 
/*      */         
/*      */         case CHAR:
/*      */         case VARCHAR:
/*      */         case LONGVARCHAR:
/* 3484 */           if (((String)value).length() > destPrecision) {
/* 3485 */             MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_InvalidDataForAE"));
/* 3486 */             Object[] arrayOfObject = { srcJdbcType, destJdbcType };
/* 3487 */             throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*      */           } 
/* 3489 */           return ((String)value).getBytes(StandardCharsets.UTF_8);
/*      */ 
/*      */         
/*      */         case NCHAR:
/*      */         case NVARCHAR:
/*      */         case LONGNVARCHAR:
/* 3495 */           if (((String)value).length() > destPrecision) {
/* 3496 */             MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_InvalidDataForAE"));
/* 3497 */             Object[] arrayOfObject = { srcJdbcType, destJdbcType };
/* 3498 */             throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*      */           } 
/* 3500 */           return ((String)value).getBytes(StandardCharsets.UTF_16LE);
/*      */         
/*      */         case REAL:
/* 3503 */           floatValue = Float.valueOf((value instanceof String) ? Float.parseFloat((String)value) : ((Float)value).floatValue());
/* 3504 */           return ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN)
/* 3505 */             .putFloat(floatValue.floatValue()).array();
/*      */         
/*      */         case FLOAT:
/*      */         case DOUBLE:
/* 3509 */           doubleValue = Double.valueOf((value instanceof String) ? Double.parseDouble((String)value) : (
/* 3510 */               (Double)value).doubleValue());
/* 3511 */           return ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN)
/* 3512 */             .putDouble(doubleValue.doubleValue()).array();
/*      */         
/*      */         case NUMERIC:
/*      */         case DECIMAL:
/* 3516 */           srcDataScale = ((BigDecimal)value).scale();
/* 3517 */           srcDataPrecision = ((BigDecimal)value).precision();
/* 3518 */           bigDataValue = (BigDecimal)value;
/* 3519 */           if (srcDataPrecision > destPrecision || srcDataScale > destScale) {
/* 3520 */             MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_InvalidDataForAE"));
/* 3521 */             Object[] arrayOfObject = { srcJdbcType, destJdbcType };
/* 3522 */             throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/* 3523 */           }  if (srcDataScale < destScale)
/*      */           {
/* 3525 */             bigDataValue = bigDataValue.setScale(destScale);
/*      */           }
/* 3527 */           byteValue = DDC.convertBigDecimalToBytes(bigDataValue, bigDataValue.scale());
/* 3528 */           decimalbyteValue = new byte[16];
/*      */           
/* 3530 */           System.arraycopy(byteValue, 2, decimalbyteValue, 0, byteValue.length - 2);
/* 3531 */           return decimalbyteValue;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case SMALLMONEY:
/*      */         case MONEY:
/* 3538 */           bdValue = (BigDecimal)value;
/*      */           
/* 3540 */           Util.validateMoneyRange(bdValue, destJdbcType);
/*      */ 
/*      */ 
/*      */           
/* 3544 */           digitCount = bdValue.precision() - bdValue.scale() + 4;
/*      */ 
/*      */           
/* 3547 */           moneyVal = ((BigDecimal)value).multiply(new BigDecimal(10000), new MathContext(digitCount, RoundingMode.HALF_UP)).longValue();
/* 3548 */           bbuf = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN);
/* 3549 */           bbuf.putInt((int)(moneyVal >> 32L)).array();
/* 3550 */           bbuf.putInt((int)moneyVal).array();
/* 3551 */           return bbuf.array();
/*      */       } 
/*      */       
/* 3554 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_UnsupportedDataTypeAE"));
/* 3555 */       Object[] msgArgs = { destJdbcType };
/* 3556 */       throw new SQLServerException(this, form.format(msgArgs), null, 0, false);
/*      */ 
/*      */     
/*      */     }
/* 3560 */     catch (NumberFormatException ex) {
/* 3561 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_InvalidDataForAE"));
/* 3562 */       Object[] msgArgs = { srcJdbcType, destJdbcType };
/* 3563 */       throw new SQLServerException(this, form.format(msgArgs), null, 0, false);
/* 3564 */     } catch (IllegalArgumentException ex) {
/* 3565 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_InvalidDataForAE"));
/* 3566 */       Object[] msgArgs = { srcJdbcType, destJdbcType };
/* 3567 */       throw new SQLServerException(this, form.format(msgArgs), null, 0, false);
/* 3568 */     } catch (ClassCastException ex) {
/* 3569 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_InvalidDataForAE"));
/* 3570 */       Object[] msgArgs = { srcJdbcType, destJdbcType };
/* 3571 */       throw new SQLServerException(this, form.format(msgArgs), null, 0, false);
/*      */     } 
/*      */   }
/*      */   
/*      */   private boolean goToNextRow() throws SQLServerException {
/*      */     try {
/* 3577 */       if (null != this.sourceResultSet) {
/* 3578 */         return this.sourceResultSet.next();
/*      */       }
/* 3580 */       return this.serverBulkData.next();
/*      */     }
/* 3582 */     catch (SQLException e) {
/* 3583 */       throw new SQLServerException(SQLServerException.getErrString("R_unableRetrieveSourceData"), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean writeBatchData(TDSWriter tdsWriter, TDSCommand command, boolean insertRowByRow) throws SQLServerException {
/* 3593 */     int batchsize = this.copyOptions.getBatchSize();
/* 3594 */     int row = 0;
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 3599 */       if (0 != batchsize && row >= batchsize) {
/* 3600 */         return true;
/*      */       }
/*      */       
/* 3603 */       if (!goToNextRow()) {
/* 3604 */         return false;
/*      */       }
/* 3606 */       if (insertRowByRow) {
/*      */         
/* 3608 */         ((SQLServerResultSet)this.sourceResultSet).getTDSReader().readPacket();
/*      */         
/* 3610 */         tdsWriter = sendBulkCopyCommand(command);
/*      */       } 
/*      */ 
/*      */       
/* 3614 */       tdsWriter.writeByte((byte)-47);
/*      */ 
/*      */       
/* 3617 */       if (null != this.sourceResultSet) {
/*      */ 
/*      */         
/* 3620 */         for (ColumnMapping columnMapping : this.columnMappings) {
/* 3621 */           writeColumn(tdsWriter, columnMapping.sourceColumnOrdinal, columnMapping.destinationColumnOrdinal, null);
/*      */         }
/*      */       } else {
/*      */         Object[] rowObjects;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         try {
/* 3637 */           rowObjects = this.serverBulkData.getRowData();
/* 3638 */         } catch (Exception ex) {
/*      */           
/* 3640 */           throw new SQLServerException(SQLServerException.getErrString("R_unableRetrieveSourceData"), ex);
/*      */         } 
/*      */         
/* 3643 */         for (ColumnMapping columnMapping : this.columnMappings)
/*      */         {
/*      */ 
/*      */           
/* 3647 */           writeColumn(tdsWriter, columnMapping.sourceColumnOrdinal, columnMapping.destinationColumnOrdinal, rowObjects[columnMapping.sourceColumnOrdinal - 1]);
/*      */         }
/*      */       } 
/*      */       
/* 3651 */       row++;
/*      */       
/* 3653 */       if (insertRowByRow) {
/* 3654 */         writePacketDataDone(tdsWriter);
/* 3655 */         tdsWriter.setCryptoMetaData(null);
/*      */ 
/*      */         
/* 3658 */         TDSParser.parse(command.startResponse(), command.getLogContext());
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void setStmtColumnEncriptionSetting(SQLServerStatementColumnEncryptionSetting stmtColumnEncriptionSetting) {
/* 3665 */     this.stmtColumnEncriptionSetting = stmtColumnEncriptionSetting;
/*      */   }
/*      */   
/*      */   protected void setDestinationTableMetadata(SQLServerResultSet rs) {
/* 3669 */     this.destinationTableMetadata = rs;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean unicodeConversionRequired(int jdbcType, SSType ssType) {
/* 3680 */     return ((1 == jdbcType || 12 == jdbcType || -16 == jdbcType) && (SSType.NCHAR == ssType || SSType.NVARCHAR == ssType || SSType.NVARCHARMAX == ssType));
/*      */   }
/*      */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerBulkCopy.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */