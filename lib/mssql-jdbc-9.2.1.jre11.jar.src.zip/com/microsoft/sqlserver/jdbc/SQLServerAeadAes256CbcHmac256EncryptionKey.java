/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.security.GeneralSecurityException;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.text.MessageFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SQLServerAeadAes256CbcHmac256EncryptionKey
/*     */   extends SQLServerSymmetricKey
/*     */ {
/*     */   static final int keySize = 256;
/*     */   private final String algorithmName;
/*     */   private String encryptionKeySaltFormat;
/*     */   private String macKeySaltFormat;
/*     */   private String ivKeySaltFormat;
/*     */   private SQLServerSymmetricKey encryptionKey;
/*     */   private SQLServerSymmetricKey macKey;
/*     */   private SQLServerSymmetricKey ivKey;
/*     */   
/*     */   SQLServerAeadAes256CbcHmac256EncryptionKey(byte[] rootKey, String algorithmName) throws SQLServerException {
/*  47 */     super(rootKey);
/*  48 */     this.algorithmName = algorithmName;
/*  49 */     this.encryptionKeySaltFormat = "Microsoft SQL Server cell encryption key with encryption algorithm:" + this.algorithmName + " and key length:256";
/*     */     
/*  51 */     this.macKeySaltFormat = "Microsoft SQL Server cell MAC key with encryption algorithm:" + this.algorithmName + " and key length:256";
/*     */     
/*  53 */     this.ivKeySaltFormat = "Microsoft SQL Server cell IV key with encryption algorithm:" + this.algorithmName + " and key length:256";
/*     */     
/*  55 */     int keySizeInBytes = 32;
/*  56 */     if (rootKey.length != keySizeInBytes) {
/*  57 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_InvalidKeySize"));
/*  58 */       Object[] msgArgs = { Integer.valueOf(rootKey.length), Integer.valueOf(keySizeInBytes), this.algorithmName };
/*  59 */       throw new SQLServerException(this, form.format(msgArgs), null, 0, false);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  65 */     byte[] encKeyBuff = new byte[keySizeInBytes];
/*     */ 
/*     */     
/*     */     try {
/*  69 */       encKeyBuff = SQLServerSecurityUtility.getHMACWithSHA256(this.encryptionKeySaltFormat.getBytes(StandardCharsets.UTF_16LE), rootKey, encKeyBuff.length);
/*     */ 
/*     */       
/*  72 */       this.encryptionKey = new SQLServerSymmetricKey(encKeyBuff);
/*     */ 
/*     */       
/*  75 */       byte[] macKeyBuff = new byte[keySizeInBytes];
/*  76 */       macKeyBuff = SQLServerSecurityUtility.getHMACWithSHA256(this.macKeySaltFormat.getBytes(StandardCharsets.UTF_16LE), rootKey, macKeyBuff.length);
/*     */ 
/*     */       
/*  79 */       this.macKey = new SQLServerSymmetricKey(macKeyBuff);
/*     */ 
/*     */       
/*  82 */       byte[] ivKeyBuff = new byte[keySizeInBytes];
/*  83 */       ivKeyBuff = SQLServerSecurityUtility.getHMACWithSHA256(this.ivKeySaltFormat.getBytes(StandardCharsets.UTF_16LE), rootKey, ivKeyBuff.length);
/*     */       
/*  85 */       this.ivKey = new SQLServerSymmetricKey(ivKeyBuff);
/*  86 */     } catch (InvalidKeyException|java.security.NoSuchAlgorithmException e) {
/*  87 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_KeyExtractionFailed"));
/*  88 */       Object[] msgArgs = { e.getMessage() };
/*  89 */       throw new SQLServerException(this, form.format(msgArgs), null, 0, false);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getEncryptionKey() {
/*  99 */     return this.encryptionKey.getRootKey();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getMacKey() {
/* 107 */     return this.macKey.getRootKey();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getIVKey() {
/* 115 */     return this.ivKey.getRootKey();
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerAeadAes256CbcHmac256EncryptionKey.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */