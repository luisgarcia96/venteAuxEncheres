/*    */ package com.microsoft.sqlserver.jdbc.osgi;
/*    */ 
/*    */ import com.microsoft.sqlserver.jdbc.SQLServerDriver;
/*    */ import java.util.Dictionary;
/*    */ import java.util.Hashtable;
/*    */ import org.osgi.framework.BundleActivator;
/*    */ import org.osgi.framework.BundleContext;
/*    */ import org.osgi.framework.ServiceRegistration;
/*    */ import org.osgi.service.jdbc.DataSourceFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Activator
/*    */   implements BundleActivator
/*    */ {
/*    */   private ServiceRegistration<DataSourceFactory> service;
/*    */   
/*    */   public void start(BundleContext context) throws Exception {
/* 27 */     Dictionary<String, Object> properties = new Hashtable<>();
/* 28 */     SQLServerDriver driver = new SQLServerDriver();
/* 29 */     properties.put("osgi.jdbc.driver.class", driver.getClass().getName());
/* 30 */     properties.put("osgi.jdbc.driver.name", "Microsoft JDBC Driver for SQL Server");
/* 31 */     properties.put("osgi.jdbc.driver.version", "" + driver
/* 32 */         .getMajorVersion() + "." + driver.getMajorVersion());
/* 33 */     this.service = context.registerService(DataSourceFactory.class, new SQLServerDataSourceFactory(), properties);
/* 34 */     SQLServerDriver.register();
/*    */   }
/*    */ 
/*    */   
/*    */   public void stop(BundleContext context) throws Exception {
/* 39 */     if (this.service != null) {
/* 40 */       this.service.unregister();
/*    */     }
/* 42 */     SQLServerDriver.deregister();
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\osgi\Activator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */