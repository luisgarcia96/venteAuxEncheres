/*     */ package com.microsoft.sqlserver.jdbc.osgi;
/*     */ 
/*     */ import com.microsoft.sqlserver.jdbc.SQLServerConnectionPoolDataSource;
/*     */ import com.microsoft.sqlserver.jdbc.SQLServerDataSource;
/*     */ import com.microsoft.sqlserver.jdbc.SQLServerDriver;
/*     */ import com.microsoft.sqlserver.jdbc.SQLServerXADataSource;
/*     */ import java.sql.Driver;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Locale;
/*     */ import java.util.Properties;
/*     */ import java.util.ResourceBundle;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.sql.ConnectionPoolDataSource;
/*     */ import javax.sql.DataSource;
/*     */ import javax.sql.XADataSource;
/*     */ import org.osgi.service.jdbc.DataSourceFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SQLServerDataSourceFactory
/*     */   implements DataSourceFactory
/*     */ {
/*  33 */   private static Logger osgiLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.osgi.SQLServerDataSourceFactory");
/*     */   
/*  35 */   private static final String NOT_SUPPORTED_MSG = ResourceBundle.getBundle("com.microsoft.sqlserver.jdbc.SQLServerResource", Locale.getDefault())
/*  36 */     .getString("R_propertyNotSupported");
/*     */ 
/*     */   
/*     */   public DataSource createDataSource(Properties props) throws SQLException {
/*  40 */     SQLServerDataSource source = new SQLServerDataSource();
/*  41 */     setup(source, props);
/*  42 */     return (DataSource)source;
/*     */   }
/*     */ 
/*     */   
/*     */   public ConnectionPoolDataSource createConnectionPoolDataSource(Properties props) throws SQLException {
/*  47 */     SQLServerConnectionPoolDataSource poolDataSource = new SQLServerConnectionPoolDataSource();
/*  48 */     setupXSource(poolDataSource, props);
/*  49 */     return (ConnectionPoolDataSource)poolDataSource;
/*     */   }
/*     */ 
/*     */   
/*     */   public XADataSource createXADataSource(Properties props) throws SQLException {
/*  54 */     SQLServerXADataSource xaDataSource = new SQLServerXADataSource();
/*  55 */     setupXSource((SQLServerConnectionPoolDataSource)xaDataSource, props);
/*  56 */     return (XADataSource)xaDataSource;
/*     */   }
/*     */ 
/*     */   
/*     */   public Driver createDriver(Properties props) throws SQLException {
/*  61 */     return (Driver)new SQLServerDriver();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setup(SQLServerDataSource source, Properties props) {
/*  68 */     if (props == null) {
/*     */       return;
/*     */     }
/*  71 */     if (props.containsKey("databaseName")) {
/*  72 */       source.setDatabaseName(props.getProperty("databaseName"));
/*     */     }
/*  74 */     if (props.containsKey("dataSourceName")) {
/*  75 */       osgiLogger.log(Level.WARNING, NOT_SUPPORTED_MSG, "dataSourceName");
/*     */     }
/*  77 */     if (props.containsKey("description")) {
/*  78 */       source.setDescription(props.getProperty("description"));
/*     */     }
/*  80 */     if (props.containsKey("networkProtocol")) {
/*  81 */       osgiLogger.log(Level.WARNING, NOT_SUPPORTED_MSG, "networkProtocol");
/*     */     }
/*  83 */     if (props.containsKey("password")) {
/*  84 */       source.setPassword(props.getProperty("password"));
/*     */     }
/*  86 */     if (props.containsKey("portNumber")) {
/*  87 */       source.setPortNumber(Integer.parseInt(props.getProperty("portNumber")));
/*     */     }
/*  89 */     if (props.containsKey("roleName")) {
/*  90 */       osgiLogger.log(Level.WARNING, NOT_SUPPORTED_MSG, "roleName");
/*     */     }
/*  92 */     if (props.containsKey("serverName")) {
/*  93 */       source.setServerName(props.getProperty("serverName"));
/*     */     }
/*  95 */     if (props.containsKey("url")) {
/*  96 */       source.setURL(props.getProperty("url"));
/*     */     }
/*  98 */     if (props.containsKey("user")) {
/*  99 */       source.setUser(props.getProperty("user"));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setupXSource(SQLServerConnectionPoolDataSource source, Properties props) {
/* 107 */     if (props == null) {
/*     */       return;
/*     */     }
/* 110 */     setup((SQLServerDataSource)source, props);
/* 111 */     if (props.containsKey("initialPoolSize")) {
/* 112 */       osgiLogger.log(Level.WARNING, NOT_SUPPORTED_MSG, "initialPoolSize");
/*     */     }
/* 114 */     if (props.containsKey("maxIdleTime")) {
/* 115 */       osgiLogger.log(Level.WARNING, NOT_SUPPORTED_MSG, "maxIdleTime");
/*     */     }
/* 117 */     if (props.containsKey("maxStatements")) {
/* 118 */       osgiLogger.log(Level.WARNING, NOT_SUPPORTED_MSG, "maxStatements");
/*     */     }
/* 120 */     if (props.containsKey("maxPoolSize")) {
/* 121 */       osgiLogger.log(Level.WARNING, NOT_SUPPORTED_MSG, "maxPoolSize");
/*     */     }
/* 123 */     if (props.containsKey("minPoolSize"))
/* 124 */       osgiLogger.log(Level.WARNING, NOT_SUPPORTED_MSG, "minPoolSize"); 
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\osgi\SQLServerDataSourceFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */