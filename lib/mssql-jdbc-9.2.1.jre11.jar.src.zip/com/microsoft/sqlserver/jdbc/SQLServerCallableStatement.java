/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.io.Closeable;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Date;
/*      */ import java.sql.NClob;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.RowId;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLType;
/*      */ import java.sql.SQLXML;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.text.MessageFormat;
/*      */ import java.time.LocalDate;
/*      */ import java.time.LocalDateTime;
/*      */ import java.time.LocalTime;
/*      */ import java.time.OffsetDateTime;
/*      */ import java.time.OffsetTime;
/*      */ import java.util.Calendar;
/*      */ import java.util.HashMap;
/*      */ import java.util.Map;
/*      */ import java.util.TreeMap;
/*      */ import java.util.UUID;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.atomic.AtomicInteger;
/*      */ import java.util.logging.Level;
/*      */ import microsoft.sql.DateTimeOffset;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class SQLServerCallableStatement
/*      */   extends SQLServerPreparedStatement
/*      */   implements ISQLServerCallableStatement
/*      */ {
/*      */   private static final long serialVersionUID = 5044984771674532350L;
/*      */   private HashMap<String, Integer> parameterNames;
/*      */   private TreeMap<String, Integer> insensitiveParameterNames;
/*   58 */   int nOutParams = 0;
/*      */ 
/*      */   
/*   61 */   int nOutParamsAssigned = 0;
/*      */   
/*   63 */   private int outParamIndex = -1;
/*      */ 
/*      */   
/*      */   private Parameter lastParamAccessed;
/*      */ 
/*      */   
/*      */   private Closeable activeStream;
/*      */ 
/*      */   
/*      */   String getClassNameInternal() {
/*   73 */     return "SQLServerCallableStatement";
/*      */   }
/*      */   
/*   76 */   Map<String, Integer> map = new ConcurrentHashMap<>();
/*   77 */   AtomicInteger ai = new AtomicInteger(0);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   SQLServerCallableStatement(SQLServerConnection connection, String sql, int nRSType, int nRSConcur, SQLServerStatementColumnEncryptionSetting stmtColEncSetting) throws SQLServerException {
/*   96 */     super(connection, sql, nRSType, nRSConcur, stmtColEncSetting);
/*      */   }
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int index, int sqlType) throws SQLServerException {
/*  101 */     if (loggerExternal.isLoggable(Level.FINER))
/*  102 */       loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] { Integer.valueOf(index), Integer.valueOf(sqlType) }); 
/*  103 */     checkClosed();
/*  104 */     if (index < 1 || index > this.inOutParam.length) {
/*  105 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_indexOutOfRange"));
/*  106 */       Object[] msgArgs = { Integer.valueOf(index) };
/*  107 */       SQLServerException.makeFromDriverError(this.connection, this, form.format(msgArgs), "7009", false);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  113 */     if (2012 == sqlType) {
/*  114 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_featureNotSupported"));
/*  115 */       Object[] msgArgs = { "REF_CURSOR" };
/*  116 */       SQLServerException.makeFromDriverError(this.connection, this, form.format(msgArgs), null, false);
/*      */     } 
/*      */     
/*  119 */     JDBCType jdbcType = JDBCType.of(sqlType);
/*      */ 
/*      */ 
/*      */     
/*  123 */     discardLastExecutionResults();
/*      */ 
/*      */ 
/*      */     
/*  127 */     if (jdbcType.isUnsupported()) {
/*  128 */       jdbcType = JDBCType.BINARY;
/*      */     }
/*  130 */     Parameter param = this.inOutParam[index - 1];
/*  131 */     assert null != param;
/*      */ 
/*      */ 
/*      */     
/*  135 */     if (!param.isOutput()) {
/*  136 */       this.nOutParams++;
/*      */     }
/*      */ 
/*      */     
/*  140 */     param.registerForOutput(jdbcType, this.connection);
/*  141 */     switch (sqlType) {
/*      */       case -151:
/*  143 */         param.setOutScale(3);
/*      */         break;
/*      */       case -155:
/*      */       case 92:
/*      */       case 93:
/*  148 */         param.setOutScale(7);
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  154 */     loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Parameter getOutParameter(int i) throws SQLServerException {
/*  165 */     processResults();
/*      */ 
/*      */     
/*  168 */     if (this.inOutParam[i - 1] == this.lastParamAccessed || this.inOutParam[i - 1].isValueGotten()) {
/*  169 */       return this.inOutParam[i - 1];
/*      */     }
/*      */ 
/*      */     
/*  173 */     while (this.outParamIndex != i - 1) {
/*  174 */       skipOutParameters(1, false);
/*      */     }
/*  176 */     return this.inOutParam[i - 1];
/*      */   }
/*      */   
/*      */   void startResults() {
/*  180 */     super.startResults();
/*  181 */     this.outParamIndex = -1;
/*  182 */     this.nOutParamsAssigned = 0;
/*  183 */     this.lastParamAccessed = null;
/*  184 */     assert null == this.activeStream;
/*      */   }
/*      */   
/*      */   void processBatch() throws SQLServerException {
/*  188 */     processResults();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  194 */     assert this.nOutParams >= 0;
/*  195 */     if (this.nOutParams > 0) {
/*  196 */       processOutParameters();
/*  197 */       processBatchRemainder();
/*      */     } 
/*      */   }
/*      */   
/*      */   final void processOutParameters() throws SQLServerException {
/*  202 */     assert this.nOutParams > 0;
/*  203 */     assert null != this.inOutParam;
/*      */ 
/*      */     
/*  206 */     closeActiveStream();
/*      */ 
/*      */ 
/*      */     
/*  210 */     if (this.outParamIndex >= 0)
/*      */     {
/*      */ 
/*      */ 
/*      */       
/*  215 */       for (int index = 0; index < this.inOutParam.length; index++) {
/*  216 */         if (index != this.outParamIndex && this.inOutParam[index].isValueGotten()) {
/*  217 */           assert this.inOutParam[index].isOutput();
/*  218 */           this.inOutParam[index].resetOutputValue();
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*  224 */     assert this.nOutParamsAssigned <= this.nOutParams;
/*  225 */     if (this.nOutParamsAssigned < this.nOutParams) {
/*  226 */       skipOutParameters(this.nOutParams - this.nOutParamsAssigned, true);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  232 */     if (this.outParamIndex >= 0) {
/*  233 */       this.inOutParam[this.outParamIndex].skipValue(resultsReader(), true);
/*  234 */       this.inOutParam[this.outParamIndex].resetOutputValue();
/*  235 */       this.outParamIndex = -1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void processBatchRemainder() throws SQLServerException {
/*      */     final class ExecDoneHandler
/*      */       extends TDSTokenHandler
/*      */     {
/*      */       ExecDoneHandler() {
/*  246 */         super("ExecDoneHandler");
/*      */       }
/*      */ 
/*      */       
/*      */       boolean onDone(TDSReader tdsReader) throws SQLServerException {
/*  251 */         StreamDone doneToken = new StreamDone();
/*  252 */         doneToken.setFromTDS(tdsReader);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  257 */         if (doneToken.wasRPCInBatch()) {
/*  258 */           SQLServerCallableStatement.this.startResults();
/*  259 */           return false;
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  264 */         return true;
/*      */       }
/*      */     };
/*      */     
/*  268 */     ExecDoneHandler execDoneHandler = new ExecDoneHandler();
/*  269 */     TDSParser.parse(resultsReader(), execDoneHandler);
/*      */   }
/*      */   
/*      */   private void skipOutParameters(int numParamsToSkip, boolean discardValues) throws SQLServerException {
/*      */     final class OutParamHandler
/*      */       extends TDSTokenHandler {
/*  275 */       final StreamRetValue srv = new StreamRetValue();
/*      */       
/*      */       private boolean foundParam;
/*      */       
/*      */       final boolean foundParam() {
/*  280 */         return this.foundParam;
/*      */       }
/*      */       
/*      */       OutParamHandler() {
/*  284 */         super("OutParamHandler");
/*      */       }
/*      */       
/*      */       final void reset() {
/*  288 */         this.foundParam = false;
/*      */       }
/*      */       
/*      */       boolean onRetValue(TDSReader tdsReader) throws SQLServerException {
/*  292 */         this.srv.setFromTDS(tdsReader);
/*  293 */         this.foundParam = true;
/*  294 */         return false;
/*      */       }
/*      */     };
/*      */     
/*  298 */     OutParamHandler outParamHandler = new OutParamHandler();
/*      */ 
/*      */     
/*  301 */     assert numParamsToSkip <= this.nOutParams - this.nOutParamsAssigned;
/*  302 */     for (int paramsSkipped = 0; paramsSkipped < numParamsToSkip; paramsSkipped++) {
/*      */ 
/*      */       
/*  305 */       if (-1 != this.outParamIndex) {
/*  306 */         this.inOutParam[this.outParamIndex].skipValue(resultsReader(), discardValues);
/*  307 */         if (discardValues) {
/*  308 */           this.inOutParam[this.outParamIndex].resetOutputValue();
/*      */         }
/*      */       } 
/*      */       
/*  312 */       outParamHandler.reset();
/*  313 */       TDSParser.parse(resultsReader(), outParamHandler);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  318 */       if (!outParamHandler.foundParam()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  324 */         if (discardValues) {
/*      */           break;
/*      */         }
/*      */ 
/*      */         
/*  329 */         MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_valueNotSetForParameter"));
/*  330 */         Object[] msgArgs = { Integer.valueOf(this.outParamIndex + 1) };
/*  331 */         SQLServerException.makeFromDriverError(this.connection, this, form.format(msgArgs), null, false);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  340 */       this.outParamIndex = outParamHandler.srv.getOrdinalOrLength();
/*      */ 
/*      */ 
/*      */       
/*  344 */       this.outParamIndex -= this.outParamIndexAdjustment;
/*  345 */       if (this.outParamIndex < 0 || this.outParamIndex >= this.inOutParam.length || !this.inOutParam[this.outParamIndex].isOutput()) {
/*  346 */         getStatementLogger().info(toString() + " Unexpected outParamIndex: " + toString() + "; adjustment: " + this.outParamIndex);
/*      */         
/*  348 */         this.connection.throwInvalidTDS();
/*      */       } 
/*      */       
/*  351 */       this.nOutParamsAssigned++;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int index, int sqlType, String typeName) throws SQLServerException {
/*  357 */     if (loggerExternal.isLoggable(Level.FINER))
/*  358 */       loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] {
/*  359 */             Integer.valueOf(index), Integer.valueOf(sqlType), typeName
/*      */           }); 
/*  361 */     checkClosed();
/*      */     
/*  363 */     registerOutParameter(index, sqlType);
/*      */     
/*  365 */     loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
/*      */   }
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int index, int sqlType, int scale) throws SQLServerException {
/*  370 */     if (loggerExternal.isLoggable(Level.FINER))
/*  371 */       loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] {
/*  372 */             Integer.valueOf(index), Integer.valueOf(sqlType), Integer.valueOf(scale)
/*      */           }); 
/*  374 */     checkClosed();
/*      */     
/*  376 */     registerOutParameter(index, sqlType);
/*  377 */     this.inOutParam[index - 1].setOutScale(scale);
/*      */     
/*  379 */     loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
/*      */   }
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int index, int sqlType, int precision, int scale) throws SQLServerException {
/*  384 */     if (loggerExternal.isLoggable(Level.FINER))
/*  385 */       loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] {
/*  386 */             Integer.valueOf(index), Integer.valueOf(sqlType), Integer.valueOf(scale), Integer.valueOf(precision)
/*      */           }); 
/*  388 */     checkClosed();
/*      */     
/*  390 */     registerOutParameter(index, sqlType);
/*  391 */     this.inOutParam[index - 1].setValueLength(precision);
/*  392 */     this.inOutParam[index - 1].setOutScale(scale);
/*      */     
/*  394 */     loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Parameter getterGetParam(int index) throws SQLServerException {
/*  400 */     checkClosed();
/*      */ 
/*      */     
/*  403 */     if (index < 1 || index > this.inOutParam.length) {
/*  404 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidOutputParameter"));
/*  405 */       Object[] msgArgs = { Integer.valueOf(index) };
/*  406 */       SQLServerException.makeFromDriverError(this.connection, this, form.format(msgArgs), "07009", false);
/*      */     } 
/*      */ 
/*      */     
/*  410 */     if (!this.inOutParam[index - 1].isOutput()) {
/*      */       
/*  412 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_outputParameterNotRegisteredForOutput"));
/*  413 */       Object[] msgArgs = { Integer.valueOf(index) };
/*  414 */       SQLServerException.makeFromDriverError(this.connection, this, form.format(msgArgs), "07009", true);
/*      */     } 
/*      */ 
/*      */     
/*  418 */     if (!wasExecuted()) {
/*  419 */       SQLServerException.makeFromDriverError(this.connection, this, 
/*  420 */           SQLServerException.getErrString("R_statementMustBeExecuted"), "07009", false);
/*      */     }
/*  422 */     resultsReader().getCommand().checkForInterrupt();
/*      */     
/*  424 */     closeActiveStream();
/*  425 */     if (getStatementLogger().isLoggable(Level.FINER)) {
/*  426 */       getStatementLogger().finer(toString() + " Getting Param:" + toString());
/*      */     }
/*      */     
/*  429 */     this.lastParamAccessed = getOutParameter(index);
/*  430 */     return this.lastParamAccessed;
/*      */   }
/*      */   
/*      */   private Object getValue(int parameterIndex, JDBCType jdbcType) throws SQLServerException {
/*  434 */     return getterGetParam(parameterIndex).getValue(jdbcType, null, null, resultsReader());
/*      */   }
/*      */   
/*      */   private Object getValue(int parameterIndex, JDBCType jdbcType, Calendar cal) throws SQLServerException {
/*  438 */     return getterGetParam(parameterIndex).getValue(jdbcType, null, cal, resultsReader());
/*      */   }
/*      */   
/*      */   private Object getStream(int parameterIndex, StreamType streamType) throws SQLServerException {
/*  442 */     Object value = getterGetParam(parameterIndex).getValue(streamType.getJDBCType(), new InputStreamGetterArgs(streamType, 
/*  443 */           getIsResponseBufferingAdaptive(), 
/*  444 */           getIsResponseBufferingAdaptive(), toString()), null, 
/*      */         
/*  446 */         resultsReader());
/*      */     
/*  448 */     this.activeStream = (Closeable)value;
/*  449 */     return value;
/*      */   }
/*      */   
/*      */   private Object getSQLXMLInternal(int parameterIndex) throws SQLServerException {
/*  453 */     SQLServerSQLXML value = (SQLServerSQLXML)getterGetParam(parameterIndex).getValue(JDBCType.SQLXML, new InputStreamGetterArgs(StreamType.SQLXML, 
/*  454 */           getIsResponseBufferingAdaptive(), 
/*  455 */           getIsResponseBufferingAdaptive(), toString()), null, 
/*      */         
/*  457 */         resultsReader());
/*      */     
/*  459 */     if (null != value)
/*  460 */       this.activeStream = value.getStream(); 
/*  461 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getInt(int index) throws SQLServerException {
/*  466 */     loggerExternal.entering(getClassNameLogging(), "getInt", Integer.valueOf(index));
/*  467 */     checkClosed();
/*  468 */     Integer value = (Integer)getValue(index, JDBCType.INTEGER);
/*  469 */     loggerExternal.exiting(getClassNameLogging(), "getInt", value);
/*  470 */     return (null != value) ? value.intValue() : 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getInt(String parameterName) throws SQLServerException {
/*  475 */     loggerExternal.entering(getClassNameLogging(), "getInt", parameterName);
/*  476 */     checkClosed();
/*  477 */     Integer value = (Integer)getValue(findColumn(parameterName), JDBCType.INTEGER);
/*  478 */     loggerExternal.exiting(getClassNameLogging(), "getInt", value);
/*  479 */     return (null != value) ? value.intValue() : 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getString(int index) throws SQLServerException {
/*  484 */     loggerExternal.entering(getClassNameLogging(), "getString", Integer.valueOf(index));
/*  485 */     checkClosed();
/*  486 */     String value = null;
/*  487 */     Object objectValue = getValue(index, JDBCType.CHAR);
/*  488 */     if (null != objectValue) {
/*  489 */       value = objectValue.toString();
/*      */     }
/*  491 */     loggerExternal.exiting(getClassNameLogging(), "getString", value);
/*  492 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getString(String parameterName) throws SQLServerException {
/*  497 */     loggerExternal.entering(getClassNameLogging(), "getString", parameterName);
/*  498 */     checkClosed();
/*  499 */     String value = null;
/*  500 */     Object objectValue = getValue(findColumn(parameterName), JDBCType.CHAR);
/*  501 */     if (null != objectValue) {
/*  502 */       value = objectValue.toString();
/*      */     }
/*  504 */     loggerExternal.exiting(getClassNameLogging(), "getString", value);
/*  505 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public final String getNString(int parameterIndex) throws SQLException {
/*  510 */     loggerExternal.entering(getClassNameLogging(), "getNString", Integer.valueOf(parameterIndex));
/*  511 */     checkClosed();
/*  512 */     String value = (String)getValue(parameterIndex, JDBCType.NCHAR);
/*  513 */     loggerExternal.exiting(getClassNameLogging(), "getNString", value);
/*  514 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public final String getNString(String parameterName) throws SQLException {
/*  519 */     loggerExternal.entering(getClassNameLogging(), "getNString", parameterName);
/*  520 */     checkClosed();
/*  521 */     String value = (String)getValue(findColumn(parameterName), JDBCType.NCHAR);
/*  522 */     loggerExternal.exiting(getClassNameLogging(), "getNString", value);
/*  523 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public BigDecimal getBigDecimal(int parameterIndex, int scale) throws SQLException {
/*  529 */     if (loggerExternal.isLoggable(Level.FINER))
/*  530 */       loggerExternal.entering(getClassNameLogging(), "getBigDecimal", new Object[] { Integer.valueOf(parameterIndex), Integer.valueOf(scale) }); 
/*  531 */     checkClosed();
/*  532 */     BigDecimal value = (BigDecimal)getValue(parameterIndex, JDBCType.DECIMAL);
/*  533 */     if (null != value)
/*  534 */       value = value.setScale(scale, 1); 
/*  535 */     loggerExternal.exiting(getClassNameLogging(), "getBigDecimal", value);
/*  536 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public BigDecimal getBigDecimal(String parameterName, int scale) throws SQLServerException {
/*  542 */     if (loggerExternal.isLoggable(Level.FINER))
/*  543 */       loggerExternal.entering(getClassNameLogging(), "getBigDecimal", new Object[] { parameterName, Integer.valueOf(scale) }); 
/*  544 */     checkClosed();
/*  545 */     BigDecimal value = (BigDecimal)getValue(findColumn(parameterName), JDBCType.DECIMAL);
/*  546 */     if (null != value)
/*  547 */       value = value.setScale(scale, 1); 
/*  548 */     loggerExternal.exiting(getClassNameLogging(), "getBigDecimal", value);
/*  549 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean getBoolean(int index) throws SQLServerException {
/*  554 */     loggerExternal.entering(getClassNameLogging(), "getBoolean", Integer.valueOf(index));
/*  555 */     checkClosed();
/*  556 */     Boolean value = (Boolean)getValue(index, JDBCType.BIT);
/*  557 */     loggerExternal.exiting(getClassNameLogging(), "getBoolean", value);
/*  558 */     return (null != value) ? value.booleanValue() : false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean getBoolean(String parameterName) throws SQLServerException {
/*  563 */     loggerExternal.entering(getClassNameLogging(), "getBoolean", parameterName);
/*  564 */     checkClosed();
/*  565 */     Boolean value = (Boolean)getValue(findColumn(parameterName), JDBCType.BIT);
/*  566 */     loggerExternal.exiting(getClassNameLogging(), "getBoolean", value);
/*  567 */     return (null != value) ? value.booleanValue() : false;
/*      */   }
/*      */ 
/*      */   
/*      */   public byte getByte(int index) throws SQLServerException {
/*  572 */     loggerExternal.entering(getClassNameLogging(), "getByte", Integer.valueOf(index));
/*  573 */     checkClosed();
/*  574 */     Short shortValue = (Short)getValue(index, JDBCType.TINYINT);
/*  575 */     byte byteValue = (null != shortValue) ? shortValue.byteValue() : 0;
/*  576 */     loggerExternal.exiting(getClassNameLogging(), "getByte", Byte.valueOf(byteValue));
/*  577 */     return byteValue;
/*      */   }
/*      */ 
/*      */   
/*      */   public byte getByte(String parameterName) throws SQLServerException {
/*  582 */     loggerExternal.entering(getClassNameLogging(), "getByte", parameterName);
/*  583 */     checkClosed();
/*  584 */     Short shortValue = (Short)getValue(findColumn(parameterName), JDBCType.TINYINT);
/*  585 */     byte byteValue = (null != shortValue) ? shortValue.byteValue() : 0;
/*  586 */     loggerExternal.exiting(getClassNameLogging(), "getByte", Byte.valueOf(byteValue));
/*  587 */     return byteValue;
/*      */   }
/*      */ 
/*      */   
/*      */   public byte[] getBytes(int index) throws SQLServerException {
/*  592 */     loggerExternal.entering(getClassNameLogging(), "getBytes", Integer.valueOf(index));
/*  593 */     checkClosed();
/*  594 */     byte[] value = (byte[])getValue(index, JDBCType.BINARY);
/*  595 */     loggerExternal.exiting(getClassNameLogging(), "getBytes", value);
/*  596 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public byte[] getBytes(String parameterName) throws SQLServerException {
/*  601 */     loggerExternal.entering(getClassNameLogging(), "getBytes", parameterName);
/*  602 */     checkClosed();
/*  603 */     byte[] value = (byte[])getValue(findColumn(parameterName), JDBCType.BINARY);
/*  604 */     loggerExternal.exiting(getClassNameLogging(), "getBytes", value);
/*  605 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Date getDate(int index) throws SQLServerException {
/*  610 */     loggerExternal.entering(getClassNameLogging(), "getDate", Integer.valueOf(index));
/*  611 */     checkClosed();
/*  612 */     Date value = (Date)getValue(index, JDBCType.DATE);
/*  613 */     loggerExternal.exiting(getClassNameLogging(), "getDate", value);
/*  614 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Date getDate(String parameterName) throws SQLServerException {
/*  619 */     loggerExternal.entering(getClassNameLogging(), "getDate", parameterName);
/*  620 */     checkClosed();
/*  621 */     Date value = (Date)getValue(findColumn(parameterName), JDBCType.DATE);
/*  622 */     loggerExternal.exiting(getClassNameLogging(), "getDate", value);
/*  623 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Date getDate(int index, Calendar cal) throws SQLServerException {
/*  628 */     if (loggerExternal.isLoggable(Level.FINER))
/*  629 */       loggerExternal.entering(getClassNameLogging(), "getDate", new Object[] { Integer.valueOf(index), cal }); 
/*  630 */     checkClosed();
/*  631 */     Date value = (Date)getValue(index, JDBCType.DATE, cal);
/*  632 */     loggerExternal.exiting(getClassNameLogging(), "getDate", value);
/*  633 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Date getDate(String parameterName, Calendar cal) throws SQLServerException {
/*  638 */     if (loggerExternal.isLoggable(Level.FINER))
/*  639 */       loggerExternal.entering(getClassNameLogging(), "getDate", new Object[] { parameterName, cal }); 
/*  640 */     checkClosed();
/*  641 */     Date value = (Date)getValue(findColumn(parameterName), JDBCType.DATE, cal);
/*  642 */     loggerExternal.exiting(getClassNameLogging(), "getDate", value);
/*  643 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public double getDouble(int index) throws SQLServerException {
/*  648 */     loggerExternal.entering(getClassNameLogging(), "getDouble", Integer.valueOf(index));
/*  649 */     checkClosed();
/*  650 */     Double value = (Double)getValue(index, JDBCType.DOUBLE);
/*  651 */     loggerExternal.exiting(getClassNameLogging(), "getDouble", value);
/*  652 */     return (null != value) ? value.doubleValue() : 0.0D;
/*      */   }
/*      */ 
/*      */   
/*      */   public double getDouble(String parameterName) throws SQLServerException {
/*  657 */     loggerExternal.entering(getClassNameLogging(), "getDouble", parameterName);
/*  658 */     checkClosed();
/*  659 */     Double value = (Double)getValue(findColumn(parameterName), JDBCType.DOUBLE);
/*  660 */     loggerExternal.exiting(getClassNameLogging(), "getDouble", value);
/*  661 */     return (null != value) ? value.doubleValue() : 0.0D;
/*      */   }
/*      */ 
/*      */   
/*      */   public float getFloat(int index) throws SQLServerException {
/*  666 */     loggerExternal.entering(getClassNameLogging(), "getFloat", Integer.valueOf(index));
/*  667 */     checkClosed();
/*  668 */     Float value = (Float)getValue(index, JDBCType.REAL);
/*  669 */     loggerExternal.exiting(getClassNameLogging(), "getFloat", value);
/*  670 */     return (null != value) ? value.floatValue() : 0.0F;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFloat(String parameterName) throws SQLServerException {
/*  676 */     loggerExternal.entering(getClassNameLogging(), "getFloat", parameterName);
/*  677 */     checkClosed();
/*  678 */     Float value = (Float)getValue(findColumn(parameterName), JDBCType.REAL);
/*  679 */     loggerExternal.exiting(getClassNameLogging(), "getFloat", value);
/*  680 */     return (null != value) ? value.floatValue() : 0.0F;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLong(int index) throws SQLServerException {
/*  686 */     loggerExternal.entering(getClassNameLogging(), "getLong", Integer.valueOf(index));
/*  687 */     checkClosed();
/*  688 */     Long value = (Long)getValue(index, JDBCType.BIGINT);
/*  689 */     loggerExternal.exiting(getClassNameLogging(), "getLong", value);
/*  690 */     return (null != value) ? value.longValue() : 0L;
/*      */   }
/*      */ 
/*      */   
/*      */   public long getLong(String parameterName) throws SQLServerException {
/*  695 */     loggerExternal.entering(getClassNameLogging(), "getLong", parameterName);
/*  696 */     checkClosed();
/*  697 */     Long value = (Long)getValue(findColumn(parameterName), JDBCType.BIGINT);
/*  698 */     loggerExternal.exiting(getClassNameLogging(), "getLong", value);
/*  699 */     return (null != value) ? value.longValue() : 0L;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int index) throws SQLServerException {
/*  705 */     loggerExternal.entering(getClassNameLogging(), "getObject", Integer.valueOf(index));
/*  706 */     checkClosed();
/*  707 */     Object value = getValue(index, 
/*  708 */         (null != getterGetParam(index).getJdbcTypeSetByUser()) ? getterGetParam(index).getJdbcTypeSetByUser() : 
/*  709 */         getterGetParam(index).getJdbcType());
/*  710 */     loggerExternal.exiting(getClassNameLogging(), "getObject", value);
/*  711 */     return value;
/*      */   }
/*      */   
/*      */   public <T> T getObject(int index, Class<T> type) throws SQLException {
/*      */     Object returnValue;
/*  716 */     loggerExternal.entering(getClassNameLogging(), "getObject", Integer.valueOf(index));
/*  717 */     checkClosed();
/*      */     
/*  719 */     if (type == String.class) {
/*  720 */       returnValue = getString(index);
/*  721 */     } else if (type == Byte.class) {
/*  722 */       byte byteValue = getByte(index);
/*  723 */       returnValue = wasNull() ? null : Byte.valueOf(byteValue);
/*  724 */     } else if (type == Short.class) {
/*  725 */       short shortValue = getShort(index);
/*  726 */       returnValue = wasNull() ? null : Short.valueOf(shortValue);
/*  727 */     } else if (type == Integer.class) {
/*  728 */       int intValue = getInt(index);
/*  729 */       returnValue = wasNull() ? null : Integer.valueOf(intValue);
/*  730 */     } else if (type == Long.class) {
/*  731 */       long longValue = getLong(index);
/*  732 */       returnValue = wasNull() ? null : Long.valueOf(longValue);
/*  733 */     } else if (type == BigDecimal.class) {
/*  734 */       returnValue = getBigDecimal(index);
/*  735 */     } else if (type == Boolean.class) {
/*  736 */       boolean booleanValue = getBoolean(index);
/*  737 */       returnValue = wasNull() ? null : Boolean.valueOf(booleanValue);
/*  738 */     } else if (type == Date.class) {
/*  739 */       returnValue = getDate(index);
/*  740 */     } else if (type == Time.class) {
/*  741 */       returnValue = getTime(index);
/*  742 */     } else if (type == Timestamp.class) {
/*  743 */       returnValue = getTimestamp(index);
/*  744 */     } else if (type == LocalDateTime.class || type == LocalDate.class || type == LocalTime.class) {
/*      */       
/*  746 */       LocalDateTime ldt = getLocalDateTime(index);
/*  747 */       if (null == ldt) {
/*  748 */         returnValue = null;
/*      */       }
/*  750 */       else if (type == LocalDateTime.class) {
/*  751 */         returnValue = ldt;
/*  752 */       } else if (type == LocalDate.class) {
/*  753 */         returnValue = ldt.toLocalDate();
/*      */       } else {
/*  755 */         returnValue = ldt.toLocalTime();
/*      */       }
/*      */     
/*  758 */     } else if (type == OffsetDateTime.class) {
/*  759 */       DateTimeOffset dateTimeOffset = getDateTimeOffset(index);
/*  760 */       if (dateTimeOffset == null) {
/*  761 */         returnValue = null;
/*      */       } else {
/*  763 */         returnValue = dateTimeOffset.getOffsetDateTime();
/*      */       } 
/*  765 */     } else if (type == OffsetTime.class) {
/*  766 */       DateTimeOffset dateTimeOffset = getDateTimeOffset(index);
/*  767 */       if (dateTimeOffset == null) {
/*  768 */         returnValue = null;
/*      */       } else {
/*  770 */         returnValue = dateTimeOffset.getOffsetDateTime().toOffsetTime();
/*      */       } 
/*  772 */     } else if (type == DateTimeOffset.class) {
/*  773 */       returnValue = getDateTimeOffset(index);
/*  774 */     } else if (type == UUID.class) {
/*      */       
/*  776 */       byte[] guid = getBytes(index);
/*  777 */       returnValue = (null != guid) ? Util.readGUIDtoUUID(guid) : null;
/*  778 */     } else if (type == SQLXML.class) {
/*  779 */       returnValue = getSQLXML(index);
/*  780 */     } else if (type == Blob.class) {
/*  781 */       returnValue = getBlob(index);
/*  782 */     } else if (type == Clob.class) {
/*  783 */       returnValue = getClob(index);
/*  784 */     } else if (type == NClob.class) {
/*  785 */       returnValue = getNClob(index);
/*  786 */     } else if (type == byte[].class) {
/*  787 */       returnValue = getBytes(index);
/*  788 */     } else if (type == Float.class) {
/*  789 */       float floatValue = getFloat(index);
/*  790 */       returnValue = wasNull() ? null : Float.valueOf(floatValue);
/*  791 */     } else if (type == Double.class) {
/*  792 */       double doubleValue = getDouble(index);
/*  793 */       returnValue = wasNull() ? null : Double.valueOf(doubleValue);
/*      */     }
/*      */     else {
/*      */       
/*  797 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_unsupportedConversionTo"));
/*  798 */       Object[] msgArgs = { type };
/*  799 */       throw new SQLServerException(form.format(msgArgs), SQLState.DATA_EXCEPTION_NOT_SPECIFIC, DriverError.NOT_SET, null);
/*      */     } 
/*      */     
/*  802 */     loggerExternal.exiting(getClassNameLogging(), "getObject", Integer.valueOf(index));
/*  803 */     return type.cast(returnValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public Object getObject(String parameterName) throws SQLServerException {
/*  808 */     loggerExternal.entering(getClassNameLogging(), "getObject", parameterName);
/*  809 */     checkClosed();
/*  810 */     int parameterIndex = findColumn(parameterName);
/*  811 */     Object value = getValue(parameterIndex, 
/*  812 */         (null != getterGetParam(parameterIndex).getJdbcTypeSetByUser()) ? getterGetParam(
/*  813 */           parameterIndex).getJdbcTypeSetByUser() : getterGetParam(parameterIndex).getJdbcType());
/*  814 */     loggerExternal.exiting(getClassNameLogging(), "getObject", value);
/*  815 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> T getObject(String parameterName, Class<T> type) throws SQLException {
/*  820 */     loggerExternal.entering(getClassNameLogging(), "getObject", parameterName);
/*  821 */     checkClosed();
/*  822 */     int parameterIndex = findColumn(parameterName);
/*  823 */     T value = getObject(parameterIndex, type);
/*  824 */     loggerExternal.exiting(getClassNameLogging(), "getObject", value);
/*  825 */     return value;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public short getShort(int index) throws SQLServerException {
/*  831 */     loggerExternal.entering(getClassNameLogging(), "getShort", Integer.valueOf(index));
/*  832 */     checkClosed();
/*  833 */     Short value = (Short)getValue(index, JDBCType.SMALLINT);
/*  834 */     loggerExternal.exiting(getClassNameLogging(), "getShort", value);
/*  835 */     return (null != value) ? value.shortValue() : 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public short getShort(String parameterName) throws SQLServerException {
/*  840 */     loggerExternal.entering(getClassNameLogging(), "getShort", parameterName);
/*  841 */     checkClosed();
/*  842 */     Short value = (Short)getValue(findColumn(parameterName), JDBCType.SMALLINT);
/*  843 */     loggerExternal.exiting(getClassNameLogging(), "getShort", value);
/*  844 */     return (null != value) ? value.shortValue() : 0;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(int index) throws SQLServerException {
/*  850 */     loggerExternal.entering(getClassNameLogging(), "getTime", Integer.valueOf(index));
/*  851 */     checkClosed();
/*  852 */     Time value = (Time)getValue(index, JDBCType.TIME);
/*  853 */     loggerExternal.exiting(getClassNameLogging(), "getTime", value);
/*  854 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Time getTime(String parameterName) throws SQLServerException {
/*  859 */     loggerExternal.entering(getClassNameLogging(), "getTime", parameterName);
/*  860 */     checkClosed();
/*  861 */     Time value = (Time)getValue(findColumn(parameterName), JDBCType.TIME);
/*  862 */     loggerExternal.exiting(getClassNameLogging(), "getTime", value);
/*  863 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Time getTime(int index, Calendar cal) throws SQLServerException {
/*  868 */     if (loggerExternal.isLoggable(Level.FINER))
/*  869 */       loggerExternal.entering(getClassNameLogging(), "getTime", new Object[] { Integer.valueOf(index), cal }); 
/*  870 */     checkClosed();
/*  871 */     Time value = (Time)getValue(index, JDBCType.TIME, cal);
/*  872 */     loggerExternal.exiting(getClassNameLogging(), "getTime", value);
/*  873 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Time getTime(String parameterName, Calendar cal) throws SQLServerException {
/*  878 */     if (loggerExternal.isLoggable(Level.FINER))
/*  879 */       loggerExternal.entering(getClassNameLogging(), "getTime", new Object[] { parameterName, cal }); 
/*  880 */     checkClosed();
/*  881 */     Time value = (Time)getValue(findColumn(parameterName), JDBCType.TIME, cal);
/*  882 */     loggerExternal.exiting(getClassNameLogging(), "getTime", value);
/*  883 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(int index) throws SQLServerException {
/*  888 */     if (loggerExternal.isLoggable(Level.FINER))
/*  889 */       loggerExternal.entering(getClassNameLogging(), "getTimestamp", Integer.valueOf(index)); 
/*  890 */     checkClosed();
/*  891 */     Timestamp value = (Timestamp)getValue(index, JDBCType.TIMESTAMP);
/*  892 */     loggerExternal.exiting(getClassNameLogging(), "getTimestamp", value);
/*  893 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(String parameterName) throws SQLServerException {
/*  898 */     loggerExternal.entering(getClassNameLogging(), "getTimestamp", parameterName);
/*  899 */     checkClosed();
/*  900 */     Timestamp value = (Timestamp)getValue(findColumn(parameterName), JDBCType.TIMESTAMP);
/*  901 */     loggerExternal.exiting(getClassNameLogging(), "getTimestamp", value);
/*  902 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(int index, Calendar cal) throws SQLServerException {
/*  907 */     if (loggerExternal.isLoggable(Level.FINER))
/*  908 */       loggerExternal.entering(getClassNameLogging(), "getTimestamp", new Object[] { Integer.valueOf(index), cal }); 
/*  909 */     checkClosed();
/*  910 */     Timestamp value = (Timestamp)getValue(index, JDBCType.TIMESTAMP, cal);
/*  911 */     loggerExternal.exiting(getClassNameLogging(), "getTimestamp", value);
/*  912 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(String name, Calendar cal) throws SQLServerException {
/*  917 */     if (loggerExternal.isLoggable(Level.FINER))
/*  918 */       loggerExternal.entering(getClassNameLogging(), "getTimestamp", new Object[] { name, cal }); 
/*  919 */     checkClosed();
/*  920 */     Timestamp value = (Timestamp)getValue(findColumn(name), JDBCType.TIMESTAMP, cal);
/*  921 */     loggerExternal.exiting(getClassNameLogging(), "getTimestamp", value);
/*  922 */     return value;
/*      */   }
/*      */   
/*      */   LocalDateTime getLocalDateTime(int columnIndex) throws SQLServerException {
/*  926 */     loggerExternal.entering(getClassNameLogging(), "getLocalDateTime", Integer.valueOf(columnIndex));
/*  927 */     checkClosed();
/*  928 */     LocalDateTime value = (LocalDateTime)getValue(columnIndex, JDBCType.LOCALDATETIME);
/*  929 */     loggerExternal.exiting(getClassNameLogging(), "getLocalDateTime", value);
/*  930 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Timestamp getDateTime(int index) throws SQLServerException {
/*  935 */     if (loggerExternal.isLoggable(Level.FINER))
/*  936 */       loggerExternal.entering(getClassNameLogging(), "getDateTime", Integer.valueOf(index)); 
/*  937 */     checkClosed();
/*  938 */     Timestamp value = (Timestamp)getValue(index, JDBCType.DATETIME);
/*  939 */     loggerExternal.exiting(getClassNameLogging(), "getDateTime", value);
/*  940 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Timestamp getDateTime(String parameterName) throws SQLServerException {
/*  945 */     loggerExternal.entering(getClassNameLogging(), "getDateTime", parameterName);
/*  946 */     checkClosed();
/*  947 */     Timestamp value = (Timestamp)getValue(findColumn(parameterName), JDBCType.DATETIME);
/*  948 */     loggerExternal.exiting(getClassNameLogging(), "getDateTime", value);
/*  949 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Timestamp getDateTime(int index, Calendar cal) throws SQLServerException {
/*  954 */     if (loggerExternal.isLoggable(Level.FINER))
/*  955 */       loggerExternal.entering(getClassNameLogging(), "getDateTime", new Object[] { Integer.valueOf(index), cal }); 
/*  956 */     checkClosed();
/*  957 */     Timestamp value = (Timestamp)getValue(index, JDBCType.DATETIME, cal);
/*  958 */     loggerExternal.exiting(getClassNameLogging(), "getDateTime", value);
/*  959 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Timestamp getDateTime(String name, Calendar cal) throws SQLServerException {
/*  964 */     if (loggerExternal.isLoggable(Level.FINER))
/*  965 */       loggerExternal.entering(getClassNameLogging(), "getDateTime", new Object[] { name, cal }); 
/*  966 */     checkClosed();
/*  967 */     Timestamp value = (Timestamp)getValue(findColumn(name), JDBCType.DATETIME, cal);
/*  968 */     loggerExternal.exiting(getClassNameLogging(), "getDateTime", value);
/*  969 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Timestamp getSmallDateTime(int index) throws SQLServerException {
/*  974 */     if (loggerExternal.isLoggable(Level.FINER))
/*  975 */       loggerExternal.entering(getClassNameLogging(), "getSmallDateTime", Integer.valueOf(index)); 
/*  976 */     checkClosed();
/*  977 */     Timestamp value = (Timestamp)getValue(index, JDBCType.SMALLDATETIME);
/*  978 */     loggerExternal.exiting(getClassNameLogging(), "getSmallDateTime", value);
/*  979 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Timestamp getSmallDateTime(String parameterName) throws SQLServerException {
/*  984 */     loggerExternal.entering(getClassNameLogging(), "getSmallDateTime", parameterName);
/*  985 */     checkClosed();
/*  986 */     Timestamp value = (Timestamp)getValue(findColumn(parameterName), JDBCType.SMALLDATETIME);
/*  987 */     loggerExternal.exiting(getClassNameLogging(), "getSmallDateTime", value);
/*  988 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Timestamp getSmallDateTime(int index, Calendar cal) throws SQLServerException {
/*  993 */     if (loggerExternal.isLoggable(Level.FINER))
/*  994 */       loggerExternal.entering(getClassNameLogging(), "getSmallDateTime", new Object[] { Integer.valueOf(index), cal }); 
/*  995 */     checkClosed();
/*  996 */     Timestamp value = (Timestamp)getValue(index, JDBCType.SMALLDATETIME, cal);
/*  997 */     loggerExternal.exiting(getClassNameLogging(), "getSmallDateTime", value);
/*  998 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Timestamp getSmallDateTime(String name, Calendar cal) throws SQLServerException {
/* 1003 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1004 */       loggerExternal.entering(getClassNameLogging(), "getSmallDateTime", new Object[] { name, cal }); 
/* 1005 */     checkClosed();
/* 1006 */     Timestamp value = (Timestamp)getValue(findColumn(name), JDBCType.SMALLDATETIME, cal);
/* 1007 */     loggerExternal.exiting(getClassNameLogging(), "getSmallDateTime", value);
/* 1008 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public DateTimeOffset getDateTimeOffset(int index) throws SQLServerException {
/* 1013 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1014 */       loggerExternal.entering(getClassNameLogging(), "getDateTimeOffset", Integer.valueOf(index)); 
/* 1015 */     checkClosed();
/*      */ 
/*      */     
/* 1018 */     if (!this.connection.isKatmaiOrLater()) {
/* 1019 */       throw new SQLServerException(SQLServerException.getErrString("R_notSupported"), SQLState.DATA_EXCEPTION_NOT_SPECIFIC, DriverError.NOT_SET, null);
/*      */     }
/*      */     
/* 1022 */     DateTimeOffset value = (DateTimeOffset)getValue(index, JDBCType.DATETIMEOFFSET);
/* 1023 */     loggerExternal.exiting(getClassNameLogging(), "getDateTimeOffset", value);
/* 1024 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public DateTimeOffset getDateTimeOffset(String parameterName) throws SQLServerException {
/* 1029 */     loggerExternal.entering(getClassNameLogging(), "getDateTimeOffset", parameterName);
/* 1030 */     checkClosed();
/*      */ 
/*      */     
/* 1033 */     if (!this.connection.isKatmaiOrLater()) {
/* 1034 */       throw new SQLServerException(SQLServerException.getErrString("R_notSupported"), SQLState.DATA_EXCEPTION_NOT_SPECIFIC, DriverError.NOT_SET, null);
/*      */     }
/*      */     
/* 1037 */     DateTimeOffset value = (DateTimeOffset)getValue(findColumn(parameterName), JDBCType.DATETIMEOFFSET);
/*      */     
/* 1039 */     loggerExternal.exiting(getClassNameLogging(), "getDateTimeOffset", value);
/* 1040 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean wasNull() throws SQLServerException {
/* 1045 */     loggerExternal.entering(getClassNameLogging(), "wasNull");
/* 1046 */     checkClosed();
/* 1047 */     boolean bWasNull = false;
/* 1048 */     if (null != this.lastParamAccessed) {
/* 1049 */       bWasNull = this.lastParamAccessed.isNull();
/*      */     }
/* 1051 */     loggerExternal.exiting(getClassNameLogging(), "wasNull", Boolean.valueOf(bWasNull));
/* 1052 */     return bWasNull;
/*      */   }
/*      */ 
/*      */   
/*      */   public final InputStream getAsciiStream(int parameterIndex) throws SQLServerException {
/* 1057 */     loggerExternal.entering(getClassNameLogging(), "getAsciiStream", Integer.valueOf(parameterIndex));
/* 1058 */     checkClosed();
/* 1059 */     InputStream value = (InputStream)getStream(parameterIndex, StreamType.ASCII);
/* 1060 */     loggerExternal.exiting(getClassNameLogging(), "getAsciiStream", value);
/* 1061 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public final InputStream getAsciiStream(String parameterName) throws SQLServerException {
/* 1066 */     loggerExternal.entering(getClassNameLogging(), "getAsciiStream", parameterName);
/* 1067 */     checkClosed();
/* 1068 */     InputStream value = (InputStream)getStream(findColumn(parameterName), StreamType.ASCII);
/* 1069 */     loggerExternal.exiting(getClassNameLogging(), "getAsciiStream", value);
/* 1070 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(int parameterIndex) throws SQLServerException {
/* 1075 */     loggerExternal.entering(getClassNameLogging(), "getBigDecimal", Integer.valueOf(parameterIndex));
/* 1076 */     checkClosed();
/* 1077 */     BigDecimal value = (BigDecimal)getValue(parameterIndex, JDBCType.DECIMAL);
/* 1078 */     loggerExternal.exiting(getClassNameLogging(), "getBigDecimal", value);
/* 1079 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(String parameterName) throws SQLServerException {
/* 1084 */     loggerExternal.entering(getClassNameLogging(), "getBigDecimal", parameterName);
/* 1085 */     checkClosed();
/* 1086 */     BigDecimal value = (BigDecimal)getValue(findColumn(parameterName), JDBCType.DECIMAL);
/* 1087 */     loggerExternal.exiting(getClassNameLogging(), "getBigDecimal", value);
/* 1088 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public BigDecimal getMoney(int parameterIndex) throws SQLServerException {
/* 1093 */     loggerExternal.entering(getClassNameLogging(), "getMoney", Integer.valueOf(parameterIndex));
/* 1094 */     checkClosed();
/* 1095 */     BigDecimal value = (BigDecimal)getValue(parameterIndex, JDBCType.MONEY);
/* 1096 */     loggerExternal.exiting(getClassNameLogging(), "getMoney", value);
/* 1097 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public BigDecimal getMoney(String parameterName) throws SQLServerException {
/* 1102 */     loggerExternal.entering(getClassNameLogging(), "getMoney", parameterName);
/* 1103 */     checkClosed();
/* 1104 */     BigDecimal value = (BigDecimal)getValue(findColumn(parameterName), JDBCType.MONEY);
/* 1105 */     loggerExternal.exiting(getClassNameLogging(), "getMoney", value);
/* 1106 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public BigDecimal getSmallMoney(int parameterIndex) throws SQLServerException {
/* 1111 */     loggerExternal.entering(getClassNameLogging(), "getSmallMoney", Integer.valueOf(parameterIndex));
/* 1112 */     checkClosed();
/* 1113 */     BigDecimal value = (BigDecimal)getValue(parameterIndex, JDBCType.SMALLMONEY);
/* 1114 */     loggerExternal.exiting(getClassNameLogging(), "getSmallMoney", value);
/* 1115 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public BigDecimal getSmallMoney(String parameterName) throws SQLServerException {
/* 1120 */     loggerExternal.entering(getClassNameLogging(), "getSmallMoney", parameterName);
/* 1121 */     checkClosed();
/* 1122 */     BigDecimal value = (BigDecimal)getValue(findColumn(parameterName), JDBCType.SMALLMONEY);
/* 1123 */     loggerExternal.exiting(getClassNameLogging(), "getSmallMoney", value);
/* 1124 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public final InputStream getBinaryStream(int parameterIndex) throws SQLServerException {
/* 1129 */     loggerExternal.entering(getClassNameLogging(), "getBinaryStream", Integer.valueOf(parameterIndex));
/* 1130 */     checkClosed();
/* 1131 */     InputStream value = (InputStream)getStream(parameterIndex, StreamType.BINARY);
/* 1132 */     loggerExternal.exiting(getClassNameLogging(), "getBinaryStream", value);
/* 1133 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public final InputStream getBinaryStream(String parameterName) throws SQLServerException {
/* 1138 */     loggerExternal.entering(getClassNameLogging(), "getBinaryStream", parameterName);
/* 1139 */     checkClosed();
/* 1140 */     InputStream value = (InputStream)getStream(findColumn(parameterName), StreamType.BINARY);
/* 1141 */     loggerExternal.exiting(getClassNameLogging(), "getBinaryStream", value);
/* 1142 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Blob getBlob(int parameterIndex) throws SQLServerException {
/* 1147 */     loggerExternal.entering(getClassNameLogging(), "getBlob", Integer.valueOf(parameterIndex));
/* 1148 */     checkClosed();
/* 1149 */     Blob value = (Blob)getValue(parameterIndex, JDBCType.BLOB);
/* 1150 */     loggerExternal.exiting(getClassNameLogging(), "getBlob", value);
/* 1151 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public Blob getBlob(String parameterName) throws SQLServerException {
/* 1156 */     loggerExternal.entering(getClassNameLogging(), "getBlob", parameterName);
/* 1157 */     checkClosed();
/* 1158 */     Blob value = (Blob)getValue(findColumn(parameterName), JDBCType.BLOB);
/* 1159 */     loggerExternal.exiting(getClassNameLogging(), "getBlob", value);
/* 1160 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public final Reader getCharacterStream(int parameterIndex) throws SQLServerException {
/* 1165 */     loggerExternal.entering(getClassNameLogging(), "getCharacterStream", Integer.valueOf(parameterIndex));
/* 1166 */     checkClosed();
/* 1167 */     Reader reader = (Reader)getStream(parameterIndex, StreamType.CHARACTER);
/* 1168 */     loggerExternal.exiting(getClassNameLogging(), "getCharacterStream", reader);
/* 1169 */     return reader;
/*      */   }
/*      */ 
/*      */   
/*      */   public final Reader getCharacterStream(String parameterName) throws SQLException {
/* 1174 */     loggerExternal.entering(getClassNameLogging(), "getCharacterStream", parameterName);
/* 1175 */     checkClosed();
/* 1176 */     Reader reader = (Reader)getStream(findColumn(parameterName), StreamType.CHARACTER);
/* 1177 */     loggerExternal.exiting(getClassNameLogging(), "getCharacterSream", reader);
/* 1178 */     return reader;
/*      */   }
/*      */ 
/*      */   
/*      */   public final Reader getNCharacterStream(int parameterIndex) throws SQLException {
/* 1183 */     loggerExternal.entering(getClassNameLogging(), "getNCharacterStream", Integer.valueOf(parameterIndex));
/* 1184 */     checkClosed();
/* 1185 */     Reader reader = (Reader)getStream(parameterIndex, StreamType.NCHARACTER);
/* 1186 */     loggerExternal.exiting(getClassNameLogging(), "getNCharacterStream", reader);
/* 1187 */     return reader;
/*      */   }
/*      */ 
/*      */   
/*      */   public final Reader getNCharacterStream(String parameterName) throws SQLException {
/* 1192 */     loggerExternal.entering(getClassNameLogging(), "getNCharacterStream", parameterName);
/* 1193 */     checkClosed();
/* 1194 */     Reader reader = (Reader)getStream(findColumn(parameterName), StreamType.NCHARACTER);
/* 1195 */     loggerExternal.exiting(getClassNameLogging(), "getNCharacterStream", reader);
/* 1196 */     return reader;
/*      */   }
/*      */   
/*      */   void closeActiveStream() throws SQLServerException {
/* 1200 */     if (null != this.activeStream) {
/*      */       try {
/* 1202 */         this.activeStream.close();
/* 1203 */       } catch (IOException e) {
/* 1204 */         SQLServerException.makeFromDriverError(null, null, e.getMessage(), null, true);
/*      */       } finally {
/* 1206 */         this.activeStream = null;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public Clob getClob(int parameterIndex) throws SQLServerException {
/* 1213 */     loggerExternal.entering(getClassNameLogging(), "getClob", Integer.valueOf(parameterIndex));
/* 1214 */     checkClosed();
/* 1215 */     Clob clob = (Clob)getValue(parameterIndex, JDBCType.CLOB);
/* 1216 */     loggerExternal.exiting(getClassNameLogging(), "getClob", clob);
/* 1217 */     return clob;
/*      */   }
/*      */ 
/*      */   
/*      */   public Clob getClob(String parameterName) throws SQLServerException {
/* 1222 */     loggerExternal.entering(getClassNameLogging(), "getClob", parameterName);
/* 1223 */     checkClosed();
/* 1224 */     Clob clob = (Clob)getValue(findColumn(parameterName), JDBCType.CLOB);
/* 1225 */     loggerExternal.exiting(getClassNameLogging(), "getClob", clob);
/* 1226 */     return clob;
/*      */   }
/*      */ 
/*      */   
/*      */   public NClob getNClob(int parameterIndex) throws SQLException {
/* 1231 */     loggerExternal.entering(getClassNameLogging(), "getNClob", Integer.valueOf(parameterIndex));
/* 1232 */     checkClosed();
/* 1233 */     NClob nClob = (NClob)getValue(parameterIndex, JDBCType.NCLOB);
/* 1234 */     loggerExternal.exiting(getClassNameLogging(), "getNClob", nClob);
/* 1235 */     return nClob;
/*      */   }
/*      */ 
/*      */   
/*      */   public NClob getNClob(String parameterName) throws SQLException {
/* 1240 */     loggerExternal.entering(getClassNameLogging(), "getNClob", parameterName);
/* 1241 */     checkClosed();
/* 1242 */     NClob nClob = (NClob)getValue(findColumn(parameterName), JDBCType.NCLOB);
/* 1243 */     loggerExternal.exiting(getClassNameLogging(), "getNClob", nClob);
/* 1244 */     return nClob;
/*      */   }
/*      */ 
/*      */   
/*      */   public Object getObject(int parameterIndex, Map<String, Class<?>> map) throws SQLException {
/* 1249 */     SQLServerException.throwNotSupportedException(this.connection, this);
/* 1250 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public Object getObject(String parameterName, Map<String, Class<?>> m) throws SQLException {
/* 1255 */     checkClosed();
/* 1256 */     return getObject(findColumn(parameterName), m);
/*      */   }
/*      */ 
/*      */   
/*      */   public Ref getRef(int parameterIndex) throws SQLException {
/* 1261 */     SQLServerException.throwNotSupportedException(this.connection, this);
/* 1262 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public Ref getRef(String parameterName) throws SQLException {
/* 1267 */     checkClosed();
/* 1268 */     return getRef(findColumn(parameterName));
/*      */   }
/*      */ 
/*      */   
/*      */   public Array getArray(int parameterIndex) throws SQLException {
/* 1273 */     SQLServerException.throwNotSupportedException(this.connection, this);
/* 1274 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public Array getArray(String parameterName) throws SQLException {
/* 1279 */     checkClosed();
/* 1280 */     return getArray(findColumn(parameterName));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int findColumn(String columnName) throws SQLServerException {
/* 1295 */     if (null == this.parameterNames) {
/* 1296 */       try { SQLServerStatement s = (SQLServerStatement)this.connection.createStatement();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1303 */         try { ThreePartName threePartName = ThreePartName.parse(this.procedureName);
/* 1304 */           StringBuilder metaQuery = new StringBuilder("exec sp_sproc_columns ");
/* 1305 */           if (null != threePartName.getDatabasePart()) {
/* 1306 */             metaQuery.append("@procedure_qualifier=");
/* 1307 */             metaQuery.append(threePartName.getDatabasePart());
/* 1308 */             metaQuery.append(", ");
/*      */           } 
/* 1310 */           if (null != threePartName.getOwnerPart()) {
/* 1311 */             metaQuery.append("@procedure_owner=");
/* 1312 */             metaQuery.append(threePartName.getOwnerPart());
/* 1313 */             metaQuery.append(", ");
/*      */           } 
/* 1315 */           if (null != threePartName.getProcedurePart()) {
/*      */             
/* 1317 */             metaQuery.append("@procedure_name=");
/* 1318 */             metaQuery.append(threePartName.getProcedurePart());
/* 1319 */             metaQuery.append(" , @ODBCVer=3, @fUsePattern=0");
/*      */           
/*      */           }
/*      */           else {
/*      */             
/* 1324 */             MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_parameterNotDefinedForProcedure"));
/* 1325 */             Object[] msgArgs = { columnName, "" };
/* 1326 */             SQLServerException.makeFromDriverError(this.connection, this, form.format(msgArgs), "07009", false);
/*      */           } 
/*      */           
/* 1329 */           ResultSet rs = s.executeQueryInternal(metaQuery.toString()); 
/* 1330 */           try { this.parameterNames = new HashMap<>();
/* 1331 */             this.insensitiveParameterNames = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
/* 1332 */             int columnIndex = 0;
/* 1333 */             while (rs.next()) {
/* 1334 */               String p = rs.getString(4).trim();
/* 1335 */               this.parameterNames.put(p, Integer.valueOf(columnIndex));
/* 1336 */               this.insensitiveParameterNames.put(p, Integer.valueOf(columnIndex++));
/*      */             } 
/* 1338 */             if (rs != null) rs.close();  } catch (Throwable throwable) { if (rs != null)
/* 1339 */               try { rs.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  if (s != null) s.close();  } catch (Throwable throwable) { if (s != null) try { s.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException e)
/* 1340 */       { SQLServerException.makeFromDriverError(this.connection, this, e.toString(), null, false); }
/*      */     
/*      */     }
/*      */ 
/*      */     
/* 1345 */     int l = 0;
/* 1346 */     if (null != this.parameterNames) {
/* 1347 */       l = this.parameterNames.size();
/*      */     }
/* 1349 */     if (l == 0) {
/* 1350 */       this.map.putIfAbsent(columnName, Integer.valueOf(this.ai.incrementAndGet()));
/* 1351 */       return ((Integer)this.map.get(columnName)).intValue();
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1356 */     String columnNameWithSign = columnName.startsWith("@") ? columnName : ("@" + columnName);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1364 */     Integer matchPos = this.parameterNames.get(columnNameWithSign);
/* 1365 */     if (null == matchPos) {
/* 1366 */       matchPos = this.insensitiveParameterNames.get(columnNameWithSign);
/*      */     }
/* 1368 */     if (null == matchPos) {
/*      */       
/* 1370 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_parameterNotDefinedForProcedure"));
/* 1371 */       Object[] msgArgs = { columnName, this.procedureName };
/* 1372 */       SQLServerException.makeFromDriverError(this.connection, this, form.format(msgArgs), "07009", false);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1377 */     if (this.bReturnValueSyntax) {
/* 1378 */       return matchPos.intValue() + 1;
/*      */     }
/* 1380 */     return matchPos.intValue();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimestamp(String parameterName, Timestamp value, Calendar calendar) throws SQLServerException {
/* 1386 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 1387 */       loggerExternal.entering(getClassNameLogging(), "setTimeStamp", new Object[] { parameterName, value, calendar });
/*      */     }
/* 1389 */     checkClosed();
/* 1390 */     setValue(findColumn(parameterName), JDBCType.TIMESTAMP, value, JavaType.TIMESTAMP, calendar, false);
/* 1391 */     loggerExternal.exiting(getClassNameLogging(), "setTimeStamp");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimestamp(String parameterName, Timestamp value, Calendar calendar, boolean forceEncrypt) throws SQLServerException {
/* 1397 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1398 */       loggerExternal.entering(getClassNameLogging(), "setTimeStamp", new Object[] { parameterName, value, calendar, 
/* 1399 */             Boolean.valueOf(forceEncrypt) }); 
/* 1400 */     checkClosed();
/* 1401 */     setValue(findColumn(parameterName), JDBCType.TIMESTAMP, value, JavaType.TIMESTAMP, calendar, forceEncrypt);
/* 1402 */     loggerExternal.exiting(getClassNameLogging(), "setTimeStamp");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setTime(String parameterName, Time value, Calendar calendar) throws SQLServerException {
/* 1407 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1408 */       loggerExternal.entering(getClassNameLogging(), "setTime", new Object[] { parameterName, value, calendar }); 
/* 1409 */     checkClosed();
/* 1410 */     setValue(findColumn(parameterName), JDBCType.TIME, value, JavaType.TIME, calendar, false);
/* 1411 */     loggerExternal.exiting(getClassNameLogging(), "setTime");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTime(String parameterName, Time value, Calendar calendar, boolean forceEncrypt) throws SQLServerException {
/* 1417 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1418 */       loggerExternal.entering(getClassNameLogging(), "setTime", new Object[] { parameterName, value, calendar, 
/* 1419 */             Boolean.valueOf(forceEncrypt) }); 
/* 1420 */     checkClosed();
/* 1421 */     setValue(findColumn(parameterName), JDBCType.TIME, value, JavaType.TIME, calendar, forceEncrypt);
/* 1422 */     loggerExternal.exiting(getClassNameLogging(), "setTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setDate(String parameterName, Date value, Calendar calendar) throws SQLServerException {
/* 1427 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1428 */       loggerExternal.entering(getClassNameLogging(), "setDate", new Object[] { parameterName, value, calendar }); 
/* 1429 */     checkClosed();
/* 1430 */     setValue(findColumn(parameterName), JDBCType.DATE, value, JavaType.DATE, calendar, false);
/* 1431 */     loggerExternal.exiting(getClassNameLogging(), "setDate");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDate(String parameterName, Date value, Calendar calendar, boolean forceEncrypt) throws SQLServerException {
/* 1437 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1438 */       loggerExternal.entering(getClassNameLogging(), "setDate", new Object[] { parameterName, value, calendar, 
/* 1439 */             Boolean.valueOf(forceEncrypt) }); 
/* 1440 */     checkClosed();
/* 1441 */     setValue(findColumn(parameterName), JDBCType.DATE, value, JavaType.DATE, calendar, forceEncrypt);
/* 1442 */     loggerExternal.exiting(getClassNameLogging(), "setDate");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setCharacterStream(String parameterName, Reader reader) throws SQLException {
/* 1447 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1448 */       loggerExternal.entering(getClassNameLogging(), "setCharacterStream", new Object[] { parameterName, reader }); 
/* 1449 */     checkClosed();
/* 1450 */     setStream(findColumn(parameterName), StreamType.CHARACTER, reader, JavaType.READER, -1L);
/*      */     
/* 1452 */     loggerExternal.exiting(getClassNameLogging(), "setCharacterStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setCharacterStream(String parameterName, Reader value, int length) throws SQLException {
/* 1457 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1458 */       loggerExternal.entering(getClassNameLogging(), "setCharacterStream", new Object[] { parameterName, value, 
/* 1459 */             Integer.valueOf(length) }); 
/* 1460 */     checkClosed();
/* 1461 */     setStream(findColumn(parameterName), StreamType.CHARACTER, value, JavaType.READER, length);
/* 1462 */     loggerExternal.exiting(getClassNameLogging(), "setCharacterStream");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setCharacterStream(String parameterName, Reader reader, long length) throws SQLException {
/* 1468 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1469 */       loggerExternal.entering(getClassNameLogging(), "setCharacterStream", new Object[] { parameterName, reader, 
/* 1470 */             Long.valueOf(length) }); 
/* 1471 */     checkClosed();
/* 1472 */     setStream(findColumn(parameterName), StreamType.CHARACTER, reader, JavaType.READER, length);
/* 1473 */     loggerExternal.exiting(getClassNameLogging(), "setCharacterStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setNCharacterStream(String parameterName, Reader value) throws SQLException {
/* 1478 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1479 */       loggerExternal.entering(getClassNameLogging(), "setNCharacterStream", new Object[] { parameterName, value }); 
/* 1480 */     checkClosed();
/* 1481 */     setStream(findColumn(parameterName), StreamType.NCHARACTER, value, JavaType.READER, -1L);
/*      */     
/* 1483 */     loggerExternal.exiting(getClassNameLogging(), "setNCharacterStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setNCharacterStream(String parameterName, Reader value, long length) throws SQLException {
/* 1488 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1489 */       loggerExternal.entering(getClassNameLogging(), "setNCharacterStream", new Object[] { parameterName, value, 
/* 1490 */             Long.valueOf(length) }); 
/* 1491 */     checkClosed();
/* 1492 */     setStream(findColumn(parameterName), StreamType.NCHARACTER, value, JavaType.READER, length);
/* 1493 */     loggerExternal.exiting(getClassNameLogging(), "setNCharacterStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setClob(String parameterName, Clob value) throws SQLException {
/* 1498 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1499 */       loggerExternal.entering(getClassNameLogging(), "setClob", new Object[] { parameterName, value }); 
/* 1500 */     checkClosed();
/* 1501 */     setValue(findColumn(parameterName), JDBCType.CLOB, value, JavaType.CLOB, false);
/* 1502 */     loggerExternal.exiting(getClassNameLogging(), "setClob");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setClob(String parameterName, Reader reader) throws SQLException {
/* 1507 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1508 */       loggerExternal.entering(getClassNameLogging(), "setClob", new Object[] { parameterName, reader }); 
/* 1509 */     checkClosed();
/* 1510 */     setStream(findColumn(parameterName), StreamType.CHARACTER, reader, JavaType.READER, -1L);
/*      */     
/* 1512 */     loggerExternal.exiting(getClassNameLogging(), "setClob");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setClob(String parameterName, Reader value, long length) throws SQLException {
/* 1517 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1518 */       loggerExternal.entering(getClassNameLogging(), "setClob", new Object[] { parameterName, value, Long.valueOf(length) }); 
/* 1519 */     checkClosed();
/* 1520 */     setStream(findColumn(parameterName), StreamType.CHARACTER, value, JavaType.READER, length);
/* 1521 */     loggerExternal.exiting(getClassNameLogging(), "setClob");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setNClob(String parameterName, NClob value) throws SQLException {
/* 1526 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1527 */       loggerExternal.entering(getClassNameLogging(), "setNClob", new Object[] { parameterName, value }); 
/* 1528 */     checkClosed();
/* 1529 */     setValue(findColumn(parameterName), JDBCType.NCLOB, value, JavaType.NCLOB, false);
/* 1530 */     loggerExternal.exiting(getClassNameLogging(), "setNClob");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setNClob(String parameterName, Reader reader) throws SQLException {
/* 1535 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1536 */       loggerExternal.entering(getClassNameLogging(), "setNClob", new Object[] { parameterName, reader }); 
/* 1537 */     checkClosed();
/* 1538 */     setStream(findColumn(parameterName), StreamType.NCHARACTER, reader, JavaType.READER, -1L);
/*      */     
/* 1540 */     loggerExternal.exiting(getClassNameLogging(), "setNClob");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setNClob(String parameterName, Reader reader, long length) throws SQLException {
/* 1545 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1546 */       loggerExternal.entering(getClassNameLogging(), "setNClob", new Object[] { parameterName, reader, Long.valueOf(length) }); 
/* 1547 */     checkClosed();
/* 1548 */     setStream(findColumn(parameterName), StreamType.NCHARACTER, reader, JavaType.READER, length);
/* 1549 */     loggerExternal.exiting(getClassNameLogging(), "setNClob");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setNString(String parameterName, String value) throws SQLException {
/* 1554 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1555 */       loggerExternal.entering(getClassNameLogging(), "setNString", new Object[] { parameterName, value }); 
/* 1556 */     checkClosed();
/* 1557 */     setValue(findColumn(parameterName), JDBCType.NVARCHAR, value, JavaType.STRING, false);
/* 1558 */     loggerExternal.exiting(getClassNameLogging(), "setNString");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setNString(String parameterName, String value, boolean forceEncrypt) throws SQLServerException {
/* 1563 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1564 */       loggerExternal.entering(getClassNameLogging(), "setNString", new Object[] { parameterName, value, 
/* 1565 */             Boolean.valueOf(forceEncrypt) }); 
/* 1566 */     checkClosed();
/* 1567 */     setValue(findColumn(parameterName), JDBCType.NVARCHAR, value, JavaType.STRING, forceEncrypt);
/* 1568 */     loggerExternal.exiting(getClassNameLogging(), "setNString");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setObject(String parameterName, Object value) throws SQLServerException {
/* 1573 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1574 */       loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] { parameterName, value }); 
/* 1575 */     checkClosed();
/* 1576 */     setObjectNoType(findColumn(parameterName), value, false);
/* 1577 */     loggerExternal.exiting(getClassNameLogging(), "setObject");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setObject(String parameterName, Object value, int sqlType) throws SQLServerException {
/* 1582 */     String tvpName = null;
/* 1583 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1584 */       loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] { parameterName, value, Integer.valueOf(sqlType) }); 
/* 1585 */     checkClosed();
/* 1586 */     if (-153 == sqlType) {
/* 1587 */       tvpName = getTVPNameFromObject(findColumn(parameterName), value);
/* 1588 */       setObject(setterGetParam(findColumn(parameterName)), value, JavaType.TVP, JDBCType.TVP, (Integer)null, (Integer)null, false, 
/* 1589 */           findColumn(parameterName), tvpName);
/*      */     } else {
/* 1591 */       setObject(setterGetParam(findColumn(parameterName)), value, JavaType.of(value), JDBCType.of(sqlType), (Integer)null, (Integer)null, false, 
/* 1592 */           findColumn(parameterName), tvpName);
/* 1593 */     }  loggerExternal.exiting(getClassNameLogging(), "setObject");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setObject(String parameterName, Object value, int sqlType, int decimals) throws SQLServerException {
/* 1598 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1599 */       loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] { parameterName, value, 
/* 1600 */             Integer.valueOf(sqlType), Integer.valueOf(decimals) }); 
/* 1601 */     checkClosed();
/* 1602 */     setObject(setterGetParam(findColumn(parameterName)), value, JavaType.of(value), JDBCType.of(sqlType), Integer.valueOf(decimals), (Integer)null, false, 
/* 1603 */         findColumn(parameterName), (String)null);
/* 1604 */     loggerExternal.exiting(getClassNameLogging(), "setObject");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(String parameterName, Object value, int sqlType, int decimals, boolean forceEncrypt) throws SQLServerException {
/* 1610 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1611 */       loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] { parameterName, value, 
/* 1612 */             Integer.valueOf(sqlType), Integer.valueOf(decimals), Boolean.valueOf(forceEncrypt) }); 
/* 1613 */     checkClosed();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1619 */     setObject(setterGetParam(findColumn(parameterName)), value, JavaType.of(value), JDBCType.of(sqlType), (
/* 1620 */         2 == sqlType || 3 == sqlType) ? Integer.valueOf(decimals) : null, (Integer)null, forceEncrypt, 
/* 1621 */         findColumn(parameterName), (String)null);
/*      */     
/* 1623 */     loggerExternal.exiting(getClassNameLogging(), "setObject");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setObject(String parameterName, Object value, int targetSqlType, Integer precision, int scale) throws SQLServerException {
/* 1629 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1630 */       loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] { parameterName, value, 
/* 1631 */             Integer.valueOf(targetSqlType), precision, Integer.valueOf(scale) }); 
/* 1632 */     checkClosed();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1639 */     setObject(setterGetParam(findColumn(parameterName)), value, JavaType.of(value), JDBCType.of(targetSqlType), (
/* 1640 */         2 == targetSqlType || 3 == targetSqlType || InputStream.class
/* 1641 */         .isInstance(value) || Reader.class.isInstance(value)) ? Integer.valueOf(scale) : null, precision, false, 
/* 1642 */         findColumn(parameterName), (String)null);
/*      */     
/* 1644 */     loggerExternal.exiting(getClassNameLogging(), "setObject");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setAsciiStream(String parameterName, InputStream value) throws SQLException {
/* 1649 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1650 */       loggerExternal.entering(getClassNameLogging(), "setAsciiStream", new Object[] { parameterName, value }); 
/* 1651 */     checkClosed();
/* 1652 */     setStream(findColumn(parameterName), StreamType.ASCII, value, JavaType.INPUTSTREAM, -1L);
/*      */     
/* 1654 */     loggerExternal.exiting(getClassNameLogging(), "setAsciiStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setAsciiStream(String parameterName, InputStream value, int length) throws SQLException {
/* 1659 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1660 */       loggerExternal.entering(getClassNameLogging(), "setAsciiStream", new Object[] { parameterName, value, 
/* 1661 */             Integer.valueOf(length) }); 
/* 1662 */     checkClosed();
/* 1663 */     setStream(findColumn(parameterName), StreamType.ASCII, value, JavaType.INPUTSTREAM, length);
/* 1664 */     loggerExternal.exiting(getClassNameLogging(), "setAsciiStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setAsciiStream(String parameterName, InputStream value, long length) throws SQLException {
/* 1669 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1670 */       loggerExternal.entering(getClassNameLogging(), "setAsciiStream", new Object[] { parameterName, value, 
/* 1671 */             Long.valueOf(length) }); 
/* 1672 */     checkClosed();
/* 1673 */     setStream(findColumn(parameterName), StreamType.ASCII, value, JavaType.INPUTSTREAM, length);
/* 1674 */     loggerExternal.exiting(getClassNameLogging(), "setAsciiStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setBinaryStream(String parameterName, InputStream value) throws SQLException {
/* 1679 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1680 */       loggerExternal.entering(getClassNameLogging(), "setBinaryStream", new Object[] { parameterName, value }); 
/* 1681 */     checkClosed();
/* 1682 */     setStream(findColumn(parameterName), StreamType.BINARY, value, JavaType.INPUTSTREAM, -1L);
/*      */     
/* 1684 */     loggerExternal.exiting(getClassNameLogging(), "setBinaryStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setBinaryStream(String parameterName, InputStream value, int length) throws SQLException {
/* 1689 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1690 */       loggerExternal.entering(getClassNameLogging(), "setBinaryStream", new Object[] { parameterName, value, 
/* 1691 */             Integer.valueOf(length) }); 
/* 1692 */     checkClosed();
/* 1693 */     setStream(findColumn(parameterName), StreamType.BINARY, value, JavaType.INPUTSTREAM, length);
/* 1694 */     loggerExternal.exiting(getClassNameLogging(), "setBinaryStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setBinaryStream(String parameterName, InputStream value, long length) throws SQLException {
/* 1699 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1700 */       loggerExternal.entering(getClassNameLogging(), "setBinaryStream", new Object[] { parameterName, value, 
/* 1701 */             Long.valueOf(length) }); 
/* 1702 */     checkClosed();
/* 1703 */     setStream(findColumn(parameterName), StreamType.BINARY, value, JavaType.INPUTSTREAM, length);
/* 1704 */     loggerExternal.exiting(getClassNameLogging(), "setBinaryStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setBlob(String parameterName, Blob inputStream) throws SQLException {
/* 1709 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1710 */       loggerExternal.entering(getClassNameLogging(), "setBlob", new Object[] { parameterName, inputStream }); 
/* 1711 */     checkClosed();
/* 1712 */     setValue(findColumn(parameterName), JDBCType.BLOB, inputStream, JavaType.BLOB, false);
/* 1713 */     loggerExternal.exiting(getClassNameLogging(), "setBlob");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setBlob(String parameterName, InputStream value) throws SQLException {
/* 1718 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1719 */       loggerExternal.entering(getClassNameLogging(), "setBlob", new Object[] { parameterName, value }); 
/* 1720 */     checkClosed();
/* 1721 */     setStream(findColumn(parameterName), StreamType.BINARY, value, JavaType.INPUTSTREAM, -1L);
/*      */     
/* 1723 */     loggerExternal.exiting(getClassNameLogging(), "setBlob");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setBlob(String parameterName, InputStream inputStream, long length) throws SQLException {
/* 1728 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1729 */       loggerExternal.entering(getClassNameLogging(), "setBlob", new Object[] { parameterName, inputStream, 
/* 1730 */             Long.valueOf(length) }); 
/* 1731 */     checkClosed();
/* 1732 */     setStream(findColumn(parameterName), StreamType.BINARY, inputStream, JavaType.INPUTSTREAM, length);
/* 1733 */     loggerExternal.exiting(getClassNameLogging(), "setBlob");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setTimestamp(String parameterName, Timestamp value) throws SQLServerException {
/* 1738 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1739 */       loggerExternal.entering(getClassNameLogging(), "setTimestamp", new Object[] { parameterName, value }); 
/* 1740 */     checkClosed();
/* 1741 */     setValue(findColumn(parameterName), JDBCType.TIMESTAMP, value, JavaType.TIMESTAMP, false);
/* 1742 */     loggerExternal.exiting(getClassNameLogging(), "setTimestamp");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setTimestamp(String parameterName, Timestamp value, int scale) throws SQLServerException {
/* 1747 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1748 */       loggerExternal.entering(getClassNameLogging(), "setTimestamp", new Object[] { parameterName, value }); 
/* 1749 */     checkClosed();
/* 1750 */     setValue(findColumn(parameterName), JDBCType.TIMESTAMP, value, JavaType.TIMESTAMP, (Integer)null, Integer.valueOf(scale), false);
/* 1751 */     loggerExternal.exiting(getClassNameLogging(), "setTimestamp");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimestamp(String parameterName, Timestamp value, int scale, boolean forceEncrypt) throws SQLServerException {
/* 1757 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1758 */       loggerExternal.entering(getClassNameLogging(), "setTimestamp", new Object[] { parameterName, value, 
/* 1759 */             Boolean.valueOf(forceEncrypt) }); 
/* 1760 */     checkClosed();
/* 1761 */     setValue(findColumn(parameterName), JDBCType.TIMESTAMP, value, JavaType.TIMESTAMP, (Integer)null, Integer.valueOf(scale), forceEncrypt);
/* 1762 */     loggerExternal.exiting(getClassNameLogging(), "setTimestamp");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setDateTimeOffset(String parameterName, DateTimeOffset value) throws SQLServerException {
/* 1767 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1768 */       loggerExternal.entering(getClassNameLogging(), "setDateTimeOffset", new Object[] { parameterName, value }); 
/* 1769 */     checkClosed();
/* 1770 */     setValue(findColumn(parameterName), JDBCType.DATETIMEOFFSET, value, JavaType.DATETIMEOFFSET, false);
/* 1771 */     loggerExternal.exiting(getClassNameLogging(), "setDateTimeOffset");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDateTimeOffset(String parameterName, DateTimeOffset value, int scale) throws SQLServerException {
/* 1777 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1778 */       loggerExternal.entering(getClassNameLogging(), "setDateTimeOffset", new Object[] { parameterName, value }); 
/* 1779 */     checkClosed();
/* 1780 */     setValue(findColumn(parameterName), JDBCType.DATETIMEOFFSET, value, JavaType.DATETIMEOFFSET, (Integer)null, Integer.valueOf(scale), false);
/*      */     
/* 1782 */     loggerExternal.exiting(getClassNameLogging(), "setDateTimeOffset");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDateTimeOffset(String parameterName, DateTimeOffset value, int scale, boolean forceEncrypt) throws SQLServerException {
/* 1788 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1789 */       loggerExternal.entering(getClassNameLogging(), "setDateTimeOffset", new Object[] { parameterName, value, 
/* 1790 */             Boolean.valueOf(forceEncrypt) }); 
/* 1791 */     checkClosed();
/* 1792 */     setValue(findColumn(parameterName), JDBCType.DATETIMEOFFSET, value, JavaType.DATETIMEOFFSET, (Integer)null, Integer.valueOf(scale), forceEncrypt);
/*      */     
/* 1794 */     loggerExternal.exiting(getClassNameLogging(), "setDateTimeOffset");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setDate(String parameterName, Date value) throws SQLServerException {
/* 1799 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1800 */       loggerExternal.entering(getClassNameLogging(), "setDate", new Object[] { parameterName, value }); 
/* 1801 */     checkClosed();
/* 1802 */     setValue(findColumn(parameterName), JDBCType.DATE, value, JavaType.DATE, false);
/* 1803 */     loggerExternal.exiting(getClassNameLogging(), "setDate");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setTime(String parameterName, Time value) throws SQLServerException {
/* 1808 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1809 */       loggerExternal.entering(getClassNameLogging(), "setTime", new Object[] { parameterName, value }); 
/* 1810 */     checkClosed();
/* 1811 */     setValue(findColumn(parameterName), JDBCType.TIME, value, JavaType.TIME, false);
/* 1812 */     loggerExternal.exiting(getClassNameLogging(), "setTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setTime(String parameterName, Time value, int scale) throws SQLServerException {
/* 1817 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1818 */       loggerExternal.entering(getClassNameLogging(), "setTime", new Object[] { parameterName, value }); 
/* 1819 */     checkClosed();
/* 1820 */     setValue(findColumn(parameterName), JDBCType.TIME, value, JavaType.TIME, (Integer)null, Integer.valueOf(scale), false);
/* 1821 */     loggerExternal.exiting(getClassNameLogging(), "setTime");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTime(String parameterName, Time value, int scale, boolean forceEncrypt) throws SQLServerException {
/* 1827 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1828 */       loggerExternal.entering(getClassNameLogging(), "setTime", new Object[] { parameterName, value, 
/* 1829 */             Boolean.valueOf(forceEncrypt) }); 
/* 1830 */     checkClosed();
/* 1831 */     setValue(findColumn(parameterName), JDBCType.TIME, value, JavaType.TIME, (Integer)null, Integer.valueOf(scale), forceEncrypt);
/* 1832 */     loggerExternal.exiting(getClassNameLogging(), "setTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setDateTime(String parameterName, Timestamp value) throws SQLServerException {
/* 1837 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1838 */       loggerExternal.entering(getClassNameLogging(), "setDateTime", new Object[] { parameterName, value }); 
/* 1839 */     checkClosed();
/* 1840 */     setValue(findColumn(parameterName), JDBCType.DATETIME, value, JavaType.TIMESTAMP, false);
/* 1841 */     loggerExternal.exiting(getClassNameLogging(), "setDateTime");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDateTime(String parameterName, Timestamp value, boolean forceEncrypt) throws SQLServerException {
/* 1847 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1848 */       loggerExternal.entering(getClassNameLogging(), "setDateTime", new Object[] { parameterName, value, 
/* 1849 */             Boolean.valueOf(forceEncrypt) }); 
/* 1850 */     checkClosed();
/* 1851 */     setValue(findColumn(parameterName), JDBCType.DATETIME, value, JavaType.TIMESTAMP, forceEncrypt);
/* 1852 */     loggerExternal.exiting(getClassNameLogging(), "setDateTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setSmallDateTime(String parameterName, Timestamp value) throws SQLServerException {
/* 1857 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1858 */       loggerExternal.entering(getClassNameLogging(), "setSmallDateTime", new Object[] { parameterName, value }); 
/* 1859 */     checkClosed();
/* 1860 */     setValue(findColumn(parameterName), JDBCType.SMALLDATETIME, value, JavaType.TIMESTAMP, false);
/* 1861 */     loggerExternal.exiting(getClassNameLogging(), "setSmallDateTime");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSmallDateTime(String parameterName, Timestamp value, boolean forceEncrypt) throws SQLServerException {
/* 1867 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1868 */       loggerExternal.entering(getClassNameLogging(), "setSmallDateTime", new Object[] { parameterName, value, 
/* 1869 */             Boolean.valueOf(forceEncrypt) }); 
/* 1870 */     checkClosed();
/* 1871 */     setValue(findColumn(parameterName), JDBCType.SMALLDATETIME, value, JavaType.TIMESTAMP, forceEncrypt);
/* 1872 */     loggerExternal.exiting(getClassNameLogging(), "setSmallDateTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setUniqueIdentifier(String parameterName, String guid) throws SQLServerException {
/* 1877 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1878 */       loggerExternal.entering(getClassNameLogging(), "setUniqueIdentifier", new Object[] { parameterName, guid }); 
/* 1879 */     checkClosed();
/* 1880 */     setValue(findColumn(parameterName), JDBCType.GUID, guid, JavaType.STRING, false);
/* 1881 */     loggerExternal.exiting(getClassNameLogging(), "setUniqueIdentifier");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setUniqueIdentifier(String parameterName, String guid, boolean forceEncrypt) throws SQLServerException {
/* 1886 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1887 */       loggerExternal.entering(getClassNameLogging(), "setUniqueIdentifier", new Object[] { parameterName, guid, 
/* 1888 */             Boolean.valueOf(forceEncrypt) }); 
/* 1889 */     checkClosed();
/* 1890 */     setValue(findColumn(parameterName), JDBCType.GUID, guid, JavaType.STRING, forceEncrypt);
/* 1891 */     loggerExternal.exiting(getClassNameLogging(), "setUniqueIdentifier");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setBytes(String parameterName, byte[] value) throws SQLServerException {
/* 1896 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1897 */       loggerExternal.entering(getClassNameLogging(), "setBytes", new Object[] { parameterName, value }); 
/* 1898 */     checkClosed();
/* 1899 */     setValue(findColumn(parameterName), JDBCType.BINARY, value, JavaType.BYTEARRAY, false);
/* 1900 */     loggerExternal.exiting(getClassNameLogging(), "setBytes");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setBytes(String parameterName, byte[] value, boolean forceEncrypt) throws SQLServerException {
/* 1905 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1906 */       loggerExternal.entering(getClassNameLogging(), "setBytes", new Object[] { parameterName, value, 
/* 1907 */             Boolean.valueOf(forceEncrypt) }); 
/* 1908 */     checkClosed();
/* 1909 */     setValue(findColumn(parameterName), JDBCType.BINARY, value, JavaType.BYTEARRAY, forceEncrypt);
/* 1910 */     loggerExternal.exiting(getClassNameLogging(), "setBytes");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setByte(String parameterName, byte value) throws SQLServerException {
/* 1915 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1916 */       loggerExternal.entering(getClassNameLogging(), "setByte", new Object[] { parameterName, Byte.valueOf(value) }); 
/* 1917 */     checkClosed();
/* 1918 */     setValue(findColumn(parameterName), JDBCType.TINYINT, Byte.valueOf(value), JavaType.BYTE, false);
/* 1919 */     loggerExternal.exiting(getClassNameLogging(), "setByte");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setByte(String parameterName, byte value, boolean forceEncrypt) throws SQLServerException {
/* 1924 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1925 */       loggerExternal.entering(getClassNameLogging(), "setByte", new Object[] { parameterName, 
/* 1926 */             Byte.valueOf(value), Boolean.valueOf(forceEncrypt) }); 
/* 1927 */     checkClosed();
/* 1928 */     setValue(findColumn(parameterName), JDBCType.TINYINT, Byte.valueOf(value), JavaType.BYTE, forceEncrypt);
/* 1929 */     loggerExternal.exiting(getClassNameLogging(), "setByte");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setString(String parameterName, String value) throws SQLServerException {
/* 1934 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1935 */       loggerExternal.entering(getClassNameLogging(), "setString", new Object[] { parameterName, value }); 
/* 1936 */     checkClosed();
/* 1937 */     setValue(findColumn(parameterName), JDBCType.VARCHAR, value, JavaType.STRING, false);
/* 1938 */     loggerExternal.exiting(getClassNameLogging(), "setString");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setString(String parameterName, String value, boolean forceEncrypt) throws SQLServerException {
/* 1943 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1944 */       loggerExternal.entering(getClassNameLogging(), "setString", new Object[] { parameterName, value, 
/* 1945 */             Boolean.valueOf(forceEncrypt) }); 
/* 1946 */     checkClosed();
/* 1947 */     setValue(findColumn(parameterName), JDBCType.VARCHAR, value, JavaType.STRING, forceEncrypt);
/* 1948 */     loggerExternal.exiting(getClassNameLogging(), "setString");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setMoney(String parameterName, BigDecimal value) throws SQLServerException {
/* 1953 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1954 */       loggerExternal.entering(getClassNameLogging(), "setMoney", new Object[] { parameterName, value }); 
/* 1955 */     checkClosed();
/* 1956 */     setValue(findColumn(parameterName), JDBCType.MONEY, value, JavaType.BIGDECIMAL, false);
/* 1957 */     loggerExternal.exiting(getClassNameLogging(), "setMoney");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setMoney(String parameterName, BigDecimal value, boolean forceEncrypt) throws SQLServerException {
/* 1962 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1963 */       loggerExternal.entering(getClassNameLogging(), "setMoney", new Object[] { parameterName, value, 
/* 1964 */             Boolean.valueOf(forceEncrypt) }); 
/* 1965 */     checkClosed();
/* 1966 */     setValue(findColumn(parameterName), JDBCType.MONEY, value, JavaType.BIGDECIMAL, forceEncrypt);
/* 1967 */     loggerExternal.exiting(getClassNameLogging(), "setMoney");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setSmallMoney(String parameterName, BigDecimal value) throws SQLServerException {
/* 1972 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1973 */       loggerExternal.entering(getClassNameLogging(), "setSmallMoney", new Object[] { parameterName, value }); 
/* 1974 */     checkClosed();
/* 1975 */     setValue(findColumn(parameterName), JDBCType.SMALLMONEY, value, JavaType.BIGDECIMAL, false);
/* 1976 */     loggerExternal.exiting(getClassNameLogging(), "setSmallMoney");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setSmallMoney(String parameterName, BigDecimal value, boolean forceEncrypt) throws SQLServerException {
/* 1981 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1982 */       loggerExternal.entering(getClassNameLogging(), "setSmallMoney", new Object[] { parameterName, value, 
/* 1983 */             Boolean.valueOf(forceEncrypt) }); 
/* 1984 */     checkClosed();
/* 1985 */     setValue(findColumn(parameterName), JDBCType.SMALLMONEY, value, JavaType.BIGDECIMAL, forceEncrypt);
/* 1986 */     loggerExternal.exiting(getClassNameLogging(), "setSmallMoney");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setBigDecimal(String parameterName, BigDecimal value) throws SQLServerException {
/* 1991 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1992 */       loggerExternal.entering(getClassNameLogging(), "setBigDecimal", new Object[] { parameterName, value }); 
/* 1993 */     checkClosed();
/* 1994 */     setValue(findColumn(parameterName), JDBCType.DECIMAL, value, JavaType.BIGDECIMAL, false);
/* 1995 */     loggerExternal.exiting(getClassNameLogging(), "setBigDecimal");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBigDecimal(String parameterName, BigDecimal value, int precision, int scale) throws SQLServerException {
/* 2001 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2002 */       loggerExternal.entering(getClassNameLogging(), "setBigDecimal", new Object[] { parameterName, value, 
/* 2003 */             Integer.valueOf(precision), Integer.valueOf(scale) }); 
/* 2004 */     checkClosed();
/* 2005 */     setValue(findColumn(parameterName), JDBCType.DECIMAL, value, JavaType.BIGDECIMAL, Integer.valueOf(precision), Integer.valueOf(scale), false);
/* 2006 */     loggerExternal.exiting(getClassNameLogging(), "setBigDecimal");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBigDecimal(String parameterName, BigDecimal value, int precision, int scale, boolean forceEncrypt) throws SQLServerException {
/* 2012 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2013 */       loggerExternal.entering(getClassNameLogging(), "setBigDecimal", new Object[] { parameterName, value, 
/* 2014 */             Integer.valueOf(precision), Integer.valueOf(scale), Boolean.valueOf(forceEncrypt) }); 
/* 2015 */     checkClosed();
/* 2016 */     setValue(findColumn(parameterName), JDBCType.DECIMAL, value, JavaType.BIGDECIMAL, Integer.valueOf(precision), Integer.valueOf(scale), forceEncrypt);
/*      */     
/* 2018 */     loggerExternal.exiting(getClassNameLogging(), "setBigDecimal");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setDouble(String parameterName, double value) throws SQLServerException {
/* 2023 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2024 */       loggerExternal.entering(getClassNameLogging(), "setDouble", new Object[] { parameterName, Double.valueOf(value) }); 
/* 2025 */     checkClosed();
/* 2026 */     setValue(findColumn(parameterName), JDBCType.DOUBLE, Double.valueOf(value), JavaType.DOUBLE, false);
/* 2027 */     loggerExternal.exiting(getClassNameLogging(), "setDouble");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setDouble(String parameterName, double value, boolean forceEncrypt) throws SQLServerException {
/* 2032 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2033 */       loggerExternal.entering(getClassNameLogging(), "setDouble", new Object[] { parameterName, 
/* 2034 */             Double.valueOf(value), Boolean.valueOf(forceEncrypt) }); 
/* 2035 */     checkClosed();
/* 2036 */     setValue(findColumn(parameterName), JDBCType.DOUBLE, Double.valueOf(value), JavaType.DOUBLE, forceEncrypt);
/* 2037 */     loggerExternal.exiting(getClassNameLogging(), "setDouble");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setFloat(String parameterName, float value) throws SQLServerException {
/* 2042 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2043 */       loggerExternal.entering(getClassNameLogging(), "setFloat", new Object[] { parameterName, Float.valueOf(value) }); 
/* 2044 */     checkClosed();
/* 2045 */     setValue(findColumn(parameterName), JDBCType.REAL, Float.valueOf(value), JavaType.FLOAT, false);
/* 2046 */     loggerExternal.exiting(getClassNameLogging(), "setFloat");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setFloat(String parameterName, float value, boolean forceEncrypt) throws SQLServerException {
/* 2051 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2052 */       loggerExternal.entering(getClassNameLogging(), "setFloat", new Object[] { parameterName, 
/* 2053 */             Float.valueOf(value), Boolean.valueOf(forceEncrypt) }); 
/* 2054 */     checkClosed();
/* 2055 */     setValue(findColumn(parameterName), JDBCType.REAL, Float.valueOf(value), JavaType.FLOAT, forceEncrypt);
/* 2056 */     loggerExternal.exiting(getClassNameLogging(), "setFloat");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setInt(String parameterName, int value) throws SQLServerException {
/* 2061 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2062 */       loggerExternal.entering(getClassNameLogging(), "setInt", new Object[] { parameterName, Integer.valueOf(value) }); 
/* 2063 */     checkClosed();
/* 2064 */     setValue(findColumn(parameterName), JDBCType.INTEGER, Integer.valueOf(value), JavaType.INTEGER, false);
/* 2065 */     loggerExternal.exiting(getClassNameLogging(), "setInt");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setInt(String parameterName, int value, boolean forceEncrypt) throws SQLServerException {
/* 2070 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2071 */       loggerExternal.entering(getClassNameLogging(), "setInt", new Object[] { parameterName, Integer.valueOf(value), Boolean.valueOf(forceEncrypt) }); 
/* 2072 */     checkClosed();
/* 2073 */     setValue(findColumn(parameterName), JDBCType.INTEGER, Integer.valueOf(value), JavaType.INTEGER, forceEncrypt);
/* 2074 */     loggerExternal.exiting(getClassNameLogging(), "setInt");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setLong(String parameterName, long value) throws SQLServerException {
/* 2079 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2080 */       loggerExternal.entering(getClassNameLogging(), "setLong", new Object[] { parameterName, Long.valueOf(value) }); 
/* 2081 */     checkClosed();
/* 2082 */     setValue(findColumn(parameterName), JDBCType.BIGINT, Long.valueOf(value), JavaType.LONG, false);
/* 2083 */     loggerExternal.exiting(getClassNameLogging(), "setLong");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setLong(String parameterName, long value, boolean forceEncrypt) throws SQLServerException {
/* 2088 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2089 */       loggerExternal.entering(getClassNameLogging(), "setLong", new Object[] { parameterName, 
/* 2090 */             Long.valueOf(value), Boolean.valueOf(forceEncrypt) }); 
/* 2091 */     checkClosed();
/* 2092 */     setValue(findColumn(parameterName), JDBCType.BIGINT, Long.valueOf(value), JavaType.LONG, forceEncrypt);
/* 2093 */     loggerExternal.exiting(getClassNameLogging(), "setLong");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setShort(String parameterName, short value) throws SQLServerException {
/* 2098 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2099 */       loggerExternal.entering(getClassNameLogging(), "setShort", new Object[] { parameterName, Short.valueOf(value) }); 
/* 2100 */     checkClosed();
/* 2101 */     setValue(findColumn(parameterName), JDBCType.SMALLINT, Short.valueOf(value), JavaType.SHORT, false);
/* 2102 */     loggerExternal.exiting(getClassNameLogging(), "setShort");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setShort(String parameterName, short value, boolean forceEncrypt) throws SQLServerException {
/* 2107 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2108 */       loggerExternal.entering(getClassNameLogging(), "setShort", new Object[] { parameterName, 
/* 2109 */             Short.valueOf(value), Boolean.valueOf(forceEncrypt) }); 
/* 2110 */     checkClosed();
/* 2111 */     setValue(findColumn(parameterName), JDBCType.SMALLINT, Short.valueOf(value), JavaType.SHORT, forceEncrypt);
/* 2112 */     loggerExternal.exiting(getClassNameLogging(), "setShort");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setBoolean(String parameterName, boolean value) throws SQLServerException {
/* 2117 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2118 */       loggerExternal.entering(getClassNameLogging(), "setBoolean", new Object[] { parameterName, Boolean.valueOf(value) }); 
/* 2119 */     checkClosed();
/* 2120 */     setValue(findColumn(parameterName), JDBCType.BIT, Boolean.valueOf(value), JavaType.BOOLEAN, false);
/* 2121 */     loggerExternal.exiting(getClassNameLogging(), "setBoolean");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setBoolean(String parameterName, boolean value, boolean forceEncrypt) throws SQLServerException {
/* 2126 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2127 */       loggerExternal.entering(getClassNameLogging(), "setBoolean", new Object[] { parameterName, 
/* 2128 */             Boolean.valueOf(value), Boolean.valueOf(forceEncrypt) }); 
/* 2129 */     checkClosed();
/* 2130 */     setValue(findColumn(parameterName), JDBCType.BIT, Boolean.valueOf(value), JavaType.BOOLEAN, forceEncrypt);
/* 2131 */     loggerExternal.exiting(getClassNameLogging(), "setBoolean");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setNull(String parameterName, int nType) throws SQLServerException {
/* 2136 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2137 */       loggerExternal.entering(getClassNameLogging(), "setNull", new Object[] { parameterName, Integer.valueOf(nType) }); 
/* 2138 */     checkClosed();
/* 2139 */     setObject(setterGetParam(findColumn(parameterName)), (Object)null, JavaType.OBJECT, JDBCType.of(nType), (Integer)null, (Integer)null, false, 
/* 2140 */         findColumn(parameterName), (String)null);
/* 2141 */     loggerExternal.exiting(getClassNameLogging(), "setNull");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setNull(String parameterName, int nType, String sTypeName) throws SQLServerException {
/* 2146 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2147 */       loggerExternal.entering(getClassNameLogging(), "setNull", new Object[] { parameterName, Integer.valueOf(nType), sTypeName }); 
/* 2148 */     checkClosed();
/* 2149 */     setObject(setterGetParam(findColumn(parameterName)), (Object)null, JavaType.OBJECT, JDBCType.of(nType), (Integer)null, (Integer)null, false, 
/* 2150 */         findColumn(parameterName), sTypeName);
/* 2151 */     loggerExternal.exiting(getClassNameLogging(), "setNull");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setURL(String parameterName, URL url) throws SQLException {
/* 2156 */     loggerExternal.entering(getClassNameLogging(), "setURL", parameterName);
/* 2157 */     checkClosed();
/* 2158 */     setURL(findColumn(parameterName), url);
/* 2159 */     loggerExternal.exiting(getClassNameLogging(), "setURL");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setStructured(String parameterName, String tvpName, SQLServerDataTable tvpDataTable) throws SQLServerException {
/* 2165 */     tvpName = getTVPNameIfNull(findColumn(parameterName), tvpName);
/* 2166 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 2167 */       loggerExternal.entering(getClassNameLogging(), "setStructured", new Object[] { parameterName, tvpName, tvpDataTable });
/*      */     }
/* 2169 */     checkClosed();
/* 2170 */     setValue(findColumn(parameterName), JDBCType.TVP, tvpDataTable, JavaType.TVP, tvpName);
/* 2171 */     loggerExternal.exiting(getClassNameLogging(), "setStructured");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setStructured(String parameterName, String tvpName, ResultSet tvpResultSet) throws SQLServerException {
/* 2177 */     tvpName = getTVPNameIfNull(findColumn(parameterName), tvpName);
/* 2178 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 2179 */       loggerExternal.entering(getClassNameLogging(), "setStructured", new Object[] { parameterName, tvpName, tvpResultSet });
/*      */     }
/* 2181 */     checkClosed();
/* 2182 */     setValue(findColumn(parameterName), JDBCType.TVP, tvpResultSet, JavaType.TVP, tvpName);
/* 2183 */     loggerExternal.exiting(getClassNameLogging(), "setStructured");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setStructured(String parameterName, String tvpName, ISQLServerDataRecord tvpDataRecord) throws SQLServerException {
/* 2189 */     tvpName = getTVPNameIfNull(findColumn(parameterName), tvpName);
/* 2190 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 2191 */       loggerExternal.entering(getClassNameLogging(), "setStructured", new Object[] { parameterName, tvpName, tvpDataRecord });
/*      */     }
/* 2193 */     checkClosed();
/* 2194 */     setValue(findColumn(parameterName), JDBCType.TVP, tvpDataRecord, JavaType.TVP, tvpName);
/* 2195 */     loggerExternal.exiting(getClassNameLogging(), "setStructured");
/*      */   }
/*      */ 
/*      */   
/*      */   public URL getURL(int parameterIndex) throws SQLException {
/* 2200 */     SQLServerException.throwNotSupportedException(this.connection, this);
/* 2201 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public URL getURL(String parameterName) throws SQLException {
/* 2206 */     SQLServerException.throwNotSupportedException(this.connection, this);
/* 2207 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setSQLXML(String parameterName, SQLXML xmlObject) throws SQLException {
/* 2212 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2213 */       loggerExternal.entering(getClassNameLogging(), "setSQLXML", new Object[] { parameterName, xmlObject }); 
/* 2214 */     checkClosed();
/* 2215 */     setSQLXMLInternal(findColumn(parameterName), xmlObject);
/* 2216 */     loggerExternal.exiting(getClassNameLogging(), "setSQLXML");
/*      */   }
/*      */ 
/*      */   
/*      */   public final SQLXML getSQLXML(int parameterIndex) throws SQLException {
/* 2221 */     loggerExternal.entering(getClassNameLogging(), "getSQLXML", Integer.valueOf(parameterIndex));
/* 2222 */     checkClosed();
/* 2223 */     SQLServerSQLXML value = (SQLServerSQLXML)getSQLXMLInternal(parameterIndex);
/* 2224 */     loggerExternal.exiting(getClassNameLogging(), "getSQLXML", value);
/* 2225 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public final SQLXML getSQLXML(String parameterName) throws SQLException {
/* 2230 */     loggerExternal.entering(getClassNameLogging(), "getSQLXML", parameterName);
/* 2231 */     checkClosed();
/* 2232 */     SQLServerSQLXML value = (SQLServerSQLXML)getSQLXMLInternal(findColumn(parameterName));
/* 2233 */     loggerExternal.exiting(getClassNameLogging(), "getSQLXML", value);
/* 2234 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setRowId(String parameterName, RowId value) throws SQLException {
/* 2239 */     SQLServerException.throwNotSupportedException(this.connection, this);
/*      */   }
/*      */ 
/*      */   
/*      */   public final RowId getRowId(int parameterIndex) throws SQLException {
/* 2244 */     SQLServerException.throwNotSupportedException(this.connection, this);
/* 2245 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public final RowId getRowId(String parameterName) throws SQLException {
/* 2250 */     SQLServerException.throwNotSupportedException(this.connection, this);
/* 2251 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String parameterName, int sqlType, String typeName) throws SQLServerException {
/* 2256 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2257 */       loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] { parameterName, 
/* 2258 */             Integer.valueOf(sqlType), typeName }); 
/* 2259 */     checkClosed();
/* 2260 */     registerOutParameter(findColumn(parameterName), sqlType, typeName);
/* 2261 */     loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
/*      */   }
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String parameterName, int sqlType, int scale) throws SQLServerException {
/* 2266 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2267 */       loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] { parameterName, 
/* 2268 */             Integer.valueOf(sqlType), Integer.valueOf(scale) }); 
/* 2269 */     checkClosed();
/* 2270 */     registerOutParameter(findColumn(parameterName), sqlType, scale);
/* 2271 */     loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String parameterName, int sqlType, int precision, int scale) throws SQLServerException {
/* 2277 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2278 */       loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] { parameterName, 
/* 2279 */             Integer.valueOf(sqlType), Integer.valueOf(scale) }); 
/* 2280 */     checkClosed();
/* 2281 */     registerOutParameter(findColumn(parameterName), sqlType, precision, scale);
/* 2282 */     loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
/*      */   }
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String parameterName, int sqlType) throws SQLServerException {
/* 2287 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2288 */       loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] { parameterName, 
/* 2289 */             Integer.valueOf(sqlType) }); 
/* 2290 */     checkClosed();
/* 2291 */     registerOutParameter(findColumn(parameterName), sqlType);
/* 2292 */     loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int parameterIndex, SQLType sqlType) throws SQLServerException {
/* 2298 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 2299 */       loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] {
/* 2300 */             Integer.valueOf(parameterIndex), sqlType
/*      */           });
/*      */     }
/* 2303 */     registerOutParameter(parameterIndex, sqlType.getVendorTypeNumber().intValue());
/* 2304 */     loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int parameterIndex, SQLType sqlType, String typeName) throws SQLServerException {
/* 2310 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 2311 */       loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] {
/* 2312 */             Integer.valueOf(parameterIndex), sqlType, typeName
/*      */           });
/*      */     }
/* 2315 */     registerOutParameter(parameterIndex, sqlType.getVendorTypeNumber().intValue(), typeName);
/* 2316 */     loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int parameterIndex, SQLType sqlType, int scale) throws SQLServerException {
/* 2322 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 2323 */       loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] {
/* 2324 */             Integer.valueOf(parameterIndex), sqlType, Integer.valueOf(scale)
/*      */           });
/*      */     }
/* 2327 */     registerOutParameter(parameterIndex, sqlType.getVendorTypeNumber().intValue(), scale);
/* 2328 */     loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int parameterIndex, SQLType sqlType, int precision, int scale) throws SQLServerException {
/* 2335 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 2336 */       loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] {
/* 2337 */             Integer.valueOf(parameterIndex), sqlType, Integer.valueOf(scale)
/*      */           });
/*      */     }
/* 2340 */     registerOutParameter(parameterIndex, sqlType.getVendorTypeNumber().intValue(), precision, scale);
/* 2341 */     loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(String parameterName, Object value, SQLType jdbcType) throws SQLServerException {
/* 2347 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 2348 */       loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] { parameterName, value, jdbcType });
/*      */     }
/*      */     
/* 2351 */     setObject(parameterName, value, jdbcType.getVendorTypeNumber().intValue());
/* 2352 */     loggerExternal.exiting(getClassNameLogging(), "setObject");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(String parameterName, Object value, SQLType jdbcType, int scale) throws SQLServerException {
/* 2358 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 2359 */       loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] { parameterName, value, jdbcType, 
/* 2360 */             Integer.valueOf(scale) });
/*      */     }
/*      */     
/* 2363 */     setObject(parameterName, value, jdbcType.getVendorTypeNumber().intValue(), scale);
/* 2364 */     loggerExternal.exiting(getClassNameLogging(), "setObject");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(String parameterName, Object value, SQLType jdbcType, int scale, boolean forceEncrypt) throws SQLServerException {
/* 2371 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 2372 */       loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] { parameterName, value, jdbcType, 
/* 2373 */             Integer.valueOf(scale), Boolean.valueOf(forceEncrypt) });
/*      */     }
/*      */     
/* 2376 */     setObject(parameterName, value, jdbcType.getVendorTypeNumber().intValue(), scale, forceEncrypt);
/* 2377 */     loggerExternal.exiting(getClassNameLogging(), "setObject");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String parameterName, SQLType sqlType, String typeName) throws SQLServerException {
/* 2383 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 2384 */       loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] { parameterName, sqlType, typeName });
/*      */     }
/*      */ 
/*      */     
/* 2388 */     registerOutParameter(parameterName, sqlType.getVendorTypeNumber().intValue(), typeName);
/* 2389 */     loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String parameterName, SQLType sqlType, int scale) throws SQLServerException {
/* 2395 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 2396 */       loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] { parameterName, sqlType, 
/* 2397 */             Integer.valueOf(scale) });
/*      */     }
/*      */     
/* 2400 */     registerOutParameter(parameterName, sqlType.getVendorTypeNumber().intValue(), scale);
/* 2401 */     loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String parameterName, SQLType sqlType, int precision, int scale) throws SQLServerException {
/* 2408 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 2409 */       loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] { parameterName, sqlType, 
/* 2410 */             Integer.valueOf(scale) });
/*      */     }
/*      */     
/* 2413 */     registerOutParameter(parameterName, sqlType.getVendorTypeNumber().intValue(), precision, scale);
/* 2414 */     loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String parameterName, SQLType sqlType) throws SQLServerException {
/* 2420 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 2421 */       loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] { parameterName, sqlType });
/*      */     }
/*      */ 
/*      */     
/* 2425 */     registerOutParameter(parameterName, sqlType.getVendorTypeNumber().intValue());
/* 2426 */     loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
/*      */   }
/*      */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerCallableStatement.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */