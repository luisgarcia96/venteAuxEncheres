/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class UDTTDSHeader
/*    */ {
/*    */   private final int maxLen;
/*    */   private final String databaseName;
/*    */   private final String schemaName;
/*    */   private final String typeName;
/*    */   private final String assemblyQualifiedName;
/*    */   
/*    */   UDTTDSHeader(TDSReader tdsReader) throws SQLServerException {
/* 34 */     this.maxLen = tdsReader.readUnsignedShort();
/* 35 */     this.databaseName = tdsReader.readUnicodeString(tdsReader.readUnsignedByte());
/* 36 */     this.schemaName = tdsReader.readUnicodeString(tdsReader.readUnsignedByte());
/* 37 */     this.typeName = tdsReader.readUnicodeString(tdsReader.readUnsignedByte());
/* 38 */     this.assemblyQualifiedName = tdsReader.readUnicodeString(tdsReader.readUnsignedShort());
/*    */   }
/*    */   
/*    */   int getMaxLen() {
/* 42 */     return this.maxLen;
/*    */   }
/*    */   
/*    */   String getTypeName() {
/* 46 */     return this.typeName;
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\UDTTDSHeader.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */