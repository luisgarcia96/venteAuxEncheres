/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class StreamRetStatus
/*    */   extends StreamPacket
/*    */ {
/*    */   private int status;
/*    */   
/*    */   final int getStatus() {
/* 17 */     return this.status;
/*    */   }
/*    */   
/*    */   StreamRetStatus() {
/* 21 */     super(121);
/*    */   }
/*    */   
/*    */   void setFromTDS(TDSReader tdsReader) throws SQLServerException {
/* 25 */     if (121 != tdsReader.readUnsignedByte() && 
/* 26 */       !$assertionsDisabled) throw new AssertionError(); 
/* 27 */     this.status = tdsReader.readInt();
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\StreamRetStatus.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */