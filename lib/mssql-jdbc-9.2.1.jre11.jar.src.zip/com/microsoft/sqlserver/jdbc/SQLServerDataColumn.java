/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SQLServerDataColumn
/*    */ {
/*    */   String columnName;
/*    */   int javaSqlType;
/* 14 */   int precision = 0;
/* 15 */   int scale = 0;
/* 16 */   int numberOfDigitsIntegerPart = 0;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SQLServerDataColumn(String columnName, int sqlType) {
/* 27 */     this.columnName = columnName;
/* 28 */     this.javaSqlType = sqlType;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getColumnName() {
/* 37 */     return this.columnName;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getColumnType() {
/* 46 */     return this.javaSqlType;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 51 */     int hash = 7;
/* 52 */     hash = 31 * hash + this.javaSqlType;
/* 53 */     hash = 31 * hash + this.precision;
/* 54 */     hash = 31 * hash + this.scale;
/* 55 */     hash = 31 * hash + this.numberOfDigitsIntegerPart;
/* 56 */     hash = 31 * hash + ((null != this.columnName) ? this.columnName.hashCode() : 0);
/* 57 */     return hash;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object object) {
/* 62 */     if (this == object) {
/* 63 */       return true;
/*    */     }
/*    */     
/* 66 */     if (null != object && object.getClass() == SQLServerDataColumn.class) {
/* 67 */       SQLServerDataColumn aSQLServerDataColumn = (SQLServerDataColumn)object;
/* 68 */       if (hashCode() == aSQLServerDataColumn.hashCode()) {
/*    */         
/* 70 */         if ((null == this.columnName) ? (null == aSQLServerDataColumn.columnName) : this.columnName
/* 71 */           .equals(aSQLServerDataColumn.columnName)) if (this.javaSqlType == aSQLServerDataColumn.javaSqlType && this.numberOfDigitsIntegerPart == aSQLServerDataColumn.numberOfDigitsIntegerPart && this.precision == aSQLServerDataColumn.precision && this.scale == aSQLServerDataColumn.scale);
/*    */ 
/*    */         
/*    */         return false;
/*    */       } 
/*    */     } 
/* 77 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerDataColumn.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */