/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class XMLTDSHeader
/*    */ {
/*    */   private final String databaseName;
/*    */   private final String owningSchema;
/*    */   private final String xmlSchemaCollection;
/*    */   
/*    */   XMLTDSHeader(TDSReader tdsReader) throws SQLServerException {
/* 35 */     if (0 != tdsReader.readUnsignedByte()) {
/*    */       
/* 37 */       this.databaseName = tdsReader.readUnicodeString(tdsReader.readUnsignedByte());
/* 38 */       this.owningSchema = tdsReader.readUnicodeString(tdsReader.readUnsignedByte());
/* 39 */       this.xmlSchemaCollection = tdsReader.readUnicodeString(tdsReader.readUnsignedShort());
/*    */     } else {
/* 41 */       this.xmlSchemaCollection = null;
/* 42 */       this.owningSchema = null;
/* 43 */       this.databaseName = null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\XMLTDSHeader.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */