/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.text.MessageFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ enum TDSType
/*     */ {
/*  28 */   BIT1(50),
/*  29 */   INT8(127),
/*  30 */   INT4(56),
/*  31 */   INT2(52),
/*  32 */   INT1(48),
/*  33 */   FLOAT4(59),
/*  34 */   FLOAT8(62),
/*  35 */   DATETIME4(58),
/*  36 */   DATETIME8(61),
/*  37 */   MONEY4(122),
/*  38 */   MONEY8(60),
/*     */ 
/*     */   
/*  41 */   BITN(104),
/*  42 */   INTN(38),
/*  43 */   DECIMALN(106),
/*  44 */   NUMERICN(108),
/*  45 */   FLOATN(109),
/*  46 */   MONEYN(110),
/*  47 */   DATETIMEN(111),
/*  48 */   GUID(36),
/*  49 */   DATEN(40),
/*  50 */   TIMEN(41),
/*  51 */   DATETIME2N(42),
/*  52 */   DATETIMEOFFSETN(43),
/*     */ 
/*     */   
/*  55 */   BIGCHAR(175),
/*  56 */   BIGVARCHAR(167),
/*  57 */   BIGBINARY(173),
/*  58 */   BIGVARBINARY(165),
/*  59 */   NCHAR(239),
/*  60 */   NVARCHAR(231),
/*     */ 
/*     */   
/*  63 */   IMAGE(34),
/*  64 */   TEXT(35),
/*  65 */   NTEXT(99),
/*  66 */   UDT(240),
/*  67 */   XML(241),
/*     */ 
/*     */   
/*  70 */   SQL_VARIANT(98);
/*     */   private final int intValue;
/*     */   private static final int MAXELEMENTS = 256;
/*     */   
/*     */   static {
/*  75 */     VALUES = values();
/*  76 */     valuesTypes = new TDSType[256];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  83 */     for (TDSType s : VALUES)
/*  84 */       valuesTypes[s.intValue] = s; 
/*     */   }
/*     */   private static final TDSType[] VALUES; private static final TDSType[] valuesTypes;
/*     */   TDSType(int intValue) {
/*  88 */     this.intValue = intValue;
/*     */   }
/*     */   
/*     */   byte byteValue() {
/*     */     return (byte)this.intValue;
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\TDSType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */