/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.RoundingMode;
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.MessageFormat;
/*     */ import java.time.OffsetDateTime;
/*     */ import java.time.OffsetTime;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.logging.Level;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SQLServerBulkCSVFileRecord
/*     */   extends SQLServerBulkRecord
/*     */   implements AutoCloseable
/*     */ {
/*     */   private static final long serialVersionUID = 1546487135640225989L;
/*     */   private BufferedReader fileReader;
/*     */   private InputStreamReader sr;
/*     */   private FileInputStream fis;
/*  45 */   private String currentLine = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String delimiter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean escapeDelimiters;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String escapeSplitPattern = "(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String loggerClassName = "SQLServerBulkCSVFileRecord";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SQLServerBulkCSVFileRecord(String fileToParse, String encoding, String delimiter, boolean firstLineIsColumnNames) throws SQLServerException {
/*  78 */     initLoggerResources();
/*  79 */     if (loggerExternal.isLoggable(Level.FINER)) {
/*  80 */       loggerExternal.entering(this.loggerPackageName, "SQLServerBulkCSVFileRecord", new Object[] { fileToParse, encoding, delimiter, 
/*  81 */             Boolean.valueOf(firstLineIsColumnNames) });
/*     */     }
/*     */     
/*  84 */     if (null == fileToParse) {
/*  85 */       throwInvalidArgument("fileToParse");
/*  86 */     } else if (null == delimiter) {
/*  87 */       throwInvalidArgument("delimiter");
/*     */     } 
/*     */     
/*  90 */     this.delimiter = delimiter;
/*     */     
/*     */     try {
/*  93 */       this.fis = new FileInputStream(fileToParse);
/*  94 */       if (null == encoding || 0 == encoding.length()) {
/*  95 */         this.sr = new InputStreamReader(this.fis);
/*     */       } else {
/*  97 */         this.sr = new InputStreamReader(this.fis, encoding);
/*     */       } 
/*  99 */       initFileReader(this.sr, encoding, delimiter, firstLineIsColumnNames);
/* 100 */     } catch (UnsupportedEncodingException unsupportedEncoding) {
/* 101 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_unsupportedEncoding"));
/* 102 */       throw new SQLServerException(form.format(new Object[] { encoding }, ), null, 0, unsupportedEncoding);
/* 103 */     } catch (Exception e) {
/* 104 */       throw new SQLServerException(null, e.getMessage(), null, 0, false);
/*     */     } 
/* 106 */     this.columnMetadata = new HashMap<>();
/*     */     
/* 108 */     loggerExternal.exiting(this.loggerPackageName, "SQLServerBulkCSVFileRecord");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SQLServerBulkCSVFileRecord(InputStream fileToParse, String encoding, String delimiter, boolean firstLineIsColumnNames) throws SQLServerException {
/* 127 */     initLoggerResources();
/* 128 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 129 */       loggerExternal.entering(this.loggerPackageName, "SQLServerBulkCSVFileRecord", new Object[] { fileToParse, encoding, delimiter, 
/* 130 */             Boolean.valueOf(firstLineIsColumnNames) });
/*     */     }
/*     */     
/* 133 */     if (null == fileToParse) {
/* 134 */       throwInvalidArgument("fileToParse");
/* 135 */     } else if (null == delimiter) {
/* 136 */       throwInvalidArgument("delimiter");
/*     */     } 
/*     */     
/* 139 */     this.delimiter = delimiter;
/*     */     try {
/* 141 */       if (null == encoding || 0 == encoding.length()) {
/* 142 */         this.sr = new InputStreamReader(fileToParse);
/*     */       } else {
/* 144 */         this.sr = new InputStreamReader(fileToParse, encoding);
/*     */       } 
/* 146 */       initFileReader(this.sr, encoding, delimiter, firstLineIsColumnNames);
/* 147 */     } catch (UnsupportedEncodingException unsupportedEncoding) {
/* 148 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_unsupportedEncoding"));
/* 149 */       throw new SQLServerException(form.format(new Object[] { encoding }, ), null, 0, unsupportedEncoding);
/* 150 */     } catch (Exception e) {
/* 151 */       throw new SQLServerException(null, e.getMessage(), null, 0, false);
/*     */     } 
/* 153 */     this.columnMetadata = new HashMap<>();
/*     */     
/* 155 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 156 */       loggerExternal.exiting(this.loggerPackageName, "SQLServerBulkCSVFileRecord");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SQLServerBulkCSVFileRecord(String fileToParse, String encoding, boolean firstLineIsColumnNames) throws SQLServerException {
/* 174 */     this(fileToParse, encoding, ",", firstLineIsColumnNames);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SQLServerBulkCSVFileRecord(String fileToParse, boolean firstLineIsColumnNames) throws SQLServerException {
/* 188 */     this(fileToParse, (String)null, ",", firstLineIsColumnNames);
/*     */   }
/*     */ 
/*     */   
/*     */   private void initFileReader(InputStreamReader sr, String encoding, String demlimeter, boolean firstLineIsColumnNames) throws SQLServerException, IOException {
/* 193 */     this.fileReader = new BufferedReader(sr);
/* 194 */     if (firstLineIsColumnNames) {
/* 195 */       this.currentLine = this.fileReader.readLine();
/* 196 */       if (null != this.currentLine) {
/* 197 */         this
/* 198 */           .columnNames = (this.escapeDelimiters && this.currentLine.contains("\"")) ? escapeQuotesRFC4180(this.currentLine.split(this.delimiter + "(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1)) : this.currentLine.split(this.delimiter, -1);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void initLoggerResources() {
/* 204 */     this.loggerPackageName = "com.microsoft.sqlserver.jdbc.SQLServerBulkCSVFileRecord";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws SQLServerException {
/* 214 */     loggerExternal.entering(this.loggerPackageName, "close");
/*     */ 
/*     */     
/* 217 */     if (this.fileReader != null)
/*     */       try {
/* 219 */         this.fileReader.close();
/* 220 */       } catch (Exception exception) {} 
/* 221 */     if (this.sr != null)
/*     */       try {
/* 223 */         this.sr.close();
/* 224 */       } catch (Exception exception) {} 
/* 225 */     if (this.fis != null) {
/*     */       try {
/* 227 */         this.fis.close();
/* 228 */       } catch (Exception exception) {}
/*     */     }
/* 230 */     loggerExternal.exiting(this.loggerPackageName, "close");
/*     */   }
/*     */ 
/*     */   
/*     */   public Object[] getRowData() throws SQLServerException {
/* 235 */     if (null == this.currentLine) {
/* 236 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 243 */     String[] data = (this.escapeDelimiters && this.currentLine.contains("\"")) ? escapeQuotesRFC4180(this.currentLine.split(this.delimiter + "(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1)) : this.currentLine.split(this.delimiter, -1);
/*     */ 
/*     */ 
/*     */     
/* 247 */     Object[] dataRow = new Object[data.length];
/*     */     
/* 249 */     for (Map.Entry<Integer, SQLServerBulkRecord.ColumnMetadata> pair : this.columnMetadata.entrySet()) {
/* 250 */       SQLServerBulkRecord.ColumnMetadata cm = pair.getValue();
/*     */       
/* 252 */       if (data.length < ((Integer)pair.getKey()).intValue() - 1) {
/* 253 */         MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidColumn"));
/* 254 */         Object[] msgArgs = { pair.getKey() };
/* 255 */         throw new SQLServerException(form.format(msgArgs), SQLState.COL_NOT_FOUND, DriverError.NOT_SET, null);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 260 */       if (this.columnNames != null && this.columnNames.length > data.length) {
/* 261 */         MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_DataSchemaMismatch"));
/* 262 */         Object[] msgArgs = new Object[0];
/* 263 */         throw new SQLServerException(form.format(msgArgs), SQLState.COL_NOT_FOUND, DriverError.NOT_SET, null);
/*     */       }  try {
/*     */         DecimalFormat decimalFormatter; BigDecimal bd; String binData; OffsetTime offsetTimeValue;
/*     */         OffsetDateTime offsetDateTimeValue;
/*     */         String formatedfInput;
/* 268 */         if (0 == data[((Integer)pair.getKey()).intValue() - 1].length()) {
/* 269 */           dataRow[((Integer)pair.getKey()).intValue() - 1] = null;
/*     */           
/*     */           continue;
/*     */         } 
/* 273 */         switch (cm.columnType) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           case 4:
/* 280 */             decimalFormatter = new DecimalFormat("#");
/* 281 */             decimalFormatter.setRoundingMode(RoundingMode.DOWN);
/*     */             
/* 283 */             formatedfInput = decimalFormatter.format(Double.parseDouble(data[((Integer)pair.getKey()).intValue() - 1]));
/* 284 */             dataRow[((Integer)pair.getKey()).intValue() - 1] = Integer.valueOf(formatedfInput);
/*     */             continue;
/*     */ 
/*     */ 
/*     */           
/*     */           case -6:
/*     */           case 5:
/* 291 */             decimalFormatter = new DecimalFormat("#");
/* 292 */             decimalFormatter.setRoundingMode(RoundingMode.DOWN);
/*     */             
/* 294 */             formatedfInput = decimalFormatter.format(Double.parseDouble(data[((Integer)pair.getKey()).intValue() - 1]));
/* 295 */             dataRow[((Integer)pair.getKey()).intValue() - 1] = Short.valueOf(formatedfInput);
/*     */             continue;
/*     */ 
/*     */           
/*     */           case -5:
/* 300 */             bd = new BigDecimal(data[((Integer)pair.getKey()).intValue() - 1].trim());
/*     */             try {
/* 302 */               dataRow[((Integer)pair.getKey()).intValue() - 1] = Long.valueOf(bd.setScale(0, RoundingMode.DOWN).longValueExact());
/* 303 */             } catch (ArithmeticException ex) {
/* 304 */               String value = "'" + data[((Integer)pair.getKey()).intValue() - 1] + "'";
/*     */               
/* 306 */               MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_errorConvertingValue"));
/* 307 */               throw new SQLServerException(form
/* 308 */                   .format(new Object[] { value, JDBCType.of(cm.columnType) }, ), null, 0, ex);
/*     */             } 
/*     */             continue;
/*     */ 
/*     */           
/*     */           case -148:
/*     */           case -146:
/*     */           case 2:
/*     */           case 3:
/* 317 */             bd = new BigDecimal(data[((Integer)pair.getKey()).intValue() - 1].trim());
/* 318 */             dataRow[((Integer)pair.getKey()).intValue() - 1] = bd.setScale(cm.scale, RoundingMode.HALF_UP);
/*     */             continue;
/*     */ 
/*     */ 
/*     */           
/*     */           case -7:
/*     */             try {
/* 325 */               dataRow[((Integer)pair.getKey()).intValue() - 1] = 
/* 326 */                 (0.0D == Double.parseDouble(data[((Integer)pair.getKey()).intValue() - 1])) ? Boolean.FALSE : 
/* 327 */                 Boolean.TRUE;
/* 328 */             } catch (NumberFormatException e) {
/* 329 */               dataRow[((Integer)pair.getKey()).intValue() - 1] = Boolean.valueOf(Boolean.parseBoolean(data[((Integer)pair.getKey()).intValue() - 1]));
/*     */             } 
/*     */             continue;
/*     */ 
/*     */           
/*     */           case 7:
/* 335 */             dataRow[((Integer)pair.getKey()).intValue() - 1] = Float.valueOf(Float.parseFloat(data[((Integer)pair.getKey()).intValue() - 1]));
/*     */             continue;
/*     */ 
/*     */           
/*     */           case 8:
/* 340 */             dataRow[((Integer)pair.getKey()).intValue() - 1] = Double.valueOf(Double.parseDouble(data[((Integer)pair.getKey()).intValue() - 1]));
/*     */             continue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           case -4:
/*     */           case -3:
/*     */           case -2:
/*     */           case 2004:
/* 358 */             binData = data[((Integer)pair.getKey()).intValue() - 1].trim();
/* 359 */             if (binData.startsWith("0x") || binData.startsWith("0X")) {
/* 360 */               dataRow[((Integer)pair.getKey()).intValue() - 1] = binData.substring(2); continue;
/*     */             } 
/* 362 */             dataRow[((Integer)pair.getKey()).intValue() - 1] = binData;
/*     */             continue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           case 2013:
/* 371 */             if (null != cm.dateTimeFormatter) {
/* 372 */               offsetTimeValue = OffsetTime.parse(data[((Integer)pair.getKey()).intValue() - 1], cm.dateTimeFormatter);
/* 373 */             } else if (this.timeFormatter != null) {
/* 374 */               offsetTimeValue = OffsetTime.parse(data[((Integer)pair.getKey()).intValue() - 1], this.timeFormatter);
/*     */             } else {
/* 376 */               offsetTimeValue = OffsetTime.parse(data[((Integer)pair.getKey()).intValue() - 1]);
/*     */             } 
/* 378 */             dataRow[((Integer)pair.getKey()).intValue() - 1] = offsetTimeValue;
/*     */             continue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           case 2014:
/* 386 */             if (null != cm.dateTimeFormatter) {
/* 387 */               offsetDateTimeValue = OffsetDateTime.parse(data[((Integer)pair.getKey()).intValue() - 1], cm.dateTimeFormatter);
/*     */             }
/* 389 */             else if (this.dateTimeFormatter != null) {
/* 390 */               offsetDateTimeValue = OffsetDateTime.parse(data[((Integer)pair.getKey()).intValue() - 1], this.dateTimeFormatter);
/*     */             } else {
/* 392 */               offsetDateTimeValue = OffsetDateTime.parse(data[((Integer)pair.getKey()).intValue() - 1]);
/*     */             } 
/* 394 */             dataRow[((Integer)pair.getKey()).intValue() - 1] = offsetDateTimeValue;
/*     */             continue;
/*     */ 
/*     */           
/*     */           case 0:
/* 399 */             dataRow[((Integer)pair.getKey()).intValue() - 1] = null;
/*     */             continue;
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 427 */         dataRow[((Integer)pair.getKey()).intValue() - 1] = data[((Integer)pair.getKey()).intValue() - 1];
/*     */ 
/*     */       
/*     */       }
/* 431 */       catch (IllegalArgumentException e) {
/* 432 */         String value = "'" + data[((Integer)pair.getKey()).intValue() - 1] + "'";
/* 433 */         MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_errorConvertingValue"));
/* 434 */         throw new SQLServerException(form.format(new Object[] { value, JDBCType.of(cm.columnType) }, ), null, 0, e);
/*     */       }
/* 436 */       catch (ArrayIndexOutOfBoundsException e) {
/* 437 */         throw new SQLServerException(SQLServerException.getErrString("R_DataSchemaMismatch"), e);
/*     */       } 
/*     */     } 
/*     */     
/* 441 */     return dataRow;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void addColumnMetadataInternal(int positionInSource, String name, int jdbcType, int precision, int scale, DateTimeFormatter dateTimeFormatter) throws SQLServerException {
/* 448 */     loggerExternal.entering(this.loggerPackageName, "addColumnMetadata", new Object[] {
/* 449 */           Integer.valueOf(positionInSource), name, Integer.valueOf(jdbcType), Integer.valueOf(precision), Integer.valueOf(scale)
/*     */         });
/* 451 */     String colName = "";
/*     */     
/* 453 */     if (0 >= positionInSource) {
/* 454 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidColumnOrdinal"));
/* 455 */       Object[] msgArgs = { Integer.valueOf(positionInSource) };
/* 456 */       throw new SQLServerException(form.format(msgArgs), SQLState.COL_NOT_FOUND, DriverError.NOT_SET, null);
/*     */     } 
/*     */     
/* 459 */     if (null != name) {
/* 460 */       colName = name.trim();
/* 461 */     } else if (null != this.columnNames && this.columnNames.length >= positionInSource) {
/* 462 */       colName = this.columnNames[positionInSource - 1];
/*     */     } 
/* 464 */     if (null != this.columnNames && positionInSource > this.columnNames.length) {
/* 465 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidColumn"));
/* 466 */       Object[] msgArgs = { Integer.valueOf(positionInSource) };
/* 467 */       throw new SQLServerException(form.format(msgArgs), SQLState.COL_NOT_FOUND, DriverError.NOT_SET, null);
/*     */     } 
/*     */     
/* 470 */     checkDuplicateColumnName(positionInSource, name);
/* 471 */     switch (jdbcType) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case -155:
/*     */       case 91:
/*     */       case 92:
/*     */       case 93:
/* 481 */         this.columnMetadata.put(Integer.valueOf(positionInSource), new SQLServerBulkRecord.ColumnMetadata(this, colName, jdbcType, 50, scale, dateTimeFormatter));
/*     */         break;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 2009:
/* 488 */         this.columnMetadata.put(Integer.valueOf(positionInSource), new SQLServerBulkRecord.ColumnMetadata(this, colName, -16, precision, scale, dateTimeFormatter));
/*     */         break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 6:
/* 496 */         this.columnMetadata.put(Integer.valueOf(positionInSource), new SQLServerBulkRecord.ColumnMetadata(this, colName, 8, precision, scale, dateTimeFormatter));
/*     */         break;
/*     */ 
/*     */ 
/*     */       
/*     */       case 16:
/* 502 */         this.columnMetadata.put(Integer.valueOf(positionInSource), new SQLServerBulkRecord.ColumnMetadata(this, colName, -7, precision, scale, dateTimeFormatter));
/*     */         break;
/*     */ 
/*     */       
/*     */       default:
/* 507 */         this.columnMetadata.put(Integer.valueOf(positionInSource), new SQLServerBulkRecord.ColumnMetadata(this, colName, jdbcType, precision, scale, dateTimeFormatter));
/*     */         break;
/*     */     } 
/*     */     
/* 511 */     loggerExternal.exiting(this.loggerPackageName, "addColumnMetadata");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean next() throws SQLServerException {
/*     */     try {
/* 517 */       this.currentLine = this.fileReader.readLine();
/* 518 */     } catch (IOException e) {
/* 519 */       throw new SQLServerException(e.getMessage(), null, 0, e);
/*     */     } 
/* 521 */     return (null != this.currentLine);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEscapeColumnDelimitersCSV() {
/* 530 */     return this.escapeDelimiters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEscapeColumnDelimitersCSV(boolean escapeDelimiters) {
/* 544 */     this.escapeDelimiters = escapeDelimiters;
/*     */   }
/*     */   
/*     */   private static String[] escapeQuotesRFC4180(String[] tokens) throws SQLServerException {
/* 548 */     if (null == tokens) {
/* 549 */       return tokens;
/*     */     }
/* 551 */     for (int i = 0; i < tokens.length; i++) {
/* 552 */       boolean escaped = false;
/* 553 */       int j = 0;
/* 554 */       StringBuilder sb = new StringBuilder();
/* 555 */       long quoteCount = tokens[i].chars().filter(ch -> (ch == 34)).count();
/* 556 */       if (quoteCount > 0L) {
/* 557 */         tokens[i] = tokens[i].trim();
/*     */       }
/* 559 */       if (0L != quoteCount % 2L || (quoteCount > 0L && ('"' != tokens[i]
/* 560 */         .charAt(0) || '"' != tokens[i].charAt(tokens[i].length() - 1)))) {
/* 561 */         throw new SQLServerException(SQLServerException.getErrString("R_InvalidCSVQuotes"), null, 0, null);
/*     */       }
/* 563 */       while (j < tokens[i].length()) {
/* 564 */         if ('"' == tokens[i].charAt(j)) {
/* 565 */           if (!escaped) {
/* 566 */             escaped = true;
/*     */           }
/* 568 */           else if (j < tokens[i].length() - 1 && '"' == tokens[i].charAt(j + 1)) {
/* 569 */             sb.append('"');
/* 570 */             j++;
/*     */           } 
/*     */         } else {
/*     */           
/* 574 */           sb.append(tokens[i].charAt(j));
/*     */         } 
/* 576 */         j++;
/*     */       } 
/* 578 */       tokens[i] = sb.toString();
/*     */     } 
/* 580 */     return tokens;
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerBulkCSVFileRecord.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */