/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ParameterUtils
/*     */ {
/*     */   static byte[] HexToBin(String hexV) throws SQLServerException {
/*  14 */     int len = hexV.length();
/*  15 */     char[] orig = hexV.toCharArray();
/*  16 */     if (len % 2 != 0) {
/*  17 */       SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_stringNotInHex"), null, false);
/*     */     }
/*  19 */     byte[] bin = new byte[len / 2];
/*  20 */     for (int i = 0; i < len / 2; i++) {
/*  21 */       bin[i] = (byte)((CharToHex(orig[2 * i]) << 4) + (CharToHex(orig[2 * i + 1]) & 0xFF));
/*     */     }
/*  23 */     return bin;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static byte CharToHex(char CTX) throws SQLServerException {
/*  30 */     byte ret = 0;
/*  31 */     if (CTX >= 'A' && CTX <= 'F') {
/*  32 */       ret = (byte)(CTX - 65 + 10);
/*  33 */     } else if (CTX >= 'a' && CTX <= 'f') {
/*  34 */       ret = (byte)(CTX - 97 + 10);
/*  35 */     } else if (CTX >= '0' && CTX <= '9') {
/*  36 */       ret = (byte)(CTX - 48);
/*     */     } else {
/*  38 */       SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_stringNotInHex"), null, false);
/*     */     } 
/*     */     
/*  41 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int scanSQLForChar(char ch, String sql, int offset) {
/*  68 */     int len = sql.length();
/*     */     
/*  70 */     while (offset < len) {
/*  71 */       char chTmp; switch (chTmp = sql.charAt(offset++))
/*     */       { case '/':
/*  73 */           if (offset == len) {
/*     */             continue;
/*     */           }
/*  76 */           if (sql.charAt(offset) == '*') {
/*  77 */             while (++offset < len) {
/*  78 */               if (sql.charAt(offset) == '*' && offset + 1 < len && sql.charAt(offset + 1) == '/')
/*     */               {
/*  80 */                 offset += 2;
/*     */               }
/*     */             } 
/*     */             continue;
/*     */           } 
/*  85 */           if (sql.charAt(offset) == '-') {
/*     */             continue;
/*     */           }
/*     */         
/*     */         case '-':
/*  90 */           if (offset >= 0 && offset < sql.length() && sql.charAt(offset) == '-') {
/*  91 */             label35: while (++offset < len) {
/*  92 */               if (sql.charAt(offset) != '\n') { if (sql.charAt(offset) == '\r')
/*     */                 {
/*  94 */                   offset++; } 
/*     */                 continue; }
/*     */               
/*     */               break label35;
/*     */             } 
/*     */             continue;
/*     */           } 
/*     */         default:
/* 102 */           if (ch == chTmp)
/* 103 */             return offset - 1; 
/*     */           continue;
/*     */         case '[':
/* 106 */           chTmp = ']'; break;
/*     */         case '"':
/*     */         case '\'':
/* 109 */           break; }  char chQuote = chTmp;
/* 110 */       while (offset < len) {
/* 111 */         if (sql.charAt(offset++) == chQuote) {
/* 112 */           if (len == offset || sql.charAt(offset) != chQuote) {
/*     */             break;
/*     */           }
/* 115 */           offset++;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 122 */     return len;
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\ParameterUtils.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */