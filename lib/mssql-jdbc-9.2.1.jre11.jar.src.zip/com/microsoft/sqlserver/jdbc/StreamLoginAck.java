/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class StreamLoginAck
/*    */   extends StreamPacket
/*    */ {
/*    */   String sSQLServerVersion;
/*    */   int tdsVersion;
/*    */   
/*    */   StreamLoginAck() {
/* 18 */     super(173);
/*    */   }
/*    */   
/*    */   void setFromTDS(TDSReader tdsReader) throws SQLServerException {
/* 22 */     if (173 != tdsReader.readUnsignedByte() && 
/* 23 */       !$assertionsDisabled) throw new AssertionError(); 
/* 24 */     tdsReader.readUnsignedShort();
/* 25 */     tdsReader.readUnsignedByte();
/* 26 */     this.tdsVersion = tdsReader.readIntBigEndian();
/* 27 */     tdsReader.readUnicodeString(tdsReader.readUnsignedByte());
/* 28 */     int serverMajorVersion = tdsReader.readUnsignedByte();
/* 29 */     int serverMinorVersion = tdsReader.readUnsignedByte();
/* 30 */     int serverBuildNumber = tdsReader.readUnsignedByte() << 8 | tdsReader.readUnsignedByte();
/*    */     
/* 32 */     this.sSQLServerVersion = "" + serverMajorVersion + "." + serverMajorVersion + ((serverMinorVersion <= 9) ? "0" : "") + "." + serverMinorVersion;
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\StreamLoginAck.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */