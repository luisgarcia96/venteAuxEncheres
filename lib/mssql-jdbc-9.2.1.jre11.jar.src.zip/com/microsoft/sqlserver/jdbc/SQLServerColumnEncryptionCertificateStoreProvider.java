/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import java.util.logging.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SQLServerColumnEncryptionCertificateStoreProvider
/*    */   extends SQLServerColumnEncryptionKeyStoreProvider
/*    */ {
/* 18 */   private static final Logger windowsCertificateStoreLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.SQLServerColumnEncryptionCertificateStoreProvider");
/*    */   
/*    */   static boolean isWindows;
/*    */   
/* 22 */   String name = "MSSQL_CERTIFICATE_STORE";
/*    */   
/*    */   static final String localMachineDirectory = "LocalMachine";
/*    */   static final String currentUserDirectory = "CurrentUser";
/*    */   static final String myCertificateStore = "My";
/*    */   
/*    */   static {
/* 29 */     if (System.getProperty("os.name").toLowerCase(Locale.ENGLISH).startsWith("windows")) {
/* 30 */       isWindows = true;
/*    */     } else {
/* 32 */       isWindows = false;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SQLServerColumnEncryptionCertificateStoreProvider() {
/* 40 */     windowsCertificateStoreLogger.entering(SQLServerColumnEncryptionCertificateStoreProvider.class.getName(), "SQLServerColumnEncryptionCertificateStoreProvider");
/*    */   }
/*    */ 
/*    */   
/*    */   public void setName(String name) {
/* 45 */     this.name = name;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 49 */     return this.name;
/*    */   }
/*    */ 
/*    */   
/*    */   public byte[] encryptColumnEncryptionKey(String masterKeyPath, String encryptionAlgorithm, byte[] plainTextColumnEncryptionKey) throws SQLServerException {
/* 54 */     throw new SQLServerException(null, 
/* 55 */         SQLServerException.getErrString("R_InvalidWindowsCertificateStoreEncryption"), null, 0, false);
/*    */   }
/*    */ 
/*    */   
/*    */   private byte[] decryptColumnEncryptionKeyWindows(String masterKeyPath, String encryptionAlgorithm, byte[] encryptedColumnEncryptionKey) throws SQLServerException {
/*    */     try {
/* 61 */       return AuthenticationJNI.DecryptColumnEncryptionKey(masterKeyPath, encryptionAlgorithm, encryptedColumnEncryptionKey);
/*    */     }
/* 63 */     catch (DLLException e) {
/* 64 */       DLLException.buildException(e.GetErrCode(), e.GetParam1(), e.GetParam2(), e.GetParam3());
/* 65 */       return null;
/*    */     } 
/*    */   }
/*    */   
/*    */   public byte[] decryptColumnEncryptionKey(String masterKeyPath, String encryptionAlgorithm, byte[] encryptedColumnEncryptionKey) throws SQLServerException {
/*    */     byte[] plainCek;
/* 71 */     windowsCertificateStoreLogger.entering(SQLServerColumnEncryptionCertificateStoreProvider.class.getName(), "decryptColumnEncryptionKey", "Decrypting Column Encryption Key.");
/*    */ 
/*    */     
/* 74 */     if (isWindows) {
/* 75 */       plainCek = decryptColumnEncryptionKeyWindows(masterKeyPath, encryptionAlgorithm, encryptedColumnEncryptionKey);
/*    */     } else {
/*    */       
/* 78 */       throw new SQLServerException(SQLServerException.getErrString("R_notSupported"), null);
/*    */     } 
/* 80 */     windowsCertificateStoreLogger.exiting(SQLServerColumnEncryptionCertificateStoreProvider.class.getName(), "decryptColumnEncryptionKey", "Finished decrypting Column Encryption Key.");
/*    */     
/* 82 */     return plainCek;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean verifyColumnMasterKeyMetadata(String masterKeyPath, boolean allowEnclaveComputations, byte[] signature) throws SQLServerException {
/*    */     try {
/* 89 */       return AuthenticationJNI.VerifyColumnMasterKeyMetadata(masterKeyPath, allowEnclaveComputations, signature);
/* 90 */     } catch (DLLException e) {
/* 91 */       DLLException.buildException(e.GetErrCode(), e.GetParam1(), e.GetParam2(), e.GetParam3());
/* 92 */       return false;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerColumnEncryptionCertificateStoreProvider.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */