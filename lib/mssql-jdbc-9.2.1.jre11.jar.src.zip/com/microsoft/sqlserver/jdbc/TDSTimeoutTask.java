/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import java.util.UUID;
/*    */ import java.util.concurrent.atomic.AtomicLong;
/*    */ import java.util.logging.Level;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class TDSTimeoutTask
/*    */   implements Runnable
/*    */ {
/* 16 */   private static final AtomicLong COUNTER = new AtomicLong(0L);
/*    */   
/*    */   private final UUID connectionId;
/*    */   private final TDSCommand command;
/*    */   private final SQLServerConnection sqlServerConnection;
/*    */   
/*    */   public TDSTimeoutTask(TDSCommand command, SQLServerConnection sqlServerConnection) {
/* 23 */     this.connectionId = (sqlServerConnection == null) ? null : sqlServerConnection.getClientConIdInternal();
/* 24 */     this.command = command;
/* 25 */     this.sqlServerConnection = sqlServerConnection;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final void run() {
/* 32 */     String name = "mssql-timeout-task-" + COUNTER.incrementAndGet() + "-" + this.connectionId;
/* 33 */     Thread thread = new Thread(this::interrupt, name);
/* 34 */     thread.setDaemon(true);
/* 35 */     thread.start();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void interrupt() {
/*    */     try {
/* 44 */       if (null == this.command) {
/* 45 */         if (null != this.sqlServerConnection) {
/* 46 */           this.sqlServerConnection.terminate(3, 
/* 47 */               SQLServerException.getErrString("R_connectionIsClosed"));
/*    */         }
/*    */       }
/*    */       else {
/*    */         
/* 52 */         this.command.interrupt(SQLServerException.getErrString("R_queryTimedOut"));
/*    */       } 
/* 54 */     } catch (SQLServerException e) {
/*    */ 
/*    */       
/* 57 */       assert null != this.command;
/* 58 */       this.command.log(Level.WARNING, "Command could not be timed out. Reason: " + e.getMessage());
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\TDSTimeoutTask.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */