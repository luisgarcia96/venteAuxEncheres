/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.concurrent.ScheduledFuture;
/*     */ import java.util.concurrent.ScheduledThreadPoolExecutor;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SharedTimer
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -4069361613863955760L;
/*     */   static final String CORE_THREAD_PREFIX = "mssql-jdbc-shared-timer-core-";
/*  23 */   private static final AtomicLong CORE_THREAD_COUNTER = new AtomicLong();
/*  24 */   private static final Object lock = new Object();
/*     */ 
/*     */ 
/*     */   
/*  28 */   private final long id = CORE_THREAD_COUNTER.getAndIncrement();
/*     */ 
/*     */ 
/*     */   
/*  32 */   private final AtomicInteger refCount = new AtomicInteger();
/*     */   
/*     */   private static volatile SharedTimer instance;
/*     */   private ScheduledThreadPoolExecutor executor;
/*     */   
/*     */   private SharedTimer() {
/*  38 */     this.executor = new ScheduledThreadPoolExecutor(1, task -> {
/*     */           Thread t = new Thread(task, "mssql-jdbc-shared-timer-core-" + this.id);
/*     */           t.setDaemon(true);
/*     */           return t;
/*     */         });
/*  43 */     this.executor.setRemoveOnCancelPolicy(true);
/*     */   }
/*     */   
/*     */   public long getId() {
/*  47 */     return this.id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isRunning() {
/*  54 */     return (instance != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeRef() {
/*  63 */     synchronized (lock) {
/*  64 */       if (this.refCount.get() <= 0) {
/*  65 */         throw new IllegalStateException("removeRef() called more than actual references");
/*     */       }
/*  67 */       if (this.refCount.decrementAndGet() == 0) {
/*     */         
/*  69 */         this.executor.shutdownNow();
/*  70 */         this.executor = null;
/*  71 */         instance = null;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SharedTimer getTimer() {
/*  84 */     synchronized (lock) {
/*  85 */       if (instance == null)
/*     */       {
/*  87 */         instance = new SharedTimer();
/*     */       }
/*  89 */       instance.refCount.getAndIncrement();
/*  90 */       return instance;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ScheduledFuture<?> schedule(TDSTimeoutTask task, long delaySeconds) {
/*  98 */     return schedule(task, delaySeconds, TimeUnit.SECONDS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ScheduledFuture<?> schedule(TDSTimeoutTask task, long delay, TimeUnit unit) {
/* 105 */     if (this.executor == null) {
/* 106 */       throw new IllegalStateException("Cannot schedule tasks after shutdown");
/*     */     }
/* 108 */     return this.executor.schedule(task, delay, unit);
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SharedTimer.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */