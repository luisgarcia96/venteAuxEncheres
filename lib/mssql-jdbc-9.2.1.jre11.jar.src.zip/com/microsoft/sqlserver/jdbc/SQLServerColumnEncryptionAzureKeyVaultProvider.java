/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import com.azure.core.credential.TokenCredential;
/*     */ import com.azure.core.http.HttpPipeline;
/*     */ import com.azure.identity.ManagedIdentityCredentialBuilder;
/*     */ import com.azure.security.keyvault.keys.KeyClient;
/*     */ import com.azure.security.keyvault.keys.KeyClientBuilder;
/*     */ import com.azure.security.keyvault.keys.cryptography.CryptographyClient;
/*     */ import com.azure.security.keyvault.keys.cryptography.CryptographyClientBuilder;
/*     */ import com.azure.security.keyvault.keys.cryptography.models.KeyWrapAlgorithm;
/*     */ import com.azure.security.keyvault.keys.cryptography.models.SignResult;
/*     */ import com.azure.security.keyvault.keys.cryptography.models.SignatureAlgorithm;
/*     */ import com.azure.security.keyvault.keys.cryptography.models.UnwrapResult;
/*     */ import com.azure.security.keyvault.keys.cryptography.models.VerifyResult;
/*     */ import com.azure.security.keyvault.keys.cryptography.models.WrapResult;
/*     */ import com.azure.security.keyvault.keys.models.KeyType;
/*     */ import com.azure.security.keyvault.keys.models.KeyVaultKey;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SQLServerColumnEncryptionAzureKeyVaultProvider
/*     */   extends SQLServerColumnEncryptionKeyStoreProvider
/*     */ {
/*  57 */   private static final Logger akvLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.SQLServerColumnEncryptionAzureKeyVaultProvider");
/*     */   
/*     */   private static final int KEY_NAME_INDEX = 4;
/*     */   
/*     */   private static final int KEY_URL_SPLIT_LENGTH_WITH_VERSION = 6;
/*     */   
/*     */   private static final String KEY_URL_DELIMITER = "/";
/*     */   
/*     */   private static final String NULL_VALUE = "R_NullValue";
/*     */   
/*     */   private HttpPipeline keyVaultPipeline;
/*     */   private KeyVaultTokenCredential keyVaultTokenCredential;
/*  69 */   String name = "AZURE_KEY_VAULT";
/*     */   
/*     */   private static final String MSSQL_JDBC_PROPERTIES = "mssql-jdbc.properties";
/*     */   
/*     */   private static final String AKV_TRUSTED_ENDPOINTS_KEYWORD = "AKVTrustedEndpoints";
/*     */   private static final String RSA_ENCRYPTION_ALGORITHM_WITH_OAEP_FOR_AKV = "RSA-OAEP";
/*  75 */   private static final List<String> akvTrustedEndpoints = getTrustedEndpoints();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  80 */   private final byte[] firstVersion = new byte[] { 1 };
/*     */   
/*  82 */   private Map<String, KeyClient> cachedKeyClients = new ConcurrentHashMap<>();
/*  83 */   private Map<String, CryptographyClient> cachedCryptographyClients = new ConcurrentHashMap<>();
/*     */   private TokenCredential credential;
/*     */   
/*     */   public void setName(String name) {
/*  87 */     this.name = name;
/*     */   }
/*     */   
/*     */   public String getName() {
/*  91 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SQLServerColumnEncryptionAzureKeyVaultProvider(String clientId, String clientKey) throws SQLServerException {
/* 106 */     if (null == clientId || clientId.isEmpty()) {
/* 107 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_NullValue"));
/* 108 */       Object[] msgArgs1 = { "Client ID" };
/* 109 */       throw new SQLServerException(form.format(msgArgs1), null);
/*     */     } 
/* 111 */     if (null == clientKey || clientKey.isEmpty()) {
/* 112 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_NullValue"));
/* 113 */       Object[] msgArgs1 = { "Client Key" };
/* 114 */       throw new SQLServerException(form.format(msgArgs1), null);
/*     */     } 
/*     */ 
/*     */     
/* 118 */     this.keyVaultTokenCredential = new KeyVaultTokenCredential(clientId, clientKey);
/*     */     
/* 120 */     this.keyVaultPipeline = (new KeyVaultHttpPipelineBuilder()).credential(this.keyVaultTokenCredential).buildPipeline();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SQLServerColumnEncryptionAzureKeyVaultProvider() throws SQLServerException {
/* 131 */     setCredential((TokenCredential)(new ManagedIdentityCredentialBuilder()).build());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SQLServerColumnEncryptionAzureKeyVaultProvider(String clientId) throws SQLServerException {
/* 145 */     if (null == clientId || clientId.isEmpty()) {
/* 146 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_NullValue"));
/* 147 */       Object[] msgArgs1 = { "Client ID" };
/* 148 */       throw new SQLServerException(form.format(msgArgs1), null);
/*     */     } 
/* 150 */     setCredential((TokenCredential)(new ManagedIdentityCredentialBuilder()).clientId(clientId).build());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SQLServerColumnEncryptionAzureKeyVaultProvider(TokenCredential tokenCredential) throws SQLServerException {
/* 164 */     if (null == tokenCredential) {
/* 165 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_NullValue"));
/* 166 */       Object[] msgArgs1 = { "Token Credential" };
/* 167 */       throw new SQLServerException(form.format(msgArgs1), null);
/*     */     } 
/*     */     
/* 170 */     setCredential(tokenCredential);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SQLServerColumnEncryptionAzureKeyVaultProvider(SQLServerKeyVaultAuthenticationCallback authenticationCallback) throws SQLServerException {
/* 187 */     if (null == authenticationCallback) {
/* 188 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_NullValue"));
/* 189 */       Object[] msgArgs1 = { "SQLServerKeyVaultAuthenticationCallback" };
/* 190 */       throw new SQLServerException(form.format(msgArgs1), null);
/*     */     } 
/*     */     
/* 193 */     this.keyVaultTokenCredential = new KeyVaultTokenCredential(authenticationCallback);
/* 194 */     this.keyVaultPipeline = (new KeyVaultHttpPipelineBuilder()).credential(this.keyVaultTokenCredential).buildPipeline();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setCredential(TokenCredential credential) throws SQLServerException {
/* 206 */     if (null == credential) {
/* 207 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_NullValue"));
/* 208 */       Object[] msgArgs1 = { "Credential" };
/* 209 */       throw new SQLServerException(form.format(msgArgs1), null);
/*     */     } 
/*     */     
/* 212 */     this.credential = credential;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] decryptColumnEncryptionKey(String masterKeyPath, String encryptionAlgorithm, byte[] encryptedColumnEncryptionKey) throws SQLServerException {
/* 231 */     ValidateNonEmptyAKVPath(masterKeyPath);
/*     */     
/* 233 */     if (null == encryptedColumnEncryptionKey) {
/* 234 */       throw new SQLServerException(SQLServerException.getErrString("R_NullEncryptedColumnEncryptionKey"), null);
/*     */     }
/*     */     
/* 237 */     if (0 == encryptedColumnEncryptionKey.length) {
/* 238 */       throw new SQLServerException(SQLServerException.getErrString("R_EmptyEncryptedColumnEncryptionKey"), null);
/*     */     }
/*     */ 
/*     */     
/* 242 */     KeyWrapAlgorithm keyWrapAlgorithm = validateEncryptionAlgorithm(encryptionAlgorithm);
/*     */ 
/*     */     
/* 245 */     int keySizeInBytes = getAKVKeySize(masterKeyPath);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 256 */     if (encryptedColumnEncryptionKey[0] != this.firstVersion[0]) {
/*     */       
/* 258 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_InvalidEcryptionAlgorithmVersion"));
/*     */       
/* 260 */       Object[] msgArgs = { String.format("%02X ", new Object[] { Byte.valueOf(encryptedColumnEncryptionKey[0]) }), String.format("%02X ", new Object[] { Byte.valueOf(this.firstVersion[0]) }) };
/* 261 */       throw new SQLServerException(this, form.format(msgArgs), null, 0, false);
/*     */     } 
/*     */ 
/*     */     
/* 265 */     int currentIndex = this.firstVersion.length;
/* 266 */     short keyPathLength = convertTwoBytesToShort(encryptedColumnEncryptionKey, currentIndex);
/*     */     
/* 268 */     currentIndex += 2;
/*     */ 
/*     */     
/* 271 */     short cipherTextLength = convertTwoBytesToShort(encryptedColumnEncryptionKey, currentIndex);
/* 272 */     currentIndex += 2;
/*     */ 
/*     */ 
/*     */     
/* 276 */     currentIndex += keyPathLength;
/*     */ 
/*     */     
/* 279 */     if (cipherTextLength != keySizeInBytes) {
/* 280 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_AKVKeyLengthError"));
/* 281 */       Object[] msgArgs = { Short.valueOf(cipherTextLength), Integer.valueOf(keySizeInBytes), masterKeyPath };
/* 282 */       throw new SQLServerException(this, form.format(msgArgs), null, 0, false);
/*     */     } 
/*     */ 
/*     */     
/* 286 */     int signatureLength = encryptedColumnEncryptionKey.length - currentIndex - cipherTextLength;
/*     */     
/* 288 */     if (signatureLength != keySizeInBytes) {
/* 289 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_AKVSignatureLengthError"));
/* 290 */       Object[] msgArgs = { Integer.valueOf(signatureLength), Integer.valueOf(keySizeInBytes), masterKeyPath };
/* 291 */       throw new SQLServerException(this, form.format(msgArgs), null, 0, false);
/*     */     } 
/*     */ 
/*     */     
/* 295 */     byte[] cipherText = new byte[cipherTextLength];
/* 296 */     System.arraycopy(encryptedColumnEncryptionKey, currentIndex, cipherText, 0, cipherTextLength);
/* 297 */     currentIndex += cipherTextLength;
/*     */ 
/*     */     
/* 300 */     byte[] signature = new byte[signatureLength];
/* 301 */     System.arraycopy(encryptedColumnEncryptionKey, currentIndex, signature, 0, signatureLength);
/*     */ 
/*     */     
/* 304 */     byte[] hash = new byte[encryptedColumnEncryptionKey.length - signature.length];
/*     */     
/* 306 */     System.arraycopy(encryptedColumnEncryptionKey, 0, hash, 0, encryptedColumnEncryptionKey.length - signature.length);
/*     */ 
/*     */     
/* 309 */     MessageDigest md = null;
/*     */     try {
/* 311 */       md = MessageDigest.getInstance("SHA-256");
/* 312 */     } catch (NoSuchAlgorithmException e) {
/* 313 */       throw new SQLServerException(SQLServerException.getErrString("R_NoSHA256Algorithm"), e);
/*     */     } 
/* 315 */     md.update(hash);
/* 316 */     byte[] dataToVerify = md.digest();
/*     */     
/* 318 */     if (null == dataToVerify) {
/* 319 */       throw new SQLServerException(SQLServerException.getErrString("R_HashNull"), null);
/*     */     }
/*     */ 
/*     */     
/* 323 */     if (!AzureKeyVaultVerifySignature(dataToVerify, signature, masterKeyPath)) {
/* 324 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_CEKSignatureNotMatchCMK"));
/* 325 */       Object[] msgArgs = { masterKeyPath };
/* 326 */       throw new SQLServerException(this, form.format(msgArgs), null, 0, false);
/*     */     } 
/*     */ 
/*     */     
/* 330 */     byte[] decryptedCEK = AzureKeyVaultUnWrap(masterKeyPath, keyWrapAlgorithm, cipherText);
/*     */     
/* 332 */     return decryptedCEK;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private short convertTwoBytesToShort(byte[] input, int index) throws SQLServerException {
/* 338 */     if (index + 1 >= input.length) {
/* 339 */       throw new SQLServerException(null, SQLServerException.getErrString("R_ByteToShortConversion"), null, 0, false);
/*     */     }
/*     */     
/* 342 */     ByteBuffer byteBuffer = ByteBuffer.allocate(2);
/* 343 */     byteBuffer.order(ByteOrder.LITTLE_ENDIAN);
/* 344 */     byteBuffer.put(input[index]);
/* 345 */     byteBuffer.put(input[index + 1]);
/* 346 */     short shortVal = byteBuffer.getShort(0);
/* 347 */     return shortVal;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] encryptColumnEncryptionKey(String masterKeyPath, String encryptionAlgorithm, byte[] columnEncryptionKey) throws SQLServerException {
/* 367 */     ValidateNonEmptyAKVPath(masterKeyPath);
/*     */     
/* 369 */     if (null == columnEncryptionKey) {
/* 370 */       throw new SQLServerException(SQLServerException.getErrString("R_NullColumnEncryptionKey"), null);
/*     */     }
/*     */     
/* 373 */     if (0 == columnEncryptionKey.length) {
/* 374 */       throw new SQLServerException(SQLServerException.getErrString("R_EmptyCEK"), null);
/*     */     }
/*     */ 
/*     */     
/* 378 */     KeyWrapAlgorithm keyWrapAlgorithm = validateEncryptionAlgorithm(encryptionAlgorithm);
/*     */ 
/*     */     
/* 381 */     int keySizeInBytes = getAKVKeySize(masterKeyPath);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 388 */     byte[] version = { this.firstVersion[0] };
/*     */ 
/*     */     
/* 391 */     byte[] masterKeyPathBytes = masterKeyPath.toLowerCase(Locale.ENGLISH).getBytes(StandardCharsets.UTF_16LE);
/*     */     
/* 393 */     byte[] keyPathLength = new byte[2];
/* 394 */     keyPathLength[0] = (byte)((short)masterKeyPathBytes.length & 0xFF);
/* 395 */     keyPathLength[1] = (byte)((short)masterKeyPathBytes.length >> 8 & 0xFF);
/*     */ 
/*     */     
/* 398 */     byte[] cipherText = AzureKeyVaultWrap(masterKeyPath, keyWrapAlgorithm, columnEncryptionKey);
/*     */     
/* 400 */     byte[] cipherTextLength = new byte[2];
/* 401 */     cipherTextLength[0] = (byte)((short)cipherText.length & 0xFF);
/* 402 */     cipherTextLength[1] = (byte)((short)cipherText.length >> 8 & 0xFF);
/*     */     
/* 404 */     if (cipherText.length != keySizeInBytes) {
/* 405 */       throw new SQLServerException(SQLServerException.getErrString("R_CipherTextLengthNotMatchRSASize"), null);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 410 */     byte[] dataToHash = new byte[version.length + keyPathLength.length + cipherTextLength.length + masterKeyPathBytes.length + cipherText.length];
/*     */     
/* 412 */     int destinationPosition = version.length;
/* 413 */     System.arraycopy(version, 0, dataToHash, 0, version.length);
/*     */     
/* 415 */     System.arraycopy(keyPathLength, 0, dataToHash, destinationPosition, keyPathLength.length);
/* 416 */     destinationPosition += keyPathLength.length;
/*     */     
/* 418 */     System.arraycopy(cipherTextLength, 0, dataToHash, destinationPosition, cipherTextLength.length);
/* 419 */     destinationPosition += cipherTextLength.length;
/*     */     
/* 421 */     System.arraycopy(masterKeyPathBytes, 0, dataToHash, destinationPosition, masterKeyPathBytes.length);
/* 422 */     destinationPosition += masterKeyPathBytes.length;
/*     */     
/* 424 */     System.arraycopy(cipherText, 0, dataToHash, destinationPosition, cipherText.length);
/*     */     
/* 426 */     MessageDigest md = null;
/*     */     try {
/* 428 */       md = MessageDigest.getInstance("SHA-256");
/* 429 */     } catch (NoSuchAlgorithmException e) {
/* 430 */       throw new SQLServerException(SQLServerException.getErrString("R_NoSHA256Algorithm"), e);
/*     */     } 
/* 432 */     md.update(dataToHash);
/* 433 */     byte[] dataToSign = md.digest();
/*     */ 
/*     */     
/* 436 */     byte[] signedHash = AzureKeyVaultSignHashedData(dataToSign, masterKeyPath);
/*     */     
/* 438 */     if (signedHash.length != keySizeInBytes) {
/* 439 */       throw new SQLServerException(SQLServerException.getErrString("R_SignedHashLengthError"), null);
/*     */     }
/*     */     
/* 442 */     if (!AzureKeyVaultVerifySignature(dataToSign, signedHash, masterKeyPath)) {
/* 443 */       throw new SQLServerException(SQLServerException.getErrString("R_InvalidSignatureComputed"), null);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 448 */     int encryptedColumnEncryptionKeyLength = version.length + cipherTextLength.length + keyPathLength.length + cipherText.length + masterKeyPathBytes.length + signedHash.length;
/*     */     
/* 450 */     byte[] encryptedColumnEncryptionKey = new byte[encryptedColumnEncryptionKeyLength];
/*     */ 
/*     */     
/* 453 */     int currentIndex = 0;
/* 454 */     System.arraycopy(version, 0, encryptedColumnEncryptionKey, currentIndex, version.length);
/* 455 */     currentIndex += version.length;
/*     */ 
/*     */     
/* 458 */     System.arraycopy(keyPathLength, 0, encryptedColumnEncryptionKey, currentIndex, keyPathLength.length);
/* 459 */     currentIndex += keyPathLength.length;
/*     */ 
/*     */     
/* 462 */     System.arraycopy(cipherTextLength, 0, encryptedColumnEncryptionKey, currentIndex, cipherTextLength.length);
/* 463 */     currentIndex += cipherTextLength.length;
/*     */ 
/*     */     
/* 466 */     System.arraycopy(masterKeyPathBytes, 0, encryptedColumnEncryptionKey, currentIndex, masterKeyPathBytes.length);
/* 467 */     currentIndex += masterKeyPathBytes.length;
/*     */ 
/*     */     
/* 470 */     System.arraycopy(cipherText, 0, encryptedColumnEncryptionKey, currentIndex, cipherText.length);
/* 471 */     currentIndex += cipherText.length;
/*     */ 
/*     */     
/* 474 */     System.arraycopy(signedHash, 0, encryptedColumnEncryptionKey, currentIndex, signedHash.length);
/*     */     
/* 476 */     return encryptedColumnEncryptionKey;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private KeyWrapAlgorithm validateEncryptionAlgorithm(String encryptionAlgorithm) throws SQLServerException {
/* 489 */     if (null == encryptionAlgorithm) {
/* 490 */       throw new SQLServerException(null, SQLServerException.getErrString("R_NullKeyEncryptionAlgorithm"), null, 0, false);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 495 */     if ("RSA_OAEP".equalsIgnoreCase(encryptionAlgorithm)) {
/* 496 */       encryptionAlgorithm = "RSA-OAEP";
/*     */     }
/*     */     
/* 499 */     if (!"RSA-OAEP".equalsIgnoreCase(encryptionAlgorithm.trim())) {
/* 500 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_InvalidKeyEncryptionAlgorithm"));
/* 501 */       Object[] msgArgs = { encryptionAlgorithm, "RSA-OAEP" };
/* 502 */       throw new SQLServerException(this, form.format(msgArgs), null, 0, false);
/*     */     } 
/*     */     
/* 505 */     return KeyWrapAlgorithm.fromString(encryptionAlgorithm);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void ValidateNonEmptyAKVPath(String masterKeyPath) throws SQLServerException {
/* 516 */     if (null == masterKeyPath || masterKeyPath.trim().isEmpty()) {
/* 517 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_AKVPathNull"));
/* 518 */       Object[] arrayOfObject = { masterKeyPath };
/* 519 */       throw new SQLServerException(null, messageFormat.format(arrayOfObject), null, 0, false);
/*     */     } 
/* 521 */     URI parsedUri = null;
/*     */     try {
/* 523 */       parsedUri = new URI(masterKeyPath);
/*     */ 
/*     */ 
/*     */       
/* 527 */       String host = parsedUri.getHost();
/* 528 */       if (null != host) {
/* 529 */         host = host.toLowerCase(Locale.ENGLISH);
/*     */       }
/* 531 */       for (String endpoint : akvTrustedEndpoints) {
/* 532 */         if (null != host && host.endsWith(endpoint)) {
/*     */           return;
/*     */         }
/*     */       } 
/* 536 */     } catch (URISyntaxException e) {
/* 537 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_AKVURLInvalid"));
/* 538 */       Object[] arrayOfObject = { masterKeyPath };
/* 539 */       throw new SQLServerException(messageFormat.format(arrayOfObject), null, 0, e);
/*     */     } 
/*     */     
/* 542 */     MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_AKVMasterKeyPathInvalid"));
/* 543 */     Object[] msgArgs = { masterKeyPath };
/* 544 */     throw new SQLServerException(null, form.format(msgArgs), null, 0, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] AzureKeyVaultWrap(String masterKeyPath, KeyWrapAlgorithm encryptionAlgorithm, byte[] columnEncryptionKey) throws SQLServerException {
/* 562 */     if (null == columnEncryptionKey) {
/* 563 */       throw new SQLServerException(SQLServerException.getErrString("R_CEKNull"), null);
/*     */     }
/*     */     
/* 566 */     CryptographyClient cryptoClient = getCryptographyClient(masterKeyPath);
/* 567 */     WrapResult wrappedKey = cryptoClient.wrapKey(KeyWrapAlgorithm.RSA_OAEP, columnEncryptionKey);
/* 568 */     return wrappedKey.getEncryptedKey();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] AzureKeyVaultUnWrap(String masterKeyPath, KeyWrapAlgorithm encryptionAlgorithm, byte[] encryptedColumnEncryptionKey) throws SQLServerException {
/* 585 */     if (null == encryptedColumnEncryptionKey) {
/* 586 */       throw new SQLServerException(SQLServerException.getErrString("R_EncryptedCEKNull"), null);
/*     */     }
/*     */     
/* 589 */     if (0 == encryptedColumnEncryptionKey.length) {
/* 590 */       throw new SQLServerException(SQLServerException.getErrString("R_EmptyEncryptedCEK"), null);
/*     */     }
/*     */     
/* 593 */     CryptographyClient cryptoClient = getCryptographyClient(masterKeyPath);
/*     */     
/* 595 */     UnwrapResult unwrappedKey = cryptoClient.unwrapKey(encryptionAlgorithm, encryptedColumnEncryptionKey);
/*     */     
/* 597 */     return unwrappedKey.getKey();
/*     */   }
/*     */   private CryptographyClient getCryptographyClient(String masterKeyPath) throws SQLServerException {
/*     */     CryptographyClient cryptoClient;
/* 601 */     if (this.cachedCryptographyClients.containsKey(masterKeyPath)) {
/* 602 */       return this.cachedCryptographyClients.get(masterKeyPath);
/*     */     }
/*     */     
/* 605 */     KeyVaultKey retrievedKey = getKeyVaultKey(masterKeyPath);
/*     */ 
/*     */     
/* 608 */     if (null != this.credential) {
/*     */       
/* 610 */       cryptoClient = (new CryptographyClientBuilder()).credential(this.credential).keyIdentifier(retrievedKey.getId()).buildClient();
/*     */     } else {
/*     */       
/* 613 */       cryptoClient = (new CryptographyClientBuilder()).pipeline(this.keyVaultPipeline).keyIdentifier(retrievedKey.getId()).buildClient();
/*     */     } 
/* 615 */     this.cachedCryptographyClients.putIfAbsent(masterKeyPath, cryptoClient);
/* 616 */     return this.cachedCryptographyClients.get(masterKeyPath);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] AzureKeyVaultSignHashedData(byte[] dataToSign, String masterKeyPath) throws SQLServerException {
/* 630 */     assert null != dataToSign && 0 != dataToSign.length;
/*     */     
/* 632 */     CryptographyClient cryptoClient = getCryptographyClient(masterKeyPath);
/* 633 */     SignResult signedData = cryptoClient.sign(SignatureAlgorithm.RS256, dataToSign);
/* 634 */     return signedData.getSignature();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean AzureKeyVaultVerifySignature(byte[] dataToVerify, byte[] signature, String masterKeyPath) throws SQLServerException {
/* 649 */     assert null != dataToVerify && 0 != dataToVerify.length;
/* 650 */     assert null != signature && 0 != signature.length;
/*     */     
/* 652 */     CryptographyClient cryptoClient = getCryptographyClient(masterKeyPath);
/* 653 */     VerifyResult valid = cryptoClient.verify(SignatureAlgorithm.RS256, dataToVerify, signature);
/*     */     
/* 655 */     return valid.isValid().booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int getAKVKeySize(String masterKeyPath) throws SQLServerException {
/* 668 */     KeyVaultKey retrievedKey = getKeyVaultKey(masterKeyPath);
/* 669 */     return (retrievedKey.getKey().getN()).length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private KeyVaultKey getKeyVaultKey(String masterKeyPath) throws SQLServerException {
/* 683 */     String[] keyTokens = masterKeyPath.split("/");
/* 684 */     String keyName = keyTokens[4];
/* 685 */     String keyVersion = null;
/* 686 */     if (keyTokens.length == 6) {
/* 687 */       keyVersion = keyTokens[keyTokens.length - 1];
/*     */     }
/*     */     try {
/*     */       KeyVaultKey retrievedKey;
/* 691 */       KeyClient keyClient = getKeyClient(masterKeyPath);
/*     */       
/* 693 */       if (null != keyVersion) {
/* 694 */         retrievedKey = keyClient.getKey(keyName, keyVersion);
/*     */       } else {
/* 696 */         retrievedKey = keyClient.getKey(keyName);
/*     */       } 
/* 698 */       if (null == retrievedKey) {
/* 699 */         MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_AKVKeyNotFound"));
/* 700 */         Object[] msgArgs = { keyTokens[keyTokens.length - 1] };
/* 701 */         throw new SQLServerException(null, form.format(msgArgs), null, 0, false);
/*     */       } 
/*     */       
/* 704 */       if (retrievedKey.getKeyType() != KeyType.RSA && retrievedKey.getKeyType() != KeyType.RSA_HSM) {
/* 705 */         MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_NonRSAKey"));
/* 706 */         Object[] msgArgs = { retrievedKey.getKeyType().toString() };
/* 707 */         throw new SQLServerException(null, form.format(msgArgs), null, 0, false);
/*     */       } 
/* 709 */       return retrievedKey;
/* 710 */     } catch (RuntimeException e) {
/* 711 */       throw new SQLServerException(e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private KeyClient getKeyClient(String masterKeyPath) {
/*     */     KeyClient keyClient;
/* 725 */     if (this.cachedKeyClients.containsKey(masterKeyPath)) {
/* 726 */       return this.cachedKeyClients.get(masterKeyPath);
/*     */     }
/* 728 */     String vaultUrl = getVaultUrl(masterKeyPath);
/*     */ 
/*     */     
/* 731 */     if (null != this.credential) {
/* 732 */       keyClient = (new KeyClientBuilder()).credential(this.credential).vaultUrl(vaultUrl).buildClient();
/*     */     } else {
/* 734 */       keyClient = (new KeyClientBuilder()).pipeline(this.keyVaultPipeline).vaultUrl(vaultUrl).buildClient();
/*     */     } 
/* 736 */     this.cachedKeyClients.putIfAbsent(masterKeyPath, keyClient);
/* 737 */     return this.cachedKeyClients.get(masterKeyPath);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getVaultUrl(String masterKeyPath) {
/* 748 */     String[] keyTokens = masterKeyPath.split("/");
/* 749 */     String hostName = keyTokens[2];
/* 750 */     return "https://" + hostName;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean verifyColumnMasterKeyMetadata(String masterKeyPath, boolean allowEnclaveComputations, byte[] signature) throws SQLServerException {
/* 756 */     if (!allowEnclaveComputations) {
/* 757 */       return false;
/*     */     }
/*     */     
/* 760 */     KeyStoreProviderCommon.validateNonEmptyMasterKeyPath(masterKeyPath);
/*     */     
/*     */     try {
/* 763 */       MessageDigest md = MessageDigest.getInstance("SHA-256");
/* 764 */       md.update(this.name.toLowerCase().getBytes(StandardCharsets.UTF_16LE));
/* 765 */       md.update(masterKeyPath.toLowerCase().getBytes(StandardCharsets.UTF_16LE));
/*     */       
/* 767 */       md.update("true".getBytes(StandardCharsets.UTF_16LE));
/*     */       
/* 769 */       byte[] dataToVerify = md.digest();
/* 770 */       if (null == dataToVerify) {
/* 771 */         throw new SQLServerException(SQLServerException.getErrString("R_HashNull"), null);
/*     */       }
/*     */ 
/*     */       
/* 775 */       byte[] signedHash = AzureKeyVaultSignHashedData(dataToVerify, masterKeyPath);
/* 776 */       if (null == signedHash) {
/* 777 */         throw new SQLServerException(SQLServerException.getErrString("R_SignedHashLengthError"), null);
/*     */       }
/*     */ 
/*     */       
/* 781 */       return AzureKeyVaultVerifySignature(dataToVerify, signature, masterKeyPath);
/* 782 */     } catch (NoSuchAlgorithmException e) {
/* 783 */       throw new SQLServerException(SQLServerException.getErrString("R_NoSHA256Algorithm"), e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static List<String> getTrustedEndpoints() {
/* 788 */     Properties mssqlJdbcProperties = getMssqlJdbcProperties();
/* 789 */     List<String> trustedEndpoints = new ArrayList<>();
/* 790 */     boolean append = true;
/* 791 */     if (null != mssqlJdbcProperties) {
/* 792 */       String endpoints = mssqlJdbcProperties.getProperty("AKVTrustedEndpoints");
/* 793 */       if (null != endpoints && !endpoints.trim().isEmpty()) {
/* 794 */         endpoints = endpoints.trim();
/*     */         
/* 796 */         if (';' != endpoints.charAt(0)) {
/* 797 */           append = false;
/*     */         } else {
/* 799 */           endpoints = endpoints.substring(1);
/*     */         } 
/* 801 */         String[] entries = endpoints.split(";");
/* 802 */         for (String entry : entries) {
/* 803 */           if (null != entry && !entry.trim().isEmpty()) {
/* 804 */             trustedEndpoints.add(entry.trim());
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 813 */     if (append) {
/* 814 */       trustedEndpoints.add("vault.azure.net");
/* 815 */       trustedEndpoints.add("vault.azure.cn");
/* 816 */       trustedEndpoints.add("vault.usgovcloudapi.net");
/* 817 */       trustedEndpoints.add("vault.microsoftazure.de");
/* 818 */       trustedEndpoints.add("managedhsm.azure.net");
/* 819 */       trustedEndpoints.add("managedhsm.azure.cn");
/* 820 */       trustedEndpoints.add("managedhsm.usgovcloudapi.net");
/* 821 */       trustedEndpoints.add("managedhsm.microsoftazure.de");
/*     */     } 
/* 823 */     return trustedEndpoints;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Properties getMssqlJdbcProperties() {
/* 832 */     Properties props = null; 
/* 833 */     try { FileInputStream in = new FileInputStream("mssql-jdbc.properties"); 
/* 834 */       try { props = new Properties();
/* 835 */         props.load(in);
/* 836 */         in.close(); } catch (Throwable throwable) { try { in.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } catch (IOException e)
/* 837 */     { if (akvLogger.isLoggable(Level.FINER)) {
/* 838 */         akvLogger.finer("Unable to load the mssql-jdbc.properties file: " + e);
/*     */       } }
/*     */     
/* 841 */     return (null != props && !props.isEmpty()) ? props : null;
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerColumnEncryptionAzureKeyVaultProvider.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */