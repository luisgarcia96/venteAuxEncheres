/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Arrays;
/*    */ import java.util.Properties;
/*    */ import javax.security.auth.callback.Callback;
/*    */ import javax.security.auth.callback.CallbackHandler;
/*    */ import javax.security.auth.callback.NameCallback;
/*    */ import javax.security.auth.callback.PasswordCallback;
/*    */ import javax.security.auth.callback.UnsupportedCallbackException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class KerbCallback
/*    */   implements CallbackHandler
/*    */ {
/*    */   private final SQLServerConnection con;
/* 25 */   private String usernameRequested = null;
/*    */   
/*    */   KerbCallback(SQLServerConnection con) {
/* 28 */     this.con = con;
/*    */   }
/*    */ 
/*    */   
/*    */   private static String getAnyOf(Callback callback, Properties properties, String... names) throws UnsupportedCallbackException {
/* 33 */     for (String name : names) {
/* 34 */       String val = properties.getProperty(name);
/* 35 */       if (val != null && !val.trim().isEmpty()) {
/* 36 */         return val;
/*    */       }
/*    */     } 
/* 39 */     throw new UnsupportedCallbackException(callback, "Cannot get any of properties: " + 
/* 40 */         Arrays.toString(names) + " from con properties");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getUsernameRequested() {
/* 49 */     return this.usernameRequested;
/*    */   }
/*    */ 
/*    */   
/*    */   public void handle(Callback[] callbacks) throws IOException, UnsupportedCallbackException {
/* 54 */     for (Callback callback : callbacks) {
/* 55 */       if (callback instanceof NameCallback) {
/* 56 */         this.usernameRequested = getAnyOf(callback, this.con.activeConnectionProperties, new String[] { "user", SQLServerDriverStringProperty.USER
/* 57 */               .name() });
/* 58 */         ((NameCallback)callback).setName(this.usernameRequested);
/* 59 */       } else if (callback instanceof PasswordCallback) {
/* 60 */         String password = getAnyOf(callback, this.con.activeConnectionProperties, new String[] { "password", SQLServerDriverStringProperty.PASSWORD
/* 61 */               .name() });
/* 62 */         ((PasswordCallback)callback).setPassword(password.toCharArray());
/*    */       } else {
/*    */         
/* 65 */         throw new UnsupportedCallbackException(callback, "Unrecognized Callback type: " + callback.getClass());
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\KerbCallback.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */