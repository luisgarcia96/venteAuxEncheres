/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.Reader;
/*     */ import java.io.Writer;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLXML;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.parsers.SAXParser;
/*     */ import javax.xml.parsers.SAXParserFactory;
/*     */ import javax.xml.stream.XMLInputFactory;
/*     */ import javax.xml.stream.XMLOutputFactory;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import javax.xml.stream.XMLStreamWriter;
/*     */ import javax.xml.transform.Result;
/*     */ import javax.xml.transform.Source;
/*     */ import javax.xml.transform.TransformerConfigurationException;
/*     */ import javax.xml.transform.TransformerException;
/*     */ import javax.xml.transform.TransformerFactory;
/*     */ import javax.xml.transform.dom.DOMResult;
/*     */ import javax.xml.transform.dom.DOMSource;
/*     */ import javax.xml.transform.sax.SAXResult;
/*     */ import javax.xml.transform.sax.SAXSource;
/*     */ import javax.xml.transform.sax.SAXTransformerFactory;
/*     */ import javax.xml.transform.sax.TransformerHandler;
/*     */ import javax.xml.transform.stax.StAXResult;
/*     */ import javax.xml.transform.stax.StAXSource;
/*     */ import javax.xml.transform.stream.StreamResult;
/*     */ import javax.xml.transform.stream.StreamSource;
/*     */ import org.w3c.dom.Document;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.XMLReader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SQLServerSQLXML
/*     */   implements SQLXML
/*     */ {
/*     */   private final SQLServerConnection con;
/*     */   private final PLPXMLInputStream contents;
/*     */   private final InputStreamGetterArgs getterArgs;
/*     */   private final TypeInfo typeInfo;
/*     */   private boolean isUsed = false;
/*     */   private boolean isFreed = false;
/*  67 */   private static final Logger logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerSQLXML");
/*     */ 
/*     */   
/*     */   private ByteArrayOutputStreamToInputStream outputStreamValue;
/*     */   
/*     */   private Document docValue;
/*     */   
/*     */   private String strValue;
/*     */   
/*  76 */   private static final AtomicInteger baseID = new AtomicInteger(0);
/*     */   
/*     */   private final String traceID;
/*     */   
/*     */   public final String toString() {
/*  81 */     return this.traceID;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int nextInstanceID() {
/*  90 */     return baseID.incrementAndGet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   InputStream getValue() throws SQLServerException {
/*  97 */     checkClosed();
/*     */ 
/*     */ 
/*     */     
/* 101 */     if (!this.isUsed) {
/* 102 */       SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_noDataXML"), null, true);
/*     */     }
/* 104 */     assert null == this.contents;
/* 105 */     ByteArrayInputStream o = null;
/* 106 */     if (null != this.outputStreamValue) {
/* 107 */       o = this.outputStreamValue.getInputStream();
/* 108 */       assert null == this.docValue;
/* 109 */       assert null == this.strValue;
/* 110 */     } else if (null != this.docValue) {
/* 111 */       assert null == this.outputStreamValue;
/* 112 */       assert null == this.strValue;
/* 113 */       ByteArrayOutputStreamToInputStream strm = new ByteArrayOutputStreamToInputStream();
/*     */ 
/*     */       
/*     */       try {
/* 117 */         TransformerFactory factory = TransformerFactory.newInstance();
/* 118 */         factory.setFeature("http://javax.xml.XMLConstants/feature/secure-processing", true);
/* 119 */         factory.newTransformer().transform(new DOMSource(this.docValue), new StreamResult(strm));
/* 120 */       } catch (TransformerException e) {
/* 121 */         MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_noParserSupport"));
/* 122 */         Object[] msgArgs = { e.toString() };
/* 123 */         SQLServerException.makeFromDriverError(this.con, null, form.format(msgArgs), null, true);
/*     */       } 
/* 125 */       o = strm.getInputStream();
/*     */     } else {
/* 127 */       assert null == this.outputStreamValue;
/* 128 */       assert null == this.docValue;
/* 129 */       assert null != this.strValue;
/* 130 */       o = new ByteArrayInputStream(this.strValue.getBytes(Encoding.UNICODE.charset()));
/*     */     } 
/* 132 */     assert null != o;
/* 133 */     this.isFreed = true;
/* 134 */     return o;
/*     */   }
/*     */ 
/*     */   
/*     */   SQLServerSQLXML(SQLServerConnection connection) {
/* 139 */     this.contents = null;
/* 140 */     this.traceID = " SQLServerSQLXML:" + nextInstanceID();
/* 141 */     this.con = connection;
/*     */     
/* 143 */     if (logger.isLoggable(Level.FINE))
/* 144 */       logger.fine(toString() + " created by (" + toString() + ")"); 
/* 145 */     this.getterArgs = null;
/* 146 */     this.typeInfo = null;
/*     */   }
/*     */   
/*     */   SQLServerSQLXML(InputStream stream, InputStreamGetterArgs getterArgs, TypeInfo typeInfo) throws SQLServerException {
/* 150 */     this.traceID = " SQLServerSQLXML:" + nextInstanceID();
/* 151 */     this.contents = (PLPXMLInputStream)stream;
/* 152 */     this.con = null;
/* 153 */     this.getterArgs = getterArgs;
/* 154 */     this.typeInfo = typeInfo;
/* 155 */     if (logger.isLoggable(Level.FINE))
/* 156 */       logger.fine(toString() + " created by (null connection)"); 
/*     */   }
/*     */   
/*     */   InputStream getStream() {
/* 160 */     return this.contents;
/*     */   }
/*     */ 
/*     */   
/*     */   public void free() throws SQLException {
/* 165 */     if (!this.isFreed) {
/* 166 */       this.isFreed = true;
/* 167 */       if (null != this.contents) {
/*     */         try {
/* 169 */           this.contents.close();
/* 170 */         } catch (IOException e) {
/* 171 */           SQLServerException.makeFromDriverError(null, null, e.getMessage(), null, true);
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void checkClosed() throws SQLServerException {
/* 178 */     if (this.isFreed || (null != this.con && this.con.isClosed())) {
/* 179 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_isFreed"));
/* 180 */       SQLServerException.makeFromDriverError(this.con, null, form.format(new Object[] { "SQLXML" }, ), null, true);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void checkReadXML() throws SQLException {
/* 185 */     if (null == this.contents) {
/* 186 */       SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_writeOnlyXML"), null, true);
/*     */     }
/* 188 */     if (this.isUsed) {
/* 189 */       SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_dataHasBeenReadXML"), null, true);
/*     */     }
/*     */     try {
/* 192 */       this.contents.checkClosed();
/* 193 */     } catch (IOException e) {
/* 194 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_isFreed"));
/* 195 */       SQLServerException.makeFromDriverError(this.con, null, form.format(new Object[] { "SQLXML" }, ), null, true);
/*     */     } 
/*     */   }
/*     */   
/*     */   void checkWriteXML() throws SQLException {
/* 200 */     if (null != this.contents) {
/* 201 */       SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_readOnlyXML"), null, true);
/*     */     }
/* 203 */     if (this.isUsed) {
/* 204 */       SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_dataHasBeenSetXML"), null, true);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputStream getBinaryStream() throws SQLException {
/* 218 */     checkClosed();
/* 219 */     checkReadXML();
/* 220 */     this.isUsed = true;
/* 221 */     return this.contents;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OutputStream setBinaryStream() throws SQLException {
/* 234 */     checkClosed();
/* 235 */     checkWriteXML();
/* 236 */     this.isUsed = true;
/* 237 */     this.outputStreamValue = new ByteArrayOutputStreamToInputStream();
/* 238 */     return this.outputStreamValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public Writer setCharacterStream() throws SQLException {
/* 243 */     checkClosed();
/* 244 */     checkWriteXML();
/* 245 */     this.isUsed = true;
/* 246 */     this.outputStreamValue = new ByteArrayOutputStreamToInputStream();
/* 247 */     return new OutputStreamWriter(this.outputStreamValue, Encoding.UNICODE.charset());
/*     */   }
/*     */ 
/*     */   
/*     */   public Reader getCharacterStream() throws SQLException {
/* 252 */     checkClosed();
/* 253 */     checkReadXML();
/* 254 */     this.isUsed = true;
/* 255 */     StreamType type = StreamType.CHARACTER;
/* 256 */     InputStreamGetterArgs newArgs = new InputStreamGetterArgs(type, this.getterArgs.isAdaptive, this.getterArgs.isStreaming, this.getterArgs.logContext);
/*     */ 
/*     */     
/* 259 */     assert null != this.contents;
/*     */     
/*     */     try {
/* 262 */       this.contents.read();
/* 263 */       this.contents.read();
/* 264 */     } catch (IOException e) {
/* 265 */       SQLServerException.makeFromDriverError(null, null, e.getMessage(), null, true);
/*     */     } 
/*     */     
/* 268 */     Reader rd = (Reader)DDC.convertStreamToObject(this.contents, this.typeInfo, type.getJDBCType(), newArgs);
/* 269 */     return rd;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getString() throws SQLException {
/* 274 */     checkClosed();
/* 275 */     checkReadXML();
/* 276 */     this.isUsed = true;
/* 277 */     assert null != this.contents;
/*     */     
/*     */     try {
/* 280 */       this.contents.read();
/* 281 */       this.contents.read();
/* 282 */     } catch (IOException e) {
/* 283 */       SQLServerException.makeFromDriverError(null, null, e.getMessage(), null, true);
/*     */     } 
/*     */     
/* 286 */     byte[] byteContents = this.contents.getBytes();
/* 287 */     return new String(byteContents, 0, byteContents.length, Encoding.UNICODE.charset());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setString(String value) throws SQLException {
/* 292 */     checkClosed();
/* 293 */     checkWriteXML();
/* 294 */     this.isUsed = true;
/* 295 */     if (null == value) {
/* 296 */       SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_cantSetNull"), null, true);
/*     */     }
/* 298 */     this.strValue = value;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends Source> T getSource(Class<T> iface) throws SQLException {
/* 304 */     checkClosed();
/* 305 */     checkReadXML();
/* 306 */     if (null == iface) {
/*     */ 
/*     */ 
/*     */       
/* 310 */       T src = getSourceInternal((Class)StreamSource.class);
/* 311 */       return src;
/*     */     } 
/* 313 */     return getSourceInternal(iface);
/*     */   }
/*     */   <T extends Source> T getSourceInternal(Class<T> iface) throws SQLException {
/*     */     Source source;
/* 317 */     this.isUsed = true;
/* 318 */     T src = null;
/* 319 */     if (DOMSource.class == iface) {
/* 320 */       source = (Source)iface.cast(getDOMSource());
/* 321 */     } else if (SAXSource.class == iface) {
/* 322 */       source = (Source)iface.cast(getSAXSource());
/* 323 */     } else if (StAXSource.class == iface) {
/* 324 */       source = (Source)iface.cast(getStAXSource());
/* 325 */     } else if (StreamSource.class == iface) {
/* 326 */       source = (Source)iface.cast(new StreamSource(this.contents));
/*     */     } else {
/*     */       
/* 329 */       SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_notSupported"), null, true);
/*     */     } 
/* 331 */     return (T)source;
/*     */   }
/*     */ 
/*     */   
/*     */   public <T extends Result> T setResult(Class<T> resultClass) throws SQLException {
/* 336 */     checkClosed();
/* 337 */     checkWriteXML();
/* 338 */     if (null == resultClass) {
/*     */ 
/*     */ 
/*     */       
/* 342 */       T result = setResultInternal((Class)StreamResult.class);
/* 343 */       return result;
/*     */     } 
/* 345 */     return setResultInternal(resultClass);
/*     */   }
/*     */   
/*     */   <T extends Result> T setResultInternal(Class<T> resultClass) throws SQLException {
/*     */     Result result1;
/* 350 */     this.isUsed = true;
/* 351 */     T result = null;
/* 352 */     if (DOMResult.class == resultClass) {
/* 353 */       result1 = (Result)resultClass.cast(getDOMResult());
/* 354 */     } else if (SAXResult.class == resultClass) {
/* 355 */       result1 = (Result)resultClass.cast(getSAXResult());
/* 356 */     } else if (StAXResult.class == resultClass) {
/* 357 */       result1 = (Result)resultClass.cast(getStAXResult());
/* 358 */     } else if (StreamResult.class == resultClass) {
/* 359 */       this.outputStreamValue = new ByteArrayOutputStreamToInputStream();
/* 360 */       result1 = (Result)resultClass.cast(new StreamResult(this.outputStreamValue));
/*     */     } else {
/* 362 */       SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_notSupported"), null, true);
/*     */     } 
/* 364 */     return (T)result1;
/*     */   }
/*     */ 
/*     */   
/*     */   private DOMSource getDOMSource() throws SQLException {
/* 369 */     Document document = null;
/* 370 */     DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 379 */       factory.setFeature("http://javax.xml.XMLConstants/feature/secure-processing", true);
/* 380 */       DocumentBuilder builder = factory.newDocumentBuilder();
/*     */ 
/*     */       
/* 383 */       builder.setEntityResolver(new SQLServerEntityResolver());
/*     */       try {
/* 385 */         document = builder.parse(this.contents);
/* 386 */       } catch (IOException e) {
/* 387 */         MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_errorReadingStream"));
/* 388 */         Object[] msgArgs = { e.toString() };
/* 389 */         SQLServerException.makeFromDriverError(null, null, form.format(msgArgs), "", true);
/*     */       } 
/* 391 */       DOMSource inputSource = new DOMSource(document);
/* 392 */       return inputSource;
/*     */     }
/* 394 */     catch (ParserConfigurationException e) {
/* 395 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_noParserSupport"));
/* 396 */       Object[] msgArgs = { e.toString() };
/* 397 */       SQLServerException.makeFromDriverError(this.con, null, form.format(msgArgs), null, true);
/* 398 */     } catch (SAXException e) {
/* 399 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_failedToParseXML"));
/* 400 */       Object[] msgArgs = { e.toString() };
/* 401 */       SQLServerException.makeFromDriverError(this.con, null, form.format(msgArgs), null, true);
/*     */     } 
/* 403 */     return null;
/*     */   }
/*     */   
/*     */   private SAXSource getSAXSource() throws SQLException {
/*     */     try {
/* 408 */       InputSource src = new InputSource(this.contents);
/* 409 */       SAXParserFactory factory = SAXParserFactory.newInstance();
/* 410 */       SAXParser parser = factory.newSAXParser();
/* 411 */       XMLReader reader = parser.getXMLReader();
/* 412 */       SAXSource saxSource = new SAXSource(reader, src);
/* 413 */       return saxSource;
/*     */     }
/* 415 */     catch (SAXException|ParserConfigurationException e) {
/* 416 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_failedToParseXML"));
/* 417 */       Object[] msgArgs = { e.toString() };
/* 418 */       SQLServerException.makeFromDriverError(this.con, null, form.format(msgArgs), null, true);
/*     */       
/* 420 */       return null;
/*     */     } 
/*     */   }
/*     */   private StAXSource getStAXSource() throws SQLException {
/* 424 */     XMLInputFactory factory = XMLInputFactory.newInstance();
/*     */     try {
/* 426 */       XMLStreamReader r = factory.createXMLStreamReader(this.contents);
/* 427 */       StAXSource result = new StAXSource(r);
/* 428 */       return result;
/*     */     }
/* 430 */     catch (XMLStreamException e) {
/* 431 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_noParserSupport"));
/* 432 */       Object[] msgArgs = { e.toString() };
/* 433 */       SQLServerException.makeFromDriverError(this.con, null, form.format(msgArgs), null, true);
/*     */       
/* 435 */       return null;
/*     */     } 
/*     */   }
/*     */   private StAXResult getStAXResult() throws SQLException {
/* 439 */     XMLOutputFactory factory = XMLOutputFactory.newInstance();
/* 440 */     this.outputStreamValue = new ByteArrayOutputStreamToInputStream();
/*     */     try {
/* 442 */       XMLStreamWriter r = factory.createXMLStreamWriter(this.outputStreamValue);
/* 443 */       StAXResult result = new StAXResult(r);
/* 444 */       return result;
/*     */     }
/* 446 */     catch (XMLStreamException e) {
/* 447 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_noParserSupport"));
/* 448 */       Object[] msgArgs = { e.toString() };
/* 449 */       SQLServerException.makeFromDriverError(this.con, null, form.format(msgArgs), null, true);
/*     */       
/* 451 */       return null;
/*     */     } 
/*     */   }
/*     */   private SAXResult getSAXResult() throws SQLException {
/* 455 */     TransformerHandler handler = null;
/*     */     try {
/* 457 */       SAXTransformerFactory stf = (SAXTransformerFactory)TransformerFactory.newInstance();
/* 458 */       stf.setFeature("http://javax.xml.XMLConstants/feature/secure-processing", true);
/* 459 */       handler = stf.newTransformerHandler();
/* 460 */     } catch (TransformerConfigurationException e) {
/* 461 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_noParserSupport"));
/* 462 */       Object[] msgArgs = { e.toString() };
/* 463 */       SQLServerException.makeFromDriverError(this.con, null, form.format(msgArgs), null, true);
/* 464 */     } catch (ClassCastException e) {
/* 465 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_noParserSupport"));
/* 466 */       Object[] msgArgs = { e.toString() };
/* 467 */       SQLServerException.makeFromDriverError(this.con, null, form.format(msgArgs), null, true);
/*     */     } 
/* 469 */     this.outputStreamValue = new ByteArrayOutputStreamToInputStream();
/* 470 */     handler.setResult(new StreamResult(this.outputStreamValue));
/* 471 */     SAXResult result = new SAXResult(handler);
/* 472 */     return result;
/*     */   }
/*     */   
/*     */   private DOMResult getDOMResult() throws SQLException {
/* 476 */     DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
/*     */     
/* 478 */     assert null == this.outputStreamValue;
/*     */     try {
/* 480 */       DocumentBuilder builder = factory.newDocumentBuilder();
/* 481 */       this.docValue = builder.newDocument();
/* 482 */       DOMResult result = new DOMResult(this.docValue);
/* 483 */       return result;
/*     */     }
/* 485 */     catch (ParserConfigurationException e) {
/* 486 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_noParserSupport"));
/* 487 */       Object[] msgArgs = { e.toString() };
/* 488 */       SQLServerException.makeFromDriverError(this.con, null, form.format(msgArgs), null, true);
/*     */       
/* 490 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerSQLXML.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */