/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.security.GeneralSecurityException;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.SecureRandom;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.logging.Logger;
/*     */ import javax.crypto.Cipher;
/*     */ import javax.crypto.Mac;
/*     */ import javax.crypto.spec.IvParameterSpec;
/*     */ import javax.crypto.spec.SecretKeySpec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SQLServerAeadAes256CbcHmac256Algorithm
/*     */   extends SQLServerEncryptionAlgorithm
/*     */ {
/*  34 */   private static final Logger aeLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.SQLServerAeadAes256CbcHmac256Algorithm");
/*     */   
/*     */   static final String algorithmName = "AEAD_AES_256_CBC_HMAC_SHA256";
/*     */   
/*     */   private SQLServerAeadAes256CbcHmac256EncryptionKey columnEncryptionkey;
/*     */   
/*     */   private byte algorithmVersion;
/*     */   
/*     */   private boolean isDeterministic = false;
/*     */   
/*  44 */   private int blockSizeInBytes = 16;
/*  45 */   private int keySizeInBytes = 32;
/*  46 */   private byte[] version = new byte[] { 1 };
/*     */   
/*  48 */   private byte[] versionSize = new byte[] { 1 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   private int minimumCipherTextLengthInBytesNoAuthenticationTag = 1 + this.blockSizeInBytes + this.blockSizeInBytes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   private int minimumCipherTextLengthInBytesWithAuthenticationTag = this.minimumCipherTextLengthInBytesNoAuthenticationTag + this.keySizeInBytes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SQLServerAeadAes256CbcHmac256Algorithm(SQLServerAeadAes256CbcHmac256EncryptionKey columnEncryptionkey, SQLServerEncryptionType encryptionType, byte algorithmVersion) {
/*  76 */     this.columnEncryptionkey = columnEncryptionkey;
/*     */     
/*  78 */     if (encryptionType == SQLServerEncryptionType.Deterministic) {
/*  79 */       this.isDeterministic = true;
/*     */     }
/*  81 */     this.algorithmVersion = algorithmVersion;
/*  82 */     this.version[0] = algorithmVersion;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] encryptData(byte[] plainText) throws SQLServerException {
/*  88 */     return encryptData(plainText, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected byte[] encryptData(byte[] plainText, boolean hasAuthenticationTag) throws SQLServerException {
/* 102 */     aeLogger.entering(SQLServerAeadAes256CbcHmac256Algorithm.class.getName(), "encryptData", "Encrypting data.");
/*     */ 
/*     */     
/* 105 */     assert plainText != null;
/* 106 */     byte[] iv = new byte[this.blockSizeInBytes];
/*     */     
/* 108 */     SecretKeySpec skeySpec = new SecretKeySpec(this.columnEncryptionkey.getEncryptionKey(), "AES");
/*     */     
/* 110 */     if (this.isDeterministic) {
/*     */       
/*     */       try {
/* 113 */         iv = SQLServerSecurityUtility.getHMACWithSHA256(plainText, this.columnEncryptionkey.getIVKey(), this.blockSizeInBytes);
/*     */       }
/* 115 */       catch (InvalidKeyException|NoSuchAlgorithmException e) {
/* 116 */         MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_EncryptionFailed"));
/* 117 */         Object[] msgArgs = { e.getMessage() };
/* 118 */         throw new SQLServerException(this, form.format(msgArgs), null, 0, false);
/*     */       } 
/*     */     } else {
/* 121 */       SecureRandom random = new SecureRandom();
/* 122 */       random.nextBytes(iv);
/*     */     } 
/*     */     
/* 125 */     int numBlocks = plainText.length / this.blockSizeInBytes + 1;
/*     */     
/* 127 */     int hmacStartIndex = 1;
/* 128 */     int authenticationTagLen = hasAuthenticationTag ? this.keySizeInBytes : 0;
/* 129 */     int ivStartIndex = hmacStartIndex + authenticationTagLen;
/* 130 */     int cipherStartIndex = ivStartIndex + this.blockSizeInBytes;
/*     */ 
/*     */     
/* 133 */     int outputBufSize = 1 + authenticationTagLen + iv.length + numBlocks * this.blockSizeInBytes;
/* 134 */     byte[] outBuffer = new byte[outputBufSize];
/*     */ 
/*     */     
/* 137 */     outBuffer[0] = this.algorithmVersion;
/*     */     
/* 139 */     System.arraycopy(iv, 0, outBuffer, ivStartIndex, iv.length);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 145 */       IvParameterSpec ivector = new IvParameterSpec(iv);
/* 146 */       Cipher encryptCipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
/* 147 */       encryptCipher.init(1, skeySpec, ivector);
/*     */       
/* 149 */       int count = 0;
/* 150 */       int cipherIndex = cipherStartIndex;
/*     */       
/* 152 */       if (numBlocks > 1) {
/* 153 */         count = (numBlocks - 1) * this.blockSizeInBytes;
/* 154 */         cipherIndex += encryptCipher.update(plainText, 0, count, outBuffer, cipherIndex);
/*     */       } 
/*     */       
/* 157 */       byte[] buffTmp = encryptCipher.doFinal(plainText, count, plainText.length - count);
/*     */       
/* 159 */       System.arraycopy(buffTmp, 0, outBuffer, cipherIndex, buffTmp.length);
/*     */       
/* 161 */       if (hasAuthenticationTag)
/*     */       {
/* 163 */         Mac hmac = Mac.getInstance("HmacSHA256");
/* 164 */         SecretKeySpec initkey = new SecretKeySpec(this.columnEncryptionkey.getMacKey(), "HmacSHA256");
/* 165 */         hmac.init(initkey);
/* 166 */         hmac.update(this.version, 0, this.version.length);
/* 167 */         hmac.update(iv, 0, iv.length);
/* 168 */         hmac.update(outBuffer, cipherStartIndex, numBlocks * this.blockSizeInBytes);
/* 169 */         hmac.update(this.versionSize, 0, this.version.length);
/* 170 */         byte[] hash = hmac.doFinal();
/*     */         
/* 172 */         System.arraycopy(hash, 0, outBuffer, hmacStartIndex, authenticationTagLen);
/*     */       }
/*     */     
/* 175 */     } catch (NoSuchAlgorithmException|java.security.InvalidAlgorithmParameterException|InvalidKeyException|javax.crypto.NoSuchPaddingException|javax.crypto.IllegalBlockSizeException|javax.crypto.BadPaddingException|javax.crypto.ShortBufferException e) {
/*     */ 
/*     */       
/* 178 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_EncryptionFailed"));
/* 179 */       Object[] msgArgs = { e.getMessage() };
/* 180 */       throw new SQLServerException(this, form.format(msgArgs), null, 0, false);
/*     */     } 
/*     */     
/* 183 */     aeLogger.exiting(SQLServerAeadAes256CbcHmac256Algorithm.class.getName(), "encryptData", "Data encrypted.");
/* 184 */     return outBuffer;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] decryptData(byte[] cipherText) throws SQLServerException {
/* 190 */     return decryptData(cipherText, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] decryptData(byte[] cipherText, boolean hasAuthenticationTag) throws SQLServerException {
/* 204 */     assert cipherText != null;
/*     */     
/* 206 */     byte[] iv = new byte[this.blockSizeInBytes];
/*     */ 
/*     */     
/* 209 */     int minimumCipherTextLength = hasAuthenticationTag ? this.minimumCipherTextLengthInBytesWithAuthenticationTag : this.minimumCipherTextLengthInBytesNoAuthenticationTag;
/*     */ 
/*     */ 
/*     */     
/* 213 */     if (cipherText.length < minimumCipherTextLength) {
/* 214 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_InvalidCipherTextSize"));
/* 215 */       Object[] msgArgs = { Integer.valueOf(cipherText.length), Integer.valueOf(minimumCipherTextLength) };
/* 216 */       throw new SQLServerException(this, form.format(msgArgs), null, 0, false);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 221 */     int startIndex = 0;
/* 222 */     if (cipherText[startIndex] != this.algorithmVersion) {
/* 223 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_InvalidAlgorithmVersion"));
/*     */ 
/*     */       
/* 226 */       Object[] msgArgs = { String.format("%02X ", new Object[] { Byte.valueOf(cipherText[startIndex]) }), String.format("%02X ", new Object[] { Byte.valueOf(this.algorithmVersion) }) };
/* 227 */       throw new SQLServerException(this, form.format(msgArgs), null, 0, false);
/*     */     } 
/*     */ 
/*     */     
/* 231 */     startIndex++;
/* 232 */     int authenticationTagOffset = 0;
/*     */ 
/*     */     
/* 235 */     if (hasAuthenticationTag) {
/* 236 */       authenticationTagOffset = startIndex;
/*     */       
/* 238 */       startIndex += this.keySizeInBytes;
/*     */     } 
/*     */ 
/*     */     
/* 242 */     System.arraycopy(cipherText, startIndex, iv, 0, iv.length);
/* 243 */     startIndex += iv.length;
/*     */ 
/*     */     
/* 246 */     int cipherTextOffset = startIndex;
/*     */     
/* 248 */     int cipherTextCount = cipherText.length - startIndex;
/*     */     
/* 250 */     if (hasAuthenticationTag) {
/*     */       byte[] authenticationTag;
/*     */       try {
/* 253 */         authenticationTag = prepareAuthenticationTag(iv, cipherText, cipherTextOffset, cipherTextCount);
/* 254 */       } catch (InvalidKeyException|NoSuchAlgorithmException e) {
/* 255 */         MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_DecryptionFailed"));
/* 256 */         Object[] msgArgs = { e.getMessage() };
/* 257 */         throw new SQLServerException(this, form.format(msgArgs), null, 0, false);
/*     */       } 
/*     */       
/* 260 */       if (!SQLServerSecurityUtility.compareBytes(authenticationTag, cipherText, authenticationTagOffset, cipherTextCount))
/*     */       {
/*     */         
/* 263 */         throw new SQLServerException(this, SQLServerException.getErrString("R_InvalidAuthenticationTag"), null, 0, false);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 271 */     return decryptData(iv, cipherText, cipherTextOffset, cipherTextCount);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] decryptData(byte[] iv, byte[] cipherText, int offset, int count) throws SQLServerException {
/* 289 */     aeLogger.entering(SQLServerAeadAes256CbcHmac256Algorithm.class.getName(), "decryptData", "Decrypting data.");
/* 290 */     assert cipherText != null;
/* 291 */     assert iv != null;
/* 292 */     byte[] plainText = null;
/*     */     
/* 294 */     SecretKeySpec skeySpec = new SecretKeySpec(this.columnEncryptionkey.getEncryptionKey(), "AES");
/* 295 */     IvParameterSpec ivector = new IvParameterSpec(iv);
/*     */     
/*     */     try {
/* 298 */       Cipher decryptCipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
/* 299 */       decryptCipher.init(2, skeySpec, ivector);
/* 300 */       plainText = decryptCipher.doFinal(cipherText, offset, count);
/* 301 */     } catch (NoSuchAlgorithmException|java.security.InvalidAlgorithmParameterException|InvalidKeyException|javax.crypto.NoSuchPaddingException|javax.crypto.IllegalBlockSizeException|javax.crypto.BadPaddingException e) {
/*     */ 
/*     */       
/* 304 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_DecryptionFailed"));
/* 305 */       Object[] msgArgs = { e.getMessage() };
/* 306 */       throw new SQLServerException(this, form.format(msgArgs), null, 0, false);
/*     */     } 
/*     */     
/* 309 */     aeLogger.exiting(SQLServerAeadAes256CbcHmac256Algorithm.class.getName(), "decryptData", "Data decrypted.");
/* 310 */     return plainText;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] prepareAuthenticationTag(byte[] iv, byte[] cipherText, int offset, int length) throws NoSuchAlgorithmException, InvalidKeyException {
/* 329 */     assert cipherText != null;
/*     */     
/* 331 */     byte[] authenticationTag = new byte[this.keySizeInBytes];
/*     */     
/* 333 */     Mac hmac = Mac.getInstance("HmacSHA256");
/* 334 */     SecretKeySpec key = new SecretKeySpec(this.columnEncryptionkey.getMacKey(), "HmacSHA256");
/* 335 */     hmac.init(key);
/* 336 */     hmac.update(this.version, 0, this.version.length);
/* 337 */     hmac.update(iv, 0, iv.length);
/* 338 */     hmac.update(cipherText, offset, length);
/* 339 */     hmac.update(this.versionSize, 0, this.version.length);
/* 340 */     byte[] computedHash = hmac.doFinal();
/* 341 */     System.arraycopy(computedHash, 0, authenticationTag, 0, authenticationTag.length);
/*     */     
/* 343 */     return authenticationTag;
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerAeadAes256CbcHmac256Algorithm.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */