/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import java.security.GeneralSecurityException;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.Signature;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.text.MessageFormat;
/*     */ import javax.crypto.Cipher;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class KeyStoreProviderCommon
/*     */ {
/*     */   static final String rsaEncryptionAlgorithmWithOAEP = "RSA_OAEP";
/*  43 */   static byte[] version = new byte[] { 1 };
/*     */   
/*     */   static void validateEncryptionAlgorithm(String encryptionAlgorithm, boolean isEncrypt) throws SQLServerException {
/*  46 */     String errString = isEncrypt ? "R_NullKeyEncryptionAlgorithm" : "R_NullKeyEncryptionAlgorithmInternal";
/*  47 */     if (null == encryptionAlgorithm)
/*     */     {
/*  49 */       throw new SQLServerException(null, SQLServerException.getErrString(errString), null, 0, false);
/*     */     }
/*     */ 
/*     */     
/*  53 */     errString = isEncrypt ? "R_InvalidKeyEncryptionAlgorithm" : "R_InvalidKeyEncryptionAlgorithmInternal";
/*  54 */     if (!"RSA_OAEP".equalsIgnoreCase(encryptionAlgorithm.trim())) {
/*     */       
/*  56 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString(errString));
/*  57 */       Object[] msgArgs = { encryptionAlgorithm, "RSA_OAEP" };
/*  58 */       throw new SQLServerException(form.format(msgArgs), null);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static void validateNonEmptyMasterKeyPath(String masterKeyPath) throws SQLServerException {
/*  64 */     if (null == masterKeyPath || masterKeyPath.trim().length() == 0) {
/*  65 */       throw new SQLServerException(null, SQLServerException.getErrString("R_InvalidMasterKeyDetails"), null, 0, false);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static byte[] decryptColumnEncryptionKey(String masterKeyPath, String encryptionAlgorithm, byte[] encryptedColumnEncryptionKey, CertificateDetails certificateDetails) throws SQLServerException {
/*  72 */     if (null == encryptedColumnEncryptionKey)
/*     */     {
/*  74 */       throw new SQLServerException(null, SQLServerException.getErrString("R_NullEncryptedColumnEncryptionKey"), null, 0, false);
/*     */     }
/*     */     
/*  77 */     if (0 == encryptedColumnEncryptionKey.length)
/*     */     {
/*  79 */       throw new SQLServerException(null, SQLServerException.getErrString("R_EmptyEncryptedColumnEncryptionKey"), null, 0, false);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  84 */     validateEncryptionAlgorithm(encryptionAlgorithm, false);
/*     */     
/*  86 */     int currentIndex = version.length;
/*  87 */     int keyPathLength = convertTwoBytesToShort(encryptedColumnEncryptionKey, currentIndex);
/*     */     
/*  89 */     currentIndex += 2;
/*     */ 
/*     */     
/*  92 */     int cipherTextLength = convertTwoBytesToShort(encryptedColumnEncryptionKey, currentIndex);
/*  93 */     currentIndex += 2;
/*     */     
/*  95 */     currentIndex += keyPathLength;
/*     */     
/*  97 */     int signatureLength = encryptedColumnEncryptionKey.length - currentIndex - cipherTextLength;
/*     */ 
/*     */     
/* 100 */     byte[] cipherText = new byte[cipherTextLength];
/* 101 */     System.arraycopy(encryptedColumnEncryptionKey, currentIndex, cipherText, 0, cipherTextLength);
/* 102 */     currentIndex += cipherTextLength;
/*     */     
/* 104 */     byte[] signature = new byte[signatureLength];
/* 105 */     System.arraycopy(encryptedColumnEncryptionKey, currentIndex, signature, 0, signatureLength);
/*     */     
/* 107 */     byte[] hash = new byte[encryptedColumnEncryptionKey.length - signature.length];
/*     */     
/* 109 */     System.arraycopy(encryptedColumnEncryptionKey, 0, hash, 0, encryptedColumnEncryptionKey.length - signature.length);
/*     */ 
/*     */     
/* 112 */     if (!verifyRSASignature(hash, signature, certificateDetails.certificate, masterKeyPath)) {
/* 113 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_InvalidCertificateSignature"));
/* 114 */       Object[] msgArgs = { masterKeyPath };
/* 115 */       throw new SQLServerException(form.format(msgArgs), null);
/*     */     } 
/*     */     
/* 118 */     byte[] plainCEK = decryptRSAOAEP(cipherText, certificateDetails);
/*     */     
/* 120 */     return plainCEK;
/*     */   }
/*     */ 
/*     */   
/*     */   private static byte[] decryptRSAOAEP(byte[] cipherText, CertificateDetails certificateDetails) throws SQLServerException {
/* 125 */     byte[] plainCEK = null;
/*     */     try {
/* 127 */       Cipher rsa = Cipher.getInstance("RSA/ECB/OAEPWithSHA-1AndMGF1Padding");
/* 128 */       rsa.init(2, certificateDetails.privateKey);
/* 129 */       rsa.update(cipherText);
/* 130 */       plainCEK = rsa.doFinal();
/* 131 */     } catch (InvalidKeyException|java.security.NoSuchAlgorithmException|javax.crypto.NoSuchPaddingException|javax.crypto.IllegalBlockSizeException|javax.crypto.BadPaddingException e) {
/*     */       
/* 133 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_CEKDecryptionFailed"));
/* 134 */       Object[] msgArgs = { e.getMessage() };
/* 135 */       throw new SQLServerException(form.format(msgArgs), e);
/*     */     } 
/*     */     
/* 138 */     return plainCEK;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean verifyRSASignature(byte[] hash, byte[] signature, X509Certificate certificate, String masterKeyPath) throws SQLServerException {
/* 145 */     boolean verificationSuccess = false;
/*     */     try {
/* 147 */       Signature signVerify = Signature.getInstance("SHA256withRSA");
/* 148 */       signVerify.initVerify(certificate.getPublicKey());
/* 149 */       signVerify.update(hash);
/* 150 */       verificationSuccess = signVerify.verify(signature);
/* 151 */     } catch (InvalidKeyException|java.security.NoSuchAlgorithmException|java.security.SignatureException e) {
/* 152 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_InvalidCertificateSignature"));
/* 153 */       Object[] msgArgs = { masterKeyPath };
/* 154 */       throw new SQLServerException(form.format(msgArgs), e);
/*     */     } 
/*     */     
/* 157 */     return verificationSuccess;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static short convertTwoBytesToShort(byte[] input, int index) throws SQLServerException {
/* 164 */     if (index + 1 >= input.length) {
/* 165 */       throw new SQLServerException(null, SQLServerException.getErrString("R_ByteToShortConversion"), null, 0, false);
/*     */     }
/*     */     
/* 168 */     ByteBuffer byteBuffer = ByteBuffer.allocate(2);
/* 169 */     byteBuffer.order(ByteOrder.LITTLE_ENDIAN);
/* 170 */     byteBuffer.put(input[index]);
/* 171 */     byteBuffer.put(input[index + 1]);
/* 172 */     short shortVal = byteBuffer.getShort(0);
/* 173 */     return shortVal;
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\KeyStoreProviderCommon.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */