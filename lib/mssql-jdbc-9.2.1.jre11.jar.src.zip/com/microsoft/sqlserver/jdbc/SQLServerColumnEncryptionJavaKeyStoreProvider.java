/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.security.GeneralSecurityException;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.Key;
/*     */ import java.security.KeyStore;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.Signature;
/*     */ import java.security.UnrecoverableKeyException;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.crypto.Cipher;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SQLServerColumnEncryptionJavaKeyStoreProvider
/*     */   extends SQLServerColumnEncryptionKeyStoreProvider
/*     */ {
/*  42 */   String name = "MSSQL_JAVA_KEYSTORE";
/*  43 */   String keyStorePath = null;
/*  44 */   char[] keyStorePwd = null;
/*     */ 
/*     */   
/*  47 */   private static final Logger javaKeyStoreLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.SQLServerColumnEncryptionJavaKeyStoreProvider");
/*     */   
/*     */   public void setName(String name) {
/*  50 */     this.name = name;
/*     */   }
/*     */   
/*     */   public String getName() {
/*  54 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SQLServerColumnEncryptionJavaKeyStoreProvider(String keyStoreLocation, char[] keyStoreSecret) throws SQLServerException {
/*  69 */     javaKeyStoreLogger.entering(SQLServerColumnEncryptionJavaKeyStoreProvider.class.getName(), "SQLServerColumnEncryptionJavaKeyStoreProvider");
/*     */ 
/*     */     
/*  72 */     if (null == keyStoreLocation || 0 == keyStoreLocation.length()) {
/*  73 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_InvalidConnectionSetting"));
/*  74 */       Object[] msgArgs = { "keyStoreLocation", keyStoreLocation };
/*  75 */       throw new SQLServerException(form.format(msgArgs), null);
/*     */     } 
/*     */     
/*  78 */     this.keyStorePath = keyStoreLocation;
/*     */     
/*  80 */     if (javaKeyStoreLogger.isLoggable(Level.FINE)) {
/*  81 */       javaKeyStoreLogger.fine("Path of key store provider is set.");
/*     */     }
/*     */ 
/*     */     
/*  85 */     if (null == keyStoreSecret) {
/*  86 */       keyStoreSecret = "".toCharArray();
/*     */     }
/*     */     
/*  89 */     this.keyStorePwd = new char[keyStoreSecret.length];
/*  90 */     System.arraycopy(keyStoreSecret, 0, this.keyStorePwd, 0, keyStoreSecret.length);
/*     */     
/*  92 */     if (javaKeyStoreLogger.isLoggable(Level.FINE)) {
/*  93 */       javaKeyStoreLogger.fine("Password for key store provider is set.");
/*     */     }
/*     */     
/*  96 */     javaKeyStoreLogger.exiting(SQLServerColumnEncryptionJavaKeyStoreProvider.class.getName(), "SQLServerColumnEncryptionJavaKeyStoreProvider");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] decryptColumnEncryptionKey(String masterKeyPath, String encryptionAlgorithm, byte[] encryptedColumnEncryptionKey) throws SQLServerException {
/* 103 */     javaKeyStoreLogger.entering(SQLServerColumnEncryptionJavaKeyStoreProvider.class.getName(), "decryptColumnEncryptionKey", "Decrypting Column Encryption Key.");
/*     */ 
/*     */     
/* 106 */     KeyStoreProviderCommon.validateNonEmptyMasterKeyPath(masterKeyPath);
/* 107 */     CertificateDetails certificateDetails = getCertificateDetails(masterKeyPath);
/* 108 */     byte[] plainCEK = KeyStoreProviderCommon.decryptColumnEncryptionKey(masterKeyPath, encryptionAlgorithm, encryptedColumnEncryptionKey, certificateDetails);
/*     */ 
/*     */     
/* 111 */     javaKeyStoreLogger.exiting(SQLServerColumnEncryptionJavaKeyStoreProvider.class.getName(), "decryptColumnEncryptionKey", "Finished decrypting Column Encryption Key.");
/*     */     
/* 113 */     return plainCEK;
/*     */   }
/*     */   
/*     */   private CertificateDetails getCertificateDetails(String masterKeyPath) throws SQLServerException {
/* 117 */     FileInputStream fis = null;
/* 118 */     KeyStore keyStore = null;
/* 119 */     CertificateDetails certificateDetails = null;
/*     */     
/*     */     try {
/* 122 */       if (null == masterKeyPath || 0 == masterKeyPath.length()) {
/* 123 */         throw new SQLServerException(null, SQLServerException.getErrString("R_InvalidMasterKeyDetails"), null, 0, false);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 129 */         keyStore = KeyStore.getInstance("JKS");
/* 130 */         fis = new FileInputStream(this.keyStorePath);
/* 131 */         keyStore.load(fis, this.keyStorePwd);
/* 132 */       } catch (IOException e) {
/* 133 */         if (null != fis) {
/* 134 */           fis.close();
/*     */         }
/*     */         
/* 137 */         keyStore = KeyStore.getInstance("PKCS12");
/* 138 */         fis = new FileInputStream(this.keyStorePath);
/* 139 */         keyStore.load(fis, this.keyStorePwd);
/*     */       } 
/*     */       
/* 142 */       certificateDetails = getCertificateDetailsByAlias(keyStore, masterKeyPath);
/* 143 */     } catch (FileNotFoundException fileNotFound) {
/* 144 */       throw new SQLServerException(this, SQLServerException.getErrString("R_KeyStoreNotFound"), null, 0, false);
/* 145 */     } catch (IOException|java.security.cert.CertificateException|NoSuchAlgorithmException|java.security.KeyStoreException e) {
/* 146 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidKeyStoreFile"));
/* 147 */       Object[] msgArgs = { this.keyStorePath };
/* 148 */       throw new SQLServerException(form.format(msgArgs), e);
/*     */     } finally {
/*     */       try {
/* 151 */         if (null != fis) {
/* 152 */           fis.close();
/*     */         }
/*     */       }
/* 155 */       catch (IOException iOException) {}
/*     */     } 
/*     */     
/* 158 */     return certificateDetails;
/*     */   }
/*     */   
/*     */   private CertificateDetails getCertificateDetailsByAlias(KeyStore keyStore, String alias) throws SQLServerException {
/*     */     try {
/* 163 */       X509Certificate publicCertificate = (X509Certificate)keyStore.getCertificate(alias);
/* 164 */       Key keyPrivate = keyStore.getKey(alias, this.keyStorePwd);
/* 165 */       if (null == publicCertificate) {
/*     */ 
/*     */         
/* 168 */         MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_CertificateNotFoundForAlias"));
/* 169 */         Object[] msgArgs = { alias, "MSSQL_JAVA_KEYSTORE" };
/* 170 */         throw new SQLServerException(this, form.format(msgArgs), null, 0, false);
/*     */       } 
/*     */ 
/*     */       
/* 174 */       if (null == keyPrivate) {
/* 175 */         throw new UnrecoverableKeyException();
/*     */       }
/*     */       
/* 178 */       return new CertificateDetails(publicCertificate, keyPrivate);
/* 179 */     } catch (UnrecoverableKeyException unrecoverableKeyException) {
/*     */       
/* 181 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_UnrecoverableKeyAE"));
/* 182 */       Object[] msgArgs = { alias };
/* 183 */       throw new SQLServerException(this, form.format(msgArgs), null, 0, false);
/* 184 */     } catch (NoSuchAlgorithmException|java.security.KeyStoreException e) {
/* 185 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_CertificateError"));
/* 186 */       Object[] msgArgs = { alias, this.name };
/* 187 */       throw new SQLServerException(form.format(msgArgs), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] encryptColumnEncryptionKey(String masterKeyPath, String encryptionAlgorithm, byte[] plainTextColumnEncryptionKey) throws SQLServerException {
/* 194 */     javaKeyStoreLogger.entering(SQLServerColumnEncryptionJavaKeyStoreProvider.class.getName(), "encryptColumnEncryptionKey", "Encrypting Column Encryption Key.");
/*     */ 
/*     */     
/* 197 */     byte[] version = KeyStoreProviderCommon.version;
/* 198 */     KeyStoreProviderCommon.validateNonEmptyMasterKeyPath(masterKeyPath);
/*     */     
/* 200 */     if (null == plainTextColumnEncryptionKey)
/*     */     {
/* 202 */       throw new SQLServerException(null, SQLServerException.getErrString("R_NullColumnEncryptionKey"), null, 0, false);
/*     */     }
/*     */     
/* 205 */     if (0 == plainTextColumnEncryptionKey.length)
/*     */     {
/* 207 */       throw new SQLServerException(null, SQLServerException.getErrString("R_EmptyColumnEncryptionKey"), null, 0, false);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 212 */     KeyStoreProviderCommon.validateEncryptionAlgorithm(encryptionAlgorithm, true);
/*     */     
/* 214 */     CertificateDetails certificateDetails = getCertificateDetails(masterKeyPath);
/* 215 */     byte[] cipherText = encryptRSAOAEP(plainTextColumnEncryptionKey, certificateDetails);
/* 216 */     byte[] cipherTextLength = getLittleEndianBytesFromShort((short)cipherText.length);
/* 217 */     byte[] masterKeyPathBytes = masterKeyPath.toLowerCase().getBytes(StandardCharsets.UTF_16LE);
/*     */     
/* 219 */     byte[] keyPathLength = getLittleEndianBytesFromShort((short)masterKeyPathBytes.length);
/*     */     
/* 221 */     byte[] dataToSign = new byte[version.length + keyPathLength.length + cipherTextLength.length + masterKeyPathBytes.length + cipherText.length];
/*     */     
/* 223 */     int destinationPosition = version.length;
/* 224 */     System.arraycopy(version, 0, dataToSign, 0, version.length);
/*     */     
/* 226 */     System.arraycopy(keyPathLength, 0, dataToSign, destinationPosition, keyPathLength.length);
/* 227 */     destinationPosition += keyPathLength.length;
/*     */     
/* 229 */     System.arraycopy(cipherTextLength, 0, dataToSign, destinationPosition, cipherTextLength.length);
/* 230 */     destinationPosition += cipherTextLength.length;
/*     */     
/* 232 */     System.arraycopy(masterKeyPathBytes, 0, dataToSign, destinationPosition, masterKeyPathBytes.length);
/* 233 */     destinationPosition += masterKeyPathBytes.length;
/*     */     
/* 235 */     System.arraycopy(cipherText, 0, dataToSign, destinationPosition, cipherText.length);
/* 236 */     byte[] signedHash = rsaSignHashedData(dataToSign, certificateDetails);
/*     */     
/* 238 */     int encryptedColumnEncryptionKeyLength = version.length + cipherTextLength.length + keyPathLength.length + cipherText.length + masterKeyPathBytes.length + signedHash.length;
/*     */     
/* 240 */     byte[] encryptedColumnEncryptionKey = new byte[encryptedColumnEncryptionKeyLength];
/*     */     
/* 242 */     int currentIndex = 0;
/* 243 */     System.arraycopy(version, 0, encryptedColumnEncryptionKey, currentIndex, version.length);
/* 244 */     currentIndex += version.length;
/*     */     
/* 246 */     System.arraycopy(keyPathLength, 0, encryptedColumnEncryptionKey, currentIndex, keyPathLength.length);
/* 247 */     currentIndex += keyPathLength.length;
/*     */     
/* 249 */     System.arraycopy(cipherTextLength, 0, encryptedColumnEncryptionKey, currentIndex, cipherTextLength.length);
/* 250 */     currentIndex += cipherTextLength.length;
/*     */     
/* 252 */     System.arraycopy(masterKeyPathBytes, 0, encryptedColumnEncryptionKey, currentIndex, masterKeyPathBytes.length);
/* 253 */     currentIndex += masterKeyPathBytes.length;
/*     */     
/* 255 */     System.arraycopy(cipherText, 0, encryptedColumnEncryptionKey, currentIndex, cipherText.length);
/* 256 */     currentIndex += cipherText.length;
/*     */     
/* 258 */     System.arraycopy(signedHash, 0, encryptedColumnEncryptionKey, currentIndex, signedHash.length);
/*     */     
/* 260 */     javaKeyStoreLogger.exiting(SQLServerColumnEncryptionJavaKeyStoreProvider.class.getName(), "encryptColumnEncryptionKey", "Finished encrypting Column Encryption Key.");
/*     */     
/* 262 */     return encryptedColumnEncryptionKey;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] encryptRSAOAEP(byte[] plainText, CertificateDetails certificateDetails) throws SQLServerException {
/* 276 */     byte[] cipherText = null;
/*     */     try {
/* 278 */       Cipher rsa = Cipher.getInstance("RSA/ECB/OAEPWithSHA-1AndMGF1Padding");
/* 279 */       rsa.init(1, certificateDetails.certificate.getPublicKey());
/* 280 */       rsa.update(plainText);
/* 281 */       cipherText = rsa.doFinal();
/* 282 */     } catch (InvalidKeyException|NoSuchAlgorithmException|javax.crypto.IllegalBlockSizeException|javax.crypto.NoSuchPaddingException|javax.crypto.BadPaddingException e) {
/*     */       
/* 284 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_EncryptionFailed"));
/* 285 */       Object[] msgArgs = { e.getMessage() };
/* 286 */       throw new SQLServerException(this, form.format(msgArgs), null, 0, false);
/*     */     } 
/*     */     
/* 289 */     return cipherText;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] rsaSignHashedData(byte[] dataToSign, CertificateDetails certificateDetails) throws SQLServerException {
/* 296 */     byte[] signedHash = null;
/*     */     
/*     */     try {
/* 299 */       Signature signature = Signature.getInstance("SHA256withRSA");
/* 300 */       signature.initSign((PrivateKey)certificateDetails.privateKey);
/* 301 */       signature.update(dataToSign);
/* 302 */       signedHash = signature.sign();
/* 303 */     } catch (InvalidKeyException|NoSuchAlgorithmException|java.security.SignatureException e) {
/* 304 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_EncryptionFailed"));
/* 305 */       Object[] msgArgs = { e.getMessage() };
/* 306 */       throw new SQLServerException(this, form.format(msgArgs), null, 0, false);
/*     */     } 
/* 308 */     return signedHash;
/*     */   }
/*     */ 
/*     */   
/*     */   private byte[] getLittleEndianBytesFromShort(short value) {
/* 313 */     ByteBuffer byteBuffer = ByteBuffer.allocate(2);
/* 314 */     byteBuffer.order(ByteOrder.LITTLE_ENDIAN);
/* 315 */     byte[] byteValue = byteBuffer.putShort(value).array();
/* 316 */     return byteValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean rsaVerifySignature(byte[] dataToVerify, byte[] signature, CertificateDetails certificateDetails) throws SQLServerException {
/*     */     try {
/* 325 */       Signature sig = Signature.getInstance("SHA256withRSA");
/* 326 */       sig.initSign((PrivateKey)certificateDetails.privateKey);
/* 327 */       sig.update(dataToVerify);
/* 328 */       byte[] signedHash = sig.sign();
/*     */       
/* 330 */       sig.initVerify(certificateDetails.certificate.getPublicKey());
/* 331 */       sig.update(dataToVerify);
/*     */       
/* 333 */       return sig.verify(signedHash);
/*     */     }
/* 335 */     catch (InvalidKeyException|NoSuchAlgorithmException|java.security.SignatureException e) {
/* 336 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_VerifySignatureFailed"));
/* 337 */       Object[] msgArgs = { e.getMessage() };
/* 338 */       throw new SQLServerException(this, form.format(msgArgs), null, 0, false);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean verifyColumnMasterKeyMetadata(String masterKeyPath, boolean allowEnclaveComputations, byte[] signature) throws SQLServerException {
/* 346 */     if (!allowEnclaveComputations) {
/* 347 */       return false;
/*     */     }
/* 349 */     KeyStoreProviderCommon.validateNonEmptyMasterKeyPath(masterKeyPath);
/* 350 */     CertificateDetails certificateDetails = getCertificateDetails(masterKeyPath);
/* 351 */     if (null == certificateDetails) {
/* 352 */       return false;
/*     */     }
/*     */     
/*     */     try {
/* 356 */       MessageDigest md = MessageDigest.getInstance("SHA-256");
/* 357 */       md.update(this.name.toLowerCase().getBytes(StandardCharsets.UTF_16LE));
/* 358 */       md.update(masterKeyPath.toLowerCase().getBytes(StandardCharsets.UTF_16LE));
/*     */       
/* 360 */       md.update("true".getBytes(StandardCharsets.UTF_16LE));
/* 361 */       return rsaVerifySignature(md.digest(), signature, certificateDetails);
/* 362 */     } catch (NoSuchAlgorithmException e) {
/* 363 */       throw new SQLServerException(SQLServerException.getErrString("R_NoSHA256Algorithm"), e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerColumnEncryptionJavaKeyStoreProvider.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */