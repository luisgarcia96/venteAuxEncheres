/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.StringReader;
/*     */ import java.math.BigInteger;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Paths;
/*     */ import java.security.GeneralSecurityException;
/*     */ import java.security.KeyFactory;
/*     */ import java.security.KeyPair;
/*     */ import java.security.KeyStore;
/*     */ import java.security.KeyStoreException;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.UnrecoverableKeyException;
/*     */ import java.security.cert.Certificate;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.CertificateFactory;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.security.spec.InvalidKeySpecException;
/*     */ import java.security.spec.PKCS8EncodedKeySpec;
/*     */ import java.security.spec.RSAPrivateCrtKeySpec;
/*     */ import java.util.Arrays;
/*     */ import java.util.Base64;
/*     */ import javax.crypto.Cipher;
/*     */ import javax.crypto.SecretKey;
/*     */ import javax.crypto.spec.SecretKeySpec;
/*     */ import javax.net.ssl.KeyManager;
/*     */ import javax.net.ssl.KeyManagerFactory;
/*     */ import org.bouncycastle.openssl.PEMDecryptorProvider;
/*     */ import org.bouncycastle.openssl.PEMEncryptedKeyPair;
/*     */ import org.bouncycastle.openssl.PEMKeyPair;
/*     */ import org.bouncycastle.openssl.PEMParser;
/*     */ import org.bouncycastle.openssl.jcajce.JcaPEMKeyConverter;
/*     */ import org.bouncycastle.openssl.jcajce.JcePEMDecryptorProviderBuilder;
/*     */ 
/*     */ final class SQLServerCertificateUtils
/*     */ {
/*     */   private static final String PKCS12_ALG = "PKCS12";
/*     */   private static final String SUN_X_509 = "SunX509";
/*     */   private static final String PEM_PRIVATE_START = "-----BEGIN PRIVATE KEY-----";
/*     */   private static final String PEM_PRIVATE_END = "-----END PRIVATE KEY-----";
/*     */   private static final String JAVA_KEY_STORE = "JKS";
/*     */   private static final String CLIENT_CERT = "client-cert";
/*     */   private static final String CLIENT_KEY = "client-key";
/*     */   private static final String PEM_RSA_PRIVATE_START = "-----BEGIN RSA PRIVATE KEY-----";
/*     */   private static final long PVK_MAGIC = 2964713758L;
/*     */   
/*     */   static KeyManager[] getKeyManagerFromFile(String certPath, String keyPath, String keyPassword) throws IOException, GeneralSecurityException, SQLServerException {
/*  59 */     if (keyPath != null && keyPath.length() > 0) {
/*  60 */       return readPKCS8Certificate(certPath, keyPath, keyPassword);
/*     */     }
/*  62 */     return readPKCS12Certificate(certPath, keyPassword);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  79 */   private static final byte[] RSA2_MAGIC = new byte[] { 82, 83, 65, 50 };
/*     */   
/*     */   private static final String RC4_ALG = "RC4";
/*     */   private static final String RSA_ALG = "RSA";
/*     */   
/*     */   private static KeyManager[] readPKCS12Certificate(String certPath, String keyPassword) throws NoSuchAlgorithmException, CertificateException, FileNotFoundException, IOException, UnrecoverableKeyException, KeyStoreException, SQLServerException {
/*  85 */     KeyStore keystore = KeyStore.getInstance("PKCS12"); 
/*  86 */     try { FileInputStream certStream = new FileInputStream(certPath); 
/*  87 */       try { keystore.load(certStream, keyPassword.toCharArray());
/*  88 */         certStream.close(); } catch (Throwable throwable) { try { certStream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } catch (FileNotFoundException e)
/*  89 */     { throw new SQLServerException(SQLServerException.getErrString("R_clientCertError"), null, 0, null); }
/*     */     
/*  91 */     KeyManagerFactory keyManagerFactory = KeyManagerFactory.getInstance("SunX509");
/*  92 */     keyManagerFactory.init(keystore, keyPassword.toCharArray());
/*  93 */     return keyManagerFactory.getKeyManagers();
/*     */   }
/*     */ 
/*     */   
/*     */   private static KeyManager[] readPKCS8Certificate(String certPath, String keyPath, String keyPassword) throws IOException, GeneralSecurityException, SQLServerException {
/*  98 */     Certificate clientCertificate = loadCertificate(certPath);
/*  99 */     ((X509Certificate)clientCertificate).checkValidity();
/* 100 */     PrivateKey privateKey = loadPrivateKey(keyPath, keyPassword);
/*     */     
/* 102 */     KeyStore keyStore = KeyStore.getInstance("JKS");
/* 103 */     keyStore.load(null, null);
/* 104 */     keyStore.setCertificateEntry("client-cert", clientCertificate);
/* 105 */     keyStore.setKeyEntry("client-key", privateKey, keyPassword.toCharArray(), new Certificate[] { clientCertificate });
/*     */     
/* 107 */     KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
/* 108 */     kmf.init(keyStore, keyPassword.toCharArray());
/* 109 */     return kmf.getKeyManagers();
/*     */   }
/*     */ 
/*     */   
/*     */   private static PrivateKey loadPrivateKeyFromPKCS8(String key) throws IOException, NoSuchAlgorithmException, InvalidKeySpecException {
/* 114 */     StringBuilder sb = new StringBuilder(key);
/* 115 */     deleteFirst(sb, "-----BEGIN PRIVATE KEY-----");
/* 116 */     deleteFirst(sb, "-----END PRIVATE KEY-----");
/* 117 */     byte[] formattedKey = Base64.getDecoder().decode(sb.toString().replaceAll("\\s", ""));
/*     */     
/* 119 */     KeyFactory factory = KeyFactory.getInstance("RSA");
/* 120 */     return factory.generatePrivate(new PKCS8EncodedKeySpec(formattedKey));
/*     */   }
/*     */   
/*     */   private static void deleteFirst(StringBuilder sb, String str) {
/* 124 */     int i = sb.indexOf(str);
/* 125 */     if (i != -1) {
/* 126 */       sb.delete(i, i + str.length());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static PrivateKey loadPrivateKeyFromPKCS1(String key, String keyPass) throws IOException, NoSuchAlgorithmException, InvalidKeySpecException {
/* 132 */     SQLServerBouncyCastleLoader.loadBouncyCastle();
/* 133 */     PEMParser pemParser = null; try {
/*     */       KeyPair kp;
/* 135 */       pemParser = new PEMParser(new StringReader(key));
/* 136 */       Object object = pemParser.readObject();
/* 137 */       JcaPEMKeyConverter converter = (new JcaPEMKeyConverter()).setProvider("BC");
/*     */       
/* 139 */       if (object instanceof PEMEncryptedKeyPair && keyPass != null) {
/* 140 */         PEMDecryptorProvider decProv = (new JcePEMDecryptorProviderBuilder()).build(keyPass.toCharArray());
/* 141 */         kp = converter.getKeyPair(((PEMEncryptedKeyPair)object).decryptKeyPair(decProv));
/*     */       } else {
/* 143 */         kp = converter.getKeyPair((PEMKeyPair)object);
/*     */       } 
/* 145 */       return kp.getPrivate();
/*     */     } finally {
/* 147 */       if (null != pemParser) {
/* 148 */         pemParser.close();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static PrivateKey loadPrivateKeyFromPVK(String keyPath, String keyPass) throws IOException, GeneralSecurityException, SQLServerException {
/* 155 */     File f = new File(keyPath);
/* 156 */     ByteBuffer buffer = ByteBuffer.allocate((int)f.length());
/* 157 */     FileInputStream in = new FileInputStream(f); 
/* 158 */     try { in.getChannel().read(buffer);
/* 159 */       buffer.order(ByteOrder.LITTLE_ENDIAN).rewind();
/*     */       
/* 161 */       long magic = buffer.getInt() & 0xFFFFFFFFL;
/* 162 */       if (2964713758L != magic) {
/* 163 */         SQLServerException.makeFromDriverError(null, Long.valueOf(magic), SQLServerResource.getResource("R_pvkHeaderError"), "", false);
/*     */       }
/*     */ 
/*     */       
/* 167 */       buffer.position(buffer.position() + 8);
/* 168 */       boolean encrypted = (buffer.getInt() != 0);
/* 169 */       int saltLength = buffer.getInt();
/* 170 */       int keyLength = buffer.getInt();
/* 171 */       byte[] salt = new byte[saltLength];
/* 172 */       buffer.get(salt);
/*     */       
/* 174 */       buffer.position(buffer.position() + 8);
/*     */ 
/*     */       
/* 177 */       byte[] key = new byte[keyLength - 8];
/* 178 */       buffer.get(key);
/*     */       
/* 180 */       if (encrypted) {
/* 181 */         MessageDigest digest = MessageDigest.getInstance("SHA1");
/* 182 */         digest.update(salt);
/* 183 */         if (null != keyPass) {
/* 184 */           digest.update(keyPass.getBytes());
/*     */         }
/* 186 */         byte[] hash = digest.digest();
/* 187 */         key = getSecretKeyFromHash(key, hash);
/*     */       } 
/*     */       
/* 190 */       ByteBuffer buff = ByteBuffer.wrap(key).order(ByteOrder.LITTLE_ENDIAN);
/* 191 */       buff.position(RSA2_MAGIC.length);
/*     */       
/* 193 */       int byteLength = buff.getInt() / 8;
/* 194 */       BigInteger publicExponent = BigInteger.valueOf(buff.getInt());
/* 195 */       BigInteger modulus = getBigInteger(buff, byteLength);
/* 196 */       BigInteger prime1 = getBigInteger(buff, byteLength / 2);
/* 197 */       BigInteger prime2 = getBigInteger(buff, byteLength / 2);
/* 198 */       BigInteger primeExponent1 = getBigInteger(buff, byteLength / 2);
/* 199 */       BigInteger primeExponent2 = getBigInteger(buff, byteLength / 2);
/* 200 */       BigInteger crtCoefficient = getBigInteger(buff, byteLength / 2);
/* 201 */       BigInteger privateExponent = getBigInteger(buff, byteLength);
/*     */       
/* 203 */       RSAPrivateCrtKeySpec spec = new RSAPrivateCrtKeySpec(modulus, publicExponent, privateExponent, prime1, prime2, primeExponent1, primeExponent2, crtCoefficient);
/*     */       
/* 205 */       KeyFactory factory = KeyFactory.getInstance("RSA");
/* 206 */       PrivateKey privateKey = factory.generatePrivate(spec);
/* 207 */       in.close(); return privateKey; }
/*     */     catch (Throwable throwable) { try { in.close(); }
/*     */       catch (Throwable throwable1)
/*     */       { throwable.addSuppressed(throwable1); }
/*     */        throw throwable; }
/* 212 */      } private static Certificate loadCertificate(String certificatePem) throws IOException, GeneralSecurityException, SQLServerException { CertificateFactory certificateFactory = CertificateFactory.getInstance("X509");
/* 213 */     InputStream certStream = fileToStream(certificatePem); 
/* 214 */     try { Certificate certificate = certificateFactory.generateCertificate(certStream);
/* 215 */       if (certStream != null) certStream.close();  return certificate; }
/*     */     catch (Throwable throwable) { if (certStream != null)
/*     */         try { certStream.close(); }
/*     */         catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*     */           throw throwable; }
/* 220 */      } private static PrivateKey loadPrivateKey(String privateKeyPemPath, String privateKeyPassword) throws GeneralSecurityException, IOException, SQLServerException { String privateKeyPem = getStringFromFile(privateKeyPemPath);
/*     */     
/* 222 */     if (privateKeyPem.contains("-----BEGIN PRIVATE KEY-----"))
/* 223 */       return loadPrivateKeyFromPKCS8(privateKeyPem); 
/* 224 */     if (privateKeyPem.contains("-----BEGIN RSA PRIVATE KEY-----")) {
/* 225 */       return loadPrivateKeyFromPKCS1(privateKeyPem, privateKeyPassword);
/*     */     }
/* 227 */     return loadPrivateKeyFromPVK(privateKeyPemPath, privateKeyPassword); }
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean startsWithMagic(byte[] b) {
/* 232 */     for (int i = 0; i < RSA2_MAGIC.length; i++) {
/* 233 */       if (b[i] != RSA2_MAGIC[i])
/* 234 */         return false; 
/*     */     } 
/* 236 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private static byte[] getSecretKeyFromHash(byte[] originalKey, byte[] keyHash) throws GeneralSecurityException, SQLServerException {
/* 241 */     SecretKey key = new SecretKeySpec(keyHash, 0, 16, "RC4");
/* 242 */     byte[] decrypted = decryptSecretKey(key, originalKey);
/* 243 */     if (startsWithMagic(decrypted)) {
/* 244 */       return decrypted;
/*     */     }
/*     */ 
/*     */     
/* 248 */     Arrays.fill(keyHash, 5, keyHash.length, (byte)0);
/* 249 */     key = new SecretKeySpec(keyHash, 0, 16, "RC4");
/* 250 */     decrypted = decryptSecretKey(key, originalKey);
/* 251 */     if (startsWithMagic(decrypted)) {
/* 252 */       return decrypted;
/*     */     }
/*     */     
/* 255 */     SQLServerException.makeFromDriverError(null, originalKey, SQLServerResource.getResource("R_pvkParseError"), "", false);
/*     */     
/* 257 */     return null;
/*     */   }
/*     */   
/*     */   private static byte[] decryptSecretKey(SecretKey key, byte[] encoded) throws GeneralSecurityException {
/* 261 */     Cipher cipher = Cipher.getInstance(key.getAlgorithm());
/* 262 */     cipher.init(2, key);
/* 263 */     return cipher.doFinal(encoded);
/*     */   }
/*     */ 
/*     */   
/*     */   private static BigInteger getBigInteger(ByteBuffer buffer, int length) {
/* 268 */     byte[] array = new byte[length + 1];
/*     */     
/* 270 */     for (int i = 0; i < length; i++) {
/* 271 */       array[array.length - 1 - i] = buffer.get();
/*     */     }
/* 273 */     return new BigInteger(array);
/*     */   }
/*     */   private static InputStream fileToStream(String fname) throws IOException, SQLServerException {
/*     */     
/* 277 */     try { FileInputStream fis = new FileInputStream(fname); try { DataInputStream dis = new DataInputStream(fis); 
/* 278 */         try { byte[] bytes = new byte[dis.available()];
/* 279 */           dis.readFully(bytes);
/* 280 */           ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bytes);
/* 281 */           dis.close(); fis.close(); return byteArrayInputStream; } catch (Throwable throwable) { try { dis.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } catch (Throwable throwable) { try { fis.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } catch (FileNotFoundException e)
/* 282 */     { throw new SQLServerException(SQLServerException.getErrString("R_clientCertError"), null, 0, null); }
/*     */   
/*     */   }
/*     */   
/*     */   private static String getStringFromFile(String filePath) throws IOException {
/* 287 */     return new String(Files.readAllBytes(Paths.get(filePath, new String[0])));
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerCertificateUtils.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */