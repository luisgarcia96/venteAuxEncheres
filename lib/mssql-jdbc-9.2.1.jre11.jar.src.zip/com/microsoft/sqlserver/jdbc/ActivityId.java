/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.util.UUID;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ActivityId
/*     */ {
/*     */   private final UUID id;
/*     */   private final Thread thread;
/*     */   private long sequence;
/*     */   private boolean isSentToServer;
/*     */   
/*     */   ActivityId(Thread thread) {
/*  72 */     this.id = UUID.randomUUID();
/*  73 */     this.thread = thread;
/*  74 */     this.sequence = 0L;
/*  75 */     this.isSentToServer = false;
/*     */   }
/*     */   
/*     */   Thread getThread() {
/*  79 */     return this.thread;
/*     */   }
/*     */   
/*     */   UUID getId() {
/*  83 */     return this.id;
/*     */   }
/*     */   
/*     */   long getSequence() {
/*  87 */     return this.sequence;
/*     */   }
/*     */   
/*     */   void increment() {
/*  91 */     if (this.sequence < 4294967295L) {
/*     */       
/*  93 */       this.sequence++;
/*     */     } else {
/*  95 */       this.sequence = 0L;
/*     */     } 
/*     */     
/*  98 */     this.isSentToServer = false;
/*     */   }
/*     */   
/*     */   void setSentFlag() {
/* 102 */     this.isSentToServer = true;
/*     */   }
/*     */   
/*     */   boolean isSentToServer() {
/* 106 */     return this.isSentToServer;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 111 */     StringBuilder sb = new StringBuilder();
/* 112 */     sb.append(this.id.toString());
/* 113 */     sb.append("-");
/* 114 */     sb.append(this.sequence);
/* 115 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\ActivityId.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */