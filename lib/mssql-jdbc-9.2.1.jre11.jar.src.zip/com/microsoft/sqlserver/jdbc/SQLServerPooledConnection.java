/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Vector;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.sql.ConnectionEvent;
/*     */ import javax.sql.ConnectionEventListener;
/*     */ import javax.sql.PooledConnection;
/*     */ import javax.sql.StatementEventListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SQLServerPooledConnection
/*     */   implements PooledConnection, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 3492921646187451164L;
/*     */   private final Vector<ConnectionEventListener> listeners;
/*     */   private SQLServerDataSource factoryDataSource;
/*     */   private SQLServerConnection physicalConnection;
/*     */   private SQLServerConnectionPoolProxy lastProxyConnection;
/*     */   private String factoryUser;
/*     */   private String factoryPassword;
/*     */   private Logger pcLogger;
/*     */   private final String traceID;
/*  41 */   private static final AtomicInteger basePooledConnectionID = new AtomicInteger(0);
/*     */   
/*     */   SQLServerPooledConnection(SQLServerDataSource ds, String user, String password) throws SQLException {
/*  44 */     this.listeners = new Vector<>();
/*     */     
/*  46 */     this.pcLogger = SQLServerDataSource.dsLogger;
/*     */ 
/*     */     
/*  49 */     this.factoryDataSource = ds;
/*  50 */     this.factoryUser = user;
/*  51 */     this.factoryPassword = password;
/*     */     
/*  53 */     if (this.pcLogger.isLoggable(Level.FINER)) {
/*  54 */       this.pcLogger.finer(toString() + " Start create new connection for pool.");
/*     */     }
/*  56 */     this.physicalConnection = createNewConnection();
/*  57 */     String nameL = getClass().getName();
/*  58 */     this.traceID = nameL.substring(1 + nameL.lastIndexOf('.')) + ":" + nameL.substring(1 + nameL.lastIndexOf('.'));
/*  59 */     if (this.pcLogger.isLoggable(Level.FINE)) {
/*  60 */       this.pcLogger.fine(toString() + " created by (" + toString() + ") Physical connection " + ds.toString() + ", End create new connection for pool");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  71 */     return this.traceID;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private SQLServerConnection createNewConnection() throws SQLException {
/*  81 */     return this.factoryDataSource.getConnectionInternal(this.factoryUser, this.factoryPassword, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Connection getConnection() throws SQLException {
/*  93 */     if (this.pcLogger.isLoggable(Level.FINER))
/*  94 */       this.pcLogger.finer(toString() + " user:(default)."); 
/*  95 */     synchronized (this) {
/*     */       
/*  97 */       if (this.physicalConnection == null) {
/*  98 */         SQLServerException.makeFromDriverError(null, this, 
/*  99 */             SQLServerException.getErrString("R_physicalConnectionIsClosed"), "", true);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 106 */       this.physicalConnection.doSecurityCheck();
/* 107 */       if (this.pcLogger.isLoggable(Level.FINE)) {
/* 108 */         this.pcLogger.fine(toString() + " Physical connection, " + toString());
/*     */       }
/* 110 */       if (this.physicalConnection.needsReconnect()) {
/* 111 */         this.physicalConnection.close();
/* 112 */         this.physicalConnection = createNewConnection();
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 119 */       if (null != this.lastProxyConnection) {
/*     */         
/* 121 */         this.physicalConnection.resetPooledConnection();
/*     */         
/* 123 */         if (!this.lastProxyConnection.isClosed()) {
/* 124 */           if (this.pcLogger.isLoggable(Level.FINE)) {
/* 125 */             this.pcLogger.fine(toString() + "proxy " + toString() + " is not closed before getting the connection.");
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 132 */           this.lastProxyConnection.internalClose();
/*     */         } 
/*     */       } 
/*     */       
/* 136 */       this.lastProxyConnection = new SQLServerConnectionPoolProxy(this.physicalConnection);
/* 137 */       if (this.pcLogger.isLoggable(Level.FINE) && !this.lastProxyConnection.isClosed()) {
/* 138 */         this.pcLogger.fine(toString() + " proxy " + toString() + " is returned.");
/*     */       }
/* 140 */       return this.lastProxyConnection;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void notifyEvent(SQLServerException e) {
/* 150 */     if (this.pcLogger.isLoggable(Level.FINER)) {
/* 151 */       this.pcLogger.finer(toString() + " Exception:" + toString() + e);
/*     */     }
/*     */     
/* 154 */     if (null != e) {
/* 155 */       synchronized (this) {
/* 156 */         if (null != this.lastProxyConnection) {
/* 157 */           this.lastProxyConnection.internalClose();
/* 158 */           this.lastProxyConnection = null;
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 164 */     synchronized (this.listeners) {
/* 165 */       for (int i = 0; i < this.listeners.size(); i++) {
/* 166 */         ConnectionEventListener listener = this.listeners.elementAt(i);
/*     */         
/* 168 */         if (listener != null) {
/*     */ 
/*     */           
/* 171 */           ConnectionEvent ev = new ConnectionEvent(this, e);
/* 172 */           if (null == e) {
/* 173 */             if (this.pcLogger.isLoggable(Level.FINER))
/* 174 */               this.pcLogger.finer(toString() + " notifyEvent:connectionClosed " + toString()); 
/* 175 */             listener.connectionClosed(ev);
/*     */           } else {
/* 177 */             if (this.pcLogger.isLoggable(Level.FINER))
/* 178 */               this.pcLogger.finer(toString() + " notifyEvent:connectionErrorOccurred " + toString()); 
/* 179 */             listener.connectionErrorOccurred(ev);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void addConnectionEventListener(ConnectionEventListener listener) {
/* 187 */     if (this.pcLogger.isLoggable(Level.FINER))
/* 188 */       this.pcLogger.finer(toString() + toString()); 
/* 189 */     synchronized (this.listeners) {
/* 190 */       this.listeners.add(listener);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() throws SQLException {
/* 196 */     if (this.pcLogger.isLoggable(Level.FINER))
/* 197 */       this.pcLogger.finer(toString() + " Closing physical connection, " + toString()); 
/* 198 */     synchronized (this) {
/*     */       
/* 200 */       if (null != this.lastProxyConnection)
/*     */       {
/* 202 */         this.lastProxyConnection.internalClose(); } 
/* 203 */       if (null != this.physicalConnection) {
/* 204 */         this.physicalConnection.DetachFromPool();
/* 205 */         this.physicalConnection.close();
/*     */       } 
/* 207 */       this.physicalConnection = null;
/*     */     } 
/* 209 */     synchronized (this.listeners) {
/* 210 */       this.listeners.clear();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeConnectionEventListener(ConnectionEventListener listener) {
/* 217 */     if (this.pcLogger.isLoggable(Level.FINER))
/* 218 */       this.pcLogger.finer(toString() + toString()); 
/* 219 */     synchronized (this.listeners) {
/* 220 */       this.listeners.remove(listener);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addStatementEventListener(StatementEventListener listener) {
/* 227 */     throw new UnsupportedOperationException(SQLServerException.getErrString("R_notSupported"));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeStatementEventListener(StatementEventListener listener) {
/* 233 */     throw new UnsupportedOperationException(SQLServerException.getErrString("R_notSupported"));
/*     */   }
/*     */ 
/*     */   
/*     */   SQLServerConnection getPhysicalConnection() {
/* 238 */     return this.physicalConnection;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int nextPooledConnectionID() {
/* 243 */     return basePooledConnectionID.incrementAndGet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String safeCID() {
/* 251 */     if (null == this.physicalConnection)
/* 252 */       return " ConnectionID:(null)"; 
/* 253 */     return this.physicalConnection.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerPooledConnection.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */