/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.EnumMap;
/*     */ import java.util.EnumSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ enum SSType
/*     */ {
/*     */   final Category category;
/*     */   private final String name;
/*     */   private final JDBCType jdbcType;
/*     */   private static final SSType[] VALUES;
/* 115 */   UNKNOWN(Category.UNKNOWN, "unknown", JDBCType.UNKNOWN),
/* 116 */   TINYINT(Category.NUMERIC, "tinyint", JDBCType.TINYINT),
/* 117 */   BIT(Category.NUMERIC, "bit", JDBCType.BIT),
/* 118 */   SMALLINT(Category.NUMERIC, "smallint", JDBCType.SMALLINT),
/* 119 */   INTEGER(Category.NUMERIC, "int", JDBCType.INTEGER),
/* 120 */   BIGINT(Category.NUMERIC, "bigint", JDBCType.BIGINT),
/* 121 */   FLOAT(Category.NUMERIC, "float", JDBCType.DOUBLE),
/* 122 */   REAL(Category.NUMERIC, "real", JDBCType.REAL),
/* 123 */   SMALLDATETIME(Category.DATETIME, "smalldatetime", JDBCType.SMALLDATETIME),
/* 124 */   DATETIME(Category.DATETIME, "datetime", JDBCType.DATETIME),
/* 125 */   DATE(Category.DATE, "date", JDBCType.DATE),
/* 126 */   TIME(Category.TIME, "time", JDBCType.TIME),
/* 127 */   DATETIME2(Category.DATETIME2, "datetime2", JDBCType.TIMESTAMP),
/* 128 */   DATETIMEOFFSET(Category.DATETIMEOFFSET, "datetimeoffset", JDBCType.DATETIMEOFFSET),
/* 129 */   SMALLMONEY(Category.NUMERIC, "smallmoney", JDBCType.SMALLMONEY),
/* 130 */   MONEY(Category.NUMERIC, "money", JDBCType.MONEY),
/* 131 */   CHAR(Category.CHARACTER, "char", JDBCType.CHAR),
/* 132 */   VARCHAR(Category.CHARACTER, "varchar", JDBCType.VARCHAR),
/* 133 */   VARCHARMAX(Category.LONG_CHARACTER, "varchar", JDBCType.LONGVARCHAR),
/* 134 */   TEXT(Category.LONG_CHARACTER, "text", JDBCType.LONGVARCHAR),
/* 135 */   NCHAR(Category.NCHARACTER, "nchar", JDBCType.NCHAR),
/* 136 */   NVARCHAR(Category.NCHARACTER, "nvarchar", JDBCType.NVARCHAR),
/* 137 */   NVARCHARMAX(Category.LONG_NCHARACTER, "nvarchar", JDBCType.LONGNVARCHAR),
/* 138 */   NTEXT(Category.LONG_NCHARACTER, "ntext", JDBCType.LONGNVARCHAR),
/* 139 */   BINARY(Category.BINARY, "binary", JDBCType.BINARY),
/* 140 */   VARBINARY(Category.BINARY, "varbinary", JDBCType.VARBINARY),
/* 141 */   VARBINARYMAX(Category.LONG_BINARY, "varbinary", JDBCType.LONGVARBINARY),
/* 142 */   IMAGE(Category.LONG_BINARY, "image", JDBCType.LONGVARBINARY),
/* 143 */   DECIMAL(Category.NUMERIC, "decimal", JDBCType.DECIMAL),
/* 144 */   NUMERIC(Category.NUMERIC, "numeric", JDBCType.NUMERIC),
/* 145 */   GUID(Category.GUID, "uniqueidentifier", JDBCType.GUID),
/* 146 */   SQL_VARIANT(Category.SQL_VARIANT, "sql_variant", JDBCType.SQL_VARIANT),
/* 147 */   UDT(Category.UDT, "udt", JDBCType.VARBINARY),
/* 148 */   XML(Category.XML, "xml", JDBCType.LONGNVARCHAR),
/* 149 */   TIMESTAMP(Category.TIMESTAMP, "timestamp", JDBCType.BINARY),
/* 150 */   GEOMETRY(Category.UDT, "geometry", JDBCType.GEOMETRY),
/* 151 */   GEOGRAPHY(Category.UDT, "geography", JDBCType.GEOGRAPHY); static final BigDecimal MAX_VALUE_MONEY; static final BigDecimal MIN_VALUE_MONEY;
/*     */   static final BigDecimal MAX_VALUE_SMALLMONEY;
/*     */   static final BigDecimal MIN_VALUE_SMALLMONEY;
/*     */   
/*     */   static {
/* 156 */     VALUES = values();
/*     */     
/* 158 */     MAX_VALUE_MONEY = new BigDecimal("922337203685477.5807");
/* 159 */     MIN_VALUE_MONEY = new BigDecimal("-922337203685477.5808");
/* 160 */     MAX_VALUE_SMALLMONEY = new BigDecimal("214748.3647");
/* 161 */     MIN_VALUE_SMALLMONEY = new BigDecimal("-214748.3648");
/*     */   }
/*     */   SSType(Category category, String name, JDBCType jdbcType) {
/* 164 */     this.category = category;
/* 165 */     this.name = name;
/* 166 */     this.jdbcType = jdbcType;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 170 */     return this.name;
/*     */   }
/*     */   
/*     */   final JDBCType getJDBCType() {
/* 174 */     return this.jdbcType;
/*     */   }
/*     */   
/*     */   static SSType of(String typeName) throws SQLServerException {
/* 178 */     for (SSType ssType : VALUES) {
/* 179 */       if (ssType.name.equalsIgnoreCase(typeName))
/* 180 */         return ssType; 
/*     */     } 
/* 182 */     MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_unknownSSType"));
/* 183 */     Object[] msgArgs = { typeName };
/* 184 */     SQLServerException.makeFromDriverError(null, null, form.format(msgArgs), null, true);
/* 185 */     return UNKNOWN;
/*     */   }
/*     */   
/*     */   enum Category {
/* 189 */     BINARY,
/* 190 */     CHARACTER,
/* 191 */     DATE,
/* 192 */     DATETIME,
/* 193 */     DATETIME2,
/* 194 */     DATETIMEOFFSET,
/* 195 */     GUID,
/* 196 */     LONG_BINARY,
/* 197 */     LONG_CHARACTER,
/* 198 */     LONG_NCHARACTER,
/* 199 */     NCHARACTER,
/* 200 */     NUMERIC,
/* 201 */     UNKNOWN,
/* 202 */     TIME,
/* 203 */     TIMESTAMP,
/* 204 */     UDT,
/* 205 */     SQL_VARIANT,
/* 206 */     XML;
/*     */     
/* 208 */     private static final Category[] VALUES = values();
/*     */     static {
/*     */     
/*     */     } }
/* 212 */   enum GetterConversion { NUMERIC((String)SSType.Category.NUMERIC, EnumSet.of(JDBCType.Category.NUMERIC, JDBCType.Category.CHARACTER, JDBCType.Category.BINARY)),
/*     */ 
/*     */     
/* 215 */     DATETIME((String)SSType.Category.DATETIME, EnumSet.of(JDBCType.Category.DATE, JDBCType.Category.TIME, JDBCType.Category.TIMESTAMP, JDBCType.Category.CHARACTER, JDBCType.Category.BINARY)),
/*     */ 
/*     */     
/* 218 */     DATETIME2((String)SSType.Category.DATETIME2, EnumSet.of(JDBCType.Category.DATE, JDBCType.Category.TIME, JDBCType.Category.TIMESTAMP, JDBCType.Category.CHARACTER)),
/*     */ 
/*     */     
/* 221 */     DATE((String)SSType.Category.DATE, EnumSet.of(JDBCType.Category.DATE, JDBCType.Category.TIMESTAMP, JDBCType.Category.CHARACTER)),
/*     */ 
/*     */     
/* 224 */     TIME((String)SSType.Category.TIME, EnumSet.of(JDBCType.Category.TIME, JDBCType.Category.TIMESTAMP, JDBCType.Category.CHARACTER)),
/*     */ 
/*     */     
/* 227 */     DATETIMEOFFSET((String)SSType.Category.DATETIMEOFFSET, EnumSet.of(JDBCType.Category.DATE, JDBCType.Category.TIME, JDBCType.Category.TIMESTAMP, JDBCType.Category.DATETIMEOFFSET, JDBCType.Category.CHARACTER)),
/*     */ 
/*     */     
/* 230 */     CHARACTER((String)SSType.Category.CHARACTER, EnumSet.of(JDBCType.Category.NUMERIC, new JDBCType.Category[] { JDBCType.Category.DATE, JDBCType.Category.TIME, JDBCType.Category.TIMESTAMP, JDBCType.Category.CHARACTER, JDBCType.Category.LONG_CHARACTER, JDBCType.Category.BINARY, JDBCType.Category.GUID
/*     */ 
/*     */         
/*     */         })),
/* 234 */     LONG_CHARACTER((String)SSType.Category.LONG_CHARACTER, EnumSet.of(JDBCType.Category.NUMERIC, new JDBCType.Category[] { JDBCType.Category.DATE, JDBCType.Category.TIME, JDBCType.Category.TIMESTAMP, JDBCType.Category.CHARACTER, JDBCType.Category.LONG_CHARACTER, JDBCType.Category.BINARY, JDBCType.Category.CLOB
/*     */ 
/*     */         
/*     */         })),
/* 238 */     NCHARACTER((String)SSType.Category.NCHARACTER, EnumSet.of(JDBCType.Category.NUMERIC, new JDBCType.Category[] { JDBCType.Category.CHARACTER, JDBCType.Category.LONG_CHARACTER, JDBCType.Category.NCHARACTER, JDBCType.Category.LONG_NCHARACTER, JDBCType.Category.BINARY, JDBCType.Category.DATE, JDBCType.Category.TIME, JDBCType.Category.TIMESTAMP
/*     */ 
/*     */         
/*     */         })),
/* 242 */     LONG_NCHARACTER((String)SSType.Category.LONG_NCHARACTER, EnumSet.of(JDBCType.Category.NUMERIC, new JDBCType.Category[] { JDBCType.Category.CHARACTER, JDBCType.Category.LONG_CHARACTER, JDBCType.Category.NCHARACTER, JDBCType.Category.LONG_NCHARACTER, JDBCType.Category.BINARY, JDBCType.Category.DATE, JDBCType.Category.TIME, JDBCType.Category.TIMESTAMP, JDBCType.Category.CLOB, JDBCType.Category.NCLOB
/*     */ 
/*     */ 
/*     */         
/*     */         })),
/* 247 */     BINARY((String)SSType.Category.BINARY, EnumSet.of(JDBCType.Category.BINARY, JDBCType.Category.LONG_BINARY, JDBCType.Category.CHARACTER, JDBCType.Category.LONG_CHARACTER, JDBCType.Category.GUID)),
/*     */ 
/*     */     
/* 250 */     LONG_BINARY((String)SSType.Category.LONG_BINARY, EnumSet.of(JDBCType.Category.BINARY, JDBCType.Category.LONG_BINARY, JDBCType.Category.CHARACTER, JDBCType.Category.LONG_CHARACTER, JDBCType.Category.BLOB)),
/*     */ 
/*     */     
/* 253 */     TIMESTAMP((String)SSType.Category.TIMESTAMP, EnumSet.of(JDBCType.Category.BINARY, JDBCType.Category.LONG_BINARY, JDBCType.Category.CHARACTER)),
/*     */ 
/*     */     
/* 256 */     XML((String)SSType.Category.XML, EnumSet.of(JDBCType.Category.CHARACTER, new JDBCType.Category[] { JDBCType.Category.LONG_CHARACTER, JDBCType.Category.CLOB, JDBCType.Category.NCHARACTER, JDBCType.Category.LONG_NCHARACTER, JDBCType.Category.NCLOB, JDBCType.Category.BINARY, JDBCType.Category.LONG_BINARY, JDBCType.Category.BLOB, JDBCType.Category.SQLXML
/*     */ 
/*     */ 
/*     */         
/*     */         })),
/* 261 */     UDT((String)SSType.Category.UDT, EnumSet.of(JDBCType.Category.BINARY, JDBCType.Category.LONG_BINARY, JDBCType.Category.CHARACTER, JDBCType.Category.GEOMETRY, JDBCType.Category.GEOGRAPHY)),
/*     */ 
/*     */     
/* 264 */     GUID((String)SSType.Category.GUID, EnumSet.of(JDBCType.Category.BINARY, JDBCType.Category.CHARACTER)),
/*     */     
/* 266 */     SQL_VARIANT((String)SSType.Category.SQL_VARIANT, EnumSet.of(JDBCType.Category.CHARACTER, new JDBCType.Category[] { JDBCType.Category.SQL_VARIANT, JDBCType.Category.NUMERIC, JDBCType.Category.DATE, JDBCType.Category.TIME, JDBCType.Category.BINARY, JDBCType.Category.TIMESTAMP, JDBCType.Category.NCHARACTER, JDBCType.Category.GUID }));
/*     */     
/*     */     private final SSType.Category from;
/*     */     
/*     */     private final EnumSet<JDBCType.Category> to;
/*     */     
/* 272 */     private static final GetterConversion[] VALUES = values();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 279 */     private static final EnumMap<SSType.Category, EnumSet<JDBCType.Category>> conversionMap = new EnumMap<>(SSType.Category.class);
/*     */     
/*     */     static
/*     */     {
/* 283 */       for (SSType.Category category : SSType.Category.VALUES) {
/* 284 */         conversionMap.put(category, EnumSet.noneOf(JDBCType.Category.class));
/*     */       }
/* 286 */       for (GetterConversion conversion : VALUES)
/* 287 */         ((EnumSet<JDBCType.Category>)conversionMap.get(conversion.from)).addAll(conversion.to); 
/*     */     }
/*     */     
/*     */     static final boolean converts(SSType fromSSType, JDBCType toJDBCType) {
/* 291 */       return ((EnumSet)conversionMap.get(fromSSType.category)).contains(toJDBCType.category);
/*     */     } GetterConversion(SSType.Category from, EnumSet<JDBCType.Category> to) {
/*     */       this.from = from;
/*     */       this.to = to;
/*     */     } } boolean convertsTo(JDBCType jdbcType) {
/* 296 */     return GetterConversion.converts(this, jdbcType);
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SSType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */