/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.text.MessageFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DLLException
/*     */   extends Exception
/*     */ {
/*     */   private static final long serialVersionUID = -4498171382218222079L;
/*  20 */   private int category = -9;
/*     */   
/*  22 */   private int status = -9;
/*     */   
/*  24 */   private int state = -9;
/*     */ 
/*     */   
/*  27 */   private int errCode = -1;
/*     */   
/*  29 */   private String param1 = "";
/*  30 */   private String param2 = "";
/*  31 */   private String param3 = "";
/*     */   
/*     */   DLLException(String message, int category, int status, int state) {
/*  34 */     super(message);
/*  35 */     this.category = category;
/*  36 */     this.status = status;
/*  37 */     this.state = state;
/*     */   }
/*     */   
/*     */   DLLException(String param1, String param2, String param3, int errCode) {
/*  41 */     this.errCode = errCode;
/*  42 */     this.param1 = param1;
/*  43 */     this.param2 = param2;
/*  44 */     this.param3 = param3;
/*     */   }
/*     */   
/*     */   int GetCategory() {
/*  48 */     return this.category;
/*     */   }
/*     */   
/*     */   int GetStatus() {
/*  52 */     return this.status;
/*     */   }
/*     */   
/*     */   int GetState() {
/*  56 */     return this.state;
/*     */   }
/*     */   
/*     */   int GetErrCode() {
/*  60 */     return this.errCode;
/*     */   }
/*     */   
/*     */   String GetParam1() {
/*  64 */     return this.param1;
/*     */   }
/*     */   
/*     */   String GetParam2() {
/*  68 */     return this.param2;
/*     */   }
/*     */   
/*     */   String GetParam3() {
/*  72 */     return this.param3;
/*     */   }
/*     */ 
/*     */   
/*     */   static void buildException(int errCode, String param1, String param2, String param3) throws SQLServerException {
/*  77 */     String errMessage = getErrMessage(errCode);
/*  78 */     MessageFormat form = new MessageFormat(SQLServerException.getErrString(errMessage));
/*     */     
/*  80 */     String[] msgArgs = buildMsgParams(errMessage, param1, param2, param3);
/*     */     
/*  82 */     throw new SQLServerException(null, form.format(msgArgs), null, 0, false);
/*     */   }
/*     */ 
/*     */   
/*     */   private static String[] buildMsgParams(String errMessage, String parameter1, String parameter2, String parameter3) {
/*  87 */     String[] msgArgs = new String[3];
/*     */     
/*  89 */     if ("R_AECertLocBad".equalsIgnoreCase(errMessage)) {
/*  90 */       msgArgs[0] = parameter1;
/*  91 */       msgArgs[1] = parameter1 + "/" + parameter1 + "/" + parameter2;
/*  92 */     } else if ("R_AECertStoreBad".equalsIgnoreCase(errMessage)) {
/*  93 */       msgArgs[0] = parameter2;
/*  94 */       msgArgs[1] = parameter1 + "/" + parameter1 + "/" + parameter2;
/*  95 */     } else if ("R_AECertHashEmpty".equalsIgnoreCase(errMessage)) {
/*  96 */       msgArgs[0] = parameter1 + "/" + parameter1 + "/" + parameter2;
/*     */     } else {
/*  98 */       msgArgs[0] = parameter1;
/*  99 */       msgArgs[1] = parameter2;
/* 100 */       msgArgs[2] = parameter3;
/*     */     } 
/*     */     
/* 103 */     return msgArgs;
/*     */   }
/*     */ 
/*     */   
/*     */   private static String getErrMessage(int errCode) {
/* 108 */     switch (errCode)
/*     */     { case 1:
/* 110 */         message = "R_AEKeypathEmpty";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 165 */         return message;case 2: message = "R_EncryptedCEKNull"; return message;case 3: message = "R_NullKeyEncryptionAlgorithm"; return message;case 4: message = "R_AEWinApiErr"; return message;case 5: message = "R_AECertpathBad"; return message;case 6: message = "R_AECertLocBad"; return message;case 7: message = "R_AECertStoreBad"; return message;case 8: message = "R_AECertHashEmpty"; return message;case 9: message = "R_AECertNotFound"; return message;case 10: message = "R_AEMaloc"; return message;case 11: message = "R_EmptyEncryptedCEK"; return message;case 12: message = "R_InvalidKeyEncryptionAlgorithm"; return message;case 13: message = "R_AEKeypathLong"; return message;case 14: message = "R_InvalidEcryptionAlgorithmVersion"; return message;case 15: message = "R_AEECEKLenBad"; return message;case 16: message = "R_AEECEKSigLenBad"; return message;case 17: message = "R_InvalidCertificateSignature"; return message; }  String message = "R_AEWinApiErr"; return message;
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\DLLException.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */