/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum InternalSpatialDatatype
/*    */ {
/*    */   private byte typeCode;
/*    */   private String typeName;
/* 12 */   POINT((byte)1, "POINT"),
/* 13 */   LINESTRING((byte)2, "LINESTRING"),
/* 14 */   POLYGON((byte)3, "POLYGON"),
/* 15 */   MULTIPOINT((byte)4, "MULTIPOINT"),
/* 16 */   MULTILINESTRING((byte)5, "MULTILINESTRING"),
/* 17 */   MULTIPOLYGON((byte)6, "MULTIPOLYGON"),
/* 18 */   GEOMETRYCOLLECTION((byte)7, "GEOMETRYCOLLECTION"),
/* 19 */   CIRCULARSTRING((byte)8, "CIRCULARSTRING"),
/* 20 */   COMPOUNDCURVE((byte)9, "COMPOUNDCURVE"),
/* 21 */   CURVEPOLYGON((byte)10, "CURVEPOLYGON"),
/* 22 */   FULLGLOBE((byte)11, "FULLGLOBE"),
/* 23 */   INVALID_TYPE((byte)0, null);
/*    */   private static final InternalSpatialDatatype[] VALUES;
/*    */   
/*    */   static {
/* 27 */     VALUES = values();
/*    */   }
/*    */   InternalSpatialDatatype(byte typeCode, String typeName) {
/* 30 */     this.typeCode = typeCode;
/* 31 */     this.typeName = typeName;
/*    */   }
/*    */   
/*    */   byte getTypeCode() {
/* 35 */     return this.typeCode;
/*    */   }
/*    */   
/*    */   String getTypeName() {
/* 39 */     return this.typeName;
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\InternalSpatialDatatype.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */