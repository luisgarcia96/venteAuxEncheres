/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import java.text.MessageFormat;
/*    */ import java.util.logging.Level;
/*    */ import java.util.logging.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MaxResultBufferCounter
/*    */   implements ICounter
/*    */ {
/* 18 */   private final Logger logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.MaxResultBufferCounter");
/*    */   
/* 20 */   private long counter = 0L;
/*    */   private final long maxResultBuffer;
/*    */   
/*    */   public MaxResultBufferCounter(long maxResultBuffer) {
/* 24 */     this.maxResultBuffer = maxResultBuffer;
/*    */   }
/*    */   
/*    */   public void increaseCounter(long bytes) throws SQLServerException {
/* 28 */     if (this.maxResultBuffer > 0L) {
/* 29 */       this.counter += bytes;
/* 30 */       checkForMaxResultBufferOverflow(this.counter);
/*    */     } 
/*    */   }
/*    */   
/*    */   public void resetCounter() {
/* 35 */     this.counter = 0L;
/*    */   }
/*    */   
/*    */   private void checkForMaxResultBufferOverflow(long number) throws SQLServerException {
/* 39 */     if (number > this.maxResultBuffer) {
/* 40 */       if (this.logger.isLoggable(Level.SEVERE))
/* 41 */         this.logger.log(Level.SEVERE, SQLServerException.getErrString("R_maxResultBufferPropertyExceeded"), new Object[] {
/* 42 */               Long.valueOf(number), Long.valueOf(this.maxResultBuffer)
/*    */             }); 
/* 44 */       throwExceededMaxResultBufferException(new Object[] { Long.valueOf(this.counter), Long.valueOf(this.maxResultBuffer) });
/*    */     } 
/*    */   }
/*    */   
/*    */   private void throwExceededMaxResultBufferException(Object... arguments) throws SQLServerException {
/* 49 */     MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_maxResultBufferPropertyExceeded"));
/* 50 */     throw new SQLServerException(form.format(arguments), null);
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\MaxResultBufferCounter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */