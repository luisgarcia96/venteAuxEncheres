/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import java.util.regex.Matcher;
/*    */ import java.util.regex.Pattern;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ThreePartName
/*    */ {
/* 18 */   private static final Pattern THREE_PART_NAME = Pattern.compile(JDBCSyntaxTranslator.getSQLIdentifierWithGroups());
/*    */   
/*    */   private final String databasePart;
/*    */   private final String ownerPart;
/*    */   private final String procedurePart;
/*    */   
/*    */   private ThreePartName(String databasePart, String ownerPart, String procedurePart) {
/* 25 */     this.databasePart = databasePart;
/* 26 */     this.ownerPart = ownerPart;
/* 27 */     this.procedurePart = procedurePart;
/*    */   }
/*    */   
/*    */   String getDatabasePart() {
/* 31 */     return this.databasePart;
/*    */   }
/*    */   
/*    */   String getOwnerPart() {
/* 35 */     return this.ownerPart;
/*    */   }
/*    */   
/*    */   String getProcedurePart() {
/* 39 */     return this.procedurePart;
/*    */   }
/*    */   
/*    */   static ThreePartName parse(String theProcName) {
/* 43 */     String procedurePart = null;
/* 44 */     String ownerPart = null;
/* 45 */     String databasePart = null;
/*    */     
/* 47 */     if (null != theProcName) {
/* 48 */       Matcher matcher = THREE_PART_NAME.matcher(theProcName);
/* 49 */       if (matcher.matches()) {
/* 50 */         if (matcher.group(2) != null) {
/* 51 */           databasePart = matcher.group(1);
/*    */ 
/*    */           
/* 54 */           matcher = THREE_PART_NAME.matcher(matcher.group(2));
/* 55 */           if (matcher.matches()) {
/* 56 */             if (null != matcher.group(2)) {
/* 57 */               ownerPart = matcher.group(1);
/* 58 */               procedurePart = matcher.group(2);
/*    */             } else {
/* 60 */               ownerPart = databasePart;
/* 61 */               databasePart = null;
/* 62 */               procedurePart = matcher.group(1);
/*    */             } 
/*    */           }
/*    */         } else {
/* 66 */           procedurePart = matcher.group(1);
/*    */         } 
/*    */       } else {
/* 69 */         procedurePart = theProcName;
/*    */       } 
/*    */     } 
/* 72 */     return new ThreePartName(databasePart, ownerPart, procedurePart);
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\ThreePartName.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */