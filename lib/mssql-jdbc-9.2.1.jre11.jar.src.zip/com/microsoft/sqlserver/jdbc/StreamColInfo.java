/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class StreamColInfo
/*    */   extends StreamPacket
/*    */ {
/*    */   private TDSReader tdsReader;
/*    */   private TDSReaderMark colInfoMark;
/*    */   
/*    */   StreamColInfo() {
/* 17 */     super(165);
/*    */   }
/*    */   
/*    */   void setFromTDS(TDSReader tdsReader) throws SQLServerException {
/* 21 */     if (165 != tdsReader.readUnsignedByte() && 
/* 22 */       !$assertionsDisabled) throw new AssertionError("Not a COLINFO token");
/*    */     
/* 24 */     this.tdsReader = tdsReader;
/* 25 */     int tokenLength = tdsReader.readUnsignedShort();
/* 26 */     this.colInfoMark = tdsReader.mark();
/* 27 */     tdsReader.skip(tokenLength);
/*    */   }
/*    */   
/*    */   int applyTo(Column[] columns) throws SQLServerException {
/* 31 */     int numTables = 0;
/*    */ 
/*    */     
/* 34 */     TDSReaderMark currentMark = this.tdsReader.mark();
/* 35 */     this.tdsReader.reset(this.colInfoMark);
/* 36 */     for (Column col : columns) {
/*    */ 
/*    */ 
/*    */       
/* 40 */       this.tdsReader.readUnsignedByte();
/*    */ 
/*    */ 
/*    */       
/* 44 */       col.setTableNum(this.tdsReader.readUnsignedByte());
/* 45 */       if (col.getTableNum() > numTables) {
/* 46 */         numTables = col.getTableNum();
/*    */       }
/*    */       
/* 49 */       col.setInfoStatus(this.tdsReader.readUnsignedByte());
/* 50 */       if (col.hasDifferentName()) {
/* 51 */         col.setBaseColumnName(this.tdsReader.readUnicodeString(this.tdsReader.readUnsignedByte()));
/*    */       }
/*    */     } 
/* 54 */     this.tdsReader.reset(currentMark);
/* 55 */     return numTables;
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\StreamColInfo.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */