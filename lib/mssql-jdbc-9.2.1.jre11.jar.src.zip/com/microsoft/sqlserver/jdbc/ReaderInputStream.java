/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.CharBuffer;
/*     */ import java.nio.charset.Charset;
/*     */ import java.text.MessageFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ReaderInputStream
/*     */   extends InputStream
/*     */ {
/*     */   private final Reader reader;
/*     */   private final Charset charset;
/*     */   private final long readerLength;
/*  42 */   private long readerCharsRead = 0L;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean atEndOfStream = false;
/*     */ 
/*     */   
/*  49 */   private CharBuffer rawChars = null;
/*     */ 
/*     */   
/*     */   private static final int MAX_CHAR_BUFFER_SIZE = 4000;
/*     */   
/*  54 */   private static final ByteBuffer EMPTY_BUFFER = ByteBuffer.allocate(0);
/*  55 */   private ByteBuffer encodedChars = EMPTY_BUFFER;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final byte[] oneByte;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int available() throws IOException {
/*  76 */     assert null != this.reader;
/*  77 */     assert null != this.encodedChars;
/*     */ 
/*     */     
/*  80 */     if (0L == this.readerLength) {
/*  81 */       return 0;
/*     */     }
/*     */     
/*  84 */     if (this.encodedChars.remaining() > 0) {
/*  85 */       return this.encodedChars.remaining();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  90 */     if (this.reader.ready()) {
/*  91 */       return 1;
/*     */     }
/*     */ 
/*     */     
/*  95 */     return 0;
/*     */   }
/*     */   
/*  98 */   ReaderInputStream(Reader reader, Charset charset, long readerLength) { this.oneByte = new byte[1]; assert reader != null; assert charset != null; assert -1L == readerLength || readerLength >= 0L;
/*     */     this.reader = reader;
/*     */     this.charset = charset;
/* 101 */     this.readerLength = readerLength; } public int read() throws IOException { return (-1 == readInternal(this.oneByte, 0, this.oneByte.length)) ? -1 : this.oneByte[0]; }
/*     */ 
/*     */   
/*     */   public int read(byte[] b) throws IOException {
/* 105 */     return readInternal(b, 0, b.length);
/*     */   }
/*     */   
/*     */   public int read(byte[] b, int off, int len) throws IOException {
/* 109 */     return readInternal(b, off, len);
/*     */   }
/*     */   
/*     */   private int readInternal(byte[] b, int off, int len) throws IOException {
/* 113 */     assert null != b;
/* 114 */     assert 0 <= off && off <= b.length;
/* 115 */     assert 0 <= len && len <= b.length;
/* 116 */     assert off <= b.length - len;
/*     */     
/* 118 */     if (0 == len) {
/* 119 */       return 0;
/*     */     }
/* 121 */     int bytesRead = 0;
/* 122 */     while (bytesRead < len && encodeChars()) {
/*     */ 
/*     */ 
/*     */       
/* 126 */       int bytesToRead = this.encodedChars.remaining();
/* 127 */       if (bytesToRead > len - bytesRead) {
/* 128 */         bytesToRead = len - bytesRead;
/*     */       }
/*     */ 
/*     */       
/* 132 */       assert bytesToRead > 0;
/*     */       
/* 134 */       this.encodedChars.get(b, off + bytesRead, bytesToRead);
/* 135 */       bytesRead += bytesToRead;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 140 */     return (0 == bytesRead && this.atEndOfStream) ? -1 : bytesRead;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean encodeChars() throws IOException {
/* 154 */     if (this.atEndOfStream) {
/* 155 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 160 */     if (this.encodedChars.hasRemaining()) {
/* 161 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 171 */     if (null == this.rawChars || !this.rawChars.hasRemaining()) {
/* 172 */       if (null == this.rawChars) {
/*     */         
/* 174 */         this.rawChars = CharBuffer.allocate((-1L == this.readerLength || this.readerLength > 4000L) ? 
/* 175 */             4000 : 
/* 176 */             Math.max((int)this.readerLength, 1));
/*     */       } else {
/*     */         
/* 179 */         this.rawChars.clear();
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 190 */       while (this.rawChars.hasRemaining()) {
/* 191 */         int lastPosition = this.rawChars.position();
/* 192 */         int charsRead = 0;
/*     */ 
/*     */         
/*     */         try {
/* 196 */           charsRead = this.reader.read(this.rawChars);
/*     */ 
/*     */ 
/*     */         
/*     */         }
/* 201 */         catch (Exception e) {
/* 202 */           String detailMessage = e.getMessage();
/* 203 */           if (null == detailMessage)
/* 204 */             detailMessage = SQLServerException.getErrString("R_streamReadReturnedInvalidValue"); 
/* 205 */           IOException ioException = new IOException(detailMessage);
/* 206 */           ioException.initCause(e);
/* 207 */           throw ioException;
/*     */         } 
/*     */         
/* 210 */         if (charsRead < -1 || 0 == charsRead) {
/* 211 */           throw new IOException(SQLServerException.getErrString("R_streamReadReturnedInvalidValue"));
/*     */         }
/* 213 */         if (-1 == charsRead) {
/*     */           
/* 215 */           if (this.rawChars.position() != lastPosition) {
/* 216 */             throw new IOException(SQLServerException.getErrString("R_streamReadReturnedInvalidValue"));
/*     */           }
/*     */           
/* 219 */           if (-1L != this.readerLength && 0L != this.readerLength - this.readerCharsRead) {
/*     */             
/* 221 */             MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_mismatchedStreamLength"));
/* 222 */             throw new IOException(form.format(new Object[] { Long.valueOf(this.readerLength), Long.valueOf(this.readerCharsRead) }));
/*     */           } 
/*     */ 
/*     */           
/* 226 */           if (0 == this.rawChars.position()) {
/* 227 */             this.rawChars = null;
/* 228 */             this.atEndOfStream = true;
/* 229 */             return false;
/*     */           } 
/*     */ 
/*     */           
/*     */           break;
/*     */         } 
/*     */         
/* 236 */         assert charsRead > 0;
/*     */ 
/*     */         
/* 239 */         if (charsRead != this.rawChars.position() - lastPosition) {
/* 240 */           throw new IOException(SQLServerException.getErrString("R_streamReadReturnedInvalidValue"));
/*     */         }
/*     */         
/* 243 */         if (-1L != this.readerLength && charsRead > this.readerLength - this.readerCharsRead) {
/* 244 */           MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_mismatchedStreamLength"));
/* 245 */           throw new IOException(form.format(new Object[] { Long.valueOf(this.readerLength), Long.valueOf(this.readerCharsRead) }));
/*     */         } 
/*     */         
/* 248 */         this.readerCharsRead += charsRead;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 253 */       this.rawChars.flip();
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 259 */     if (!this.rawChars.hasRemaining()) {
/* 260 */       return false;
/*     */     }
/*     */     
/* 263 */     this.encodedChars = this.charset.encode(this.rawChars);
/* 264 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\ReaderInputStream.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */