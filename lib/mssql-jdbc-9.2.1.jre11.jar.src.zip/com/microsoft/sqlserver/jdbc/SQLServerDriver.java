/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.Driver;
/*     */ import java.sql.DriverManager;
/*     */ import java.sql.DriverPropertyInfo;
/*     */ import java.sql.SQLException;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Properties;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SQLServerDriver
/*     */   implements Driver
/*     */ {
/*     */   static final String PRODUCT_NAME = "Microsoft JDBC Driver 9.2 for SQL Server";
/* 476 */   static final String AUTH_DLL_NAME = "mssql-jdbc_auth-9.2.1." + Util.getJVMArchOnWindows();
/*     */   
/*     */   static final String DEFAULT_APP_NAME = "Microsoft JDBC Driver for SQL Server";
/* 479 */   private static final String[] TRUE_FALSE = new String[] { "true", "false" };
/* 480 */   private static final SQLServerDriverPropertyInfo[] DRIVER_PROPERTIES = new SQLServerDriverPropertyInfo[] { new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.APPLICATION_INTENT
/*     */ 
/*     */         
/* 483 */         .toString(), SQLServerDriverStringProperty.APPLICATION_INTENT
/* 484 */         .getDefaultValue(), false, new String[] { ApplicationIntent.READ_ONLY
/* 485 */           .toString(), ApplicationIntent.READ_WRITE.toString() }), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.APPLICATION_NAME
/* 486 */         .toString(), SQLServerDriverStringProperty.APPLICATION_NAME
/* 487 */         .getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.COLUMN_ENCRYPTION
/* 488 */         .toString(), SQLServerDriverStringProperty.COLUMN_ENCRYPTION
/* 489 */         .getDefaultValue(), false, new String[] { ColumnEncryptionSetting.Disabled
/* 490 */           .toString(), ColumnEncryptionSetting.Enabled
/* 491 */           .toString() }), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.ENCLAVE_ATTESTATION_URL
/* 492 */         .toString(), SQLServerDriverStringProperty.ENCLAVE_ATTESTATION_URL
/* 493 */         .getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.ENCLAVE_ATTESTATION_PROTOCOL
/* 494 */         .toString(), SQLServerDriverStringProperty.ENCLAVE_ATTESTATION_PROTOCOL
/* 495 */         .getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.DATABASE_NAME
/* 496 */         .toString(), SQLServerDriverStringProperty.DATABASE_NAME
/* 497 */         .getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverBooleanProperty.DISABLE_STATEMENT_POOLING
/* 498 */         .toString(), 
/* 499 */         Boolean.toString(SQLServerDriverBooleanProperty.DISABLE_STATEMENT_POOLING.getDefaultValue()), false, new String[] { "true" }), new SQLServerDriverPropertyInfo(SQLServerDriverBooleanProperty.ENCRYPT
/*     */         
/* 501 */         .toString(), 
/* 502 */         Boolean.toString(SQLServerDriverBooleanProperty.ENCRYPT.getDefaultValue()), false, TRUE_FALSE), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.FAILOVER_PARTNER
/* 503 */         .toString(), SQLServerDriverStringProperty.FAILOVER_PARTNER
/* 504 */         .getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.HOSTNAME_IN_CERTIFICATE
/* 505 */         .toString(), SQLServerDriverStringProperty.HOSTNAME_IN_CERTIFICATE
/* 506 */         .getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.INSTANCE_NAME
/* 507 */         .toString(), SQLServerDriverStringProperty.INSTANCE_NAME
/* 508 */         .getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverBooleanProperty.INTEGRATED_SECURITY
/* 509 */         .toString(), 
/* 510 */         Boolean.toString(SQLServerDriverBooleanProperty.INTEGRATED_SECURITY.getDefaultValue()), false, TRUE_FALSE), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.KEY_STORE_AUTHENTICATION
/*     */         
/* 512 */         .toString(), SQLServerDriverStringProperty.KEY_STORE_AUTHENTICATION
/* 513 */         .getDefaultValue(), false, new String[] { KeyStoreAuthentication.JavaKeyStorePassword
/* 514 */           .toString() }), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.KEY_STORE_SECRET
/* 515 */         .toString(), SQLServerDriverStringProperty.KEY_STORE_SECRET
/* 516 */         .getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.KEY_STORE_LOCATION
/* 517 */         .toString(), SQLServerDriverStringProperty.KEY_STORE_LOCATION
/* 518 */         .getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverBooleanProperty.LAST_UPDATE_COUNT
/* 519 */         .toString(), 
/* 520 */         Boolean.toString(SQLServerDriverBooleanProperty.LAST_UPDATE_COUNT.getDefaultValue()), false, TRUE_FALSE), new SQLServerDriverPropertyInfo(SQLServerDriverIntProperty.LOCK_TIMEOUT
/*     */         
/* 522 */         .toString(), 
/* 523 */         Integer.toString(SQLServerDriverIntProperty.LOCK_TIMEOUT.getDefaultValue()), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverIntProperty.LOGIN_TIMEOUT
/* 524 */         .toString(), 
/* 525 */         Integer.toString(SQLServerDriverIntProperty.LOGIN_TIMEOUT.getDefaultValue()), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverBooleanProperty.MULTI_SUBNET_FAILOVER
/* 526 */         .toString(), 
/* 527 */         Boolean.toString(SQLServerDriverBooleanProperty.MULTI_SUBNET_FAILOVER.getDefaultValue()), false, TRUE_FALSE), new SQLServerDriverPropertyInfo(SQLServerDriverIntProperty.PACKET_SIZE
/*     */         
/* 529 */         .toString(), 
/* 530 */         Integer.toString(SQLServerDriverIntProperty.PACKET_SIZE.getDefaultValue()), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.PASSWORD
/* 531 */         .toString(), SQLServerDriverStringProperty.PASSWORD
/* 532 */         .getDefaultValue(), true, null), new SQLServerDriverPropertyInfo(SQLServerDriverIntProperty.PORT_NUMBER
/* 533 */         .toString(), 
/* 534 */         Integer.toString(SQLServerDriverIntProperty.PORT_NUMBER.getDefaultValue()), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverIntProperty.QUERY_TIMEOUT
/* 535 */         .toString(), 
/* 536 */         Integer.toString(SQLServerDriverIntProperty.QUERY_TIMEOUT.getDefaultValue()), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.RESPONSE_BUFFERING
/* 537 */         .toString(), SQLServerDriverStringProperty.RESPONSE_BUFFERING
/* 538 */         .getDefaultValue(), false, new String[] { "adaptive", "full" }), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.SELECT_METHOD
/*     */         
/* 540 */         .toString(), SQLServerDriverStringProperty.SELECT_METHOD
/* 541 */         .getDefaultValue(), false, new String[] { "direct", "cursor" }), new SQLServerDriverPropertyInfo(SQLServerDriverBooleanProperty.SEND_STRING_PARAMETERS_AS_UNICODE
/*     */         
/* 543 */         .toString(), 
/* 544 */         Boolean.toString(SQLServerDriverBooleanProperty.SEND_STRING_PARAMETERS_AS_UNICODE
/* 545 */           .getDefaultValue()), false, TRUE_FALSE), new SQLServerDriverPropertyInfo(SQLServerDriverBooleanProperty.SERVER_NAME_AS_ACE
/*     */         
/* 547 */         .toString(), 
/* 548 */         Boolean.toString(SQLServerDriverBooleanProperty.SERVER_NAME_AS_ACE.getDefaultValue()), false, TRUE_FALSE), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.DOMAIN
/*     */         
/* 550 */         .toString(), SQLServerDriverStringProperty.DOMAIN
/* 551 */         .getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.SERVER_NAME
/* 552 */         .toString(), SQLServerDriverStringProperty.SERVER_NAME
/* 553 */         .getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.SERVER_SPN
/* 554 */         .toString(), SQLServerDriverStringProperty.SERVER_SPN
/* 555 */         .getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.SOCKET_FACTORY_CLASS
/* 556 */         .toString(), SQLServerDriverStringProperty.SOCKET_FACTORY_CLASS
/* 557 */         .getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.SOCKET_FACTORY_CONSTRUCTOR_ARG
/* 558 */         .toString(), SQLServerDriverStringProperty.SOCKET_FACTORY_CONSTRUCTOR_ARG
/* 559 */         .getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverBooleanProperty.TRANSPARENT_NETWORK_IP_RESOLUTION
/* 560 */         .toString(), 
/* 561 */         Boolean.toString(SQLServerDriverBooleanProperty.TRANSPARENT_NETWORK_IP_RESOLUTION
/* 562 */           .getDefaultValue()), false, TRUE_FALSE), new SQLServerDriverPropertyInfo(SQLServerDriverBooleanProperty.TRUST_SERVER_CERTIFICATE
/*     */         
/* 564 */         .toString(), 
/* 565 */         Boolean.toString(SQLServerDriverBooleanProperty.TRUST_SERVER_CERTIFICATE.getDefaultValue()), false, TRUE_FALSE), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.TRUST_STORE_TYPE
/*     */         
/* 567 */         .toString(), SQLServerDriverStringProperty.TRUST_STORE_TYPE
/* 568 */         .getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.TRUST_STORE
/* 569 */         .toString(), SQLServerDriverStringProperty.TRUST_STORE
/* 570 */         .getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.TRUST_STORE_PASSWORD
/* 571 */         .toString(), SQLServerDriverStringProperty.TRUST_STORE_PASSWORD
/* 572 */         .getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.TRUST_MANAGER_CLASS
/* 573 */         .toString(), SQLServerDriverStringProperty.TRUST_MANAGER_CLASS
/* 574 */         .getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.TRUST_MANAGER_CONSTRUCTOR_ARG
/* 575 */         .toString(), SQLServerDriverStringProperty.TRUST_MANAGER_CONSTRUCTOR_ARG
/* 576 */         .getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverBooleanProperty.SEND_TIME_AS_DATETIME
/* 577 */         .toString(), 
/* 578 */         Boolean.toString(SQLServerDriverBooleanProperty.SEND_TIME_AS_DATETIME.getDefaultValue()), false, TRUE_FALSE), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.USER
/*     */         
/* 580 */         .toString(), SQLServerDriverStringProperty.USER
/* 581 */         .getDefaultValue(), true, null), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.WORKSTATION_ID
/* 582 */         .toString(), SQLServerDriverStringProperty.WORKSTATION_ID
/* 583 */         .getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverBooleanProperty.XOPEN_STATES
/* 584 */         .toString(), 
/* 585 */         Boolean.toString(SQLServerDriverBooleanProperty.XOPEN_STATES.getDefaultValue()), false, TRUE_FALSE), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.AUTHENTICATION_SCHEME
/* 586 */         .toString(), SQLServerDriverStringProperty.AUTHENTICATION_SCHEME
/* 587 */         .getDefaultValue(), false, new String[] { AuthenticationScheme.javaKerberos
/* 588 */           .toString(), AuthenticationScheme.nativeAuthentication
/* 589 */           .toString(), AuthenticationScheme.ntlm
/* 590 */           .toString() }), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.AUTHENTICATION
/* 591 */         .toString(), SQLServerDriverStringProperty.AUTHENTICATION
/* 592 */         .getDefaultValue(), false, new String[] { SqlAuthentication.NotSpecified
/* 593 */           .toString(), SqlAuthentication.SqlPassword.toString(), SqlAuthentication.ActiveDirectoryPassword
/* 594 */           .toString(), SqlAuthentication.ActiveDirectoryIntegrated
/* 595 */           .toString(), SqlAuthentication.ActiveDirectoryMSI
/* 596 */           .toString(), SqlAuthentication.ActiveDirectoryServicePrincipal
/* 597 */           .toString(), SqlAuthentication.ActiveDirectoryInteractive
/* 598 */           .toString() }), new SQLServerDriverPropertyInfo(SQLServerDriverIntProperty.SOCKET_TIMEOUT
/*     */         
/* 600 */         .toString(), 
/* 601 */         Integer.toString(SQLServerDriverIntProperty.SOCKET_TIMEOUT.getDefaultValue()), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverBooleanProperty.FIPS
/* 602 */         .toString(), 
/* 603 */         Boolean.toString(SQLServerDriverBooleanProperty.FIPS.getDefaultValue()), false, TRUE_FALSE), new SQLServerDriverPropertyInfo(SQLServerDriverBooleanProperty.ENABLE_PREPARE_ON_FIRST_PREPARED_STATEMENT
/*     */         
/* 605 */         .toString(), 
/* 606 */         Boolean.toString(SQLServerDriverBooleanProperty.ENABLE_PREPARE_ON_FIRST_PREPARED_STATEMENT
/* 607 */           .getDefaultValue()), false, TRUE_FALSE), new SQLServerDriverPropertyInfo(SQLServerDriverIntProperty.SERVER_PREPARED_STATEMENT_DISCARD_THRESHOLD
/*     */ 
/*     */         
/* 610 */         .toString(), 
/* 611 */         Integer.toString(SQLServerDriverIntProperty.SERVER_PREPARED_STATEMENT_DISCARD_THRESHOLD
/* 612 */           .getDefaultValue()), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverIntProperty.STATEMENT_POOLING_CACHE_SIZE
/*     */         
/* 614 */         .toString(), 
/* 615 */         Integer.toString(SQLServerDriverIntProperty.STATEMENT_POOLING_CACHE_SIZE.getDefaultValue()), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.JAAS_CONFIG_NAME
/*     */         
/* 617 */         .toString(), SQLServerDriverStringProperty.JAAS_CONFIG_NAME
/* 618 */         .getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.SSL_PROTOCOL
/* 619 */         .toString(), SQLServerDriverStringProperty.SSL_PROTOCOL
/* 620 */         .getDefaultValue(), false, new String[] { SSLProtocol.TLS
/* 621 */           .toString(), SSLProtocol.TLS_V10.toString(), SSLProtocol.TLS_V11
/* 622 */           .toString(), SSLProtocol.TLS_V12.toString() }), new SQLServerDriverPropertyInfo(SQLServerDriverIntProperty.CANCEL_QUERY_TIMEOUT
/* 623 */         .toString(), 
/* 624 */         Integer.toString(SQLServerDriverIntProperty.CANCEL_QUERY_TIMEOUT.getDefaultValue()), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverBooleanProperty.USE_BULK_COPY_FOR_BATCH_INSERT
/* 625 */         .toString(), 
/* 626 */         Boolean.toString(SQLServerDriverBooleanProperty.USE_BULK_COPY_FOR_BATCH_INSERT.getDefaultValue()), false, TRUE_FALSE), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.MSI_CLIENT_ID
/*     */         
/* 628 */         .toString(), SQLServerDriverStringProperty.MSI_CLIENT_ID
/* 629 */         .getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.KEY_VAULT_PROVIDER_CLIENT_ID
/* 630 */         .toString(), SQLServerDriverStringProperty.KEY_VAULT_PROVIDER_CLIENT_ID
/* 631 */         .getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.KEY_VAULT_PROVIDER_CLIENT_KEY
/* 632 */         .toString(), SQLServerDriverStringProperty.KEY_VAULT_PROVIDER_CLIENT_KEY
/* 633 */         .getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverBooleanProperty.USE_FMT_ONLY
/* 634 */         .toString(), 
/* 635 */         Boolean.toString(SQLServerDriverBooleanProperty.USE_FMT_ONLY.getDefaultValue()), false, TRUE_FALSE), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.KEY_STORE_PRINCIPAL_ID
/* 636 */         .toString(), SQLServerDriverStringProperty.KEY_STORE_PRINCIPAL_ID
/* 637 */         .getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.CLIENT_CERTIFICATE
/* 638 */         .toString(), SQLServerDriverStringProperty.CLIENT_CERTIFICATE
/* 639 */         .getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.CLIENT_KEY
/* 640 */         .toString(), SQLServerDriverStringProperty.CLIENT_KEY
/* 641 */         .getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.CLIENT_KEY_PASSWORD
/* 642 */         .toString(), SQLServerDriverStringProperty.CLIENT_KEY_PASSWORD
/* 643 */         .getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverBooleanProperty.DELAY_LOADING_LOBS
/* 644 */         .toString(), 
/* 645 */         Boolean.toString(SQLServerDriverBooleanProperty.DELAY_LOADING_LOBS.getDefaultValue()), false, TRUE_FALSE), new SQLServerDriverPropertyInfo(SQLServerDriverBooleanProperty.SEND_TEMPORAL_DATATYPES_AS_STRING_FOR_BULK_COPY
/*     */ 
/*     */         
/* 648 */         .toString(), 
/* 649 */         Boolean.toString(SQLServerDriverBooleanProperty.SEND_TEMPORAL_DATATYPES_AS_STRING_FOR_BULK_COPY
/* 650 */           .getDefaultValue()), false, TRUE_FALSE), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.AAD_SECURE_PRINCIPAL_ID
/*     */         
/* 652 */         .toString(), SQLServerDriverStringProperty.AAD_SECURE_PRINCIPAL_ID
/* 653 */         .getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.AAD_SECURE_PRINCIPAL_SECRET
/* 654 */         .toString(), SQLServerDriverStringProperty.AAD_SECURE_PRINCIPAL_SECRET
/* 655 */         .getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.MAX_RESULT_BUFFER
/* 656 */         .toString(), SQLServerDriverStringProperty.MAX_RESULT_BUFFER
/* 657 */         .getDefaultValue(), false, null) };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 662 */   private static final SQLServerDriverPropertyInfo[] DRIVER_PROPERTIES_PROPERTY_ONLY = new SQLServerDriverPropertyInfo[] { new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.ACCESS_TOKEN
/*     */ 
/*     */         
/* 665 */         .toString(), SQLServerDriverStringProperty.ACCESS_TOKEN
/* 666 */         .getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverObjectProperty.GSS_CREDENTIAL
/* 667 */         .toString(), SQLServerDriverObjectProperty.GSS_CREDENTIAL
/* 668 */         .getDefaultValue(), false, null) };
/*     */   
/* 670 */   private static final String[][] driverPropertiesSynonyms = new String[][] { { "database", SQLServerDriverStringProperty.DATABASE_NAME
/* 671 */         .toString() }, { "userName", SQLServerDriverStringProperty.USER
/* 672 */         .toString() }, { "server", SQLServerDriverStringProperty.SERVER_NAME
/* 673 */         .toString() }, { "domainName", SQLServerDriverStringProperty.DOMAIN
/* 674 */         .toString() }, { "port", SQLServerDriverIntProperty.PORT_NUMBER
/* 675 */         .toString() } };
/* 676 */   private static final AtomicInteger baseID = new AtomicInteger(0);
/*     */   
/*     */   private final int instanceID;
/*     */   
/*     */   private final String traceID;
/*     */   
/*     */   private static int nextInstanceID() {
/* 683 */     return baseID.incrementAndGet();
/*     */   }
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 688 */     return this.traceID;
/*     */   }
/*     */ 
/*     */   
/* 692 */   private static final Logger loggerExternal = Logger.getLogger("com.microsoft.sqlserver.jdbc.Driver");
/*     */   
/* 694 */   private static final Logger parentLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc");
/*     */   private final String loggingClassName;
/*     */   
/*     */   String getClassNameLogging() {
/* 698 */     return this.loggingClassName;
/*     */   }
/*     */ 
/*     */   
/* 702 */   private static final Logger drLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerDriver");
/* 703 */   private static Driver mssqlDriver = null;
/*     */   
/*     */   static {
/*     */     try {
/* 707 */       register();
/* 708 */     } catch (SQLException e) {
/* 709 */       if (drLogger.isLoggable(Level.FINER) && Util.isActivityTraceOn()) {
/* 710 */         drLogger.finer("Error registering driver: " + e);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void register() throws SQLException {
/* 719 */     if (!isRegistered()) {
/* 720 */       mssqlDriver = new SQLServerDriver();
/* 721 */       DriverManager.registerDriver(mssqlDriver);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void deregister() throws SQLException {
/* 729 */     if (isRegistered()) {
/* 730 */       DriverManager.deregisterDriver(mssqlDriver);
/* 731 */       mssqlDriver = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isRegistered() {
/* 739 */     return (mssqlDriver != null);
/*     */   }
/*     */   
/*     */   public SQLServerDriver() {
/* 743 */     this.instanceID = nextInstanceID();
/* 744 */     this.traceID = "SQLServerDriver:" + this.instanceID;
/* 745 */     this.loggingClassName = "com.microsoft.sqlserver.jdbc.SQLServerDriver:" + this.instanceID;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Properties fixupProperties(Properties props) throws SQLServerException {
/* 754 */     Properties fixedup = new Properties();
/* 755 */     Enumeration<?> e = props.keys();
/* 756 */     while (e.hasMoreElements()) {
/* 757 */       String name = (String)e.nextElement();
/* 758 */       String newname = getNormalizedPropertyName(name, drLogger);
/*     */       
/* 760 */       if (null == newname) {
/* 761 */         newname = getPropertyOnlyName(name, drLogger);
/*     */       }
/*     */       
/* 764 */       if (null != newname) {
/* 765 */         String val = props.getProperty(name);
/* 766 */         if (null != val) {
/*     */           
/* 768 */           fixedup.setProperty(newname, val); continue;
/* 769 */         }  if ("gsscredential".equalsIgnoreCase(newname) && props.get(name) instanceof org.ietf.jgss.GSSCredential) {
/* 770 */           fixedup.put(newname, props.get(name)); continue;
/*     */         } 
/* 772 */         MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidpropertyValue"));
/* 773 */         Object[] msgArgs = { name };
/* 774 */         throw new SQLServerException(null, form.format(msgArgs), null, 0, false);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 779 */     return fixedup;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Properties mergeURLAndSuppliedProperties(Properties urlProps, Properties suppliedProperties) throws SQLServerException {
/* 789 */     if (null == suppliedProperties)
/* 790 */       return urlProps; 
/* 791 */     if (suppliedProperties.isEmpty())
/* 792 */       return urlProps; 
/* 793 */     Properties suppliedPropertiesFixed = fixupProperties(suppliedProperties);
/*     */     
/* 795 */     for (SQLServerDriverPropertyInfo DRIVER_PROPERTY : DRIVER_PROPERTIES) {
/* 796 */       String sProp = DRIVER_PROPERTY.getName();
/* 797 */       String sPropVal = suppliedPropertiesFixed.getProperty(sProp);
/* 798 */       if (null != sPropVal)
/*     */       {
/* 800 */         urlProps.put(sProp, sPropVal);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 805 */     for (SQLServerDriverPropertyInfo aDRIVER_PROPERTIES_PROPERTY_ONLY : DRIVER_PROPERTIES_PROPERTY_ONLY) {
/* 806 */       String sProp = aDRIVER_PROPERTIES_PROPERTY_ONLY.getName();
/* 807 */       Object oPropVal = suppliedPropertiesFixed.get(sProp);
/* 808 */       if (null != oPropVal)
/*     */       {
/* 810 */         urlProps.put(sProp, oPropVal);
/*     */       }
/*     */     } 
/*     */     
/* 814 */     return urlProps;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String getNormalizedPropertyName(String name, Logger logger) {
/* 826 */     if (null == name) {
/* 827 */       return name;
/*     */     }
/* 829 */     for (String[] driverPropertiesSynonym : driverPropertiesSynonyms) {
/* 830 */       if (driverPropertiesSynonym[0].equalsIgnoreCase(name)) {
/* 831 */         return driverPropertiesSynonym[1];
/*     */       }
/*     */     } 
/* 834 */     for (SQLServerDriverPropertyInfo DRIVER_PROPERTY : DRIVER_PROPERTIES) {
/* 835 */       if (DRIVER_PROPERTY.getName().equalsIgnoreCase(name)) {
/* 836 */         return DRIVER_PROPERTY.getName();
/*     */       }
/*     */     } 
/*     */     
/* 840 */     if (logger.isLoggable(Level.FINER))
/* 841 */       logger.finer("Unknown property" + name); 
/* 842 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String getPropertyOnlyName(String name, Logger logger) {
/* 854 */     if (null == name) {
/* 855 */       return name;
/*     */     }
/* 857 */     for (SQLServerDriverPropertyInfo aDRIVER_PROPERTIES_PROPERTY_ONLY : DRIVER_PROPERTIES_PROPERTY_ONLY) {
/* 858 */       if (aDRIVER_PROPERTIES_PROPERTY_ONLY.getName().equalsIgnoreCase(name)) {
/* 859 */         return aDRIVER_PROPERTIES_PROPERTY_ONLY.getName();
/*     */       }
/*     */     } 
/*     */     
/* 863 */     if (logger.isLoggable(Level.FINER))
/* 864 */       logger.finer("Unknown property" + name); 
/* 865 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Connection connect(String Url, Properties suppliedProperties) throws SQLServerException {
/* 870 */     loggerExternal.entering(getClassNameLogging(), "connect", "Arguments not traced.");
/* 871 */     SQLServerConnection result = null;
/*     */ 
/*     */     
/* 874 */     Properties connectProperties = parseAndMergeProperties(Url, suppliedProperties);
/* 875 */     if (connectProperties != null) {
/* 876 */       if (Util.use43Wrapper()) {
/* 877 */         result = new SQLServerConnection43(toString());
/*     */       } else {
/* 879 */         result = new SQLServerConnection(toString());
/*     */       } 
/* 881 */       result.connect(connectProperties, null);
/*     */     } 
/* 883 */     loggerExternal.exiting(getClassNameLogging(), "connect", result);
/* 884 */     return result;
/*     */   }
/*     */   
/*     */   private Properties parseAndMergeProperties(String Url, Properties suppliedProperties) throws SQLServerException {
/* 888 */     if (Url == null) {
/* 889 */       throw new SQLServerException(null, SQLServerException.getErrString("R_nullConnection"), null, 0, false);
/*     */     }
/*     */ 
/*     */     
/* 893 */     Properties connectProperties = Util.parseUrl(Url, drLogger);
/* 894 */     if (null == connectProperties) {
/* 895 */       return null;
/*     */     }
/* 897 */     String loginTimeoutProp = connectProperties.getProperty(SQLServerDriverIntProperty.LOGIN_TIMEOUT.toString());
/* 898 */     int dmLoginTimeout = DriverManager.getLoginTimeout();
/*     */ 
/*     */     
/* 901 */     if (dmLoginTimeout > 0 && null == loginTimeoutProp) {
/* 902 */       connectProperties.setProperty(SQLServerDriverIntProperty.LOGIN_TIMEOUT.toString(), 
/* 903 */           String.valueOf(dmLoginTimeout));
/*     */     }
/*     */ 
/*     */     
/* 907 */     connectProperties = mergeURLAndSuppliedProperties(connectProperties, suppliedProperties);
/*     */     
/* 909 */     return connectProperties;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean acceptsURL(String url) throws SQLServerException {
/* 914 */     loggerExternal.entering(getClassNameLogging(), "acceptsURL", "Arguments not traced.");
/*     */     
/* 916 */     if (null == url) {
/* 917 */       throw new SQLServerException(null, SQLServerException.getErrString("R_nullConnection"), null, 0, false);
/*     */     }
/*     */     
/* 920 */     boolean result = false;
/*     */     try {
/* 922 */       result = (Util.parseUrl(url, drLogger) != null);
/* 923 */     } catch (SQLServerException e) {
/*     */       
/* 925 */       result = false;
/*     */     } 
/* 927 */     loggerExternal.exiting(getClassNameLogging(), "acceptsURL", Boolean.valueOf(result));
/* 928 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public DriverPropertyInfo[] getPropertyInfo(String Url, Properties Info) throws SQLServerException {
/* 933 */     loggerExternal.entering(getClassNameLogging(), "getPropertyInfo", "Arguments not traced.");
/*     */     
/* 935 */     Properties connProperties = parseAndMergeProperties(Url, Info);
/*     */     
/* 937 */     if (null == connProperties)
/* 938 */       throw new SQLServerException(null, SQLServerException.getErrString("R_invalidConnection"), null, 0, false); 
/* 939 */     DriverPropertyInfo[] properties = getPropertyInfoFromProperties(connProperties);
/* 940 */     loggerExternal.exiting(getClassNameLogging(), "getPropertyInfo");
/*     */     
/* 942 */     return properties;
/*     */   }
/*     */   
/*     */   static final DriverPropertyInfo[] getPropertyInfoFromProperties(Properties props) {
/* 946 */     DriverPropertyInfo[] properties = new DriverPropertyInfo[DRIVER_PROPERTIES.length];
/*     */     
/* 948 */     for (int i = 0; i < DRIVER_PROPERTIES.length; i++)
/* 949 */       properties[i] = DRIVER_PROPERTIES[i].build(props); 
/* 950 */     return properties;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getMajorVersion() {
/* 955 */     loggerExternal.entering(getClassNameLogging(), "getMajorVersion");
/* 956 */     loggerExternal.exiting(getClassNameLogging(), "getMajorVersion", Integer.valueOf(9));
/* 957 */     return 9;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getMinorVersion() {
/* 962 */     loggerExternal.entering(getClassNameLogging(), "getMinorVersion");
/* 963 */     loggerExternal.exiting(getClassNameLogging(), "getMinorVersion", Integer.valueOf(2));
/* 964 */     return 2;
/*     */   }
/*     */ 
/*     */   
/*     */   public Logger getParentLogger() {
/* 969 */     return parentLogger;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean jdbcCompliant() {
/* 974 */     loggerExternal.entering(getClassNameLogging(), "jdbcCompliant");
/* 975 */     loggerExternal.exiting(getClassNameLogging(), "jdbcCompliant", Boolean.TRUE);
/* 976 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerDriver.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */