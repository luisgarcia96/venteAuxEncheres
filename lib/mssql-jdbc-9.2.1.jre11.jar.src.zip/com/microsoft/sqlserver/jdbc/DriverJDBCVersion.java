/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import java.sql.BatchUpdateException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class DriverJDBCVersion
/*    */ {
/*    */   static final int major = 4;
/*    */   static final int minor = 3;
/*    */   
/*    */   static final void checkSupportsJDBC43() {}
/*    */   
/*    */   static final void throwBatchUpdateException(SQLServerException lastError, long[] updateCounts) throws BatchUpdateException {
/* 29 */     throw new BatchUpdateException(lastError.getMessage(), lastError.getSQLState(), lastError.getErrorCode(), updateCounts, new Throwable(lastError
/* 30 */           .getMessage()));
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\DriverJDBCVersion.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */