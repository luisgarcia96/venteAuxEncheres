/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.sql.ParameterMetaData;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.sql.SQLException;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SQLServerParameterMetaData
/*     */   implements ParameterMetaData
/*     */ {
/*     */   private static final int SQL_SERVER_2012_VERSION = 11;
/*     */   private final SQLServerPreparedStatement stmtParent;
/*     */   private SQLServerConnection con;
/*     */   private List<Map<String, Object>> procMetadata;
/*     */   protected boolean procedureIsFound = false;
/*  44 */   private static final Logger logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerParameterMetaData");
/*     */   
/*  46 */   private static final AtomicInteger baseID = new AtomicInteger(0);
/*     */   
/*  48 */   private final String traceID = " SQLServerParameterMetaData:" + nextInstanceID();
/*     */   
/*     */   boolean isTVP = false;
/*     */   
/*     */   private static int nextInstanceID() {
/*  53 */     return baseID.incrementAndGet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString() {
/*  63 */     return this.traceID;
/*     */   }
/*     */   
/*     */   class QueryMeta
/*     */   {
/*  68 */     String parameterClassName = null;
/*  69 */     int parameterType = 0;
/*  70 */     String parameterTypeName = null;
/*  71 */     int precision = 0;
/*  72 */     int scale = 0;
/*  73 */     int isNullable = 2;
/*     */     
/*     */     boolean isSigned = false;
/*     */   }
/*  77 */   Map<Integer, QueryMeta> queryMetaMap = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseQueryMeta(ResultSet rsQueryMeta) throws SQLServerException {
/*  83 */     Pattern datatypePattern = Pattern.compile("(.*)\\((.*)(\\)|,(.*)\\))");
/*     */     try {
/*  85 */       if (null != rsQueryMeta) {
/*  86 */         while (rsQueryMeta.next()) {
/*  87 */           QueryMeta qm = new QueryMeta();
/*  88 */           SSType ssType = null;
/*     */           
/*  90 */           int paramOrdinal = rsQueryMeta.getInt("parameter_ordinal");
/*  91 */           String typename = rsQueryMeta.getString("suggested_system_type_name");
/*     */           
/*  93 */           if (null == typename)
/*  94 */           { typename = rsQueryMeta.getString("suggested_user_type_name");
/*  95 */             SQLServerPreparedStatement pstmt = (SQLServerPreparedStatement)this.con.prepareStatement("select max_length, precision, scale, is_nullable from sys.assembly_types where name = ?");
/*     */             
/*  97 */             try { pstmt.setNString(1, typename);
/*  98 */               ResultSet assemblyRs = pstmt.executeQuery(); 
/*  99 */               try { if (assemblyRs.next()) {
/* 100 */                   qm.parameterTypeName = typename;
/* 101 */                   qm.precision = assemblyRs.getInt("max_length");
/* 102 */                   qm.scale = assemblyRs.getInt("scale");
/* 103 */                   ssType = SSType.UDT;
/*     */                 } 
/* 105 */                 if (assemblyRs != null) assemblyRs.close();  } catch (Throwable throwable) { if (assemblyRs != null)
/* 106 */                   try { assemblyRs.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  if (pstmt != null) pstmt.close();  } catch (Throwable throwable) { if (pstmt != null)
/*     */                 try { pstmt.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  }
/* 108 */           else { qm.precision = rsQueryMeta.getInt("suggested_precision");
/* 109 */             qm.scale = rsQueryMeta.getInt("suggested_scale");
/*     */             
/* 111 */             Matcher matcher = datatypePattern.matcher(typename);
/* 112 */             if (matcher.matches()) {
/*     */               
/* 114 */               ssType = SSType.of(matcher.group(1));
/* 115 */               if ("varchar(max)".equalsIgnoreCase(typename) || "varbinary(max)"
/* 116 */                 .equalsIgnoreCase(typename)) {
/* 117 */                 qm.precision = Integer.MAX_VALUE;
/* 118 */               } else if ("nvarchar(max)".equalsIgnoreCase(typename)) {
/* 119 */                 qm.precision = 1073741823;
/* 120 */               } else if (SSType.Category.CHARACTER == ssType.category || SSType.Category.BINARY == ssType.category || SSType.Category.NCHARACTER == ssType.category) {
/*     */ 
/*     */                 
/*     */                 try {
/*     */ 
/*     */ 
/*     */                   
/* 127 */                   qm.precision = Integer.parseInt(matcher.group(2));
/* 128 */                 } catch (NumberFormatException e) {
/*     */                   
/* 130 */                   MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_metaDataErrorForParameter"));
/* 131 */                   Object[] msgArgs = { Integer.valueOf(paramOrdinal) };
/* 132 */                   SQLServerException.makeFromDriverError(this.con, this.stmtParent, form
/* 133 */                       .format(msgArgs) + " " + form.format(msgArgs), (String)null, false);
/*     */                 } 
/*     */               } 
/*     */             } else {
/* 137 */               ssType = SSType.of(typename);
/*     */             } 
/*     */             
/* 140 */             if (SSType.FLOAT == ssType) {
/*     */ 
/*     */               
/* 143 */               qm.precision = 15;
/* 144 */             } else if (SSType.REAL == ssType) {
/* 145 */               qm.precision = 7;
/* 146 */             } else if (SSType.TEXT == ssType) {
/* 147 */               qm.precision = Integer.MAX_VALUE;
/* 148 */             } else if (SSType.NTEXT == ssType) {
/* 149 */               qm.precision = 1073741823;
/* 150 */             } else if (SSType.IMAGE == ssType) {
/* 151 */               qm.precision = Integer.MAX_VALUE;
/* 152 */             } else if (SSType.GUID == ssType) {
/* 153 */               qm.precision = 36;
/* 154 */             } else if (SSType.TIMESTAMP == ssType) {
/* 155 */               qm.precision = 8;
/* 156 */             } else if (SSType.XML == ssType) {
/* 157 */               qm.precision = 1073741823;
/*     */             } 
/*     */             
/* 160 */             qm.parameterTypeName = ssType.toString(); }
/*     */ 
/*     */ 
/*     */           
/* 164 */           if (null == ssType) {
/* 165 */             throw new SQLServerException(SQLServerException.getErrString("R_metaDataErrorForParameter"), null);
/*     */           }
/*     */ 
/*     */           
/* 169 */           JDBCType jdbcType = ssType.getJDBCType();
/* 170 */           qm.parameterClassName = jdbcType.className();
/* 171 */           qm.parameterType = jdbcType.getIntValue();
/*     */           
/* 173 */           qm.isSigned = (SSType.Category.NUMERIC == ssType.category && SSType.BIT != ssType && SSType.TINYINT != ssType);
/*     */           
/* 175 */           this.queryMetaMap.put(Integer.valueOf(paramOrdinal), qm);
/*     */         } 
/*     */       }
/* 178 */     } catch (SQLException e) {
/* 179 */       throw new SQLServerException(SQLServerException.getErrString("R_metaDataErrorForParameter"), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void parseFMTQueryMeta(ResultSetMetaData md, SQLServerFMTQuery f) throws SQLServerException {
/*     */     try {
/* 186 */       List<String> columns = f.getColumns();
/*     */       
/* 188 */       List<List<String>> params = f.getValuesList();
/* 189 */       int valueListOffset = 0;
/* 190 */       int mdIndex = 1;
/* 191 */       int mapIndex = 1;
/* 192 */       for (int i = 0; i < columns.size(); i++) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 199 */         if ("*".equals(columns.get(i))) {
/* 200 */           for (int j = 0; j < ((List)params.get(valueListOffset)).size(); j++) {
/* 201 */             if ("?".equals(((List)params.get(valueListOffset)).get(j)) && 
/* 202 */               !md.isAutoIncrement(mdIndex + j)) {
/* 203 */               QueryMeta qm = getQueryMetaFromResultSetMetaData(md, mdIndex + j);
/* 204 */               this.queryMetaMap.put(Integer.valueOf(mapIndex++), qm);
/* 205 */               i++;
/*     */             } 
/*     */           } 
/*     */           
/* 209 */           mdIndex += ((List)params.get(valueListOffset)).size();
/* 210 */           valueListOffset++;
/*     */         
/*     */         }
/*     */         else {
/*     */           
/* 215 */           QueryMeta qm = getQueryMetaFromResultSetMetaData(md, mdIndex);
/* 216 */           this.queryMetaMap.put(Integer.valueOf(mapIndex++), qm);
/* 217 */           mdIndex++;
/*     */         } 
/*     */       } 
/* 220 */     } catch (SQLException e) {
/* 221 */       throw new SQLServerException(SQLServerException.getErrString("R_metaDataErrorForParameter"), e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private QueryMeta getQueryMetaFromResultSetMetaData(ResultSetMetaData md, int index) throws SQLException {
/* 226 */     QueryMeta qm = new QueryMeta();
/* 227 */     qm.parameterClassName = md.getColumnClassName(index);
/* 228 */     qm.parameterType = md.getColumnType(index);
/* 229 */     qm.parameterTypeName = md.getColumnTypeName(index);
/* 230 */     qm.precision = md.getPrecision(index);
/* 231 */     qm.scale = md.getScale(index);
/* 232 */     qm.isNullable = md.isNullable(index);
/* 233 */     qm.isSigned = md.isSigned(index);
/* 234 */     return qm;
/*     */   }
/*     */   
/*     */   String parseProcIdentifier(String procIdentifier) throws SQLServerException {
/* 238 */     ThreePartName threePartName = ThreePartName.parse(procIdentifier);
/* 239 */     StringBuilder sb = new StringBuilder();
/* 240 */     if (threePartName.getDatabasePart() != null) {
/* 241 */       sb.append("@procedure_qualifier=");
/* 242 */       sb.append(threePartName.getDatabasePart());
/* 243 */       sb.append(", ");
/*     */     } 
/* 245 */     if (threePartName.getOwnerPart() != null) {
/* 246 */       sb.append("@procedure_owner=");
/* 247 */       sb.append(threePartName.getOwnerPart());
/* 248 */       sb.append(", ");
/*     */     } 
/* 250 */     if (threePartName.getProcedurePart() != null) {
/* 251 */       sb.append("@procedure_name=");
/* 252 */       sb.append(threePartName.getProcedurePart());
/*     */     } else {
/* 254 */       SQLServerException.makeFromDriverError(this.con, this.stmtParent, SQLServerException.getErrString("R_noMetadata"), (String)null, false);
/*     */     } 
/*     */     
/* 257 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkClosed() throws SQLServerException {
/* 263 */     this.con.checkClosed();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SQLServerParameterMetaData(SQLServerPreparedStatement st, String sProcString) throws SQLServerException {
/* 277 */     assert null != st;
/* 278 */     this.stmtParent = st;
/* 279 */     this.con = st.connection;
/* 280 */     if (logger.isLoggable(Level.FINE)) {
/* 281 */       logger.fine(toString() + " created by (" + toString() + ")");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 287 */       if (null != st.procedureName) {
/* 288 */         String sProc = parseProcIdentifier(st.procedureName);
/* 289 */         SQLServerStatement s = (SQLServerStatement)this.con.createStatement(1004, 1007);
/*     */         
/* 291 */         try { final SQLServerResultSet rsProcedureMeta = s.executeQueryInternal(
/* 292 */               this.con.isKatmaiOrLater() ? ("exec sp_sproc_columns_100 " + sProc + ", @ODBCVer=3, @fUsePattern=0") : ("exec sp_sproc_columns " + 
/* 293 */               sProc + ", @ODBCVer=3, @fUsePattern=0"));
/*     */ 
/*     */           
/* 296 */           try { if (rsProcedureMeta.next()) {
/* 297 */               this.procedureIsFound = true;
/*     */             } else {
/* 299 */               this.procedureIsFound = false;
/*     */             } 
/*     */             
/* 302 */             rsProcedureMeta.beforeFirst();
/*     */ 
/*     */             
/* 305 */             rsProcedureMeta.getColumn(6).setFilter(new DataTypeFilter());
/* 306 */             if (this.con.isKatmaiOrLater()) {
/* 307 */               rsProcedureMeta.getColumn(8).setFilter(new ZeroFixupFilter());
/* 308 */               rsProcedureMeta.getColumn(9).setFilter(new ZeroFixupFilter());
/* 309 */               rsProcedureMeta.getColumn(17).setFilter(new ZeroFixupFilter());
/*     */             } 
/*     */             
/* 312 */             this.procMetadata = new ArrayList<>();
/*     */ 
/*     */             
/* 315 */             while (rsProcedureMeta.next()) {
/* 316 */               this.procMetadata.add(new HashMap<String, Object>()
/*     */                   {
/*     */                   
/*     */                   });
/*     */             } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 328 */             if (rsProcedureMeta != null) rsProcedureMeta.close();  } catch (Throwable throwable) { if (rsProcedureMeta != null) try { rsProcedureMeta.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  if (s != null) s.close();  }
/*     */         catch (Throwable throwable) { if (s != null)
/*     */             try { s.close(); }
/*     */             catch (Throwable throwable1)
/*     */             { throwable.addSuppressed(throwable1); }
/*     */               throw throwable; }
/*     */       
/*     */       } else {
/* 336 */         this.queryMetaMap = new HashMap<>();
/* 337 */         if (this.con.getServerMajorVersion() >= 11 && !st.getUseFmtOnly())
/* 338 */         { String preparedSQL = this.con.replaceParameterMarkers(this.stmtParent.userSQL, this.stmtParent.userSQLParamPositions, this.stmtParent.inOutParam, this.stmtParent.bReturnValueSyntax);
/*     */ 
/*     */ 
/*     */           
/* 342 */           SQLServerCallableStatement cstmt = (SQLServerCallableStatement)this.con.prepareCall("exec sp_describe_undeclared_parameters ?"); 
/* 343 */           try { cstmt.setNString(1, preparedSQL);
/* 344 */             parseQueryMeta(cstmt.executeQueryInternal());
/* 345 */             if (cstmt != null) cstmt.close();  } catch (Throwable throwable) { if (cstmt != null)
/*     */               try { cstmt.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  }
/* 347 */         else { SQLServerFMTQuery f = new SQLServerFMTQuery(sProcString);
/* 348 */           SQLServerStatement stmt = (SQLServerStatement)this.con.createStatement(); 
/* 349 */           try { ResultSet rs = stmt.executeQuery(f.getFMTQuery()); 
/* 350 */             try { parseFMTQueryMeta(rs.getMetaData(), f);
/* 351 */               if (rs != null) rs.close();  } catch (Throwable throwable) { if (rs != null) try { rs.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  if (stmt != null) stmt.close();  } catch (Throwable throwable) { if (stmt != null)
/*     */               try { stmt.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }
/*     */            }
/*     */       
/*     */       } 
/* 356 */     } catch (SQLServerException e) {
/* 357 */       throw e;
/* 358 */     } catch (SQLException e) {
/* 359 */       SQLServerException.makeFromDriverError(this.con, this.stmtParent, e.getMessage(), (String)null, false);
/* 360 */     } catch (StringIndexOutOfBoundsException e) {
/* 361 */       SQLServerException.makeFromDriverError(this.con, this.stmtParent, e.getMessage(), (String)null, false);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isWrapperFor(Class<?> iface) throws SQLException {
/* 367 */     boolean f = iface.isInstance(this);
/* 368 */     return f;
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T unwrap(Class<T> iface) throws SQLException {
/*     */     T t;
/*     */     try {
/* 375 */       t = iface.cast(this);
/* 376 */     } catch (ClassCastException e) {
/* 377 */       throw new SQLServerException(e.getMessage(), e);
/*     */     } 
/* 379 */     return t;
/*     */   }
/*     */   
/*     */   private Map<String, Object> getParameterInfo(int param) {
/* 383 */     if (this.stmtParent.bReturnValueSyntax && this.isTVP) {
/* 384 */       return this.procMetadata.get(param - 1);
/*     */     }
/*     */     
/* 387 */     return this.procMetadata.get(param);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isValidParamProc(int n) {
/* 393 */     return ((this.stmtParent.bReturnValueSyntax && this.isTVP && this.procMetadata.size() >= n) || this.procMetadata.size() > n);
/*     */   }
/*     */   
/*     */   private boolean isValidParamQuery(int n) {
/* 397 */     return (null != this.queryMetaMap && this.queryMetaMap.containsKey(Integer.valueOf(n)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkParam(int param) throws SQLServerException {
/* 408 */     if (null == this.procMetadata) {
/*     */       
/* 410 */       if (!isValidParamQuery(param)) {
/* 411 */         SQLServerException.makeFromDriverError(this.con, this.stmtParent, SQLServerException.getErrString("R_noMetadata"), (String)null, false);
/*     */       }
/*     */     }
/* 414 */     else if (!isValidParamProc(param)) {
/*     */       
/* 416 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidParameterNumber"));
/* 417 */       Object[] msgArgs = { Integer.valueOf(param) };
/* 418 */       SQLServerException.makeFromDriverError(this.con, this.stmtParent, form.format(msgArgs), (String)null, false);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getParameterClassName(int param) throws SQLServerException {
/* 424 */     checkClosed();
/* 425 */     checkParam(param);
/*     */     try {
/* 427 */       if (null == this.procMetadata) {
/* 428 */         return ((QueryMeta)this.queryMetaMap.get(Integer.valueOf(param))).parameterClassName;
/*     */       }
/* 430 */       return JDBCType.of(((Short)getParameterInfo(param).get("DATA_TYPE")).shortValue()).className();
/*     */     }
/* 432 */     catch (SQLServerException e) {
/* 433 */       SQLServerException.makeFromDriverError(this.con, this.stmtParent, e.getMessage(), (String)null, false);
/* 434 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getParameterCount() throws SQLServerException {
/* 440 */     checkClosed();
/* 441 */     if (null == this.procMetadata) {
/* 442 */       return this.queryMetaMap.size();
/*     */     }
/*     */     
/* 445 */     return (this.procMetadata.size() == 0) ? 0 : (this.procMetadata.size() - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getParameterMode(int param) throws SQLServerException {
/* 451 */     checkClosed();
/* 452 */     checkParam(param);
/* 453 */     if (null == this.procMetadata)
/*     */     {
/* 455 */       return 1;
/*     */     }
/* 457 */     int n = ((Integer)getParameterInfo(param).get("COLUMN_TYPE")).intValue();
/* 458 */     if (n == 1)
/* 459 */       return 1; 
/* 460 */     if (n == 2) {
/* 461 */       return 4;
/*     */     }
/* 463 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getParameterType(int param) throws SQLServerException {
/* 469 */     checkClosed();
/* 470 */     checkParam(param);
/* 471 */     int parameterType = 0;
/* 472 */     if (null == this.procMetadata) {
/* 473 */       parameterType = ((QueryMeta)this.queryMetaMap.get(Integer.valueOf(param))).parameterType;
/*     */     } else {
/* 475 */       parameterType = ((Short)getParameterInfo(param).get("DATA_TYPE")).shortValue();
/*     */     } 
/* 477 */     if (0 != parameterType) {
/* 478 */       switch (parameterType) {
/*     */         case -151:
/*     */         case -150:
/* 481 */           parameterType = SSType.DATETIME2.getJDBCType().asJavaSqlType();
/*     */           break;
/*     */         case -148:
/*     */         case -146:
/* 485 */           parameterType = SSType.DECIMAL.getJDBCType().asJavaSqlType();
/*     */           break;
/*     */         case -145:
/* 488 */           parameterType = SSType.CHAR.getJDBCType().asJavaSqlType();
/*     */           break;
/*     */       } 
/*     */ 
/*     */     
/*     */     }
/* 494 */     return parameterType;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getParameterTypeName(int param) throws SQLServerException {
/* 499 */     checkClosed();
/* 500 */     checkParam(param);
/* 501 */     if (null == this.procMetadata) {
/* 502 */       return ((QueryMeta)this.queryMetaMap.get(Integer.valueOf(param))).parameterTypeName;
/*     */     }
/* 504 */     return getParameterInfo(param).get("TYPE_NAME").toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPrecision(int param) throws SQLServerException {
/* 510 */     checkClosed();
/* 511 */     checkParam(param);
/* 512 */     if (null == this.procMetadata) {
/* 513 */       return ((QueryMeta)this.queryMetaMap.get(Integer.valueOf(param))).precision;
/*     */     }
/* 515 */     return ((Integer)getParameterInfo(param).get("PRECISION")).intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getScale(int param) throws SQLServerException {
/* 521 */     checkClosed();
/* 522 */     checkParam(param);
/* 523 */     if (null == this.procMetadata) {
/* 524 */       return ((QueryMeta)this.queryMetaMap.get(Integer.valueOf(param))).scale;
/*     */     }
/* 526 */     return ((Integer)getParameterInfo(param).get("SCALE")).intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int isNullable(int param) throws SQLServerException {
/* 532 */     checkClosed();
/* 533 */     checkParam(param);
/* 534 */     if (this.procMetadata == null) {
/* 535 */       return ((QueryMeta)this.queryMetaMap.get(Integer.valueOf(param))).isNullable;
/*     */     }
/* 537 */     return ((Integer)getParameterInfo(param).get("NULLABLE")).intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSigned(int param) throws SQLServerException {
/* 552 */     checkClosed();
/* 553 */     checkParam(param);
/*     */     try {
/* 555 */       if (null == this.procMetadata) {
/* 556 */         return ((QueryMeta)this.queryMetaMap.get(Integer.valueOf(param))).isSigned;
/*     */       }
/* 558 */       return JDBCType.of(((Short)getParameterInfo(param).get("DATA_TYPE")).shortValue()).isSigned();
/*     */     }
/* 560 */     catch (SQLException e) {
/* 561 */       SQLServerException.makeFromDriverError(this.con, this.stmtParent, e.getMessage(), (String)null, false);
/* 562 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   String getTVPSchemaFromStoredProcedure(int param) throws SQLServerException {
/* 567 */     checkClosed();
/* 568 */     checkParam(param);
/* 569 */     return (String)getParameterInfo(param).get("SS_TYPE_SCHEMA_NAME");
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerParameterMetaData.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */