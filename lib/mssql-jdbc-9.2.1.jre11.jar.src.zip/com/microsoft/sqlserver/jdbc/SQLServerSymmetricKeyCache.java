/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Base64;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SQLServerSymmetricKeyCache
/*     */ {
/*  54 */   static final Object lock = new Object();
/*     */   private final ConcurrentHashMap<String, SQLServerSymmetricKey> cache;
/*  56 */   private static final SQLServerSymmetricKeyCache instance = new SQLServerSymmetricKeyCache();
/*  57 */   private static ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1, new ThreadFactory()
/*     */       {
/*     */         public Thread newThread(Runnable r) {
/*  60 */           Thread t = Executors.defaultThreadFactory().newThread(r);
/*  61 */           t.setDaemon(true);
/*  62 */           return t;
/*     */         }
/*     */       });
/*     */ 
/*     */   
/*  67 */   private static final Logger aeLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.SQLServerSymmetricKeyCache");
/*     */   
/*     */   private SQLServerSymmetricKeyCache() {
/*  70 */     this.cache = new ConcurrentHashMap<>();
/*     */   }
/*     */   
/*     */   static SQLServerSymmetricKeyCache getInstance() {
/*  74 */     return instance;
/*     */   }
/*     */   
/*     */   ConcurrentHashMap<String, SQLServerSymmetricKey> getCache() {
/*  78 */     return this.cache;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SQLServerSymmetricKey getKey(EncryptionKeyInfo keyInfo, SQLServerConnection connection) throws SQLServerException {
/*  90 */     SQLServerSymmetricKey encryptionKey = null;
/*  91 */     synchronized (lock) {
/*  92 */       String serverName = connection.getTrustedServerNameAE();
/*  93 */       assert null != serverName : "serverName should not be null in getKey.";
/*     */       
/*  95 */       StringBuilder keyLookupValuebuffer = new StringBuilder(serverName);
/*     */       
/*  97 */       keyLookupValuebuffer.append(":");
/*     */       
/*  99 */       keyLookupValuebuffer
/* 100 */         .append(Base64.getEncoder().encodeToString((new String(keyInfo.encryptedKey, StandardCharsets.UTF_8)).getBytes()));
/*     */       
/* 102 */       keyLookupValuebuffer.append(":");
/* 103 */       keyLookupValuebuffer.append(keyInfo.keyStoreName);
/* 104 */       String keyLookupValue = keyLookupValuebuffer.toString();
/* 105 */       keyLookupValuebuffer.setLength(0);
/*     */       
/* 107 */       if (aeLogger.isLoggable(Level.FINE)) {
/* 108 */         aeLogger.fine("Checking trusted master key path...");
/*     */       }
/* 110 */       Boolean[] hasEntry = new Boolean[1];
/* 111 */       List<String> trustedKeyPaths = SQLServerConnection.getColumnEncryptionTrustedMasterKeyPaths(serverName, hasEntry);
/*     */       
/* 113 */       if (hasEntry[0].booleanValue() && (
/* 114 */         null == trustedKeyPaths || 0 == trustedKeyPaths.size() || 
/* 115 */         !trustedKeyPaths.contains(keyInfo.keyPath))) {
/* 116 */         MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_UntrustedKeyPath"));
/* 117 */         Object[] msgArgs = { keyInfo.keyPath, serverName };
/* 118 */         throw new SQLServerException(this, form.format(msgArgs), null, 0, false);
/*     */       } 
/*     */ 
/*     */       
/* 122 */       if (aeLogger.isLoggable(Level.FINE)) {
/* 123 */         aeLogger.fine("Checking Symmetric key cache...");
/*     */       }
/*     */ 
/*     */       
/* 127 */       if (!this.cache.containsKey(keyLookupValue)) {
/*     */ 
/*     */         
/* 130 */         byte[] plaintextKey = connection.getColumnEncryptionKeyStoreProvider(keyInfo.keyStoreName).decryptColumnEncryptionKey(keyInfo.keyPath, keyInfo.algorithmName, keyInfo.encryptedKey);
/* 131 */         encryptionKey = new SQLServerSymmetricKey(plaintextKey);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 138 */         long columnEncryptionKeyCacheTtl = SQLServerConnection.getColumnEncryptionKeyCacheTtl();
/* 139 */         if (0L != columnEncryptionKeyCacheTtl) {
/* 140 */           this.cache.putIfAbsent(keyLookupValue, encryptionKey);
/* 141 */           if (aeLogger.isLoggable(Level.FINE)) {
/* 142 */             aeLogger.fine("Adding encryption key to cache...");
/*     */           }
/* 144 */           scheduler.schedule(new CacheClear(keyLookupValue), columnEncryptionKeyCacheTtl, TimeUnit.SECONDS);
/*     */         } 
/*     */       } else {
/* 147 */         encryptionKey = this.cache.get(keyLookupValue);
/*     */       } 
/*     */     } 
/* 150 */     return encryptionKey;
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerSymmetricKeyCache.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */