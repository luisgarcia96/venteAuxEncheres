/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class EncryptionKeyInfo
/*    */ {
/*    */   byte[] encryptedKey;
/*    */   int databaseId;
/*    */   int cekId;
/*    */   int cekVersion;
/*    */   byte[] cekMdVersion;
/*    */   String keyPath;
/*    */   String keyStoreName;
/*    */   String algorithmName;
/*    */   byte normalizationRuleVersion;
/*    */   
/*    */   EncryptionKeyInfo(byte[] encryptedKeyVal, int dbId, int keyId, int keyVersion, byte[] mdVersion, String keyPathVal, String keyStoreNameVal, String algorithmNameVal) {
/* 20 */     this.encryptedKey = encryptedKeyVal;
/* 21 */     this.databaseId = dbId;
/* 22 */     this.cekId = keyId;
/* 23 */     this.cekVersion = keyVersion;
/* 24 */     this.cekMdVersion = mdVersion;
/* 25 */     this.keyPath = keyPathVal;
/* 26 */     this.keyStoreName = keyStoreNameVal;
/* 27 */     this.algorithmName = algorithmNameVal;
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\EncryptionKeyInfo.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */