/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.text.MessageFormat;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class SQLServerBulkRecord
/*     */   implements ISQLServerBulkRecord
/*     */ {
/*     */   private static final long serialVersionUID = -170992637946357449L;
/*     */   
/*     */   protected class ColumnMetadata
/*     */   {
/*     */     String columnName;
/*     */     int columnType;
/*     */     int precision;
/*     */     int scale;
/*  30 */     DateTimeFormatter dateTimeFormatter = null;
/*     */     
/*     */     ColumnMetadata(String name, int type, int precision, int scale, DateTimeFormatter dateTimeFormatter) {
/*  33 */       this.columnName = name;
/*  34 */       this.columnType = type;
/*  35 */       this.precision = precision;
/*  36 */       this.scale = scale;
/*  37 */       this.dateTimeFormatter = dateTimeFormatter;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  44 */   protected String[] columnNames = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Map<Integer, ColumnMetadata> columnMetadata;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   protected DateTimeFormatter dateTimeFormatter = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   protected DateTimeFormatter timeFormatter = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  65 */   protected String loggerPackageName = "com.microsoft.jdbc.SQLServerBulkRecord";
/*     */   
/*  67 */   protected static Logger loggerExternal = Logger.getLogger("com.microsoft.jdbc.SQLServerBulkRecord");
/*     */ 
/*     */ 
/*     */   
/*     */   public void addColumnMetadata(int positionInSource, String name, int jdbcType, int precision, int scale, DateTimeFormatter dateTimeFormatter) throws SQLServerException {
/*  72 */     addColumnMetadataInternal(positionInSource, name, jdbcType, precision, scale, dateTimeFormatter);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addColumnMetadata(int positionInSource, String name, int jdbcType, int precision, int scale) throws SQLServerException {
/*  78 */     addColumnMetadataInternal(positionInSource, name, jdbcType, precision, scale, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void addColumnMetadataInternal(int positionInSource, String name, int jdbcType, int precision, int scale, DateTimeFormatter dateTimeFormatter) throws SQLServerException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTimestampWithTimezoneFormat(String dateTimeFormat) {
/* 104 */     loggerExternal.entering(this.loggerPackageName, "setTimestampWithTimezoneFormat", dateTimeFormat);
/* 105 */     this.dateTimeFormatter = DateTimeFormatter.ofPattern(dateTimeFormat);
/* 106 */     loggerExternal.exiting(this.loggerPackageName, "setTimestampWithTimezoneFormat");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTimestampWithTimezoneFormat(DateTimeFormatter dateTimeFormatter) {
/* 111 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 112 */       loggerExternal.entering(this.loggerPackageName, "setTimestampWithTimezoneFormat", new Object[] { dateTimeFormatter });
/*     */     }
/*     */     
/* 115 */     this.dateTimeFormatter = dateTimeFormatter;
/* 116 */     loggerExternal.exiting(this.loggerPackageName, "setTimestampWithTimezoneFormat");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTimeWithTimezoneFormat(String timeFormat) {
/* 121 */     loggerExternal.entering(this.loggerPackageName, "setTimeWithTimezoneFormat", timeFormat);
/* 122 */     this.timeFormatter = DateTimeFormatter.ofPattern(timeFormat);
/* 123 */     loggerExternal.exiting(this.loggerPackageName, "setTimeWithTimezoneFormat");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTimeWithTimezoneFormat(DateTimeFormatter dateTimeFormatter) {
/* 128 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 129 */       loggerExternal.entering(this.loggerPackageName, "setTimeWithTimezoneFormat", new Object[] { dateTimeFormatter });
/*     */     }
/* 131 */     this.timeFormatter = dateTimeFormatter;
/* 132 */     loggerExternal.exiting(this.loggerPackageName, "setTimeWithTimezoneFormat");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void throwInvalidArgument(String argument) throws SQLServerException {
/* 139 */     MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidArgument"));
/* 140 */     Object[] msgArgs = { argument };
/* 141 */     SQLServerException.makeFromDriverError(null, null, form.format(msgArgs), null, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void checkDuplicateColumnName(int positionInTable, String colName) throws SQLServerException {
/* 149 */     if (null != colName && colName.trim().length() != 0) {
/* 150 */       for (Map.Entry<Integer, ColumnMetadata> entry : this.columnMetadata.entrySet()) {
/*     */ 
/*     */         
/* 153 */         if (null != entry && ((Integer)entry.getKey()).intValue() != positionInTable && 
/* 154 */           null != entry.getValue() && colName.trim().equalsIgnoreCase(((ColumnMetadata)entry.getValue()).columnName)) {
/* 155 */           throw new SQLServerException(SQLServerException.getErrString("R_BulkDataDuplicateColumn"), null);
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DateTimeFormatter getColumnDateTimeFormatter(int column) {
/* 165 */     return ((ColumnMetadata)this.columnMetadata.get(Integer.valueOf(column))).dateTimeFormatter;
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<Integer> getColumnOrdinals() {
/* 170 */     return this.columnMetadata.keySet();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getColumnName(int column) {
/* 175 */     return ((ColumnMetadata)this.columnMetadata.get(Integer.valueOf(column))).columnName;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getColumnType(int column) {
/* 180 */     return ((ColumnMetadata)this.columnMetadata.get(Integer.valueOf(column))).columnType;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrecision(int column) {
/* 185 */     return ((ColumnMetadata)this.columnMetadata.get(Integer.valueOf(column))).precision;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getScale(int column) {
/* 190 */     return ((ColumnMetadata)this.columnMetadata.get(Integer.valueOf(column))).scale;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAutoIncrement(int column) {
/* 195 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerBulkRecord.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */