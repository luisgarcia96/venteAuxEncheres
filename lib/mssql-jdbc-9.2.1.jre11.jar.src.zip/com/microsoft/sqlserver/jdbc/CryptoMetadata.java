/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CryptoMetadata
/*     */ {
/*     */   TypeInfo baseTypeInfo;
/*     */   CekTableEntry cekTableEntry;
/*     */   byte cipherAlgorithmId;
/*     */   String cipherAlgorithmName;
/*     */   SQLServerEncryptionType encryptionType;
/*     */   byte normalizationRuleVersion;
/* 159 */   SQLServerEncryptionAlgorithm cipherAlgorithm = null;
/*     */   EncryptionKeyInfo encryptionKeyInfo;
/*     */   short ordinal;
/*     */   
/*     */   CekTableEntry getCekTableEntry() {
/* 164 */     return this.cekTableEntry;
/*     */   }
/*     */   
/*     */   void setCekTableEntry(CekTableEntry cekTableEntryObj) {
/* 168 */     this.cekTableEntry = cekTableEntryObj;
/*     */   }
/*     */   
/*     */   TypeInfo getBaseTypeInfo() {
/* 172 */     return this.baseTypeInfo;
/*     */   }
/*     */   
/*     */   void setBaseTypeInfo(TypeInfo baseTypeInfoObj) {
/* 176 */     this.baseTypeInfo = baseTypeInfoObj;
/*     */   }
/*     */   
/*     */   SQLServerEncryptionAlgorithm getEncryptionAlgorithm() {
/* 180 */     return this.cipherAlgorithm;
/*     */   }
/*     */   
/*     */   void setEncryptionAlgorithm(SQLServerEncryptionAlgorithm encryptionAlgorithmObj) {
/* 184 */     this.cipherAlgorithm = encryptionAlgorithmObj;
/*     */   }
/*     */   
/*     */   EncryptionKeyInfo getEncryptionKeyInfo() {
/* 188 */     return this.encryptionKeyInfo;
/*     */   }
/*     */   
/*     */   void setEncryptionKeyInfo(EncryptionKeyInfo encryptionKeyInfoObj) {
/* 192 */     this.encryptionKeyInfo = encryptionKeyInfoObj;
/*     */   }
/*     */   
/*     */   byte getEncryptionAlgorithmId() {
/* 196 */     return this.cipherAlgorithmId;
/*     */   }
/*     */   
/*     */   String getEncryptionAlgorithmName() {
/* 200 */     return this.cipherAlgorithmName;
/*     */   }
/*     */   
/*     */   SQLServerEncryptionType getEncryptionType() {
/* 204 */     return this.encryptionType;
/*     */   }
/*     */   
/*     */   byte getNormalizationRuleVersion() {
/* 208 */     return this.normalizationRuleVersion;
/*     */   }
/*     */   
/*     */   short getOrdinal() {
/* 212 */     return this.ordinal;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   CryptoMetadata(CekTableEntry cekTableEntryObj, short ordinalVal, byte cipherAlgorithmIdVal, String cipherAlgorithmNameVal, byte encryptionTypeVal, byte normalizationRuleVersionVal) throws SQLServerException {
/* 218 */     this.cekTableEntry = cekTableEntryObj;
/* 219 */     this.ordinal = ordinalVal;
/* 220 */     this.cipherAlgorithmId = cipherAlgorithmIdVal;
/* 221 */     this.cipherAlgorithmName = cipherAlgorithmNameVal;
/* 222 */     this.encryptionType = SQLServerEncryptionType.of(encryptionTypeVal);
/* 223 */     this.normalizationRuleVersion = normalizationRuleVersionVal;
/* 224 */     this.encryptionKeyInfo = null;
/*     */   }
/*     */   
/*     */   boolean IsAlgorithmInitialized() {
/* 228 */     return (null != this.cipherAlgorithm);
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\CryptoMetadata.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */