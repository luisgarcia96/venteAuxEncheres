/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.io.InvalidObjectException;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.ObjectStreamException;
/*      */ import java.io.PrintWriter;
/*      */ import java.io.Serializable;
/*      */ import java.sql.Connection;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLFeatureNotSupportedException;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Properties;
/*      */ import java.util.concurrent.atomic.AtomicInteger;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ import javax.naming.Reference;
/*      */ import javax.naming.Referenceable;
/*      */ import javax.naming.StringRefAddr;
/*      */ import javax.sql.DataSource;
/*      */ import org.ietf.jgss.GSSCredential;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class SQLServerDataSource
/*      */   implements ISQLServerDataSource, DataSource, Serializable, Referenceable
/*      */ {
/*   30 */   static final Logger dsLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerDataSource");
/*      */   
/*   32 */   static final Logger loggerExternal = Logger.getLogger("com.microsoft.sqlserver.jdbc.DataSource");
/*      */   
/*   34 */   private static final Logger parentLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc");
/*      */   
/*      */   private final String loggingClassName;
/*      */   
/*      */   private boolean trustStorePasswordStripped = false;
/*      */   
/*      */   private static final long serialVersionUID = 654861379544314296L;
/*      */   
/*      */   private Properties connectionProps;
/*      */   
/*      */   private String dataSourceURL;
/*      */   
/*      */   private String dataSourceDescription;
/*   47 */   private static final AtomicInteger baseDataSourceID = new AtomicInteger(0);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final String traceID;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private transient PrintWriter logWriter;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SQLServerDataSource() {
/*   63 */     this.connectionProps = new Properties();
/*   64 */     int dataSourceID = nextDataSourceID();
/*   65 */     String nameL = getClass().getName();
/*   66 */     this.traceID = nameL.substring(1 + nameL.lastIndexOf('.')) + ":" + nameL.substring(1 + nameL.lastIndexOf('.'));
/*   67 */     this.loggingClassName = "com.microsoft.sqlserver.jdbc." + nameL.substring(1 + nameL.lastIndexOf('.')) + ":" + dataSourceID;
/*      */   }
/*      */ 
/*      */   
/*      */   String getClassNameLogging() {
/*   72 */     return this.loggingClassName;
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/*   77 */     return this.traceID;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Connection getConnection() throws SQLServerException {
/*   84 */     loggerExternal.entering(getClassNameLogging(), "getConnection");
/*   85 */     Connection con = getConnectionInternal(null, null, null);
/*   86 */     loggerExternal.exiting(getClassNameLogging(), "getConnection", con);
/*   87 */     return con;
/*      */   }
/*      */ 
/*      */   
/*      */   public Connection getConnection(String username, String password) throws SQLServerException {
/*   92 */     if (loggerExternal.isLoggable(Level.FINER)) {
/*   93 */       loggerExternal.entering(getClassNameLogging(), "getConnection", new Object[] { username, "Password not traced" });
/*      */     }
/*   95 */     Connection con = getConnectionInternal(username, password, null);
/*   96 */     loggerExternal.exiting(getClassNameLogging(), "getConnection", con);
/*   97 */     return con;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLoginTimeout(int loginTimeout) {
/*  106 */     setIntProperty(this.connectionProps, SQLServerDriverIntProperty.LOGIN_TIMEOUT.toString(), loginTimeout);
/*      */   }
/*      */ 
/*      */   
/*      */   public int getLoginTimeout() {
/*  111 */     int defaultTimeOut = SQLServerDriverIntProperty.LOGIN_TIMEOUT.getDefaultValue();
/*  112 */     int logintimeout = getIntProperty(this.connectionProps, SQLServerDriverIntProperty.LOGIN_TIMEOUT.toString(), defaultTimeOut);
/*      */ 
/*      */     
/*  115 */     return (logintimeout == 0) ? defaultTimeOut : logintimeout;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLogWriter(PrintWriter out) {
/*  126 */     loggerExternal.entering(getClassNameLogging(), "setLogWriter", out);
/*  127 */     this.logWriter = out;
/*  128 */     loggerExternal.exiting(getClassNameLogging(), "setLogWriter");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PrintWriter getLogWriter() {
/*  136 */     loggerExternal.entering(getClassNameLogging(), "getLogWriter");
/*  137 */     loggerExternal.exiting(getClassNameLogging(), "getLogWriter", this.logWriter);
/*  138 */     return this.logWriter;
/*      */   }
/*      */ 
/*      */   
/*      */   public Logger getParentLogger() throws SQLFeatureNotSupportedException {
/*  143 */     return parentLogger;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setApplicationName(String applicationName) {
/*  153 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.APPLICATION_NAME.toString(), applicationName);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getApplicationName() {
/*  158 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.APPLICATION_NAME.toString(), SQLServerDriverStringProperty.APPLICATION_NAME
/*  159 */         .getDefaultValue());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDatabaseName(String databaseName) {
/*  170 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.DATABASE_NAME.toString(), databaseName);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getDatabaseName() {
/*  175 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.DATABASE_NAME.toString(), null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInstanceName(String instanceName) {
/*  186 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.INSTANCE_NAME.toString(), instanceName);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getInstanceName() {
/*  191 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.INSTANCE_NAME.toString(), null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setIntegratedSecurity(boolean enable) {
/*  196 */     setBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.INTEGRATED_SECURITY.toString(), enable);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setAuthenticationScheme(String authenticationScheme) {
/*  201 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.AUTHENTICATION_SCHEME.toString(), authenticationScheme);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAuthentication(String authentication) {
/*  207 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.AUTHENTICATION.toString(), authentication);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getAuthentication() {
/*  212 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.AUTHENTICATION.toString(), SQLServerDriverStringProperty.AUTHENTICATION
/*  213 */         .getDefaultValue());
/*      */   }
/*      */ 
/*      */   
/*      */   public void setGSSCredentials(GSSCredential userCredential) {
/*  218 */     setObjectProperty(this.connectionProps, SQLServerDriverObjectProperty.GSS_CREDENTIAL.toString(), userCredential);
/*      */   }
/*      */ 
/*      */   
/*      */   public GSSCredential getGSSCredentials() {
/*  223 */     return (GSSCredential)getObjectProperty(this.connectionProps, SQLServerDriverObjectProperty.GSS_CREDENTIAL
/*  224 */         .toString(), SQLServerDriverObjectProperty.GSS_CREDENTIAL
/*  225 */         .getDefaultValue());
/*      */   }
/*      */ 
/*      */   
/*      */   public void setAccessToken(String accessToken) {
/*  230 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.ACCESS_TOKEN.toString(), accessToken);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getAccessToken() {
/*  235 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.ACCESS_TOKEN.toString(), null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setColumnEncryptionSetting(String columnEncryptionSetting) {
/*  245 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.COLUMN_ENCRYPTION.toString(), columnEncryptionSetting);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getColumnEncryptionSetting() {
/*  251 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.COLUMN_ENCRYPTION.toString(), SQLServerDriverStringProperty.COLUMN_ENCRYPTION
/*  252 */         .getDefaultValue());
/*      */   }
/*      */ 
/*      */   
/*      */   public void setKeyStoreAuthentication(String keyStoreAuthentication) {
/*  257 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.KEY_STORE_AUTHENTICATION.toString(), keyStoreAuthentication);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getKeyStoreAuthentication() {
/*  263 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.KEY_STORE_AUTHENTICATION.toString(), SQLServerDriverStringProperty.KEY_STORE_AUTHENTICATION
/*  264 */         .getDefaultValue());
/*      */   }
/*      */ 
/*      */   
/*      */   public void setKeyStoreSecret(String keyStoreSecret) {
/*  269 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.KEY_STORE_SECRET.toString(), keyStoreSecret);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setKeyStoreLocation(String keyStoreLocation) {
/*  274 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.KEY_STORE_LOCATION.toString(), keyStoreLocation);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getKeyStoreLocation() {
/*  280 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.KEY_STORE_LOCATION.toString(), SQLServerDriverStringProperty.KEY_STORE_LOCATION
/*  281 */         .getDefaultValue());
/*      */   }
/*      */ 
/*      */   
/*      */   public void setLastUpdateCount(boolean lastUpdateCount) {
/*  286 */     setBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.LAST_UPDATE_COUNT.toString(), lastUpdateCount);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getLastUpdateCount() {
/*  292 */     return getBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.LAST_UPDATE_COUNT.toString(), SQLServerDriverBooleanProperty.LAST_UPDATE_COUNT
/*  293 */         .getDefaultValue());
/*      */   }
/*      */ 
/*      */   
/*      */   public void setEncrypt(boolean encrypt) {
/*  298 */     setBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.ENCRYPT.toString(), encrypt);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean getEncrypt() {
/*  303 */     return getBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.ENCRYPT.toString(), SQLServerDriverBooleanProperty.ENCRYPT
/*  304 */         .getDefaultValue());
/*      */   }
/*      */ 
/*      */   
/*      */   public void setTransparentNetworkIPResolution(boolean tnir) {
/*  309 */     setBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.TRANSPARENT_NETWORK_IP_RESOLUTION.toString(), tnir);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getTransparentNetworkIPResolution() {
/*  315 */     return getBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.TRANSPARENT_NETWORK_IP_RESOLUTION
/*  316 */         .toString(), SQLServerDriverBooleanProperty.TRANSPARENT_NETWORK_IP_RESOLUTION
/*  317 */         .getDefaultValue());
/*      */   }
/*      */ 
/*      */   
/*      */   public void setTrustServerCertificate(boolean e) {
/*  322 */     setBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.TRUST_SERVER_CERTIFICATE.toString(), e);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean getTrustServerCertificate() {
/*  327 */     return getBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.TRUST_SERVER_CERTIFICATE.toString(), SQLServerDriverBooleanProperty.TRUST_SERVER_CERTIFICATE
/*  328 */         .getDefaultValue());
/*      */   }
/*      */ 
/*      */   
/*      */   public void setTrustStoreType(String trustStoreType) {
/*  333 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.TRUST_STORE_TYPE.toString(), trustStoreType);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getTrustStoreType() {
/*  338 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.TRUST_STORE_TYPE.toString(), SQLServerDriverStringProperty.TRUST_STORE_TYPE
/*  339 */         .getDefaultValue());
/*      */   }
/*      */ 
/*      */   
/*      */   public void setTrustStore(String trustStore) {
/*  344 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.TRUST_STORE.toString(), trustStore);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getTrustStore() {
/*  349 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.TRUST_STORE.toString(), null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTrustStorePassword(String trustStorePassword) {
/*  355 */     if (trustStorePassword != null)
/*  356 */       this.trustStorePasswordStripped = false; 
/*  357 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.TRUST_STORE_PASSWORD.toString(), trustStorePassword);
/*      */   }
/*      */ 
/*      */   
/*      */   String getTrustStorePassword() {
/*  362 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.TRUST_STORE_PASSWORD.toString(), null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setHostNameInCertificate(String hostName) {
/*  367 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.HOSTNAME_IN_CERTIFICATE.toString(), hostName);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getHostNameInCertificate() {
/*  372 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.HOSTNAME_IN_CERTIFICATE.toString(), null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLockTimeout(int lockTimeout) {
/*  386 */     setIntProperty(this.connectionProps, SQLServerDriverIntProperty.LOCK_TIMEOUT.toString(), lockTimeout);
/*      */   }
/*      */ 
/*      */   
/*      */   public int getLockTimeout() {
/*  391 */     return getIntProperty(this.connectionProps, SQLServerDriverIntProperty.LOCK_TIMEOUT.toString(), SQLServerDriverIntProperty.LOCK_TIMEOUT
/*  392 */         .getDefaultValue());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPassword(String password) {
/*  404 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.PASSWORD.toString(), password);
/*      */   }
/*      */   
/*      */   String getPassword() {
/*  408 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.PASSWORD.toString(), null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPortNumber(int portNumber) {
/*  421 */     setIntProperty(this.connectionProps, SQLServerDriverIntProperty.PORT_NUMBER.toString(), portNumber);
/*      */   }
/*      */ 
/*      */   
/*      */   public int getPortNumber() {
/*  426 */     return getIntProperty(this.connectionProps, SQLServerDriverIntProperty.PORT_NUMBER.toString(), SQLServerDriverIntProperty.PORT_NUMBER
/*  427 */         .getDefaultValue());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSelectMethod(String selectMethod) {
/*  442 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.SELECT_METHOD.toString(), selectMethod);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getSelectMethod() {
/*  447 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.SELECT_METHOD.toString(), SQLServerDriverStringProperty.SELECT_METHOD
/*  448 */         .getDefaultValue());
/*      */   }
/*      */ 
/*      */   
/*      */   public void setResponseBuffering(String bufferingMode) {
/*  453 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.RESPONSE_BUFFERING.toString(), bufferingMode);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getResponseBuffering() {
/*  458 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.RESPONSE_BUFFERING.toString(), SQLServerDriverStringProperty.RESPONSE_BUFFERING
/*  459 */         .getDefaultValue());
/*      */   }
/*      */ 
/*      */   
/*      */   public void setApplicationIntent(String applicationIntent) {
/*  464 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.APPLICATION_INTENT.toString(), applicationIntent);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getApplicationIntent() {
/*  470 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.APPLICATION_INTENT.toString(), SQLServerDriverStringProperty.APPLICATION_INTENT
/*  471 */         .getDefaultValue());
/*      */   }
/*      */ 
/*      */   
/*      */   public void setSendTimeAsDatetime(boolean sendTimeAsDatetime) {
/*  476 */     setBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.SEND_TIME_AS_DATETIME.toString(), sendTimeAsDatetime);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getSendTimeAsDatetime() {
/*  482 */     return getBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.SEND_TIME_AS_DATETIME.toString(), SQLServerDriverBooleanProperty.SEND_TIME_AS_DATETIME
/*  483 */         .getDefaultValue());
/*      */   }
/*      */ 
/*      */   
/*      */   public void setUseFmtOnly(boolean useFmtOnly) {
/*  488 */     setBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.USE_FMT_ONLY.toString(), useFmtOnly);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean getUseFmtOnly() {
/*  493 */     return getBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.USE_FMT_ONLY.toString(), SQLServerDriverBooleanProperty.USE_FMT_ONLY
/*  494 */         .getDefaultValue());
/*      */   }
/*      */ 
/*      */   
/*      */   public void setDelayLoadingLobs(boolean delayLoadingLobs) {
/*  499 */     setBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.DELAY_LOADING_LOBS.toString(), delayLoadingLobs);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getDelayLoadingLobs() {
/*  505 */     return getBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.DELAY_LOADING_LOBS.toString(), SQLServerDriverBooleanProperty.DELAY_LOADING_LOBS
/*  506 */         .getDefaultValue());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSendStringParametersAsUnicode(boolean sendStringParametersAsUnicode) {
/*  519 */     setBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.SEND_STRING_PARAMETERS_AS_UNICODE.toString(), sendStringParametersAsUnicode);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getSendStringParametersAsUnicode() {
/*  525 */     return getBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.SEND_STRING_PARAMETERS_AS_UNICODE
/*  526 */         .toString(), SQLServerDriverBooleanProperty.SEND_STRING_PARAMETERS_AS_UNICODE
/*  527 */         .getDefaultValue());
/*      */   }
/*      */ 
/*      */   
/*      */   public void setServerNameAsACE(boolean serverNameAsACE) {
/*  532 */     setBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.SERVER_NAME_AS_ACE.toString(), serverNameAsACE);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getServerNameAsACE() {
/*  538 */     return getBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.SERVER_NAME_AS_ACE.toString(), SQLServerDriverBooleanProperty.SERVER_NAME_AS_ACE
/*  539 */         .getDefaultValue());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setServerName(String serverName) {
/*  550 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.SERVER_NAME.toString(), serverName);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getServerName() {
/*  555 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.SERVER_NAME.toString(), null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setServerSpn(String serverSpn) {
/*  567 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.SERVER_SPN.toString(), serverSpn);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getServerSpn() {
/*  572 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.SERVER_SPN.toString(), null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFailoverPartner(String serverName) {
/*  583 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.FAILOVER_PARTNER.toString(), serverName);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getFailoverPartner() {
/*  588 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.FAILOVER_PARTNER.toString(), null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setMultiSubnetFailover(boolean multiSubnetFailover) {
/*  593 */     setBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.MULTI_SUBNET_FAILOVER.toString(), multiSubnetFailover);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getMultiSubnetFailover() {
/*  599 */     return getBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.MULTI_SUBNET_FAILOVER.toString(), SQLServerDriverBooleanProperty.MULTI_SUBNET_FAILOVER
/*  600 */         .getDefaultValue());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUser(String user) {
/*  611 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.USER.toString(), user);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getUser() {
/*  616 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.USER.toString(), null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setWorkstationID(String workstationID) {
/*  629 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.WORKSTATION_ID.toString(), workstationID);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getWorkstationID() {
/*  634 */     if (loggerExternal.isLoggable(Level.FINER))
/*  635 */       loggerExternal.entering(getClassNameLogging(), "getWorkstationID"); 
/*  636 */     String getWSID = this.connectionProps.getProperty(SQLServerDriverStringProperty.WORKSTATION_ID.toString());
/*      */ 
/*      */     
/*  639 */     if (null == getWSID) {
/*  640 */       getWSID = Util.lookupHostName();
/*      */     }
/*  642 */     loggerExternal.exiting(getClassNameLogging(), "getWorkstationID", getWSID);
/*  643 */     return getWSID;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setXopenStates(boolean xopenStates) {
/*  655 */     setBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.XOPEN_STATES.toString(), xopenStates);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean getXopenStates() {
/*  660 */     return getBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.XOPEN_STATES.toString(), SQLServerDriverBooleanProperty.XOPEN_STATES
/*  661 */         .getDefaultValue());
/*      */   }
/*      */ 
/*      */   
/*      */   public void setFIPS(boolean fips) {
/*  666 */     setBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.FIPS.toString(), fips);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean getFIPS() {
/*  671 */     return getBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.FIPS.toString(), SQLServerDriverBooleanProperty.FIPS
/*  672 */         .getDefaultValue());
/*      */   }
/*      */ 
/*      */   
/*      */   public String getSocketFactoryClass() {
/*  677 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.SOCKET_FACTORY_CLASS.toString(), null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setSocketFactoryClass(String socketFactoryClass) {
/*  682 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.SOCKET_FACTORY_CLASS.toString(), socketFactoryClass);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getSocketFactoryConstructorArg() {
/*  688 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.SOCKET_FACTORY_CONSTRUCTOR_ARG
/*  689 */         .toString(), null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setSocketFactoryConstructorArg(String socketFactoryConstructorArg) {
/*  694 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.SOCKET_FACTORY_CONSTRUCTOR_ARG.toString(), socketFactoryConstructorArg);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSSLProtocol(String sslProtocol) {
/*  700 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.SSL_PROTOCOL.toString(), sslProtocol);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getSSLProtocol() {
/*  705 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.SSL_PROTOCOL.toString(), SQLServerDriverStringProperty.SSL_PROTOCOL
/*  706 */         .getDefaultValue());
/*      */   }
/*      */ 
/*      */   
/*      */   public void setTrustManagerClass(String trustManagerClass) {
/*  711 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.TRUST_MANAGER_CLASS.toString(), trustManagerClass);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getTrustManagerClass() {
/*  717 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.TRUST_MANAGER_CLASS.toString(), SQLServerDriverStringProperty.TRUST_MANAGER_CLASS
/*  718 */         .getDefaultValue());
/*      */   }
/*      */ 
/*      */   
/*      */   public void setTrustManagerConstructorArg(String trustManagerConstructorArg) {
/*  723 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.TRUST_MANAGER_CONSTRUCTOR_ARG.toString(), trustManagerConstructorArg);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getTrustManagerConstructorArg() {
/*  729 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.TRUST_MANAGER_CONSTRUCTOR_ARG
/*  730 */         .toString(), SQLServerDriverStringProperty.TRUST_MANAGER_CONSTRUCTOR_ARG
/*  731 */         .getDefaultValue());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setURL(String url) {
/*  749 */     loggerExternal.entering(getClassNameLogging(), "setURL", url);
/*      */     
/*  751 */     this.dataSourceURL = url;
/*  752 */     loggerExternal.exiting(getClassNameLogging(), "setURL");
/*      */   }
/*      */ 
/*      */   
/*      */   public String getURL() {
/*  757 */     String url = this.dataSourceURL;
/*  758 */     loggerExternal.entering(getClassNameLogging(), "getURL");
/*      */     
/*  760 */     if (null == this.dataSourceURL)
/*  761 */       url = "jdbc:sqlserver://"; 
/*  762 */     loggerExternal.exiting(getClassNameLogging(), "getURL", url);
/*  763 */     return url;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDescription(String description) {
/*  772 */     loggerExternal.entering(getClassNameLogging(), "setDescription", description);
/*  773 */     this.dataSourceDescription = description;
/*  774 */     loggerExternal.exiting(getClassNameLogging(), "setDescription");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getDescription() {
/*  782 */     loggerExternal.entering(getClassNameLogging(), "getDescription");
/*  783 */     loggerExternal.exiting(getClassNameLogging(), "getDescription", this.dataSourceDescription);
/*  784 */     return this.dataSourceDescription;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPacketSize(int packetSize) {
/*  797 */     setIntProperty(this.connectionProps, SQLServerDriverIntProperty.PACKET_SIZE.toString(), packetSize);
/*      */   }
/*      */ 
/*      */   
/*      */   public int getPacketSize() {
/*  802 */     return getIntProperty(this.connectionProps, SQLServerDriverIntProperty.PACKET_SIZE.toString(), SQLServerDriverIntProperty.PACKET_SIZE
/*  803 */         .getDefaultValue());
/*      */   }
/*      */ 
/*      */   
/*      */   public void setQueryTimeout(int queryTimeout) {
/*  808 */     setIntProperty(this.connectionProps, SQLServerDriverIntProperty.QUERY_TIMEOUT.toString(), queryTimeout);
/*      */   }
/*      */ 
/*      */   
/*      */   public int getQueryTimeout() {
/*  813 */     return getIntProperty(this.connectionProps, SQLServerDriverIntProperty.QUERY_TIMEOUT.toString(), SQLServerDriverIntProperty.QUERY_TIMEOUT
/*  814 */         .getDefaultValue());
/*      */   }
/*      */ 
/*      */   
/*      */   public void setCancelQueryTimeout(int cancelQueryTimeout) {
/*  819 */     setIntProperty(this.connectionProps, SQLServerDriverIntProperty.CANCEL_QUERY_TIMEOUT.toString(), cancelQueryTimeout);
/*      */   }
/*      */ 
/*      */   
/*      */   public int getCancelQueryTimeout() {
/*  824 */     return getIntProperty(this.connectionProps, SQLServerDriverIntProperty.CANCEL_QUERY_TIMEOUT.toString(), SQLServerDriverIntProperty.CANCEL_QUERY_TIMEOUT
/*  825 */         .getDefaultValue());
/*      */   }
/*      */ 
/*      */   
/*      */   public void setEnablePrepareOnFirstPreparedStatementCall(boolean enablePrepareOnFirstPreparedStatementCall) {
/*  830 */     setBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.ENABLE_PREPARE_ON_FIRST_PREPARED_STATEMENT
/*  831 */         .toString(), enablePrepareOnFirstPreparedStatementCall);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getEnablePrepareOnFirstPreparedStatementCall() {
/*  838 */     boolean defaultValue = SQLServerDriverBooleanProperty.ENABLE_PREPARE_ON_FIRST_PREPARED_STATEMENT.getDefaultValue();
/*  839 */     return getBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.ENABLE_PREPARE_ON_FIRST_PREPARED_STATEMENT
/*  840 */         .toString(), defaultValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setServerPreparedStatementDiscardThreshold(int serverPreparedStatementDiscardThreshold) {
/*  845 */     setIntProperty(this.connectionProps, SQLServerDriverIntProperty.SERVER_PREPARED_STATEMENT_DISCARD_THRESHOLD
/*  846 */         .toString(), serverPreparedStatementDiscardThreshold);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getServerPreparedStatementDiscardThreshold() {
/*  852 */     int defaultSize = SQLServerDriverIntProperty.SERVER_PREPARED_STATEMENT_DISCARD_THRESHOLD.getDefaultValue();
/*  853 */     return getIntProperty(this.connectionProps, SQLServerDriverIntProperty.SERVER_PREPARED_STATEMENT_DISCARD_THRESHOLD
/*  854 */         .toString(), defaultSize);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setStatementPoolingCacheSize(int statementPoolingCacheSize) {
/*  859 */     setIntProperty(this.connectionProps, SQLServerDriverIntProperty.STATEMENT_POOLING_CACHE_SIZE.toString(), statementPoolingCacheSize);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getStatementPoolingCacheSize() {
/*  865 */     int defaultSize = SQLServerDriverIntProperty.STATEMENT_POOLING_CACHE_SIZE.getDefaultValue();
/*  866 */     return getIntProperty(this.connectionProps, SQLServerDriverIntProperty.STATEMENT_POOLING_CACHE_SIZE.toString(), defaultSize);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDisableStatementPooling(boolean disableStatementPooling) {
/*  872 */     setBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.DISABLE_STATEMENT_POOLING.toString(), disableStatementPooling);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getDisableStatementPooling() {
/*  878 */     boolean defaultValue = SQLServerDriverBooleanProperty.DISABLE_STATEMENT_POOLING.getDefaultValue();
/*  879 */     return getBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.DISABLE_STATEMENT_POOLING.toString(), defaultValue);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSocketTimeout(int socketTimeout) {
/*  885 */     setIntProperty(this.connectionProps, SQLServerDriverIntProperty.SOCKET_TIMEOUT.toString(), socketTimeout);
/*      */   }
/*      */ 
/*      */   
/*      */   public int getSocketTimeout() {
/*  890 */     int defaultTimeOut = SQLServerDriverIntProperty.SOCKET_TIMEOUT.getDefaultValue();
/*  891 */     return getIntProperty(this.connectionProps, SQLServerDriverIntProperty.SOCKET_TIMEOUT.toString(), defaultTimeOut);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setUseBulkCopyForBatchInsert(boolean useBulkCopyForBatchInsert) {
/*  896 */     setBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.USE_BULK_COPY_FOR_BATCH_INSERT.toString(), useBulkCopyForBatchInsert);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getUseBulkCopyForBatchInsert() {
/*  902 */     return getBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.USE_BULK_COPY_FOR_BATCH_INSERT
/*  903 */         .toString(), SQLServerDriverBooleanProperty.USE_BULK_COPY_FOR_BATCH_INSERT
/*  904 */         .getDefaultValue());
/*      */   }
/*      */ 
/*      */   
/*      */   public void setJASSConfigurationName(String configurationName) {
/*  909 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.JAAS_CONFIG_NAME.toString(), configurationName);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getJASSConfigurationName() {
/*  915 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.JAAS_CONFIG_NAME.toString(), SQLServerDriverStringProperty.JAAS_CONFIG_NAME
/*  916 */         .getDefaultValue());
/*      */   }
/*      */ 
/*      */   
/*      */   public void setMSIClientId(String msiClientId) {
/*  921 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.MSI_CLIENT_ID.toString(), msiClientId);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getMSIClientId() {
/*  926 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.MSI_CLIENT_ID.toString(), SQLServerDriverStringProperty.MSI_CLIENT_ID
/*  927 */         .getDefaultValue());
/*      */   }
/*      */ 
/*      */   
/*      */   public void setKeyVaultProviderClientId(String keyVaultProviderClientId) {
/*  932 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.KEY_VAULT_PROVIDER_CLIENT_ID.toString(), keyVaultProviderClientId);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getKeyVaultProviderClientId() {
/*  938 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.KEY_VAULT_PROVIDER_CLIENT_ID.toString(), SQLServerDriverStringProperty.KEY_VAULT_PROVIDER_CLIENT_ID
/*  939 */         .getDefaultValue());
/*      */   }
/*      */ 
/*      */   
/*      */   public void setKeyVaultProviderClientKey(String keyVaultProviderClientKey) {
/*  944 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.KEY_VAULT_PROVIDER_CLIENT_KEY.toString(), keyVaultProviderClientKey);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setKeyStorePrincipalId(String keyStorePrincipalId) {
/*  950 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.KEY_STORE_PRINCIPAL_ID.toString(), keyStorePrincipalId);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getKeyStorePrincipalId() {
/*  956 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.KEY_STORE_PRINCIPAL_ID.toString(), SQLServerDriverStringProperty.KEY_STORE_PRINCIPAL_ID
/*  957 */         .getDefaultValue());
/*      */   }
/*      */ 
/*      */   
/*      */   public String getDomain() {
/*  962 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.DOMAIN.toString(), SQLServerDriverStringProperty.DOMAIN
/*  963 */         .getDefaultValue());
/*      */   }
/*      */ 
/*      */   
/*      */   public void setDomain(String domain) {
/*  968 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.DOMAIN.toString(), domain);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getEnclaveAttestationUrl() {
/*  973 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.ENCLAVE_ATTESTATION_URL.toString(), SQLServerDriverStringProperty.ENCLAVE_ATTESTATION_URL
/*  974 */         .getDefaultValue());
/*      */   }
/*      */ 
/*      */   
/*      */   public void setEnclaveAttestationUrl(String url) {
/*  979 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.ENCLAVE_ATTESTATION_URL.toString(), url);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getEnclaveAttestationProtocol() {
/*  984 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.ENCLAVE_ATTESTATION_PROTOCOL.toString(), SQLServerDriverStringProperty.ENCLAVE_ATTESTATION_PROTOCOL
/*  985 */         .getDefaultValue());
/*      */   }
/*      */ 
/*      */   
/*      */   public void setEnclaveAttestationProtocol(String protocol) {
/*  990 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.ENCLAVE_ATTESTATION_PROTOCOL.toString(), protocol);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getClientCertificate() {
/*  996 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.CLIENT_CERTIFICATE.toString(), SQLServerDriverStringProperty.CLIENT_CERTIFICATE
/*  997 */         .getDefaultValue());
/*      */   }
/*      */ 
/*      */   
/*      */   public void setClientCertificate(String certPath) {
/* 1002 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.CLIENT_CERTIFICATE.toString(), certPath);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getClientKey() {
/* 1007 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.CLIENT_KEY.toString(), SQLServerDriverStringProperty.CLIENT_KEY
/* 1008 */         .getDefaultValue());
/*      */   }
/*      */ 
/*      */   
/*      */   public void setClientKey(String keyPath) {
/* 1013 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.CLIENT_KEY.toString(), keyPath);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setClientKeyPassword(String password) {
/* 1018 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.CLIENT_KEY_PASSWORD.toString(), password);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getAADSecurePrincipalId() {
/* 1023 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.AAD_SECURE_PRINCIPAL_ID.toString(), SQLServerDriverStringProperty.AAD_SECURE_PRINCIPAL_ID
/* 1024 */         .getDefaultValue());
/*      */   }
/*      */ 
/*      */   
/*      */   public void setAADSecurePrincipalId(String AADSecurePrincipalId) {
/* 1029 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.AAD_SECURE_PRINCIPAL_ID.toString(), AADSecurePrincipalId);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getAADSecurePrincipalSecret() {
/* 1035 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.AAD_SECURE_PRINCIPAL_SECRET.toString(), SQLServerDriverStringProperty.AAD_SECURE_PRINCIPAL_SECRET
/* 1036 */         .getDefaultValue());
/*      */   }
/*      */ 
/*      */   
/*      */   public void setAADSecurePrincipalSecret(String AADSecurePrincipalSecret) {
/* 1041 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.AAD_SECURE_PRINCIPAL_SECRET.toString(), AADSecurePrincipalSecret);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getSendTemporalDataTypesAsStringForBulkCopy() {
/* 1047 */     return getBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.SEND_TEMPORAL_DATATYPES_AS_STRING_FOR_BULK_COPY
/* 1048 */         .toString(), SQLServerDriverBooleanProperty.SEND_TEMPORAL_DATATYPES_AS_STRING_FOR_BULK_COPY
/* 1049 */         .getDefaultValue());
/*      */   }
/*      */ 
/*      */   
/*      */   public void setSendTemporalDataTypesAsStringForBulkCopy(boolean sendTemporalDataTypesAsStringForBulkCopy) {
/* 1054 */     setBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.SEND_TEMPORAL_DATATYPES_AS_STRING_FOR_BULK_COPY
/* 1055 */         .toString(), sendTemporalDataTypesAsStringForBulkCopy);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getMaxResultBuffer() {
/* 1061 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.MAX_RESULT_BUFFER.toString(), SQLServerDriverStringProperty.MAX_RESULT_BUFFER
/* 1062 */         .getDefaultValue());
/*      */   }
/*      */ 
/*      */   
/*      */   public void setMaxResultBuffer(String maxResultBuffer) {
/* 1067 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.MAX_RESULT_BUFFER.toString(), maxResultBuffer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setStringProperty(Properties props, String propKey, String propValue) {
/* 1080 */     if (loggerExternal.isLoggable(Level.FINER) && !propKey.contains("password") && 
/* 1081 */       !propKey.contains("Password")) {
/* 1082 */       loggerExternal.entering(getClassNameLogging(), "set" + propKey, propValue);
/*      */     } else {
/* 1084 */       loggerExternal.entering(getClassNameLogging(), "set" + propKey);
/* 1085 */     }  if (null != propValue)
/* 1086 */       props.setProperty(propKey, propValue); 
/* 1087 */     loggerExternal.exiting(getClassNameLogging(), "set" + propKey);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String getStringProperty(Properties props, String propKey, String defaultValue) {
/* 1100 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1101 */       loggerExternal.entering(getClassNameLogging(), "get" + propKey); 
/* 1102 */     String propValue = props.getProperty(propKey);
/* 1103 */     if (null == propValue)
/* 1104 */       propValue = defaultValue; 
/* 1105 */     if (loggerExternal.isLoggable(Level.FINER) && !propKey.contains("password") && 
/* 1106 */       !propKey.contains("Password"))
/* 1107 */       loggerExternal.exiting(getClassNameLogging(), "get" + propKey, propValue); 
/* 1108 */     return propValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setIntProperty(Properties props, String propKey, int propValue) {
/* 1120 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1121 */       loggerExternal.entering(getClassNameLogging(), "set" + propKey, Integer.valueOf(propValue)); 
/* 1122 */     props.setProperty(propKey, Integer.valueOf(propValue).toString());
/* 1123 */     loggerExternal.exiting(getClassNameLogging(), "set" + propKey);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int getIntProperty(Properties props, String propKey, int defaultValue) {
/* 1131 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1132 */       loggerExternal.entering(getClassNameLogging(), "get" + propKey); 
/* 1133 */     String propValue = props.getProperty(propKey);
/* 1134 */     int value = defaultValue;
/* 1135 */     if (null != propValue) {
/*      */       try {
/* 1137 */         value = Integer.parseInt(propValue);
/* 1138 */       } catch (NumberFormatException nfe) {
/*      */ 
/*      */         
/* 1141 */         assert false : "Bad portNumber:-" + propValue;
/*      */       } 
/*      */     }
/* 1144 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1145 */       loggerExternal.exiting(getClassNameLogging(), "get" + propKey, Integer.valueOf(value)); 
/* 1146 */     return value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setBooleanProperty(Properties props, String propKey, boolean propValue) {
/* 1153 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1154 */       loggerExternal.entering(getClassNameLogging(), "set" + propKey, Boolean.valueOf(propValue)); 
/* 1155 */     props.setProperty(propKey, propValue ? "true" : "false");
/* 1156 */     loggerExternal.exiting(getClassNameLogging(), "set" + propKey);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean getBooleanProperty(Properties props, String propKey, boolean defaultValue) {
/*      */     boolean value;
/* 1164 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1165 */       loggerExternal.entering(getClassNameLogging(), "get" + propKey); 
/* 1166 */     String propValue = props.getProperty(propKey);
/*      */     
/* 1168 */     if (null == propValue) {
/* 1169 */       value = defaultValue;
/*      */     }
/*      */     else {
/*      */       
/* 1173 */       value = Boolean.valueOf(propValue).booleanValue();
/*      */     } 
/* 1175 */     loggerExternal.exiting(getClassNameLogging(), "get" + propKey, Boolean.valueOf(value));
/* 1176 */     return value;
/*      */   }
/*      */   
/*      */   private void setObjectProperty(Properties props, String propKey, Object propValue) {
/* 1180 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 1181 */       loggerExternal.entering(getClassNameLogging(), "set" + propKey);
/*      */     }
/* 1183 */     if (null != propValue) {
/* 1184 */       props.put(propKey, propValue);
/*      */     }
/* 1186 */     loggerExternal.exiting(getClassNameLogging(), "set" + propKey);
/*      */   }
/*      */   
/*      */   private Object getObjectProperty(Properties props, String propKey, Object defaultValue) {
/* 1190 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1191 */       loggerExternal.entering(getClassNameLogging(), "get" + propKey); 
/* 1192 */     Object propValue = props.get(propKey);
/* 1193 */     if (null == propValue)
/* 1194 */       propValue = defaultValue; 
/* 1195 */     loggerExternal.exiting(getClassNameLogging(), "get" + propKey);
/* 1196 */     return propValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   SQLServerConnection getConnectionInternal(String username, String password, SQLServerPooledConnection pooledConnection) throws SQLServerException {
/*      */     Properties userSuppliedProps, mergedProps;
/* 1211 */     if (this.trustStorePasswordStripped) {
/* 1212 */       SQLServerException.makeFromDriverError(null, null, 
/* 1213 */           SQLServerException.getErrString("R_referencingFailedTSP"), null, true);
/*      */     }
/*      */ 
/*      */     
/* 1217 */     if (null != username || null != password) {
/* 1218 */       userSuppliedProps = (Properties)this.connectionProps.clone();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1223 */       userSuppliedProps.remove(SQLServerDriverStringProperty.USER.toString());
/* 1224 */       userSuppliedProps.remove(SQLServerDriverStringProperty.PASSWORD.toString());
/*      */       
/* 1226 */       if (null != username)
/* 1227 */         userSuppliedProps.put(SQLServerDriverStringProperty.USER.toString(), username); 
/* 1228 */       if (null != password)
/* 1229 */         userSuppliedProps.put(SQLServerDriverStringProperty.PASSWORD.toString(), password); 
/*      */     } else {
/* 1231 */       userSuppliedProps = this.connectionProps;
/*      */     } 
/*      */ 
/*      */     
/* 1235 */     if (null != this.dataSourceURL) {
/* 1236 */       Properties urlProps = Util.parseUrl(this.dataSourceURL, dsLogger);
/*      */ 
/*      */       
/* 1239 */       if (null == urlProps) {
/* 1240 */         SQLServerException.makeFromDriverError(null, null, 
/* 1241 */             SQLServerException.getErrString("R_errorConnectionString"), null, true);
/*      */       }
/* 1243 */       mergedProps = SQLServerDriver.mergeURLAndSuppliedProperties(urlProps, userSuppliedProps);
/*      */     } else {
/* 1245 */       mergedProps = userSuppliedProps;
/*      */     } 
/*      */ 
/*      */     
/* 1249 */     if (dsLogger.isLoggable(Level.FINER))
/* 1250 */       dsLogger.finer(toString() + " Begin create new connection."); 
/* 1251 */     SQLServerConnection result = null;
/* 1252 */     if (Util.use43Wrapper()) {
/* 1253 */       result = new SQLServerConnection43(toString());
/*      */     } else {
/* 1255 */       result = new SQLServerConnection(toString());
/*      */     } 
/* 1257 */     result.connect(mergedProps, pooledConnection);
/* 1258 */     if (dsLogger.isLoggable(Level.FINER))
/* 1259 */       dsLogger.finer(toString() + " End create new connection " + toString()); 
/* 1260 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reference getReference() {
/* 1267 */     loggerExternal.entering(getClassNameLogging(), "getReference");
/* 1268 */     Reference ref = getReferenceInternal("com.microsoft.sqlserver.jdbc.SQLServerDataSource");
/* 1269 */     loggerExternal.exiting(getClassNameLogging(), "getReference", ref);
/* 1270 */     return ref;
/*      */   }
/*      */   
/*      */   Reference getReferenceInternal(String dataSourceClassString) {
/* 1274 */     if (dsLogger.isLoggable(Level.FINER)) {
/* 1275 */       dsLogger.finer(toString() + " creating reference for " + toString() + ".");
/*      */     }
/* 1277 */     Reference ref = new Reference(getClass().getName(), "com.microsoft.sqlserver.jdbc.SQLServerDataSourceObjectFactory", null);
/*      */     
/* 1279 */     if (null != dataSourceClassString) {
/* 1280 */       ref.add(new StringRefAddr("class", dataSourceClassString));
/*      */     }
/* 1282 */     if (this.trustStorePasswordStripped) {
/* 1283 */       ref.add(new StringRefAddr("trustStorePasswordStripped", "true"));
/*      */     }
/*      */     
/* 1286 */     Enumeration<?> e = this.connectionProps.keys();
/* 1287 */     while (e.hasMoreElements()) {
/* 1288 */       String propertyName = (String)e.nextElement();
/*      */ 
/*      */       
/* 1291 */       if (propertyName.equals(SQLServerDriverStringProperty.TRUST_STORE_PASSWORD.toString())) {
/*      */ 
/*      */         
/* 1294 */         assert !this.trustStorePasswordStripped;
/* 1295 */         ref.add(new StringRefAddr("trustStorePasswordStripped", "true"));
/*      */         
/*      */         continue;
/*      */       } 
/* 1299 */       if (!propertyName.contains(SQLServerDriverStringProperty.PASSWORD.toString())) {
/* 1300 */         ref.add(new StringRefAddr(propertyName, this.connectionProps.getProperty(propertyName)));
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1306 */     if (null != this.dataSourceURL) {
/* 1307 */       ref.add(new StringRefAddr("dataSourceURL", this.dataSourceURL));
/*      */     }
/* 1309 */     if (null != this.dataSourceDescription) {
/* 1310 */       ref.add(new StringRefAddr("dataSourceDescription", this.dataSourceDescription));
/*      */     }
/* 1312 */     return ref;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void initializeFromReference(Reference ref) {
/* 1324 */     Enumeration<?> e = ref.getAll();
/* 1325 */     while (e.hasMoreElements()) {
/* 1326 */       StringRefAddr addr = (StringRefAddr)e.nextElement();
/* 1327 */       String propertyName = addr.getType();
/* 1328 */       String propertyValue = (String)addr.getContent();
/*      */ 
/*      */       
/* 1331 */       if ("dataSourceURL".equals(propertyName)) {
/* 1332 */         this.dataSourceURL = propertyValue; continue;
/* 1333 */       }  if ("dataSourceDescription".equals(propertyName)) {
/* 1334 */         this.dataSourceDescription = propertyValue; continue;
/* 1335 */       }  if ("trustStorePasswordStripped".equals(propertyName)) {
/* 1336 */         this.trustStorePasswordStripped = true;
/*      */         
/*      */         continue;
/*      */       } 
/* 1340 */       if (!"class".equals(propertyName))
/*      */       {
/* 1342 */         this.connectionProps.setProperty(propertyName, propertyValue);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isWrapperFor(Class<?> iface) throws SQLException {
/* 1349 */     loggerExternal.entering(getClassNameLogging(), "isWrapperFor", iface);
/* 1350 */     boolean f = iface.isInstance(this);
/* 1351 */     loggerExternal.exiting(getClassNameLogging(), "isWrapperFor", Boolean.valueOf(f));
/* 1352 */     return f;
/*      */   }
/*      */   
/*      */   public <T> T unwrap(Class<T> iface) throws SQLException {
/*      */     T t;
/* 1357 */     loggerExternal.entering(getClassNameLogging(), "unwrap", iface);
/*      */     
/*      */     try {
/* 1360 */       t = iface.cast(this);
/* 1361 */     } catch (ClassCastException e) {
/* 1362 */       throw new SQLServerException(e.getMessage(), e);
/*      */     } 
/* 1364 */     loggerExternal.exiting(getClassNameLogging(), "unwrap", t);
/* 1365 */     return t;
/*      */   }
/*      */ 
/*      */   
/*      */   private static int nextDataSourceID() {
/* 1370 */     return baseDataSourceID.incrementAndGet();
/*      */   }
/*      */   
/*      */   private Object writeReplace() throws ObjectStreamException {
/* 1374 */     return new SerializationProxy(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void readObject(ObjectInputStream stream) throws InvalidObjectException {
/* 1382 */     throw new InvalidObjectException("");
/*      */   }
/*      */ 
/*      */   
/*      */   private static class SerializationProxy
/*      */     implements Serializable
/*      */   {
/*      */     private final Reference ref;
/*      */     
/*      */     private static final long serialVersionUID = 654661379542314226L;
/*      */     
/*      */     SerializationProxy(SQLServerDataSource ds) {
/* 1394 */       this.ref = ds.getReferenceInternal(null);
/*      */     }
/*      */     
/*      */     private Object readResolve() {
/* 1398 */       SQLServerDataSource ds = new SQLServerDataSource();
/* 1399 */       ds.initializeFromReference(this.ref);
/* 1400 */       return ds;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerDataSource.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */