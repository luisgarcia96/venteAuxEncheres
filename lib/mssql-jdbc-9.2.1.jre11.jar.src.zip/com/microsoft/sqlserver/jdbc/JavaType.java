/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.sql.Blob;
/*     */ import java.sql.Clob;
/*     */ import java.sql.Date;
/*     */ import java.sql.NClob;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.time.LocalDate;
/*     */ import java.time.LocalDateTime;
/*     */ import java.time.LocalTime;
/*     */ import java.time.OffsetDateTime;
/*     */ import java.time.OffsetTime;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.EnumMap;
/*     */ import java.util.EnumSet;
/*     */ import microsoft.sql.DateTimeOffset;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ enum JavaType
/*     */ {
/*     */   private final Class<?> javaClass;
/*     */   private final JDBCType jdbcTypeFromJavaType;
/*     */   private static double jvmVersion;
/*     */   private static final JavaType[] VALUES;
/*     */   
/* 396 */   INTEGER(Integer.class, JDBCType.INTEGER),
/* 397 */   STRING(String.class, JDBCType.CHAR),
/* 398 */   DATE(Date.class, JDBCType.DATE),
/* 399 */   TIME(Time.class, JDBCType.TIME),
/* 400 */   TIMESTAMP(Timestamp.class, JDBCType.TIMESTAMP),
/* 401 */   UTILDATE(Date.class, JDBCType.TIMESTAMP),
/* 402 */   CALENDAR(Calendar.class, JDBCType.TIMESTAMP),
/* 403 */   LOCALDATE(getJavaClass("LocalDate"), JDBCType.DATE),
/* 404 */   LOCALTIME(getJavaClass("LocalTime"), JDBCType.TIME),
/* 405 */   LOCALDATETIME(getJavaClass("LocalDateTime"), JDBCType.TIMESTAMP),
/* 406 */   OFFSETTIME(getJavaClass("OffsetTime"), JDBCType.TIME_WITH_TIMEZONE),
/* 407 */   OFFSETDATETIME(getJavaClass("OffsetDateTime"), JDBCType.TIMESTAMP_WITH_TIMEZONE),
/* 408 */   DATETIMEOFFSET(DateTimeOffset.class, JDBCType.DATETIMEOFFSET),
/* 409 */   BOOLEAN(Boolean.class, JDBCType.BIT),
/* 410 */   BIGDECIMAL(BigDecimal.class, JDBCType.DECIMAL),
/* 411 */   DOUBLE(Double.class, JDBCType.DOUBLE),
/* 412 */   FLOAT(Float.class, JDBCType.REAL),
/* 413 */   SHORT(Short.class, JDBCType.SMALLINT),
/* 414 */   LONG(Long.class, JDBCType.BIGINT),
/* 415 */   BIGINTEGER(BigInteger.class, JDBCType.BIGINT),
/* 416 */   BYTE(Byte.class, JDBCType.TINYINT),
/* 417 */   BYTEARRAY(byte[].class, JDBCType.BINARY),
/*     */   
/* 419 */   NCLOB(NClob.class, JDBCType.NCLOB),
/* 420 */   CLOB(Clob.class, JDBCType.CLOB),
/* 421 */   BLOB(Blob.class, JDBCType.BLOB),
/* 422 */   TVP(TVP.class, JDBCType.TVP),
/* 423 */   GEOMETRY(Geometry.class, JDBCType.GEOMETRY),
/* 424 */   GEOGRAPHY(Geography.class, JDBCType.GEOGRAPHY),
/*     */   
/* 426 */   INPUTSTREAM(InputStream.class, JDBCType.UNKNOWN)
/*     */   {
/*     */     JDBCType getJDBCType(SSType ssType, JDBCType jdbcTypeFromApp)
/*     */     {
/*     */       JDBCType jdbcType;
/*     */ 
/*     */ 
/*     */       
/* 434 */       if (SSType.UNKNOWN != ssType) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 441 */         switch (ssType) {
/*     */           case CHAR:
/*     */           case VARCHAR:
/*     */           case VARCHARMAX:
/*     */           case TEXT:
/*     */           case NCHAR:
/*     */           case NVARCHAR:
/*     */           case NVARCHARMAX:
/*     */           case NTEXT:
/* 450 */             jdbcType = JDBCType.LONGVARCHAR;
/*     */             break;
/*     */ 
/*     */           
/*     */           default:
/* 455 */             jdbcType = JDBCType.LONGVARBINARY;
/*     */             break;
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       } else {
/* 465 */         jdbcType = jdbcTypeFromApp.isTextual() ? JDBCType.LONGVARCHAR : JDBCType.LONGVARBINARY;
/*     */       } 
/*     */       
/* 468 */       assert null != jdbcType;
/* 469 */       return jdbcType;
/*     */     }
/*     */   },
/*     */   
/* 473 */   READER(Reader.class, JDBCType.LONGVARCHAR),
/*     */   
/* 475 */   SQLXML(SQLServerSQLXML.class, JDBCType.SQLXML),
/* 476 */   OBJECT(Object.class, JDBCType.UNKNOWN);
/*     */ 
/*     */   
/*     */   static {
/* 480 */     jvmVersion = 0.0D;
/* 481 */     VALUES = values();
/*     */   }
/*     */   JavaType(Class<?> javaClass, JDBCType jdbcTypeFromJavaType) {
/* 484 */     this.javaClass = javaClass;
/* 485 */     this.jdbcTypeFromJavaType = jdbcTypeFromJavaType;
/*     */   }
/*     */   
/*     */   static Class<?> getJavaClass(String className) {
/* 489 */     if (0.0D == jvmVersion) {
/*     */       
/*     */       try {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 496 */         String jvmSpecVersion = System.getProperty("java.specification.version");
/* 497 */         if (jvmSpecVersion != null) {
/* 498 */           jvmVersion = Double.parseDouble(jvmSpecVersion);
/*     */         }
/* 500 */       } catch (NumberFormatException e) {
/*     */         
/* 502 */         jvmVersion = 0.1D;
/*     */       } 
/*     */     }
/*     */     
/* 506 */     if (jvmVersion < 1.8D) {
/* 507 */       return null;
/*     */     }
/*     */     
/* 510 */     switch (className) {
/*     */       case "LocalDate":
/* 512 */         return LocalDate.class;
/*     */       case "LocalTime":
/* 514 */         return LocalTime.class;
/*     */       case "LocalDateTime":
/* 516 */         return LocalDateTime.class;
/*     */       case "OffsetTime":
/* 518 */         return OffsetTime.class;
/*     */       case "OffsetDateTime":
/* 520 */         return OffsetDateTime.class;
/*     */     } 
/* 522 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   static JavaType of(Object obj) {
/* 527 */     if (obj instanceof SQLServerDataTable || obj instanceof java.sql.ResultSet || obj instanceof ISQLServerDataRecord)
/* 528 */       return TVP; 
/* 529 */     if (null != obj) {
/* 530 */       for (JavaType javaType : VALUES) {
/*     */ 
/*     */         
/* 533 */         if (null != javaType.javaClass && 
/* 534 */           javaType.javaClass.isInstance(obj)) {
/* 535 */           return javaType;
/*     */         }
/*     */       } 
/*     */     }
/* 539 */     return OBJECT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   JDBCType getJDBCType(SSType ssType, JDBCType jdbcTypeFromApp) {
/* 548 */     return this.jdbcTypeFromJavaType;
/*     */   }
/*     */   
/*     */   enum SetterConversionAE {
/* 552 */     BIT((String)JavaType.BOOLEAN, EnumSet.of(JDBCType.BIT, JDBCType.TINYINT, JDBCType.SMALLINT, JDBCType.INTEGER, JDBCType.BIGINT)),
/*     */ 
/*     */     
/* 555 */     SHORT((String)JavaType.SHORT, EnumSet.of(JDBCType.TINYINT, JDBCType.SMALLINT, JDBCType.INTEGER, JDBCType.BIGINT)),
/*     */     
/* 557 */     INTEGER((String)JavaType.INTEGER, EnumSet.of(JDBCType.INTEGER, JDBCType.BIGINT)),
/* 558 */     LONG((String)JavaType.LONG, EnumSet.of(JDBCType.BIGINT)),
/*     */     
/* 560 */     BIGDECIMAL((String)JavaType.BIGDECIMAL, EnumSet.of(JDBCType.MONEY, JDBCType.SMALLMONEY, JDBCType.DECIMAL, JDBCType.NUMERIC)),
/*     */ 
/*     */     
/* 563 */     BYTE((String)JavaType.BYTE, EnumSet.of(JDBCType.BINARY, JDBCType.VARBINARY, JDBCType.LONGVARBINARY, JDBCType.TINYINT)),
/*     */     
/* 565 */     BYTEARRAY((String)JavaType.BYTEARRAY, EnumSet.of(JDBCType.BINARY, JDBCType.VARBINARY, JDBCType.LONGVARBINARY)),
/*     */     
/* 567 */     DATE((String)JavaType.DATE, EnumSet.of(JDBCType.DATE)),
/*     */     
/* 569 */     DATETIMEOFFSET((String)JavaType.DATETIMEOFFSET, EnumSet.of(JDBCType.DATETIMEOFFSET)),
/*     */     
/* 571 */     DOUBLE((String)JavaType.DOUBLE, EnumSet.of(JDBCType.DOUBLE)),
/*     */     
/* 573 */     FLOAT((String)JavaType.FLOAT, EnumSet.of(JDBCType.REAL, JDBCType.DOUBLE)),
/*     */     
/* 575 */     STRING((String)JavaType.STRING, EnumSet.of(JDBCType.CHAR, new JDBCType[] { JDBCType.VARCHAR, JDBCType.LONGVARCHAR, JDBCType.NCHAR, JDBCType.NVARCHAR, JDBCType.LONGNVARCHAR, JDBCType.GUID
/*     */         
/*     */         })),
/* 578 */     TIME((String)JavaType.TIME, EnumSet.of(JDBCType.TIME)),
/*     */     
/* 580 */     TIMESTAMP((String)JavaType.TIMESTAMP, EnumSet.of(JDBCType.TIME, JDBCType.TIMESTAMP, JDBCType.DATETIME, JDBCType.SMALLDATETIME));
/*     */ 
/*     */     
/*     */     private final EnumSet<JDBCType> to;
/*     */     
/*     */     private final JavaType from;
/*     */     
/* 587 */     private static final SetterConversionAE[] VALUES = values();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 594 */     private static final EnumMap<JavaType, EnumSet<JDBCType>> setterConversionAEMap = new EnumMap<>(JavaType.class);
/*     */     
/*     */     static {
/* 597 */       for (JavaType javaType : JavaType.VALUES) {
/* 598 */         setterConversionAEMap.put(javaType, EnumSet.noneOf(JDBCType.class));
/*     */       }
/* 600 */       for (SetterConversionAE conversion : VALUES)
/* 601 */         ((EnumSet<JDBCType>)setterConversionAEMap.get(conversion.from)).addAll(conversion.to); 
/*     */     }
/*     */     
/*     */     static boolean converts(JavaType fromJavaType, JDBCType toJDBCType, boolean sendStringParametersAsUnicode) {
/* 605 */       if (null == fromJavaType || JavaType.OBJECT == fromJavaType)
/* 606 */         return true; 
/* 607 */       if (!sendStringParametersAsUnicode && fromJavaType == JavaType.BYTEARRAY && (toJDBCType == JDBCType.VARCHAR || toJDBCType == JDBCType.CHAR || toJDBCType == JDBCType.LONGVARCHAR))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 613 */         return true; } 
/* 614 */       if (!setterConversionAEMap.containsKey(fromJavaType))
/* 615 */         return false; 
/* 616 */       return ((EnumSet)setterConversionAEMap.get(fromJavaType)).contains(toJDBCType);
/*     */     }
/*     */     
/*     */     SetterConversionAE(JavaType from, EnumSet<JDBCType> to) {
/*     */       this.from = from;
/*     */       this.to = to;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\JavaType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */