/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import com.azure.core.credential.AccessToken;
/*     */ import com.azure.core.credential.TokenCredential;
/*     */ import com.azure.core.credential.TokenRequestContext;
/*     */ import com.microsoft.aad.msal4j.ClientCredentialFactory;
/*     */ import com.microsoft.aad.msal4j.ClientCredentialParameters;
/*     */ import com.microsoft.aad.msal4j.ConfidentialClientApplication;
/*     */ import com.microsoft.aad.msal4j.IAuthenticationResult;
/*     */ import com.microsoft.aad.msal4j.IClientCredential;
/*     */ import com.microsoft.aad.msal4j.IClientSecret;
/*     */ import com.microsoft.aad.msal4j.SilentParameters;
/*     */ import java.net.MalformedURLException;
/*     */ import java.text.MessageFormat;
/*     */ import java.time.OffsetDateTime;
/*     */ import java.time.ZoneOffset;
/*     */ import java.util.HashSet;
/*     */ import java.util.concurrent.CompletableFuture;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class KeyVaultTokenCredential
/*     */   implements TokenCredential
/*     */ {
/*     */   private static final String NULL_VALUE = "R_NullValue";
/*     */   private final String clientId;
/*     */   private final String clientSecret;
/*     */   private final SQLServerKeyVaultAuthenticationCallback authenticationCallback;
/*     */   private String authorization;
/*     */   private ConfidentialClientApplication confidentialClientApplication;
/*     */   private String resource;
/*     */   private String scope;
/*     */   
/*     */   KeyVaultTokenCredential(String clientId, String clientSecret) throws SQLServerException {
/*  52 */     if (null == clientId || clientId.isEmpty()) {
/*  53 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_NullValue"));
/*  54 */       Object[] msgArgs1 = { "Client ID" };
/*  55 */       throw new SQLServerException(form.format(msgArgs1), null);
/*     */     } 
/*     */     
/*  58 */     if (null == clientSecret || clientSecret.isEmpty()) {
/*  59 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_NullValue"));
/*  60 */       Object[] msgArgs1 = { "Client Secret" };
/*  61 */       throw new SQLServerException(form.format(msgArgs1), null);
/*     */     } 
/*     */     
/*  64 */     this.clientId = clientId;
/*  65 */     this.clientSecret = clientSecret;
/*  66 */     this.authenticationCallback = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   KeyVaultTokenCredential(SQLServerKeyVaultAuthenticationCallback authenticationCallback) {
/*  76 */     this.authenticationCallback = authenticationCallback;
/*  77 */     this.clientId = null;
/*  78 */     this.clientSecret = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Mono<AccessToken> getToken(TokenRequestContext request) {
/*  83 */     if (null != this.authenticationCallback) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  89 */       String accessToken = this.authenticationCallback.getAccessToken(this.authorization, this.resource, this.scope);
/*  90 */       return Mono.just(new AccessToken(accessToken, OffsetDateTime.MIN));
/*     */     } 
/*     */ 
/*     */     
/*  94 */     return authenticateWithConfidentialClientCache(request).onErrorResume(t -> Mono.empty())
/*  95 */       .switchIfEmpty(Mono.defer(() -> authenticateWithConfidentialClient(request)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   KeyVaultTokenCredential setAuthorization(String authorization) {
/* 106 */     if (null != this.authorization && this.authorization.equals(authorization)) {
/* 107 */       return this;
/*     */     }
/* 109 */     this.authorization = authorization;
/* 110 */     this.confidentialClientApplication = getConfidentialClientApplication();
/* 111 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ConfidentialClientApplication getConfidentialClientApplication() {
/* 120 */     if (null == this.clientId) {
/* 121 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_NullValue"));
/* 122 */       Object[] msgArgs1 = { "Client ID" };
/* 123 */       throw new IllegalArgumentException(form.format(msgArgs1), null);
/*     */     } 
/*     */     
/* 126 */     if (null == this.authorization) {
/* 127 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_NullValue"));
/* 128 */       Object[] msgArgs1 = { "Authorization" };
/* 129 */       throw new IllegalArgumentException(form.format(msgArgs1), null);
/*     */     } 
/*     */     
/* 132 */     if (null == this.clientSecret) {
/* 133 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_NullValue"));
/* 134 */       Object[] msgArgs1 = { "Client Secret" };
/* 135 */       throw new IllegalArgumentException(form.format(msgArgs1), null);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 140 */     IClientSecret iClientSecret = ClientCredentialFactory.createFromSecret(this.clientSecret);
/* 141 */     ConfidentialClientApplication.Builder applicationBuilder = ConfidentialClientApplication.builder(this.clientId, (IClientCredential)iClientSecret);
/*     */     
/*     */     try {
/* 144 */       applicationBuilder = (ConfidentialClientApplication.Builder)applicationBuilder.authority(this.authorization);
/* 145 */     } catch (MalformedURLException e) {
/* 146 */       throw new RuntimeException(e);
/*     */     } 
/* 148 */     return applicationBuilder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Mono<AccessToken> authenticateWithConfidentialClientCache(TokenRequestContext request) {
/* 160 */     return Mono.fromFuture(() -> {
/*     */           SilentParameters.SilentParametersBuilder parametersBuilder = SilentParameters.builder(new HashSet(request.getScopes()));
/*     */           
/*     */           try {
/*     */             return this.confidentialClientApplication.acquireTokenSilently(parametersBuilder.build());
/* 165 */           } catch (MalformedURLException e) {
/*     */             return getFailedCompletableFuture(new RuntimeException(e));
/*     */           } 
/* 168 */         }).map(ar -> new AccessToken(ar.accessToken(), OffsetDateTime.ofInstant(ar.expiresOnDate().toInstant(), ZoneOffset.UTC)))
/* 169 */       .filter(t -> !t.isExpired());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private CompletableFuture<IAuthenticationResult> getFailedCompletableFuture(Exception e) {
/* 180 */     CompletableFuture<IAuthenticationResult> completableFuture = new CompletableFuture<>();
/* 181 */     completableFuture.completeExceptionally(e);
/* 182 */     return completableFuture;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Mono<AccessToken> authenticateWithConfidentialClient(TokenRequestContext request) {
/* 193 */     return 
/* 194 */       Mono.fromFuture(() -> this.confidentialClientApplication.acquireToken(ClientCredentialParameters.builder(new HashSet(request.getScopes())).build()))
/*     */       
/* 196 */       .map(ar -> new AccessToken(ar.accessToken(), OffsetDateTime.ofInstant(ar.expiresOnDate().toInstant(), ZoneOffset.UTC)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setResource(String resource) {
/* 207 */     this.resource = resource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setScope(String scope) {
/* 217 */     this.scope = scope;
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\KeyVaultTokenCredential.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */