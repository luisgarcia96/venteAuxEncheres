/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Locale;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ enum ColumnEncryptionSetting
/*     */ {
/* 104 */   Enabled,
/* 105 */   Disabled;
/*     */   
/*     */   static ColumnEncryptionSetting valueOfString(String value) throws SQLServerException {
/* 108 */     ColumnEncryptionSetting method = null;
/*     */     
/* 110 */     if (value.toLowerCase(Locale.US).equalsIgnoreCase(Enabled.toString())) {
/* 111 */       method = Enabled;
/* 112 */     } else if (value.toLowerCase(Locale.US).equalsIgnoreCase(Disabled.toString())) {
/* 113 */       method = Disabled;
/*     */     } else {
/* 115 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_InvalidConnectionSetting"));
/* 116 */       Object[] msgArgs = { "columnEncryptionSetting", value };
/* 117 */       throw new SQLServerException(form.format(msgArgs), null);
/*     */     } 
/* 119 */     return method;
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\ColumnEncryptionSetting.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */