/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import com.azure.core.http.HttpPipeline;
/*    */ import com.azure.core.http.HttpPipelineBuilder;
/*    */ import com.azure.core.http.policy.HttpLogOptions;
/*    */ import com.azure.core.http.policy.HttpLoggingPolicy;
/*    */ import com.azure.core.http.policy.HttpPipelinePolicy;
/*    */ import com.azure.core.http.policy.HttpPolicyProviders;
/*    */ import com.azure.core.http.policy.RetryPolicy;
/*    */ import java.text.MessageFormat;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class KeyVaultHttpPipelineBuilder
/*    */ {
/* 35 */   private final RetryPolicy retryPolicy = new RetryPolicy();
/* 36 */   private HttpLogOptions httpLogOptions = new HttpLogOptions();
/* 37 */   private final List<HttpPipelinePolicy> policies = new ArrayList<>();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private KeyVaultTokenCredential credential;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   HttpPipeline buildPipeline() throws SQLServerException {
/* 48 */     List<HttpPipelinePolicy> policies = new ArrayList<>();
/*    */     
/* 50 */     HttpPolicyProviders.addBeforeRetryPolicies(policies);
/* 51 */     policies.add(this.retryPolicy);
/* 52 */     policies.add(new KeyVaultCustomCredentialPolicy(this.credential));
/* 53 */     policies.addAll(this.policies);
/* 54 */     HttpPolicyProviders.addAfterRetryPolicies(policies);
/* 55 */     policies.add(new HttpLoggingPolicy(this.httpLogOptions));
/*    */     
/* 57 */     return (new HttpPipelineBuilder()).policies(policies.<HttpPipelinePolicy>toArray(new HttpPipelinePolicy[0])).build();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   KeyVaultHttpPipelineBuilder credential(KeyVaultTokenCredential credential) throws SQLServerException {
/* 69 */     if (null == credential) {
/* 70 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_NullValue"));
/* 71 */       Object[] msgArgs1 = { "Credential" };
/* 72 */       throw new SQLServerException(form.format(msgArgs1), null);
/*    */     } 
/*    */     
/* 75 */     this.credential = credential;
/* 76 */     return this;
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\KeyVaultHttpPipelineBuilder.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */