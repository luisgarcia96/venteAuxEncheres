/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import java.util.logging.Level;
/*    */ import java.util.logging.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CacheClear
/*    */   implements Runnable
/*    */ {
/*    */   private String keylookupValue;
/* 24 */   private static Logger aeLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.CacheClear");
/*    */   
/*    */   CacheClear(String keylookupValue) {
/* 27 */     this.keylookupValue = keylookupValue;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void run() {
/* 34 */     synchronized (SQLServerSymmetricKeyCache.lock) {
/* 35 */       SQLServerSymmetricKeyCache instance = SQLServerSymmetricKeyCache.getInstance();
/* 36 */       if (instance.getCache().containsKey(this.keylookupValue)) {
/* 37 */         ((SQLServerSymmetricKey)instance.getCache().get(this.keylookupValue)).zeroOutKey();
/* 38 */         instance.getCache().remove(this.keylookupValue);
/* 39 */         if (aeLogger.isLoggable(Level.FINE))
/* 40 */           aeLogger.fine("Removed encryption key from cache..."); 
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\CacheClear.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */