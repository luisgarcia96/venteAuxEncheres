/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class StreamRetValue
/*    */   extends StreamPacket
/*    */ {
/*    */   private String paramName;
/*    */   private int ordinalOrLength;
/*    */   private int status;
/*    */   
/*    */   final int getOrdinalOrLength() {
/* 22 */     return this.ordinalOrLength;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   StreamRetValue() {
/* 33 */     super(172);
/*    */   }
/*    */   
/*    */   void setFromTDS(TDSReader tdsReader) throws SQLServerException {
/* 37 */     if (172 != tdsReader.readUnsignedByte() && 
/* 38 */       !$assertionsDisabled) throw new AssertionError(); 
/* 39 */     this.ordinalOrLength = tdsReader.readUnsignedShort();
/* 40 */     this.paramName = tdsReader.readUnicodeString(tdsReader.readUnsignedByte());
/* 41 */     this.status = tdsReader.readUnsignedByte();
/*    */   }
/*    */   
/*    */   CryptoMetadata getCryptoMetadata(TDSReader tdsReader) throws SQLServerException {
/* 45 */     CryptoMetadata cryptoMeta = (new StreamColumns()).readCryptoMetadata(tdsReader);
/* 46 */     return cryptoMeta;
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\StreamRetValue.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */