/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Deque;
/*     */ import java.util.List;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Objects;
/*     */ import java.util.Stack;
/*     */ import org.antlr.v4.runtime.Token;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SQLServerParser
/*     */ {
/*  22 */   private static final List<Integer> SELECT_DELIMITING_WORDS = Arrays.asList(new Integer[] { Integer.valueOf(8), 
/*  23 */         Integer.valueOf(10), Integer.valueOf(9), Integer.valueOf(11), Integer.valueOf(12) });
/*  24 */   private static final List<Integer> INSERT_DELIMITING_WORDS = Arrays.asList(new Integer[] { Integer.valueOf(14), 
/*  25 */         Integer.valueOf(15), Integer.valueOf(71), Integer.valueOf(1), Integer.valueOf(7), 
/*  26 */         Integer.valueOf(17), Integer.valueOf(19) });
/*  27 */   private static final List<Integer> DELETE_DELIMITING_WORDS = Arrays.asList(new Integer[] { Integer.valueOf(12), 
/*  28 */         Integer.valueOf(8), Integer.valueOf(15), Integer.valueOf(5) });
/*  29 */   private static final List<Integer> UPDATE_DELIMITING_WORDS = Arrays.asList(new Integer[] { Integer.valueOf(20), 
/*  30 */         Integer.valueOf(15), Integer.valueOf(8), Integer.valueOf(12) });
/*  31 */   private static final List<Integer> FROM_DELIMITING_WORDS = Arrays.asList(new Integer[] { Integer.valueOf(8), Integer.valueOf(10), 
/*  32 */         Integer.valueOf(9), Integer.valueOf(11), Integer.valueOf(12), Integer.valueOf(35) });
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void parseQuery(SQLServerTokenIterator iter, SQLServerFMTQuery query) throws SQLServerException {
/*  38 */     Token t = null;
/*  39 */     while (iter.hasNext()) {
/*  40 */       int parameterIndex; String columnName; t = iter.next();
/*  41 */       switch (t.getType()) {
/*     */         case 1:
/*  43 */           t = skipTop(iter);
/*  44 */           while (t.getType() != 78) {
/*  45 */             if (t.getType() == 89) {
/*  46 */               String str = findColumnAroundParameter(iter);
/*  47 */               query.getColumns().add(str);
/*     */             } 
/*  49 */             if (t.getType() == 5) {
/*  50 */               query.getTableTarget()
/*  51 */                 .add(getTableTargetChunk(iter, query.getAliases(), SELECT_DELIMITING_WORDS));
/*     */               break;
/*     */             } 
/*  54 */             if (iter.hasNext()) {
/*  55 */               t = iter.next();
/*     */             }
/*     */           } 
/*     */ 
/*     */ 
/*     */         
/*     */         case 2:
/*  62 */           t = skipTop(iter);
/*     */           
/*  64 */           if (t.getType() != 6) {
/*  65 */             t = iter.previous();
/*     */           }
/*  67 */           query.getTableTarget().add(getTableTargetChunk(iter, query.getAliases(), INSERT_DELIMITING_WORDS));
/*     */           
/*  69 */           if (iter.hasNext()) {
/*  70 */             List<String> tableValues = getValuesList(iter);
/*     */             
/*  72 */             boolean valuesFound = false;
/*  73 */             int valuesMarker = iter.nextIndex();
/*  74 */             while (!valuesFound && iter.hasNext()) {
/*  75 */               t = iter.next();
/*  76 */               if (t.getType() == 14) {
/*  77 */                 valuesFound = true;
/*     */                 do {
/*  79 */                   query.getValuesList().add(getValuesList(iter));
/*  80 */                 } while (iter.hasNext() && iter.next().getType() == 77);
/*  81 */                 iter.previous();
/*     */               } 
/*     */             } 
/*  84 */             if (!valuesFound) {
/*  85 */               resetIteratorIndex(iter, valuesMarker);
/*     */             }
/*  87 */             if (!query.getValuesList().isEmpty()) {
/*  88 */               for (List<String> ls : query.getValuesList()) {
/*  89 */                 if (tableValues.isEmpty()) {
/*  90 */                   query.getColumns().add("*");
/*     */                 }
/*  92 */                 for (int i = 0; i < ls.size(); i++) {
/*  93 */                   if ("?".equalsIgnoreCase(ls.get(i))) {
/*  94 */                     if (0 == tableValues.size()) {
/*  95 */                       query.getColumns().add("?");
/*     */                     }
/*  97 */                     else if (i < tableValues.size()) {
/*  98 */                       query.getColumns().add(tableValues.get(i));
/*     */                     } else {
/* 100 */                       SQLServerException.makeFromDriverError(null, null, 
/* 101 */                           SQLServerResource.getResource("R_invalidInsertValuesQuery"), null, false);
/*     */                     } 
/*     */                   }
/*     */                 } 
/*     */               } 
/*     */             }
/*     */           } 
/*     */ 
/*     */ 
/*     */         
/*     */         case 3:
/* 112 */           t = skipTop(iter);
/*     */           
/* 114 */           if (t.getType() != 5) {
/* 115 */             t = iter.previous();
/*     */           }
/* 117 */           query.getTableTarget().add(getTableTargetChunk(iter, query.getAliases(), DELETE_DELIMITING_WORDS));
/*     */         
/*     */         case 4:
/* 120 */           skipTop(iter);
/* 121 */           t = iter.previous();
/*     */           
/* 123 */           query.getTableTarget().add(getTableTargetChunk(iter, query.getAliases(), UPDATE_DELIMITING_WORDS));
/*     */         
/*     */         case 5:
/* 126 */           query.getTableTarget().add(getTableTargetChunk(iter, query.getAliases(), FROM_DELIMITING_WORDS));
/*     */         
/*     */         case 89:
/* 129 */           parameterIndex = iter.nextIndex();
/* 130 */           columnName = findColumnAroundParameter(iter);
/* 131 */           query.getColumns().add(columnName);
/* 132 */           resetIteratorIndex(iter, parameterIndex);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void resetIteratorIndex(SQLServerTokenIterator iter, int index) {
/* 142 */     if (iter.nextIndex() < index) {
/* 143 */       while (iter.nextIndex() != index) {
/* 144 */         iter.next();
/*     */       }
/* 146 */     } else if (iter.nextIndex() > index) {
/* 147 */       while (iter.nextIndex() != index) {
/* 148 */         iter.previous();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private static String getRoundBracketChunk(SQLServerTokenIterator iter) throws SQLServerException {
/* 154 */     StringBuilder sb = new StringBuilder();
/* 155 */     sb.append('(');
/* 156 */     Stack<String> s = new Stack<>();
/* 157 */     s.push("(");
/* 158 */     while (!s.empty() && iter.hasNext()) {
/* 159 */       Token t = iter.next();
/* 160 */       if (t.getType() == 72) {
/* 161 */         sb.append(")");
/* 162 */         s.pop(); continue;
/* 163 */       }  if (t.getType() == 71) {
/* 164 */         sb.append("(");
/* 165 */         s.push("("); continue;
/*     */       } 
/* 167 */       sb.append(t.getText()).append(" ");
/*     */     } 
/*     */     
/* 170 */     return sb.toString();
/*     */   }
/*     */   
/*     */   private static String getRoundBracketChunkBefore(SQLServerTokenIterator iter) {
/* 174 */     StringBuilder sb = new StringBuilder();
/* 175 */     sb.append('(');
/* 176 */     Stack<String> s = new Stack<>();
/* 177 */     s.push(")");
/* 178 */     while (!s.empty()) {
/* 179 */       Token t = iter.previous();
/* 180 */       if (t.getType() == 72) {
/* 181 */         sb.append("(");
/* 182 */         s.push(")"); continue;
/* 183 */       }  if (t.getType() == 71) {
/* 184 */         sb.append(")");
/* 185 */         s.pop(); continue;
/*     */       } 
/* 187 */       sb.append(t.getText()).append(" ");
/*     */     } 
/*     */     
/* 190 */     return sb.toString();
/*     */   }
/*     */   
/* 193 */   private static final List<Integer> OPERATORS = Arrays.asList(new Integer[] { Integer.valueOf(50), Integer.valueOf(51), 
/* 194 */         Integer.valueOf(52), Integer.valueOf(53), Integer.valueOf(54), Integer.valueOf(55), 
/* 195 */         Integer.valueOf(57), Integer.valueOf(58), Integer.valueOf(59), 
/* 196 */         Integer.valueOf(60), Integer.valueOf(61), Integer.valueOf(62), Integer.valueOf(63), 
/* 197 */         Integer.valueOf(64), Integer.valueOf(80), Integer.valueOf(81), Integer.valueOf(82), 
/* 198 */         Integer.valueOf(83), Integer.valueOf(84), Integer.valueOf(30), Integer.valueOf(31), Integer.valueOf(34) });
/*     */   
/*     */   static String findColumnAroundParameter(SQLServerTokenIterator iter) throws SQLServerException {
/* 201 */     int index = iter.nextIndex();
/* 202 */     iter.previous();
/* 203 */     String value = findColumnBeforeParameter(iter);
/* 204 */     resetIteratorIndex(iter, index);
/* 205 */     if ("".equalsIgnoreCase(value)) {
/* 206 */       value = findColumnAfterParameter(iter);
/* 207 */       resetIteratorIndex(iter, index);
/*     */     } 
/* 209 */     return value;
/*     */   }
/*     */   
/*     */   private static String findColumnAfterParameter(SQLServerTokenIterator iter) throws SQLServerException {
/* 213 */     StringBuilder sb = new StringBuilder();
/* 214 */     while (0 == sb.length() && iter.hasNext()) {
/* 215 */       Token t = iter.next();
/* 216 */       if (t.getType() == 33 && iter.hasNext()) {
/* 217 */         t = iter.next();
/*     */       }
/* 219 */       if (OPERATORS.contains(Integer.valueOf(t.getType())) && iter.hasNext()) {
/* 220 */         t = iter.next();
/* 221 */         if (t.getType() != 89) {
/* 222 */           if (t.getType() == 71) {
/* 223 */             sb.append(getRoundBracketChunk(iter));
/*     */           } else {
/* 225 */             sb.append(t.getText());
/*     */           } 
/* 227 */           for (int i = 0; i < 3 && iter.hasNext(); i++) {
/* 228 */             t = iter.next();
/* 229 */             if (t.getType() == 66) {
/* 230 */               sb.append(".");
/* 231 */               if (iter.hasNext()) {
/* 232 */                 t = iter.next();
/* 233 */                 sb.append(t.getText());
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         }  continue;
/*     */       } 
/* 239 */       return "";
/*     */     } 
/*     */     
/* 242 */     return sb.toString();
/*     */   }
/*     */   
/*     */   private static String findColumnBeforeParameter(SQLServerTokenIterator iter) {
/* 246 */     StringBuilder sb = new StringBuilder();
/* 247 */     while (0 == sb.length() && iter.hasPrevious()) {
/* 248 */       Token t = iter.previous();
/* 249 */       if (t.getType() == 70 && iter.hasPrevious()) {
/* 250 */         t = iter.previous();
/*     */       }
/* 252 */       if (t.getType() == 35 && iter.hasPrevious()) {
/* 253 */         t = iter.previous();
/* 254 */         if (iter.hasPrevious()) {
/* 255 */           t = iter.previous();
/* 256 */           if (t.getType() == 34 && iter.hasNext()) {
/* 257 */             iter.next();
/*     */             continue;
/*     */           } 
/* 260 */           return "";
/*     */         } 
/*     */       } 
/*     */       
/* 264 */       if (OPERATORS.contains(Integer.valueOf(t.getType())) && iter.hasPrevious()) {
/* 265 */         t = iter.previous();
/* 266 */         if (t.getType() == 33) {
/* 267 */           t = iter.previous();
/*     */         }
/* 269 */         if (t.getType() != 89) {
/* 270 */           Deque<String> d = new ArrayDeque<>();
/* 271 */           if (t.getType() == 72) {
/* 272 */             d.push(getRoundBracketChunkBefore(iter));
/*     */           } else {
/* 274 */             d.push(t.getText());
/*     */           } 
/*     */           
/* 277 */           for (int i = 0; i < 3 && iter.hasPrevious(); i++) {
/* 278 */             t = iter.previous();
/* 279 */             if (t.getType() == 66) {
/* 280 */               d.push(".");
/* 281 */               if (iter.hasPrevious()) {
/* 282 */                 t = iter.previous();
/* 283 */                 d.push(t.getText());
/*     */               } 
/*     */             } 
/*     */           } 
/* 287 */           Objects.requireNonNull(sb); d.stream().forEach(sb::append);
/*     */         }  continue;
/*     */       } 
/* 290 */       return "";
/*     */     } 
/*     */     
/* 293 */     return sb.toString();
/*     */   }
/*     */   
/*     */   static List<String> getValuesList(SQLServerTokenIterator iter) throws SQLServerException {
/* 297 */     Token t = iter.next();
/* 298 */     if (t.getType() == 71) {
/* 299 */       ArrayList<String> parameterColumns = new ArrayList<>();
/* 300 */       Deque<Integer> d = new ArrayDeque<>();
/* 301 */       StringBuilder sb = new StringBuilder();
/*     */       while (true) {
/* 303 */         switch (t.getType()) {
/*     */           case 71:
/* 305 */             if (!d.isEmpty()) {
/* 306 */               sb.append('(');
/*     */             }
/* 308 */             d.push(Integer.valueOf(71));
/*     */             break;
/*     */           case 72:
/* 311 */             if (((Integer)d.peek()).intValue() == 71) {
/* 312 */               d.pop();
/*     */             }
/* 314 */             if (!d.isEmpty()) {
/* 315 */               sb.append(')'); break;
/*     */             } 
/* 317 */             parameterColumns.add(sb.toString().trim());
/*     */             break;
/*     */           
/*     */           case 77:
/* 321 */             if (d.size() == 1) {
/* 322 */               parameterColumns.add(sb.toString().trim());
/* 323 */               sb = new StringBuilder(); break;
/*     */             } 
/* 325 */             sb.append(',');
/*     */             break;
/*     */           
/*     */           default:
/* 329 */             sb.append(t.getText());
/*     */             break;
/*     */         } 
/* 332 */         if (iter.hasNext() && !d.isEmpty()) {
/* 333 */           t = iter.next();
/* 334 */         } else if (!iter.hasNext() && !d.isEmpty()) {
/* 335 */           SQLServerException.makeFromDriverError(null, null, 
/* 336 */               SQLServerResource.getResource("R_invalidValuesList"), null, false);
/*     */         } 
/* 338 */         if (d.isEmpty())
/* 339 */           return parameterColumns; 
/*     */       } 
/* 341 */     }  iter.previous();
/* 342 */     return new ArrayList<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Token skipTop(SQLServerTokenIterator iter) throws SQLServerException {
/* 351 */     if (!iter.hasNext()) {
/* 352 */       SQLServerException.makeFromDriverError(null, null, SQLServerResource.getResource("R_invalidUserSQL"), null, false);
/*     */     }
/*     */     
/* 355 */     Token t = iter.next();
/* 356 */     if (t.getType() == 26) {
/* 357 */       t = iter.next();
/* 358 */       if (t.getType() == 71) {
/* 359 */         getRoundBracketChunk(iter);
/*     */       }
/* 361 */       t = iter.next();
/*     */ 
/*     */       
/* 364 */       if (t.getType() == 28) {
/* 365 */         t = iter.next();
/*     */       }
/*     */ 
/*     */       
/* 369 */       if (t.getType() == 17) {
/* 370 */         t = iter.next();
/* 371 */         if (t.getType() == 29) {
/* 372 */           t = iter.next();
/*     */         
/*     */         }
/*     */         else {
/*     */ 
/*     */           
/* 378 */           t = iter.previous();
/*     */         } 
/*     */       } 
/*     */     } 
/* 382 */     return t;
/*     */   }
/*     */   
/*     */   static String getCTE(SQLServerTokenIterator iter) throws SQLServerException {
/* 386 */     if (iter.hasNext()) {
/* 387 */       Token t = iter.next();
/* 388 */       if (t.getType() == 17) {
/* 389 */         StringBuilder sb = new StringBuilder("WITH ");
/* 390 */         getCTESegment(iter, sb);
/* 391 */         return sb.toString();
/*     */       } 
/* 393 */       iter.previous();
/*     */     } 
/*     */     
/* 396 */     return "";
/*     */   }
/*     */   
/*     */   static void getCTESegment(SQLServerTokenIterator iter, StringBuilder sb) throws SQLServerException {
/*     */     try {
/* 401 */       sb.append(getTableTargetChunk(iter, null, Arrays.asList(new Integer[] { Integer.valueOf(18) })));
/* 402 */       iter.next();
/* 403 */       Token t = iter.next();
/* 404 */       sb.append(" AS ");
/* 405 */       if (t.getType() != 71) {
/* 406 */         SQLServerException.makeFromDriverError(null, null, SQLServerResource.getResource("R_invalidCTEFormat"), null, false);
/*     */       }
/*     */       
/* 409 */       int leftRoundBracketCount = 0;
/*     */       do {
/* 411 */         sb.append(t.getText()).append(' ');
/* 412 */         if (t.getType() == 71) {
/* 413 */           leftRoundBracketCount++;
/* 414 */         } else if (t.getType() == 72) {
/* 415 */           leftRoundBracketCount--;
/*     */         } 
/* 417 */         t = iter.next();
/* 418 */       } while (leftRoundBracketCount > 0);
/*     */       
/* 420 */       if (t.getType() == 77) {
/* 421 */         sb.append(", ");
/* 422 */         getCTESegment(iter, sb);
/*     */       } else {
/* 424 */         iter.previous();
/*     */       } 
/* 426 */     } catch (NoSuchElementException e) {
/* 427 */       SQLServerException.makeFromDriverError(null, null, SQLServerResource.getResource("R_invalidCTEFormat"), null, false);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getTableTargetChunk(SQLServerTokenIterator iter, List<String> possibleAliases, List<Integer> delimiters) throws SQLServerException {
/* 434 */     StringBuilder sb = new StringBuilder();
/* 435 */     if (iter.hasNext()) {
/* 436 */       Token t = iter.next();
/*     */       while (true)
/* 438 */       { switch (t.getType()) {
/*     */           case 71:
/* 440 */             sb.append(getRoundBracketChunk(iter));
/*     */             break;
/*     */           case 21:
/*     */           case 22:
/*     */           case 23:
/*     */           case 24:
/*     */           case 25:
/* 447 */             sb.append(t.getText());
/* 448 */             t = iter.next();
/* 449 */             if (t.getType() != 71) {
/* 450 */               SQLServerException.makeFromDriverError(null, null, 
/* 451 */                   SQLServerResource.getResource("R_invalidOpenqueryCall"), null, false);
/*     */             }
/* 453 */             sb.append(getRoundBracketChunk(iter));
/*     */             break;
/*     */           case 18:
/* 456 */             sb.append(t.getText());
/* 457 */             if (iter.hasNext()) {
/* 458 */               String s = iter.next().getText();
/* 459 */               if (possibleAliases != null) {
/* 460 */                 possibleAliases.add(s);
/*     */               } else {
/* 462 */                 SQLServerException.makeFromDriverError(null, null, 
/* 463 */                     SQLServerResource.getResource("R_invalidCTEFormat"), null, false);
/*     */               } 
/* 465 */               sb.append(" ").append(s);
/*     */             } 
/*     */             break;
/*     */           default:
/* 469 */             sb.append(t.getText());
/*     */             break;
/*     */         } 
/* 472 */         if (iter.hasNext())
/* 473 */         { sb.append(' ');
/* 474 */           t = iter.next();
/*     */ 
/*     */ 
/*     */           
/* 478 */           if (delimiters.contains(Integer.valueOf(t.getType())) || t.getType() == 78)
/* 479 */             break;  continue; }  break; }  if (iter.hasNext()) {
/* 480 */         iter.previous();
/*     */       }
/*     */     } 
/* 483 */     return sb.toString().trim();
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerParser.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */