/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.sql.CallableStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLTimeoutException;
/*     */ import java.sql.Statement;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Properties;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.transaction.xa.XAException;
/*     */ import javax.transaction.xa.XAResource;
/*     */ import javax.transaction.xa.Xid;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SQLServerXAResource
/*     */   implements XAResource
/*     */ {
/*     */   private int timeoutSeconds;
/*     */   static final int XA_START = 0;
/*     */   static final int XA_END = 1;
/*     */   static final int XA_PREPARE = 2;
/*     */   static final int XA_COMMIT = 3;
/*     */   static final int XA_ROLLBACK = 4;
/*     */   static final int XA_FORGET = 5;
/*     */   static final int XA_RECOVER = 6;
/*     */   static final int XA_PREPARE_EX = 7;
/*     */   static final int XA_ROLLBACK_EX = 8;
/*     */   static final int XA_FORGET_EX = 9;
/*     */   static final int XA_INIT = 10;
/*     */   private SQLServerConnection controlConnection;
/*     */   private SQLServerConnection con;
/*     */   private boolean serverInfoRetrieved;
/*     */   private String version;
/*     */   private String instanceName;
/*     */   private int architectureMSSQL;
/*     */   private int architectureOS;
/*     */   private static boolean xaInitDone;
/*     */   private static final Object xaInitLock;
/*     */   private String sResourceManagerId;
/*     */   private int enlistedTransactionCount;
/*     */   private final Logger xaLogger;
/* 162 */   private static final AtomicInteger baseResourceID = new AtomicInteger(0);
/*     */   
/* 164 */   private int tightlyCoupled = 0;
/* 165 */   private int isTransacrionTimeoutSet = 0;
/*     */   
/*     */   public static final int SSTRANSTIGHTLYCPLD = 32768;
/* 168 */   private SQLServerCallableStatement[] xaStatements = new SQLServerCallableStatement[] { null, null, null, null, null, null, null, null, null, null };
/*     */ 
/*     */   
/*     */   private final String traceID;
/*     */   
/* 173 */   private int recoveryAttempt = 0;
/*     */   static {
/* 175 */     xaInitLock = new Object();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 180 */     return this.traceID;
/*     */   }
/*     */   
/*     */   SQLServerXAResource(SQLServerConnection original, SQLServerConnection control, String loginfo) {
/* 184 */     this.traceID = " XAResourceID:" + nextResourceID();
/*     */     
/* 186 */     this.xaLogger = SQLServerXADataSource.xaLogger;
/* 187 */     this.controlConnection = control;
/* 188 */     this.con = original;
/* 189 */     Properties p = original.activeConnectionProperties;
/* 190 */     if (p == null) {
/* 191 */       this.sResourceManagerId = "";
/*     */     } else {
/* 193 */       this
/*     */         
/* 195 */         .sResourceManagerId = p.getProperty(SQLServerDriverStringProperty.SERVER_NAME.toString()) + "." + p.getProperty(SQLServerDriverStringProperty.SERVER_NAME.toString()) + "." + p.getProperty(SQLServerDriverStringProperty.DATABASE_NAME.toString());
/*     */     } 
/* 197 */     if (this.xaLogger.isLoggable(Level.FINE)) {
/* 198 */       this.xaLogger.fine(toString() + " created by (" + toString() + ")");
/*     */     }
/*     */     
/* 201 */     this.serverInfoRetrieved = false;
/* 202 */     this.version = "0";
/* 203 */     this.instanceName = "";
/* 204 */     this.architectureMSSQL = 0;
/* 205 */     this.architectureOS = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   private synchronized SQLServerCallableStatement getXACallableStatementHandle(int number) throws SQLServerException {
/* 210 */     assert number >= 0 && number <= 9;
/* 211 */     assert number < this.xaStatements.length;
/* 212 */     if (null != this.xaStatements[number]) {
/* 213 */       return this.xaStatements[number];
/*     */     }
/* 215 */     CallableStatement CS = null;
/*     */     
/* 217 */     switch (number)
/*     */     { case 0:
/* 219 */         CS = this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_start(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 254 */         this.xaStatements[number] = (SQLServerCallableStatement)CS;
/* 255 */         return this.xaStatements[number];case 1: CS = this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_end(?, ?, ?, ?, ?, ?, ?)}"); this.xaStatements[number] = (SQLServerCallableStatement)CS; return this.xaStatements[number];case 2: CS = this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_prepare(?, ?, ?, ?, ?)}"); this.xaStatements[number] = (SQLServerCallableStatement)CS; return this.xaStatements[number];case 3: CS = this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_commit(?, ?, ?, ?, ?, ?)}"); this.xaStatements[number] = (SQLServerCallableStatement)CS; return this.xaStatements[number];case 4: CS = this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_rollback(?, ?, ?, ?, ?)}"); this.xaStatements[number] = (SQLServerCallableStatement)CS; return this.xaStatements[number];case 5: CS = this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_forget(?, ?, ?, ?, ?)}"); this.xaStatements[number] = (SQLServerCallableStatement)CS; return this.xaStatements[number];case 6: CS = this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_recover(?, ?, ?, ?)}"); this.xaStatements[number] = (SQLServerCallableStatement)CS; return this.xaStatements[number];case 7: CS = this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_prepare_ex(?, ?, ?, ?, ?, ?)}"); this.xaStatements[number] = (SQLServerCallableStatement)CS; return this.xaStatements[number];case 8: CS = this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_rollback_ex(?, ?, ?, ?, ?, ?)}"); this.xaStatements[number] = (SQLServerCallableStatement)CS; return this.xaStatements[number];case 9: CS = this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_forget_ex(?, ?, ?, ?, ?, ?)}"); this.xaStatements[number] = (SQLServerCallableStatement)CS; return this.xaStatements[number]; }  assert false : "Bad handle request:" + number; this.xaStatements[number] = (SQLServerCallableStatement)CS; return this.xaStatements[number];
/*     */   }
/*     */   
/*     */   private synchronized void closeXAStatements() throws SQLServerException {
/* 259 */     for (int i = 0; i < this.xaStatements.length; i++) {
/* 260 */       if (null != this.xaStatements[i]) {
/* 261 */         this.xaStatements[i].close();
/* 262 */         this.xaStatements[i] = null;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   final synchronized void close() throws SQLServerException {
/*     */     try {
/* 268 */       closeXAStatements();
/* 269 */     } catch (Exception e) {
/* 270 */       if (this.xaLogger.isLoggable(Level.WARNING)) {
/* 271 */         this.xaLogger.warning(toString() + "Closing exception ignored: " + toString());
/*     */       }
/*     */     } 
/* 274 */     if (null != this.controlConnection) {
/* 275 */       this.controlConnection.close();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private String flagsDisplay(int flags) {
/* 282 */     if (0 == flags) {
/* 283 */       return "TMNOFLAGS";
/*     */     }
/*     */     
/* 286 */     StringBuilder sb = new StringBuilder(100);
/*     */     
/* 288 */     if (0 != (0x800000 & flags)) {
/* 289 */       sb.append("TMENDRSCAN");
/*     */     }
/* 291 */     if (0 != (0x20000000 & flags)) {
/* 292 */       if (sb.length() > 0)
/* 293 */         sb.append("|"); 
/* 294 */       sb.append("TMFAIL");
/*     */     } 
/* 296 */     if (0 != (0x200000 & flags)) {
/* 297 */       if (sb.length() > 0)
/* 298 */         sb.append("|"); 
/* 299 */       sb.append("TMJOIN");
/*     */     } 
/* 301 */     if (0 != (0x40000000 & flags)) {
/* 302 */       if (sb.length() > 0)
/* 303 */         sb.append("|"); 
/* 304 */       sb.append("TMONEPHASE");
/*     */     } 
/* 306 */     if (0 != (0x8000000 & flags)) {
/* 307 */       if (sb.length() > 0)
/* 308 */         sb.append("|"); 
/* 309 */       sb.append("TMRESUME");
/*     */     } 
/* 311 */     if (0 != (0x1000000 & flags)) {
/* 312 */       if (sb.length() > 0)
/* 313 */         sb.append("|"); 
/* 314 */       sb.append("TMSTARTRSCAN");
/*     */     } 
/* 316 */     if (0 != (0x4000000 & flags)) {
/* 317 */       if (sb.length() > 0)
/* 318 */         sb.append("|"); 
/* 319 */       sb.append("TMSUCCESS");
/*     */     } 
/* 321 */     if (0 != (0x2000000 & flags)) {
/* 322 */       if (sb.length() > 0)
/* 323 */         sb.append("|"); 
/* 324 */       sb.append("TMSUSPEND");
/*     */     } 
/*     */     
/* 327 */     if (0 != (0x8000 & flags)) {
/* 328 */       if (sb.length() > 0)
/* 329 */         sb.append("|"); 
/* 330 */       sb.append("SSTRANSTIGHTLYCPLD");
/*     */     } 
/* 332 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   private String cookieDisplay(byte[] cookie) {
/* 337 */     return Util.byteToHexDisplayString(cookie);
/*     */   }
/*     */ 
/*     */   
/*     */   private String typeDisplay(int type) {
/* 342 */     switch (type) {
/*     */       case 0:
/* 344 */         return "XA_START";
/*     */       case 1:
/* 346 */         return "XA_END";
/*     */       case 2:
/* 348 */         return "XA_PREPARE";
/*     */       case 3:
/* 350 */         return "XA_COMMIT";
/*     */       case 4:
/* 352 */         return "XA_ROLLBACK";
/*     */       case 5:
/* 354 */         return "XA_FORGET";
/*     */       case 6:
/* 356 */         return "XA_RECOVER";
/*     */     } 
/* 358 */     return "UNKNOWN" + type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private XAReturnValue DTC_XA_Interface(int nType, Xid xid, int xaFlags) throws XAException {
/* 365 */     if (this.xaLogger.isLoggable(Level.FINER)) {
/* 366 */       this.xaLogger.finer(toString() + " Calling XA function for type:" + toString() + " flags:" + typeDisplay(nType) + " xid:" + 
/* 367 */           flagsDisplay(xaFlags));
/*     */     }
/* 369 */     int formatId = 0;
/* 370 */     byte[] gid = null;
/* 371 */     byte[] bid = null;
/* 372 */     if (xid != null) {
/* 373 */       formatId = xid.getFormatId();
/* 374 */       gid = xid.getGlobalTransactionId();
/* 375 */       bid = xid.getBranchQualifier();
/*     */     } 
/*     */     
/* 378 */     String sContext = "DTC_XA_";
/* 379 */     int n = 1;
/* 380 */     int nStatus = 0;
/* 381 */     XAReturnValue returnStatus = new XAReturnValue();
/*     */     
/* 383 */     SQLServerCallableStatement cs = null;
/*     */     try {
/* 385 */       synchronized (this) {
/* 386 */         if (!xaInitDone) {
/*     */           try {
/* 388 */             synchronized (xaInitLock) {
/* 389 */               SQLServerCallableStatement initCS = null;
/*     */ 
/*     */               
/* 392 */               initCS = (SQLServerCallableStatement)this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_init_ex(?, ?,?)}");
/* 393 */               initCS.registerOutParameter(1, 4);
/* 394 */               initCS.registerOutParameter(2, 1);
/* 395 */               initCS.registerOutParameter(3, 1);
/*     */               try {
/* 397 */                 initCS.execute();
/* 398 */               } catch (SQLServerException eX) {
/*     */                 try {
/* 400 */                   initCS.close();
/*     */                   
/* 402 */                   this.controlConnection.close();
/* 403 */                 } catch (SQLException e3) {
/*     */                   
/* 405 */                   if (this.xaLogger.isLoggable(Level.FINER)) {
/* 406 */                     this.xaLogger.finer(toString() + " Ignoring exception when closing failed execution. exception:" + toString());
/*     */                   }
/*     */                 } 
/* 409 */                 if (this.xaLogger.isLoggable(Level.FINER))
/* 410 */                   this.xaLogger.finer(toString() + " exception:" + toString()); 
/* 411 */                 throw eX;
/* 412 */               } catch (SQLTimeoutException e4) {
/* 413 */                 if (this.xaLogger.isLoggable(Level.FINER))
/* 414 */                   this.xaLogger.finer(toString() + " exception:" + toString()); 
/* 415 */                 throw new SQLServerException(e4.getMessage(), SQLState.STATEMENT_CANCELED, DriverError.NOT_SET, null);
/*     */               } 
/*     */ 
/*     */ 
/*     */               
/* 420 */               int initStatus = initCS.getInt(1);
/* 421 */               String initErr = initCS.getString(2);
/* 422 */               String versionNumberXADLL = initCS.getString(3);
/* 423 */               if (this.xaLogger.isLoggable(Level.FINE))
/* 424 */                 this.xaLogger.fine(toString() + " Server XA DLL version:" + toString()); 
/* 425 */               initCS.close();
/* 426 */               if (0 != initStatus) {
/* 427 */                 assert null != initErr && initErr.length() > 1;
/* 428 */                 this.controlConnection.close();
/*     */ 
/*     */                 
/* 431 */                 MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_failedToInitializeXA"));
/* 432 */                 Object[] msgArgs = { String.valueOf(initStatus), initErr };
/* 433 */                 XAException xex = new XAException(form.format(msgArgs));
/* 434 */                 xex.errorCode = initStatus;
/* 435 */                 if (this.xaLogger.isLoggable(Level.FINER))
/* 436 */                   this.xaLogger.finer(toString() + " exception:" + toString()); 
/* 437 */                 throw xex;
/*     */               } 
/*     */             } 
/* 440 */           } catch (SQLServerException e1) {
/*     */             
/* 442 */             MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_failedToCreateXAConnection"));
/* 443 */             Object[] msgArgs = { e1.getMessage() };
/* 444 */             if (this.xaLogger.isLoggable(Level.FINER))
/* 445 */               this.xaLogger.finer(toString() + " exception:" + toString()); 
/* 446 */             SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, form.format(msgArgs), (String)null, true);
/*     */           } 
/* 448 */           xaInitDone = true;
/*     */         } 
/*     */       } 
/*     */       
/* 452 */       switch (nType) {
/*     */         
/*     */         case 0:
/* 455 */           if (!this.serverInfoRetrieved) {
/* 456 */             String query = "select convert(varchar(100), SERVERPROPERTY('Edition'))as edition,  convert(varchar(100), SERVERPROPERTY('InstanceName'))as instance, convert(varchar(100), SERVERPROPERTY('ProductVersion')) as version, @@VERSION;";
/*     */             
/*     */             try {
/* 459 */               Statement stmt = this.controlConnection.createStatement(); 
/* 460 */               try { ResultSet rs = stmt.executeQuery(query); 
/* 461 */                 try { this.serverInfoRetrieved = true;
/* 462 */                   rs.next();
/*     */                   
/* 464 */                   String edition = rs.getString(1);
/* 465 */                   this.architectureMSSQL = (null != edition && edition.contains("(64-bit)")) ? 64 : 32;
/*     */ 
/*     */                   
/* 468 */                   this.instanceName = (rs.getString(2) == null) ? "MSSQLSERVER" : rs.getString(2);
/* 469 */                   this.version = rs.getString(3);
/* 470 */                   if (null == this.version) {
/* 471 */                     this.version = "0";
/* 472 */                   } else if (-1 != this.version.indexOf('.')) {
/* 473 */                     this.version = this.version.substring(0, this.version.indexOf('.'));
/*     */                   } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                   
/* 480 */                   String buildInfo = rs.getString(4);
/*     */                   
/* 482 */                   if (null != buildInfo && buildInfo.contains("Linux")) {
/* 483 */                     this.architectureOS = 64;
/* 484 */                   } else if (null != buildInfo) {
/* 485 */                     this.architectureOS = Integer.parseInt(buildInfo.substring(buildInfo.lastIndexOf('<') + 2, buildInfo
/* 486 */                           .lastIndexOf('>')));
/*     */                   } 
/* 488 */                   if (rs != null) rs.close();  } catch (Throwable throwable) { if (rs != null) try { rs.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  if (stmt != null) stmt.close();  } catch (Throwable throwable) { if (stmt != null)
/*     */                   try { stmt.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; } 
/* 490 */             } catch (Exception e) {
/* 491 */               if (this.xaLogger.isLoggable(Level.WARNING)) {
/* 492 */                 this.xaLogger.warning(
/* 493 */                     toString() + " Cannot retrieve server information: :" + toString());
/*     */               }
/*     */             } 
/*     */           } 
/* 497 */           sContext = "START:";
/* 498 */           cs = getXACallableStatementHandle(0);
/* 499 */           cs.registerOutParameter(n++, 4);
/* 500 */           cs.registerOutParameter(n++, 1);
/* 501 */           cs.setBytes(n++, gid);
/* 502 */           cs.setBytes(n++, bid);
/* 503 */           cs.setInt(n++, xaFlags);
/* 504 */           cs.registerOutParameter(n++, -2);
/* 505 */           cs.setInt(n++, this.timeoutSeconds);
/* 506 */           cs.setInt(n++, formatId);
/* 507 */           cs.registerOutParameter(n++, 1);
/* 508 */           cs.setInt(n++, Integer.parseInt(this.version));
/* 509 */           cs.setInt(n++, this.instanceName.length());
/* 510 */           cs.setBytes(n++, this.instanceName.getBytes());
/* 511 */           cs.setInt(n++, this.architectureMSSQL);
/* 512 */           cs.setInt(n++, this.architectureOS);
/* 513 */           cs.setInt(n++, this.isTransacrionTimeoutSet);
/* 514 */           cs.registerOutParameter(n++, -2);
/*     */           break;
/*     */ 
/*     */         
/*     */         case 1:
/* 519 */           sContext = "END:";
/* 520 */           cs = getXACallableStatementHandle(1);
/* 521 */           cs.registerOutParameter(n++, 4);
/* 522 */           cs.registerOutParameter(n++, 1);
/* 523 */           cs.setBytes(n++, gid);
/* 524 */           cs.setBytes(n++, bid);
/* 525 */           cs.setInt(n++, xaFlags);
/* 526 */           cs.setInt(n++, formatId);
/* 527 */           cs.registerOutParameter(n++, -2);
/*     */           break;
/*     */         
/*     */         case 2:
/* 531 */           sContext = "PREPARE:";
/* 532 */           if ((0x8000 & xaFlags) == 32768) {
/* 533 */             cs = getXACallableStatementHandle(7);
/*     */           } else {
/* 535 */             cs = getXACallableStatementHandle(2);
/*     */           } 
/* 537 */           cs.registerOutParameter(n++, 4);
/* 538 */           cs.registerOutParameter(n++, 1);
/* 539 */           cs.setBytes(n++, gid);
/* 540 */           cs.setBytes(n++, bid);
/* 541 */           if ((0x8000 & xaFlags) == 32768)
/* 542 */             cs.setInt(n++, xaFlags); 
/* 543 */           cs.setInt(n++, formatId);
/*     */           break;
/*     */         
/*     */         case 3:
/* 547 */           sContext = "COMMIT:";
/* 548 */           cs = getXACallableStatementHandle(3);
/* 549 */           cs.registerOutParameter(n++, 4);
/* 550 */           cs.registerOutParameter(n++, 1);
/* 551 */           cs.setBytes(n++, gid);
/* 552 */           cs.setBytes(n++, bid);
/* 553 */           cs.setInt(n++, xaFlags);
/* 554 */           cs.setInt(n++, formatId);
/*     */           break;
/*     */         
/*     */         case 4:
/* 558 */           sContext = "ROLLBACK:";
/* 559 */           if ((0x8000 & xaFlags) == 32768) {
/* 560 */             cs = getXACallableStatementHandle(8);
/*     */           } else {
/* 562 */             cs = getXACallableStatementHandle(4);
/*     */           } 
/* 564 */           cs.registerOutParameter(n++, 4);
/* 565 */           cs.registerOutParameter(n++, 1);
/* 566 */           cs.setBytes(n++, gid);
/* 567 */           cs.setBytes(n++, bid);
/* 568 */           if ((0x8000 & xaFlags) == 32768)
/* 569 */             cs.setInt(n++, xaFlags); 
/* 570 */           cs.setInt(n++, formatId);
/*     */           break;
/*     */         
/*     */         case 5:
/* 574 */           sContext = "FORGET:";
/* 575 */           if ((0x8000 & xaFlags) == 32768) {
/* 576 */             cs = getXACallableStatementHandle(9);
/*     */           } else {
/* 578 */             cs = getXACallableStatementHandle(5);
/* 579 */           }  cs.registerOutParameter(n++, 4);
/* 580 */           cs.registerOutParameter(n++, 1);
/* 581 */           cs.setBytes(n++, gid);
/* 582 */           cs.setBytes(n++, bid);
/* 583 */           if ((0x8000 & xaFlags) == 32768)
/* 584 */             cs.setInt(n++, xaFlags); 
/* 585 */           cs.setInt(n++, formatId);
/*     */           break;
/*     */         
/*     */         case 6:
/* 589 */           sContext = "RECOVER:";
/* 590 */           cs = getXACallableStatementHandle(6);
/* 591 */           cs.registerOutParameter(n++, 4);
/* 592 */           cs.registerOutParameter(n++, 1);
/* 593 */           cs.setInt(n++, xaFlags);
/* 594 */           cs.registerOutParameter(n++, -2);
/*     */           break;
/*     */         
/*     */         default:
/* 598 */           assert false : "Unknown execution type:" + nType;
/*     */           break;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 605 */       cs.execute();
/* 606 */       nStatus = cs.getInt(1);
/* 607 */       String sErr = cs.getString(2);
/* 608 */       if (nType == 0) {
/* 609 */         String versionNumberXADLL = cs.getString(9);
/* 610 */         if (this.xaLogger.isLoggable(Level.FINE)) {
/* 611 */           this.xaLogger.fine(toString() + " Server XA DLL version:" + toString());
/* 612 */           if (null != cs.getString(16)) {
/* 613 */             StringBuffer strBuf = new StringBuffer(cs.getString(16));
/* 614 */             strBuf.insert(20, '-');
/* 615 */             strBuf.insert(16, '-');
/* 616 */             strBuf.insert(12, '-');
/* 617 */             strBuf.insert(8, '-');
/* 618 */             this.xaLogger.fine(toString() + " XID to UoW mapping for XA type:XA_START XID: " + toString() + " UoW: " + 
/* 619 */                 XidImpl.xidDisplay(xid));
/*     */           } 
/*     */         } 
/*     */       } 
/* 623 */       if (nType == 1 && 
/* 624 */         this.xaLogger.isLoggable(Level.FINE) && 
/* 625 */         null != cs.getString(7)) {
/* 626 */         StringBuffer strBuf = new StringBuffer(cs.getString(7));
/* 627 */         strBuf.insert(20, '-');
/* 628 */         strBuf.insert(16, '-');
/* 629 */         strBuf.insert(12, '-');
/* 630 */         strBuf.insert(8, '-');
/* 631 */         this.xaLogger.fine(toString() + " XID to UoW mapping for XA type:XA_END XID: " + toString() + " UoW: " + 
/* 632 */             XidImpl.xidDisplay(xid));
/*     */       } 
/*     */ 
/*     */       
/* 636 */       if (6 == nType && 0 != nStatus && this.recoveryAttempt < 1) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 642 */         this.recoveryAttempt++;
/* 643 */         DTC_XA_Interface(0, xid, 0);
/* 644 */         return DTC_XA_Interface(6, xid, xaFlags);
/*     */       } 
/*     */ 
/*     */       
/* 648 */       if ((3 == nStatus && 1 != nType && 2 != nType) || (0 != nStatus && 3 != nStatus)) {
/*     */         
/* 650 */         assert null != sErr && sErr.length() > 1;
/* 651 */         MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_failedFunctionXA"));
/* 652 */         Object[] msgArgs = { sContext, String.valueOf(nStatus), sErr };
/* 653 */         XAException e = new XAException(form.format(msgArgs));
/* 654 */         e.errorCode = nStatus;
/*     */         
/* 656 */         if (nType == 1 && -7 == nStatus)
/*     */           try {
/* 658 */             if (this.xaLogger.isLoggable(Level.FINER))
/* 659 */               this.xaLogger.finer(toString() + " Begin un-enlist, enlisted count:" + toString()); 
/* 660 */             this.con.JTAUnenlistConnection();
/* 661 */             this.enlistedTransactionCount--;
/* 662 */             if (this.xaLogger.isLoggable(Level.FINER))
/* 663 */               this.xaLogger.finer(toString() + " End un-enlist, enlisted count:" + toString()); 
/* 664 */           } catch (SQLServerException e1) {
/*     */             
/* 666 */             if (this.xaLogger.isLoggable(Level.FINER)) {
/* 667 */               this.xaLogger.finer(toString() + " Ignoring exception:" + toString());
/*     */             }
/*     */           }  
/* 670 */         throw e;
/*     */       } 
/* 672 */       if (nType == 0) {
/*     */         
/* 674 */         byte[] transactionCookie = cs.getBytes(6);
/* 675 */         if (transactionCookie == null) {
/*     */           
/* 677 */           MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_noTransactionCookie"));
/* 678 */           Object[] msgArgs = { sContext };
/* 679 */           SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, form.format(msgArgs), (String)null, true);
/*     */         } else {
/*     */           
/*     */           try {
/* 683 */             if (this.xaLogger.isLoggable(Level.FINER)) {
/* 684 */               this.xaLogger.finer(
/* 685 */                   toString() + " Begin enlisting, cookie:" + toString() + " enlisted count:" + cookieDisplay(transactionCookie));
/*     */             }
/* 687 */             this.con.JTAEnlistConnection(transactionCookie);
/* 688 */             this.enlistedTransactionCount++;
/* 689 */             if (this.xaLogger.isLoggable(Level.FINER)) {
/* 690 */               this.xaLogger.finer(toString() + " End enlisting, cookie:" + toString() + " enlisted count:" + cookieDisplay(transactionCookie));
/*     */             }
/* 692 */           } catch (SQLServerException e1) {
/* 693 */             MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_failedToEnlist"));
/* 694 */             Object[] msgArgs = { e1.getMessage() };
/* 695 */             SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, form.format(msgArgs), (String)null, true);
/*     */           } 
/*     */         } 
/*     */       } 
/* 699 */       if (nType == 1) {
/*     */         try {
/* 701 */           if (this.xaLogger.isLoggable(Level.FINER))
/* 702 */             this.xaLogger.finer(toString() + " Begin un-enlist, enlisted count:" + toString()); 
/* 703 */           this.con.JTAUnenlistConnection();
/* 704 */           this.enlistedTransactionCount--;
/* 705 */           if (this.xaLogger.isLoggable(Level.FINER))
/* 706 */             this.xaLogger.finer(toString() + " End un-enlist, enlisted count:" + toString()); 
/* 707 */         } catch (SQLServerException e1) {
/* 708 */           MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_failedToUnEnlist"));
/* 709 */           Object[] msgArgs = { e1.getMessage() };
/* 710 */           SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, form.format(msgArgs), (String)null, true);
/*     */         } 
/*     */       }
/* 713 */       if (nType == 6) {
/*     */         
/*     */         try {
/*     */           
/* 717 */           returnStatus.bData = cs.getBytes(4);
/* 718 */         } catch (SQLServerException e1) {
/*     */           
/* 720 */           MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_failedToReadRecoveryXIDs"));
/* 721 */           Object[] msgArgs = { e1.getMessage() };
/* 722 */           SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, form.format(msgArgs), (String)null, true);
/*     */         }
/*     */       
/*     */       }
/* 726 */     } catch (SQLServerException|SQLTimeoutException ex) {
/* 727 */       if (this.xaLogger.isLoggable(Level.FINER))
/* 728 */         this.xaLogger.finer(toString() + " exception:" + toString()); 
/* 729 */       XAException e = new XAException(ex.toString());
/* 730 */       e.errorCode = -3;
/* 731 */       throw e;
/*     */     } 
/*     */     
/* 734 */     if (this.xaLogger.isLoggable(Level.FINER)) {
/* 735 */       this.xaLogger.finer(toString() + " Status:" + toString());
/*     */     }
/* 737 */     returnStatus.nStatus = nStatus;
/* 738 */     return returnStatus;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start(Xid xid, int flags) throws XAException {
/* 762 */     this.tightlyCoupled = flags & 0x8000;
/* 763 */     DTC_XA_Interface(0, xid, flags);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void end(Xid xid, int flags) throws XAException {
/* 778 */     DTC_XA_Interface(1, xid, flags | this.tightlyCoupled);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int prepare(Xid xid) throws XAException {
/* 789 */     int nStatus = 0;
/* 790 */     XAReturnValue r = DTC_XA_Interface(2, xid, this.tightlyCoupled);
/* 791 */     nStatus = r.nStatus;
/*     */     
/* 793 */     return nStatus;
/*     */   }
/*     */ 
/*     */   
/*     */   public void commit(Xid xid, boolean onePhase) throws XAException {
/* 798 */     DTC_XA_Interface(3, xid, (onePhase ? 1073741824 : 0) | this.tightlyCoupled);
/*     */   }
/*     */ 
/*     */   
/*     */   public void rollback(Xid xid) throws XAException {
/* 803 */     DTC_XA_Interface(4, xid, this.tightlyCoupled);
/*     */   }
/*     */ 
/*     */   
/*     */   public void forget(Xid xid) throws XAException {
/* 808 */     DTC_XA_Interface(5, xid, this.tightlyCoupled);
/*     */   }
/*     */ 
/*     */   
/*     */   public Xid[] recover(int flags) throws XAException {
/* 813 */     XAReturnValue r = DTC_XA_Interface(6, null, flags | this.tightlyCoupled);
/* 814 */     int offset = 0;
/* 815 */     ArrayList<XidImpl> al = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 826 */     if (null == r.bData) {
/* 827 */       return (Xid[])new XidImpl[0];
/*     */     }
/* 829 */     while (offset < r.bData.length) {
/* 830 */       int power = 1;
/* 831 */       int formatId = 0;
/* 832 */       for (int j = 0; j < 4; j++) {
/* 833 */         int x = r.bData[offset + j] & 0xFF;
/* 834 */         x *= power;
/* 835 */         formatId += x;
/* 836 */         power *= 256;
/*     */       } 
/*     */       
/*     */       try {
/* 840 */         offset += 4;
/* 841 */         int gid_len = r.bData[offset++] & 0xFF;
/* 842 */         int bid_len = r.bData[offset++] & 0xFF;
/* 843 */         byte[] gid = new byte[gid_len];
/* 844 */         byte[] bid = new byte[bid_len];
/* 845 */         System.arraycopy(r.bData, offset, gid, 0, gid_len);
/* 846 */         offset += gid_len;
/* 847 */         System.arraycopy(r.bData, offset, bid, 0, bid_len);
/* 848 */         offset += bid_len;
/* 849 */         XidImpl xid = new XidImpl(formatId, gid, bid);
/* 850 */         al.add(xid);
/* 851 */       } catch (ArrayIndexOutOfBoundsException e) {
/* 852 */         MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_indexOutOfRange"));
/* 853 */         Object[] msgArgs = { Integer.valueOf(offset) };
/* 854 */         XAException xex = new XAException(form.format(msgArgs));
/* 855 */         xex.errorCode = -3;
/* 856 */         if (this.xaLogger.isLoggable(Level.FINER))
/* 857 */           this.xaLogger.finer(toString() + " exception:" + toString()); 
/* 858 */         throw xex;
/*     */       } 
/*     */     } 
/*     */     
/* 862 */     XidImpl[] xids = new XidImpl[al.size()];
/* 863 */     for (int i = 0; i < al.size(); i++) {
/* 864 */       xids[i] = al.get(i);
/* 865 */       if (this.xaLogger.isLoggable(Level.FINER))
/* 866 */         this.xaLogger.finer(toString() + toString()); 
/*     */     } 
/* 868 */     return (Xid[])xids;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSameRM(XAResource xares) throws XAException {
/* 875 */     if (this.xaLogger.isLoggable(Level.FINER)) {
/* 876 */       this.xaLogger.finer(toString() + " xares:" + toString());
/*     */     }
/*     */     
/* 879 */     if (!(xares instanceof SQLServerXAResource))
/* 880 */       return false; 
/* 881 */     SQLServerXAResource jxa = (SQLServerXAResource)xares;
/* 882 */     return jxa.sResourceManagerId.equals(this.sResourceManagerId);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean setTransactionTimeout(int seconds) throws XAException {
/* 888 */     this.isTransacrionTimeoutSet = 1;
/* 889 */     this.timeoutSeconds = seconds;
/* 890 */     if (this.xaLogger.isLoggable(Level.FINER))
/* 891 */       this.xaLogger.finer(toString() + " TransactionTimeout:" + toString()); 
/* 892 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getTransactionTimeout() throws XAException {
/* 897 */     return this.timeoutSeconds;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int nextResourceID() {
/* 902 */     return baseResourceID.incrementAndGet();
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerXAResource.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */