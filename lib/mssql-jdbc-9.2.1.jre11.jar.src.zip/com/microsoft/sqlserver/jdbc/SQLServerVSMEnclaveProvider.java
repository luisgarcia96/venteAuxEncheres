/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.security.GeneralSecurityException;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SQLServerVSMEnclaveProvider
/*     */   implements ISQLServerEnclaveProvider
/*     */ {
/*  42 */   private static EnclaveSessionCache enclaveCache = new EnclaveSessionCache();
/*     */   
/*  44 */   private VSMAttestationParameters vsmParams = null;
/*  45 */   private VSMAttestationResponse hgsResponse = null;
/*  46 */   private String attestationUrl = null;
/*  47 */   private EnclaveSession enclaveSession = null;
/*     */ 
/*     */   
/*     */   public void getAttestationParameters(String url) throws SQLServerException {
/*  51 */     if (null == this.vsmParams) {
/*  52 */       this.attestationUrl = url;
/*  53 */       this.vsmParams = new VSMAttestationParameters();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayList<byte[]> createEnclaveSession(SQLServerConnection connection, String userSql, String preparedTypeDefinitions, Parameter[] params, ArrayList<String> parameterNames) throws SQLServerException {
/*  63 */     StringBuilder keyLookup = (new StringBuilder(connection.getServerName())).append(connection.getCatalog()).append(this.attestationUrl);
/*  64 */     EnclaveCacheEntry entry = enclaveCache.getSession(keyLookup.toString());
/*  65 */     if (null != entry) {
/*  66 */       this.enclaveSession = entry.getEnclaveSession();
/*  67 */       this.vsmParams = (VSMAttestationParameters)entry.getBaseAttestationRequest();
/*     */     } 
/*  69 */     ArrayList<byte[]> b = describeParameterEncryption(connection, userSql, preparedTypeDefinitions, params, parameterNames);
/*     */     
/*  71 */     if (connection.enclaveEstablished())
/*  72 */       return b; 
/*  73 */     if (null != this.hgsResponse && !connection.enclaveEstablished()) {
/*     */       
/*     */       try {
/*     */         
/*  77 */         this
/*  78 */           .enclaveSession = new EnclaveSession(this.hgsResponse.getSessionID(), this.vsmParams.createSessionSecret(this.hgsResponse.getDHpublicKey()));
/*  79 */         enclaveCache.addEntry(connection.getServerName(), connection.getCatalog(), connection.enclaveAttestationUrl, this.vsmParams, this.enclaveSession);
/*     */       }
/*  81 */       catch (GeneralSecurityException e) {
/*  82 */         SQLServerException.makeFromDriverError(connection, this, e.getLocalizedMessage(), "0", false);
/*     */       } 
/*     */     }
/*  85 */     return b;
/*     */   }
/*     */ 
/*     */   
/*     */   public void invalidateEnclaveSession() {
/*  90 */     if (null != this.enclaveSession) {
/*  91 */       enclaveCache.removeEntry(this.enclaveSession);
/*     */     }
/*  93 */     this.enclaveSession = null;
/*  94 */     this.vsmParams = null;
/*  95 */     this.attestationUrl = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public EnclaveSession getEnclaveSession() {
/* 100 */     return this.enclaveSession;
/*     */   }
/*     */   
/*     */   private void validateAttestationResponse() throws SQLServerException {
/* 104 */     if (null != this.hgsResponse) {
/*     */       try {
/* 106 */         byte[] attestationCerts = getAttestationCertificates();
/* 107 */         this.hgsResponse.validateCert(attestationCerts);
/* 108 */         this.hgsResponse.validateStatementSignature();
/* 109 */         this.hgsResponse.validateDHPublicKey();
/* 110 */       } catch (IOException|GeneralSecurityException e) {
/* 111 */         SQLServerException.makeFromDriverError(null, this, e.getLocalizedMessage(), "0", false);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/* 116 */   private static Hashtable<String, X509CertificateEntry> certificateCache = new Hashtable<>();
/*     */   
/*     */   private byte[] getAttestationCertificates() throws IOException {
/* 119 */     byte[] certData = null;
/* 120 */     X509CertificateEntry cacheEntry = certificateCache.get(this.attestationUrl);
/* 121 */     if (null != cacheEntry && !cacheEntry.expired()) {
/* 122 */       certData = cacheEntry.getCertificates();
/* 123 */     } else if (null != cacheEntry && cacheEntry.expired()) {
/* 124 */       certificateCache.remove(this.attestationUrl);
/*     */     } 
/*     */     
/* 127 */     if (null == certData) {
/* 128 */       URL url = new URL(this.attestationUrl + "/attestationservice.svc/v2.0/signingCertificates/");
/* 129 */       URLConnection con = url.openConnection();
/* 130 */       byte[] buff = new byte[con.getInputStream().available()];
/* 131 */       con.getInputStream().read(buff, 0, buff.length);
/* 132 */       String s = new String(buff);
/*     */       
/* 134 */       String[] bytesString = s.substring(1, s.length() - 1).split(",");
/* 135 */       certData = new byte[bytesString.length];
/* 136 */       for (int i = 0; i < certData.length; i++) {
/* 137 */         certData[i] = (byte)Integer.parseInt(bytesString[i]);
/*     */       }
/* 139 */       certificateCache.put(this.attestationUrl, new X509CertificateEntry(certData));
/*     */     } 
/* 141 */     return certData;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ArrayList<byte[]> describeParameterEncryption(SQLServerConnection connection, String userSql, String preparedTypeDefinitions, Parameter[] params, ArrayList<String> parameterNames) throws SQLServerException {
/* 147 */     ArrayList<byte[]> enclaveRequestedCEKs = (ArrayList)new ArrayList<>(); 
/* 148 */     try { PreparedStatement stmt = connection.prepareStatement(connection.enclaveEstablished() ? "EXEC sp_describe_parameter_encryption ?,?" : "EXEC sp_describe_parameter_encryption ?,?,?");
/*     */       
/* 150 */       try { ResultSet rs = connection.enclaveEstablished() ? executeSDPEv1(stmt, userSql, preparedTypeDefinitions) : executeSDPEv2(stmt, userSql, preparedTypeDefinitions, this.vsmParams); 
/* 151 */         try { if (null == rs)
/*     */           
/*     */           { 
/* 154 */             ArrayList<byte[]> arrayList = enclaveRequestedCEKs;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 171 */             if (rs != null) rs.close(); 
/* 172 */             if (stmt != null) stmt.close();  return arrayList; }  processSDPEv1(userSql, preparedTypeDefinitions, params, parameterNames, connection, stmt, rs, enclaveRequestedCEKs); if (connection.isAEv2() && stmt.getMoreResults()) { ResultSet hgsRs = stmt.getResultSet(); try { if (hgsRs.next()) { this.hgsResponse = new VSMAttestationResponse(hgsRs.getBytes(1)); validateAttestationResponse(); } else { SQLServerException.makeFromDriverError(null, this, SQLServerException.getErrString("R_UnableRetrieveParameterMetadata"), "0", false); }  if (hgsRs != null) hgsRs.close();  } catch (Throwable throwable) { if (hgsRs != null) try { hgsRs.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  }  if (rs != null) rs.close();  } catch (Throwable throwable) { if (rs != null) try { rs.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  if (stmt != null) stmt.close();  } catch (Throwable throwable) { if (stmt != null) try { stmt.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException|IOException e)
/* 173 */     { if (e instanceof SQLServerException) {
/* 174 */         throw (SQLServerException)e;
/*     */       }
/* 176 */       throw new SQLServerException(SQLServerException.getErrString("R_UnableRetrieveParameterMetadata"), null, 0, e); }
/*     */ 
/*     */ 
/*     */     
/* 180 */     return enclaveRequestedCEKs;
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerVSMEnclaveProvider.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */