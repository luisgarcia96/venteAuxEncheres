/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import javax.security.auth.login.AppConfigurationEntry;
/*    */ import javax.security.auth.login.Configuration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JaasConfiguration
/*    */   extends Configuration
/*    */ {
/*    */   private final Configuration delegate;
/*    */   private AppConfigurationEntry[] defaultValue;
/*    */   
/*    */   private static AppConfigurationEntry[] generateDefaultConfiguration() {
/* 23 */     if (Util.isIBM()) {
/* 24 */       Map<String, String> confDetailsWithoutPassword = new HashMap<>();
/* 25 */       confDetailsWithoutPassword.put("useDefaultCcache", "true");
/* 26 */       Map<String, String> confDetailsWithPassword = new HashMap<>();
/*    */ 
/*    */ 
/*    */       
/* 30 */       String ibmLoginModule = "com.ibm.security.auth.module.Krb5LoginModule";
/* 31 */       return new AppConfigurationEntry[] { new AppConfigurationEntry("com.ibm.security.auth.module.Krb5LoginModule", AppConfigurationEntry.LoginModuleControlFlag.SUFFICIENT, confDetailsWithoutPassword), new AppConfigurationEntry("com.ibm.security.auth.module.Krb5LoginModule", AppConfigurationEntry.LoginModuleControlFlag.SUFFICIENT, confDetailsWithPassword) };
/*    */     } 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 37 */     Map<String, String> confDetails = new HashMap<>();
/* 38 */     confDetails.put("useTicketCache", "true");
/* 39 */     return new AppConfigurationEntry[] { new AppConfigurationEntry("com.sun.security.auth.module.Krb5LoginModule", AppConfigurationEntry.LoginModuleControlFlag.REQUIRED, confDetails) };
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   JaasConfiguration(Configuration delegate) {
/* 52 */     this.delegate = delegate;
/* 53 */     this.defaultValue = generateDefaultConfiguration();
/*    */   }
/*    */ 
/*    */   
/*    */   public AppConfigurationEntry[] getAppConfigurationEntry(String name) {
/* 58 */     AppConfigurationEntry[] conf = (this.delegate == null) ? null : this.delegate.getAppConfigurationEntry(name);
/*    */ 
/*    */     
/* 61 */     if (conf == null && name.equals(SQLServerDriverStringProperty.JAAS_CONFIG_NAME.getDefaultValue())) {
/* 62 */       return this.defaultValue;
/*    */     }
/* 64 */     return conf;
/*    */   }
/*    */ 
/*    */   
/*    */   public void refresh() {
/* 69 */     if (null != this.delegate)
/* 70 */       this.delegate.refresh(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\JaasConfiguration.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */