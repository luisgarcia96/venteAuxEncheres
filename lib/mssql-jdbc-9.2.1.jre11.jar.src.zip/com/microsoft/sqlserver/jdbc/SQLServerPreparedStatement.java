/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.BatchUpdateException;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Date;
/*      */ import java.sql.NClob;
/*      */ import java.sql.ParameterMetaData;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.RowId;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLTimeoutException;
/*      */ import java.sql.SQLType;
/*      */ import java.sql.SQLXML;
/*      */ import java.sql.Statement;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.HashMap;
/*      */ import java.util.Map;
/*      */ import java.util.Objects;
/*      */ import java.util.Vector;
/*      */ import java.util.logging.Level;
/*      */ import microsoft.sql.DateTimeOffset;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class SQLServerPreparedStatement
/*      */   extends SQLServerStatement
/*      */   implements ISQLServerPreparedStatement
/*      */ {
/*      */   private static final long serialVersionUID = -6292257029445685221L;
/*      */   private static final int BATCH_STATEMENT_DELIMITER_TDS_71 = 128;
/*      */   private static final int BATCH_STATEMENT_DELIMITER_TDS_72 = 255;
/*   59 */   final int nBatchStatementDelimiter = 255;
/*      */ 
/*      */ 
/*      */   
/*      */   private String preparedTypeDefinitions;
/*      */ 
/*      */ 
/*      */   
/*      */   final String userSQL;
/*      */ 
/*      */ 
/*      */   
/*      */   final int[] userSQLParamPositions;
/*      */ 
/*      */   
/*      */   private String preparedSQL;
/*      */ 
/*      */   
/*      */   private boolean isExecutedAtLeastOnce = false;
/*      */ 
/*      */   
/*      */   private SQLServerConnection.PreparedStatementHandle cachedPreparedStatementHandle;
/*      */ 
/*      */   
/*      */   private SQLServerConnection.CityHash128Key sqlTextCacheKey;
/*      */ 
/*      */   
/*      */   private ArrayList<String> parameterNames;
/*      */ 
/*      */   
/*      */   final boolean bReturnValueSyntax;
/*      */ 
/*      */   
/*   92 */   private boolean useFmtOnly = this.connection.getUseFmtOnly();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int outParamIndexAdjustment;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ArrayList<Parameter[]> batchParamValues;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  107 */   private int prepStmtHandle = 0;
/*      */ 
/*      */   
/*  110 */   private SQLServerStatement internalStmt = null; private boolean useBulkCopyForBatchInsert;
/*      */   
/*      */   private void setPreparedStatementHandle(int handle) {
/*  113 */     this.prepStmtHandle = handle;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean getUseBulkCopyForBatchInsert() throws SQLServerException {
/*  130 */     checkClosed();
/*  131 */     return this.useBulkCopyForBatchInsert;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setUseBulkCopyForBatchInsert(boolean useBulkCopyForBatchInsert) throws SQLServerException {
/*  144 */     checkClosed();
/*  145 */     this.useBulkCopyForBatchInsert = useBulkCopyForBatchInsert;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getPreparedStatementHandle() throws SQLServerException {
/*  150 */     checkClosed();
/*  151 */     return this.prepStmtHandle;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean hasPreparedStatementHandle() {
/*  160 */     return (0 < this.prepStmtHandle);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean resetPrepStmtHandle(boolean discardCurrentCacheItem) {
/*  167 */     boolean statementPoolingUsed = (null != this.cachedPreparedStatementHandle);
/*      */     
/*  169 */     if (statementPoolingUsed)
/*      */     {
/*  171 */       if (discardCurrentCacheItem)
/*  172 */         this.cachedPreparedStatementHandle.setIsExplicitlyDiscarded(); 
/*      */     }
/*  174 */     this.prepStmtHandle = 0;
/*  175 */     return statementPoolingUsed;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean expectPrepStmtHandle = false;
/*      */ 
/*      */   
/*      */   private boolean encryptionMetadataIsRetrieved = false;
/*      */ 
/*      */   
/*      */   private String localUserSQL;
/*      */   
/*  188 */   private Vector<CryptoMetadata> cryptoMetaBatch = new Vector<>();
/*      */   private ArrayList<byte[]> enclaveCEKs;
/*      */   
/*      */   String getClassNameInternal() {
/*  192 */     return "SQLServerPreparedStatement";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   SQLServerPreparedStatement(SQLServerConnection conn, String sql, int nRSType, int nRSConcur, SQLServerStatementColumnEncryptionSetting stmtColEncSetting) throws SQLServerException {
/*  213 */     super(conn, nRSType, nRSConcur, stmtColEncSetting);
/*      */     
/*  215 */     if (null == sql) {
/*  216 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_NullValue"));
/*  217 */       Object[] msgArgs1 = { "Statement SQL" };
/*  218 */       throw new SQLServerException(form.format(msgArgs1), null);
/*      */     } 
/*      */     
/*  221 */     this.stmtPoolable = true;
/*      */ 
/*      */     
/*  224 */     this.sqlTextCacheKey = new SQLServerConnection.CityHash128Key(sql);
/*      */ 
/*      */     
/*  227 */     ParsedSQLCacheItem parsedSQL = SQLServerConnection.getCachedParsedSQL(this.sqlTextCacheKey);
/*  228 */     if (null != parsedSQL) {
/*  229 */       if (null != this.connection && this.connection.isStatementPoolingEnabled()) {
/*  230 */         this.isExecutedAtLeastOnce = true;
/*      */       }
/*      */     } else {
/*  233 */       parsedSQL = SQLServerConnection.parseAndCacheSQL(this.sqlTextCacheKey, sql);
/*      */     } 
/*      */ 
/*      */     
/*  237 */     this.procedureName = parsedSQL.procedureName;
/*  238 */     this.bReturnValueSyntax = parsedSQL.bReturnValueSyntax;
/*  239 */     this.userSQL = parsedSQL.processedSQL;
/*  240 */     this.userSQLParamPositions = parsedSQL.parameterPositions;
/*  241 */     initParams(this.userSQLParamPositions.length);
/*  242 */     this.useBulkCopyForBatchInsert = conn.getUseBulkCopyForBatchInsert();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void closePreparedHandle() {
/*  249 */     if (!hasPreparedStatementHandle()) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  255 */     if (this.connection.isSessionUnAvailable()) {
/*  256 */       if (loggerExternal.isLoggable(Level.FINER)) {
/*  257 */         loggerExternal.finer("" + this + ": Not closing PreparedHandle:" + this + "; connection is already closed.");
/*      */       }
/*      */     } else {
/*  260 */       this.isExecutedAtLeastOnce = false;
/*  261 */       final int handleToClose = this.prepStmtHandle;
/*      */ 
/*      */       
/*  264 */       if (resetPrepStmtHandle(false)) {
/*  265 */         this.connection.returnCachedPreparedStatementHandle(this.cachedPreparedStatementHandle);
/*      */ 
/*      */       
/*      */       }
/*  269 */       else if (this.connection.isPreparedStatementUnprepareBatchingEnabled()) {
/*      */         
/*  271 */         Objects.requireNonNull(this.connection); this.connection.enqueueUnprepareStatementHandle(new SQLServerConnection.PreparedStatementHandle(this.connection, null, handleToClose, this.executedSqlDirectly, true));
/*      */       } else {
/*      */         
/*  274 */         if (loggerExternal.isLoggable(Level.FINER)) {
/*  275 */           loggerExternal.finer("" + this + ": Closing PreparedHandle:" + this);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         try {
/*  303 */           executeCommand(new PreparedHandleClose());
/*  304 */         } catch (SQLServerException e) {
/*  305 */           if (loggerExternal.isLoggable(Level.FINER)) {
/*  306 */             loggerExternal.log(Level.FINER, "" + this + ": Error (ignored) closing PreparedHandle:" + this, e);
/*      */           }
/*      */         } 
/*      */         
/*  310 */         if (loggerExternal.isLoggable(Level.FINER)) {
/*  311 */           loggerExternal.finer("" + this + ": Closed PreparedHandle:" + this);
/*      */         }
/*      */       } 
/*      */       
/*  315 */       this.connection.unprepareUnreferencedPreparedStatementHandles(false);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void closeInternal() {
/*  328 */     super.closeInternal();
/*      */ 
/*      */     
/*  331 */     closePreparedHandle();
/*      */ 
/*      */     
/*      */     try {
/*  335 */       if (null != this.internalStmt)
/*  336 */         this.internalStmt.close(); 
/*  337 */     } catch (SQLServerException e) {
/*  338 */       if (loggerExternal.isLoggable(Level.FINER))
/*  339 */         loggerExternal
/*  340 */           .finer("Ignored error closing internal statement: " + e.getErrorCode() + " " + e.getMessage()); 
/*      */     } finally {
/*  342 */       this.internalStmt = null;
/*      */     } 
/*      */ 
/*      */     
/*  346 */     this.batchParamValues = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void initParams(int nParams) {
/*  356 */     this.inOutParam = new Parameter[nParams];
/*  357 */     for (int i = 0; i < nParams; i++) {
/*  358 */       this.inOutParam[i] = new Parameter(Util.shouldHonorAEForParameters(this.stmtColumnEncriptionSetting, this.connection));
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public final void clearParameters() throws SQLServerException {
/*  364 */     loggerExternal.entering(getClassNameLogging(), "clearParameters");
/*  365 */     checkClosed();
/*  366 */     this.encryptionMetadataIsRetrieved = false;
/*      */     
/*  368 */     if (this.inOutParam == null)
/*      */       return; 
/*  370 */     for (int i = 0; i < this.inOutParam.length; i++) {
/*  371 */       this.inOutParam[i].clearInputValue();
/*      */     }
/*  373 */     loggerExternal.exiting(getClassNameLogging(), "clearParameters");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean buildPreparedStrings(Parameter[] params, boolean renewDefinition) throws SQLServerException {
/*  381 */     String newTypeDefinitions = buildParamTypeDefinitions(params, renewDefinition);
/*  382 */     if (null != this.preparedTypeDefinitions && newTypeDefinitions.equalsIgnoreCase(this.preparedTypeDefinitions)) {
/*  383 */       return false;
/*      */     }
/*  385 */     this.preparedTypeDefinitions = newTypeDefinitions;
/*      */ 
/*      */     
/*  388 */     this.preparedSQL = this.connection.replaceParameterMarkers(this.userSQL, this.userSQLParamPositions, params, this.bReturnValueSyntax);
/*  389 */     if (this.bRequestedGeneratedKeys) {
/*  390 */       this.preparedSQL += " select SCOPE_IDENTITY() AS GENERATED_KEYS";
/*      */     }
/*  392 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String buildParamTypeDefinitions(Parameter[] params, boolean renewDefinition) throws SQLServerException {
/*  407 */     StringBuilder sb = new StringBuilder();
/*  408 */     int nCols = params.length;
/*  409 */     char[] cParamName = new char[10];
/*  410 */     this.parameterNames = new ArrayList<>();
/*      */     
/*  412 */     for (int i = 0; i < nCols; i++) {
/*  413 */       if (i > 0) {
/*  414 */         sb.append(',');
/*      */       }
/*  416 */       int l = SQLServerConnection.makeParamName(i, cParamName, 0);
/*  417 */       for (int j = 0; j < l; j++)
/*  418 */         sb.append(cParamName[j]); 
/*  419 */       sb.append(' ');
/*      */       
/*  421 */       this.parameterNames.add(i, (new String(cParamName)).trim());
/*      */       
/*  423 */       (params[i]).renewDefinition = renewDefinition;
/*  424 */       String typeDefinition = params[i].getTypeDefinition(this.connection, resultsReader());
/*  425 */       if (null == typeDefinition) {
/*  426 */         MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_valueNotSetForParameter"));
/*  427 */         Object[] msgArgs = { Integer.valueOf(i + 1) };
/*  428 */         SQLServerException.makeFromDriverError(this.connection, this, form.format(msgArgs), (String)null, false);
/*      */       } 
/*      */       
/*  431 */       sb.append(typeDefinition);
/*      */       
/*  433 */       if (params[i].isOutput())
/*  434 */         sb.append(" OUTPUT"); 
/*      */     } 
/*  436 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   
/*      */   public ResultSet executeQuery() throws SQLServerException, SQLTimeoutException {
/*  441 */     loggerExternal.entering(getClassNameLogging(), "executeQuery");
/*  442 */     if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) {
/*  443 */       loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */     }
/*  445 */     checkClosed();
/*  446 */     executeStatement(new PrepStmtExecCmd(this, 1));
/*  447 */     loggerExternal.exiting(getClassNameLogging(), "executeQuery");
/*  448 */     return this.resultSet;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final ResultSet executeQueryInternal() throws SQLServerException, SQLTimeoutException {
/*  459 */     checkClosed();
/*  460 */     executeStatement(new PrepStmtExecCmd(this, 5));
/*  461 */     return this.resultSet;
/*      */   }
/*      */ 
/*      */   
/*      */   public int executeUpdate() throws SQLServerException, SQLTimeoutException {
/*  466 */     loggerExternal.entering(getClassNameLogging(), "executeUpdate");
/*  467 */     if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) {
/*  468 */       loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */     }
/*      */     
/*  471 */     checkClosed();
/*      */     
/*  473 */     executeStatement(new PrepStmtExecCmd(this, 2));
/*      */ 
/*      */     
/*  476 */     if (this.updateCount < -2147483648L || this.updateCount > 2147483647L) {
/*  477 */       SQLServerException.makeFromDriverError(this.connection, this, 
/*  478 */           SQLServerException.getErrString("R_updateCountOutofRange"), (String)null, true);
/*      */     }
/*  480 */     loggerExternal.exiting(getClassNameLogging(), "executeUpdate", Long.valueOf(this.updateCount));
/*      */     
/*  482 */     return (int)this.updateCount;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public long executeLargeUpdate() throws SQLServerException, SQLTimeoutException {
/*  488 */     loggerExternal.entering(getClassNameLogging(), "executeLargeUpdate");
/*  489 */     if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) {
/*  490 */       loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */     }
/*  492 */     checkClosed();
/*  493 */     executeStatement(new PrepStmtExecCmd(this, 2));
/*  494 */     loggerExternal.exiting(getClassNameLogging(), "executeLargeUpdate", Long.valueOf(this.updateCount));
/*  495 */     return this.updateCount;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean execute() throws SQLServerException, SQLTimeoutException {
/*  500 */     loggerExternal.entering(getClassNameLogging(), "execute");
/*  501 */     if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) {
/*  502 */       loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */     }
/*  504 */     checkClosed();
/*  505 */     executeStatement(new PrepStmtExecCmd(this, 3));
/*  506 */     loggerExternal.exiting(getClassNameLogging(), "execute", Boolean.valueOf((null != this.resultSet)));
/*  507 */     return (null != this.resultSet);
/*      */   }
/*      */ 
/*      */   
/*      */   private final class PrepStmtExecCmd
/*      */     extends TDSCommand
/*      */   {
/*      */     private static final long serialVersionUID = 4098801171124750861L;
/*      */     private final SQLServerPreparedStatement stmt;
/*      */     
/*      */     PrepStmtExecCmd(SQLServerPreparedStatement stmt, int executeMethod) {
/*  518 */       super(stmt.toString() + " executeXXX", SQLServerPreparedStatement.this.queryTimeout, SQLServerPreparedStatement.this.cancelQueryTimeoutSeconds);
/*  519 */       this.stmt = stmt;
/*  520 */       stmt.executeMethod = executeMethod;
/*      */     }
/*      */     
/*      */     final boolean doExecute() throws SQLServerException {
/*  524 */       this.stmt.doExecutePreparedStatement(this);
/*  525 */       return false;
/*      */     }
/*      */     
/*      */     final void processResponse(TDSReader tdsReader) throws SQLServerException {
/*  529 */       SQLServerPreparedStatement.this.ensureExecuteResultsReader(tdsReader);
/*  530 */       SQLServerPreparedStatement.this.processExecuteResults();
/*      */     }
/*      */   }
/*      */   
/*      */   final void doExecutePreparedStatement(PrepStmtExecCmd command) throws SQLServerException {
/*  535 */     resetForReexecute();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  547 */     setMaxRowsAndMaxFieldSize();
/*      */     
/*  549 */     if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) {
/*  550 */       loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */     }
/*      */     
/*  553 */     boolean hasExistingTypeDefinitions = (this.preparedTypeDefinitions != null);
/*  554 */     boolean hasNewTypeDefinitions = true;
/*  555 */     if (!this.encryptionMetadataIsRetrieved) {
/*  556 */       hasNewTypeDefinitions = buildPreparedStrings(this.inOutParam, false);
/*      */     }
/*      */     
/*  559 */     if (this.connection.isAEv2() && !this.isInternalEncryptionQuery) {
/*  560 */       this.enclaveCEKs = this.connection.initEnclaveParameters(this.preparedSQL, this.preparedTypeDefinitions, this.inOutParam, this.parameterNames);
/*      */       
/*  562 */       this.encryptionMetadataIsRetrieved = true;
/*  563 */       setMaxRowsAndMaxFieldSize();
/*  564 */       hasNewTypeDefinitions = buildPreparedStrings(this.inOutParam, true);
/*      */     } 
/*      */     
/*  567 */     if (Util.shouldHonorAEForParameters(this.stmtColumnEncriptionSetting, this.connection) && 0 < this.inOutParam.length && !this.isInternalEncryptionQuery) {
/*      */ 
/*      */ 
/*      */       
/*  571 */       if (!this.encryptionMetadataIsRetrieved) {
/*  572 */         getParameterEncryptionMetadata(this.inOutParam);
/*  573 */         this.encryptionMetadataIsRetrieved = true;
/*      */ 
/*      */ 
/*      */         
/*  577 */         setMaxRowsAndMaxFieldSize();
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  582 */       hasNewTypeDefinitions = buildPreparedStrings(this.inOutParam, true);
/*      */     } 
/*      */     
/*  585 */     boolean needsPrepare = true;
/*      */     
/*  587 */     for (int attempt = 1; attempt <= 2;) {
/*      */       
/*      */       try {
/*  590 */         if (reuseCachedHandle(hasNewTypeDefinitions, (1 < attempt))) {
/*  591 */           hasNewTypeDefinitions = false;
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*  596 */         TDSWriter tdsWriter = command.startRequest((byte)3);
/*      */         
/*  598 */         needsPrepare = doPrepExec(tdsWriter, this.inOutParam, hasNewTypeDefinitions, hasExistingTypeDefinitions);
/*      */         
/*  600 */         ensureExecuteResultsReader(command.startResponse(getIsResponseBufferingAdaptive()));
/*  601 */         startResults();
/*  602 */         getNextResult(true);
/*  603 */       } catch (SQLException e) {
/*  604 */         if (retryBasedOnFailedReuseOfCachedHandle(e, attempt, needsPrepare, false)) {
/*      */           attempt++; continue;
/*      */         } 
/*  607 */         throw e;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  612 */     if (1 == this.executeMethod && null == this.resultSet) {
/*  613 */       SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_noResultset"), (String)null, true);
/*      */     }
/*  615 */     else if (2 == this.executeMethod && null != this.resultSet) {
/*  616 */       SQLServerException.makeFromDriverError(this.connection, this, 
/*  617 */           SQLServerException.getErrString("R_resultsetGeneratedForUpdate"), (String)null, false);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean retryBasedOnFailedReuseOfCachedHandle(SQLException e, int attempt, boolean needsPrepare, boolean isBatch) {
/*  632 */     if (needsPrepare && !isBatch)
/*  633 */       return false; 
/*  634 */     return (1 == attempt && (586 == e.getErrorCode() || 8179 == e.getErrorCode()) && this.connection
/*  635 */       .isStatementPoolingEnabled());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean consumeExecOutParam(TDSReader tdsReader) throws SQLServerException {
/*      */     final class PrepStmtExecOutParamHandler
/*      */       extends SQLServerStatement.StmtExecOutParamHandler
/*      */     {
/*      */       boolean onRetValue(TDSReader tdsReader) throws SQLServerException {
/*  650 */         if (!SQLServerPreparedStatement.this.expectPrepStmtHandle) {
/*  651 */           return super.onRetValue(tdsReader);
/*      */         }
/*      */ 
/*      */         
/*  655 */         SQLServerPreparedStatement.this.expectPrepStmtHandle = false;
/*      */         
/*  657 */         Parameter param = new Parameter(Util.shouldHonorAEForParameters(SQLServerPreparedStatement.this.stmtColumnEncriptionSetting, SQLServerPreparedStatement.this.connection));
/*  658 */         param.skipRetValStatus(tdsReader);
/*      */         
/*  660 */         SQLServerPreparedStatement.this.setPreparedStatementHandle(param.getInt(tdsReader));
/*      */ 
/*      */         
/*  663 */         if (null == SQLServerPreparedStatement.this.cachedPreparedStatementHandle && !SQLServerPreparedStatement.this.isCursorable(SQLServerPreparedStatement.this.executeMethod)) {
/*  664 */           SQLServerPreparedStatement.this.cachedPreparedStatementHandle = SQLServerPreparedStatement.this.connection.registerCachedPreparedStatementHandle(new SQLServerConnection.CityHash128Key(SQLServerPreparedStatement.this.preparedSQL, SQLServerPreparedStatement.this.preparedTypeDefinitions), SQLServerPreparedStatement.this.prepStmtHandle, SQLServerPreparedStatement.this.executedSqlDirectly);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*  669 */         param.skipValue(tdsReader, true);
/*  670 */         if (SQLServerPreparedStatement.this.getStatementLogger().isLoggable(Level.FINER)) {
/*  671 */           SQLServerPreparedStatement.this.getStatementLogger().finer(toString() + ": Setting PreparedHandle:" + toString());
/*      */         }
/*  673 */         return true;
/*      */       }
/*      */     };
/*      */     
/*  677 */     if (this.expectPrepStmtHandle || this.expectCursorOutParams) {
/*  678 */       TDSParser.parse(tdsReader, new PrepStmtExecOutParamHandler());
/*  679 */       return true;
/*      */     } 
/*      */     
/*  682 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void sendParamsByRPC(TDSWriter tdsWriter, Parameter[] params) throws SQLServerException {
/*  690 */     for (int index = 0; index < params.length; index++) {
/*  691 */       if (JDBCType.TVP == params[index].getJdbcType()) {
/*  692 */         char[] cParamName = new char[10];
/*  693 */         int paramNameLen = SQLServerConnection.makeParamName(index, cParamName, 0);
/*  694 */         tdsWriter.writeByte((byte)paramNameLen);
/*  695 */         tdsWriter.writeString(new String(cParamName, 0, paramNameLen));
/*      */       } 
/*  697 */       params[index].sendByRPC(tdsWriter, this.connection);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void buildServerCursorPrepExecParams(TDSWriter tdsWriter) throws SQLServerException {
/*  702 */     if (getStatementLogger().isLoggable(Level.FINE)) {
/*  703 */       getStatementLogger().fine(toString() + ": calling sp_cursorprepexec: PreparedHandle:" + toString() + ", SQL:" + 
/*  704 */           getPreparedStatementHandle());
/*      */     }
/*  706 */     this.expectPrepStmtHandle = true;
/*  707 */     this.executedSqlDirectly = false;
/*  708 */     this.expectCursorOutParams = true;
/*  709 */     this.outParamIndexAdjustment = 7;
/*      */     
/*  711 */     tdsWriter.writeShort((short)-1);
/*  712 */     tdsWriter.writeShort((short)5);
/*  713 */     tdsWriter.writeByte((byte)0);
/*  714 */     tdsWriter.writeByte((byte)0);
/*  715 */     tdsWriter.sendEnclavePackage(this.preparedSQL, this.enclaveCEKs);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  720 */     tdsWriter.writeRPCInt(null, Integer.valueOf(getPreparedStatementHandle()), true);
/*  721 */     resetPrepStmtHandle(false);
/*      */ 
/*      */     
/*  724 */     tdsWriter.writeRPCInt(null, Integer.valueOf(0), true);
/*      */ 
/*      */     
/*  727 */     tdsWriter.writeRPCStringUnicode((this.preparedTypeDefinitions.length() > 0) ? this.preparedTypeDefinitions : null);
/*      */ 
/*      */     
/*  730 */     tdsWriter.writeRPCStringUnicode(this.preparedSQL);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  735 */     tdsWriter.writeRPCInt(null, Integer.valueOf(getResultSetScrollOpt() & ((
/*  736 */           (0 == this.preparedTypeDefinitions.length()) ? 4096 : 0) ^ 0xFFFFFFFF)), false);
/*      */ 
/*      */     
/*  739 */     tdsWriter.writeRPCInt(null, Integer.valueOf(getResultSetCCOpt()), false);
/*      */ 
/*      */     
/*  742 */     tdsWriter.writeRPCInt(null, Integer.valueOf(0), true);
/*      */   }
/*      */   
/*      */   private void buildPrepExecParams(TDSWriter tdsWriter) throws SQLServerException {
/*  746 */     if (getStatementLogger().isLoggable(Level.FINE)) {
/*  747 */       getStatementLogger().fine(toString() + ": calling sp_prepexec: PreparedHandle:" + toString() + ", SQL:" + 
/*  748 */           getPreparedStatementHandle());
/*      */     }
/*  750 */     this.expectPrepStmtHandle = true;
/*  751 */     this.executedSqlDirectly = true;
/*  752 */     this.expectCursorOutParams = false;
/*  753 */     this.outParamIndexAdjustment = 3;
/*      */     
/*  755 */     tdsWriter.writeShort((short)-1);
/*  756 */     tdsWriter.writeShort((short)13);
/*  757 */     tdsWriter.writeByte((byte)0);
/*  758 */     tdsWriter.writeByte((byte)0);
/*  759 */     tdsWriter.sendEnclavePackage(this.preparedSQL, this.enclaveCEKs);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  764 */     tdsWriter.writeRPCInt(null, Integer.valueOf(getPreparedStatementHandle()), true);
/*  765 */     resetPrepStmtHandle(false);
/*      */ 
/*      */     
/*  768 */     tdsWriter.writeRPCStringUnicode((this.preparedTypeDefinitions.length() > 0) ? this.preparedTypeDefinitions : null);
/*      */ 
/*      */     
/*  771 */     tdsWriter.writeRPCStringUnicode(this.preparedSQL);
/*      */   }
/*      */   
/*      */   private void buildExecSQLParams(TDSWriter tdsWriter) throws SQLServerException {
/*  775 */     if (getStatementLogger().isLoggable(Level.FINE)) {
/*  776 */       getStatementLogger().fine(toString() + ": calling sp_executesql: SQL:" + toString());
/*      */     }
/*  778 */     this.expectPrepStmtHandle = false;
/*  779 */     this.executedSqlDirectly = true;
/*  780 */     this.expectCursorOutParams = false;
/*  781 */     this.outParamIndexAdjustment = 2;
/*      */     
/*  783 */     tdsWriter.writeShort((short)-1);
/*  784 */     tdsWriter.writeShort((short)10);
/*  785 */     tdsWriter.writeByte((byte)0);
/*  786 */     tdsWriter.writeByte((byte)0);
/*  787 */     tdsWriter.sendEnclavePackage(this.preparedSQL, this.enclaveCEKs);
/*      */ 
/*      */     
/*  790 */     resetPrepStmtHandle(false);
/*      */ 
/*      */     
/*  793 */     tdsWriter.writeRPCStringUnicode(this.preparedSQL);
/*      */ 
/*      */     
/*  796 */     if (this.preparedTypeDefinitions.length() > 0)
/*  797 */       tdsWriter.writeRPCStringUnicode(this.preparedTypeDefinitions); 
/*      */   }
/*      */   
/*      */   private void buildServerCursorExecParams(TDSWriter tdsWriter) throws SQLServerException {
/*  801 */     if (getStatementLogger().isLoggable(Level.FINE)) {
/*  802 */       getStatementLogger().fine(toString() + ": calling sp_cursorexecute: PreparedHandle:" + toString() + ", SQL:" + 
/*  803 */           getPreparedStatementHandle());
/*      */     }
/*  805 */     this.expectPrepStmtHandle = false;
/*  806 */     this.executedSqlDirectly = false;
/*  807 */     this.expectCursorOutParams = true;
/*  808 */     this.outParamIndexAdjustment = 5;
/*      */     
/*  810 */     tdsWriter.writeShort((short)-1);
/*  811 */     tdsWriter.writeShort((short)4);
/*  812 */     tdsWriter.writeByte((byte)0);
/*  813 */     tdsWriter.writeByte((byte)0);
/*  814 */     tdsWriter.sendEnclavePackage(this.preparedSQL, this.enclaveCEKs);
/*      */ 
/*      */     
/*  817 */     assert hasPreparedStatementHandle();
/*  818 */     tdsWriter.writeRPCInt(null, Integer.valueOf(getPreparedStatementHandle()), false);
/*      */ 
/*      */     
/*  821 */     tdsWriter.writeRPCInt(null, Integer.valueOf(0), true);
/*      */ 
/*      */     
/*  824 */     tdsWriter.writeRPCInt(null, Integer.valueOf(getResultSetScrollOpt() & 0xFFFFEFFF), false);
/*      */ 
/*      */     
/*  827 */     tdsWriter.writeRPCInt(null, Integer.valueOf(getResultSetCCOpt()), false);
/*      */ 
/*      */     
/*  830 */     tdsWriter.writeRPCInt(null, Integer.valueOf(0), true);
/*      */   }
/*      */   
/*      */   private void buildExecParams(TDSWriter tdsWriter) throws SQLServerException {
/*  834 */     if (getStatementLogger().isLoggable(Level.FINE)) {
/*  835 */       getStatementLogger().fine(toString() + ": calling sp_execute: PreparedHandle:" + toString() + ", SQL:" + 
/*  836 */           getPreparedStatementHandle());
/*      */     }
/*  838 */     this.expectPrepStmtHandle = false;
/*  839 */     this.executedSqlDirectly = true;
/*  840 */     this.expectCursorOutParams = false;
/*  841 */     this.outParamIndexAdjustment = 1;
/*      */     
/*  843 */     tdsWriter.writeShort((short)-1);
/*  844 */     tdsWriter.writeShort((short)12);
/*  845 */     tdsWriter.writeByte((byte)0);
/*  846 */     tdsWriter.writeByte((byte)0);
/*  847 */     tdsWriter.sendEnclavePackage(this.preparedSQL, this.enclaveCEKs);
/*      */ 
/*      */     
/*  850 */     assert hasPreparedStatementHandle();
/*  851 */     tdsWriter.writeRPCInt(null, Integer.valueOf(getPreparedStatementHandle()), false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void getParameterEncryptionMetadata(Parameter[] params) throws SQLServerException {
/*  860 */     assert this.connection != null : "Connection should not be null";
/*      */     
/*  862 */     try { Statement stmt = this.connection.prepareCall("exec sp_describe_parameter_encryption ?,?"); 
/*  863 */       try { if (getStatementLogger().isLoggable(Level.FINE)) {
/*  864 */           getStatementLogger().fine("Calling stored procedure sp_describe_parameter_encryption to get parameter encryption information.");
/*      */         }
/*      */         
/*  867 */         ((SQLServerCallableStatement)stmt).isInternalEncryptionQuery = true;
/*  868 */         ((SQLServerCallableStatement)stmt).setNString(1, this.preparedSQL);
/*  869 */         ((SQLServerCallableStatement)stmt).setNString(2, this.preparedTypeDefinitions);
/*  870 */         ResultSet rs = ((SQLServerCallableStatement)stmt).executeQueryInternal(); 
/*  871 */         try { if (null == rs)
/*      */           
/*      */           { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  960 */             if (rs != null) rs.close(); 
/*  961 */             if (stmt != null) stmt.close();  return; }  Map<Integer, CekTableEntry> cekList = new HashMap<>(); CekTableEntry cekEntry = null; while (rs.next()) { int currentOrdinal = rs.getInt(DescribeParameterEncryptionResultSet1.KeyOrdinal.value()); if (!cekList.containsKey(Integer.valueOf(currentOrdinal))) { cekEntry = new CekTableEntry(currentOrdinal); cekList.put(Integer.valueOf(cekEntry.ordinal), cekEntry); } else { cekEntry = cekList.get(Integer.valueOf(currentOrdinal)); }  cekEntry.add(rs.getBytes(DescribeParameterEncryptionResultSet1.EncryptedKey.value()), rs.getInt(DescribeParameterEncryptionResultSet1.DbId.value()), rs.getInt(DescribeParameterEncryptionResultSet1.KeyId.value()), rs.getInt(DescribeParameterEncryptionResultSet1.KeyVersion.value()), rs.getBytes(DescribeParameterEncryptionResultSet1.KeyMdVersion.value()), rs.getString(DescribeParameterEncryptionResultSet1.KeyPath.value()), rs.getString(DescribeParameterEncryptionResultSet1.ProviderName.value()), rs.getString(DescribeParameterEncryptionResultSet1.KeyEncryptionAlgorithm.value())); }  if (getStatementLogger().isLoggable(Level.FINE)) getStatementLogger().fine("Matadata of CEKs is retrieved.");  if (!stmt.getMoreResults()) throw new SQLServerException(this, SQLServerException.getErrString("R_UnexpectedDescribeParamFormat"), null, 0, false);  int paramCount = 0; ResultSet secondRs = stmt.getResultSet(); try { while (secondRs.next()) { paramCount++; String paramName = secondRs.getString(DescribeParameterEncryptionResultSet2.ParameterName.value()); int paramIndex = this.parameterNames.indexOf(paramName); int cekOrdinal = secondRs.getInt(DescribeParameterEncryptionResultSet2.ColumnEncryptionKeyOrdinal.value()); cekEntry = cekList.get(Integer.valueOf(cekOrdinal)); if (null != cekEntry && cekList.size() < cekOrdinal) { MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_InvalidEncryptionKeyOrdinal")); Object[] msgArgs = { Integer.valueOf(cekOrdinal), Integer.valueOf(cekEntry.getSize()) }; throw new SQLServerException(this, form.format(msgArgs), null, 0, false); }  SQLServerEncryptionType encType = SQLServerEncryptionType.of((byte)secondRs.getInt(DescribeParameterEncryptionResultSet2.ColumnEncrytionType.value())); if (SQLServerEncryptionType.PlainText != encType) { (params[paramIndex]).cryptoMeta = new CryptoMetadata(cekEntry, (short)cekOrdinal, (byte)secondRs.getInt(DescribeParameterEncryptionResultSet2.ColumnEncryptionAlgorithm.value()), null, encType.value, (byte)secondRs.getInt(DescribeParameterEncryptionResultSet2.NormalizationRuleVersion.value())); SQLServerSecurityUtility.decryptSymmetricKey((params[paramIndex]).cryptoMeta, this.connection); continue; }  if (params[paramIndex].getForceEncryption()) { MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_ForceEncryptionTrue_HonorAETrue_UnencryptedColumn")); Object[] msgArgs = { this.userSQL, Integer.valueOf(paramIndex + 1) }; SQLServerException.makeFromDriverError(this.connection, this, form.format(msgArgs), (String)null, true); }  }  if (getStatementLogger().isLoggable(Level.FINE)) getStatementLogger().fine("Parameter encryption metadata is set.");  if (secondRs != null) secondRs.close();  } catch (Throwable throwable) { if (secondRs != null) try { secondRs.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  if (paramCount != params.length) { MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_MissingParamEncryptionMetadata")); Object[] msgArgs = { this.userSQL }; throw new SQLServerException(this, form.format(msgArgs), null, 0, false); }  if (rs != null) rs.close();  } catch (Throwable throwable) { if (rs != null) try { rs.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  if (stmt != null) stmt.close();  } catch (Throwable throwable) { if (stmt != null) try { stmt.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (SQLException e)
/*  962 */     { if (e instanceof SQLServerException) {
/*  963 */         throw (SQLServerException)e;
/*      */       }
/*  965 */       throw new SQLServerException(SQLServerException.getErrString("R_UnableRetrieveParameterMetadata"), null, 0, e); }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  970 */     this.connection.resetCurrentCommand();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean reuseCachedHandle(boolean hasNewTypeDefinitions, boolean discardCurrentCacheItem) {
/*  978 */     if (isCursorable(this.executeMethod)) {
/*  979 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  984 */     if (discardCurrentCacheItem || hasNewTypeDefinitions) {
/*  985 */       if (null != this.cachedPreparedStatementHandle && (discardCurrentCacheItem || (
/*  986 */         hasPreparedStatementHandle() && this.prepStmtHandle == this.cachedPreparedStatementHandle.getHandle()))) {
/*  987 */         this.cachedPreparedStatementHandle.removeReference();
/*      */       }
/*      */ 
/*      */       
/*  991 */       resetPrepStmtHandle(discardCurrentCacheItem);
/*  992 */       this.cachedPreparedStatementHandle = null;
/*  993 */       if (discardCurrentCacheItem) {
/*  994 */         return false;
/*      */       }
/*      */     } 
/*      */     
/*  998 */     if (null == this.cachedPreparedStatementHandle) {
/*      */       
/* 1000 */       SQLServerConnection.PreparedStatementHandle cachedHandle = this.connection.getCachedPreparedStatementHandle(new SQLServerConnection.CityHash128Key(this.preparedSQL, this.preparedTypeDefinitions));
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1005 */       if (null != cachedHandle && (
/* 1006 */         !this.connection.isColumnEncryptionSettingEnabled() || (this.connection
/* 1007 */         .isColumnEncryptionSettingEnabled() && this.encryptionMetadataIsRetrieved)) && 
/* 1008 */         cachedHandle.tryAddReference()) {
/* 1009 */         setPreparedStatementHandle(cachedHandle.getHandle());
/* 1010 */         this.cachedPreparedStatementHandle = cachedHandle;
/* 1011 */         return true;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1016 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean doPrepExec(TDSWriter tdsWriter, Parameter[] params, boolean hasNewTypeDefinitions, boolean hasExistingTypeDefinitions) throws SQLServerException {
/* 1024 */     boolean needsPrepare = ((hasNewTypeDefinitions && hasExistingTypeDefinitions) || !hasPreparedStatementHandle());
/*      */ 
/*      */     
/* 1027 */     if (isCursorable(this.executeMethod)) {
/*      */       
/* 1029 */       if (needsPrepare) {
/* 1030 */         buildServerCursorPrepExecParams(tdsWriter);
/*      */       } else {
/* 1032 */         buildServerCursorExecParams(tdsWriter);
/*      */       }
/*      */     
/*      */     }
/* 1036 */     else if (needsPrepare && !this.connection.getEnablePrepareOnFirstPreparedStatementCall() && !this.isExecutedAtLeastOnce) {
/* 1037 */       buildExecSQLParams(tdsWriter);
/* 1038 */       this.isExecutedAtLeastOnce = true;
/*      */     
/*      */     }
/* 1041 */     else if (needsPrepare) {
/* 1042 */       buildPrepExecParams(tdsWriter);
/*      */     } else {
/* 1044 */       buildExecParams(tdsWriter);
/*      */     } 
/*      */     
/* 1047 */     sendParamsByRPC(tdsWriter, params);
/*      */     
/* 1049 */     return needsPrepare;
/*      */   }
/*      */ 
/*      */   
/*      */   public final ResultSetMetaData getMetaData() throws SQLServerException, SQLTimeoutException {
/* 1054 */     loggerExternal.entering(getClassNameLogging(), "getMetaData");
/* 1055 */     checkClosed();
/* 1056 */     boolean rsclosed = false;
/* 1057 */     ResultSetMetaData rsmd = null;
/*      */     
/*      */     try {
/* 1060 */       if (this.resultSet != null)
/* 1061 */         this.resultSet.checkClosed(); 
/* 1062 */     } catch (SQLServerException e) {
/* 1063 */       rsclosed = true;
/*      */     } 
/* 1065 */     if (this.resultSet == null || rsclosed) {
/* 1066 */       SQLServerResultSet emptyResultSet = buildExecuteMetaData();
/* 1067 */       if (null != emptyResultSet)
/* 1068 */         rsmd = emptyResultSet.getMetaData(); 
/* 1069 */     } else if (this.resultSet != null) {
/* 1070 */       rsmd = this.resultSet.getMetaData();
/*      */     } 
/* 1072 */     loggerExternal.exiting(getClassNameLogging(), "getMetaData", rsmd);
/* 1073 */     return rsmd;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private SQLServerResultSet buildExecuteMetaData() throws SQLServerException, SQLTimeoutException {
/* 1084 */     String fmtSQL = this.userSQL;
/*      */     
/* 1086 */     SQLServerResultSet emptyResultSet = null;
/*      */     try {
/* 1088 */       fmtSQL = replaceMarkerWithNull(fmtSQL);
/* 1089 */       this.internalStmt = (SQLServerStatement)this.connection.createStatement();
/* 1090 */       emptyResultSet = this.internalStmt.executeQueryInternal("set fmtonly on " + fmtSQL + "\nset fmtonly off");
/* 1091 */     } catch (SQLServerException sqle) {
/*      */       
/* 1093 */       if (!sqle.getMessage().equals(SQLServerException.getErrString("R_noResultset"))) {
/* 1094 */         throw sqle;
/*      */       }
/*      */     } 
/* 1097 */     return emptyResultSet;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final Parameter setterGetParam(int index) throws SQLServerException {
/* 1112 */     if (index < 1 || index > this.inOutParam.length) {
/* 1113 */       MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_indexOutOfRange"));
/* 1114 */       Object[] msgArgs = { Integer.valueOf(index) };
/* 1115 */       SQLServerException.makeFromDriverError(this.connection, this, form.format(msgArgs), "07009", false);
/*      */     } 
/*      */     
/* 1118 */     return this.inOutParam[index - 1];
/*      */   }
/*      */ 
/*      */   
/*      */   final void setValue(int parameterIndex, JDBCType jdbcType, Object value, JavaType javaType, String tvpName) throws SQLServerException {
/* 1123 */     setterGetParam(parameterIndex).setValue(jdbcType, value, javaType, null, null, null, null, this.connection, false, this.stmtColumnEncriptionSetting, parameterIndex, this.userSQL, tvpName);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   final void setValue(int parameterIndex, JDBCType jdbcType, Object value, JavaType javaType, boolean forceEncrypt) throws SQLServerException {
/* 1129 */     setterGetParam(parameterIndex).setValue(jdbcType, value, javaType, null, null, null, null, this.connection, forceEncrypt, this.stmtColumnEncriptionSetting, parameterIndex, this.userSQL, null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   final void setValue(int parameterIndex, JDBCType jdbcType, Object value, JavaType javaType, Integer precision, Integer scale, boolean forceEncrypt) throws SQLServerException {
/* 1135 */     setterGetParam(parameterIndex).setValue(jdbcType, value, javaType, null, null, precision, scale, this.connection, forceEncrypt, this.stmtColumnEncriptionSetting, parameterIndex, this.userSQL, null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   final void setValue(int parameterIndex, JDBCType jdbcType, Object value, JavaType javaType, Calendar cal, boolean forceEncrypt) throws SQLServerException {
/* 1141 */     setterGetParam(parameterIndex).setValue(jdbcType, value, javaType, null, cal, null, null, this.connection, forceEncrypt, this.stmtColumnEncriptionSetting, parameterIndex, this.userSQL, null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   final void setStream(int parameterIndex, StreamType streamType, Object streamValue, JavaType javaType, long length) throws SQLServerException {
/* 1147 */     setterGetParam(parameterIndex).setValue(streamType.getJDBCType(), streamValue, javaType, new StreamSetterArgs(streamType, length), null, null, null, this.connection, false, this.stmtColumnEncriptionSetting, parameterIndex, this.userSQL, null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   final void setSQLXMLInternal(int parameterIndex, SQLXML value) throws SQLServerException {
/* 1153 */     setterGetParam(parameterIndex).setValue(JDBCType.SQLXML, value, JavaType.SQLXML, new StreamSetterArgs(StreamType.SQLXML, -1L), null, null, null, this.connection, false, this.stmtColumnEncriptionSetting, parameterIndex, this.userSQL, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setAsciiStream(int parameterIndex, InputStream x) throws SQLException {
/* 1160 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1161 */       loggerExternal.entering(getClassNameLogging(), "setAsciiStream", new Object[] { Integer.valueOf(parameterIndex), x }); 
/* 1162 */     checkClosed();
/* 1163 */     setStream(parameterIndex, StreamType.ASCII, x, JavaType.INPUTSTREAM, -1L);
/* 1164 */     loggerExternal.exiting(getClassNameLogging(), "setAsciiStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setAsciiStream(int n, InputStream x, int length) throws SQLServerException {
/* 1169 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1170 */       loggerExternal.entering(getClassNameLogging(), "setAsciiStream", new Object[] { Integer.valueOf(n), x, Integer.valueOf(length) }); 
/* 1171 */     checkClosed();
/* 1172 */     setStream(n, StreamType.ASCII, x, JavaType.INPUTSTREAM, length);
/* 1173 */     loggerExternal.exiting(getClassNameLogging(), "setAsciiStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setAsciiStream(int parameterIndex, InputStream x, long length) throws SQLException {
/* 1178 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1179 */       loggerExternal.entering(getClassNameLogging(), "setAsciiStream", new Object[] { Integer.valueOf(parameterIndex), x, Long.valueOf(length) }); 
/* 1180 */     checkClosed();
/* 1181 */     setStream(parameterIndex, StreamType.ASCII, x, JavaType.INPUTSTREAM, length);
/* 1182 */     loggerExternal.exiting(getClassNameLogging(), "setAsciiStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setBigDecimal(int parameterIndex, BigDecimal x) throws SQLServerException {
/* 1187 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1188 */       loggerExternal.entering(getClassNameLogging(), "setBigDecimal", new Object[] { Integer.valueOf(parameterIndex), x }); 
/* 1189 */     checkClosed();
/* 1190 */     setValue(parameterIndex, JDBCType.DECIMAL, x, JavaType.BIGDECIMAL, false);
/* 1191 */     loggerExternal.exiting(getClassNameLogging(), "setBigDecimal");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setBigDecimal(int parameterIndex, BigDecimal x, int precision, int scale) throws SQLServerException {
/* 1197 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1198 */       loggerExternal.entering(getClassNameLogging(), "setBigDecimal", new Object[] {
/* 1199 */             Integer.valueOf(parameterIndex), x, Integer.valueOf(precision), Integer.valueOf(scale) }); 
/* 1200 */     checkClosed();
/* 1201 */     setValue(parameterIndex, JDBCType.DECIMAL, x, JavaType.BIGDECIMAL, Integer.valueOf(precision), Integer.valueOf(scale), false);
/* 1202 */     loggerExternal.exiting(getClassNameLogging(), "setBigDecimal");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setBigDecimal(int parameterIndex, BigDecimal x, int precision, int scale, boolean forceEncrypt) throws SQLServerException {
/* 1208 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1209 */       loggerExternal.entering(getClassNameLogging(), "setBigDecimal", new Object[] {
/* 1210 */             Integer.valueOf(parameterIndex), x, Integer.valueOf(precision), Integer.valueOf(scale), Boolean.valueOf(forceEncrypt) }); 
/* 1211 */     checkClosed();
/* 1212 */     setValue(parameterIndex, JDBCType.DECIMAL, x, JavaType.BIGDECIMAL, Integer.valueOf(precision), Integer.valueOf(scale), forceEncrypt);
/* 1213 */     loggerExternal.exiting(getClassNameLogging(), "setBigDecimal");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setMoney(int n, BigDecimal x) throws SQLServerException {
/* 1218 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1219 */       loggerExternal.entering(getClassNameLogging(), "setMoney", new Object[] { Integer.valueOf(n), x }); 
/* 1220 */     checkClosed();
/* 1221 */     setValue(n, JDBCType.MONEY, x, JavaType.BIGDECIMAL, false);
/* 1222 */     loggerExternal.exiting(getClassNameLogging(), "setMoney");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setMoney(int n, BigDecimal x, boolean forceEncrypt) throws SQLServerException {
/* 1227 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1228 */       loggerExternal.entering(getClassNameLogging(), "setMoney", new Object[] { Integer.valueOf(n), x, Boolean.valueOf(forceEncrypt) }); 
/* 1229 */     checkClosed();
/* 1230 */     setValue(n, JDBCType.MONEY, x, JavaType.BIGDECIMAL, forceEncrypt);
/* 1231 */     loggerExternal.exiting(getClassNameLogging(), "setMoney");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setSmallMoney(int n, BigDecimal x) throws SQLServerException {
/* 1236 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1237 */       loggerExternal.entering(getClassNameLogging(), "setSmallMoney", new Object[] { Integer.valueOf(n), x }); 
/* 1238 */     checkClosed();
/* 1239 */     setValue(n, JDBCType.SMALLMONEY, x, JavaType.BIGDECIMAL, false);
/* 1240 */     loggerExternal.exiting(getClassNameLogging(), "setSmallMoney");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setSmallMoney(int n, BigDecimal x, boolean forceEncrypt) throws SQLServerException {
/* 1245 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1246 */       loggerExternal.entering(getClassNameLogging(), "setSmallMoney", new Object[] { Integer.valueOf(n), x, Boolean.valueOf(forceEncrypt) }); 
/* 1247 */     checkClosed();
/* 1248 */     setValue(n, JDBCType.SMALLMONEY, x, JavaType.BIGDECIMAL, forceEncrypt);
/* 1249 */     loggerExternal.exiting(getClassNameLogging(), "setSmallMoney");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setBinaryStream(int parameterIndex, InputStream x) throws SQLException {
/* 1254 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1255 */       loggerExternal.entering(getClassNameLogging(), "setBinaryStreaml", new Object[] { Integer.valueOf(parameterIndex), x }); 
/* 1256 */     checkClosed();
/* 1257 */     setStream(parameterIndex, StreamType.BINARY, x, JavaType.INPUTSTREAM, -1L);
/* 1258 */     loggerExternal.exiting(getClassNameLogging(), "setBinaryStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setBinaryStream(int n, InputStream x, int length) throws SQLServerException {
/* 1263 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1264 */       loggerExternal.entering(getClassNameLogging(), "setBinaryStream", new Object[] { Integer.valueOf(n), x, Integer.valueOf(length) }); 
/* 1265 */     checkClosed();
/* 1266 */     setStream(n, StreamType.BINARY, x, JavaType.INPUTSTREAM, length);
/* 1267 */     loggerExternal.exiting(getClassNameLogging(), "setBinaryStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setBinaryStream(int parameterIndex, InputStream x, long length) throws SQLException {
/* 1272 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1273 */       loggerExternal.entering(getClassNameLogging(), "setBinaryStream", new Object[] { Integer.valueOf(parameterIndex), x, Long.valueOf(length) }); 
/* 1274 */     checkClosed();
/* 1275 */     setStream(parameterIndex, StreamType.BINARY, x, JavaType.INPUTSTREAM, length);
/* 1276 */     loggerExternal.exiting(getClassNameLogging(), "setBinaryStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setBoolean(int n, boolean x) throws SQLServerException {
/* 1281 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1282 */       loggerExternal.entering(getClassNameLogging(), "setBoolean", new Object[] { Integer.valueOf(n), Boolean.valueOf(x) }); 
/* 1283 */     checkClosed();
/* 1284 */     setValue(n, JDBCType.BIT, Boolean.valueOf(x), JavaType.BOOLEAN, false);
/* 1285 */     loggerExternal.exiting(getClassNameLogging(), "setBoolean");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setBoolean(int n, boolean x, boolean forceEncrypt) throws SQLServerException {
/* 1290 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1291 */       loggerExternal.entering(getClassNameLogging(), "setBoolean", new Object[] { Integer.valueOf(n), Boolean.valueOf(x), Boolean.valueOf(forceEncrypt) }); 
/* 1292 */     checkClosed();
/* 1293 */     setValue(n, JDBCType.BIT, Boolean.valueOf(x), JavaType.BOOLEAN, forceEncrypt);
/* 1294 */     loggerExternal.exiting(getClassNameLogging(), "setBoolean");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setByte(int n, byte x) throws SQLServerException {
/* 1299 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1300 */       loggerExternal.entering(getClassNameLogging(), "setByte", new Object[] { Integer.valueOf(n), Byte.valueOf(x) }); 
/* 1301 */     checkClosed();
/* 1302 */     setValue(n, JDBCType.TINYINT, Byte.valueOf(x), JavaType.BYTE, false);
/* 1303 */     loggerExternal.exiting(getClassNameLogging(), "setByte");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setByte(int n, byte x, boolean forceEncrypt) throws SQLServerException {
/* 1308 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1309 */       loggerExternal.entering(getClassNameLogging(), "setByte", new Object[] { Integer.valueOf(n), Byte.valueOf(x), Boolean.valueOf(forceEncrypt) }); 
/* 1310 */     checkClosed();
/* 1311 */     setValue(n, JDBCType.TINYINT, Byte.valueOf(x), JavaType.BYTE, forceEncrypt);
/* 1312 */     loggerExternal.exiting(getClassNameLogging(), "setByte");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setBytes(int n, byte[] x) throws SQLServerException {
/* 1317 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1318 */       loggerExternal.entering(getClassNameLogging(), "setBytes", new Object[] { Integer.valueOf(n), x }); 
/* 1319 */     checkClosed();
/* 1320 */     setValue(n, JDBCType.BINARY, x, JavaType.BYTEARRAY, false);
/* 1321 */     loggerExternal.exiting(getClassNameLogging(), "setBytes");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setBytes(int n, byte[] x, boolean forceEncrypt) throws SQLServerException {
/* 1326 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1327 */       loggerExternal.entering(getClassNameLogging(), "setBytes", new Object[] { Integer.valueOf(n), x, Boolean.valueOf(forceEncrypt) }); 
/* 1328 */     checkClosed();
/* 1329 */     setValue(n, JDBCType.BINARY, x, JavaType.BYTEARRAY, forceEncrypt);
/* 1330 */     loggerExternal.exiting(getClassNameLogging(), "setBytes");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setUniqueIdentifier(int index, String guid) throws SQLServerException {
/* 1335 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1336 */       loggerExternal.entering(getClassNameLogging(), "setUniqueIdentifier", new Object[] { Integer.valueOf(index), guid }); 
/* 1337 */     checkClosed();
/* 1338 */     setValue(index, JDBCType.GUID, guid, JavaType.STRING, false);
/* 1339 */     loggerExternal.exiting(getClassNameLogging(), "setUniqueIdentifier");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setUniqueIdentifier(int index, String guid, boolean forceEncrypt) throws SQLServerException {
/* 1344 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1345 */       loggerExternal.entering(getClassNameLogging(), "setUniqueIdentifier", new Object[] {
/* 1346 */             Integer.valueOf(index), guid, Boolean.valueOf(forceEncrypt) }); 
/* 1347 */     checkClosed();
/* 1348 */     setValue(index, JDBCType.GUID, guid, JavaType.STRING, forceEncrypt);
/* 1349 */     loggerExternal.exiting(getClassNameLogging(), "setUniqueIdentifier");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setDouble(int n, double x) throws SQLServerException {
/* 1354 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1355 */       loggerExternal.entering(getClassNameLogging(), "setDouble", new Object[] { Integer.valueOf(n), Double.valueOf(x) }); 
/* 1356 */     checkClosed();
/* 1357 */     setValue(n, JDBCType.DOUBLE, Double.valueOf(x), JavaType.DOUBLE, false);
/* 1358 */     loggerExternal.exiting(getClassNameLogging(), "setDouble");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setDouble(int n, double x, boolean forceEncrypt) throws SQLServerException {
/* 1363 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1364 */       loggerExternal.entering(getClassNameLogging(), "setDouble", new Object[] { Integer.valueOf(n), Double.valueOf(x), Boolean.valueOf(forceEncrypt) }); 
/* 1365 */     checkClosed();
/* 1366 */     setValue(n, JDBCType.DOUBLE, Double.valueOf(x), JavaType.DOUBLE, forceEncrypt);
/* 1367 */     loggerExternal.exiting(getClassNameLogging(), "setDouble");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setFloat(int n, float x) throws SQLServerException {
/* 1372 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1373 */       loggerExternal.entering(getClassNameLogging(), "setFloat", new Object[] { Integer.valueOf(n), Float.valueOf(x) }); 
/* 1374 */     checkClosed();
/* 1375 */     setValue(n, JDBCType.REAL, Float.valueOf(x), JavaType.FLOAT, false);
/* 1376 */     loggerExternal.exiting(getClassNameLogging(), "setFloat");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setFloat(int n, float x, boolean forceEncrypt) throws SQLServerException {
/* 1381 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1382 */       loggerExternal.entering(getClassNameLogging(), "setFloat", new Object[] { Integer.valueOf(n), Float.valueOf(x), Boolean.valueOf(forceEncrypt) }); 
/* 1383 */     checkClosed();
/* 1384 */     setValue(n, JDBCType.REAL, Float.valueOf(x), JavaType.FLOAT, forceEncrypt);
/* 1385 */     loggerExternal.exiting(getClassNameLogging(), "setFloat");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setGeometry(int n, Geometry x) throws SQLServerException {
/* 1390 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1391 */       loggerExternal.entering(getClassNameLogging(), "setGeometry", new Object[] { Integer.valueOf(n), x }); 
/* 1392 */     checkClosed();
/* 1393 */     setValue(n, JDBCType.GEOMETRY, x, JavaType.STRING, false);
/* 1394 */     loggerExternal.exiting(getClassNameLogging(), "setGeometry");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setGeography(int n, Geography x) throws SQLServerException {
/* 1399 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1400 */       loggerExternal.entering(getClassNameLogging(), "setGeography", new Object[] { Integer.valueOf(n), x }); 
/* 1401 */     checkClosed();
/* 1402 */     setValue(n, JDBCType.GEOGRAPHY, x, JavaType.STRING, false);
/* 1403 */     loggerExternal.exiting(getClassNameLogging(), "setGeography");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setInt(int n, int value) throws SQLServerException {
/* 1408 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1409 */       loggerExternal.entering(getClassNameLogging(), "setInt", new Object[] { Integer.valueOf(n), Integer.valueOf(value) }); 
/* 1410 */     checkClosed();
/* 1411 */     setValue(n, JDBCType.INTEGER, Integer.valueOf(value), JavaType.INTEGER, false);
/* 1412 */     loggerExternal.exiting(getClassNameLogging(), "setInt");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setInt(int n, int value, boolean forceEncrypt) throws SQLServerException {
/* 1417 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1418 */       loggerExternal.entering(getClassNameLogging(), "setInt", new Object[] { Integer.valueOf(n), Integer.valueOf(value), Boolean.valueOf(forceEncrypt) }); 
/* 1419 */     checkClosed();
/* 1420 */     setValue(n, JDBCType.INTEGER, Integer.valueOf(value), JavaType.INTEGER, forceEncrypt);
/* 1421 */     loggerExternal.exiting(getClassNameLogging(), "setInt");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setLong(int n, long x) throws SQLServerException {
/* 1426 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1427 */       loggerExternal.entering(getClassNameLogging(), "setLong", new Object[] { Integer.valueOf(n), Long.valueOf(x) }); 
/* 1428 */     checkClosed();
/* 1429 */     setValue(n, JDBCType.BIGINT, Long.valueOf(x), JavaType.LONG, false);
/* 1430 */     loggerExternal.exiting(getClassNameLogging(), "setLong");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setLong(int n, long x, boolean forceEncrypt) throws SQLServerException {
/* 1435 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1436 */       loggerExternal.entering(getClassNameLogging(), "setLong", new Object[] { Integer.valueOf(n), Long.valueOf(x), Boolean.valueOf(forceEncrypt) }); 
/* 1437 */     checkClosed();
/* 1438 */     setValue(n, JDBCType.BIGINT, Long.valueOf(x), JavaType.LONG, forceEncrypt);
/* 1439 */     loggerExternal.exiting(getClassNameLogging(), "setLong");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setNull(int index, int jdbcType) throws SQLServerException {
/* 1444 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1445 */       loggerExternal.entering(getClassNameLogging(), "setNull", new Object[] { Integer.valueOf(index), Integer.valueOf(jdbcType) }); 
/* 1446 */     checkClosed();
/* 1447 */     setObject(setterGetParam(index), (Object)null, JavaType.OBJECT, JDBCType.of(jdbcType), (Integer)null, (Integer)null, false, index, (String)null);
/* 1448 */     loggerExternal.exiting(getClassNameLogging(), "setNull");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   final void setObjectNoType(int index, Object obj, boolean forceEncrypt) throws SQLServerException {
/* 1454 */     Parameter param = setterGetParam(index);
/* 1455 */     JDBCType targetJDBCType = param.getJdbcType();
/* 1456 */     String tvpName = null;
/*      */     
/* 1458 */     if (null == obj) {
/*      */ 
/*      */       
/* 1461 */       if (JDBCType.UNKNOWN == targetJDBCType) {
/* 1462 */         targetJDBCType = JDBCType.CHAR;
/*      */       }
/* 1464 */       setObject(param, (Object)null, JavaType.OBJECT, targetJDBCType, (Integer)null, (Integer)null, forceEncrypt, index, (String)null);
/*      */     } else {
/* 1466 */       JavaType javaType = JavaType.of(obj);
/* 1467 */       if (JavaType.TVP == javaType) {
/*      */         
/* 1469 */         tvpName = getTVPNameFromObject(index, obj);
/*      */         
/* 1471 */         if (null == tvpName && obj instanceof ResultSet) {
/* 1472 */           throw new SQLServerException(SQLServerException.getErrString("R_TVPnotWorkWithSetObjectResultSet"), null);
/*      */         }
/*      */       } 
/*      */       
/* 1476 */       targetJDBCType = javaType.getJDBCType(SSType.UNKNOWN, targetJDBCType);
/*      */       
/* 1478 */       if (JDBCType.UNKNOWN == targetJDBCType && 
/* 1479 */         obj instanceof java.util.UUID) {
/* 1480 */         javaType = JavaType.STRING;
/* 1481 */         targetJDBCType = JDBCType.GUID;
/*      */       } 
/*      */ 
/*      */       
/* 1485 */       setObject(param, obj, javaType, targetJDBCType, (Integer)null, (Integer)null, forceEncrypt, index, tvpName);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setObject(int index, Object obj) throws SQLServerException {
/* 1491 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1492 */       loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] { Integer.valueOf(index), obj }); 
/* 1493 */     checkClosed();
/* 1494 */     setObjectNoType(index, obj, false);
/* 1495 */     loggerExternal.exiting(getClassNameLogging(), "setObject");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setObject(int n, Object obj, int jdbcType) throws SQLServerException {
/* 1500 */     String tvpName = null;
/* 1501 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1502 */       loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] { Integer.valueOf(n), obj, Integer.valueOf(jdbcType) }); 
/* 1503 */     checkClosed();
/* 1504 */     if (-153 == jdbcType) {
/* 1505 */       tvpName = getTVPNameFromObject(n, obj);
/*      */     }
/* 1507 */     setObject(setterGetParam(n), obj, JavaType.of(obj), JDBCType.of(jdbcType), (Integer)null, (Integer)null, false, n, tvpName);
/* 1508 */     loggerExternal.exiting(getClassNameLogging(), "setObject");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setObject(int parameterIndex, Object x, int targetSqlType, int scaleOrLength) throws SQLServerException {
/* 1514 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1515 */       loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] {
/* 1516 */             Integer.valueOf(parameterIndex), x, Integer.valueOf(targetSqlType), Integer.valueOf(scaleOrLength) }); 
/* 1517 */     checkClosed();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1524 */     setObject(setterGetParam(parameterIndex), x, JavaType.of(x), JDBCType.of(targetSqlType), (
/* 1525 */         2 == targetSqlType || 3 == targetSqlType || 93 == targetSqlType || 92 == targetSqlType || -155 == targetSqlType || InputStream.class
/*      */         
/* 1527 */         .isInstance(x) || Reader.class
/* 1528 */         .isInstance(x)) ? Integer.valueOf(scaleOrLength) : null, (Integer)null, false, parameterIndex, (String)null);
/*      */ 
/*      */     
/* 1531 */     loggerExternal.exiting(getClassNameLogging(), "setObject");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setObject(int parameterIndex, Object x, int targetSqlType, Integer precision, int scale) throws SQLServerException {
/* 1537 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1538 */       loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] {
/* 1539 */             Integer.valueOf(parameterIndex), x, Integer.valueOf(targetSqlType), precision, Integer.valueOf(scale) }); 
/* 1540 */     checkClosed();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1547 */     setObject(setterGetParam(parameterIndex), x, JavaType.of(x), JDBCType.of(targetSqlType), (
/* 1548 */         2 == targetSqlType || 3 == targetSqlType || InputStream.class
/* 1549 */         .isInstance(x) || Reader.class.isInstance(x)) ? Integer.valueOf(scale) : null, precision, false, parameterIndex, (String)null);
/*      */ 
/*      */     
/* 1552 */     loggerExternal.exiting(getClassNameLogging(), "setObject");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setObject(int parameterIndex, Object x, int targetSqlType, Integer precision, int scale, boolean forceEncrypt) throws SQLServerException {
/* 1558 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1559 */       loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] {
/* 1560 */             Integer.valueOf(parameterIndex), x, Integer.valueOf(targetSqlType), precision, Integer.valueOf(scale), Boolean.valueOf(forceEncrypt) }); 
/* 1561 */     checkClosed();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1568 */     setObject(setterGetParam(parameterIndex), x, JavaType.of(x), JDBCType.of(targetSqlType), (
/* 1569 */         2 == targetSqlType || 3 == targetSqlType || InputStream.class
/* 1570 */         .isInstance(x) || Reader.class.isInstance(x)) ? Integer.valueOf(scale) : null, precision, forceEncrypt, parameterIndex, (String)null);
/*      */ 
/*      */     
/* 1573 */     loggerExternal.exiting(getClassNameLogging(), "setObject");
/*      */   }
/*      */ 
/*      */   
/*      */   final void setObject(Parameter param, Object obj, JavaType javaType, JDBCType jdbcType, Integer scale, Integer precision, boolean forceEncrypt, int parameterIndex, String tvpName) throws SQLServerException {
/* 1578 */     assert JDBCType.UNKNOWN != jdbcType;
/*      */ 
/*      */ 
/*      */     
/* 1582 */     if (null != obj || JavaType.TVP == javaType) {
/*      */       
/* 1584 */       JDBCType objectJDBCType = javaType.getJDBCType(SSType.UNKNOWN, jdbcType);
/*      */ 
/*      */       
/* 1587 */       if (!objectJDBCType.convertsTo(jdbcType)) {
/* 1588 */         DataTypes.throwConversionError(objectJDBCType.toString(), jdbcType.toString());
/*      */       }
/* 1590 */       StreamSetterArgs streamSetterArgs = null;
/*      */       
/* 1592 */       switch (javaType) {
/*      */         case READER:
/* 1594 */           streamSetterArgs = new StreamSetterArgs(StreamType.CHARACTER, -1L);
/*      */           break;
/*      */ 
/*      */         
/*      */         case INPUTSTREAM:
/* 1599 */           streamSetterArgs = new StreamSetterArgs(jdbcType.isTextual() ? StreamType.CHARACTER : StreamType.BINARY, -1L);
/*      */           break;
/*      */ 
/*      */         
/*      */         case SQLXML:
/* 1604 */           streamSetterArgs = new StreamSetterArgs(StreamType.SQLXML, -1L);
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1612 */       param.setValue(jdbcType, obj, javaType, streamSetterArgs, null, precision, scale, this.connection, forceEncrypt, this.stmtColumnEncriptionSetting, parameterIndex, this.userSQL, tvpName);
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/* 1619 */       assert JavaType.OBJECT == javaType;
/*      */       
/* 1621 */       if (jdbcType.isUnsupported()) {
/* 1622 */         jdbcType = JDBCType.BINARY;
/*      */       }
/*      */       
/* 1625 */       param.setValue(jdbcType, null, JavaType.OBJECT, null, null, precision, scale, this.connection, false, this.stmtColumnEncriptionSetting, parameterIndex, this.userSQL, tvpName);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setObject(int index, Object obj, SQLType jdbcType) throws SQLServerException {
/* 1632 */     setObject(index, obj, jdbcType.getVendorTypeNumber().intValue());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setObject(int parameterIndex, Object x, SQLType targetSqlType, int scaleOrLength) throws SQLServerException {
/* 1638 */     setObject(parameterIndex, x, targetSqlType.getVendorTypeNumber().intValue(), scaleOrLength);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setObject(int parameterIndex, Object x, SQLType targetSqlType, Integer precision, Integer scale) throws SQLServerException {
/* 1644 */     setObject(parameterIndex, x, targetSqlType.getVendorTypeNumber().intValue(), precision, scale.intValue());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setObject(int parameterIndex, Object x, SQLType targetSqlType, Integer precision, Integer scale, boolean forceEncrypt) throws SQLServerException {
/* 1650 */     setObject(parameterIndex, x, targetSqlType.getVendorTypeNumber().intValue(), precision, scale.intValue(), forceEncrypt);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setShort(int index, short x) throws SQLServerException {
/* 1655 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1656 */       loggerExternal.entering(getClassNameLogging(), "setShort", new Object[] { Integer.valueOf(index), Short.valueOf(x) }); 
/* 1657 */     checkClosed();
/* 1658 */     setValue(index, JDBCType.SMALLINT, Short.valueOf(x), JavaType.SHORT, false);
/* 1659 */     loggerExternal.exiting(getClassNameLogging(), "setShort");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setShort(int index, short x, boolean forceEncrypt) throws SQLServerException {
/* 1664 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1665 */       loggerExternal.entering(getClassNameLogging(), "setShort", new Object[] { Integer.valueOf(index), Short.valueOf(x), Boolean.valueOf(forceEncrypt) }); 
/* 1666 */     checkClosed();
/* 1667 */     setValue(index, JDBCType.SMALLINT, Short.valueOf(x), JavaType.SHORT, forceEncrypt);
/* 1668 */     loggerExternal.exiting(getClassNameLogging(), "setShort");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setString(int index, String str) throws SQLServerException {
/* 1673 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1674 */       loggerExternal.entering(getClassNameLogging(), "setString", new Object[] { Integer.valueOf(index), str }); 
/* 1675 */     checkClosed();
/* 1676 */     setValue(index, JDBCType.VARCHAR, str, JavaType.STRING, false);
/* 1677 */     loggerExternal.exiting(getClassNameLogging(), "setString");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setString(int index, String str, boolean forceEncrypt) throws SQLServerException {
/* 1682 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1683 */       loggerExternal.entering(getClassNameLogging(), "setString", new Object[] { Integer.valueOf(index), str, Boolean.valueOf(forceEncrypt) }); 
/* 1684 */     checkClosed();
/* 1685 */     setValue(index, JDBCType.VARCHAR, str, JavaType.STRING, forceEncrypt);
/* 1686 */     loggerExternal.exiting(getClassNameLogging(), "setString");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setNString(int parameterIndex, String value) throws SQLException {
/* 1691 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1692 */       loggerExternal.entering(getClassNameLogging(), "setNString", new Object[] { Integer.valueOf(parameterIndex), value }); 
/* 1693 */     checkClosed();
/* 1694 */     setValue(parameterIndex, JDBCType.NVARCHAR, value, JavaType.STRING, false);
/* 1695 */     loggerExternal.exiting(getClassNameLogging(), "setNString");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setNString(int parameterIndex, String value, boolean forceEncrypt) throws SQLServerException {
/* 1700 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1701 */       loggerExternal.entering(getClassNameLogging(), "setNString", new Object[] {
/* 1702 */             Integer.valueOf(parameterIndex), value, Boolean.valueOf(forceEncrypt) }); 
/* 1703 */     checkClosed();
/* 1704 */     setValue(parameterIndex, JDBCType.NVARCHAR, value, JavaType.STRING, forceEncrypt);
/* 1705 */     loggerExternal.exiting(getClassNameLogging(), "setNString");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setTime(int n, Time x) throws SQLServerException {
/* 1710 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1711 */       loggerExternal.entering(getClassNameLogging(), "setTime", new Object[] { Integer.valueOf(n), x }); 
/* 1712 */     checkClosed();
/* 1713 */     setValue(n, JDBCType.TIME, x, JavaType.TIME, false);
/* 1714 */     loggerExternal.exiting(getClassNameLogging(), "setTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setTime(int n, Time x, int scale) throws SQLServerException {
/* 1719 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1720 */       loggerExternal.entering(getClassNameLogging(), "setTime", new Object[] { Integer.valueOf(n), x, Integer.valueOf(scale) }); 
/* 1721 */     checkClosed();
/* 1722 */     setValue(n, JDBCType.TIME, x, JavaType.TIME, (Integer)null, Integer.valueOf(scale), false);
/* 1723 */     loggerExternal.exiting(getClassNameLogging(), "setTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setTime(int n, Time x, int scale, boolean forceEncrypt) throws SQLServerException {
/* 1728 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1729 */       loggerExternal.entering(getClassNameLogging(), "setTime", new Object[] { Integer.valueOf(n), x, Integer.valueOf(scale), Boolean.valueOf(forceEncrypt) }); 
/* 1730 */     checkClosed();
/* 1731 */     setValue(n, JDBCType.TIME, x, JavaType.TIME, (Integer)null, Integer.valueOf(scale), forceEncrypt);
/* 1732 */     loggerExternal.exiting(getClassNameLogging(), "setTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setTimestamp(int n, Timestamp x) throws SQLServerException {
/* 1737 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1738 */       loggerExternal.entering(getClassNameLogging(), "setTimestamp", new Object[] { Integer.valueOf(n), x }); 
/* 1739 */     checkClosed();
/* 1740 */     setValue(n, JDBCType.TIMESTAMP, x, JavaType.TIMESTAMP, false);
/* 1741 */     loggerExternal.exiting(getClassNameLogging(), "setTimestamp");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setTimestamp(int n, Timestamp x, int scale) throws SQLServerException {
/* 1746 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1747 */       loggerExternal.entering(getClassNameLogging(), "setTimestamp", new Object[] { Integer.valueOf(n), x, Integer.valueOf(scale) }); 
/* 1748 */     checkClosed();
/* 1749 */     setValue(n, JDBCType.TIMESTAMP, x, JavaType.TIMESTAMP, (Integer)null, Integer.valueOf(scale), false);
/* 1750 */     loggerExternal.exiting(getClassNameLogging(), "setTimestamp");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setTimestamp(int n, Timestamp x, int scale, boolean forceEncrypt) throws SQLServerException {
/* 1756 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1757 */       loggerExternal.entering(getClassNameLogging(), "setTimestamp", new Object[] { Integer.valueOf(n), x, Integer.valueOf(scale), Boolean.valueOf(forceEncrypt) }); 
/* 1758 */     checkClosed();
/* 1759 */     setValue(n, JDBCType.TIMESTAMP, x, JavaType.TIMESTAMP, (Integer)null, Integer.valueOf(scale), forceEncrypt);
/* 1760 */     loggerExternal.exiting(getClassNameLogging(), "setTimestamp");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setDateTimeOffset(int n, DateTimeOffset x) throws SQLServerException {
/* 1765 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1766 */       loggerExternal.entering(getClassNameLogging(), "setDateTimeOffset", new Object[] { Integer.valueOf(n), x }); 
/* 1767 */     checkClosed();
/* 1768 */     setValue(n, JDBCType.DATETIMEOFFSET, x, JavaType.DATETIMEOFFSET, false);
/* 1769 */     loggerExternal.exiting(getClassNameLogging(), "setDateTimeOffset");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setDateTimeOffset(int n, DateTimeOffset x, int scale) throws SQLServerException {
/* 1774 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1775 */       loggerExternal.entering(getClassNameLogging(), "setDateTimeOffset", new Object[] { Integer.valueOf(n), x, Integer.valueOf(scale) }); 
/* 1776 */     checkClosed();
/* 1777 */     setValue(n, JDBCType.DATETIMEOFFSET, x, JavaType.DATETIMEOFFSET, (Integer)null, Integer.valueOf(scale), false);
/* 1778 */     loggerExternal.exiting(getClassNameLogging(), "setDateTimeOffset");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setDateTimeOffset(int n, DateTimeOffset x, int scale, boolean forceEncrypt) throws SQLServerException {
/* 1784 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1785 */       loggerExternal.entering(getClassNameLogging(), "setDateTimeOffset", new Object[] {
/* 1786 */             Integer.valueOf(n), x, Integer.valueOf(scale), Boolean.valueOf(forceEncrypt) }); 
/* 1787 */     checkClosed();
/* 1788 */     setValue(n, JDBCType.DATETIMEOFFSET, x, JavaType.DATETIMEOFFSET, (Integer)null, Integer.valueOf(scale), forceEncrypt);
/* 1789 */     loggerExternal.exiting(getClassNameLogging(), "setDateTimeOffset");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setDate(int n, Date x) throws SQLServerException {
/* 1794 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1795 */       loggerExternal.entering(getClassNameLogging(), "setDate", new Object[] { Integer.valueOf(n), x }); 
/* 1796 */     checkClosed();
/* 1797 */     setValue(n, JDBCType.DATE, x, JavaType.DATE, false);
/* 1798 */     loggerExternal.exiting(getClassNameLogging(), "setDate");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setDateTime(int n, Timestamp x) throws SQLServerException {
/* 1803 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1804 */       loggerExternal.entering(getClassNameLogging(), "setDateTime", new Object[] { Integer.valueOf(n), x }); 
/* 1805 */     checkClosed();
/* 1806 */     setValue(n, JDBCType.DATETIME, x, JavaType.TIMESTAMP, false);
/* 1807 */     loggerExternal.exiting(getClassNameLogging(), "setDateTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setDateTime(int n, Timestamp x, boolean forceEncrypt) throws SQLServerException {
/* 1812 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1813 */       loggerExternal.entering(getClassNameLogging(), "setDateTime", new Object[] { Integer.valueOf(n), x, Boolean.valueOf(forceEncrypt) }); 
/* 1814 */     checkClosed();
/* 1815 */     setValue(n, JDBCType.DATETIME, x, JavaType.TIMESTAMP, forceEncrypt);
/* 1816 */     loggerExternal.exiting(getClassNameLogging(), "setDateTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setSmallDateTime(int n, Timestamp x) throws SQLServerException {
/* 1821 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1822 */       loggerExternal.entering(getClassNameLogging(), "setSmallDateTime", new Object[] { Integer.valueOf(n), x }); 
/* 1823 */     checkClosed();
/* 1824 */     setValue(n, JDBCType.SMALLDATETIME, x, JavaType.TIMESTAMP, false);
/* 1825 */     loggerExternal.exiting(getClassNameLogging(), "setSmallDateTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setSmallDateTime(int n, Timestamp x, boolean forceEncrypt) throws SQLServerException {
/* 1830 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1831 */       loggerExternal.entering(getClassNameLogging(), "setSmallDateTime", new Object[] { Integer.valueOf(n), x, Boolean.valueOf(forceEncrypt) }); 
/* 1832 */     checkClosed();
/* 1833 */     setValue(n, JDBCType.SMALLDATETIME, x, JavaType.TIMESTAMP, forceEncrypt);
/* 1834 */     loggerExternal.exiting(getClassNameLogging(), "setSmallDateTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setStructured(int n, String tvpName, SQLServerDataTable tvpDataTable) throws SQLServerException {
/* 1839 */     tvpName = getTVPNameIfNull(n, tvpName);
/* 1840 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1841 */       loggerExternal.entering(getClassNameLogging(), "setStructured", new Object[] { Integer.valueOf(n), tvpName, tvpDataTable }); 
/* 1842 */     checkClosed();
/* 1843 */     setValue(n, JDBCType.TVP, tvpDataTable, JavaType.TVP, tvpName);
/* 1844 */     loggerExternal.exiting(getClassNameLogging(), "setStructured");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setStructured(int n, String tvpName, ResultSet tvpResultSet) throws SQLServerException {
/* 1849 */     tvpName = getTVPNameIfNull(n, tvpName);
/* 1850 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1851 */       loggerExternal.entering(getClassNameLogging(), "setStructured", new Object[] { Integer.valueOf(n), tvpName, tvpResultSet }); 
/* 1852 */     checkClosed();
/* 1853 */     setValue(n, JDBCType.TVP, tvpResultSet, JavaType.TVP, tvpName);
/* 1854 */     loggerExternal.exiting(getClassNameLogging(), "setStructured");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setStructured(int n, String tvpName, ISQLServerDataRecord tvpBulkRecord) throws SQLServerException {
/* 1860 */     tvpName = getTVPNameIfNull(n, tvpName);
/* 1861 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1862 */       loggerExternal.entering(getClassNameLogging(), "setStructured", new Object[] { Integer.valueOf(n), tvpName, tvpBulkRecord }); 
/* 1863 */     checkClosed();
/* 1864 */     setValue(n, JDBCType.TVP, tvpBulkRecord, JavaType.TVP, tvpName);
/* 1865 */     loggerExternal.exiting(getClassNameLogging(), "setStructured");
/*      */   }
/*      */   
/*      */   String getTVPNameFromObject(int n, Object obj) throws SQLServerException {
/* 1869 */     String tvpName = null;
/* 1870 */     if (obj instanceof SQLServerDataTable) {
/* 1871 */       tvpName = ((SQLServerDataTable)obj).getTvpName();
/*      */     }
/*      */     
/* 1874 */     return getTVPNameIfNull(n, tvpName);
/*      */   }
/*      */   
/*      */   String getTVPNameIfNull(int n, String tvpName) throws SQLServerException {
/* 1878 */     if (null == tvpName || 0 == tvpName.length())
/*      */     {
/* 1880 */       if (null != this.procedureName) {
/* 1881 */         SQLServerParameterMetaData pmd = (SQLServerParameterMetaData)getParameterMetaData();
/* 1882 */         pmd.isTVP = true;
/*      */         
/* 1884 */         if (!pmd.procedureIsFound) {
/*      */           
/* 1886 */           MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_StoredProcedureNotFound"));
/* 1887 */           Object[] msgArgs = { this.procedureName };
/* 1888 */           SQLServerException.makeFromDriverError(this.connection, pmd, form.format(msgArgs), (String)null, false);
/*      */         } 
/*      */         
/*      */         try {
/* 1892 */           String tvpNameWithoutSchema = pmd.getParameterTypeName(n);
/* 1893 */           String tvpSchema = pmd.getTVPSchemaFromStoredProcedure(n);
/*      */           
/* 1895 */           if (null != tvpSchema) {
/* 1896 */             tvpName = "[" + tvpSchema + "].[" + tvpNameWithoutSchema + "]";
/*      */           } else {
/* 1898 */             tvpName = tvpNameWithoutSchema;
/*      */           } 
/* 1900 */         } catch (SQLException e) {
/* 1901 */           throw new SQLServerException(SQLServerException.getErrString("R_metaDataErrorForParameter"), null, 0, e);
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/* 1906 */     return tvpName;
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final void setUnicodeStream(int n, InputStream x, int length) throws SQLException {
/* 1912 */     SQLServerException.throwNotSupportedException(this.connection, this);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void addBatch() throws SQLServerException {
/* 1917 */     loggerExternal.entering(getClassNameLogging(), "addBatch");
/* 1918 */     checkClosed();
/*      */ 
/*      */     
/* 1921 */     if (this.batchParamValues == null) {
/* 1922 */       this.batchParamValues = (ArrayList)new ArrayList<>();
/*      */     }
/* 1924 */     int numParams = this.inOutParam.length;
/* 1925 */     Parameter[] paramValues = new Parameter[numParams];
/* 1926 */     for (int i = 0; i < numParams; i++)
/* 1927 */       paramValues[i] = this.inOutParam[i].cloneForBatch(); 
/* 1928 */     this.batchParamValues.add(paramValues);
/* 1929 */     loggerExternal.exiting(getClassNameLogging(), "addBatch");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void clearBatch() throws SQLServerException {
/* 1934 */     loggerExternal.entering(getClassNameLogging(), "clearBatch");
/* 1935 */     checkClosed();
/* 1936 */     this.batchParamValues = null;
/* 1937 */     loggerExternal.exiting(getClassNameLogging(), "clearBatch");
/*      */   }
/*      */   
/*      */   public int[] executeBatch() throws SQLServerException, BatchUpdateException, SQLTimeoutException {
/*      */     int[] updateCounts;
/* 1942 */     loggerExternal.entering(getClassNameLogging(), "executeBatch");
/* 1943 */     if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) {
/* 1944 */       loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */     }
/* 1946 */     checkClosed();
/* 1947 */     discardLastExecutionResults();
/*      */ 
/*      */ 
/*      */     
/* 1951 */     this.localUserSQL = this.userSQL;
/*      */ 
/*      */     
/* 1954 */     try { if (this.useBulkCopyForBatchInsert && isInsert(this.localUserSQL))
/* 1955 */       { if (null == this.batchParamValues) {
/* 1956 */           updateCounts = new int[0];
/* 1957 */           loggerExternal.exiting(getClassNameLogging(), "executeBatch", updateCounts);
/* 1958 */           return updateCounts;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1971 */         for (Parameter[] paramValues : this.batchParamValues) {
/* 1972 */           for (Parameter paramValue : paramValues) {
/* 1973 */             if (paramValue.isOutput()) {
/* 1974 */               throw new BatchUpdateException(
/* 1975 */                   SQLServerException.getErrString("R_outParamsNotPermittedinBatch"), null, 0, null);
/*      */             }
/*      */           } 
/*      */         } 
/*      */         
/* 1980 */         String tableName = parseUserSQLForTableNameDW(false, false, false, false);
/* 1981 */         ArrayList<String> columnList = parseUserSQLForColumnListDW();
/* 1982 */         ArrayList<String> valueList = parseUserSQLForValueListDW(false);
/*      */         
/* 1984 */         checkAdditionalQuery();
/*      */         
/* 1986 */         SQLServerStatement stmt = (SQLServerStatement)this.connection.createStatement(1003, 1007, this.connection
/* 1987 */             .getHoldability(), this.stmtColumnEncriptionSetting);
/*      */ 
/*      */         
/* 1990 */         try { SQLServerResultSet rs = stmt.executeQueryInternal("sp_executesql N'SET FMTONLY ON SELECT * FROM " + 
/* 1991 */               Util.escapeSingleQuotes(tableName) + " '"); 
/* 1992 */           try { if (null != columnList && columnList.size() > 0) {
/* 1993 */               if (columnList.size() != valueList.size()) {
/* 1994 */                 throw new IllegalArgumentException("Number of provided columns does not match the table definition.");
/*      */               
/*      */               }
/*      */             }
/* 1998 */             else if (rs.getColumnCount() != valueList.size()) {
/* 1999 */               throw new IllegalArgumentException("Number of provided columns does not match the table definition.");
/*      */             } 
/*      */ 
/*      */ 
/*      */             
/* 2004 */             SQLServerBulkBatchInsertRecord batchRecord = new SQLServerBulkBatchInsertRecord(this.batchParamValues, columnList, valueList, null);
/*      */ 
/*      */             
/* 2007 */             for (int i = 1; i <= rs.getColumnCount(); i++) {
/* 2008 */               int jdbctype; Column c = rs.getColumn(i);
/* 2009 */               CryptoMetadata cryptoMetadata = c.getCryptoMetadata();
/*      */               
/* 2011 */               TypeInfo ti = c.getTypeInfo();
/* 2012 */               checkValidColumns(ti);
/* 2013 */               if (null != cryptoMetadata) {
/* 2014 */                 jdbctype = cryptoMetadata.getBaseTypeInfo().getSSType().getJDBCType().getIntValue();
/*      */               } else {
/* 2016 */                 jdbctype = ti.getSSType().getJDBCType().getIntValue();
/*      */               } 
/* 2018 */               batchRecord.addColumnMetadata(i, c.getColumnName(), jdbctype, ti.getPrecision(), ti.getScale());
/*      */             } 
/*      */             
/* 2021 */             SQLServerBulkCopy bcOperation = new SQLServerBulkCopy(this.connection);
/* 2022 */             SQLServerBulkCopyOptions option = new SQLServerBulkCopyOptions();
/* 2023 */             option.setBulkCopyTimeout(this.queryTimeout);
/* 2024 */             bcOperation.setBulkCopyOptions(option);
/* 2025 */             bcOperation.setDestinationTableName(tableName);
/* 2026 */             bcOperation.setStmtColumnEncriptionSetting(getStmtColumnEncriptionSetting());
/* 2027 */             bcOperation.setDestinationTableMetadata(rs);
/* 2028 */             bcOperation.writeToServer(batchRecord);
/* 2029 */             bcOperation.close();
/* 2030 */             updateCounts = new int[this.batchParamValues.size()];
/* 2031 */             for (int j = 0; j < this.batchParamValues.size(); j++) {
/* 2032 */               updateCounts[j] = 1;
/*      */             }
/*      */             
/* 2035 */             this.batchParamValues = null;
/* 2036 */             loggerExternal.exiting(getClassNameLogging(), "executeBatch", updateCounts);
/* 2037 */             int[] arrayOfInt = updateCounts;
/* 2038 */             if (rs != null) rs.close();  if (stmt != null) stmt.close();  return arrayOfInt; } catch (Throwable throwable) { if (rs != null)
/*      */               try { rs.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (Throwable throwable) { if (stmt != null)
/* 2040 */             try { stmt.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  }  } catch (SQLException e)
/*      */     
/* 2042 */     { throw new BatchUpdateException(e.getMessage(), null, 0, null); }
/* 2043 */     catch (IllegalArgumentException e)
/*      */     
/* 2045 */     { if (getStatementLogger().isLoggable(Level.FINE)) {
/* 2046 */         getStatementLogger().fine("Parsing user's Batch Insert SQL Query failed: " + e.getMessage());
/* 2047 */         getStatementLogger().fine("Falling back to the original implementation for Batch Insert.");
/*      */       }  }
/*      */ 
/*      */     
/* 2051 */     if (null == this.batchParamValues) {
/* 2052 */       updateCounts = new int[0];
/*      */     } else {
/*      */ 
/*      */       
/*      */       try {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2065 */         for (Parameter[] paramValues : this.batchParamValues) {
/* 2066 */           for (Parameter paramValue : paramValues) {
/* 2067 */             if (paramValue.isOutput()) {
/* 2068 */               throw new BatchUpdateException(
/* 2069 */                   SQLServerException.getErrString("R_outParamsNotPermittedinBatch"), null, 0, null);
/*      */             }
/*      */           } 
/*      */         } 
/*      */         
/* 2074 */         PrepStmtBatchExecCmd batchCommand = new PrepStmtBatchExecCmd(this);
/*      */         
/* 2076 */         executeStatement(batchCommand);
/*      */         
/* 2078 */         updateCounts = new int[batchCommand.updateCounts.length];
/* 2079 */         for (int i = 0; i < batchCommand.updateCounts.length; i++) {
/* 2080 */           updateCounts[i] = (int)batchCommand.updateCounts[i];
/*      */         }
/*      */         
/* 2083 */         if (null != batchCommand.batchException) {
/* 2084 */           throw new BatchUpdateException(batchCommand.batchException.getMessage(), batchCommand.batchException
/* 2085 */               .getSQLState(), batchCommand.batchException.getErrorCode(), updateCounts);
/*      */         }
/*      */       }
/*      */       finally {
/*      */         
/* 2090 */         this.batchParamValues = null;
/*      */       } 
/*      */     } 
/* 2093 */     loggerExternal.exiting(getClassNameLogging(), "executeBatch", updateCounts);
/* 2094 */     return updateCounts;
/*      */   }
/*      */   
/*      */   public long[] executeLargeBatch() throws SQLServerException, BatchUpdateException, SQLTimeoutException {
/*      */     long[] updateCounts;
/* 2099 */     loggerExternal.entering(getClassNameLogging(), "executeLargeBatch");
/* 2100 */     if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) {
/* 2101 */       loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */     }
/* 2103 */     checkClosed();
/* 2104 */     discardLastExecutionResults();
/*      */ 
/*      */ 
/*      */     
/* 2108 */     this.localUserSQL = this.userSQL;
/*      */ 
/*      */     
/* 2111 */     try { if (this.useBulkCopyForBatchInsert && isInsert(this.localUserSQL))
/* 2112 */       { if (null == this.batchParamValues) {
/* 2113 */           updateCounts = new long[0];
/* 2114 */           loggerExternal.exiting(getClassNameLogging(), "executeLargeBatch", updateCounts);
/* 2115 */           return updateCounts;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2128 */         for (Parameter[] paramValues : this.batchParamValues) {
/* 2129 */           for (Parameter paramValue : paramValues) {
/* 2130 */             if (paramValue.isOutput()) {
/* 2131 */               throw new BatchUpdateException(
/* 2132 */                   SQLServerException.getErrString("R_outParamsNotPermittedinBatch"), null, 0, null);
/*      */             }
/*      */           } 
/*      */         } 
/*      */         
/* 2137 */         String tableName = parseUserSQLForTableNameDW(false, false, false, false);
/* 2138 */         ArrayList<String> columnList = parseUserSQLForColumnListDW();
/* 2139 */         ArrayList<String> valueList = parseUserSQLForValueListDW(false);
/*      */         
/* 2141 */         checkAdditionalQuery();
/*      */         
/* 2143 */         SQLServerStatement stmt = (SQLServerStatement)this.connection.createStatement(1003, 1007, this.connection
/* 2144 */             .getHoldability(), this.stmtColumnEncriptionSetting);
/*      */ 
/*      */         
/* 2147 */         try { SQLServerResultSet rs = stmt.executeQueryInternal("sp_executesql N'SET FMTONLY ON SELECT * FROM " + 
/* 2148 */               Util.escapeSingleQuotes(tableName) + " '"); 
/* 2149 */           try { if (null != columnList && columnList.size() > 0) {
/* 2150 */               if (columnList.size() != valueList.size()) {
/* 2151 */                 throw new IllegalArgumentException("Number of provided columns does not match the table definition.");
/*      */               
/*      */               }
/*      */             }
/* 2155 */             else if (rs.getColumnCount() != valueList.size()) {
/* 2156 */               throw new IllegalArgumentException("Number of provided columns does not match the table definition.");
/*      */             } 
/*      */ 
/*      */ 
/*      */             
/* 2161 */             SQLServerBulkBatchInsertRecord batchRecord = new SQLServerBulkBatchInsertRecord(this.batchParamValues, columnList, valueList, null);
/*      */ 
/*      */             
/* 2164 */             for (int i = 1; i <= rs.getColumnCount(); i++) {
/* 2165 */               int jdbctype; Column c = rs.getColumn(i);
/* 2166 */               CryptoMetadata cryptoMetadata = c.getCryptoMetadata();
/*      */               
/* 2168 */               TypeInfo ti = c.getTypeInfo();
/* 2169 */               checkValidColumns(ti);
/* 2170 */               if (null != cryptoMetadata) {
/* 2171 */                 jdbctype = cryptoMetadata.getBaseTypeInfo().getSSType().getJDBCType().getIntValue();
/*      */               } else {
/* 2173 */                 jdbctype = ti.getSSType().getJDBCType().getIntValue();
/*      */               } 
/* 2175 */               batchRecord.addColumnMetadata(i, c.getColumnName(), jdbctype, ti.getPrecision(), ti.getScale());
/*      */             } 
/*      */             
/* 2178 */             SQLServerBulkCopy bcOperation = new SQLServerBulkCopy(this.connection);
/* 2179 */             SQLServerBulkCopyOptions option = new SQLServerBulkCopyOptions();
/* 2180 */             option.setBulkCopyTimeout(this.queryTimeout);
/* 2181 */             bcOperation.setBulkCopyOptions(option);
/* 2182 */             bcOperation.setDestinationTableName(tableName);
/* 2183 */             bcOperation.setStmtColumnEncriptionSetting(getStmtColumnEncriptionSetting());
/* 2184 */             bcOperation.setDestinationTableMetadata(rs);
/* 2185 */             bcOperation.writeToServer(batchRecord);
/* 2186 */             bcOperation.close();
/* 2187 */             updateCounts = new long[this.batchParamValues.size()];
/* 2188 */             for (int j = 0; j < this.batchParamValues.size(); j++) {
/* 2189 */               updateCounts[j] = 1L;
/*      */             }
/*      */             
/* 2192 */             this.batchParamValues = null;
/* 2193 */             loggerExternal.exiting(getClassNameLogging(), "executeLargeBatch", updateCounts);
/* 2194 */             long[] arrayOfLong = updateCounts;
/* 2195 */             if (rs != null) rs.close();  if (stmt != null) stmt.close();  return arrayOfLong; } catch (Throwable throwable) { if (rs != null)
/*      */               try { rs.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (Throwable throwable) { if (stmt != null)
/* 2197 */             try { stmt.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  }  } catch (SQLException e)
/*      */     
/* 2199 */     { throw new BatchUpdateException(e.getMessage(), null, 0, null); }
/* 2200 */     catch (IllegalArgumentException e)
/*      */     
/* 2202 */     { if (getStatementLogger().isLoggable(Level.FINE)) {
/* 2203 */         getStatementLogger().fine("Parsing user's Batch Insert SQL Query failed: " + e.getMessage());
/* 2204 */         getStatementLogger().fine("Falling back to the original implementation for Batch Insert.");
/*      */       }  }
/*      */ 
/*      */     
/* 2208 */     if (null == this.batchParamValues) {
/* 2209 */       updateCounts = new long[0];
/*      */     } else {
/*      */ 
/*      */       
/*      */       try {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2222 */         for (Parameter[] paramValues : this.batchParamValues) {
/* 2223 */           for (Parameter paramValue : paramValues) {
/* 2224 */             if (paramValue.isOutput()) {
/* 2225 */               throw new BatchUpdateException(
/* 2226 */                   SQLServerException.getErrString("R_outParamsNotPermittedinBatch"), null, 0, null);
/*      */             }
/*      */           } 
/*      */         } 
/*      */         
/* 2231 */         PrepStmtBatchExecCmd batchCommand = new PrepStmtBatchExecCmd(this);
/*      */         
/* 2233 */         executeStatement(batchCommand);
/*      */         
/* 2235 */         updateCounts = new long[batchCommand.updateCounts.length];
/*      */         
/* 2237 */         System.arraycopy(batchCommand.updateCounts, 0, updateCounts, 0, batchCommand.updateCounts.length);
/*      */ 
/*      */         
/* 2240 */         if (null != batchCommand.batchException) {
/* 2241 */           DriverJDBCVersion.throwBatchUpdateException(batchCommand.batchException, updateCounts);
/*      */         }
/*      */       } finally {
/*      */         
/* 2245 */         this.batchParamValues = null;
/*      */       } 
/* 2247 */     }  loggerExternal.exiting(getClassNameLogging(), "executeLargeBatch", updateCounts);
/* 2248 */     return updateCounts;
/*      */   }
/*      */   private void checkValidColumns(TypeInfo ti) throws SQLServerException {
/*      */     String typeName;
/* 2252 */     int jdbctype = ti.getSSType().getJDBCType().getIntValue();
/*      */ 
/*      */     
/* 2255 */     switch (jdbctype) {
/*      */       case -155:
/*      */       case -151:
/*      */       case -150:
/*      */       case -148:
/*      */       case -146:
/*      */       case 91:
/*      */       case 92:
/* 2263 */         typeName = ti.getSSTypeName();
/* 2264 */         form = new MessageFormat(SQLServerException.getErrString("R_BulkTypeNotSupportedDW"));
/* 2265 */         throw new IllegalArgumentException(form.format(new Object[] { typeName }));
/*      */       
/*      */       case -145:
/*      */       case -16:
/*      */       case -15:
/*      */       case -9:
/*      */       case -7:
/*      */       case -6:
/*      */       case -5:
/*      */       case -4:
/*      */       case -3:
/*      */       case -2:
/*      */       case -1:
/*      */       case 1:
/*      */       case 2:
/*      */       case 3:
/*      */       case 4:
/*      */       case 5:
/*      */       case 7:
/*      */       case 8:
/*      */       case 12:
/* 2286 */         typeName = ti.getSSTypeName();
/* 2287 */         if ("geometry".equalsIgnoreCase(typeName) || "geography".equalsIgnoreCase(typeName)) {
/* 2288 */           form = new MessageFormat(SQLServerException.getErrString("R_BulkTypeNotSupported"));
/* 2289 */           throw new IllegalArgumentException(form.format(new Object[] { typeName }));
/*      */         } 
/*      */       case -156:
/*      */       case 93:
/*      */       case 2013:
/*      */       case 2014:
/*      */         return;
/*      */     } 
/* 2297 */     MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_BulkTypeNotSupported"));
/* 2298 */     String unsupportedDataType = JDBCType.of(jdbctype).toString();
/* 2299 */     throw new IllegalArgumentException(form.format(new Object[] { unsupportedDataType }));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void checkAdditionalQuery() {
/* 2305 */     while (checkAndRemoveCommentsAndSpace(true));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2310 */     if (this.localUserSQL.length() > 0) {
/* 2311 */       throw new IllegalArgumentException("Multiple queries are not allowed.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String parseUserSQLForTableNameDW(boolean hasInsertBeenFound, boolean hasIntoBeenFound, boolean hasTableBeenFound, boolean isExpectingTableName) {
/* 2321 */     while (checkAndRemoveCommentsAndSpace(false));
/*      */     
/* 2323 */     StringBuilder sb = new StringBuilder();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2329 */     if (hasTableBeenFound && !isExpectingTableName) {
/* 2330 */       if (checkSQLLength(1) && ".".equalsIgnoreCase(this.localUserSQL.substring(0, 1))) {
/* 2331 */         sb.append(".");
/* 2332 */         this.localUserSQL = this.localUserSQL.substring(1);
/* 2333 */         return sb.toString() + sb.toString();
/*      */       } 
/* 2335 */       return "";
/*      */     } 
/*      */ 
/*      */     
/* 2339 */     if (!hasInsertBeenFound && checkSQLLength(6) && "insert".equalsIgnoreCase(this.localUserSQL.substring(0, 6))) {
/* 2340 */       this.localUserSQL = this.localUserSQL.substring(6);
/* 2341 */       return parseUserSQLForTableNameDW(true, hasIntoBeenFound, hasTableBeenFound, isExpectingTableName);
/*      */     } 
/*      */     
/* 2344 */     if (!hasIntoBeenFound && checkSQLLength(6) && "into".equalsIgnoreCase(this.localUserSQL.substring(0, 4))) {
/*      */ 
/*      */       
/* 2347 */       if (Character.isWhitespace(this.localUserSQL.charAt(4)) || (this.localUserSQL
/* 2348 */         .charAt(4) == '/' && this.localUserSQL.charAt(5) == '*')) {
/* 2349 */         this.localUserSQL = this.localUserSQL.substring(4);
/* 2350 */         return parseUserSQLForTableNameDW(hasInsertBeenFound, true, hasTableBeenFound, isExpectingTableName);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2356 */       return parseUserSQLForTableNameDW(hasInsertBeenFound, true, hasTableBeenFound, isExpectingTableName);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2363 */     if (checkSQLLength(1) && "[".equalsIgnoreCase(this.localUserSQL.substring(0, 1))) {
/* 2364 */       int tempint = this.localUserSQL.indexOf("]", 1);
/*      */ 
/*      */       
/* 2367 */       if (tempint < 0) {
/* 2368 */         throw new IllegalArgumentException("Invalid SQL Query.");
/*      */       }
/*      */ 
/*      */       
/* 2372 */       while (tempint >= 0 && checkSQLLength(tempint + 2) && this.localUserSQL.charAt(tempint + 1) == ']') {
/* 2373 */         tempint = this.localUserSQL.indexOf("]", tempint + 2);
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 2378 */       sb.append(this.localUserSQL.substring(0, tempint + 1));
/* 2379 */       this.localUserSQL = this.localUserSQL.substring(tempint + 1);
/* 2380 */       return sb.toString() + sb.toString();
/*      */     } 
/*      */ 
/*      */     
/* 2384 */     if (checkSQLLength(1) && "\"".equalsIgnoreCase(this.localUserSQL.substring(0, 1))) {
/* 2385 */       int tempint = this.localUserSQL.indexOf("\"", 1);
/*      */ 
/*      */       
/* 2388 */       if (tempint < 0) {
/* 2389 */         throw new IllegalArgumentException("Invalid SQL Query.");
/*      */       }
/*      */ 
/*      */       
/* 2393 */       while (tempint >= 0 && checkSQLLength(tempint + 2) && this.localUserSQL.charAt(tempint + 1) == '"') {
/* 2394 */         tempint = this.localUserSQL.indexOf("\"", tempint + 2);
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 2399 */       sb.append(this.localUserSQL.substring(0, tempint + 1));
/* 2400 */       this.localUserSQL = this.localUserSQL.substring(tempint + 1);
/* 2401 */       return sb.toString() + sb.toString();
/*      */     } 
/*      */ 
/*      */     
/* 2405 */     while (this.localUserSQL.length() > 0) {
/*      */ 
/*      */       
/* 2408 */       if (this.localUserSQL.charAt(0) == '.' || Character.isWhitespace(this.localUserSQL.charAt(0)) || 
/* 2409 */         checkAndRemoveCommentsAndSpace(false))
/* 2410 */         return sb.toString() + sb.toString(); 
/* 2411 */       if (this.localUserSQL.charAt(0) == ';') {
/* 2412 */         throw new IllegalArgumentException("End of query detected before VALUES have been found.");
/*      */       }
/* 2414 */       sb.append(this.localUserSQL.charAt(0));
/* 2415 */       this.localUserSQL = this.localUserSQL.substring(1);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2420 */     throw new IllegalArgumentException("Invalid SQL Query.");
/*      */   }
/*      */ 
/*      */   
/*      */   private ArrayList<String> parseUserSQLForColumnListDW() {
/* 2425 */     while (checkAndRemoveCommentsAndSpace(false));
/*      */ 
/*      */ 
/*      */     
/* 2429 */     if (checkSQLLength(1) && "(".equalsIgnoreCase(this.localUserSQL.substring(0, 1))) {
/* 2430 */       this.localUserSQL = this.localUserSQL.substring(1);
/* 2431 */       return parseUserSQLForColumnListDWHelper(new ArrayList<>());
/*      */     } 
/* 2433 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   private ArrayList<String> parseUserSQLForColumnListDWHelper(ArrayList<String> listOfColumns) {
/* 2438 */     while (checkAndRemoveCommentsAndSpace(false));
/*      */     
/* 2440 */     StringBuilder sb = new StringBuilder();
/* 2441 */     while (this.localUserSQL.length() > 0) {
/* 2442 */       while (checkAndRemoveCommentsAndSpace(false));
/*      */ 
/*      */       
/* 2445 */       if (checkSQLLength(1) && this.localUserSQL.charAt(0) == ')') {
/* 2446 */         this.localUserSQL = this.localUserSQL.substring(1);
/* 2447 */         return listOfColumns;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 2452 */       if (this.localUserSQL.charAt(0) == ',') {
/* 2453 */         this.localUserSQL = this.localUserSQL.substring(1);
/* 2454 */         while (checkAndRemoveCommentsAndSpace(false));
/*      */       } 
/*      */ 
/*      */       
/* 2458 */       if (this.localUserSQL.charAt(0) == '[') {
/* 2459 */         int tempint = this.localUserSQL.indexOf("]", 1);
/*      */ 
/*      */         
/* 2462 */         if (tempint < 0) {
/* 2463 */           throw new IllegalArgumentException("Invalid SQL Query.");
/*      */         }
/*      */ 
/*      */         
/* 2467 */         while (tempint >= 0 && checkSQLLength(tempint + 2) && this.localUserSQL.charAt(tempint + 1) == ']') {
/* 2468 */           this.localUserSQL = this.localUserSQL.substring(0, tempint) + this.localUserSQL.substring(0, tempint);
/* 2469 */           tempint = this.localUserSQL.indexOf("]", tempint + 1);
/*      */         } 
/*      */ 
/*      */         
/* 2473 */         String tempstr = this.localUserSQL.substring(1, tempint);
/* 2474 */         this.localUserSQL = this.localUserSQL.substring(tempint + 1);
/* 2475 */         listOfColumns.add(tempstr);
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/* 2480 */       if (this.localUserSQL.charAt(0) == '"') {
/* 2481 */         int tempint = this.localUserSQL.indexOf("\"", 1);
/*      */ 
/*      */         
/* 2484 */         if (tempint < 0) {
/* 2485 */           throw new IllegalArgumentException("Invalid SQL Query.");
/*      */         }
/*      */ 
/*      */         
/* 2489 */         while (tempint >= 0 && checkSQLLength(tempint + 2) && this.localUserSQL.charAt(tempint + 1) == '"') {
/* 2490 */           this.localUserSQL = this.localUserSQL.substring(0, tempint) + this.localUserSQL.substring(0, tempint);
/* 2491 */           tempint = this.localUserSQL.indexOf("\"", tempint + 1);
/*      */         } 
/*      */ 
/*      */         
/* 2495 */         String tempstr = this.localUserSQL.substring(1, tempint);
/* 2496 */         this.localUserSQL = this.localUserSQL.substring(tempint + 1);
/* 2497 */         listOfColumns.add(tempstr);
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/* 2502 */       while (this.localUserSQL.length() > 0) {
/* 2503 */         if (checkAndRemoveCommentsAndSpace(false)) {
/*      */           continue;
/*      */         }
/* 2506 */         if (this.localUserSQL.charAt(0) == ',') {
/* 2507 */           this.localUserSQL = this.localUserSQL.substring(1);
/* 2508 */           listOfColumns.add(sb.toString());
/* 2509 */           sb.setLength(0); break;
/*      */         } 
/* 2511 */         if (this.localUserSQL.charAt(0) == ')') {
/* 2512 */           this.localUserSQL = this.localUserSQL.substring(1);
/* 2513 */           listOfColumns.add(sb.toString());
/* 2514 */           return listOfColumns;
/*      */         } 
/* 2516 */         sb.append(this.localUserSQL.charAt(0));
/* 2517 */         this.localUserSQL = this.localUserSQL.substring(1);
/* 2518 */         this.localUserSQL = this.localUserSQL.trim();
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2525 */     throw new IllegalArgumentException("Invalid SQL Query.");
/*      */   }
/*      */ 
/*      */   
/*      */   private ArrayList<String> parseUserSQLForValueListDW(boolean hasValuesBeenFound) {
/* 2530 */     if (checkAndRemoveCommentsAndSpace(false));
/*      */     
/* 2532 */     if (!hasValuesBeenFound) {
/*      */       
/* 2534 */       if (checkSQLLength(6) && "VALUES".equalsIgnoreCase(this.localUserSQL.substring(0, 6))) {
/* 2535 */         this.localUserSQL = this.localUserSQL.substring(6);
/*      */ 
/*      */         
/* 2538 */         while (checkAndRemoveCommentsAndSpace(false));
/*      */         
/* 2540 */         if (checkSQLLength(1) && "(".equalsIgnoreCase(this.localUserSQL.substring(0, 1))) {
/* 2541 */           this.localUserSQL = this.localUserSQL.substring(1);
/* 2542 */           return parseUserSQLForValueListDWHelper(new ArrayList<>());
/*      */         } 
/*      */       } 
/*      */     } else {
/*      */       
/* 2547 */       while (checkAndRemoveCommentsAndSpace(false));
/*      */       
/* 2549 */       if (checkSQLLength(1) && "(".equalsIgnoreCase(this.localUserSQL.substring(0, 1))) {
/* 2550 */         this.localUserSQL = this.localUserSQL.substring(1);
/* 2551 */         return parseUserSQLForValueListDWHelper(new ArrayList<>());
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 2556 */     throw new IllegalArgumentException("Invalid SQL Query.");
/*      */   }
/*      */ 
/*      */   
/*      */   private ArrayList<String> parseUserSQLForValueListDWHelper(ArrayList<String> listOfValues) {
/* 2561 */     while (checkAndRemoveCommentsAndSpace(false));
/*      */ 
/*      */     
/* 2564 */     StringBuilder sb = new StringBuilder();
/* 2565 */     while (this.localUserSQL.length() > 0) {
/* 2566 */       if (checkAndRemoveCommentsAndSpace(false)) {
/*      */         continue;
/*      */       }
/* 2569 */       if (this.localUserSQL.charAt(0) == ',' || this.localUserSQL.charAt(0) == ')') {
/* 2570 */         if (this.localUserSQL.charAt(0) == ',') {
/* 2571 */           this.localUserSQL = this.localUserSQL.substring(1);
/* 2572 */           if (!"?".equals(sb.toString()))
/*      */           {
/* 2574 */             throw new IllegalArgumentException("Only fully parameterized queries are allowed for using Bulk Copy API for batch insert at the moment.");
/*      */           }
/*      */           
/* 2577 */           listOfValues.add(sb.toString());
/* 2578 */           sb.setLength(0); continue;
/*      */         } 
/* 2580 */         this.localUserSQL = this.localUserSQL.substring(1);
/* 2581 */         listOfValues.add(sb.toString());
/* 2582 */         return listOfValues;
/*      */       } 
/*      */       
/* 2585 */       sb.append(this.localUserSQL.charAt(0));
/* 2586 */       this.localUserSQL = this.localUserSQL.substring(1);
/* 2587 */       this.localUserSQL = this.localUserSQL.trim();
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2615 */     throw new IllegalArgumentException("Invalid SQL Query.");
/*      */   }
/*      */   
/*      */   private boolean checkAndRemoveCommentsAndSpace(boolean checkForSemicolon) {
/* 2619 */     this.localUserSQL = this.localUserSQL.trim();
/*      */     
/* 2621 */     while (checkForSemicolon && null != this.localUserSQL && this.localUserSQL.length() > 0 && this.localUserSQL
/* 2622 */       .charAt(0) == ';') {
/* 2623 */       this.localUserSQL = this.localUserSQL.substring(1);
/*      */     }
/*      */     
/* 2626 */     if (null == this.localUserSQL || this.localUserSQL.length() < 2) {
/* 2627 */       return false;
/*      */     }
/*      */     
/* 2630 */     if ("/*".equalsIgnoreCase(this.localUserSQL.substring(0, 2))) {
/* 2631 */       int temp = this.localUserSQL.indexOf("*/") + 2;
/* 2632 */       if (temp <= 0) {
/* 2633 */         this.localUserSQL = "";
/* 2634 */         return false;
/*      */       } 
/* 2636 */       this.localUserSQL = this.localUserSQL.substring(temp);
/* 2637 */       return true;
/*      */     } 
/*      */     
/* 2640 */     if ("--".equalsIgnoreCase(this.localUserSQL.substring(0, 2))) {
/* 2641 */       int temp = this.localUserSQL.indexOf("\n") + 1;
/* 2642 */       if (temp <= 0) {
/* 2643 */         this.localUserSQL = "";
/* 2644 */         return false;
/*      */       } 
/* 2646 */       this.localUserSQL = this.localUserSQL.substring(temp);
/* 2647 */       return true;
/*      */     } 
/*      */     
/* 2650 */     return false;
/*      */   }
/*      */   
/*      */   private boolean checkSQLLength(int length) {
/* 2654 */     if (null == this.localUserSQL || this.localUserSQL.length() < length) {
/* 2655 */       throw new IllegalArgumentException("Invalid SQL Query.");
/*      */     }
/* 2657 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   private final class PrepStmtBatchExecCmd
/*      */     extends TDSCommand
/*      */   {
/*      */     private static final long serialVersionUID = 5225705304799552318L;
/*      */     private final SQLServerPreparedStatement stmt;
/*      */     SQLServerException batchException;
/*      */     long[] updateCounts;
/*      */     
/*      */     PrepStmtBatchExecCmd(SQLServerPreparedStatement stmt) {
/* 2670 */       super(stmt.toString() + " executeBatch", SQLServerPreparedStatement.this.queryTimeout, SQLServerPreparedStatement.this.cancelQueryTimeoutSeconds);
/* 2671 */       this.stmt = stmt;
/*      */     }
/*      */     
/*      */     final boolean doExecute() throws SQLServerException {
/* 2675 */       this.stmt.doExecutePreparedStatementBatch(this);
/* 2676 */       return true;
/*      */     }
/*      */     
/*      */     final void processResponse(TDSReader tdsReader) throws SQLServerException {
/* 2680 */       SQLServerPreparedStatement.this.ensureExecuteResultsReader(tdsReader);
/* 2681 */       SQLServerPreparedStatement.this.processExecuteResults();
/*      */     }
/*      */   }
/*      */   
/*      */   final void doExecutePreparedStatementBatch(PrepStmtBatchExecCmd batchCommand) throws SQLServerException {
/* 2686 */     this.executeMethod = 4;
/*      */     
/* 2688 */     batchCommand.batchException = null;
/* 2689 */     int numBatches = this.batchParamValues.size();
/* 2690 */     batchCommand.updateCounts = new long[numBatches];
/* 2691 */     for (int i = 0; i < numBatches; i++) {
/* 2692 */       batchCommand.updateCounts[i] = -3L;
/*      */     }
/* 2694 */     int numBatchesPrepared = 0;
/* 2695 */     int numBatchesExecuted = 0;
/*      */     
/* 2697 */     if (isSelect(this.userSQL)) {
/* 2698 */       SQLServerException.makeFromDriverError(this.connection, this, 
/* 2699 */           SQLServerException.getErrString("R_selectNotPermittedinBatch"), (String)null, true);
/*      */     }
/*      */ 
/*      */     
/* 2703 */     this.connection.setMaxRows(0);
/*      */     
/* 2705 */     if (loggerExternal.isLoggable(Level.FINER) && Util.isActivityTraceOn()) {
/* 2706 */       loggerExternal.finer(toString() + " ActivityId: " + toString());
/*      */     }
/*      */     
/* 2709 */     Parameter[] batchParam = new Parameter[this.inOutParam.length];
/*      */     
/* 2711 */     TDSWriter tdsWriter = null;
/* 2712 */     while (numBatchesExecuted < numBatches) {
/*      */       
/* 2714 */       Parameter[] paramValues = this.batchParamValues.get(numBatchesPrepared);
/* 2715 */       assert paramValues.length == batchParam.length;
/* 2716 */       System.arraycopy(paramValues, 0, batchParam, 0, paramValues.length);
/*      */       
/* 2718 */       boolean hasExistingTypeDefinitions = (this.preparedTypeDefinitions != null);
/* 2719 */       boolean hasNewTypeDefinitions = buildPreparedStrings(batchParam, false);
/*      */       
/* 2721 */       if (0 == numBatchesExecuted && !this.isInternalEncryptionQuery && this.connection.isAEv2() && !this.encryptionMetadataIsRetrieved) {
/*      */         
/* 2723 */         this.enclaveCEKs = this.connection.initEnclaveParameters(this.preparedSQL, this.preparedTypeDefinitions, batchParam, this.parameterNames);
/*      */         
/* 2725 */         this.encryptionMetadataIsRetrieved = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2731 */         buildPreparedStrings(batchParam, true);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2737 */         for (Parameter aBatchParam : batchParam) {
/* 2738 */           this.cryptoMetaBatch.add(aBatchParam.cryptoMeta);
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/* 2743 */       if (0 == numBatchesExecuted && Util.shouldHonorAEForParameters(this.stmtColumnEncriptionSetting, this.connection) && 0 < batchParam.length && !this.isInternalEncryptionQuery && !this.encryptionMetadataIsRetrieved) {
/*      */         
/* 2745 */         this.encryptionMetadataIsRetrieved = true;
/* 2746 */         getParameterEncryptionMetadata(batchParam);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2752 */         buildPreparedStrings(batchParam, true);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2758 */         for (Parameter aBatchParam : batchParam) {
/* 2759 */           this.cryptoMetaBatch.add(aBatchParam.cryptoMeta);
/*      */         }
/*      */       } else {
/*      */         
/* 2763 */         for (int j = 0; j < this.cryptoMetaBatch.size(); j++) {
/* 2764 */           (batchParam[j]).cryptoMeta = this.cryptoMetaBatch.get(j);
/*      */         }
/*      */       } 
/*      */       
/* 2768 */       boolean needsPrepare = true;
/*      */       
/* 2770 */       for (int attempt = 1; attempt <= 2; attempt++) {
/*      */ 
/*      */         
/*      */         try {
/* 2774 */           if (reuseCachedHandle(hasNewTypeDefinitions, (1 < attempt))) {
/* 2775 */             hasNewTypeDefinitions = false;
/*      */           }
/*      */           
/* 2778 */           if (numBatchesExecuted < numBatchesPrepared) {
/*      */             
/* 2780 */             tdsWriter.writeByte((byte)-1);
/*      */           } else {
/* 2782 */             resetForReexecute();
/* 2783 */             tdsWriter = batchCommand.startRequest((byte)3);
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2794 */           numBatchesPrepared++;
/* 2795 */           needsPrepare = doPrepExec(tdsWriter, batchParam, hasNewTypeDefinitions, hasExistingTypeDefinitions);
/* 2796 */           if (needsPrepare || numBatchesPrepared == numBatches)
/* 2797 */           { ensureExecuteResultsReader(batchCommand.startResponse(getIsResponseBufferingAdaptive()));
/*      */             
/* 2799 */             boolean retry = false;
/* 2800 */             while (numBatchesExecuted < numBatchesPrepared) {
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 2805 */               startResults();
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               try {
/* 2811 */                 if (!getNextResult(true)) {
/*      */                   return;
/*      */                 }
/*      */ 
/*      */ 
/*      */                 
/* 2817 */                 if (null != this.resultSet) {
/* 2818 */                   SQLServerException.makeFromDriverError(this.connection, this, 
/* 2819 */                       SQLServerException.getErrString("R_resultsetGeneratedForUpdate"), (String)null, false);
/*      */                 }
/*      */               }
/* 2822 */               catch (SQLServerException e) {
/*      */ 
/*      */ 
/*      */                 
/* 2826 */                 if (this.connection.isSessionUnAvailable() || this.connection.rolledBackTransaction()) {
/* 2827 */                   throw e;
/*      */                 }
/*      */                 
/* 2830 */                 if (retryBasedOnFailedReuseOfCachedHandle(e, attempt, needsPrepare, true)) {
/*      */                   
/* 2832 */                   numBatchesPrepared = numBatchesExecuted;
/* 2833 */                   retry = true;
/*      */ 
/*      */                   
/*      */                   break;
/*      */                 } 
/*      */                 
/* 2839 */                 this.updateCount = -3L;
/* 2840 */                 if (null == batchCommand.batchException) {
/* 2841 */                   batchCommand.batchException = e;
/*      */                 }
/*      */               } 
/*      */ 
/*      */ 
/*      */               
/* 2847 */               batchCommand.updateCounts[numBatchesExecuted] = (-1L == this.updateCount) ? -2L : 
/* 2848 */                 this.updateCount;
/* 2849 */               processBatch();
/*      */               
/* 2851 */               numBatchesExecuted++;
/*      */             } 
/* 2853 */             if (!retry)
/*      */             
/*      */             { 
/*      */ 
/*      */               
/* 2858 */               assert numBatchesExecuted == numBatchesPrepared; break; }  } else { break; }
/*      */         
/* 2860 */         } catch (SQLException e) {
/* 2861 */           if (retryBasedOnFailedReuseOfCachedHandle(e, attempt, needsPrepare, true) && this.connection
/* 2862 */             .isStatementPoolingEnabled()) {
/*      */             
/* 2864 */             numBatchesPrepared = numBatchesExecuted;
/*      */           }
/* 2866 */           else if (null != batchCommand.batchException) {
/*      */             
/* 2868 */             numBatchesExecuted = numBatchesPrepared;
/* 2869 */             attempt++;
/*      */           } else {
/*      */             
/* 2872 */             throw e;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setUseFmtOnly(boolean useFmtOnly) throws SQLServerException {
/* 2882 */     checkClosed();
/* 2883 */     this.useFmtOnly = useFmtOnly;
/*      */   }
/*      */ 
/*      */   
/*      */   public final boolean getUseFmtOnly() throws SQLServerException {
/* 2888 */     checkClosed();
/* 2889 */     return this.useFmtOnly;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setCharacterStream(int parameterIndex, Reader reader) throws SQLException {
/* 2894 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2895 */       loggerExternal.entering(getClassNameLogging(), "setCharacterStream", new Object[] { Integer.valueOf(parameterIndex), reader }); 
/* 2896 */     checkClosed();
/* 2897 */     setStream(parameterIndex, StreamType.CHARACTER, reader, JavaType.READER, -1L);
/* 2898 */     loggerExternal.exiting(getClassNameLogging(), "setCharacterStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setCharacterStream(int n, Reader reader, int length) throws SQLServerException {
/* 2903 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2904 */       loggerExternal.entering(getClassNameLogging(), "setCharacterStream", new Object[] { Integer.valueOf(n), reader, Integer.valueOf(length) }); 
/* 2905 */     checkClosed();
/* 2906 */     setStream(n, StreamType.CHARACTER, reader, JavaType.READER, length);
/* 2907 */     loggerExternal.exiting(getClassNameLogging(), "setCharacterStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setCharacterStream(int parameterIndex, Reader reader, long length) throws SQLException {
/* 2912 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2913 */       loggerExternal.entering(getClassNameLogging(), "setCharacterStream", new Object[] {
/* 2914 */             Integer.valueOf(parameterIndex), reader, Long.valueOf(length) }); 
/* 2915 */     checkClosed();
/* 2916 */     setStream(parameterIndex, StreamType.CHARACTER, reader, JavaType.READER, length);
/* 2917 */     loggerExternal.exiting(getClassNameLogging(), "setCharacterStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setNCharacterStream(int parameterIndex, Reader value) throws SQLException {
/* 2922 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2923 */       loggerExternal.entering(getClassNameLogging(), "setNCharacterStream", new Object[] { Integer.valueOf(parameterIndex), value }); 
/* 2924 */     checkClosed();
/* 2925 */     setStream(parameterIndex, StreamType.NCHARACTER, value, JavaType.READER, -1L);
/* 2926 */     loggerExternal.exiting(getClassNameLogging(), "setNCharacterStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setNCharacterStream(int parameterIndex, Reader value, long length) throws SQLException {
/* 2931 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2932 */       loggerExternal.entering(getClassNameLogging(), "setNCharacterStream", new Object[] {
/* 2933 */             Integer.valueOf(parameterIndex), value, Long.valueOf(length) }); 
/* 2934 */     checkClosed();
/* 2935 */     setStream(parameterIndex, StreamType.NCHARACTER, value, JavaType.READER, length);
/* 2936 */     loggerExternal.exiting(getClassNameLogging(), "setNCharacterStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setRef(int i, Ref x) throws SQLException {
/* 2941 */     SQLServerException.throwNotSupportedException(this.connection, this);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setBlob(int i, Blob x) throws SQLException {
/* 2946 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2947 */       loggerExternal.entering(getClassNameLogging(), "setBlob", new Object[] { Integer.valueOf(i), x }); 
/* 2948 */     checkClosed();
/* 2949 */     setValue(i, JDBCType.BLOB, x, JavaType.BLOB, false);
/* 2950 */     loggerExternal.exiting(getClassNameLogging(), "setBlob");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setBlob(int parameterIndex, InputStream inputStream) throws SQLException {
/* 2955 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2956 */       loggerExternal.entering(getClassNameLogging(), "setBlob", new Object[] { Integer.valueOf(parameterIndex), inputStream }); 
/* 2957 */     checkClosed();
/* 2958 */     setStream(parameterIndex, StreamType.BINARY, inputStream, JavaType.INPUTSTREAM, -1L);
/*      */     
/* 2960 */     loggerExternal.exiting(getClassNameLogging(), "setBlob");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setBlob(int parameterIndex, InputStream inputStream, long length) throws SQLException {
/* 2965 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2966 */       loggerExternal.entering(getClassNameLogging(), "setBlob", new Object[] {
/* 2967 */             Integer.valueOf(parameterIndex), inputStream, Long.valueOf(length) }); 
/* 2968 */     checkClosed();
/* 2969 */     setStream(parameterIndex, StreamType.BINARY, inputStream, JavaType.INPUTSTREAM, length);
/* 2970 */     loggerExternal.exiting(getClassNameLogging(), "setBlob");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setClob(int parameterIndex, Clob clobValue) throws SQLException {
/* 2975 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2976 */       loggerExternal.entering(getClassNameLogging(), "setClob", new Object[] { Integer.valueOf(parameterIndex), clobValue }); 
/* 2977 */     checkClosed();
/* 2978 */     setValue(parameterIndex, JDBCType.CLOB, clobValue, JavaType.CLOB, false);
/* 2979 */     loggerExternal.exiting(getClassNameLogging(), "setClob");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setClob(int parameterIndex, Reader reader) throws SQLException {
/* 2984 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2985 */       loggerExternal.entering(getClassNameLogging(), "setClob", new Object[] { Integer.valueOf(parameterIndex), reader }); 
/* 2986 */     checkClosed();
/* 2987 */     setStream(parameterIndex, StreamType.CHARACTER, reader, JavaType.READER, -1L);
/* 2988 */     loggerExternal.exiting(getClassNameLogging(), "setClob");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setClob(int parameterIndex, Reader reader, long length) throws SQLException {
/* 2993 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2994 */       loggerExternal.entering(getClassNameLogging(), "setClob", new Object[] { Integer.valueOf(parameterIndex), reader, Long.valueOf(length) }); 
/* 2995 */     checkClosed();
/* 2996 */     setStream(parameterIndex, StreamType.CHARACTER, reader, JavaType.READER, length);
/* 2997 */     loggerExternal.exiting(getClassNameLogging(), "setClob");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setNClob(int parameterIndex, NClob value) throws SQLException {
/* 3002 */     if (loggerExternal.isLoggable(Level.FINER))
/* 3003 */       loggerExternal.entering(getClassNameLogging(), "setNClob", new Object[] { Integer.valueOf(parameterIndex), value }); 
/* 3004 */     checkClosed();
/* 3005 */     setValue(parameterIndex, JDBCType.NCLOB, value, JavaType.NCLOB, false);
/* 3006 */     loggerExternal.exiting(getClassNameLogging(), "setNClob");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setNClob(int parameterIndex, Reader reader) throws SQLException {
/* 3011 */     if (loggerExternal.isLoggable(Level.FINER))
/* 3012 */       loggerExternal.entering(getClassNameLogging(), "setNClob", new Object[] { Integer.valueOf(parameterIndex), reader }); 
/* 3013 */     checkClosed();
/* 3014 */     setStream(parameterIndex, StreamType.NCHARACTER, reader, JavaType.READER, -1L);
/* 3015 */     loggerExternal.exiting(getClassNameLogging(), "setNClob");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setNClob(int parameterIndex, Reader reader, long length) throws SQLException {
/* 3020 */     if (loggerExternal.isLoggable(Level.FINER))
/* 3021 */       loggerExternal.entering(getClassNameLogging(), "setNClob", new Object[] { Integer.valueOf(parameterIndex), reader, Long.valueOf(length) }); 
/* 3022 */     checkClosed();
/* 3023 */     setStream(parameterIndex, StreamType.NCHARACTER, reader, JavaType.READER, length);
/* 3024 */     loggerExternal.exiting(getClassNameLogging(), "setNClob");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setArray(int i, Array x) throws SQLException {
/* 3029 */     SQLServerException.throwNotSupportedException(this.connection, this);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setDate(int n, Date x, Calendar cal) throws SQLServerException {
/* 3034 */     if (loggerExternal.isLoggable(Level.FINER))
/* 3035 */       loggerExternal.entering(getClassNameLogging(), "setDate", new Object[] { Integer.valueOf(n), x, cal }); 
/* 3036 */     checkClosed();
/* 3037 */     setValue(n, JDBCType.DATE, x, JavaType.DATE, cal, false);
/* 3038 */     loggerExternal.exiting(getClassNameLogging(), "setDate");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setDate(int n, Date x, Calendar cal, boolean forceEncrypt) throws SQLServerException {
/* 3044 */     if (loggerExternal.isLoggable(Level.FINER))
/* 3045 */       loggerExternal.entering(getClassNameLogging(), "setDate", new Object[] { Integer.valueOf(n), x, cal, Boolean.valueOf(forceEncrypt) }); 
/* 3046 */     checkClosed();
/* 3047 */     setValue(n, JDBCType.DATE, x, JavaType.DATE, cal, forceEncrypt);
/* 3048 */     loggerExternal.exiting(getClassNameLogging(), "setDate");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setTime(int n, Time x, Calendar cal) throws SQLServerException {
/* 3053 */     if (loggerExternal.isLoggable(Level.FINER))
/* 3054 */       loggerExternal.entering(getClassNameLogging(), "setTime", new Object[] { Integer.valueOf(n), x, cal }); 
/* 3055 */     checkClosed();
/* 3056 */     setValue(n, JDBCType.TIME, x, JavaType.TIME, cal, false);
/* 3057 */     loggerExternal.exiting(getClassNameLogging(), "setTime");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setTime(int n, Time x, Calendar cal, boolean forceEncrypt) throws SQLServerException {
/* 3063 */     if (loggerExternal.isLoggable(Level.FINER))
/* 3064 */       loggerExternal.entering(getClassNameLogging(), "setTime", new Object[] { Integer.valueOf(n), x, cal, Boolean.valueOf(forceEncrypt) }); 
/* 3065 */     checkClosed();
/* 3066 */     setValue(n, JDBCType.TIME, x, JavaType.TIME, cal, forceEncrypt);
/* 3067 */     loggerExternal.exiting(getClassNameLogging(), "setTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setTimestamp(int n, Timestamp x, Calendar cal) throws SQLServerException {
/* 3072 */     if (loggerExternal.isLoggable(Level.FINER))
/* 3073 */       loggerExternal.entering(getClassNameLogging(), "setTimestamp", new Object[] { Integer.valueOf(n), x, cal }); 
/* 3074 */     checkClosed();
/* 3075 */     setValue(n, JDBCType.TIMESTAMP, x, JavaType.TIMESTAMP, cal, false);
/* 3076 */     loggerExternal.exiting(getClassNameLogging(), "setTimestamp");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setTimestamp(int n, Timestamp x, Calendar cal, boolean forceEncrypt) throws SQLServerException {
/* 3082 */     if (loggerExternal.isLoggable(Level.FINER))
/* 3083 */       loggerExternal.entering(getClassNameLogging(), "setTimestamp", new Object[] { Integer.valueOf(n), x, cal, Boolean.valueOf(forceEncrypt) }); 
/* 3084 */     checkClosed();
/* 3085 */     setValue(n, JDBCType.TIMESTAMP, x, JavaType.TIMESTAMP, cal, forceEncrypt);
/* 3086 */     loggerExternal.exiting(getClassNameLogging(), "setTimestamp");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setNull(int paramIndex, int sqlType, String typeName) throws SQLServerException {
/* 3091 */     if (loggerExternal.isLoggable(Level.FINER))
/* 3092 */       loggerExternal.entering(getClassNameLogging(), "setNull", new Object[] { Integer.valueOf(paramIndex), Integer.valueOf(sqlType), typeName }); 
/* 3093 */     checkClosed();
/* 3094 */     if (-153 == sqlType) {
/* 3095 */       setObject(setterGetParam(paramIndex), (Object)null, JavaType.TVP, JDBCType.of(sqlType), (Integer)null, (Integer)null, false, paramIndex, typeName);
/*      */     } else {
/*      */       
/* 3098 */       setObject(setterGetParam(paramIndex), (Object)null, JavaType.OBJECT, JDBCType.of(sqlType), (Integer)null, (Integer)null, false, paramIndex, typeName);
/*      */     } 
/*      */     
/* 3101 */     loggerExternal.exiting(getClassNameLogging(), "setNull");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final ParameterMetaData getParameterMetaData(boolean forceRefresh) throws SQLServerException {
/* 3107 */     SQLServerParameterMetaData pmd = this.connection.getCachedParameterMetadata(this.sqlTextCacheKey);
/*      */     
/* 3109 */     if (!forceRefresh && null != pmd) {
/* 3110 */       return pmd;
/*      */     }
/* 3112 */     loggerExternal.entering(getClassNameLogging(), "getParameterMetaData");
/* 3113 */     checkClosed();
/* 3114 */     pmd = new SQLServerParameterMetaData(this, this.userSQL);
/* 3115 */     this.connection.registerCachedParameterMetadata(this.sqlTextCacheKey, pmd);
/* 3116 */     loggerExternal.exiting(getClassNameLogging(), "getParameterMetaData", pmd);
/* 3117 */     return pmd;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ParameterMetaData getParameterMetaData() throws SQLServerException {
/* 3125 */     return getParameterMetaData(false);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setURL(int parameterIndex, URL x) throws SQLException {
/* 3130 */     SQLServerException.throwNotSupportedException(this.connection, this);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setRowId(int parameterIndex, RowId x) throws SQLException {
/* 3135 */     SQLServerException.throwNotSupportedException(this.connection, this);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setSQLXML(int parameterIndex, SQLXML xmlObject) throws SQLException {
/* 3140 */     if (loggerExternal.isLoggable(Level.FINER))
/* 3141 */       loggerExternal.entering(getClassNameLogging(), "setSQLXML", new Object[] { Integer.valueOf(parameterIndex), xmlObject }); 
/* 3142 */     checkClosed();
/* 3143 */     setSQLXMLInternal(parameterIndex, xmlObject);
/* 3144 */     loggerExternal.exiting(getClassNameLogging(), "setSQLXML");
/*      */   }
/*      */ 
/*      */   
/*      */   public final int executeUpdate(String sql) throws SQLServerException {
/* 3149 */     loggerExternal.entering(getClassNameLogging(), "executeUpdate", sql);
/*      */     
/* 3151 */     MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_cannotTakeArgumentsPreparedOrCallable"));
/* 3152 */     Object[] msgArgs = { "executeUpdate()" };
/* 3153 */     throw new SQLServerException(this, form.format(msgArgs), null, 0, false);
/*      */   }
/*      */ 
/*      */   
/*      */   public final boolean execute(String sql) throws SQLServerException {
/* 3158 */     loggerExternal.entering(getClassNameLogging(), "execute", sql);
/*      */     
/* 3160 */     MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_cannotTakeArgumentsPreparedOrCallable"));
/* 3161 */     Object[] msgArgs = { "execute()" };
/* 3162 */     throw new SQLServerException(this, form.format(msgArgs), null, 0, false);
/*      */   }
/*      */ 
/*      */   
/*      */   public final ResultSet executeQuery(String sql) throws SQLServerException {
/* 3167 */     loggerExternal.entering(getClassNameLogging(), "executeQuery", sql);
/*      */     
/* 3169 */     MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_cannotTakeArgumentsPreparedOrCallable"));
/* 3170 */     Object[] msgArgs = { "executeQuery()" };
/* 3171 */     throw new SQLServerException(this, form.format(msgArgs), null, 0, false);
/*      */   }
/*      */ 
/*      */   
/*      */   public void addBatch(String sql) throws SQLServerException {
/* 3176 */     loggerExternal.entering(getClassNameLogging(), "addBatch", sql);
/*      */     
/* 3178 */     MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_cannotTakeArgumentsPreparedOrCallable"));
/* 3179 */     Object[] msgArgs = { "addBatch()" };
/* 3180 */     throw new SQLServerException(this, form.format(msgArgs), null, 0, false);
/*      */   }
/*      */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerPreparedStatement.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */