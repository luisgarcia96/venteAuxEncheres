/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class BaseInputStream
/*     */   extends InputStream
/*     */ {
/*     */   final boolean isAdaptive;
/*     */   final boolean isStreaming;
/*     */   int payloadLength;
/*  31 */   private static final AtomicInteger lastLoggingID = new AtomicInteger(0);
/*     */   
/*     */   private static int nextLoggingID() {
/*  34 */     return lastLoggingID.incrementAndGet();
/*     */   }
/*     */ 
/*     */   
/*  38 */   static final Logger logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.InputStream");
/*     */   abstract byte[] getBytes() throws SQLServerException;
/*     */   private String traceID;
/*     */   public final String toString() {
/*  42 */     if (this.traceID == null)
/*  43 */       this.traceID = getClass().getName() + "ID:" + getClass().getName(); 
/*  44 */     return this.traceID;
/*     */   }
/*     */   
/*     */   final void setLoggingInfo(String info) {
/*  48 */     if (logger.isLoggable(Level.FINER))
/*  49 */       logger.finer(toString()); 
/*     */   }
/*     */   
/*  52 */   int streamPos = 0;
/*  53 */   int markedStreamPos = 0;
/*     */   TDSReaderMark currentMark;
/*     */   private ServerDTVImpl dtv;
/*     */   TDSReader tdsReader;
/*  57 */   int readLimit = 0;
/*     */   boolean isReadLimitSet = false;
/*     */   
/*     */   BaseInputStream(TDSReader tdsReader, boolean isAdaptive, boolean isStreaming, ServerDTVImpl dtv) {
/*  61 */     this.tdsReader = tdsReader;
/*  62 */     this.isAdaptive = isAdaptive;
/*  63 */     this.isStreaming = isStreaming;
/*     */     
/*  65 */     if (isAdaptive) {
/*  66 */       clearCurrentMark();
/*     */     } else {
/*  68 */       this.currentMark = tdsReader.mark();
/*  69 */     }  this.dtv = dtv;
/*     */   }
/*     */   
/*     */   final void clearCurrentMark() {
/*  73 */     this.currentMark = null;
/*  74 */     this.isReadLimitSet = false;
/*  75 */     if (this.isAdaptive && this.isStreaming)
/*  76 */       this.tdsReader.stream(); 
/*     */   }
/*     */   
/*     */   void closeHelper() throws IOException {
/*  80 */     if (this.isAdaptive && null != this.dtv) {
/*  81 */       if (logger.isLoggable(Level.FINER))
/*  82 */         logger.finer(toString() + " closing the adaptive stream."); 
/*  83 */       this.dtv.setPositionAfterStreamed(this.tdsReader);
/*     */     } 
/*  85 */     this.currentMark = null;
/*  86 */     this.tdsReader = null;
/*  87 */     this.dtv = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void checkClosed() throws IOException {
/*  94 */     if (null == this.tdsReader) {
/*  95 */       throw new IOException(SQLServerException.getErrString("R_streamIsClosed"));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean markSupported() {
/* 104 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void setReadLimit(int readLimit) {
/* 110 */     if (this.isAdaptive && readLimit > 0) {
/* 111 */       this.readLimit = readLimit;
/* 112 */       this.isReadLimitSet = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void resetHelper() throws IOException {
/* 123 */     checkClosed();
/*     */     
/* 125 */     if (null == this.currentMark)
/* 126 */       throw new IOException(SQLServerException.getErrString("R_streamWasNotMarkedBefore")); 
/* 127 */     this.tdsReader.reset(this.currentMark);
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\BaseInputStream.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */