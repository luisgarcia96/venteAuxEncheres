/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import java.security.Provider;
/*    */ import java.security.Security;
/*    */ import org.bouncycastle.jce.provider.BouncyCastleProvider;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SQLServerBouncyCastleLoader
/*    */ {
/*    */   static void loadBouncyCastle() {
/* 17 */     BouncyCastleProvider bouncyCastleProvider = new BouncyCastleProvider();
/* 18 */     if (null == Security.getProvider(bouncyCastleProvider.getName()))
/* 19 */       Security.addProvider((Provider)bouncyCastleProvider); 
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerBouncyCastleLoader.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */