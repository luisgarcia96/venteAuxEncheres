/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.text.MessageFormat;
/*     */ import java.util.logging.Level;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FailoverInfo
/*     */ {
/*     */   private String failoverPartner;
/*     */   private int portNumber;
/*     */   private String failoverInstance;
/*     */   private boolean setUpInfocalled;
/*     */   private boolean useFailoverPartner;
/*     */   
/*     */   boolean getUseFailoverPartner() {
/*  30 */     return this.useFailoverPartner;
/*     */   }
/*     */   
/*     */   FailoverInfo(String failover, SQLServerConnection con, boolean actualFailoverPartner) {
/*  34 */     this.failoverPartner = failover;
/*  35 */     this.useFailoverPartner = actualFailoverPartner;
/*  36 */     this.portNumber = -1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void log(SQLServerConnection con) {
/*  42 */     if (con.getConnectionLogger().isLoggable(Level.FINE)) {
/*  43 */       con.getConnectionLogger().fine(con.toString() + " Failover server :" + con.toString() + " Failover partner is primary : " + this.failoverPartner);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void setupInfo(SQLServerConnection con) throws SQLServerException {
/*  50 */     if (this.setUpInfocalled) {
/*     */       return;
/*     */     }
/*  53 */     if (0 == this.failoverPartner.length()) {
/*  54 */       this.portNumber = SQLServerConnection.DEFAULTPORT;
/*     */     } else {
/*     */       
/*  57 */       int px = this.failoverPartner.indexOf('\\');
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  62 */       if (px >= 0) {
/*  63 */         if (con.getConnectionLogger().isLoggable(Level.FINE))
/*  64 */           con.getConnectionLogger().fine(con.toString() + " Failover server :" + con.toString()); 
/*  65 */         String instanceValue = this.failoverPartner.substring(px + 1, this.failoverPartner.length());
/*  66 */         this.failoverPartner = this.failoverPartner.substring(0, px);
/*  67 */         con.validateMaxSQLLoginName(SQLServerDriverStringProperty.INSTANCE_NAME.toString(), instanceValue);
/*  68 */         this.failoverInstance = instanceValue;
/*  69 */         String instancePort = con.getInstancePort(this.failoverPartner, instanceValue);
/*     */         
/*     */         try {
/*  72 */           this.portNumber = Integer.parseInt(instancePort);
/*  73 */         } catch (NumberFormatException e) {
/*     */           
/*  75 */           MessageFormat form = new MessageFormat(SQLServerException.getErrString("R_invalidPortNumber"));
/*  76 */           Object[] msgArgs = { instancePort };
/*  77 */           SQLServerException.makeFromDriverError(con, null, form.format(msgArgs), null, false);
/*     */         } 
/*     */       } else {
/*  80 */         this.portNumber = SQLServerConnection.DEFAULTPORT;
/*     */       } 
/*  82 */     }  this.setUpInfocalled = true;
/*     */   }
/*     */ 
/*     */   
/*     */   synchronized ServerPortPlaceHolder failoverPermissionCheck(SQLServerConnection con, boolean link) throws SQLServerException {
/*  87 */     setupInfo(con);
/*  88 */     return new ServerPortPlaceHolder(this.failoverPartner, this.portNumber, this.failoverInstance, link);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   synchronized void failoverAdd(SQLServerConnection connection, boolean actualUseFailoverPartner, String actualFailoverPartner) throws SQLServerException {
/*  94 */     if (this.useFailoverPartner != actualUseFailoverPartner) {
/*  95 */       if (connection.getConnectionLogger().isLoggable(Level.FINE))
/*  96 */         connection.getConnectionLogger()
/*  97 */           .fine(connection.toString() + " Failover detected. failover partner=" + connection.toString()); 
/*  98 */       this.useFailoverPartner = actualUseFailoverPartner;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 104 */     if (!actualUseFailoverPartner && !this.failoverPartner.equals(actualFailoverPartner)) {
/* 105 */       this.failoverPartner = actualFailoverPartner;
/*     */       
/* 107 */       this.setUpInfocalled = false;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\FailoverInfo.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */