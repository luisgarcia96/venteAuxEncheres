package com.microsoft.sqlserver.jdbc;

import java.io.InputStream;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLType;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import microsoft.sql.DateTimeOffset;

public interface ISQLServerCallableStatement extends CallableStatement, ISQLServerPreparedStatement {
  @Deprecated
  BigDecimal getBigDecimal(String paramString, int paramInt) throws SQLServerException;
  
  Timestamp getDateTime(int paramInt) throws SQLServerException;
  
  Timestamp getDateTime(String paramString) throws SQLServerException;
  
  Timestamp getDateTime(int paramInt, Calendar paramCalendar) throws SQLServerException;
  
  Timestamp getDateTime(String paramString, Calendar paramCalendar) throws SQLServerException;
  
  Timestamp getSmallDateTime(int paramInt) throws SQLServerException;
  
  Timestamp getSmallDateTime(String paramString) throws SQLServerException;
  
  Timestamp getSmallDateTime(int paramInt, Calendar paramCalendar) throws SQLServerException;
  
  Timestamp getSmallDateTime(String paramString, Calendar paramCalendar) throws SQLServerException;
  
  DateTimeOffset getDateTimeOffset(int paramInt) throws SQLServerException;
  
  DateTimeOffset getDateTimeOffset(String paramString) throws SQLServerException;
  
  InputStream getAsciiStream(int paramInt) throws SQLServerException;
  
  InputStream getAsciiStream(String paramString) throws SQLServerException;
  
  BigDecimal getMoney(int paramInt) throws SQLServerException;
  
  BigDecimal getMoney(String paramString) throws SQLServerException;
  
  BigDecimal getSmallMoney(int paramInt) throws SQLServerException;
  
  BigDecimal getSmallMoney(String paramString) throws SQLServerException;
  
  InputStream getBinaryStream(int paramInt) throws SQLServerException;
  
  InputStream getBinaryStream(String paramString) throws SQLServerException;
  
  void setTimestamp(String paramString, Timestamp paramTimestamp, Calendar paramCalendar, boolean paramBoolean) throws SQLServerException;
  
  void setTime(String paramString, Time paramTime, Calendar paramCalendar, boolean paramBoolean) throws SQLServerException;
  
  void setDate(String paramString, Date paramDate, Calendar paramCalendar, boolean paramBoolean) throws SQLServerException;
  
  void setNString(String paramString1, String paramString2, boolean paramBoolean) throws SQLServerException;
  
  void setObject(String paramString, Object paramObject, int paramInt1, int paramInt2, boolean paramBoolean) throws SQLServerException;
  
  void setObject(String paramString, Object paramObject, int paramInt1, Integer paramInteger, int paramInt2) throws SQLServerException;
  
  void setTimestamp(String paramString, Timestamp paramTimestamp, int paramInt) throws SQLServerException;
  
  void setTimestamp(String paramString, Timestamp paramTimestamp, int paramInt, boolean paramBoolean) throws SQLServerException;
  
  void setDateTimeOffset(String paramString, DateTimeOffset paramDateTimeOffset) throws SQLServerException;
  
  void setDateTimeOffset(String paramString, DateTimeOffset paramDateTimeOffset, int paramInt) throws SQLServerException;
  
  void setDateTimeOffset(String paramString, DateTimeOffset paramDateTimeOffset, int paramInt, boolean paramBoolean) throws SQLServerException;
  
  void setTime(String paramString, Time paramTime, int paramInt) throws SQLServerException;
  
  void setTime(String paramString, Time paramTime, int paramInt, boolean paramBoolean) throws SQLServerException;
  
  void setDateTime(String paramString, Timestamp paramTimestamp) throws SQLServerException;
  
  void setDateTime(String paramString, Timestamp paramTimestamp, boolean paramBoolean) throws SQLServerException;
  
  void setSmallDateTime(String paramString, Timestamp paramTimestamp) throws SQLServerException;
  
  void setSmallDateTime(String paramString, Timestamp paramTimestamp, boolean paramBoolean) throws SQLServerException;
  
  void setUniqueIdentifier(String paramString1, String paramString2) throws SQLServerException;
  
  void setUniqueIdentifier(String paramString1, String paramString2, boolean paramBoolean) throws SQLServerException;
  
  void setBytes(String paramString, byte[] paramArrayOfbyte, boolean paramBoolean) throws SQLServerException;
  
  void setByte(String paramString, byte paramByte, boolean paramBoolean) throws SQLServerException;
  
  void setString(String paramString1, String paramString2, boolean paramBoolean) throws SQLServerException;
  
  void setMoney(String paramString, BigDecimal paramBigDecimal) throws SQLServerException;
  
  void setMoney(String paramString, BigDecimal paramBigDecimal, boolean paramBoolean) throws SQLServerException;
  
  void setSmallMoney(String paramString, BigDecimal paramBigDecimal) throws SQLServerException;
  
  void setSmallMoney(String paramString, BigDecimal paramBigDecimal, boolean paramBoolean) throws SQLServerException;
  
  void setBigDecimal(String paramString, BigDecimal paramBigDecimal, int paramInt1, int paramInt2) throws SQLServerException;
  
  void setBigDecimal(String paramString, BigDecimal paramBigDecimal, int paramInt1, int paramInt2, boolean paramBoolean) throws SQLServerException;
  
  void setDouble(String paramString, double paramDouble, boolean paramBoolean) throws SQLServerException;
  
  void setFloat(String paramString, float paramFloat, boolean paramBoolean) throws SQLServerException;
  
  void setInt(String paramString, int paramInt, boolean paramBoolean) throws SQLServerException;
  
  void setLong(String paramString, long paramLong, boolean paramBoolean) throws SQLServerException;
  
  void setShort(String paramString, short paramShort, boolean paramBoolean) throws SQLServerException;
  
  void setBoolean(String paramString, boolean paramBoolean1, boolean paramBoolean2) throws SQLServerException;
  
  void setStructured(String paramString1, String paramString2, SQLServerDataTable paramSQLServerDataTable) throws SQLServerException;
  
  void setStructured(String paramString1, String paramString2, ResultSet paramResultSet) throws SQLServerException;
  
  void setStructured(String paramString1, String paramString2, ISQLServerDataRecord paramISQLServerDataRecord) throws SQLServerException;
  
  void registerOutParameter(String paramString, SQLType paramSQLType, int paramInt1, int paramInt2) throws SQLServerException;
  
  void registerOutParameter(int paramInt1, SQLType paramSQLType, int paramInt2, int paramInt3) throws SQLServerException;
  
  void registerOutParameter(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLServerException;
  
  void registerOutParameter(String paramString, int paramInt1, int paramInt2, int paramInt3) throws SQLServerException;
  
  void setObject(String paramString, Object paramObject, SQLType paramSQLType, int paramInt, boolean paramBoolean) throws SQLServerException;
}


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\ISQLServerCallableStatement.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */