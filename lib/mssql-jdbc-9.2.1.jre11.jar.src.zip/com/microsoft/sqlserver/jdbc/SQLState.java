/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ enum SQLState
/*    */ {
/* 15 */   STATEMENT_CANCELED("HY008"),
/* 16 */   DATA_EXCEPTION_NOT_SPECIFIC("22000"),
/* 17 */   DATA_EXCEPTION_DATETIME_FIELD_OVERFLOW("22008"),
/* 18 */   NUMERIC_DATA_OUT_OF_RANGE("22003"),
/* 19 */   DATA_EXCEPTION_LENGTH_MISMATCH("22026"),
/* 20 */   COL_NOT_FOUND("42S22");
/*    */   
/*    */   private final String sqlStateCode;
/*    */   
/*    */   final String getSQLStateCode() {
/* 25 */     return this.sqlStateCode;
/*    */   }
/*    */   
/*    */   SQLState(String sqlStateCode) {
/* 29 */     this.sqlStateCode = sqlStateCode;
/*    */   }
/*    */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLState.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */