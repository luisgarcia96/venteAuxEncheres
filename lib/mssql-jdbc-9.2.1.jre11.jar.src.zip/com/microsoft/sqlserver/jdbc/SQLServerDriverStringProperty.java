/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ enum SQLServerDriverStringProperty
/*     */ {
/* 339 */   APPLICATION_INTENT("applicationIntent", ApplicationIntent.READ_WRITE.toString()),
/* 340 */   APPLICATION_NAME("applicationName", "Microsoft JDBC Driver for SQL Server"),
/* 341 */   DATABASE_NAME("databaseName", ""),
/* 342 */   FAILOVER_PARTNER("failoverPartner", ""),
/* 343 */   HOSTNAME_IN_CERTIFICATE("hostNameInCertificate", ""),
/* 344 */   INSTANCE_NAME("instanceName", ""),
/* 345 */   JAAS_CONFIG_NAME("jaasConfigurationName", "SQLJDBCDriver"),
/* 346 */   PASSWORD("password", ""),
/* 347 */   RESPONSE_BUFFERING("responseBuffering", "adaptive"),
/* 348 */   SELECT_METHOD("selectMethod", "direct"),
/* 349 */   DOMAIN("domain", ""),
/* 350 */   SERVER_NAME("serverName", ""),
/* 351 */   SERVER_SPN("serverSpn", ""),
/* 352 */   SOCKET_FACTORY_CLASS("socketFactoryClass", ""),
/* 353 */   SOCKET_FACTORY_CONSTRUCTOR_ARG("socketFactoryConstructorArg", ""),
/* 354 */   TRUST_STORE_TYPE("trustStoreType", "JKS"),
/* 355 */   TRUST_STORE("trustStore", ""),
/* 356 */   TRUST_STORE_PASSWORD("trustStorePassword", ""),
/* 357 */   TRUST_MANAGER_CLASS("trustManagerClass", ""),
/* 358 */   TRUST_MANAGER_CONSTRUCTOR_ARG("trustManagerConstructorArg", ""),
/* 359 */   USER("user", ""),
/* 360 */   WORKSTATION_ID("workstationID", ""),
/* 361 */   AUTHENTICATION_SCHEME("authenticationScheme", AuthenticationScheme.nativeAuthentication.toString()),
/* 362 */   AUTHENTICATION("authentication", SqlAuthentication.NotSpecified.toString()),
/* 363 */   ACCESS_TOKEN("accessToken", ""),
/* 364 */   COLUMN_ENCRYPTION("columnEncryptionSetting", ColumnEncryptionSetting.Disabled.toString()),
/* 365 */   ENCLAVE_ATTESTATION_URL("enclaveAttestationUrl", ""),
/* 366 */   ENCLAVE_ATTESTATION_PROTOCOL("enclaveAttestationProtocol", ""),
/* 367 */   KEY_STORE_AUTHENTICATION("keyStoreAuthentication", ""),
/* 368 */   KEY_STORE_SECRET("keyStoreSecret", ""),
/* 369 */   KEY_STORE_LOCATION("keyStoreLocation", ""),
/* 370 */   SSL_PROTOCOL("sslProtocol", SSLProtocol.TLS.toString()),
/* 371 */   MSI_CLIENT_ID("msiClientId", ""),
/* 372 */   KEY_VAULT_PROVIDER_CLIENT_ID("keyVaultProviderClientId", ""),
/* 373 */   KEY_VAULT_PROVIDER_CLIENT_KEY("keyVaultProviderClientKey", ""),
/* 374 */   KEY_STORE_PRINCIPAL_ID("keyStorePrincipalId", ""),
/* 375 */   CLIENT_CERTIFICATE("clientCertificate", ""),
/* 376 */   CLIENT_KEY("clientKey", ""),
/* 377 */   CLIENT_KEY_PASSWORD("clientKeyPassword", ""),
/* 378 */   AAD_SECURE_PRINCIPAL_ID("AADSecurePrincipalId", ""),
/* 379 */   AAD_SECURE_PRINCIPAL_SECRET("AADSecurePrincipalSecret", ""),
/* 380 */   MAX_RESULT_BUFFER("maxResultBuffer", "-1");
/*     */   
/*     */   private final String name;
/*     */   private final String defaultValue;
/*     */   
/*     */   SQLServerDriverStringProperty(String name, String defaultValue) {
/* 386 */     this.name = name;
/* 387 */     this.defaultValue = defaultValue;
/*     */   }
/*     */   
/*     */   String getDefaultValue() {
/* 391 */     return this.defaultValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 396 */     return this.name;
/*     */   }
/*     */ }


/* Location:              C:\Users\luisa\Desktop\PROJETS ENI\ventesAuxEncheresBis\war\DW2M_G3_ventesAuxEncheres.war!\WEB-INF\lib\mssql-jdbc-9.2.1.jre11.jar!\com\microsoft\sqlserver\jdbc\SQLServerDriverStringProperty.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */